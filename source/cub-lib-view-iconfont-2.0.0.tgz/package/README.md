# UXD Icon Font

這是 UXD 小組所使用的前端圖示 Icon Font。

## 版本更動紀錄

### v1.0.0 20210118

- 元件庫上架 **Nexus**，提供 `npm install` 使用方式。
- 新增 **Icons**
  - **44x44**：總共 5 個 Icon。
  - **40x40**：總共 40 個 Icon。
  - **24x24**：總共 24 個 Icon。
  - **18x18**：總共 1 個 Icon。
  - **10x14**：總共 3 個 Icon。

### v1.0.3 20210125

- 修正 `$cub-font-path` 變數設定。

### v1.1.0 20210315

- 新增 **Icons**
  - **44x44**：Photo、Photoerror。
  - **40x40**：Search、Star。
  - **24x24**：User、Delete、Edit、Heart、Star、Print。
- **Icon** 樣式調整
  - **24x24**：Save。（`class` 使用名稱不影響）

### v1.1.1 20210316

- **Icon** 名稱調整
  - **24x24**：Travel 更名為 Suitcase 。
- **Icon** 樣式錯誤修正
  - **24x24**：修正 Home 顯示 Icon，此為代碼重複的錯誤。（`class` 使用名稱不影響）

### v1.2.0 20210317

- **Icon Font** 名稱由 `.cub-font-icon_*` 改為 `.cub-icon-*`。

### v1.2.1 20210329

- 修正 **Font Face** 檔案引用路徑。

### v1.2.2 20210426

- 新增 **Icons**
  - **40x40**：Speaker。
  - **24x24**：Download、Switch。

### v1.2.3 20210514

- 修正 `$cub-font-path` 變數設定。

### v1.2.4 20210514

- 修正新版 `cub-icon-font.min.css` 未編譯的錯誤。

### v1.3.0 20210707

- 元件庫名稱變更，新版本的安裝名稱改為 `cub-lib-view-iconfont`，舊版本元件庫名稱則維持不變。
- 新增 **Icons**
  - **44x44**：Diagnosis、Wifi。
  - **40x40**：Borcken、Blaze、Users、Cart、Play、Notifications、Building、FileScy。
- **Icon** 名稱調整
  - **44x44**：Photoerror 更名為 Nophoto。
  - **40x40**：Ignore 更名為 Close、PPT 更名為 Powerpoint。

### v1.4.0 20210826

- 新增 **Icons**
  - **40x40**：Key、Upload、Identity。
- **Icon** 樣式調整
  - **24x24**：Date、Time。（`class` 使用名稱不影響）

### v1.5.0 20211105

- 新增 **Icons**
  - **40x40**：Check、Message、Mail、Trend、Recruit、Stopwatch。
- **Icon** 名稱調整
  - **40x40**：Borcken 更名為 BuildingBroken、Blaze 更名為 BuildingBlaze、FileScy 更名為 FileSync。

### v1.6.0 20220104

- 新增 **Icons**
  - **24x24**：Import、Update。
- **Icon** 樣式調整
  - **24x24**：Telegram。（`class` 使用名稱不影響）

### v1.7.0 20220315

- 新增 **Icons**
  - **40x40**：User、Component、Layout、Brush、Overview、FileCabinet。
  - **24x24**：Export、Message、Broom、Check。
- **Icon** 樣式調整
  - **40x40**：Search、Recruit。（`class` 使用名稱不影響）

### v1.8.0 20220725

- 新增 **Icons**
  - **40x40**：Budget、Lock、FileCheck、FaqM、SettingM。
  - **24x24**：Upload。

### v1.9.0 20221130

- 新增 **Icons**
  - **40x40**：Copy。
- **Icon** 樣式調整
  - **40x40**：UXD。（`class` 使用名稱不影響）

### v1.10.0 20230217

- 新增 **Icons**
  - **40x40**：Search、Notifications、Team、UsersM。
  - **24x24**：Eye、EyeOff、Info。

### v1.11.0 20230427

- 新增 **Icons**
  - **24x24**：Close L 尺寸。

### v1.12.0 20231114

- 新增 **Icons**
  - **40x40**：Update M 尺寸。
  - **24x24**：Seal L 尺寸。

### v1.12.1 20231212

- **Icon** 尺寸修正
  - Update 原 40x40 M 尺寸修正為 24x24 M 尺寸，`class` 使用名稱由 `.cub-icon-update_40_m` 調整為 `.cub-icon-update_24_m`。

### v1.13.0 20231212

- 新增 **Icons**
  - **40x40**：PenNib M 尺寸、Loading L 尺寸。

### v1.14.0 20240226

- 新增 **Icons**
  - **24x24**：TelegramOff L 尺寸。

### v1.15.0 20240424

- 新增 **Icons**
  - **40x40**：TreePoint M 尺寸、Scoring M 尺寸。
  - **24x24**：Telegram S 尺寸。

### v1.16.0 20240904

- 新增 **Icons**
  - **24x24**：ChevronsUp S 尺寸、ChevronsDown S 尺寸。

### v2.0.0 20251126

- **Icons**
- 新增 425 個全新設計的 Icon 圖示，採用新版設計風格，提升視覺一致性。
- Icon 命名規則全面調整，新版名稱與 1.0.0 不相容。