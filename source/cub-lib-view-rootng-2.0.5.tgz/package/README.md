# CUB RootNG Library

這是由 UXD 小組所建立的 Angular 共用元件庫 RootNG

## Dependencies V2.X.X

| cub-lib-view-rootng | cub-lib-view-utilities |
| ------------------- | ---------------------- |
| 2.0.0               | 3.0.0 以上             |
| 2.0.1               | 3.0.0 以上             |
| 2.0.2               | 3.0.0 以上             |
| 2.0.3               | 3.0.0 以上             |
| 2.0.4               | 3.0.0 以上             |
| 2.0.5               | 3.0.0 以上             |
