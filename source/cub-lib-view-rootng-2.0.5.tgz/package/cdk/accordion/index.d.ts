import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, SimpleChanges, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { UniqueSelectionDispatcher } from 'cub-lib-view-rootng/cdk/collections';
import { Subject } from 'rxjs';

/**
 * Directive whose purpose is to manage the expanded state of CubCdkAccordionItem children.
 */
declare class CubCdkAccordion implements OnDestroy, OnChanges {
    /** Emits when the state of the accordion changes */
    readonly _stateChanges: Subject<SimpleChanges>;
    /** Stream that emits true/false when openAll/closeAll is triggered. */
    readonly _openCloseAllActions: Subject<boolean>;
    /** A readonly id value to use for unique selection coordination. */
    readonly id: string;
    private _multi;
    /** Whether the accordion should allow multiple expanded accordion items simultaneously. */
    get multi(): boolean;
    set multi(multi: BooleanInput);
    /** Opens all enabled accordion items in an accordion where multi is enabled. */
    openAll(): void;
    /** Closes all enabled accordion items in an accordion where multi is enabled. */
    closeAll(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkAccordion, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkAccordion, "cub-cdk-accordion, [cubCdkAccordion]", ["cubCdkAccordion"], { "multi": { "alias": "multi"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * An basic directive expected to be extended and decorated as a component.  Sets up all
 * events and attributes needed to be managed by a CubCdkAccordion parent.
 */
declare class CubCdkAccordionItem implements OnDestroy {
    accordion: CubCdkAccordion;
    private _changeDetectorRef;
    protected _accordionDispatcher: UniqueSelectionDispatcher;
    /** The unique AccordionItem id. */
    readonly id: string;
    /** Subscription to openAll/closeAll events. */
    private _openCloseAllSubscription;
    private _expanded;
    private _disabled;
    /** Whether the AccordionItem is expanded. */
    get expanded(): boolean;
    set expanded(expanded: BooleanInput);
    /** Whether the AccordionItem is disabled. */
    get disabled(): boolean;
    set disabled(disabled: BooleanInput);
    /** Event emitted every time the AccordionItem is closed. */
    readonly closed: EventEmitter<void>;
    /** Event emitted every time the AccordionItem is opened. */
    readonly opened: EventEmitter<void>;
    /** Event emitted when the AccordionItem is destroyed. */
    readonly destroyed: EventEmitter<void>;
    /**
     * Emits whenever the expanded state of the accordion changes.
     * Primarily used to facilitate two-way binding.
     * @docs-private
     */
    readonly expandedChange: EventEmitter<boolean>;
    constructor(accordion: CubCdkAccordion, _changeDetectorRef: ChangeDetectorRef, _accordionDispatcher: UniqueSelectionDispatcher);
    /** Emits an event for the accordion item being destroyed. */
    ngOnDestroy(): void;
    /** Toggles the expanded state of the accordion item. */
    toggle(): void;
    /** Sets the expanded state of the accordion item to false. */
    close(): void;
    /** Sets the expanded state of the accordion item to true. */
    open(): void;
    /** Unregister function for _accordionDispatcher. */
    private _removeUniqueSelectionListener;
    private _subscribeToOpenCloseAllActions;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkAccordionItem, [{ optional: true; skipSelf: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkAccordionItem, "cub-cdk-accordion-item, [cubCdkAccordionItem]", ["cubCdkAccordionItem"], { "expanded": { "alias": "expanded"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "closed": "closed"; "opened": "opened"; "destroyed": "destroyed"; "expandedChange": "expandedChange"; }, never, never, true, never>;
}

declare class CubCdkAccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkAccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkAccordionModule, never, [typeof CubCdkAccordion, typeof CubCdkAccordionItem], [typeof CubCdkAccordion, typeof CubCdkAccordionItem]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkAccordionModule>;
}

export { CubCdkAccordion, CubCdkAccordionItem, CubCdkAccordionModule };
