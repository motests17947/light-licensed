import * as i0 from '@angular/core';
import { InjectionToken, OnDestroy, EventEmitter, NgZone } from '@angular/core';

/**
 * A pending copy-to-clipboard operation.
 *
 * The implementation of copying text to the clipboard modifies the DOM and
 * forces a re-layout. This re-layout can take too long if the string is large,
 * causing the execCommand('copy') to happen too long after the user clicked.
 * This results in the browser refusing to copy. This object lets the
 * re-layout happen in a separate tick from copying by providing a copy function
 * that can be called later.
 *
 * Destroy must be called when no longer in use, regardless of whether `copy` is
 * called.
 */
declare class PendingCopy {
    private readonly _document;
    private _textarea;
    constructor(text: string, _document: Document);
    /** Finishes copying the text. */
    copy(): boolean;
    /** Cleans up DOM changes used to perform the copy operation. */
    destroy(): void;
}

/**
 * A service for copying text to the clipboard.
 */
declare class Clipboard {
    private readonly _document;
    constructor(document: any);
    /**
     * Copies the provided text into the user's clipboard.
     *
     * @param text The string to copy.
     * @returns Whether the operation was successful.
     */
    copy(text: string): boolean;
    /**
     * Prepares a string to be copied later. This is useful for large strings
     * which take too long to successfully render and be copied in the same tick.
     *
     * The caller must call `destroy` on the returned `PendingCopy`.
     *
     * @param text The string to copy.
     * @returns the pending copy operation.
     */
    beginCopy(text: string): PendingCopy;
    static ɵfac: i0.ɵɵFactoryDeclaration<Clipboard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Clipboard>;
}

interface CubCdkCopyToClipboardConfig {
    attempts?: number;
}
declare const CUB_CDK_COPY_TO_CLIPBOARD_CONFIG: InjectionToken<CubCdkCopyToClipboardConfig>;
declare class CubCdkCopyToClipboard implements OnDestroy {
    private _clipboard;
    private _ngZone;
    /** 正在被觸發的所有複製內容 */
    private _pending;
    /** Directive 生命週期是否已被 destroyed */
    private _destroyed;
    /** 觸發複製內容的逾期變數 */
    private _currentTimeout;
    /** 需複製的內容 */
    text: string;
    /**
     * 嘗試複製次數，主要使用在當複製內容過長時，瀏覽器需要時間執行這個行為
     */
    attempts: number;
    /**
     * 不論複製是否成功，當有內容被複製至剪貼板時觸發
     */
    readonly copied: EventEmitter<boolean>;
    constructor(_clipboard: Clipboard, _ngZone: NgZone, config?: CubCdkCopyToClipboardConfig);
    /** 複製內容至剪貼版 */
    copy(attempts?: number): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkCopyToClipboard, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkCopyToClipboard, "[cubCdkCopyToClipboard]", never, { "text": { "alias": "cubCdkCopyToClipboard"; "required": false; }; "attempts": { "alias": "cubCdkCopyToClipboardAttempts"; "required": false; }; }, { "copied": "cubCdkCopyToClipboardCopied"; }, never, never, true, never>;
}

declare class CubCdkClipboardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkClipboardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkClipboardModule, never, [typeof CubCdkCopyToClipboard], [typeof CubCdkCopyToClipboard]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkClipboardModule>;
}

export { CUB_CDK_COPY_TO_CLIPBOARD_CONFIG, Clipboard, CubCdkClipboardModule, CubCdkCopyToClipboard, PendingCopy };
export type { CubCdkCopyToClipboardConfig };
