import { ElementRef } from '@angular/core';
import { Observable } from 'rxjs';

/**
 * Type describing the allowed values for a boolean input.
 * @docs-private
 */
type BooleanInput = string | boolean | null | undefined;
/** Coerces a data-bound value (typically a string) to a boolean. */
declare function coerceBooleanProperty(value: any): boolean;

type NumberInput = string | number | null | undefined;
declare function coerceNumberProperty(value: any): number;
declare function coerceNumberProperty<D>(value: any, fallback: D): number | D;
declare function _isNumberValue(value: any): boolean;

/**
 * Coerces an ElementRef or an Element into an element.
 * Useful for APIs that can accept either a ref or the native element itself.
 */
declare function coerceElement<T>(elementOrRef: ElementRef<T> | T): T;

/** Coerces a value to a CSS pixel value. */
declare function coerceCssPixelValue(value: any): string;

/** Wraps the provided value in an array, unless the provided value is an array. */
declare function coerceArray<T>(value: T | T[]): T[];
declare function coerceArray<T>(value: T | readonly T[]): readonly T[];

/**
 * Coerces a value to an array of trimmed non-empty strings.
 * Any input that is not an array, `null` or `undefined` will be turned into a string
 * via `toString()` and subsequently split with the given separator.
 * `null` and `undefined` will result in an empty array.
 * This results in the following outcomes:
 * - `null` -&gt; `[]`
 * - `[null]` -&gt; `["null"]`
 * - `["a", "b ", " "]` -&gt; `["a", "b"]`
 * - `[1, [2, 3]]` -&gt; `["1", "2,3"]`
 * - `[{ a: 0 }]` -&gt; `["[object Object]"]`
 * - `{ a: 0 }` -&gt; `["[object", "Object]"]`
 *
 * Useful for defining CSS classes or table columns.
 * @param value the value to coerce into an array of strings
 * @param separator split-separator if value isn't an array
 */
declare function coerceStringArray(value: any, separator?: string | RegExp): string[];

/**
 * Given either an Observable or non-Observable value, returns either the original
 * Observable, or wraps it in an Observable that emits the non-Observable value.
 */
declare function coerceObservable<T>(data: T | Observable<T>): Observable<T>;

export { _isNumberValue, coerceArray, coerceBooleanProperty, coerceCssPixelValue, coerceElement, coerceNumberProperty, coerceObservable, coerceStringArray };
export type { BooleanInput, NumberInput };
