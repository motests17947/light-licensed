import * as i0 from '@angular/core';
import { OnDestroy, ElementRef, TemplateRef, NgZone, ViewContainerRef, AfterViewInit, OnChanges, EventEmitter, QueryList, ChangeDetectorRef, SimpleChanges, InjectionToken } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { BooleanInput, NumberInput } from 'cub-lib-view-rootng/cdk/coercion';
import { Direction, Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import * as i7 from 'cub-lib-view-rootng/cdk/scrolling';
import { ViewportRuler, ScrollDispatcher } from 'cub-lib-view-rootng/cdk/scrolling';

declare class CubCdkDragHandle implements OnDestroy {
    element: ElementRef<HTMLElement>;
    _parentDrag: {} | undefined;
    readonly _stateChanges: Subject<CubCdkDragHandle>;
    private _disabled;
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    constructor(element: ElementRef<HTMLElement>, parentDrag?: any);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDragHandle, [null, { optional: true; skipSelf: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkDragHandle, "[cubCdkDragHandle]", never, { "disabled": { "alias": "cubCdkDragHandleDisabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCdkDragPlaceholder<T = any> {
    templateRef: TemplateRef<T>;
    data: T;
    constructor(templateRef: TemplateRef<T>);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDragPlaceholder<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkDragPlaceholder<any>, "ng-template[cubCdkDragPlaceholder]", never, { "data": { "alias": "data"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCdkDragPreview<T = any> {
    templateRef: TemplateRef<T>;
    private _matchSize;
    data: T;
    get matchSize(): boolean;
    set matchSize(value: BooleanInput);
    constructor(templateRef: TemplateRef<T>);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDragPreview<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkDragPreview<any>, "ng-template[cubCdkDragPreview]", never, { "data": { "alias": "data"; "required": false; }; "matchSize": { "alias": "matchSize"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DragDropRegistry<I extends {
    isDragging(): boolean;
}, C> implements OnDestroy {
    private _ngZone;
    readonly pointerMove: Subject<TouchEvent | MouseEvent>;
    readonly pointerUp: Subject<TouchEvent | MouseEvent>;
    readonly scroll: Subject<Event>;
    private _document;
    private _dropInstances;
    private _dragInstances;
    private _activeDragInstances;
    private _globalListeners;
    constructor(_ngZone: NgZone, _document: any);
    ngOnDestroy(): void;
    registerDropContainer(drop: C): void;
    registerDragItem(drag: I): void;
    removeDropContainer(drop: C): void;
    removeDragItem(drag: I): void;
    startDragging(drag: I, event: TouchEvent | MouseEvent): void;
    stopDragging(drag: I): void;
    isDragging(drag: I): boolean;
    scrolled(shadowRoot?: DocumentOrShadowRoot | null): Observable<Event>;
    private _draggingPredicate;
    private _preventDefaultWhileDragging;
    private _persistentTouchmoveListener;
    private _clearGlobalListeners;
    static ɵfac: i0.ɵɵFactoryDeclaration<DragDropRegistry<any, any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DragDropRegistry<any, any>>;
}

declare class DropListRef<T = any> {
    private _dragDropRegistry;
    private _ngZone;
    private _viewportRuler;
    element: HTMLElement | ElementRef<HTMLElement>;
    disabled: boolean;
    sortingDisabled: boolean;
    lockAxis: 'x' | 'y';
    autoScrollDisabled: boolean;
    autoScrollStep: number;
    data: T;
    readonly beforeStarted: Subject<void>;
    readonly entered: Subject<{
        item: DragRef;
        container: DropListRef;
        currentIndex: number;
    }>;
    readonly exited: Subject<{
        item: DragRef;
        container: DropListRef;
    }>;
    readonly dropped: Subject<{
        item: DragRef;
        currentIndex: number;
        previousIndex: number;
        container: DropListRef;
        previousContainer: DropListRef;
        isPointerOverContainer: boolean;
        distance: Point;
        dropPoint: Point;
        event: MouseEvent | TouchEvent;
    }>;
    readonly sorted: Subject<{
        previousIndex: number;
        currentIndex: number;
        container: DropListRef;
        item: DragRef;
    }>;
    private _isDragging;
    private _parentPositions;
    private _sortStrategy;
    private _clientRect;
    private _draggables;
    private _siblings;
    private _activeSiblings;
    private _viewportScrollSubscription;
    private _verticalScrollDirection;
    private _horizontalScrollDirection;
    private _scrollNode;
    private readonly _stopScrollTimers;
    private _cachedShadowRoot;
    private _document;
    private _scrollableElements;
    private _initialScrollSnap;
    constructor(element: ElementRef<HTMLElement> | HTMLElement, _dragDropRegistry: DragDropRegistry<DragRef, DropListRef>, _document: any, _ngZone: NgZone, _viewportRuler: ViewportRuler);
    enterPredicate: (drag: DragRef, drop: DropListRef) => boolean;
    sortPredicate: (index: number, drag: DragRef, drop: DropListRef) => boolean;
    dispose(): void;
    isDragging(): boolean;
    start(): void;
    enter(item: DragRef, pointerX: number, pointerY: number, index?: number): void;
    exit(item: DragRef): void;
    drop(item: DragRef, currentIndex: number, previousIndex: number, previousContainer: DropListRef, isPointerOverContainer: boolean, distance: Point, dropPoint: Point, event?: MouseEvent | TouchEvent): void;
    withItems(items: DragRef[]): this;
    withDirection(direction: Direction): this;
    connectedTo(connectedTo: DropListRef[]): this;
    withOrientation(orientation: 'vertical' | 'horizontal'): this;
    withScrollableParents(elements: HTMLElement[]): this;
    getScrollableParents(): readonly HTMLElement[];
    getItemIndex(item: DragRef): number;
    isReceiving(): boolean;
    _sortItem(item: DragRef, pointerX: number, pointerY: number, pointerDelta: {
        x: number;
        y: number;
    }): void;
    _startScrollingIfNecessary(pointerX: number, pointerY: number): void;
    _stopScrolling(): void;
    _isOverContainer(x: number, y: number): boolean;
    _getSiblingContainerFromPosition(item: DragRef, x: number, y: number): DropListRef | undefined;
    _canReceive(item: DragRef, x: number, y: number): boolean;
    _startReceiving(sibling: DropListRef, items: DragRef[]): void;
    _stopReceiving(sibling: DropListRef): void;
    private _draggingStarted;
    private _cacheParentPositions;
    private _reset;
    private _startScrollInterval;
    private _listenToScrollEvents;
    private _getShadowRoot;
    private _notifyReceivingSiblings;
}

type DragStartDelay = number | {
    touch: number;
    mouse: number;
};
type DragAxis = 'x' | 'y';
type DragConstrainPosition = (point: Point, dragRef: DragRef) => Point;
type DropListOrientation = 'horizontal' | 'vertical';
type PreviewContainer = 'global' | 'parent' | ElementRef<HTMLElement> | HTMLElement;
type SortPredicate<T> = (index: number, item: T) => boolean;

interface DragHelperTemplate<T = any> {
    template: TemplateRef<T> | null;
    viewContainer: ViewContainerRef;
    context: T;
}
interface DragPreviewTemplate<T = any> extends DragHelperTemplate<T> {
    matchSize?: boolean;
}
interface ScrollPosition {
    top: number;
    left: number;
}
interface DragRefConfig {
    dragStartThreshold: number;
    pointerDirectionChangeThreshold: number;
    zIndex?: number;
    parentDragRef?: DragRef;
}
interface DragRefInternal extends DragRef {
}
interface Point {
    x: number;
    y: number;
}
interface Point {
    x: number;
    y: number;
}
interface DropListRefInternal extends DropListRef {
}
interface DragCSSStyleDeclaration extends CSSStyleDeclaration {
    msScrollSnapType: string;
    scrollSnapType: string;
    webkitTapHighlightColor: string;
}
interface DropListSortStrategyItem {
    isDragging(): boolean;
    getPlaceholderElement(): HTMLElement;
    getRootElement(): HTMLElement;
    _sortFromLastPointerPosition(): void;
    getVisibleElement(): HTMLElement;
}
interface DropListSortStrategy<T extends DropListSortStrategyItem> {
    direction: Direction;
    start(items: readonly T[]): void;
    sort(item: T, pointerX: number, pointerY: number, pointerDelta: {
        x: number;
        y: number;
    }): {
        previousIndex: number;
        currentIndex: number;
    } | null;
    enter(item: T, pointerX: number, pointerY: number, index?: number): void;
    withItems(items: readonly T[]): void;
    withSortPredicate(predicate: SortPredicate<T>): void;
    reset(): void;
    getActiveItemsSnapshot(): readonly T[];
    getItemIndex(item: T): number;
    updateOnScroll(topDifference: number, leftDifference: number): void;
}
interface DragDropConfig extends Partial<DragRefConfig> {
    lockAxis?: DragAxis;
    dragStartDelay?: DragStartDelay;
    constrainPosition?: DragConstrainPosition;
    previewClass?: string | string[];
    boundaryElement?: string;
    rootElementSelector?: string;
    draggingDisabled?: boolean;
    sortingDisabled?: boolean;
    listAutoScrollDisabled?: boolean;
    listOrientation?: DropListOrientation;
    zIndex?: number;
    previewContainer?: 'global' | 'parent';
}
interface CubCdkDragStart<T = any> {
    source: CubCdkDrag<T>;
    event: MouseEvent | TouchEvent;
}
interface CubCdkDragRelease<T = any> {
    source: CubCdkDrag<T>;
    event: MouseEvent | TouchEvent;
}
interface CubCdkDragEnd<T = any> {
    source: CubCdkDrag<T>;
    distance: {
        x: number;
        y: number;
    };
    dropPoint: {
        x: number;
        y: number;
    };
    event: MouseEvent | TouchEvent;
}
interface CubCdkDragEnter<T = any, I = T> {
    container: CubCdkDropList<T>;
    item: CubCdkDrag<I>;
    currentIndex: number;
}
interface CubCdkDragExit<T = any, I = T> {
    container: CubCdkDropList<T>;
    item: CubCdkDrag<I>;
}
interface CubCdkDragDrop<T, O = T, I = any> {
    previousIndex: number;
    currentIndex: number;
    item: CubCdkDrag<I>;
    container: CubCdkDropList<T>;
    previousContainer: CubCdkDropList<O>;
    isPointerOverContainer: boolean;
    distance: {
        x: number;
        y: number;
    };
    dropPoint: {
        x: number;
        y: number;
    };
    event: MouseEvent | TouchEvent;
}
interface CubCdkDragMove<T = any> {
    source: CubCdkDrag<T>;
    pointerPosition: {
        x: number;
        y: number;
    };
    event: MouseEvent | TouchEvent;
    distance: {
        x: number;
        y: number;
    };
    delta: {
        x: -1 | 0 | 1;
        y: -1 | 0 | 1;
    };
}
interface CubCdkDragSortEvent<T = any, I = T> {
    previousIndex: number;
    currentIndex: number;
    container: CubCdkDropList<T>;
    item: CubCdkDrag<I>;
}
interface CubCdkDropListInternal extends CubCdkDropList {
}
interface CachedItemPosition<T> {
    drag: T;
    clientRect: ClientRect;
    offset: number;
    initialTransform: string;
}

declare class DragRef<T = any> {
    private _config;
    private _document;
    private _ngZone;
    private _viewportRuler;
    private _dragDropRegistry;
    data: T;
    lockAxis: 'x' | 'y';
    dragStartDelay: number | {
        touch: number;
        mouse: number;
    };
    previewClass: string | string[] | undefined;
    constrainPosition?: (userPointerPosition: Point, dragRef: DragRef, dimensions: ClientRect, pickupPositionInElement: Point) => Point;
    readonly _moveEvents: Subject<{
        source: DragRef;
        pointerPosition: {
            x: number;
            y: number;
        };
        event: MouseEvent | TouchEvent;
        distance: Point;
        delta: {
            x: -1 | 0 | 1;
            y: -1 | 0 | 1;
        };
    }>;
    readonly beforeStarted: Subject<void>;
    readonly started: Subject<{
        source: DragRef;
        event: MouseEvent | TouchEvent;
    }>;
    readonly released: Subject<{
        source: DragRef;
        event: MouseEvent | TouchEvent;
    }>;
    readonly ended: Subject<{
        source: DragRef;
        distance: Point;
        dropPoint: Point;
        event: MouseEvent | TouchEvent;
    }>;
    readonly entered: Subject<{
        container: DropListRef;
        item: DragRef;
        currentIndex: number;
    }>;
    readonly exited: Subject<{
        container: DropListRef;
        item: DragRef;
    }>;
    readonly dropped: Subject<{
        previousIndex: number;
        currentIndex: number;
        item: DragRef;
        container: DropListRef;
        previousContainer: DropListRef;
        distance: Point;
        dropPoint: Point;
        isPointerOverContainer: boolean;
        event: MouseEvent | TouchEvent;
    }>;
    readonly moved: Observable<{
        source: DragRef;
        pointerPosition: {
            x: number;
            y: number;
        };
        event: MouseEvent | TouchEvent;
        distance: Point;
        delta: {
            x: -1 | 0 | 1;
            y: -1 | 0 | 1;
        };
    }>;
    private _disabled;
    private _preview;
    private _previewRef;
    private _previewContainer;
    private _placeholderRef;
    private _placeholder;
    private _pickupPositionInElement;
    private _pickupPositionOnPage;
    private _anchor;
    private _passiveTransform;
    private _activeTransform;
    private _initialTransform?;
    private _hasStartedDragging;
    private _hasMoved;
    private _initialContainer;
    private _initialIndex;
    private _parentPositions;
    private _pointerDirectionDelta;
    private _pointerPositionAtLastDirectionChange;
    private _lastKnownPointerPosition;
    private _rootElement;
    private _ownerSVGElement;
    private _rootElementTapHighlight;
    private _pointerMoveSubscription;
    private _pointerUpSubscription;
    private _scrollSubscription;
    private _resizeSubscription;
    private _lastTouchEventTime;
    private _dragStartTime;
    private _boundaryElement;
    private _nativeInteractionsEnabled;
    private _initialClientRect?;
    private _previewRect?;
    private _boundaryRect?;
    private _previewTemplate?;
    private _placeholderTemplate?;
    private _handles;
    private _disabledHandles;
    private _dropContainer?;
    private _direction;
    private _parentDragRef;
    private _cachedShadowRoot;
    get disabled(): boolean;
    set disabled(value: boolean);
    constructor(element: ElementRef<HTMLElement> | HTMLElement, _config: DragRefConfig, _document: Document, _ngZone: NgZone, _viewportRuler: ViewportRuler, _dragDropRegistry: DragDropRegistry<DragRef, DropListRef>);
    getPlaceholderElement(): HTMLElement;
    getRootElement(): HTMLElement;
    getVisibleElement(): HTMLElement;
    withHandles(handles: (HTMLElement | ElementRef<HTMLElement>)[]): this;
    withPreviewTemplate(template: DragPreviewTemplate | null): this;
    withPlaceholderTemplate(template: DragHelperTemplate | null): this;
    withRootElement(rootElement: ElementRef<HTMLElement> | HTMLElement): this;
    withBoundaryElement(boundaryElement: ElementRef<HTMLElement> | HTMLElement | null): this;
    withParent(parent: DragRef<unknown> | null): this;
    dispose(): void;
    isDragging(): boolean;
    reset(): void;
    disableHandle(handle: HTMLElement): void;
    enableHandle(handle: HTMLElement): void;
    withDirection(direction: Direction): this;
    _withDropContainer(container: DropListRef): void;
    getFreeDragPosition(): Readonly<Point>;
    setFreeDragPosition(value: Point): this;
    withPreviewContainer(value: PreviewContainer): this;
    _sortFromLastPointerPosition(): void;
    private _removeSubscriptions;
    private _destroyPreview;
    private _destroyPlaceholder;
    private _pointerDown;
    private _pointerMove;
    private _pointerUp;
    private _endDragSequence;
    private _startDragSequence;
    private _initializeDragSequence;
    private _cleanupDragArtifacts;
    private _updateActiveDropContainer;
    private _createPreviewElement;
    private _animatePreviewToPlaceholder;
    private _createPlaceholderElement;
    private _getPointerPositionInElement;
    private _getPointerPositionOnPage;
    private _getConstrainedPointerPosition;
    private _updatePointerDirectionDelta;
    private _toggleNativeDragInteractions;
    private _removeRootElementListeners;
    private _applyRootElementTransform;
    private _applyPreviewTransform;
    private _getDragDistance;
    private _cleanupCachedDimensions;
    private _containInsideBoundaryOnResize;
    private _getDragStartDelay;
    private _updateOnScroll;
    private _getViewportScrollPosition;
    private _getShadowRoot;
    private _getPreviewInsertionPoint;
    private _getPreviewRect;
    private _nativeDragStart;
    private _getTargetHandle;
}

declare class DragDrop {
    private _document;
    private _ngZone;
    private _viewportRuler;
    private _dragDropRegistry;
    constructor(_document: any, _ngZone: NgZone, _viewportRuler: ViewportRuler, _dragDropRegistry: DragDropRegistry<DragRef, DropListRef>);
    createDrag<T = any>(element: ElementRef<HTMLElement> | HTMLElement, config?: DragRefConfig): DragRef<T>;
    createDropList<T = any>(element: ElementRef<HTMLElement> | HTMLElement): DropListRef<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DragDrop, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DragDrop>;
}

declare class CubCdkDrag<T = any> implements AfterViewInit, OnChanges, OnDestroy {
    element: ElementRef<HTMLElement>;
    dropContainer: CubCdkDropList;
    private _ngZone;
    private _viewContainerRef;
    private _dir;
    private _changeDetectorRef;
    private _selfHandle?;
    private _parentDrag?;
    private static _dragInstances;
    _dragRef: DragRef<CubCdkDrag<T>>;
    private readonly _destroyed;
    private _disabled;
    data: T;
    lockAxis: DragAxis;
    rootElementSelector: string;
    boundaryElement: string | ElementRef<HTMLElement> | HTMLElement;
    dragStartDelay: DragStartDelay;
    freeDragPosition: Point;
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    constrainPosition?: (userPointerPosition: Point, dragRef: DragRef, dimensions: ClientRect, pickupPositionInElement: Point) => Point;
    previewClass: string | string[];
    previewContainer: PreviewContainer;
    readonly started: EventEmitter<CubCdkDragStart>;
    readonly released: EventEmitter<CubCdkDragRelease>;
    readonly ended: EventEmitter<CubCdkDragEnd>;
    readonly entered: EventEmitter<CubCdkDragEnter<any>>;
    readonly exited: EventEmitter<CubCdkDragExit<any>>;
    readonly dropped: EventEmitter<CubCdkDragDrop<any>>;
    readonly moved: Observable<CubCdkDragMove<T>>;
    _handles: QueryList<CubCdkDragHandle>;
    _previewTemplate: CubCdkDragPreview;
    _placeholderTemplate: CubCdkDragPlaceholder;
    constructor(element: ElementRef<HTMLElement>, dropContainer: CubCdkDropList, _document: any, _ngZone: NgZone, _viewContainerRef: ViewContainerRef, config: DragDropConfig, _dir: Directionality, dragDrop: DragDrop, _changeDetectorRef: ChangeDetectorRef, _selfHandle?: CubCdkDragHandle | undefined, _parentDrag?: CubCdkDrag | undefined);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    getPlaceholderElement(): HTMLElement;
    getRootElement(): HTMLElement;
    reset(): void;
    getFreeDragPosition(): Readonly<Point>;
    setFreeDragPosition(value: Point): void;
    private _updateRootElement;
    private _getBoundaryElement;
    private _syncInputs;
    private _handleEvents;
    private _assignDefaults;
    private _setupHandlesListener;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDrag<any>, [null, { optional: true; skipSelf: true; }, null, null, null, { optional: true; }, { optional: true; }, null, null, { optional: true; self: true; }, { optional: true; skipSelf: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkDrag<any>, "[cubCdkDrag]", ["cubCdkDrag"], { "data": { "alias": "cubCdkDragData"; "required": false; }; "lockAxis": { "alias": "cubCdkDragLockAxis"; "required": false; }; "rootElementSelector": { "alias": "cubCdkDragRootElement"; "required": false; }; "boundaryElement": { "alias": "cubCdkDragBoundary"; "required": false; }; "dragStartDelay": { "alias": "cubCdkDragStartDelay"; "required": false; }; "freeDragPosition": { "alias": "cubCdkDragFreeDragPosition"; "required": false; }; "disabled": { "alias": "cubCdkDragDisabled"; "required": false; }; "constrainPosition": { "alias": "cubCdkDragConstrainPosition"; "required": false; }; "previewClass": { "alias": "cubCdkDragPreviewClass"; "required": false; }; "previewContainer": { "alias": "cubCdkDragPreviewContainer"; "required": false; }; }, { "started": "cubCdkDragStarted"; "released": "cubCdkDragReleased"; "ended": "cubCdkDragEnded"; "entered": "cubCdkDragEntered"; "exited": "cubCdkDragExited"; "dropped": "cubCdkDragDropped"; "moved": "cubCdkDragMoved"; }, ["_previewTemplate", "_placeholderTemplate", "_handles"], never, true, never>;
}

declare class CubCdkDropListGroup<T> implements OnDestroy {
    readonly _items: Set<T>;
    private _disabled;
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDropListGroup<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkDropListGroup<any>, "[cubCdkDropListGroup]", ["cubCdkDropListGroup"], { "disabled": { "alias": "cubCdkDropListGroupDisabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCdkDropList<T = any> implements OnDestroy {
    element: ElementRef<HTMLElement>;
    private _changeDetectorRef;
    private _scrollDispatcher;
    private _dir?;
    private _group?;
    private static _dropLists;
    _dropListRef: DropListRef<CubCdkDropList<T>>;
    private _unsortedItems;
    private _scrollableParentsResolved;
    private _disabled;
    private readonly _destroyed;
    connectedTo: (CubCdkDropList | string)[] | CubCdkDropList | string;
    data: T;
    orientation: DropListOrientation;
    id: string;
    lockAxis: DragAxis;
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    sortingDisabled: BooleanInput;
    enterPredicate: (drag: CubCdkDrag, drop: CubCdkDropList) => boolean;
    sortPredicate: (index: number, drag: CubCdkDrag, drop: CubCdkDropList) => boolean;
    autoScrollDisabled: BooleanInput;
    autoScrollStep: NumberInput;
    readonly dropped: EventEmitter<CubCdkDragDrop<T, any>>;
    readonly entered: EventEmitter<CubCdkDragEnter<T>>;
    readonly exited: EventEmitter<CubCdkDragExit<T>>;
    readonly sorted: EventEmitter<CubCdkDragSortEvent<T>>;
    constructor(element: ElementRef<HTMLElement>, dragDrop: DragDrop, _changeDetectorRef: ChangeDetectorRef, _scrollDispatcher: ScrollDispatcher, _dir?: Directionality | undefined, _group?: CubCdkDropListGroup<CubCdkDropList> | undefined, config?: DragDropConfig);
    addItem(item: CubCdkDrag): void;
    removeItem(item: CubCdkDrag): void;
    getSortedItems(): CubCdkDrag[];
    ngOnDestroy(): void;
    private _setupInputSyncSubscription;
    private _handleEvents;
    private _assignDefaults;
    private _syncItemsWithRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDropList<any>, [null, null, null, null, { optional: true; }, { optional: true; skipSelf: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkDropList<any>, "[cubCdkDropList], cub-cdk-drop-list", ["cubCdkDropList"], { "connectedTo": { "alias": "cubCdkDropListConnectedTo"; "required": false; }; "data": { "alias": "cubCdkDropListData"; "required": false; }; "orientation": { "alias": "cubCdkDropListOrientation"; "required": false; }; "id": { "alias": "id"; "required": false; }; "lockAxis": { "alias": "cubCdkDropListLockAxis"; "required": false; }; "disabled": { "alias": "cubCdkDropListDisabled"; "required": false; }; "sortingDisabled": { "alias": "cubCdkDropListSortingDisabled"; "required": false; }; "enterPredicate": { "alias": "cubCdkDropListEnterPredicate"; "required": false; }; "sortPredicate": { "alias": "cubCdkDropListSortPredicate"; "required": false; }; "autoScrollDisabled": { "alias": "cubCdkDropListAutoScrollDisabled"; "required": false; }; "autoScrollStep": { "alias": "cubCdkDropListAutoScrollStep"; "required": false; }; }, { "dropped": "cubCdkDropListDropped"; "entered": "cubCdkDropListEntered"; "exited": "cubCdkDropListExited"; "sorted": "cubCdkDropListSorted"; }, never, never, true, never>;
}

declare const DRAG_HOST_CLASS = "cub-cdk-drag";
declare const passiveEventListenerOptions: boolean | AddEventListenerOptions;
declare const activeEventListenerOptions: boolean | AddEventListenerOptions;
declare const dragImportantProperties: Set<string>;
declare const MOUSE_EVENT_IGNORE_TIME = 800;
declare const DEFAULT_CONFIG: {
    dragStartThreshold: number;
    pointerDirectionChangeThreshold: number;
};
declare const activeCapturingEventOptions: boolean | AddEventListenerOptions;
declare const CUB_CDK_DRAG_PREVIEW: InjectionToken<CubCdkDragPreview<any>>;
declare const CUB_CDK_DRAG_CONFIG: InjectionToken<DragDropConfig>;
declare const CUB_CDK_DRAG_HANDLE: InjectionToken<CubCdkDragHandle>;
declare const CUB_CDK_DRAG_PARENT: InjectionToken<{}>;
declare const CUB_CDK_DRAG_PLACEHOLDER: InjectionToken<CubCdkDragPlaceholder<any>>;
declare const CUB_CDK_DROP_LIST_GROUP: InjectionToken<CubCdkDropListGroup<unknown>>;
declare const CUB_CDK_DROP_LIST: InjectionToken<CubCdkDropList<any>>;
declare const DROP_PROXIMITY_THRESHOLD = 0.05;
declare const SCROLL_PROXIMITY_THRESHOLD = 0.05;
declare const enum AutoScrollVerticalDirection {
    NONE = 0,
    UP = 1,
    DOWN = 2
}
declare const enum AutoScrollHorizontalDirection {
    NONE = 0,
    LEFT = 1,
    RIGHT = 2
}

declare function assertElementNode(node: Node, name: string): asserts node is HTMLElement;
declare function moveItemInArray<T = any>(array: T[], fromIndex: number, toIndex: number): void;
declare function transferArrayItem<T = any>(currentArray: T[], targetArray: T[], currentIndex: number, targetIndex: number): void;
declare function copyArrayItem<T = any>(currentArray: T[], targetArray: T[], currentIndex: number, targetIndex: number): void;
declare function getMutableClientRect(element: Element): ClientRect;
declare function isInsideClientRect(clientRect: ClientRect, x: number, y: number): boolean;
declare function adjustClientRect(clientRect: {
    top: number;
    bottom: number;
    left: number;
    right: number;
    width: number;
    height: number;
}, top: number, left: number): void;
declare function isPointerNearClientRect(rect: ClientRect, threshold: number, pointerX: number, pointerY: number): boolean;
declare function extendStyles(dest: CSSStyleDeclaration, source: Record<string, string>, importantProperties?: Set<string>): CSSStyleDeclaration;
declare function toggleNativeDragInteractions(element: HTMLElement, enable: boolean): void;
declare function toggleVisibility(element: HTMLElement, enable: boolean, importantProperties?: Set<string>): void;
declare function combineTransforms(transform: string, initialTransform?: string): string;
declare function getTransformTransitionDurationInMs(element: HTMLElement): number;
declare function deepCloneNode(node: HTMLElement): HTMLElement;

declare class SingleAxisSortStrategy<T extends DropListSortStrategyItem> implements DropListSortStrategy<T> {
    private _element;
    private _dragDropRegistry;
    orientation: 'vertical' | 'horizontal';
    direction: Direction;
    private _sortPredicate;
    private _itemPositions;
    private _activeDraggables;
    private _previousSwap;
    constructor(_element: HTMLElement | ElementRef<HTMLElement>, _dragDropRegistry: DragDropRegistry<T, unknown>);
    start(items: readonly T[]): void;
    sort(item: T, pointerX: number, pointerY: number, pointerDelta: {
        x: number;
        y: number;
    }): {
        previousIndex: number;
        currentIndex: number;
    } | null;
    enter(item: T, pointerX: number, pointerY: number, index?: number): void;
    withItems(items: readonly T[]): void;
    withSortPredicate(predicate: SortPredicate<T>): void;
    reset(): void;
    getActiveItemsSnapshot(): readonly T[];
    getItemIndex(item: T): number;
    updateOnScroll(topDifference: number, leftDifference: number): void;
    private _cacheItemPositions;
    private _getItemOffsetPx;
    private _getSiblingOffsetPx;
    private _shouldEnterAsFirstChild;
    private _getItemIndexFromPointerPosition;
}

declare class ParentPositionTracker {
    private _document;
    readonly positions: Map<HTMLElement | Document, {
        scrollPosition: ScrollPosition;
        clientRect?: ClientRect;
    }>;
    constructor(_document: Document);
    clear(): void;
    cache(elements: readonly HTMLElement[]): void;
    handleScroll(event: Event): ScrollPosition | null;
    getViewportScrollPosition(): {
        top: number;
        left: number;
    };
}

declare class CubCdkDragDropModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkDragDropModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkDragDropModule, never, [typeof CubCdkDragHandle, typeof CubCdkDropList, typeof CubCdkDropListGroup, typeof CubCdkDrag, typeof CubCdkDragPlaceholder, typeof CubCdkDragPreview], [typeof i7.CubCdkScrollableModule, typeof CubCdkDragHandle, typeof CubCdkDropList, typeof CubCdkDropListGroup, typeof CubCdkDrag, typeof CubCdkDragPlaceholder, typeof CubCdkDragPreview]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkDragDropModule>;
}

export { AutoScrollHorizontalDirection, AutoScrollVerticalDirection, CUB_CDK_DRAG_CONFIG, CUB_CDK_DRAG_HANDLE, CUB_CDK_DRAG_PARENT, CUB_CDK_DRAG_PLACEHOLDER, CUB_CDK_DRAG_PREVIEW, CUB_CDK_DROP_LIST, CUB_CDK_DROP_LIST_GROUP, CubCdkDrag, CubCdkDragDropModule, CubCdkDragHandle, CubCdkDragPlaceholder, CubCdkDragPreview, CubCdkDropList, CubCdkDropListGroup, DEFAULT_CONFIG, DRAG_HOST_CLASS, DROP_PROXIMITY_THRESHOLD, DragDrop, DragDropRegistry, DragRef, DropListRef, MOUSE_EVENT_IGNORE_TIME, ParentPositionTracker, SCROLL_PROXIMITY_THRESHOLD, SingleAxisSortStrategy, activeCapturingEventOptions, activeEventListenerOptions, adjustClientRect, assertElementNode, combineTransforms, copyArrayItem, deepCloneNode, dragImportantProperties, extendStyles, getMutableClientRect, getTransformTransitionDurationInMs, isInsideClientRect, isPointerNearClientRect, moveItemInArray, passiveEventListenerOptions, toggleNativeDragInteractions, toggleVisibility, transferArrayItem };
export type { CachedItemPosition, CubCdkDragDrop, CubCdkDragEnd, CubCdkDragEnter, CubCdkDragExit, CubCdkDragMove, CubCdkDragRelease, CubCdkDragSortEvent, CubCdkDragStart, CubCdkDropListInternal, DragAxis, DragCSSStyleDeclaration, DragConstrainPosition, DragDropConfig, DragHelperTemplate, DragPreviewTemplate, DragRefConfig, DragRefInternal, DragStartDelay, DropListOrientation, DropListRefInternal, DropListSortStrategy, DropListSortStrategyItem, Point, PreviewContainer, ScrollPosition, SortPredicate };
