import * as i0 from '@angular/core';
import { OnDestroy, ElementRef, AfterContentInit, EventEmitter, NgZone } from '@angular/core';
import { Observable } from 'rxjs';
import { BooleanInput, NumberInput } from 'cub-lib-view-rootng/cdk/coercion';

/**
 * Factory that creates a new MutationObserver and allows us to stub it out in unit tests.
 * @docs-private
 */
declare class MutationObserverFactory {
    create(callback: MutationCallback): MutationObserver | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<MutationObserverFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MutationObserverFactory>;
}
/** An injectable service that allows watching elements for changes to their content. */
declare class ContentObserver implements OnDestroy {
    private _mutationObserverFactory;
    /** Keeps track of the existing MutationObservers so they can be reused. */
    private _observedElements;
    constructor(_mutationObserverFactory: MutationObserverFactory);
    ngOnDestroy(): void;
    /**
     * Observe content changes on an element.
     * @param element The element to observe for content changes.
     */
    observe(element: Element): Observable<MutationRecord[]>;
    /**
     * Observe content changes on an element.
     * @param element The element to observe for content changes.
     */
    observe(element: ElementRef<Element>): Observable<MutationRecord[]>;
    /**
     * Observes the given element by using the existing MutationObserver if available, or creating a
     * new one if not.
     */
    private _observeElement;
    /**
     * Un-observes the given element and cleans up the underlying MutationObserver if nobody else is
     * observing this element.
     */
    private _unobserveElement;
    /** Clean up the underlying MutationObserver for the specified element. */
    private _cleanupObserver;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentObserver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentObserver>;
}
/**
 * Directive that triggers a callback whenever the content of
 * its associated element has changed.
 */
declare class CubCdkObserveContent implements AfterContentInit, OnDestroy {
    private _contentObserver;
    private _elementRef;
    private _ngZone;
    private _disabled;
    private _debounce;
    private _currentSubscription;
    /**
     * Whether observing content is disabled. This option can be used
     * to disconnect the underlying MutationObserver until it is needed.
     */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /** Debounce interval for emitting the changes. */
    get debounce(): number;
    set debounce(value: NumberInput);
    /** Event emitted for each change in the element's content. */
    readonly event: EventEmitter<MutationRecord[]>;
    constructor(_contentObserver: ContentObserver, _elementRef: ElementRef<HTMLElement>, _ngZone: NgZone);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private _subscribe;
    private _unsubscribe;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkObserveContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkObserveContent, "[cubCdkObserveContent]", ["cubCdkObserveContent"], { "disabled": { "alias": "cubCdkObserveContentDisabled"; "required": false; }; "debounce": { "alias": "debounce"; "required": false; }; }, { "event": "cubCdkObserveContent"; }, never, never, true, never>;
}

declare class CubCdkObserversModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkObserversModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkObserversModule, never, [typeof CubCdkObserveContent], [typeof CubCdkObserveContent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkObserversModule>;
}

export { ContentObserver, CubCdkObserveContent, CubCdkObserversModule, MutationObserverFactory };
