import * as i0 from '@angular/core';
import { ElementRef, OnChanges, AfterContentInit, AfterViewInit, OnDestroy, QueryList, EventEmitter, ChangeDetectorRef, TemplateRef, InjectionToken } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import * as i1 from 'cub-lib-view-rootng/cdk/bidi';
import { Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { BooleanInput, NumberInput } from 'cub-lib-view-rootng/cdk/coercion';
import { FocusableOption } from 'cub-lib-view-rootng/cdk/a11y';

declare class CubCdkStepHeader implements FocusableOption {
    _elementRef: ElementRef<HTMLElement>;
    constructor(_elementRef: ElementRef<HTMLElement>);
    /** Focuses the step header. */
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkStepHeader, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkStepHeader, "[cubCdkStepHeader]", never, {}, {}, never, never, true, never>;
}

/**
 * Position state of the content of each step in stepper that is used for transitioning
 * the content into correct position upon step selection change.
 */
type StepContentPositionState = 'previous' | 'current' | 'next';
/** Possible orientation of a stepper. */
type StepperOrientation = 'horizontal' | 'vertical' | 'collapse';
/** Change event emitted on selection changes. */
declare class StepperSelectionEvent {
    /** Index of the step now selected. */
    selectedIndex: number;
    /** Index of the step previously selected. */
    previouslySelectedIndex: number;
    /** The step instance now selected. */
    selectedStep: CubCdkStep;
    /** The step instance previously selected. */
    previouslySelectedStep: CubCdkStep;
}
/** The state of each step. */
type StepState = 'number' | 'edit' | 'done' | 'error' | string;
/** Enum to represent the different states of the steps. */
declare const STEP_STATE: {
    NUMBER: string;
    EDIT: string;
    DONE: string;
    ERROR: string;
};
/** InjectionToken that can be used to specify the global stepper options. */
declare const STEPPER_GLOBAL_OPTIONS: InjectionToken<StepperOptions>;
/** Configurable options for stepper. */
interface StepperOptions {
    /**
     * Whether the stepper should display an error state or not.
     * Default behavior is assumed to be false.
     */
    showError?: boolean;
    /**
     * Whether the stepper should display the default indicator type
     * or not.
     * Default behavior is assumed to be true.
     */
    displayDefaultIndicatorType?: boolean;
}
declare class CubCdkStep implements OnChanges {
    _stepper: CubCdkStepper;
    /** Whether user has attempted to move away from the step. */
    interacted: boolean;
    _displayDefaultIndicatorType: boolean;
    _completedOverride: boolean | null;
    private _stepperOptions;
    private _editable;
    private _optional;
    private _customError;
    /** 步驟的頂層抽象控制器，預設為 undefined。 */
    stepControl: AbstractControlLike;
    /** 步驟的純文字標籤，預設為 undefined。 */
    label: string;
    /** 發生錯誤時要顯示的錯誤訊息，預設為 undefined。 */
    errorMessage: string;
    /** 頁籤的無障礙標籤，預設為 undefined。 */
    ariaLabel: string;
    /** 參考到標記該頁籤的元素，預設為 undefined。 */
    ariaLabelledby: string;
    /** 步驟的狀態，預設為 undefined。 */
    state: StepState;
    /** 當步驟標記為已完成後，使用者是否可以返回此步驟，預設為 true。 */
    get editable(): boolean;
    set editable(value: BooleanInput);
    /** 是否可選擇完成此步驟，預設為 false。 */
    get optional(): boolean;
    set optional(value: BooleanInput);
    /** 步驟是否標記為已完成，預設為 null。 */
    get completed(): boolean;
    set completed(value: BooleanInput);
    /** 步驟是否有錯誤，預設為 null。 */
    get hasError(): boolean;
    set hasError(value: BooleanInput);
    /** 當使用者嘗試離開步驟時發出事件。 */
    readonly interactedStream: EventEmitter<CubCdkStep>;
    /** Template for step content. */
    content: TemplateRef<any>;
    constructor(_stepper: CubCdkStepper, stepperOptions?: StepperOptions);
    ngOnChanges(): void;
    /** Selects this step component. */
    select(): void;
    /** Resets the step to its initial state. Note that this includes resetting form data. */
    reset(): void;
    _markAsInteracted(): void;
    /** Determines whether the error state can be shown. */
    _showError(): boolean;
    private _getDefaultError;
    private _getDefaultCompleted;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkStep, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCdkStep, "cub-cdk-step", ["cubCdkStep"], { "stepControl": { "alias": "stepControl"; "required": false; }; "label": { "alias": "label"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "state": { "alias": "state"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; "optional": { "alias": "optional"; "required": false; }; "completed": { "alias": "completed"; "required": false; }; "hasError": { "alias": "hasError"; "required": false; }; }, { "interactedStream": "interacted"; }, never, ["*"], true, never>;
}
declare class CubCdkStepper implements AfterContentInit, AfterViewInit, OnDestroy {
    private _dir;
    private _changeDetectorRef;
    private _elementRef;
    /** Used to track unique ID for each stepper component. */
    _groupId: number;
    /** Steps that belong to the current stepper, excluding ones from nested steppers. */
    readonly steps: QueryList<CubCdkStep>;
    /** Emits when the component is destroyed. */
    protected readonly _destroyed: Subject<void>;
    /** Used for managing keyboard focus. */
    private _keyManager;
    /** List of step headers sorted based on their DOM order. */
    private _sortedHeaders;
    private _linear;
    private _selectedIndex;
    private _orientation;
    /** Whether the validity of previous steps should be checked or not. */
    get linear(): boolean;
    set linear(value: BooleanInput);
    /** The index of the selected step. */
    get selectedIndex(): number;
    set selectedIndex(index: NumberInput);
    /** The step that is selected. */
    get selected(): CubCdkStep | undefined;
    set selected(step: CubCdkStep | undefined);
    /** Orientation of the stepper. */
    get orientation(): StepperOrientation;
    set orientation(value: StepperOrientation);
    /** Event emitted when the selected step has changed. */
    readonly selectionChange: EventEmitter<StepperSelectionEvent>;
    /** The list of step headers of the steps in the stepper. */
    _stepHeader: QueryList<CubCdkStepHeader>;
    /** Full list of steps inside the stepper, including inside nested steppers. */
    _steps: QueryList<CubCdkStep>;
    constructor(_dir: Directionality, _changeDetectorRef: ChangeDetectorRef, _elementRef: ElementRef<HTMLElement>);
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Selects and focuses the next step in list. */
    next(): void;
    /** Selects and focuses the previous step in list. */
    previous(): void;
    /** Resets the stepper to its initial state. Note that this includes clearing form data. */
    reset(): void;
    /** Returns a unique id for each step label element. */
    _getStepLabelId(i: number): string;
    /** Returns unique id for each step content element. */
    _getStepContentId(i: number): string;
    /** Marks the component to be change detected. */
    _stateChanged(): void;
    /** Returns position state of the step with the given index. */
    _getAnimationDirection(index: number): StepContentPositionState;
    /** Returns the type of icon to be displayed. */
    _getIndicatorType(index: number, state?: StepState): StepState;
    /** Returns the index of the currently-focused step header. */
    _getFocusIndex(): number | null;
    _onKeydown(event: KeyboardEvent): void;
    private _getDefaultIndicatorLogic;
    private _getGuidelineLogic;
    private _isCurrentStep;
    private _updateSelectedItemIndex;
    private _anyControlsInvalidOrPending;
    private _layoutDirection;
    /** Checks whether the stepper contains the focused element. */
    private _containsFocus;
    /** Checks whether the passed-in index is a valid step index. */
    private _isValidIndex;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkStepper, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkStepper, "[cubCdkStepper]", ["cubCdkStepper"], { "linear": { "alias": "linear"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; }, { "selectionChange": "selectionChange"; }, ["_stepHeader", "_steps"], never, true, never>;
}
/**
 * Simplified representation of an "AbstractControl" from @angular/forms.
 * Used to avoid having to bring in @angular/forms for a single optional interface.
 * @docs-private
 */
interface AbstractControlLike {
    asyncValidator: ((control: any) => any) | null;
    dirty: boolean;
    disabled: boolean;
    enabled: boolean;
    errors: {
        [key: string]: any;
    } | null;
    invalid: boolean;
    parent: any;
    pending: boolean;
    pristine: boolean;
    root: AbstractControlLike;
    status: string;
    readonly statusChanges: Observable<any>;
    touched: boolean;
    untouched: boolean;
    updateOn: any;
    valid: boolean;
    validator: ((control: any) => any) | null;
    value: any;
    readonly valueChanges: Observable<any>;
    clearAsyncValidators(): void;
    clearValidators(): void;
    disable(opts?: any): void;
    enable(opts?: any): void;
    get(path: (string | number)[] | string): AbstractControlLike | null;
    getError(errorCode: string, path?: (string | number)[] | string): any;
    hasError(errorCode: string, path?: (string | number)[] | string): boolean;
    markAllAsTouched(): void;
    markAsDirty(opts?: any): void;
    markAsPending(opts?: any): void;
    markAsPristine(opts?: any): void;
    markAsTouched(opts?: any): void;
    markAsUntouched(opts?: any): void;
    patchValue(value: any, options?: Object): void;
    reset(value?: any, options?: Object): void;
    setAsyncValidators(newValidator: (control: any) => any | ((control: any) => any)[] | null): void;
    setErrors(errors: {
        [key: string]: any;
    } | null, opts?: any): void;
    setParent(parent: any): void;
    setValidators(newValidator: (control: any) => any | ((control: any) => any)[] | null): void;
    setValue(value: any, options?: Object): void;
    updateValueAndValidity(opts?: any): void;
    patchValue(value: any, options?: any): void;
    reset(formState?: any, options?: any): void;
    setValue(value: any, options?: any): void;
}

/** Button that moves to the next step in a stepper workflow. */
declare class CubCdkStepperNext {
    _stepper: CubCdkStepper;
    /** Type of the next button. Defaults to "submit" if not specified. */
    type: string;
    constructor(_stepper: CubCdkStepper);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkStepperNext, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkStepperNext, "button[cubCdkStepperNext]", never, { "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
/** Button that moves to the previous step in a stepper workflow. */
declare class CubCdkStepperPrevious {
    _stepper: CubCdkStepper;
    /** Type of the previous button. Defaults to "button" if not specified. */
    type: string;
    constructor(_stepper: CubCdkStepper);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkStepperPrevious, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkStepperPrevious, "button[cubCdkStepperPrevious]", never, { "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCdkStepperModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkStepperModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkStepperModule, never, [typeof i1.CubCdkBidiModule, typeof CubCdkStep, typeof CubCdkStepper, typeof CubCdkStepHeader, typeof CubCdkStepperNext, typeof CubCdkStepperPrevious], [typeof CubCdkStep, typeof CubCdkStepper, typeof CubCdkStepHeader, typeof CubCdkStepperNext, typeof CubCdkStepperPrevious]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkStepperModule>;
}

export { CubCdkStep, CubCdkStepHeader, CubCdkStepper, CubCdkStepperModule, CubCdkStepperNext, CubCdkStepperPrevious, STEPPER_GLOBAL_OPTIONS, STEP_STATE, StepperSelectionEvent };
export type { StepContentPositionState, StepState, StepperOptions, StepperOrientation };
