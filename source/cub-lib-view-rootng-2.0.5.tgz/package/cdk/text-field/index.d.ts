import * as i0 from '@angular/core';
import { OnDestroy, NgZone, ElementRef, OnInit, EventEmitter, OnChanges, AfterContentChecked, SimpleChanges } from '@angular/core';
import { Platform } from 'cub-lib-view-rootng/cdk/platform';
import { Observable } from 'rxjs';
import { BooleanInput, NumberInput } from 'cub-lib-view-rootng/cdk/coercion';

/** An event that is emitted when the autofill state of an input changes. */
type AutofillEvent = {
    /** The element whose autofill state changes. */
    target: Element;
    /** Whether the element is currently autofilled. */
    isAutofilled: boolean;
};
/**
 * An injectable service that can be used to monitor the autofill state of an input.
 * Based on the following blog post:
 * https://medium.com/@brunn/detecting-autofilled-fields-in-javascript-aed598d25da7
 */
declare class AutofillMonitor implements OnDestroy {
    private _platform;
    private _ngZone;
    private _monitoredElements;
    constructor(_platform: Platform, _ngZone: NgZone);
    /**
     * Monitor for changes in the autofill state of the given input element.
     * @param element The element to monitor.
     * @return A stream of autofill state changes.
     */
    monitor(element: Element): Observable<AutofillEvent>;
    /**
     * Monitor for changes in the autofill state of the given input element.
     * @param element The element to monitor.
     * @return A stream of autofill state changes.
     */
    monitor(element: ElementRef<Element>): Observable<AutofillEvent>;
    /**
     * Stop monitoring the autofill state of the given input element.
     * @param element The element to stop monitoring.
     */
    stopMonitoring(element: Element): void;
    /**
     * Stop monitoring the autofill state of the given input element.
     * @param element The element to stop monitoring.
     */
    stopMonitoring(element: ElementRef<Element>): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutofillMonitor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AutofillMonitor>;
}
/** A directive that can be used to monitor the autofill state of an input. */
declare class CubCdkAutofill implements OnDestroy, OnInit {
    private _elementRef;
    private _autofillMonitor;
    /** Emits when the autofill state of the element changes. */
    readonly cubCdkAutofill: EventEmitter<AutofillEvent>;
    constructor(_elementRef: ElementRef<HTMLElement>, _autofillMonitor: AutofillMonitor);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkAutofill, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkAutofill, "[cubCdkAutofill]", never, {}, { "cubCdkAutofill": "cubCdkAutofill"; }, never, never, true, never>;
}

declare class WindowRef {
    get nativeWindow(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<WindowRef, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WindowRef>;
}

declare class CubCdkTextareaAutosize implements OnDestroy, OnChanges, AfterContentChecked {
    element: ElementRef;
    private _window;
    private _zone;
    private _minRows;
    private _maxRows;
    private autosize;
    private retries;
    private textAreaEl;
    private onlyGrow;
    private useImportant;
    private _oldContent;
    private _oldWidth;
    private _disabledHandleResizing;
    private _windowResizeHandler;
    private _destroyed;
    /** 是否禁用拖拉調整大小，預設為 false。 */
    get disabledHandleResizing(): boolean;
    set disabledHandleResizing(value: BooleanInput);
    /** 控制是否啟用 textarea 自動調整大小功能，預設值為 true。 */
    set _autosize(autosize: boolean | string);
    /** 設定 textarea 的最小行數，預設值為 undefined。 */
    get minRows(): number;
    set minRows(value: NumberInput);
    /** 設定 textarea 的最大行數，預設值為 undefined。 */
    get maxRows(): number;
    set maxRows(value: NumberInput);
    resized: EventEmitter<number>;
    onInput(textArea: HTMLTextAreaElement): void;
    constructor(element: ElementRef, _window: WindowRef, _zone: NgZone);
    ngOnDestroy(): void;
    ngAfterContentChecked(): void;
    ngOnChanges(changes: SimpleChanges): void;
    _findNestedTextArea(): void;
    _onTextAreaFound(): void;
    _addWindowResizeHandler(): void;
    adjust(inputsChanged?: boolean): void;
    private _getLineHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTextareaAutosize, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkTextareaAutosize, "textarea[cubCdkTextareaAutosize]", ["cubCdkTextareaAutosize"], { "disabledHandleResizing": { "alias": "cubCdkTextareaDisabledHandleResizing"; "required": false; }; "_autosize": { "alias": "cubCdkTextareaAutosize"; "required": false; }; "minRows": { "alias": "cubCdkAutosizeMinRows"; "required": false; }; "maxRows": { "alias": "cubCdkAutosizeMaxRows"; "required": false; }; }, { "resized": "resized"; }, never, never, true, never>;
}

declare class CubCdkTextFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTextFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkTextFieldModule, never, [typeof CubCdkAutofill, typeof CubCdkTextareaAutosize], [typeof CubCdkAutofill, typeof CubCdkTextareaAutosize]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkTextFieldModule>;
}

export { AutofillMonitor, CubCdkAutofill, CubCdkTextFieldModule, CubCdkTextareaAutosize, WindowRef };
export type { AutofillEvent };
