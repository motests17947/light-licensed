import { SelectionModel, CollectionViewer, DataSource } from 'cub-lib-view-rootng/cdk/collections';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import * as i0 from '@angular/core';
import { TemplateRef, ViewContainerRef, InjectionToken, OnDestroy, OnInit, ElementRef, EventEmitter, AfterContentChecked, AfterContentInit, AfterViewInit, TrackByFunction, QueryList, IterableDiffer, IterableDiffers } from '@angular/core';
import { TreeKeyManagerItem, TreeKeyManagerStrategy } from 'cub-lib-view-rootng/cdk/a11y';

/**
 * Tree control interface. User can implement TreeControl to expand/collapse dataNodes in the tree.
 * The CDKTree will use this TreeControl to expand/collapse a node.
 * User can also use it outside the `<cdk-tree>` to control the expansion status of the tree.
 *
 * @deprecated Use one of levelAccessor or childrenAccessor instead. To be removed in a future version.
 * @breaking-change 21.0.0
 */
interface TreeControl<T, K = T> {
    /** The saved tree nodes data for `expandAll` action. */
    dataNodes: T[];
    /** The expansion model */
    expansionModel: SelectionModel<K>;
    /** Whether the data node is expanded or collapsed. Return true if it's expanded. */
    isExpanded(dataNode: T): boolean;
    /** Get all descendants of a data node */
    getDescendants(dataNode: T): any[];
    /** Expand or collapse data node */
    toggle(dataNode: T): void;
    /** Expand one data node */
    expand(dataNode: T): void;
    /** Collapse one data node */
    collapse(dataNode: T): void;
    /** Expand all the dataNodes in the tree */
    expandAll(): void;
    /** Collapse all the dataNodes in the tree */
    collapseAll(): void;
    /** Toggle a data node by expand/collapse it and all its descendants */
    toggleDescendants(dataNode: T): void;
    /** Expand a data node and all its descendants */
    expandDescendants(dataNode: T): void;
    /** Collapse a data node and all its descendants */
    collapseDescendants(dataNode: T): void;
    /** Get depth of a given data node, return the level number. This is for flat tree node. */
    readonly getLevel: (dataNode: T) => number;
    /**
     * Whether the data node is expandable. Returns true if expandable.
     * This is for flat tree node.
     */
    readonly isExpandable: (dataNode: T) => boolean;
    /** Gets a stream that emits whenever the given data node's children change. */
    readonly getChildren: (dataNode: T) => Observable<T[]> | T[] | undefined | null;
}

/**
 * Base tree control. It has basic toggle/expand/collapse operations on a single data node.
 *
 * @deprecated Use one of levelAccessor or childrenAccessor. To be removed in a future version.
 * @breaking-change 21.0.0
 */
declare abstract class BaseTreeControl<T, K = T> implements TreeControl<T, K> {
    /** Saved data node for `expandAll` action. */
    dataNodes: T[];
    /** A selection model with multi-selection to track expansion status. */
    expansionModel: SelectionModel<K>;
    /**
     * Returns the identifier by which a dataNode should be tracked, should its
     * reference change.
     *
     * Similar to trackBy for *ngFor
     */
    trackBy?: (dataNode: T) => K;
    /** Get depth of a given data node, return the level number. This is for flat tree node. */
    getLevel: (dataNode: T) => number;
    /**
     * Whether the data node is expandable. Returns true if expandable.
     * This is for flat tree node.
     */
    isExpandable: (dataNode: T) => boolean;
    /** Gets a stream that emits whenever the given data node's children change. */
    getChildren: (dataNode: T) => Observable<T[]> | T[] | undefined | null;
    /** Toggles one single data node's expanded/collapsed state. */
    toggle(dataNode: T): void;
    /** Expands one single data node. */
    expand(dataNode: T): void;
    /** Collapses one single data node. */
    collapse(dataNode: T): void;
    /** Whether a given data node is expanded or not. Returns true if the data node is expanded. */
    isExpanded(dataNode: T): boolean;
    /** Toggles a subtree rooted at `node` recursively. */
    toggleDescendants(dataNode: T): void;
    /** Collapse all dataNodes in the tree. */
    collapseAll(): void;
    /** Expands a subtree rooted at given data node recursively. */
    expandDescendants(dataNode: T): void;
    /** Collapses a subtree rooted at given data node recursively. */
    collapseDescendants(dataNode: T): void;
    /** Gets a list of descendent data nodes of a subtree rooted at given data node recursively. */
    abstract getDescendants(dataNode: T): T[];
    /** Expands all data nodes in the tree. */
    abstract expandAll(): void;
    protected _trackByValue(value: T | K): K;
}

/** Optional set of configuration that can be provided to the FlatTreeControl. */
interface FlatTreeControlOptions<T, K> {
    trackBy?: (dataNode: T) => K;
}
/**
 * Flat tree control. Able to expand/collapse a subtree recursively for flattened tree.
 *
 * @deprecated Use one of levelAccessor or childrenAccessor instead. To be removed in a future
 * version.
 * @breaking-change 21.0.0
 */
declare class FlatTreeControl<T, K = T> extends BaseTreeControl<T, K> {
    getLevel: (dataNode: T) => number;
    isExpandable: (dataNode: T) => boolean;
    options?: FlatTreeControlOptions<T, K> | undefined;
    /** Construct with flat tree data node functions getLevel and isExpandable. */
    constructor(getLevel: (dataNode: T) => number, isExpandable: (dataNode: T) => boolean, options?: FlatTreeControlOptions<T, K> | undefined);
    /**
     * Gets a list of the data node's subtree of descendent data nodes.
     *
     * To make this working, the `dataNodes` of the TreeControl must be flattened tree nodes
     * with correct levels.
     */
    getDescendants(dataNode: T): T[];
    /**
     * Expands all data nodes in the tree.
     *
     * To make this working, the `dataNodes` variable of the TreeControl must be set to all flattened
     * data nodes of the tree.
     */
    expandAll(): void;
}

/** Optional set of configuration that can be provided to the NestedTreeControl. */
interface NestedTreeControlOptions<T, K> {
    /** Function to determine if the provided node is expandable. */
    isExpandable?: (dataNode: T) => boolean;
    trackBy?: (dataNode: T) => K;
}
/**
 * Nested tree control. Able to expand/collapse a subtree recursively for NestedNode type.
 *
 * @deprecated Use one of levelAccessor or childrenAccessor instead. To be removed in a future
 * version.
 * @breaking-change 21.0.0
 */
declare class NestedTreeControl<T, K = T> extends BaseTreeControl<T, K> {
    getChildren: (dataNode: T) => Observable<T[]> | T[] | undefined | null;
    options?: NestedTreeControlOptions<T, K> | undefined;
    /** Construct with nested tree function getChildren. */
    constructor(getChildren: (dataNode: T) => Observable<T[]> | T[] | undefined | null, options?: NestedTreeControlOptions<T, K> | undefined);
    /**
     * Expands all dataNodes in the tree.
     *
     * To make this working, the `dataNodes` variable of the TreeControl must be set to all root level
     * data nodes of the tree.
     */
    expandAll(): void;
    /** Gets a list of descendant dataNodes of a subtree rooted at given data node recursively. */
    getDescendants(dataNode: T): T[];
    /** A helper function to get descendants recursively. */
    protected _getDescendants(descendants: T[], dataNode: T): void;
}

/** Context provided to the tree node component. */
declare class CubCdkTreeNodeOutletContext<T> {
    /** Data for the node. */
    $implicit: T;
    /** Depth of the node. */
    level: number;
    /** Index location of the node. */
    index?: number;
    /** Length of the number of total dataNodes. */
    count?: number;
    constructor(data: T);
}
/**
 * Data node definition for the CubCdkTree.
 * Captures the node's template and a when predicate that describes when this node should be used.
 */
declare class CubCdkTreeNodeDef<T> {
    /** @docs-private */
    template: TemplateRef<any>;
    /**
     * Function that should return true if this node template should be used for the provided node
     * data and index. If left undefined, this node will be considered the default node template to
     * use when no other when functions return true for the data.
     * For every node, there must be at least one when function that passes or an undefined to
     * default.
     */
    when: (index: number, nodeData: T) => boolean;
    constructor(...args: unknown[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTreeNodeDef<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkTreeNodeDef<any>, "[cubCdkTreeNodeDef]", never, { "when": { "alias": "cubCdkTreeNodeDefWhen"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Injection token used to provide a `CubCdkTreeNode` to its outlet.
 * Used primarily to avoid circular imports.
 * @docs-private
 */
declare const CUB_CDK_TREE_NODE_OUTLET_NODE: InjectionToken<object>;
/**
 * Outlet for nested CdkNode. Put `[cubCdkTreeNodeOutlet]` on a tag to place children dataNodes
 * inside the outlet.
 */
declare class CubCdkTreeNodeOutlet {
    viewContainer: ViewContainerRef;
    _node?: object | null | undefined;
    constructor(...args: unknown[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTreeNodeOutlet, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkTreeNodeOutlet, "[cubCdkTreeNodeOutlet]", never, {}, {}, never, never, true, never>;
}

type RenderingData<T> = {
    flattenedNodes: null;
    nodeType: null;
    renderNodes: readonly T[];
} | {
    flattenedNodes: readonly T[];
    nodeType: 'nested' | 'flat';
    renderNodes: readonly T[];
};
/**
 * Tree node for CubCdkTree. It contains the data in the tree node.
 */
declare class CubCdkTreeNode<T, K = T> implements OnDestroy, OnInit, TreeKeyManagerItem {
    /**
     * The most recently created `CubCdkTreeNode`. We save it in static variable so we can retrieve it
     * in `CdkTree` and set the data to it.
     */
    static mostRecentTreeNode: CubCdkTreeNode<any> | null;
    _elementRef: ElementRef<HTMLElement>;
    readonly _dataChanges: Subject<void>;
    protected _data: T;
    protected _tree: CubCdkTree<T, K>;
    protected _tabindex: number | null;
    protected readonly _type: 'flat' | 'nested';
    /** Subject that emits when the component has been destroyed. */
    protected readonly _destroyed: Subject<void>;
    /** Emits when the node's data has changed. */
    private _inputIsExpandable;
    private _inputIsExpanded;
    /**
     * Flag used to determine whether or not we should be focusing the actual element based on
     * some user interaction (click or focus). On click, we don't forcibly focus the element
     * since the click could trigger some other component that wants to grab its own focus
     * (e.g. menu, dialog).
     */
    private _shouldFocus;
    private _parentNodeAriaLevel;
    private _changeDetectorRef;
    /** The tree node's data. */
    get data(): T;
    set data(value: T);
    get isLeafNode(): boolean;
    get level(): number;
    /**
     * 樹狀節點的角色 (role)。
     *
     * @deprecated 這個屬性將被忽略，因為樹狀結構會自動為節點決定適當的角色。
     * 此輸入屬性將在未來版本中移除。
     * @breaking-change 21.0.0
     */
    get role(): 'treeitem' | 'group';
    set role(_role: 'treeitem' | 'group');
    /**
     * 該節點是否可以展開/收合，預設值為 true。
     *
     */
    get isExpandable(): boolean;
    set isExpandable(isExpandable: boolean);
    /**
     * 該節點是否被展開/收合，預設值為 false
     *
     */
    get isExpanded(): boolean;
    set isExpanded(isExpanded: boolean);
    /**
     * 該節點是否被禁用。如果節點被禁用，則使用者將無法聚焦或啟用此節點。
     */
    isDisabled: boolean;
    /**
     * 用於在鍵盤快速搜尋 (typeahead) 時定位此項目的文字。
     * 如果未指定，將使用節點的 `textContent`。
     */
    typeaheadLabel: string | null;
    /**
     * 當節點被程式化或透過鍵盤啟用時發出。
     */
    readonly activation: EventEmitter<T>;
    /**
     * 當節點的展開狀態改變時發出。
     */
    readonly expandedChange: EventEmitter<boolean>;
    constructor(...args: unknown[]);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Determines if the tree node is expandable. */
    _isExpandable(): boolean;
    /**
     * Determines the value for `aria-expanded`.
     *
     * For non-expandable nodes, this is `null`.
     */
    _getAriaExpanded(): string | null;
    /**
     * Determines the size of this node's parent's child set.
     *
     * This is intended to be used for `aria-setsize`.
     */
    _getSetSize(): number;
    /**
     * Determines the index (starting from 1) of this node in its parent's child set.
     *
     * This is intended to be used for `aria-posinset`.
     */
    _getPositionInSet(): number;
    getLabel(): string;
    getParent(): CubCdkTreeNode<T, K> | null;
    getChildren(): CubCdkTreeNode<T, K>[] | Observable<CubCdkTreeNode<T, K>[]>;
    /** Focuses this data node. Implemented for TreeKeyManagerItem. */
    focus(): void;
    /** Defocus this data node. */
    unfocus(): void;
    /** Emits an activation event. Implemented for TreeKeyManagerItem. */
    activate(): void;
    /** Collapses this data node. Implemented for TreeKeyManagerItem. */
    collapse(): void;
    /** Expands this data node. Implemented for TreeKeyManagerItem. */
    expand(): void;
    /** Makes the node focusable. Implemented for TreeKeyManagerItem. */
    makeFocusable(): void;
    _focusItem(): void;
    _setActiveItem(): void;
    _emitExpansionState(expanded: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTreeNode<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkTreeNode<any, any>, "cub-cdk-tree-node", ["cubCdkTreeNode"], { "role": { "alias": "role"; "required": false; }; "isExpandable": { "alias": "isExpandable"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "typeaheadLabel": { "alias": "cubCdkTreeNodeTypeaheadLabel"; "required": false; }; }, { "activation": "activation"; "expandedChange": "expandedChange"; }, never, never, true, never>;
    static ngAcceptInputType_isExpandable: unknown;
    static ngAcceptInputType_isDisabled: unknown;
}

/**
 * CDK tree component that connects with a data source to retrieve data of type `T` and renders
 * dataNodes with hierarchy. Updates the dataNodes when new data is provided by the data source.
 */
declare class CubCdkTree<T, K = T> implements AfterContentChecked, AfterContentInit, AfterViewInit, CollectionViewer, OnDestroy, OnInit {
    /** The key manager for this tree. Handles focus and activation based on user keyboard input. */
    _keyManager: TreeKeyManagerStrategy<CubCdkTreeNode<T, K>>;
    /**
     * Stream containing the latest information on what rows are being displayed on screen.
     * Can be used by the data source to as a heuristic of what data should be provided.
     */
    readonly viewChange: BehaviorSubject<{
        start: number;
        end: number;
    }>;
    /** Keep track of which nodes are expanded. */
    private _expansionModel?;
    /**
     * Maintain a synchronous cache of flattened data nodes. This will only be
     * populated after initial render, and in certain cases, will be delayed due to
     * relying on Observable `getChildren` calls.
     */
    private _flattenedNodes;
    /** The automatically determined node type for the tree. */
    private _nodeType;
    /** The mapping between data and the node that is rendered. */
    private _nodes;
    /**
     * Synchronous cache of nodes for the `TreeKeyManager`. This is separate
     * from `_flattenedNodes` so they can be independently updated at different
     * times.
     */
    private _keyManagerNodes;
    private _keyManagerFactory;
    private _viewInit;
    private _differs;
    private _changeDetectorRef;
    private _elementRef;
    private _dir;
    /** Subject that emits when the component has been destroyed. */
    private readonly _onDestroy;
    /** Differ used to find the changes in the data provided by the data source. */
    private _dataDiffer;
    /** Stores the node definition that does not have a when predicate. */
    private _defaultNodeDef;
    /** Data subscription */
    private _dataSubscription;
    /** Level of nodes */
    private _levels;
    /** The immediate parents for a node. This is `null` if there is no parent. */
    private _parents;
    private _value;
    /**
     * Nodes grouped into each set, which is a list of nodes displayed together in the DOM.
     *
     * Lookup key is the parent of a set. Root nodes have key of null.
     *
     * Values is a 'set' of tree nodes. Each tree node maps to a treeitem element. Sets are in the
     * order that it is rendered. Each set maps directly to aria-posinset and aria-setsize attributes.
     */
    private _ariaSets;
    /**
     * 提供一個包含最新數據陣列的流 (stream) 以供渲染。
     * 它會受到樹狀結構的視窗流 (view window stream) 影響，即目前顯示在螢幕上的數據節點。
     * 數據源可以是數據陣列的 Observable，或者直接是一個要渲染的數據陣列。
     * 預設值為 undefined。
     */
    get value(): DataSource<T> | Observable<T[]> | T[];
    set value(dataSource: DataSource<T> | Observable<T[]> | T[]);
    /**
     * 樹狀結構的控制器。
     * 它負責管理樹的展開/收合狀態。
     *
     * @deprecated 這個屬性已被棄用，請改用 `levelAccessor` 或 `childrenAccessor` 來定義樹的層級和子節點關係。
     * 此屬性將在未來的版本 (21.0.0) 中被移除。
     * @breaking-change 21.0.0
     * 預設值為 undefined。
     */
    treeControl?: TreeControl<T, K>;
    /**
     * 給定一個數據節點，判斷該節點在樹狀結構中的層級。
     * 例如，根節點層級為 0，其子節點為 1，以此類推。
     *
     * 注意：`levelAccessor` 或 `childrenAccessor` 兩者必須指定其中一個，不能同時指定。
     * 這項限制會在執行時被強制檢查。
     * 預設值為 undefined。
     */
    levelAccessor?: (dataNode: T) => number;
    /**
     * 給定一個數據節點，判斷該節點的所有子節點。
     * 子節點可以是同步的 (T[]) 或異步的 (Observable<T[]>)。
     *
     * 注意：`levelAccessor` 或 `childrenAccessor` 兩者必須指定其中一個，不能同時指定。
     * 這項限制會在執行時被強制檢查。
     * 預設值為 undefined。
     */
    childrenAccessor?: (dataNode: T) => T[] | Observable<T[]>;
    /**
     * 追蹤函數，用於檢查數據變化的差異，類似於 Angular `ngFor` 中的 `trackBy` 函數。
     * 透過此函數為每個節點提供一個唯一識別碼，可以優化節點操作 (例如添加、移除、移動)，
     * 因為組件能夠更有效地識別數據變化，避免不必要的 DOM 操作。
     * 函數接受兩個參數：`index` (節點在列表中的索引) 和 `item` (節點的數據)。
     * 預設值為 undefined。
     */
    trackBy: TrackByFunction<T>;
    /**
     * 給定一個數據節點，判斷用於儲存或識別該節點展開狀態的鍵（key）。
     * 這個鍵用於確保即使節點數據發生變化，其展開狀態也能被正確地追蹤和維護。
     * 例如，如果你的節點有唯一的 ID 屬性，你可以將其作為 `expansionKey` 回傳。
     * 預設值為 undefined。
     */
    expansionKey?: (dataNode: T) => K;
    _nodeOutlet: CubCdkTreeNodeOutlet;
    /** The tree node template for the tree */
    _nodeDefs: QueryList<CubCdkTreeNodeDef<T>>;
    constructor(...args: unknown[]);
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    ngOnDestroy(): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    /**
     * Sets the node type for the tree, if it hasn't been set yet.
     *
     * This will be called by the first node that's rendered in order for the tree
     * to determine what data transformations are required.
     */
    _setNodeTypeIfUnset(newType: 'flat' | 'nested'): void;
    _getExpansionModel(): SelectionModel<K>;
    /** Check for changes made in the data and render each change (node added/removed/moved). */
    renderNodeChanges(data: readonly T[], dataDiffer?: IterableDiffer<T>, viewContainer?: ViewContainerRef, parentData?: T): void;
    /**
     * Finds the matching node definition that should be used for this node data. If there is only
     * one node definition, it is returned. Otherwise, find the node definition that has a when
     * predicate that returns true with the data. If none return true, return the default node
     * definition.
     */
    _getNodeDef(data: T, i: number): CubCdkTreeNodeDef<T>;
    /**
     * Create the embedded view for the data node template and place it in the correct index location
     * within the data node view container.
     */
    insertNode(nodeData: T, index: number, viewContainer?: ViewContainerRef, parentData?: T): void;
    /** Whether the data node is expanded or collapsed. Returns true if it's expanded. */
    isExpanded(dataNode: T): boolean;
    /** If the data node is currently expanded, collapse it. Otherwise, expand it. */
    toggle(dataNode: T): void;
    /** Expand the data node. If it is already expanded, does nothing. */
    expand(dataNode: T): void;
    /** Collapse the data node. If it is already collapsed, does nothing. */
    collapse(dataNode: T): void;
    /**
     * If the data node is currently expanded, collapse it and all its descendants.
     * Otherwise, expand it and all its descendants.
     */
    toggleDescendants(dataNode: T): void;
    /**
     * Expand the data node and all its descendants. If they are already expanded, does nothing.
     */
    expandDescendants(dataNode: T): void;
    /** Collapse the data node and all its descendants. If it is already collapsed, does nothing. */
    collapseDescendants(dataNode: T): void;
    /** Expands all data nodes in the tree. */
    expandAll(): void;
    /** Collapse all data nodes in the tree. */
    collapseAll(): void;
    /** Level accessor, used for compatibility between the old Tree and new Tree */
    _getLevelAccessor(): ((dataNode: T) => number) | undefined;
    /** Children accessor, used for compatibility between the old Tree and new Tree */
    _getChildrenAccessor(): ((dataNode: T) => T[] | Observable<T[]> | null | undefined) | undefined;
    /**
     * Gets the direct children of a node; used for compatibility between the old tree and the
     * new tree.
     */
    _getDirectChildren(dataNode: T): Observable<T[]>;
    /**
     * Adds the specified node component to the tree's internal registry.
     *
     * This primarily facilitates keyboard navigation.
     */
    _registerNode(node: CubCdkTreeNode<T, K>): void;
    /** Removes the specified node component from the tree's internal registry. */
    _unregisterNode(node: CubCdkTreeNode<T, K>): void;
    /**
     * For the given node, determine the level where this node appears in the tree.
     *
     * This is intended to be used for `aria-level` but is 0-indexed.
     */
    _getLevel(node: T): number | undefined;
    /**
     * For the given node, determine the size of the parent's child set.
     *
     * This is intended to be used for `aria-setsize`.
     */
    _getSetSize(dataNode: T): number;
    /**
     * For the given node, determine the index (starting from 1) of the node in its parent's child set.
     *
     * This is intended to be used for `aria-posinset`.
     */
    _getPositionInSet(dataNode: T): number;
    /** Given a CubCdkTreeNode, gets the node that renders that node's parent's data. */
    _getNodeParent(node: CubCdkTreeNode<T, K>): CubCdkTreeNode<T, K> | null | undefined;
    /** Given a CubCdkTreeNode, gets the nodes that renders that node's child data. */
    _getNodeChildren(node: CubCdkTreeNode<T, K>): Observable<CubCdkTreeNode<T, K>[]>;
    /** `keydown` event handler; this just passes the event to the `TreeKeyManager`. */
    protected _sendKeydownToKeyManager(event: KeyboardEvent): void;
    private _updateDefaultNodeDefinition;
    /**
     * Switch to the provided data source by resetting the data and unsubscribing from the current
     * render change subscription if one exists. If the data source is null, interpret this by
     * clearing the node outlet. Otherwise start listening for new data.
     */
    private _switchDataSource;
    /** Set up a subscription for the data provided by the data source. */
    private _subscribeToDataChanges;
    /** Given an Observable containing a stream of the raw data, returns an Observable containing the RenderingData */
    private _getRenderData;
    private _renderDataChanges;
    private _emitExpansionChanges;
    private _initializeKeyManager;
    private _initializeDataDiffer;
    private _checkTreeControlUsage;
    /**
     * Given the list of flattened nodes, the level accessor, and the level range within
     * which to consider children, finds the children for a given node.
     *
     * For example, for direct children, `levelDelta` would be 1. For all descendants,
     * `levelDelta` would be Infinity.
     */
    private _findChildrenByLevel;
    /** Gets all nested descendants of a given node. */
    private _getDescendants;
    /**
     * Gets all children and sub-children of the provided node.
     *
     * This will emit multiple times, in the order that the children will appear
     * in the tree, and can be combined with a `reduce` operator.
     */
    private _getAllChildrenRecursively;
    private _getExpansionKey;
    private _getAriaSet;
    /**
     * Finds the parent for the given node. If this is a root node, this
     * returns null. If we're unable to determine the parent, for example,
     * if we don't have cached node data, this returns undefined.
     */
    private _findParentForNode;
    /**
     * Given a set of root nodes and the current node level, flattens any nested
     * nodes into a single array.
     *
     * If any nodes are not expanded, then their children will not be added into the array.
     * This will still traverse all nested children in order to build up our internal data
     * models, but will not include them in the returned array.
     */
    private _flattenNestedNodesWithExpansion;
    /**
     * Converts children for certain tree configurations.
     *
     * This also computes parent, level, and group data.
     */
    private _computeRenderingData;
    private _updateCachedData;
    private _updateKeyManagerItems;
    /** Traverse the flattened node data and compute parents, levels, and group data. */
    private _calculateParents;
    /** Invokes a callback with all node expansion keys. */
    private _forEachExpansionKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTree<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCdkTree<any, any>, "cub-cdk-tree", ["cubCdkTree"], { "value": { "alias": "value"; "required": false; }; "treeControl": { "alias": "treeControl"; "required": false; }; "levelAccessor": { "alias": "levelAccessor"; "required": false; }; "childrenAccessor": { "alias": "childrenAccessor"; "required": false; }; "trackBy": { "alias": "trackBy"; "required": false; }; "expansionKey": { "alias": "expansionKey"; "required": false; }; }, {}, ["_nodeDefs"], never, true, never>;
}

/**
 * Nested node is a child of `<cdk-tree>`. It works with nested tree.
 * By using `cub-cdk-nested-tree-node` component in tree node template, children of the parent node will
 * be added in the `cubCdkTreeNodeOutlet` in tree node template.
 * The children of node will be automatically added to `cubCdkTreeNodeOutlet`.
 */
declare class CubCdkNestedTreeNode<T, K = T> extends CubCdkTreeNode<T, K> implements AfterContentInit, OnDestroy {
    protected _type: 'flat' | 'nested';
    protected _differs: IterableDiffers;
    /** The children data dataNodes of current node. They will be placed in `CubCdkTreeNodeOutlet`. */
    protected _children: T[];
    /** Differ used to find the changes in the data provided by the data source. */
    private _dataDiffer;
    /** The children node placeholder. */
    nodeOutlet: QueryList<CubCdkTreeNodeOutlet>;
    constructor(...args: unknown[]);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Add children dataNodes to the NodeOutlet */
    protected updateChildrenNodes(children?: T[]): void;
    /** Clear the children dataNodes. */
    protected _clear(): void;
    /** Gets the outlet for the current node. */
    private _getNodeOutlet;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkNestedTreeNode<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkNestedTreeNode<any, any>, "cub-cdk-nested-tree-node", ["cubCdkNestedTreeNode"], {}, {}, ["nodeOutlet"], never, true, never>;
}

/**
 * Indent for the children tree dataNodes.
 * This directive will add left-margin to the node to show hierarchy.
 */
declare class CubCdkTreeNodePadding<T, K = T> implements OnDestroy {
    /** CSS units used for the indentation value. */
    indentUnits: string;
    _level: number;
    _indent: number;
    private _treeNode;
    private _tree;
    private _element;
    private _dir;
    /** Current margin value applied to the element. Used to avoid unnecessarily hitting the DOM. */
    private _currentPadding;
    /** Subject that emits when the component has been destroyed. */
    private readonly _destroyed;
    /**
     * 樹狀節點的深度層級。
     * 節點的左側外邊距將會是 `level * indent` 像素。
     */
    get level(): number;
    set level(value: number);
    /**
     * 每個層級的縮排量。可以是數字 (單位為像素) 或一個 CSS 字串。
     * 預設值為 32px，這是一個常見的 Material Design 子選單縮排規範。
     */
    get indent(): number | string;
    set indent(indent: number | string);
    constructor(...args: unknown[]);
    ngOnDestroy(): void;
    /** The margin indent value for the tree node. Returns a string with px numbers if not null. */
    _marginIndent(): string | null;
    _setPadding(forceChange?: boolean): void;
    /**
     * This has been extracted to a util because of TS 4 and VE.
     * View Engine doesn't support property rename inheritance.
     * TS 4.0 doesn't allow properties to override accessors or vice-versa.
     * @docs-private
     */
    protected _setLevelInput(value: number): void;
    /**
     * This has been extracted to a util because of TS 4 and VE.
     * View Engine doesn't support property rename inheritance.
     * TS 4.0 doesn't allow properties to override accessors or vice-versa.
     * @docs-private
     */
    protected _setIndentInput(indent: number | string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTreeNodePadding<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkTreeNodePadding<any, any>, "[cubCdkTreeNodePadding]", never, { "level": { "alias": "cubCdkTreeNodePadding"; "required": false; }; "indent": { "alias": "cubCdkTreeNodePaddingIndent"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_level: unknown;
}

/**
 * Node toggle to expand and collapse the node.
 */
declare class CubCdkTreeNodeToggle<T, K = T> {
    protected _tree: CubCdkTree<T, K>;
    protected _treeNode: CubCdkTreeNode<T, K>;
    /**
     * 節點展開/收合時是否遞迴地影響其所有子節點。
     * 如果設定為 `true`，當一個節點被展開或收合時，其所有後代節點也會跟著展開或收合。
     * 預設值為 `false`，表示只會展開或收合當前節點。
     */
    recursive: boolean;
    constructor(...args: unknown[]);
    _toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTreeNodeToggle<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCdkTreeNodeToggle<any, any>, "[cubCdkTreeNodeToggle]", never, { "recursive": { "alias": "cubCdkTreeNodeToggleRecursive"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_recursive: unknown;
}

/**
 * Returns an error to be thrown when there is no usable data.
 * @docs-private
 */
declare function getTreeNoValidDataSourceError(): Error;
/**
 * Returns an error to be thrown when there are multiple nodes that are missing a when function.
 * @docs-private
 */
declare function getTreeMultipleDefaultNodeDefsError(): Error;
/**
 * Returns an error to be thrown when there are no matching node defs for a particular set of data.
 * @docs-private
 */
declare function getTreeMissingMatchingNodeDefError(): Error;
/**
 * Returns an error to be thrown when there is no tree control.
 * @docs-private
 */
declare function getTreeControlMissingError(): Error;
/**
 * Returns an error to be thrown when there are multiple ways of specifying children or level
 * provided to the tree.
 * @docs-private
 */
declare function getMultipleTreeControlsError(): Error;

declare class CubCdkTreeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCdkTreeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCdkTreeModule, never, [typeof CubCdkNestedTreeNode, typeof CubCdkTreeNodeDef, typeof CubCdkTreeNodePadding, typeof CubCdkTreeNodeToggle, typeof CubCdkTree, typeof CubCdkTreeNode, typeof CubCdkTreeNodeOutlet], [typeof CubCdkNestedTreeNode, typeof CubCdkTreeNodeDef, typeof CubCdkTreeNodePadding, typeof CubCdkTreeNodeToggle, typeof CubCdkTree, typeof CubCdkTreeNode, typeof CubCdkTreeNodeOutlet]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCdkTreeModule>;
}

export { BaseTreeControl, CUB_CDK_TREE_NODE_OUTLET_NODE, CubCdkNestedTreeNode, CubCdkTree, CubCdkTreeModule, CubCdkTreeNode, CubCdkTreeNodeDef, CubCdkTreeNodeOutlet, CubCdkTreeNodeOutletContext, CubCdkTreeNodePadding, CubCdkTreeNodeToggle, FlatTreeControl, NestedTreeControl, getMultipleTreeControlsError, getTreeControlMissingError, getTreeMissingMatchingNodeDefError, getTreeMultipleDefaultNodeDefsError, getTreeNoValidDataSourceError };
export type { FlatTreeControlOptions, NestedTreeControlOptions, RenderingData, TreeControl };
