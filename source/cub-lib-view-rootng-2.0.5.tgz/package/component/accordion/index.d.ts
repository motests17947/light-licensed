import * as i0 from '@angular/core';
import { InjectionToken, TemplateRef, AfterContentInit, OnChanges, OnDestroy, SimpleChanges, EventEmitter, ElementRef, ChangeDetectorRef, ViewContainerRef, AfterViewInit, QueryList } from '@angular/core';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import * as rxjs from 'rxjs';
import { Subject, BehaviorSubject } from 'rxjs';
import { TemplatePortal } from 'cub-lib-view-rootng/cdk/portal';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { UniqueSelectionDispatcher } from 'cub-lib-view-rootng/cdk/collections';
import { CubCdkAccordion, CubCdkAccordionItem } from 'cub-lib-view-rootng/cdk/accordion';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { HasTabIndex, CubPrefix, CubEnd, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import { FocusableOption, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';

type CubAccordionDisplayMode = 'default' | 'flat';
type CubAccordionTogglePosition = 'before' | 'after';
type CubAccordionPanelState = 'expanded' | 'collapsed';
interface CubAccordionPanelDefaultOptions {
    expandedHeight: string;
    collapsedHeight: string;
    hideToggle: boolean;
}
interface CubAccordionBase extends CubCdkAccordion {
    hideToggle: boolean;
    displayMode: CubAccordionDisplayMode;
    togglePosition: CubAccordionTogglePosition;
    _handleHeaderKeydown: (event: KeyboardEvent) => void;
    _handleHeaderFocus: (header: any) => void;
}
declare const CUB_ACCORDION: InjectionToken<CubAccordionBase>;
interface CubAccordionPanelBase extends CubCdkAccordionItem {
    hideToggle: boolean;
}
declare const CUB_ACCORDION_PANEL: InjectionToken<CubAccordionPanelBase>;

declare class CubAccordionPanelContent {
    _template: TemplateRef<any>;
    _accordionPanel?: CubAccordionPanelBase | undefined;
    constructor(_template: TemplateRef<any>, _accordionPanel?: CubAccordionPanelBase | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionPanelContent, [null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAccordionPanelContent, "ng-template[cubAccordionPanelContent]", never, {}, {}, never, never, true, never>;
}

/**
 * disabled 為是否禁用 accordion，預設值為 'false'。
 * expanded 為是否展開，預設值為 'false'。
 */
declare class CubAccordionPanel extends CubCdkAccordionItem implements AfterContentInit, OnChanges, OnDestroy {
    private _viewContainerRef;
    _animationMode: string;
    paddingStyle: Record<string, string>;
    _portal: TemplatePortal;
    _headerId: string;
    accordion: CubAccordionBase;
    readonly _inputChanges: Subject<SimpleChanges>;
    readonly _bodyAnimationDone: Subject<AnimationEvent>;
    private _document;
    private _hideToggle;
    private _togglePosition;
    get hideToggle(): boolean;
    set hideToggle(value: BooleanInput);
    get togglePosition(): CubAccordionTogglePosition;
    set togglePosition(value: CubAccordionTogglePosition);
    readonly afterExpand: EventEmitter<void>;
    readonly afterCollapse: EventEmitter<void>;
    _lazyContent: CubAccordionPanelContent;
    _body: ElementRef<HTMLElement>;
    constructor(accordion: CubAccordionBase, _changeDetectorRef: ChangeDetectorRef, _uniqueSelectionDispatcher: UniqueSelectionDispatcher, _viewContainerRef: ViewContainerRef, _document: any, _animationMode: string, defaultOptions?: CubAccordionPanelDefaultOptions);
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    toggle(): void;
    close(): void;
    open(): void;
    _hasSpacing(): boolean;
    _getExpandedState(): CubAccordionPanelState;
    _containsFocus(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionPanel, [{ optional: true; skipSelf: true; }, null, null, null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubAccordionPanel, "cub-accordion-panel", ["cubAccordionPanel"], { "disabled": { "alias": "disabled"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "opened": "opened"; "closed": "closed"; "expandedChange": "expandedChange"; "afterExpand": "afterExpand"; "afterCollapse": "afterCollapse"; }, ["_lazyContent"], ["cub-accordion-panel-header", "*", "cub-action-row"], true, never>;
}

/** @docs-private */
declare abstract class CubAccordionPanelHeaderBase {
    abstract readonly disabled: boolean;
}
declare const _CubAccordionPanelHeaderMixinBase: cub_lib_view_rootng_component_common.Constructor<HasTabIndex> & cub_lib_view_rootng_component_common.AbstractConstructor<HasTabIndex> & typeof CubAccordionPanelHeaderBase;
declare class CubAccordionPanelHeader extends _CubAccordionPanelHeaderMixinBase implements AfterViewInit, OnDestroy, FocusableOption, HasTabIndex {
    panel: CubAccordionPanel;
    private _element;
    private _focusMonitor;
    private _changeDetectorRef;
    _animationMode?: string | undefined;
    fontSize: number;
    toggleAvailable: boolean;
    elementInfo: BehaviorSubject<{
        height: number;
    }>;
    expandedHeight: string;
    collapsedHeight: string;
    elementWrap$: rxjs.Observable<boolean>;
    private _rippleDisabled;
    private _parentChangeSubscription;
    private _destroyed;
    private zone;
    private resizeObserver;
    get rippleDisabled(): boolean;
    set rippleDisabled(value: boolean);
    get disabled(): boolean;
    _prefixChildren: QueryList<CubPrefix>;
    _endChildren: QueryList<CubEnd>;
    titleElementRef: ElementRef;
    constructor(panel: CubAccordionPanel, _element: ElementRef, _focusMonitor: FocusMonitor, _changeDetectorRef: ChangeDetectorRef, _animationMode?: string | undefined, tabIndex?: string);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    _toggle(e: Event): void;
    _isExpanded(): boolean;
    _getExpandedState(): string;
    _getPanelId(): string;
    _showToggle(): boolean;
    _getHostElement(): any;
    _getHeaderHeight(): string | null;
    _keydown(event: KeyboardEvent): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    disableRipple(): void;
    enableRipple(): void;
    stopToggle(e: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionPanelHeader, [{ host: true; }, null, null, null, { optional: true; }, { attribute: "tabindex"; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubAccordionPanelHeader, "cub-accordion-panel-header", never, { "tabIndex": { "alias": "tabIndex"; "required": false; }; }, {}, ["_prefixChildren", "_endChildren"], ["[cubPrefix]", "*", "[cubSuffix]", "[cubEnd]"], true, never>;
}

declare class CubAccordion extends CubCdkAccordion implements CubAccordionBase, AfterContentInit, OnDestroy {
    displayMode: CubAccordionDisplayMode;
    togglePosition: CubAccordionTogglePosition;
    private _keyManager;
    /** Headers belonging to this accordion. */
    private _ownHeaders;
    private _hideToggle;
    get hideToggle(): boolean;
    set hideToggle(show: BooleanInput);
    colorScheme: 'dark' | 'light';
    size: CubThemeSize;
    /** All headers inside the accordion. Includes headers inside nested accordions. */
    _headers: QueryList<CubAccordionPanelHeader>;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Handles keyboard events coming in from the panel headers. */
    _handleHeaderKeydown(event: KeyboardEvent): void;
    _handleHeaderFocus(header: CubAccordionPanelHeader): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordion, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAccordion, "cub-accordion", ["CubAccordion"], { "multi": { "alias": "multi"; "required": false; }; "colorScheme": { "alias": "colorScheme"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, ["_headers"], never, true, never>;
}

declare class CubAccordionPanelActionRow {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionPanelActionRow, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAccordionPanelActionRow, "cub-action-row", never, {}, {}, never, never, true, never>;
}

declare class CubAccordionPanelDescription {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionPanelDescription, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAccordionPanelDescription, "cub-panel-description", never, {}, {}, never, never, true, never>;
}

declare class CubAccordionPanelTitle {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionPanelTitle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAccordionPanelTitle, "cub-panel-title", never, {}, {}, never, never, true, never>;
}

/** Time and timing curve for accordion panel animations. */
declare const CUB_ACCORDION_PANEL_ANIMATION_TIMING = "225ms cubic-bezier(0.4,0.0,0.2,1)";
/**
 * Animations used by the Material accordion panel.

 * Angular 動畫的 `state` 在使用 ViewContainerRef.move() 移動視圖容器時存在一個漏洞，
 * 導致被移動組件的動畫狀態在離開 DOM 時變為 `void`，並且在重新進入 DOM 時不會再次更新。
 * 這可能會導致擴充面板出現一種情況，即面板處於展開 (`expanded`) 或折疊 (`collapsed`) 狀態，
 * 但動畫狀態是 `void`。

 * 為了正確處理動畫到下一個狀態，我們在 `void` 和 `collapsed` 之間進行動畫，
 * 這兩個狀態被定義為具有相同的樣式。由於 Angular 會從目前樣式動畫到目標狀態的樣式定義，
 * 在從 `void` 的樣式移動到 `collapsed` 的情況下，這會起到一個無操作的作用，因為沒有樣式值發生變化。

 * 在 Angular 的動畫狀態與擴充面板狀態不同步的情況下，即擴充面板處於展開 (`expanded`) 狀態，
 * 而 Angular 動畫處於 `void` 狀態，那麼從展開狀態的有效樣式（儘管處於 `void` 動畫狀態）
 * 到折疊狀態的動畫將如預期發生。

 * Angular Bug：https://github.com/angular/angular/issues/18847

 * @docs-private
 */
declare const cubAccordionAnimations: {
    readonly indicatorRotate: AnimationTriggerMetadata;
    readonly bodyAccordion: AnimationTriggerMetadata;
};

declare class CubAccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubAccordionModule, never, [typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof CubAccordionPanelHeader, typeof CubAccordionPanel, typeof CubAccordionPanelActionRow, typeof CubAccordionPanelDescription, typeof CubAccordionPanelTitle, typeof CubAccordionPanelContent, typeof CubAccordion], [typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof CubAccordionPanelHeader, typeof CubAccordionPanel, typeof CubAccordionPanelActionRow, typeof CubAccordionPanelDescription, typeof CubAccordionPanelTitle, typeof CubAccordionPanelContent, typeof CubAccordion]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubAccordionModule>;
}

export { CUB_ACCORDION, CUB_ACCORDION_PANEL, CUB_ACCORDION_PANEL_ANIMATION_TIMING, CubAccordion, CubAccordionModule, CubAccordionPanel, CubAccordionPanelActionRow, CubAccordionPanelContent, CubAccordionPanelDescription, CubAccordionPanelHeader, CubAccordionPanelTitle, cubAccordionAnimations };
export type { CubAccordionBase, CubAccordionDisplayMode, CubAccordionPanelBase, CubAccordionPanelDefaultOptions, CubAccordionPanelState, CubAccordionTogglePosition };
