import * as i0 from '@angular/core';
import { EventEmitter, ElementRef } from '@angular/core';
import { CubThemeStatus } from 'cub-lib-view-rootng/component/common';

declare class CubAlert {
    private host;
    /**
     元件狀態，預設為 'error'。
     */
    status: CubThemeStatus;
    /**
     是否顯示關閉按鈕，預設為 true。
     */
    showClose: boolean;
    /**
     當關閉元件時發出通知。
     */
    closed: EventEmitter<void>;
    constructor(host: ElementRef<HTMLElement>);
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAlert, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubAlert, "cub-alert", never, { "status": { "alias": "status"; "required": false; }; "showClose": { "alias": "showClose"; "required": false; }; }, { "closed": "closed"; }, never, ["*"], true, never>;
}

declare class CubAlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubAlertModule, never, [typeof CubAlert], [typeof CubAlert]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubAlertModule>;
}

export { CubAlert, CubAlertModule };
