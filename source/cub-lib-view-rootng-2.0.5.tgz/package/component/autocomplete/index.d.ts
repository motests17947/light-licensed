import * as i0 from '@angular/core';
import { InjectionToken, AfterContentInit, OnDestroy, QueryList, EventEmitter, TemplateRef, ElementRef, ChangeDetectorRef, AfterViewInit, OnChanges, ViewContainerRef, NgZone, SimpleChanges } from '@angular/core';
import * as i3 from 'cub-lib-view-rootng/component/option';
import { _CubOptionBase, _CubOptionGroupBase, CubOptionGroup, CubOption, CubOptionSelectionChange } from 'cub-lib-view-rootng/component/option';
import { ActiveDescendantKeyManager } from 'cub-lib-view-rootng/cdk/a11y';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { Platform } from 'cub-lib-view-rootng/cdk/platform';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CanDisableRipple, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import { Overlay, ScrollStrategy } from 'cub-lib-view-rootng/cdk/overlay';
import { ControlValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';
import { Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';
import { ViewportRuler } from 'cub-lib-view-rootng/cdk/scrolling';
import * as i4 from 'cub-lib-view-rootng/component/form-field';
import { CubFormField } from 'cub-lib-view-rootng/component/form-field';
import * as i5 from 'cub-lib-view-rootng/component/label';
import * as i6 from 'cub-lib-view-rootng/component/input';
import * as i7 from 'cub-lib-view-rootng/component/input-group';

/** Default `cub-autocomplete` options that can be overridden. */
interface CubAutocompleteDefaultOptions {
    /** Whether the first option should be highlighted when an autocomplete panel is opened. */
    autoActiveFirstOption?: boolean;
    /** Whether the active option should be selected as the user is navigating. */
    autoSelectActiveOption?: boolean;
    /** Class or list of classes to be applied to the autocomplete's overlay panel. */
    overlayPanelClass?: string | string[];
}

/** @docs-private */
declare function CUB_AUTOCOMPLETE_DEFAULT_OPTIONS_FACTORY(): CubAutocompleteDefaultOptions;
/** @docs-private */
declare function CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
/**
 * Creates an error to be thrown when attempting to use an autocomplete trigger without a panel.
 * @docs-private
 */
declare function getCubAutocompleteMissingPanelError(): Error;

/** Injection token to be used to override the default options for `cub-autocomplete`. */
declare const CUB_AUTOCOMPLETE_DEFAULT_OPTIONS: InjectionToken<CubAutocompleteDefaultOptions>;
/** @docs-private */
declare const _CubAutocompleteMixinBase: cub_lib_view_rootng_component_common.Constructor<cub_lib_view_rootng_component_common.CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<cub_lib_view_rootng_component_common.CanDisableRipple> & {
    new (): {};
};
/** Injection token that determines the scroll handling while the autocomplete panel is open. */
declare const CUB_AUTOCOMPLETE_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
/** @docs-private */
declare const CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY;
};

/** Event object that is emitted when an autocomplete option is selected. */
declare class CubAutocompleteSelectedEvent {
    /** Reference to the autocomplete panel that emitted the event. */
    source: _CubAutocompleteBase;
    /** Option that was selected. */
    option: _CubOptionBase;
    constructor(
    /** Reference to the autocomplete panel that emitted the event. */
    source: _CubAutocompleteBase, 
    /** Option that was selected. */
    option: _CubOptionBase);
}
/** Event object that is emitted when an autocomplete option is activated. */
interface CubAutocompleteActivatedEvent {
    /** Reference to the autocomplete panel that emitted the event. */
    source: _CubAutocompleteBase;
    /** Option that was selected. */
    option: _CubOptionBase | null;
}
/** Base class with all of the `CubAutocomplete` functionality. */
declare abstract class _CubAutocompleteBase extends _CubAutocompleteMixinBase implements AfterContentInit, CanDisableRipple, OnDestroy {
    private _changeDetectorRef;
    private _elementRef;
    /** Unique ID to be used by autocomplete trigger's "aria-owns" property. */
    id: string;
    /** Whether the autocomplete panel should be visible, depending on option length. */
    showPanel: boolean;
    /** Manages active item in option list based on key events. */
    _keyManager: ActiveDescendantKeyManager<_CubOptionBase>;
    _isOpen: boolean;
    _classList: {
        [key: string]: boolean;
    };
    /**
     * Tells any descendant `cub-option-group` to use the inert a11y pattern.
     * @docs-private
     */
    readonly inertGroups: boolean;
    /** Reference to all options within the autocomplete. */
    abstract options: QueryList<_CubOptionBase>;
    /** Reference to all option groups within the autocomplete. */
    abstract optionGroups: QueryList<_CubOptionGroupBase>;
    /** Class to apply to the panel when it's visible. */
    protected abstract _visibleClass: string;
    /** Class to apply to the panel when it's hidden. */
    protected abstract _hiddenClass: string;
    private _activeOptionChanges;
    private _autoActiveFirstOption;
    private _autoSelectActiveOption;
    /** Whether the autocomplete panel is open. */
    get isOpen(): boolean;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 元件查無資料的提示文字，在啟用篩選功能時使用，預設為 '無資料'。 */
    emptyFilterMessage: string;
    /** 元件的標題（螢幕閱讀器讀取用），預設為 undefined。。 */
    ariaLabel: string;
    /** 元件優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 undefined。 */
    ariaLabelledby: string;
    /** 元件將選項的控制元件值對映到觸發器顯示值的函式，預設為 null */
    displayWith: ((value: any) => string) | null;
    /** 元件 Panel 開啟時，是否 Active 顯示第一個選項，預設為 false */
    get autoActiveFirstOption(): boolean;
    set autoActiveFirstOption(value: BooleanInput);
    /** 元件在使用導行路由時活動選項是否設定為被選擇狀態，預設為 false */
    get autoSelectActiveOption(): boolean;
    set autoSelectActiveOption(value: BooleanInput);
    /** 元件下拉選單 Panel 的寬度，預設為 undefined。 */
    panelWidth: string | number;
    /** 元件下拉選單 Panel 的樣式類別，預設為 undefined。 */
    set panelClass(value: string | string[]);
    /** 當從清單中選擇一個選項時發出通知。 */
    readonly optionSelected: EventEmitter<CubAutocompleteSelectedEvent>;
    /** 當開啟下拉選單 Panel 時發出通知。 */
    readonly opened: EventEmitter<void>;
    /** 當關閉下拉選單 Panel 時發出通知。 */
    readonly closed: EventEmitter<void>;
    /** 當啟用選項時發出通知。 */
    readonly optionActivated: EventEmitter<CubAutocompleteActivatedEvent>;
    /** @docs-private */
    template: TemplateRef<any>;
    /** Element for the panel containing the autocomplete options. */
    panel: ElementRef;
    constructor(_changeDetectorRef: ChangeDetectorRef, _elementRef: ElementRef<HTMLElement>, defaults: CubAutocompleteDefaultOptions, platform?: Platform);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /**
     * Sets the panel scrollTop. This allows us to manually scroll to display options
     * above or below the fold, as they are not actually being focused when active.
     */
    _setScrollTop(scrollTop: number): void;
    /** Returns the panel's scrollTop. */
    _getScrollTop(): number;
    /** Panel should hide itself when the option list is empty. */
    _setVisibility(): void;
    /** Emits the `select` event. */
    _emitSelectEvent(option: _CubOptionBase): void;
    /** Gets the aria-labelledby for the autocomplete panel. */
    _getPanelAriaLabelledby(labelId: string | null): string | null;
    /** Sets the autocomplete visibility classes on a classlist based on the panel is visible. */
    private _setVisibilityClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubAutocompleteBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubAutocompleteBase, never, never, { "size": { "alias": "size"; "required": false; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "displayWith": { "alias": "displayWith"; "required": false; }; "autoActiveFirstOption": { "alias": "autoActiveFirstOption"; "required": false; }; "autoSelectActiveOption": { "alias": "autoSelectActiveOption"; "required": false; }; "panelWidth": { "alias": "panelWidth"; "required": false; }; "panelClass": { "alias": "class"; "required": false; }; }, { "optionSelected": "optionSelected"; "opened": "opened"; "closed": "closed"; "optionActivated": "optionActivated"; }, never, never, true, never>;
}

declare class CubAutocomplete extends _CubAutocompleteBase {
    protected _visibleClass: string;
    protected _hiddenClass: string;
    /** Reference to all option groups within the autocomplete. */
    optionGroups: QueryList<CubOptionGroup>;
    /** Reference to all options within the autocomplete. */
    options: QueryList<CubOption>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAutocomplete, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubAutocomplete, "cub-autocomplete", ["cubAutocomplete"], { "disableRipple": { "alias": "disableRipple"; "required": false; }; }, {}, ["optionGroups", "options"], ["*"], true, never>;
}

/** Base class containing all of the functionality for `CubAutocompleteOrigin`. */
declare abstract class _CubAutocompleteOriginBase {
    /** Reference to the element on which the directive is applied. */
    elementRef: ElementRef<HTMLElement>;
    constructor(
    /** Reference to the element on which the directive is applied. */
    elementRef: ElementRef<HTMLElement>);
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubAutocompleteOriginBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubAutocompleteOriginBase, never, never, {}, {}, never, never, true, never>;
}

/**
 * Directive applied to an element to make it usable
 * as a connection point for an autocomplete panel.
 */
declare class CubAutocompleteOrigin extends _CubAutocompleteOriginBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAutocompleteOrigin, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAutocompleteOrigin, "[cubAutocompleteOrigin]", ["cubAutocompleteOrigin"], {}, {}, never, never, true, never>;
}

/** Base class with all of the `CubAutocompleteTrigger` functionality. */
declare abstract class _CubAutocompleteTriggerBase implements ControlValueAccessor, AfterViewInit, OnChanges, OnDestroy {
    private _element;
    private _overlay;
    private _viewContainerRef;
    private _zone;
    private _changeDetectorRef;
    private _dir;
    private _formField;
    private _document;
    private _viewportRuler;
    private _defaults?;
    /** Stream of changes to the selection state of the autocomplete options. */
    readonly optionSelections: Observable<CubOptionSelectionChange>;
    /** Class to apply to the panel when it's above the input. */
    protected abstract _aboveClass: string;
    /** Old value of the native input. Used to work around issues with the `input` event on IE. */
    private _previousValue;
    /** Strategy that is used to position the panel. */
    private _positionStrategy;
    /** Whether or not the label state is being overridden. */
    private _manuallyFloatingLabel;
    /** The subscription for closing actions (some are bound to document). */
    private _closingActionsSubscription;
    /** Subscription to viewport size changes. */
    private _viewportSubscription;
    private _overlayRef;
    private _portal;
    private _componentDestroyed;
    private _autocompleteDisabled;
    /**
     * Whether the autocomplete can open the next time it is focused. Used to prevent a focused,
     * closed autocomplete from being reopened if the user switches to another browser tab and then
     * comes back.
     */
    private _canOpenOnNextFocus;
    /** Value inside the input before we auto-selected an option. */
    private _valueBeforeAutoSelection;
    /**
     * Current option that we have auto-selected as the user is navigating,
     * but which hasn't been propagated to the model value yet.
     */
    private _pendingAutoselectedOption;
    private _overlayAttached;
    private _scrollStrategy;
    /** Stream of keyboard events that can close the panel. */
    private readonly _closeKeyEventStream;
    /** Whether or not the autocomplete panel is open. */
    get panelOpen(): boolean;
    /** The currently active option, coerced to CubOption type. */
    get activeOption(): _CubOptionBase | null;
    /**
     * A stream of actions that should close the autocomplete panel, including
     * when an option is selected, on blur, and when TAB is pressed.
     */
    get panelClosingActions(): Observable<CubOptionSelectionChange | null>;
    /** 要附著到此觸發器的自動完成面板，預設為 undefined。 */
    autocomplete: _CubAutocompleteBase;
    /** 元件下拉選單 Panel 相對於觸發器元素的位置，預設為 'auto'。可取下列值之一：
     * 'auto'：在觸發器下方還有剩餘空間時，會在觸發器下方渲染；反之下方空間不夠，將會在觸發器上方渲染。
     * 'above'：不論觸發器下方是否還有剩餘空間，都會在觸發器上方渲染。
     * 'below'：不論觸發器下方是否還有剩餘空間，都會在觸發器下方渲染。
     */
    position: 'auto' | 'above' | 'below';
    /** 定位元件下拉選單 Panel 的基準點，預設為自動完成的觸發器元素，預設為 undefined。 */
    connectedTo: _CubAutocompleteOriginBase;
    /** 是否停用元件，當停用時將無法開啟該 Panel，預設為否。 */
    get autocompleteDisabled(): boolean;
    set autocompleteDisabled(value: BooleanInput);
    /** 設定觸發器 autocomplete 屬性，預設為 'off'。 */
    autocompleteAttribute: string;
    constructor(_element: ElementRef<HTMLInputElement>, _overlay: Overlay, _viewContainerRef: ViewContainerRef, _zone: NgZone, _changeDetectorRef: ChangeDetectorRef, scrollStrategy: any, _dir: Directionality, _formField: CubFormField, _document: any, _viewportRuler: ViewportRuler, _defaults?: CubAutocompleteDefaultOptions | undefined);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /** Opens the autocomplete suggestion panel. */
    openPanel(): void;
    /** Closes the autocomplete suggestion panel. */
    closePanel(): void;
    /**
     * Updates the position of the autocomplete suggestion panel to ensure that it fits all options
     * within the viewport.
     */
    updatePosition(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => {}): void;
    registerOnTouched(fn: () => {}): void;
    setDisabledState(isDisabled: boolean): void;
    /** `View -> model callback called when value changes` */
    _onChange: (value: any) => void;
    /** `View -> model callback called when autocomplete has been touched` */
    _onTouched: () => void;
    _handleKeydown(event: KeyboardEvent): void;
    _handleInput(event: KeyboardEvent): void;
    _handleFocus(): void;
    _handleClick(): void;
    /**
     * Event handler for when the window is blurred. Needs to be an
     * arrow function in order to preserve the context.
     */
    private _windowBlurHandler;
    /** Stream of clicks outside of the autocomplete panel. */
    private _getOutsideClickStream;
    /**
     * In "auto" mode, the label will animate down as soon as focus is lost.
     * This causes the value to jump when selecting an option with the mouse.
     * This method manually floats the label until the panel can be closed.
     * @param shouldAnimate Whether the label should be animated when it is floated.
     */
    private _floatLabel;
    /** If the label has been manually elevated, return it to its normal state. */
    private _resetLabel;
    /**
     * This method listens to a stream of panel closing actions and resets the
     * stream every time the option list changes.
     */
    private _subscribeToClosingActions;
    /** Destroys the autocomplete suggestion panel. */
    private _destroyPanel;
    private _assignOptionValue;
    private _updateNativeInputValue;
    /**
     * This method closes the panel, and if a value is specified, also sets the associated
     * control to that value. It will also mark the control as dirty if this interaction
     * stemmed from the user.
     */
    private _setValueAndClose;
    /**
     * Clear any previous selected option and emit a selection change event for this option
     */
    private _clearPreviousSelectedOption;
    private _attachOverlay;
    private _getOverlayConfig;
    private _getOverlayPosition;
    /** Sets the positions on a position strategy based on the directive's input state. */
    private _setStrategyPositions;
    private _getConnectedElement;
    private _getPanelWidth;
    /** Returns the width of the input element, so the panel width can match it. */
    private _getHostWidth;
    /**
     * Resets the active item to -1 so arrow events will activate the
     * correct options, or to 0 if the consumer opted into it.
     */
    private _resetActiveItem;
    /** Determines whether the panel can be opened. */
    private _canOpen;
    /** Use defaultView of injected document if available or fallback to global window reference */
    private _getWindow;
    /** Scrolls to a particular option in the list. */
    private _scrollToOption;
    /** Handles keyboard events coming from the overlay panel. */
    private _handleOverlayEvents;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubAutocompleteTriggerBase, [null, null, null, null, null, null, { optional: true; }, { optional: true; host: true; }, { optional: true; }, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubAutocompleteTriggerBase, never, never, { "autocomplete": { "alias": "cubAutocompleteFor"; "required": false; }; "position": { "alias": "cubAutocompletePosition"; "required": false; }; "connectedTo": { "alias": "cubAutocompleteConnectedTo"; "required": false; }; "autocompleteDisabled": { "alias": "cubAutocompleteDisabled"; "required": false; }; "autocompleteAttribute": { "alias": "autocomplete"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Provider that allows the autocomplete to register as a ControlValueAccessor.
 * @docs-private
 */
declare const CUB_AUTOCOMPLETE_VALUE_ACCESSOR: any;
declare class CubAutocompleteTrigger extends _CubAutocompleteTriggerBase {
    protected _aboveClass: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAutocompleteTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubAutocompleteTrigger, "input[cubAutocompleteFor], textarea[cubAutocompleteFor]", ["cubAutocompleteTrigger"], {}, {}, never, never, true, never>;
}

declare class CubAutocompleteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubAutocompleteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubAutocompleteModule, never, [typeof i1.CubCdkScrollableModule, typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof i3.CubOptionModule, typeof i4.CubFormFieldModule, typeof i5.CubLabelModule, typeof i6.CubInputModule, typeof i7.CubInputGroupModule, typeof CubAutocomplete, typeof CubAutocompleteOrigin, typeof CubAutocompleteTrigger], [typeof i1.CubCdkScrollableModule, typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof i3.CubOptionModule, typeof i4.CubFormFieldModule, typeof i5.CubLabelModule, typeof i6.CubInputModule, typeof i7.CubInputGroupModule, typeof CubAutocomplete, typeof CubAutocompleteOrigin, typeof CubAutocompleteTrigger]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubAutocompleteModule>;
}

export { CUB_AUTOCOMPLETE_DEFAULT_OPTIONS, CUB_AUTOCOMPLETE_DEFAULT_OPTIONS_FACTORY, CUB_AUTOCOMPLETE_SCROLL_STRATEGY, CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY, CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER, CUB_AUTOCOMPLETE_VALUE_ACCESSOR, CubAutocomplete, CubAutocompleteModule, CubAutocompleteOrigin, CubAutocompleteSelectedEvent, CubAutocompleteTrigger, _CubAutocompleteBase, _CubAutocompleteMixinBase, _CubAutocompleteOriginBase, _CubAutocompleteTriggerBase, getCubAutocompleteMissingPanelError };
export type { CubAutocompleteActivatedEvent, CubAutocompleteDefaultOptions };
