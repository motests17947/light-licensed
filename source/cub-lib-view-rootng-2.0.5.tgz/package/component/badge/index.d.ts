import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ElementRef, Renderer2 } from '@angular/core';
import { CubThemeSize, CubThemeColor } from 'cub-lib-view-rootng/component/common';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';

type CubBadgePosition = 'before' | 'after' | null;
type CubBadgeShape = 'circle' | 'dot';

declare class CubBadge implements OnInit, OnDestroy {
    private elementRef;
    private renderer;
    private _color;
    private _content;
    private _shape;
    private _hidden;
    private badgeElement;
    private isInitialized;
    /** 尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 元件顏色，預設值為 'brand'。 */
    get color(): CubThemeColor;
    set color(value: CubThemeColor);
    /** 徽章內顯示的數值最大值，當超過設定數值時，會以"最大值+"顯示。
    例如：設定最大值為 99，在數值大於 99 時以 99+ 顯示，預設值為 99。*/
    max: number | null;
    /** 徽章的顯示位置，預設值為 'after'。 */
    position: CubBadgePosition;
    /** 徽章內顯示文字，當數值為 ''、undefined、null 時則不顯示為右上角的徽章樣式，預設值為 null。 */
    get content(): string | number | undefined | null;
    set content(newContent: string | number | undefined | null);
    /** 徽章的顯示形狀，預設值為 圓形。 */
    get shape(): CubBadgeShape;
    set shape(value: CubBadgeShape);
    /** 是否隱藏徽章，預設值為不隱藏。 */
    get hidden(): boolean;
    set hidden(value: BooleanInput);
    constructor(elementRef: ElementRef<HTMLElement>, renderer: Renderer2);
    ngOnInit(): void;
    ngOnDestroy(): void;
    isAfter(): boolean;
    checkRenderedContent(newContent: string | number | undefined | null): string;
    private createBadgeElement;
    private createDotBadgeElement;
    private updateRenderedContent;
    private setShape;
    private clearExistingBadges;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBadge, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubBadge, "[cubBadge]", never, { "size": { "alias": "cubBadgeSize"; "required": false; }; "color": { "alias": "cubBadgeColor"; "required": false; }; "max": { "alias": "cubBadgeMax"; "required": false; }; "position": { "alias": "cubBadgePosition"; "required": false; }; "content": { "alias": "cubBadge"; "required": false; }; "shape": { "alias": "cubBadgeShape"; "required": false; }; "hidden": { "alias": "cubBadgeHidden"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubBadgeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBadgeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubBadgeModule, never, [typeof CubBadge], [typeof CubBadge]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubBadgeModule>;
}

export { CubBadge, CubBadgeModule };
export type { CubBadgePosition, CubBadgeShape };
