import * as rxjs from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy, TemplateRef, InjectionToken } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

interface CubBreadcrumbDataNode {
    label: string;
    routerLink?: string;
    params?: {
        [param: string]: any;
    };
    queryParams?: {
        [param: string]: any;
    };
    isCustom?: boolean;
    hasComponent?: boolean;
    children?: {
        label: string;
    }[];
}

declare class CubBreadcrumbService {
    _breadcrumbItem: BehaviorSubject<CubBreadcrumbDataNode[]>;
    breadcrumbItem$: rxjs.Observable<CubBreadcrumbDataNode[]>;
    isInitialized: boolean;
    constructor();
    /**
     * 不按照 Router Data 的全自訂麵包屑
     * @param customBreadcrumb 自定義的麵包屑陣列
     */
    customBreadcrumb(customBreadcrumb: CubBreadcrumbDataNode[]): void;
    /**
     * 覆寫指定的麵包屑節點
     * @param overrideItem 指定的覆寫節點
     * @param overrideIndex 指定覆寫的索引值
     */
    overrideItem(overrideItem: CubBreadcrumbDataNode, overrideIndex?: number): void;
    /**
     * 在當前 Router Data 階層中新增麵包屑節點
     * @param newBreadcrumb 要新增的麵包屑陣列
     */
    appendItem(newBreadcrumb: CubBreadcrumbDataNode[]): void;
    /**
     * 不修改當前的 Router Data 階層，只新增功能代碼
     * @param label 功能代碼
     * @param appendIndex 指定新增的索引值
     */
    appendChild(label: string, appendIndex?: number): void;
    /** 取得路由資料 */
    getBreadcrumbItem(): CubBreadcrumbDataNode[];
    /**
     * 設定路由資料
     * @param breadcrumb 依照路由 Data 建置的麵包屑陣列
     */
    setBreadcrumbItem(breadcrumb: CubBreadcrumbDataNode[]): void;
    /** 清空路由資料與麵包屑設定 */
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBreadcrumbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubBreadcrumbService>;
}

declare class CubBreadcrumb implements OnInit, OnDestroy {
    private router;
    private activatedRoute;
    private breadcrumbService;
    isStreamlined: boolean;
    breadcrumbItem$: rxjs.Observable<CubBreadcrumbDataNode[]>;
    private _destroyed;
    itemTemplateRef?: TemplateRef<any>;
    childTemplateRef?: TemplateRef<any>;
    onResize(event: any): void;
    constructor(router: Router, activatedRoute: ActivatedRoute, breadcrumbService: CubBreadcrumbService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private _generateBreadcrumbs;
    private _createBreadcrumbsByData;
    private isMobileWidth;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBreadcrumb, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubBreadcrumb, "cub-breadcrumb", never, {}, {}, ["itemTemplateRef", "childTemplateRef"], never, true, never>;
}

declare const CUB_BREADCRUMB_ITEM: InjectionToken<CubBreadcrumbItem>;
declare class CubBreadcrumbItem {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBreadcrumbItem, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubBreadcrumbItem, "[cubBreadcrumbItem]", never, {}, {}, never, never, true, never>;
}

declare const CUB_BREADCRUMB_CHILD: InjectionToken<CubBreadcrumbChild>;
declare class CubBreadcrumbChild {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBreadcrumbChild, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubBreadcrumbChild, "[cubBreadcrumbChild]", never, {}, {}, never, never, true, never>;
}

declare class CubBreadcrumbModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubBreadcrumbModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubBreadcrumbModule, never, [typeof CubBreadcrumb, typeof CubBreadcrumbItem, typeof CubBreadcrumbChild], [typeof CubBreadcrumb, typeof CubBreadcrumbItem, typeof CubBreadcrumbChild]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubBreadcrumbModule>;
}

export { CUB_BREADCRUMB_CHILD, CUB_BREADCRUMB_ITEM, CubBreadcrumb, CubBreadcrumbChild, CubBreadcrumbItem, CubBreadcrumbModule, CubBreadcrumbService };
export type { CubBreadcrumbDataNode };
