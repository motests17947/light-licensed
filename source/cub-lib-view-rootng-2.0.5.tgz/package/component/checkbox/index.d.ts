import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CubThemeColor, HasTabIndex, CanColor, CanDisableRipple, CanDisable, CubRipple, CubThemeSize, CubFlexOrientation } from 'cub-lib-view-rootng/component/common';
import * as i0 from '@angular/core';
import { ElementRef, OnInit, AfterViewInit, DoCheck, ChangeDetectorRef, NgZone, AfterContentInit, QueryList, EventEmitter, InjectionToken, OnDestroy } from '@angular/core';
import { ControlValueAccessor, CheckboxRequiredValidator } from '@angular/forms';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { FocusableOption, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';
import * as i3 from 'cub-lib-view-rootng/component/input';

type CubCheckboxClickAction = 'noop' | 'check' | 'check-indeterminate' | undefined;

interface CubCheckboxDefaultOptions {
    color?: CubThemeColor;
    clickAction?: CubCheckboxClickAction;
}

declare const _CubCheckboxMixinBase: cub_lib_view_rootng_component_common.Constructor<HasTabIndex> & cub_lib_view_rootng_component_common.AbstractConstructor<HasTabIndex> & cub_lib_view_rootng_component_common.Constructor<CanColor> & cub_lib_view_rootng_component_common.AbstractConstructor<CanColor> & cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & {
    new (_elementRef: ElementRef): {
        _elementRef: ElementRef;
    };
};
declare class CubCheckboxChange {
    source: _CubCheckboxBase<any>;
    checked: boolean;
}
declare class CubCheckboxGroupChange {
    source: _CubCheckboxBase<any>[];
    value: string[];
    constructor(source: _CubCheckboxBase<any>[], value: string[]);
}
declare const CUB_CHECKBOX: InjectionToken<_CubCheckboxBase<any>>;
declare const CUB_CHECKBOX_GROUP: InjectionToken<_CubCheckboxGroupBase<_CubCheckboxBase<any>>>;
declare abstract class _CubCheckboxGroupBase<T extends _CubCheckboxBase<any>> implements AfterContentInit, ControlValueAccessor {
    private _changeDetector;
    abstract _checkboxes: QueryList<T>;
    private _isUpdatingFromModel;
    private _isInitialized;
    private _name;
    private _labelPosition;
    private _value;
    private _selected;
    private _disabled;
    private _required;
    /** 元件名稱，用於表單提交，預設為 undefined。 */
    get name(): string;
    set name(value: string);
    /** 元件標籤位置，預設值為 'after'。 */
    get labelPosition(): 'before' | 'after';
    set labelPosition(v: "before" | "after");
    /** 元件輸入的的當前值，預設為 undefined。 */
    get value(): string[];
    set value(value: string[]);
    /**
     * 元件的選中項目。
     * 此屬性用於設定或取得目前被選中的項目列表。
     * 預設值為 []。
     */
    get selected(): T[];
    set selected(selected: T[]);
    /** 元件是否禁用，預設為 false。 */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /** 元件是否為必填，預設為 false。 */
    get required(): boolean;
    set required(value: BooleanInput);
    /** 當元件值發生變化時觸發的事件。傳遞一個 `CubCheckboxChange` 物件，包含元件的來源和選中狀態。 */
    readonly change: EventEmitter<CubCheckboxGroupChange>;
    constructor(_changeDetector: ChangeDetectorRef);
    ngAfterContentInit(): void;
    onTouched: () => any;
    _controlValueAccessorChangeFn: (value: any) => void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    emitChangeEvent(): void;
    markCheckboxesTouched(): void;
    markCheckboxesForCheck(): void;
    private _checkSelectedCheckbox;
    private _updateCheckboxNames;
    private _updateSelectedCheckboxFromValue;
    private _updateValueFromSelectedCheckbox;
    private compareArray;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubCheckboxGroupBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubCheckboxGroupBase<any>, never, never, { "name": { "alias": "name"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "value": { "alias": "value"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, { "change": "change"; }, never, never, true, never>;
}
declare abstract class _CubCheckboxBase<E> extends _CubCheckboxMixinBase implements OnInit, AfterViewInit, ControlValueAccessor, DoCheck, CanColor, CanDisable, HasTabIndex, CanDisableRipple, FocusableOption {
    protected _changeDetectorRef: ChangeDetectorRef;
    protected _focusMonitor: FocusMonitor;
    protected _ngZone: NgZone;
    protected _options?: CubCheckboxDefaultOptions | undefined;
    abstract focus(origin?: FocusOrigin): void;
    checkboxGroup: _CubCheckboxGroupBase<_CubCheckboxBase<any>>;
    protected abstract _createChangeEvent(isChecked: boolean): E;
    protected abstract _getAnimationTargetElement(): HTMLElement | null;
    private _checked;
    private _value;
    private _disabled;
    private _required;
    private _indeterminate;
    private _labelPosition;
    private _uniqueId;
    get inputId(): string;
    /** 元件是否禁用，預設為 false。 */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /** 元件標題（螢幕閱讀器讀取用），預設為 ''。 */
    ariaLabel: string;
    /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
    ariaLabelledby: string | null;
    /** 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 ''。 */
    ariaDescribedby: string;
    /** 元件唯一識別符，預設為 undefined。 */
    id: string;
    /** 元件名稱，用於表單提交，預設為 undefined。 */
    name: string | null;
    /** 元件標籤位置，預設值為 'after'。 */
    get labelPosition(): 'before' | 'after';
    set labelPosition(value: 'before' | 'after');
    /** 元件是否被選中，預設為 false。 */
    get checked(): boolean;
    set checked(value: BooleanInput);
    /** 元件的當前值，預設為 ''。 */
    get value(): any;
    set value(value: any);
    /** 元件是否為必填，預設為 false。 */
    get required(): boolean;
    set required(value: BooleanInput);
    /** 元件部分選取狀態，預設值為 false。 */
    get indeterminate(): boolean;
    set indeterminate(value: BooleanInput);
    /** 當元件值發生變化時觸發的事件。傳遞一個 `CubCheckboxChange` 物件，包含元件的來源和選中狀態。 */
    readonly change: EventEmitter<E>;
    /** 當元件的部分選取狀態發生變化時觸發的事件。傳遞一個布林值，表示新的狀態。 */
    readonly indeterminateChange: EventEmitter<boolean>;
    _inputElement: ElementRef<HTMLInputElement>;
    _labelElement: ElementRef<HTMLInputElement>;
    ripple: CubRipple;
    constructor(idPrefix: string, checkboxGroup: _CubCheckboxGroupBase<_CubCheckboxBase<any>>, elementRef: ElementRef<HTMLElement>, _changeDetectorRef: ChangeDetectorRef, _focusMonitor: FocusMonitor, _ngZone: NgZone, tabIndex: string, _options?: CubCheckboxDefaultOptions | undefined);
    ngOnInit(): void;
    ngDoCheck(): void;
    ngAfterViewInit(): void;
    _onTouched: () => any;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    toggle(): void;
    markForCheck(): void;
    _isRippleDisabled(): boolean;
    _onLabelTextChange(): void;
    _getAriaChecked(): 'true' | 'false' | 'mixed';
    _onInteractionEvent(event: Event): void;
    _onBlur(): void;
    protected _handleInputClick(): void;
    private _controlValueAccessorChangeFn;
    private _emitChangeEvent;
    private _syncIndeterminate;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubCheckboxBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubCheckboxBase<any>, never, never, { "disabled": { "alias": "disabled"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "value": { "alias": "value"; "required": false; }; "required": { "alias": "required"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; }, { "change": "change"; "indeterminateChange": "indeterminateChange"; }, never, never, true, never>;
}
declare class CubCheckboxGroup extends _CubCheckboxGroupBase<CubCheckbox> {
    /** 群組排列方向，預設為 'horizontal'。 */
    orientation: CubFlexOrientation;
    _checkboxes: QueryList<CubCheckbox>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCheckboxGroup, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCheckboxGroup, "cub-checkbox-group", ["cubCheckboxGroup"], { "orientation": { "alias": "orientation"; "required": false; }; }, {}, ["_checkboxes"], never, true, never>;
}
declare class CubCheckbox extends _CubCheckboxBase<CubCheckboxChange> implements AfterViewInit, OnDestroy {
    _noopAnimations: boolean;
    /** 尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    constructor(checkboxGroup: CubCheckboxGroup, elementRef: ElementRef<HTMLElement>, changeDetectorRef: ChangeDetectorRef, _focusMonitor: FocusMonitor, ngZone: NgZone, tabIndex: string, _animationMode?: string, options?: CubCheckboxDefaultOptions);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * 處理標籤上的鍵盤事件。
     * 當使用者按下空白鍵時，會切換選取狀態，與顯示 Ripple 漣漪。
     */
    _onLabelKeydown(event: Event, rippleRef: CubRipple): void;
    _onInputClick(event: Event): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    protected _createChangeEvent(isChecked: boolean): CubCheckboxChange;
    protected _getAnimationTargetElement(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCheckbox, [{ optional: true; }, null, null, null, null, { attribute: "tabindex"; }, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCheckbox, "cub-checkbox", ["cubCheckbox"], { "disableRipple": { "alias": "disableRipple"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class CubCheckboxRequiredValidator extends CheckboxRequiredValidator {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCheckboxRequiredValidator, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCheckboxRequiredValidator, "cub-checkbox[required][formControlName],             cub-checkbox[required][formControl], cub-checkbox[required][ngModel]", never, {}, {}, never, never, true, never>;
}

declare const CUB_CHECKBOX_DEFAULT_OPTIONS: InjectionToken<CubCheckboxDefaultOptions>;

declare function CUB_CHECKBOX_DEFAULT_OPTIONS_FACTORY(): CubCheckboxDefaultOptions;

declare class CubCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCheckboxModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubCheckbox, typeof CubCheckboxGroup, typeof CubCheckboxRequiredValidator], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubCheckbox, typeof CubCheckboxGroup, typeof CubCheckboxRequiredValidator]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCheckboxModule>;
}

export { CUB_CHECKBOX, CUB_CHECKBOX_DEFAULT_OPTIONS, CUB_CHECKBOX_DEFAULT_OPTIONS_FACTORY, CUB_CHECKBOX_GROUP, CubCheckbox, CubCheckboxChange, CubCheckboxGroup, CubCheckboxGroupChange, CubCheckboxModule, CubCheckboxRequiredValidator, _CubCheckboxBase, _CubCheckboxGroupBase };
export type { CubCheckboxClickAction, CubCheckboxDefaultOptions };
