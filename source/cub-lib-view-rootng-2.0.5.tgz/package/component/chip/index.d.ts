import * as i0 from '@angular/core';
import { ElementRef, OnInit, AfterViewInit, AfterContentInit, OnDestroy, ChangeDetectorRef, Injector, NgZone, EventEmitter, QueryList, InjectionToken, DoCheck, OnChanges } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CubThemeSize, CubPrefix, CubSuffix, HasTabIndex, CanColor, CanDisable, CanUpdateErrorState, ErrorStateMatcher } from 'cub-lib-view-rootng/component/common';
import * as cub_lib_view_rootng_cdk from 'cub-lib-view-rootng/cdk';
import { FocusKeyManager, BreakpointObserver } from 'cub-lib-view-rootng/cdk';
import { ControlValueAccessor, NgForm, FormGroupDirective, NgControl } from '@angular/forms';
import * as cub_lib_view_rootng_component_chip from 'cub-lib-view-rootng/component/chip';
import { FocusableOption, FocusKeyManager as FocusKeyManager$1 } from 'cub-lib-view-rootng/cdk/a11y';
import { Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { SelectionModel } from 'cub-lib-view-rootng/cdk/collections';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import { CubFormFieldControl } from 'cub-lib-view-rootng/component/form-field';
import { Platform } from 'cub-lib-view-rootng/cdk/platform';
import * as i2 from 'cub-lib-view-rootng/component/label';

/**
 * Section within a chip.
 * @docs-private
 */
declare class CubChipBaseAction {
    _elementRef: ElementRef<HTMLElement>;
    /** Whether this is the primary action in the chip. */
    _isPrimary: boolean;
    protected _parentChip: {
        _handlePrimaryActionInteraction(): void;
        remove(): void;
        disabled: boolean;
        _isEditing?: boolean;
    };
    private _disabled;
    /**
     * 是否可以互動，預設值為 true。
     */
    interactive: boolean;
    /**
     * 是否停用元件狀態，預設值為 false。
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * 添加 tabIndex 屬性，預設值為 -1。
     */
    tabIndex: number;
    /**
     * 當元件為停用狀態時，是否還能 Focus，預設值為 false。
     */
    private allowFocusWhenDisabled;
    constructor(...args: unknown[]);
    focus(): void;
    _handleClick(event: MouseEvent): void;
    _handleKeydown(event: KeyboardEvent): void;
    /**
     * Determine the value of the tabindex attribute for this chip action.
     */
    protected _getTabindex(): string | null;
    /**
     * Determine the value of the disabled attribute for this chip action.
     */
    protected _getDisabledAttribute(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubChipBaseAction, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubChipBaseAction, "[CubChipBaseAction]", never, { "interactive": { "alias": "interactive"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "allowFocusWhenDisabled": { "alias": "allowFocusWhenDisabled"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_disabled: unknown;
    static ngAcceptInputType_tabIndex: unknown;
}

/** Represents an event fired on an individual `mat-chip`. */
interface CubChipBaseEvent {
    /** The chip the event was fired on. */
    chip: CubChipBase;
}
/**
 * Material design styled Chip base component. Used inside the MatChipSet component.
 *
 * Extended by MatChipOption and MatChipRow for different interaction patterns.
 */
declare class CubChipBase implements OnInit, AfterViewInit, AfterContentInit, OnDestroy {
    /** Whether the chip list is disabled. */
    _chipListDisabled: boolean;
    _changeDetectorRef: ChangeDetectorRef;
    _elementRef: ElementRef<HTMLElement>;
    /** Whether this chip is a basic (unstyled) chip. */
    _isBasicChip: boolean;
    /** Emits when the chip is focused. */
    readonly _onFocus: Subject<CubChipBaseEvent>;
    /** Emits when the chip is blurred. */
    readonly _onBlur: Subject<CubChipBaseEvent>;
    protected _value: any;
    /** The unstyled chip selector for this component. */
    protected basicChipAttrName: string;
    protected _injector: Injector;
    protected _ngZone: NgZone;
    protected _document: Document;
    private _focusMonitor;
    /** Whether the chip has focus. */
    private _hasFocusInternal;
    /** Whether moving focus into the chip is pending. */
    private _pendingFocus;
    /** Subscription to changes in the chip's actions. */
    private _actionChanges;
    private _textElement;
    private _disabled;
    /**
     * 設定元件 role 屬性，預設值為 null。
     */
    role: string | null;
    /**
     * 設定元件尺寸，預設值為 'medium'。
     */
    size: CubThemeSize;
    /**
     * 設定 id 屬性確保 chip 有一個 unique 的 id 名，預設為 'cub-chip-0'。
     */
    id: string;
    /**
     * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 null。
     */
    ariaLabel: string | null;
    /**
     * 添加 aria-description 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 null。
     */
    ariaDescription: string | null;
    /**
     添加元件的 value 會自動去掉前後的空白，預設值為 undefined。
     */
    get value(): any;
    set value(value: any);
    /**
     * 元件是否可移除，預設值為 true。
     */
    removable: boolean;
    /**
     * 元件是否要關閉漣漪效果，預設值為 false。
     */
    disableRipple: boolean;
    /**
     * 元件是否為停用狀態，預設值為 false。
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** 送出刪除元件事件 */
    readonly removed: EventEmitter<CubChipBaseEvent>;
    /** 當元件實體被移除時送出 */
    readonly destroyed: EventEmitter<CubChipBaseEvent>;
    /** The chip's leading icon. */
    leadingIcon: CubPrefix;
    /** All avatars present in the chip. */
    protected _allLeadingIcons: QueryList<CubPrefix>;
    /** All remove icons present in the chip. */
    protected _allRemoveIcons: QueryList<CubSuffix>;
    /** Id of a span that contains this chip's aria description. */
    _ariaDescriptionId: string;
    constructor(...args: unknown[]);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    _hasFocus(): boolean;
    /**
     * Allows for programmatic removal of the chip.
     *
     * Informs any listeners of the removal request. Does not remove the chip from the DOM.
     */
    remove(): void;
    /** Whether or not the ripple should be disabled. */
    _isRippleDisabled(): boolean;
    /** Handles keyboard events on the chip. */
    _handleKeydown(event: KeyboardEvent): void;
    /** Allows for programmatic focusing of the chip. */
    focus(): void;
    /** Gets the action that contains a specific target node. */
    _getSourceAction(target: Node): CubChipBaseAction | undefined;
    /** Gets all of the actions within the chip. */
    _getActions(): CubChipBaseAction[];
    /** Handles interactions with the primary action of the chip. */
    _handlePrimaryActionInteraction(): void;
    /** Starts the focus monitoring process on the chip. */
    private _monitorFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubChipBase, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubChipBase, "cub-chip-base", ["CubChipBase"], { "role": { "alias": "role"; "required": false; }; "size": { "alias": "size"; "required": false; }; "id": { "alias": "id"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaDescription": { "alias": "aria-description"; "required": false; }; "value": { "alias": "value"; "required": false; }; "removable": { "alias": "removable"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "removed": "removed"; "destroyed": "destroyed"; }, ["leadingIcon", "_allLeadingIcons", "_allRemoveIcons"], ["*"], true, never>;
    static ngAcceptInputType_removable: unknown;
    static ngAcceptInputType_disableRipple: unknown;
    static ngAcceptInputType_disabled: unknown;
}

/**
 * Basic container component for the CubChipBase component.
 *
 * Extended by CubSelectableChipGroup and CubChipBaseGrid for different interaction patterns.
 */
declare class CubChipGroupBase implements AfterViewInit, OnDestroy {
    /** Flat list of all the actions contained within the chips. */
    _chipActions: QueryList<CubChipBaseAction>;
    protected _elementRef: ElementRef<HTMLElement>;
    protected _changeDetectorRef: ChangeDetectorRef;
    /** Used to manage focus within the chip list. */
    protected _keyManager: FocusKeyManager<CubChipBaseAction>;
    /** Subject that emits when the component has been destroyed. */
    protected _destroyed: Subject<void>;
    /** Role to use if it hasn't been overwritten by the user. */
    protected _defaultRole: string;
    protected _disabled: boolean;
    private _explicitRole;
    private _dir;
    /** Index of the last destroyed chip that had focus. */
    private _lastDestroyedFocusedChipIndex;
    /** Whether the chip list contains chips or not. */
    get empty(): boolean;
    /** Whether any of the chips inside of this chip-set has focus. */
    get focused(): boolean;
    /** Combined stream of all of the child chips' focus events. */
    get chipFocusChanges(): Observable<CubChipBaseEvent>;
    /** Combined stream of all of the child chips' destroy events. */
    get chipDestroyedChanges(): Observable<CubChipBaseEvent>;
    /** Combined stream of all of the child chips' remove events. */
    get chipRemovedChanges(): Observable<CubChipBaseEvent>;
    /** 元件是否為停用狀態，預設值為 false。 */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** 添加 aria-role 的值，預設為 null。 */
    get role(): string | null;
    set role(value: string | null);
    /**
     *
     * 添加 tabIndex 屬性，預設值為 0。
     */
    tabIndex: number;
    /** The chips that are part of this chip set. */
    _chips: QueryList<CubChipBase>;
    /** 設定 tabIndex 的值，預設為 0 */
    constructor(...args: unknown[]);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Dummy method for subclasses to override. Base chip set cannot be focused. */
    focus(): void;
    /** Handles keyboard events on the chip set. */
    _handleKeydown(event: KeyboardEvent): void;
    /** Checks whether any of the chips is focused. */
    protected _hasFocusedChip(): boolean;
    /** Syncs the chip-set's state with the individual chips. */
    protected _syncChipsState(): void;
    /**
     * Utility to ensure all indexes are valid.
     *
     * @param index The index to be checked.
     * @returns True if the index is valid for our list of chips.
     */
    protected _isValidIndex(index: number): boolean;
    /**
     * Removes the `tabindex` from the chip set and resets it back afterwards, allowing the
     * user to tab out of it. This prevents the set from capturing focus and redirecting
     * it back to the first chip, creating a focus trap, if it user tries to tab away.
     */
    protected _allowFocusEscape(): void;
    /**
     * Gets a stream of events from all the chips within the set.
     * The stream will autocubically incorporate any newly-added chips.
     */
    protected _getChipStream<T, C extends CubChipBase = CubChipBase>(mappingFunction: (chip: C) => Observable<T>): Observable<T>;
    /** Checks whether an event comes from inside a chip element. */
    protected _originatesFromChip(event: Event): boolean;
    /**
     * Determines if key manager should avoid putting a given chip action in the tab index. Skip
     * non-interactive and disabled actions since the user can't do anything with them.
     */
    protected _skipPredicate(action: CubChipBaseAction): boolean;
    /** Sets up the chip set's focus management logic. */
    private _setUpFocusManagement;
    /** Listens to changes in the chip set and syncs up the state of the individual chips. */
    private _trackChipSetChanges;
    /** Starts tracking the destroyed chips in order to capture the focused one. */
    private _trackDestroyedFocusedChip;
    /**
     * Finds the next appropriate chip to move focus to,
     * if the currently-focused chip is destroyed.
     */
    private _redirectDestroyedChipFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubChipGroupBase, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubChipGroupBase, "cub-chip-group-base", never, { "disabled": { "alias": "disabled"; "required": false; }; "role": { "alias": "role"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; }, {}, ["_chips"], ["*"], true, never>;
    static ngAcceptInputType_disabled: unknown;
    static ngAcceptInputType_tabIndex: unknown;
}

/** Event object emitted by MatChipOption when selected or deselected. */
declare class CubChipBaseSelectionChange {
    /** Reference to the chip that emitted the event. */
    source: CubSelectableChip;
    /** Whether the chip that emitted the event is selected. */
    selected: boolean;
    /** Whether the selection change was a result of a user interaction. */
    isUserInput: boolean;
    constructor(
    /** Reference to the chip that emitted the event. */
    source: CubSelectableChip, 
    /** Whether the chip that emitted the event is selected. */
    selected: boolean, 
    /** Whether the selection change was a result of a user interaction. */
    isUserInput?: boolean);
}
/**
 * An extension of the MatChip component that supports chip selection. Used with MatChipListbox.
 *
 * Unlike other chips, the user can focus on disabled chip options inside a MatChipListbox. The
 * user cannot click disabled chips.
 */
declare class CubSelectableChip extends CubChipBase implements OnInit {
    /** Whether the chip list is selectable. */
    chipListSelectable: boolean;
    /** Whether the chip list is in multi-selection mode. */
    _chipListMultiple: boolean;
    /** Default chip options. */
    _defaultOptions: cub_lib_view_rootng_component_chip.CubChipBaseDefaultOptions | null;
    /** Whether the chip list hides single-selection indicator. */
    _chipListHideSingleSelectionIndicator: boolean;
    /** The unstyled chip selector for this component. */
    protected basicChipAttrName: string;
    protected _selectable: boolean;
    private _selected;
    /**
     * The ARIA selected applied to the chip. Conforms to WAI ARIA best practices for listbox
     * interaction patterns.
     *
     * From [WAI ARIA Listbox authoring practices guide](
     * https://www.w3.org/WAI/ARIA/apg/patterns/listbox/):
     *  "If any options are selected, each selected option has either aria-selected or aria-checked
     *  set to true. All options that are selectable but not selected have either aria-selected or
     *  aria-checked set to false."
     *
     * Set `aria-selected="false"` on not-selected listbox options that are selectable to fix
     * VoiceOver reading every option as "selected" (#25736).
     */
    get ariaSelected(): string | null;
    /**
     * 元件是否能夠被選取，預設值為 true。
     */
    get selectable(): boolean;
    set selectable(value: boolean);
    /**
     * 元件目前的選取狀態，預設值為 false。
     */
    get selected(): boolean;
    set selected(value: boolean);
    /** 當元件選取狀態改變時送出事件。 */
    readonly selectionChange: EventEmitter<CubChipBaseSelectionChange>;
    ngOnInit(): void;
    _handlePrimaryActionInteraction(): void;
    /** Selects the chip. */
    select(): void;
    /** Deselects the chip. */
    deselect(): void;
    /** Selects this chip and emits userInputSelection event */
    selectViaInteraction(): void;
    /** Toggles the current selected state of this chip. */
    toggleSelected(isUserInput?: boolean): boolean;
    _hasLeadingGraphic(): boolean;
    _setSelectedState(isSelected: boolean, isUserInput: boolean, emitEvent: boolean): void;
    _getHostElement(): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSelectableChip, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubSelectableChip, "cub-selectable-chip", never, { "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, { "selectionChange": "selectionChange"; }, never, ["*"], true, never>;
    static ngAcceptInputType_selectable: unknown;
    static ngAcceptInputType_selected: unknown;
}

/** Change event object that is emitted when the chip listbox value has changed. */
declare class CubSelectableChipGroupChange {
    /** Chip listbox that emitted the event. */
    source: CubSelectableChipGroup;
    /** Value of the chip listbox when the event was emitted. */
    value: any;
    constructor(
    /** Chip listbox that emitted the event. */
    source: CubSelectableChipGroup, 
    /** Value of the chip listbox when the event was emitted. */
    value: any);
}
/**
 * Provider Expression that allows mat-chip-listbox to register as a ControlValueAccessor.
 * This allows it to support [(ngModel)].
 * @docs-private
 */
declare const CUB_SELECTABLE_CHIP_GROUP_VALUE_ACCESSOR: any;
/**
 * An extension of the MatChipSet component that supports chip selection.
 * Used with MatChipOption chips.
 */
declare class CubSelectableChipGroup extends CubChipGroupBase implements AfterContentInit, OnDestroy, ControlValueAccessor {
    breakpointObserver: BreakpointObserver;
    windowSizeChange: Observable<cub_lib_view_rootng_cdk.BreakpointState>;
    protected _defaultRole: string;
    protected _selectable: boolean;
    protected _value: any;
    private _multiple;
    /** Combined stream of all of the child chips' selection change events. */
    get chipSelectionChanges(): Observable<CubChipBaseSelectionChange>;
    /** Combined stream of all of the child chips' blur events. */
    get chipBlurChanges(): Observable<CubChipBaseEvent>;
    /** The array of selected chips inside the chip listbox. */
    get selected(): CubSelectableChip[] | CubSelectableChip;
    /**
     * 是否開放多選，預設值為 false。
     */
    get multiple(): boolean;
    set multiple(value: boolean);
    /**
     * 添加 aria-orientation 屬性的值，用於告訴螢幕閱讀器元件排列方向。
     */
    ariaOrientation: 'horizontal' | 'vertical';
    /**
     * 添加元件的 label， 預設值為 ''。
     */
    label: string;
    /**
     * 添加清除按鈕的文字， 預設值為 '清除'。
     */
    clearButtonText: string;
    /**
     * 是否顯示清除的按鈕，預設值為 false。
     */
    showClearButton: boolean;
    /**
     * 選擇元件的尺寸，預設值為 'medium'。
     */
    size: CubThemeSize;
    /**
     * 元件是否可以被選取，如果不行，底下的chip選取狀態將被忽略，預設值為 true。
     */
    get selectable(): boolean;
    set selectable(value: boolean);
    /**
     * 將選項值與選取值進行比較的函數。第1個參數是來自選項的值。第2個是來自選擇的值需要返回一個布林值。
     */
    compareWith: (o1: any, o2: any) => boolean;
    /**
     * 此輸入項是否為必填，預設值為 false。
     */
    required: boolean;
    /** 元件的值，會與底下被選取的 chip 連動，預設值為 undefined。 */
    get value(): any;
    set value(value: any);
    /**
     * 當列表的值被改動時會送出事件。
     */
    readonly change: EventEmitter<CubSelectableChipGroupChange>;
    _chips: QueryList<CubSelectableChip>;
    ngAfterContentInit(): void;
    /**
     * Function when touched. Set as part of ControlValueAccessor implementation.
     * @docs-private
     */
    _onTouched: () => void;
    /**
     * Function when changed. Set as part of ControlValueAccessor implementation.
     * @docs-private
     */
    _onChange: (value: any) => void;
    /**
     * Focuses the first selected chip in this chip listbox, or the first non-disabled chip when there
     * are no selected chips.
     */
    focus(): void;
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    writeValue(value: any): void;
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    registerOnChange(fn: (value: any) => void): void;
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    registerOnTouched(fn: () => void): void;
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    setDisabledState(isDisabled: boolean): void;
    /** Selects all chips with value. */
    _setSelectionByValue(value: any, isUserInput?: boolean): void;
    /** When blurred, marks the field as touched when focus moved outside the chip listbox. */
    _blur(): void;
    _keydown(event: KeyboardEvent): void;
    clearOptions(): void;
    /**
     * Determines if key manager should avoid putting a given chip action in the tab index. Skip
     * non-interactive actions since the user can't do anything with them.
     */
    protected _skipPredicate(action: CubChipBaseAction): boolean;
    /** Marks the field as touched */
    private _markAsTouched;
    /** Emits change event to set the model value. */
    private _propagateChanges;
    /**
     * Deselects every chip in the listbox.
     * @param skip Chip that should not be deselected.
     */
    private _clearSelection;
    /**
     * Finds and selects the chip based on its value.
     * @returns Chip that has the corresponding value.
     */
    private _selectValue;
    /** Syncs the chip-listbox selection state with the individual chips. */
    private _syncListboxProperties;
    /** Returns the first selected chip in this listbox, or undefined if no chips are selected. */
    private _getFirstSelectedChip;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSelectableChipGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubSelectableChipGroup, "cub-selectable-chip-group", never, { "multiple": { "alias": "multiple"; "required": false; }; "ariaOrientation": { "alias": "aria-orientation"; "required": false; }; "label": { "alias": "label"; "required": false; }; "clearButtonText": { "alias": "clearButtonText"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "size": { "alias": "size"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "compareWith": { "alias": "compareWith"; "required": false; }; "required": { "alias": "required"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "change": "change"; }, ["_chips"], ["*"], true, never>;
    static ngAcceptInputType_multiple: unknown;
    static ngAcceptInputType_selectable: unknown;
    static ngAcceptInputType_required: unknown;
}

interface CubInputChipEvent {
    /** The chip the event was fired on. */
    chip: CubInputChip;
}
/** Event object emitted by CubInputChip when selected or deselected. */
declare class CubInputChipSelectionChange {
    /** Reference to the chip that emitted the event. */
    source: CubInputChip;
    /** Whether the chip that emitted the event is selected. */
    selected: boolean;
    /** Whether the selection change was a result of a user interaction. */
    isUserInput: boolean;
    constructor(
    /** Reference to the chip that emitted the event. */
    source: CubInputChip, 
    /** Whether the chip that emitted the event is selected. */
    selected: boolean, 
    /** Whether the selection change was a result of a user interaction. */
    isUserInput?: boolean);
}
/**
 * Injection token that can be used to reference instances of `CubInputChipRemove`. It serves as
 * alternative token to the actual `CubInputChipRemove` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
declare const CUB_INPUT_CHIP_REMOVE: InjectionToken<CubInputChipRemove>;
/** @docs-private */
declare abstract class CubInputChipBase {
    _elementRef: ElementRef;
    abstract disabled: boolean;
    constructor(_elementRef: ElementRef);
}
declare const _CubInputChipMixinBase: cub_lib_view_rootng_component_common.Constructor<HasTabIndex> & cub_lib_view_rootng_component_common.AbstractConstructor<HasTabIndex> & cub_lib_view_rootng_component_common.Constructor<CanColor> & cub_lib_view_rootng_component_common.AbstractConstructor<CanColor> & cub_lib_view_rootng_component_common.Constructor<cub_lib_view_rootng_component_common.CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<cub_lib_view_rootng_component_common.CanDisableRipple> & typeof CubInputChipBase;
/** Material Design styled chip directive. Used inside the CubInputChipList component. */
declare class CubInputChip extends _CubInputChipMixinBase implements FocusableOption, OnDestroy, CanColor, HasTabIndex, CanDisable {
    private _ngZone;
    private _changeDetectorRef;
    /** Whether the chip has focus. */
    _hasFocus: boolean;
    /** Whether the chip list is selectable */
    chipListSelectable: boolean;
    /** Whether the chip list is in multi-selection mode. */
    _chipListMultiple: boolean;
    /** Whether the chip list as a whole is disabled. */
    _chipListDisabled: boolean;
    /** Emits when the chip is focused. */
    readonly _onFocus: Subject<CubInputChipEvent>;
    /** Emits when the chip is blurred. */
    readonly _onBlur: Subject<CubInputChipEvent>;
    protected _value: any;
    protected _disabled: boolean;
    protected _removable: boolean;
    private _size;
    /**
     * 設定元件 role 屬性名稱，預設值為 'tag'。
     */
    role: string;
    /**
     * 設定元件的 value， 預設值為 undefined。
     */
    get value(): any;
    set value(value: any);
    /** 元件是否被停用，預設值為 false。 */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /**
     * 元件是否能被刪除，預設值為 true。
     */
    get removable(): boolean;
    set removable(value: BooleanInput);
    /**
     * 設定元件此吋，預設值為 'medium'。
     */
    get size(): CubThemeSize;
    set size(value: CubThemeSize);
    /**
     * 元件被選取時送出事件。
     */
    readonly selectionChange: EventEmitter<CubInputChipSelectionChange>;
    /** 元件實體被移除時送出事件。 */
    readonly destroyed: EventEmitter<CubInputChipEvent>;
    /** 元件要被刪除時送出事件。 */
    readonly removed: EventEmitter<CubInputChipEvent>;
    /** The chip's remove toggler. */
    removeIcon: CubInputChipRemove;
    constructor(elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, platform: Platform, _changeDetectorRef: ChangeDetectorRef, _document: any, animationMode?: string, tabIndex?: string);
    ngOnDestroy(): void;
    /** Toggles the current selected state of this chip. */
    /** Allows for programmatic focusing of the chip. */
    focus(): void;
    /**
     * Allows for programmatic removal of the chip. Called by the CubInputChipList when the DELETE or
     * BACKSPACE keys are pressed.
     *
     * Informs any listeners of the removal request. Does not remove the chip from the DOM.
     */
    remove(): void;
    /** Handles click events on the chip. */
    _handleClick(event: Event): void;
    /** Handle custom key presses. */
    _handleKeydown(event: KeyboardEvent): void;
    _blur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubInputChip, [null, null, null, null, null, { optional: true; }, { attribute: "tabindex"; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubInputChip, "cub-basic-chip, [cub-basic-chip], cub-input-chip, [cub-input-chip]", ["cubChip"], { "color": { "alias": "color"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "role": { "alias": "role"; "required": false; }; "value": { "alias": "value"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "removable": { "alias": "removable"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "selectionChange": "selectionChange"; "destroyed": "destroyed"; "removed": "removed"; }, ["removeIcon"], ["*"], true, never>;
}
/**
 * Applies proper (click) support and adds styling for use with the Material Design "cancel" icon
 * available at https://material.io/icons/#ic_cancel.
 *
 * Example:
 *
 *     `<cub-input-chip>
 *       <cub-icon cubChipRemove>cancel</cub-icon>
 *     </cub-input-chip>`
 *
 * You *may* use a custom icon, but you may need to override the `cub-input-chip-remove` positioning
 * styles to properly center the icon within the chip.
 */
declare class CubInputChipRemove {
    protected _parentChip: CubInputChip;
    constructor(_parentChip: CubInputChip, elementRef: ElementRef<HTMLElement>);
    /** Calls the parent chip's public `remove()` method if applicable. */
    _handleClick(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubInputChipRemove, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubInputChipRemove, "[cubChipRemove]", never, {}, {}, never, never, true, never>;
}

interface CubChipBaseDefaultOptions {
    /** The list of key codes that will trigger a chipEnd event. */
    separatorKeyCodes: readonly number[] | ReadonlySet<number>;
    /** Whether icon indicators should be hidden for single-selection. */
    hideSingleSelectionIndicator?: boolean;
}
interface CubInputChipTextControl {
    /** Unique identifier for the text control. */
    id: string;
    /** The text control's placeholder text. */
    placeholder: string;
    /** Whether the text control has browser focus. */
    focused: boolean;
    /** Whether the text control is empty. */
    empty: boolean;
    /** Focuses the text control. */
    focus(options?: FocusOptions): void;
}

/** @docs-private */
declare const _CubInputChipGroupBase: cub_lib_view_rootng_component_common.Constructor<CanUpdateErrorState> & cub_lib_view_rootng_component_common.AbstractConstructor<CanUpdateErrorState> & {
    new (_defaultErrorStateMatcher: ErrorStateMatcher, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, ngControl: NgControl): {
        /**
         * Emits whenever the component state changes and should cause the parent
         * form-field to update. Implemented as part of `MatFormFieldControl`.
         * @docs-private
         */
        readonly stateChanges: Subject<void>;
        _defaultErrorStateMatcher: ErrorStateMatcher;
        _parentForm: NgForm;
        _parentFormGroup: FormGroupDirective;
        /**
         * Form control bound to the component.
         * Implemented as part of `MatFormFieldControl`.
         * @docs-private
         */
        ngControl: NgControl;
    };
};
/** Change event object that is emitted when the chip list value has changed. */
declare class CubInputChipGroupChange {
    /** Chip list that emitted the event. */
    source: CubInputChipGroup;
    /** Value of the chip list when the event was emitted. */
    value: any;
    constructor(
    /** Chip list that emitted the event. */
    source: CubInputChipGroup, 
    /** Value of the chip list when the event was emitted. */
    value: any);
}
declare class CubInputChipGroup extends _CubInputChipGroupBase implements CubFormFieldControl<any>, ControlValueAccessor, AfterContentInit, DoCheck, OnInit, OnDestroy, CanUpdateErrorState {
    protected _elementRef: ElementRef<HTMLElement>;
    private _changeDetectorRef;
    private _dir;
    /** Uid of the chip list */
    _uid: string;
    /** Tab index for the chip list. */
    _tabIndex: number;
    /**
     * User defined tab index.
     * When it is not null, use user defined tab index. Otherwise use _tabIndex
     */
    _userTabIndex: number | null;
    /** The FocusKeyManager which handles focus. */
    _keyManager: FocusKeyManager$1<CubInputChip>;
    _selectionModel: SelectionModel<CubInputChip>;
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    readonly controlType: string;
    protected _value: any;
    protected _required: boolean | undefined;
    protected _placeholder: string;
    protected _disabled: boolean;
    /** The chip input to add more chips */
    protected _chipInput: CubInputChipTextControl;
    /**
     * When a chip is destroyed, we store the index of the destroyed chip until the chips
     * query list notifies about the update. This is necessary because we cannot determine an
     * appropriate chip that should receive focus until the array of chips updated completely.
     */
    private _lastDestroyedChipIndex;
    /** Subject that emits when the component has been destroyed. */
    private readonly _destroyed;
    /** Subscription to focus changes in the chips. */
    private _chipFocusSubscription;
    /** Subscription to blur changes in the chips. */
    private _chipBlurSubscription;
    /** Subscription to selection changes in chips. */
    private _chipSelectionSubscription;
    /** Subscription to remove changes in chips. */
    private _chipRemoveSubscription;
    private _multiple;
    private _explicitRole?;
    /**
     * 設定元件的 value， 預設值為 'cub-input-chip-group-${nextUniqueId++}'。
     */
    get id(): string;
    /** Whether any chips or the cubChipInput inside of this chip-list has focus. */
    get focused(): boolean;
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    get empty(): boolean;
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    get shouldLabelFloat(): boolean;
    /** Combined stream of all of the child chips' selection change events. */
    get chipSelectionChanges(): Observable<CubInputChipSelectionChange>;
    /** Combined stream of all of the child chips' focus change events. */
    get chipFocusChanges(): Observable<CubInputChipEvent>;
    /** Combined stream of all of the child chips' blur change events. */
    get chipBlurChanges(): Observable<CubInputChipEvent>;
    /** Combined stream of all of the child chips' remove change events. */
    get chipRemoveChanges(): Observable<CubInputChipEvent>;
    /**
     * 設定元件 role 屬性名稱，預設值為 'chip-group'
     */
    get role(): string | null;
    set role(role: string | null);
    /**
     * 設定元件尺寸，預設值為 'medium'。
     */
    size: CubThemeSize;
    /**
     * 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 ''。
     */
    ariaDescribedBy: string;
    /**
     * 用於控制何時顯示錯誤訊息的物件，預設為 undefined。
     */
    errorStateMatcher: ErrorStateMatcher;
    /**
     * 是否開放多選，預設值為 false。
     */
    get multiple(): boolean;
    set multiple(value: BooleanInput);
    /**
     * 將選項值與選取值進行比較的函數。第1個參數是來自選項的值。第2個是來自選擇的值需要返回一個布林值。
     */
    get compareWith(): (o1: any, o2: any) => boolean;
    set compareWith(fn: (o1: any, o2: any) => boolean);
    /**
     * 設定元件的 value， 預設值為 undefined。
     */
    get value(): any;
    set value(value: any);
    /**
     * 是否為必填，用於 formfield，預設值為 fales。
     */
    get required(): boolean;
    set required(value: BooleanInput);
    /**
     * 設定元件的提示字元，預設值為 ''。
     */
    get placeholder(): string;
    set placeholder(value: string);
    /**
     * 元件是否為停用狀態，預設值為 false。
     */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /**
     * 添加 aria-orientation 屬性的值，用於告訴螢幕閱讀器元件排列方向。
     */
    ariaOrientation: 'horizontal' | 'vertical';
    /**
     * 設定元件 tabindex 預設值為 0。
     */
    set tabIndex(value: number);
    /**
     * 當元件有變動時會送出事件。
     */
    readonly change: EventEmitter<CubInputChipGroupChange>;
    /**
     * 當值有變動時會送出事件。
     */
    readonly valueChange: EventEmitter<any>;
    /** The chips contained within this chip list. */
    chips: QueryList<CubInputChip>;
    constructor(_elementRef: ElementRef<HTMLElement>, _changeDetectorRef: ChangeDetectorRef, _dir: Directionality, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, _defaultErrorStateMatcher: ErrorStateMatcher, ngControl: NgControl);
    ngAfterContentInit(): void;
    ngOnInit(): void;
    ngDoCheck(): void;
    ngOnDestroy(): void;
    /** Function when touched */
    _onTouched: () => void;
    /** Function when changed */
    _onChange: (value: any) => void;
    /** Associates an HTML input element with this chip list. */
    registerInput(inputElement: CubInputChipTextControl): void;
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    setDescribedByIds(ids: string[]): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    onContainerClick(event: MouseEvent): void;
    /**
     * Focuses the first non-disabled chip in this chip list, or the associated input when there
     * are no eligible chips.
     */
    focus(options?: FocusOptions): void;
    /** Attempt to focus an input if we have one. */
    _focusInput(options?: FocusOptions): void;
    /**
     * Pass events to the keyboard manager. Available here for tests.
     */
    _keydown(event: KeyboardEvent): void;
    _setSelectionByValue(value: any, isUserInput?: boolean): void;
    /** When blurred, mark the field as touched when focus moved outside the chip list. */
    _blur(): void;
    /** Mark the field as touched */
    _markAsTouched(): void;
    /**
     * Removes the `tabindex` from the chip list and resets it back afterwards, allowing the
     * user to tab out of it. This prevents the list from capturing focus and redirecting
     * it back to the first chip, creating a focus trap, if it user tries to tab away.
     */
    _allowFocusEscape(): void;
    /**
     * Check the tab index as you should not be allowed to focus an empty list.
     */
    protected _updateTabIndex(): void;
    /**
     * If the amount of chips changed, we need to update the
     * key manager state and focus the next closest chip.
     */
    protected _updateFocusForDestroyedChips(): void;
    private _compareWith;
    /**
     * Utility to ensure all indexes are valid.
     *
     * @param index The index to be checked.
     * @returns True if the index is valid for our list of chips.
     */
    private _isValidIndex;
    /**
     * Finds and selects the chip based on its value.
     * @returns Chip that has the corresponding value.
     */
    private _selectValue;
    private _initializeSelection;
    private _resetChips;
    private _dropSubscriptions;
    /** Listens to user-generated selection events on each chip. */
    private _listenToChipsFocus;
    private _listenToChipsRemoved;
    /** Checks whether an event comes from inside a chip element. */
    private _originatesFromChip;
    /** Checks whether any of the chips is focused. */
    private _hasFocusedChip;
    /** Syncs the list's state with the individual chips. */
    private _syncChipsState;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubInputChipGroup, [null, null, { optional: true; }, { optional: true; }, { optional: true; }, null, { optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubInputChipGroup, "cub-input-chip-group", ["cubInputChipGroup"], { "role": { "alias": "role"; "required": false; }; "size": { "alias": "size"; "required": false; }; "ariaDescribedBy": { "alias": "aria-describedby"; "required": false; }; "errorStateMatcher": { "alias": "errorStateMatcher"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "compareWith": { "alias": "compareWith"; "required": false; }; "value": { "alias": "value"; "required": false; }; "required": { "alias": "required"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "ariaOrientation": { "alias": "aria-orientation"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; }, { "change": "change"; "valueChange": "valueChange"; }, ["chips"], ["*"], true, never>;
}

/** Interface for a text control that is used to drive interaction with a cub-input-chip-group. */
interface CubBaseInputChipControl {
    /** Unique identifier for the text control. */
    id: string;
    /** The text control's placeholder text. */
    placeholder: string;
    /** Whether the text control has browser focus. */
    focused: boolean;
    /** Whether the text control is empty. */
    empty: boolean;
    /** Focuses the text control. */
    focus(options?: FocusOptions): void;
}

declare const CUB_CHIP_DEFAULT_OPTIONS: InjectionToken<CubChipBaseDefaultOptions>;
declare const CUB_CHIP_REMOVE: InjectionToken<unknown>;
/**
 * Injection token used to avoid a circular dependency between the `MatChip` and `MatChipAction`.
 */
declare const CUB_CHIP: InjectionToken<unknown>;
declare const CUB_CHIPS_DEFAULT_OPTIONS: InjectionToken<CubChipsDefaultOptions>;
declare const CUB_CHIP_DEFAULT_OPTIONS_PROVIDER: {
    provide: InjectionToken<CubChipsDefaultOptions>;
    useValue: CubChipsDefaultOptions;
};
interface CubChipsDefaultOptions {
    /** The list of key codes that will trigger a chipEnd event. */
    separatorKeyCodes: readonly number[] | ReadonlySet<number>;
}

/** Represents an input event on a `CubInputChipControl`. */
interface CubInputChipControlEvent {
    /**
     * The native `<input>` element that the event is being fired for.
     */
    input: HTMLInputElement;
    /** The value of the input. */
    value: string;
    /** Reference to the chip input that emitted the event. */
    chipInput: CubInputChipControl;
}
declare class CubInputChipControl implements CubBaseInputChipControl, OnChanges, OnDestroy, AfterContentInit {
    protected _elementRef: ElementRef<HTMLInputElement>;
    private _defaultOptions;
    /** Whether the control is focused. */
    focused: boolean;
    _addOnBlur: boolean;
    _chipList: CubInputChipGroup;
    /** The native input element to which this directive is attached. */
    readonly inputElement: HTMLInputElement;
    /** Used to prevent focus moving to chips while user is holding backspace */
    private _focusLastChipOnBackspace;
    private _disabled;
    /** Whether the input is empty. */
    get empty(): boolean;
    /**
     * 註冊用於 chip 的群組，預設值為 undefiend。
     */
    set chipList(value: CubInputChipGroup);
    /**
     * 當 input 觸發 blur 事件時，是否該送出，預設值為 false。
     */
    get addOnBlur(): boolean;
    set addOnBlur(value: BooleanInput);
    /**
     * 訂定元件用的提示字元，預設值為 ''。
     */
    placeholder: string;
    /**
     * 定定元件的 id，預設值為 'cub-input-chip-control-${nextUniqueId++}'。
     */
    id: string;
    /**
     * 元件是否為停用狀態，預設值為 false。
     */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /**
     * 設定輸入框創建 chip 的 key，預設值為 enter。
     */
    separatorKeyCodes: readonly number[] | ReadonlySet<number>;
    /**
     * 當創建 chip 時送出事件。
     */
    readonly chipEnd: EventEmitter<CubInputChipControlEvent>;
    constructor(_elementRef: ElementRef<HTMLInputElement>, _defaultOptions: CubChipsDefaultOptions);
    ngOnChanges(): void;
    ngOnDestroy(): void;
    ngAfterContentInit(): void;
    /** Utility method to make host definition/tests more clear. */
    _keydown(event?: KeyboardEvent): void;
    /**
     * Pass events to the keyboard manager. Available here for tests.
     */
    _keyup(event: KeyboardEvent): void;
    /** Checks to see if the blur should emit the (chipEnd) event. */
    _blur(): void;
    _focus(): void;
    /** Checks to see if the (chipEnd) event needs to be emitted. */
    _emitChipEnd(event?: KeyboardEvent): void;
    _onInput(): void;
    /** Focuses the input. */
    focus(options?: FocusOptions): void;
    /** Clears the input */
    clear(): void;
    /** Checks whether a keycode is one of the configured separators. */
    private _isSeparatorKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubInputChipControl, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubInputChipControl, "input[cubInputChipFor]", ["cubInputChipFor"], { "chipList": { "alias": "cubInputChipFor"; "required": false; }; "addOnBlur": { "alias": "cubInputChipAddOnBlur"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "id": { "alias": "id"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "separatorKeyCodes": { "alias": "cubInputChipSeparatorKeyCodes"; "required": false; }; }, { "chipEnd": "cubInputChipTokenEnd"; }, never, never, true, never>;
}

declare class CubChipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubChipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubChipModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof CubChipBase, typeof CubChipBaseAction, typeof CubSelectableChip, typeof CubSelectableChipGroup, typeof CubInputChipControl, typeof CubInputChipRemove, typeof CubInputChipGroup, typeof CubInputChip], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof CubChipBase, typeof CubChipBaseAction, typeof CubSelectableChip, typeof CubSelectableChipGroup, typeof CubInputChipControl, typeof CubInputChipRemove, typeof CubInputChipGroup, typeof CubInputChip]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubChipModule>;
}

export { CUB_CHIP, CUB_CHIPS_DEFAULT_OPTIONS, CUB_CHIP_DEFAULT_OPTIONS, CUB_CHIP_DEFAULT_OPTIONS_PROVIDER, CUB_CHIP_REMOVE, CUB_INPUT_CHIP_REMOVE, CUB_SELECTABLE_CHIP_GROUP_VALUE_ACCESSOR, CubChipBase, CubChipBaseAction, CubChipBaseSelectionChange, CubChipGroupBase, CubChipModule, CubInputChip, CubInputChipControl, CubInputChipGroup, CubInputChipGroupChange, CubInputChipRemove, CubInputChipSelectionChange, CubSelectableChip, CubSelectableChipGroup, CubSelectableChipGroupChange };
export type { CubBaseInputChipControl, CubChipBaseDefaultOptions, CubChipBaseEvent, CubChipsDefaultOptions, CubInputChipControlEvent, CubInputChipEvent, CubInputChipTextControl };
