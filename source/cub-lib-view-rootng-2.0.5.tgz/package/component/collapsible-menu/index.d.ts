import * as i0 from '@angular/core';
import { AfterViewInit, OnChanges, OnDestroy, TemplateRef, EventEmitter, ChangeDetectorRef, SimpleChanges, ElementRef, NgZone, OnInit, Renderer2 } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CubNavMenuTrigger, CubNavMenu } from 'cub-lib-view-rootng/component/nav-menu';
import * as rxjs from 'rxjs';
import { BehaviorSubject, Subject } from 'rxjs';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CanDisable, CanDisableRipple } from 'cub-lib-view-rootng/component/common';
import { FocusableOption, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';

interface CubCollapsibleMenuItem {
    id: string;
    label: string;
    icon?: string;
    tabindex?: string;
    count?: number;
    children?: CubCollapsibleMenuItem[];
    disabled?: boolean;
    routerLink?: any;
    routerLinkActiveOptions?: any;
    queryParams?: {
        [key: string]: any;
    };
    command?: (event?: any) => void;
}
interface CubCollapsibleMenuChangeEvent {
    event: Event;
    item: CubCollapsibleMenuItem;
}

declare class CubCollapsibleMenuService {
    private _router;
    private _route;
    refreshMenuEvent: BehaviorSubject<any>;
    refreshUrlEvent: Subject<string>;
    menuItemsSubject: BehaviorSubject<CubCollapsibleMenuItem[]>;
    selectedItemSubject: BehaviorSubject<CubCollapsibleMenuItem | null>;
    expandedItemsSubject: BehaviorSubject<Set<string>>;
    multipleExpandSubject: BehaviorSubject<boolean>;
    refreshMenuEvent$: rxjs.Observable<any>;
    refreshUrlEvent$: rxjs.Observable<string>;
    menuItems$: rxjs.Observable<CubCollapsibleMenuItem[]>;
    selectedItem$: rxjs.Observable<CubCollapsibleMenuItem | null>;
    expandedItems$: rxjs.Observable<Set<string>>;
    multipleExpand$: rxjs.Observable<boolean>;
    constructor(_router: Router, _route: ActivatedRoute);
    refreshMenu(): void;
    refreshUrl(url: string): void;
    setMenuItems(items: CubCollapsibleMenuItem[]): void;
    setMultipleExpand(multiple: boolean): void;
    getMultipleExpand(): boolean;
    selectByCurrentRoute(): void;
    findMenuItemById(id: string): CubCollapsibleMenuItem | null;
    getParentPath(targetId: string): CubCollapsibleMenuItem[];
    findMenuItemByRoute(): CubCollapsibleMenuItem | null;
    selectItem(id: string): void;
    getSelectedItem(): CubCollapsibleMenuItem | null;
    toggleExpanded(id: string): void;
    clearSelection(): void;
    isExpanded(id: string): boolean;
    isSelected(id: string): boolean;
    isActive(id: string): boolean;
    private findItemRecursive;
    private findPathRecursive;
    private findByRouteRecursive;
    private expandParents;
    private getSiblingItems;
    private closeSiblingExpandedItems;
    private closeAllExpandedSubitems;
    private isRouterActive;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubCollapsibleMenuService>;
}

declare class CubCollapsibleMenu implements AfterViewInit, OnChanges, OnDestroy {
    private _changeDetectorRef;
    private _router;
    private CollapsibleMenuService;
    private currentUrl;
    private _destroyed;
    /** 導航選單的項目清單，預設值為 []。 */
    items: CubCollapsibleMenuItem[];
    /** 項目顯示名稱的模板，預設值為 undefined。 */
    itemTemplateRef: TemplateRef<any>;
    /** 點選相同路徑刷新頁面時，重新定向所使用的轉導路徑，預設值為 '/'。 */
    baseRedirectPath: string;
    /** 是否可同時展開多個子選單，預設值為 true。 */
    multiple: boolean;
    /** 是否折疊導航選單，預設值為 true。 */
    collapsed: boolean;
    readonly itemClick: EventEmitter<any>;
    defaultTemplateRef: TemplateRef<any>;
    menuTriggers: CubNavMenuTrigger[];
    get labelTemplateRef(): TemplateRef<any>;
    constructor(_changeDetectorRef: ChangeDetectorRef, _router: Router, CollapsibleMenuService: CubCollapsibleMenuService);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    openSubMenu(menu: CubNavMenuTrigger): void;
    expandedSubMenu(event: Event, item: CubCollapsibleMenuItem): void;
    selectItem(event: Event, item: CubCollapsibleMenuItem): void;
    private refreshPage;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCollapsibleMenu, "cub-collapsible-menu", never, { "items": { "alias": "items"; "required": false; }; "itemTemplateRef": { "alias": "itemTemplateRef"; "required": false; }; "baseRedirectPath": { "alias": "baseRedirectPath"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}

declare const _CubCollapsibleMenuInlineItemMixinBase: cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & {
    new (_elementRef: ElementRef): {
        _elementRef: ElementRef;
    };
};
declare class CubCollapsibleMenuInlineItem extends _CubCollapsibleMenuInlineItemMixinBase implements CanDisable, CanDisableRipple, FocusableOption, AfterViewInit, OnDestroy {
    private CollapsibleMenuService;
    private _focusMonitor;
    private _changeDetectorRef;
    _animationMode: string;
    private _ngZone?;
    _expanded: boolean;
    _selected: boolean;
    private readonly indentCharacter;
    private _destroyed;
    get spacingText(): string;
    item: CubCollapsibleMenuItem;
    level: number;
    itemTemplateRef: TemplateRef<any>;
    constructor(elementRef: ElementRef, CollapsibleMenuService: CubCollapsibleMenuService, _focusMonitor: FocusMonitor, _changeDetectorRef: ChangeDetectorRef, _animationMode: string, _ngZone?: NgZone | undefined);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    isSelected(): boolean;
    isExpanded(): boolean;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    _haltDisabledEvents: (event: Event) => void;
    _KeyboardHaltDisabledEvents: (event: KeyboardEvent) => void;
    _getHostElement(): any;
    _hasHostAttributes(...attributes: string[]): boolean;
    _monitorFocus(): void;
    _stopFocusMonitoring(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenuInlineItem, [null, null, null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCollapsibleMenuInlineItem, "[cubCollapsibleMenuInlineItem]", ["cubCollapsibleMenuInlineItem"], { "disableRipple": { "alias": "disableRipple"; "required": false; }; "item": { "alias": "cubCollapsibleMenuInlineItem"; "required": false; }; "level": { "alias": "cubCollapsibleMenuInlineItemLevel"; "required": false; }; "itemTemplateRef": { "alias": "cubCollapsibleMenuInlineItemTemplateRef"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCollapsibleMenuInlineContent implements OnInit, OnDestroy {
    private CollapsibleMenuService;
    private _changeDetectorRef;
    _animating: boolean;
    _expanded: boolean;
    private _destroyed;
    /** 選單項目，預設值為 undefined。 */
    item: CubCollapsibleMenuItem;
    /** 項目顯示名稱的模板，預設值為 undefined。 */
    itemTemplateRef: TemplateRef<any>;
    /** 展開收合的轉場動畫設定，預設值為 '400ms cubic-bezier(0.86, 0, 0.07, 1)'。 */
    transitionOptions: string;
    /** 項目的巢狀層級，預設值為 1。 */
    level: number;
    get toggleState(): any;
    toggleDone(): void;
    constructor(CollapsibleMenuService: CubCollapsibleMenuService, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    expandedSubMenu(event: Event, item: CubCollapsibleMenuItem): void;
    selectItem(event: Event, item: CubCollapsibleMenuItem): void;
    isExpanded(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenuInlineContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCollapsibleMenuInlineContent, "cub-collapsible-menu-inline-content", never, { "item": { "alias": "item"; "required": false; }; "itemTemplateRef": { "alias": "itemTemplateRef"; "required": false; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCollapsibleMenuOverlayContent implements OnInit {
    private CollapsibleMenuService;
    private _changeDetectorRef;
    menu: CubNavMenu;
    /** 選單項目，預設值為 undefined。 */
    item: CubCollapsibleMenuItem;
    /** 項目顯示名稱的模板，預設值為 undefined。 */
    itemTemplateRef: TemplateRef<any>;
    constructor(CollapsibleMenuService: CubCollapsibleMenuService, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    openSubMenu(menu: CubNavMenuTrigger): void;
    selectItem(event: Event, item: CubCollapsibleMenuItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenuOverlayContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCollapsibleMenuOverlayContent, "cub-collapsible-menu-overlay-content", never, { "item": { "alias": "item"; "required": false; }; "itemTemplateRef": { "alias": "itemTemplateRef"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCollapsibleMenuCount implements OnInit, OnChanges {
    private el;
    private renderer;
    private countElement;
    /** 元件傳入的計數數值，預設值為 0。 */
    count: number;
    /** 元件傳入的計數數值，判斷 0 是否隱藏，預設值為 true。 */
    countHidden: boolean;
    /** 顯示的數值最大值，當超過設定數值時，會以"最大值+"顯示，預設值 99。 */
    max: number | null;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private checkRenderedContent;
    private updateRenderedContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenuCount, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubCollapsibleMenuCount, "[cubCollapsibleMenuCount]", ["CubCollapsibleMenuCount"], { "count": { "alias": "cubCollapsibleMenuCount"; "required": false; }; "countHidden": { "alias": "cubCollapsibleMenuCountHidden"; "required": false; }; "max": { "alias": "cubCollapsibleMenuCountMax"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubCollapsibleMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCollapsibleMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubCollapsibleMenuModule, never, [typeof CubCollapsibleMenu, typeof CubCollapsibleMenuInlineItem, typeof CubCollapsibleMenuInlineContent, typeof CubCollapsibleMenuOverlayContent, typeof CubCollapsibleMenuCount], [typeof CubCollapsibleMenu, typeof CubCollapsibleMenuInlineItem, typeof CubCollapsibleMenuInlineContent, typeof CubCollapsibleMenuOverlayContent, typeof CubCollapsibleMenuCount]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubCollapsibleMenuModule>;
}

export { CubCollapsibleMenu, CubCollapsibleMenuCount, CubCollapsibleMenuInlineContent, CubCollapsibleMenuInlineItem, CubCollapsibleMenuModule, CubCollapsibleMenuOverlayContent, CubCollapsibleMenuService };
export type { CubCollapsibleMenuChangeEvent, CubCollapsibleMenuItem };
