import * as i1 from 'cub-lib-view-rootng/component/common';
import { CubFlexOrientation, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import * as i2 from 'cub-lib-view-rootng/component/label';
import { CubLabel } from 'cub-lib-view-rootng/component/label';
import * as i0 from '@angular/core';

declare class CubContentField {
    /**
       元件方向，預設為 'vertical'。
       */
    orientation: CubFlexOrientation;
    /**
         元件尺寸，預設為 'medium'。
         */
    size: CubThemeSize;
    _labelChildStatic: CubLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubContentField, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubContentField, "cub-content-field", ["cubContentField"], { "orientation": { "alias": "orientation"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, ["_labelChildStatic"], ["cub-label", "*"], true, never>;
}

declare class CubContentFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubContentFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubContentFieldModule, never, [typeof i1.CubCommonModule, typeof i2.CubLabelModule, typeof CubContentField], [typeof i1.CubCommonModule, typeof i2.CubLabelModule, typeof CubContentField]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubContentFieldModule>;
}

export { CubContentField, CubContentFieldModule };
