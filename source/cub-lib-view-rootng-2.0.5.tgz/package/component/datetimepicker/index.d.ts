import * as i0 from '@angular/core';
import { InjectionToken, ElementRef, AfterContentInit, OnDestroy, EventEmitter, OnInit, NgZone, ViewContainerRef, ChangeDetectorRef, OnChanges, SimpleChanges } from '@angular/core';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CubThemeColor, CubThemeSize, CanColor } from 'cub-lib-view-rootng/component/common';
import { Subject, Observable } from 'rxjs';
import * as cub_lib_view_rootng_component_datetimepicker from 'cub-lib-view-rootng/component/datetimepicker';
import { AnimationTriggerMetadata } from '@angular/animations';
import { Overlay, ScrollStrategy } from 'cub-lib-view-rootng/cdk/overlay';
import { Moment } from 'moment';
import { Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { ControlValueAccessor, Validator, AbstractControl, ValidationErrors } from '@angular/forms';
import * as i2 from 'cub-lib-view-rootng/component/form-field';
import { CubFormField } from 'cub-lib-view-rootng/component/form-field';
import { CubIconButton } from 'cub-lib-view-rootng/component/button';
import { Platform } from 'cub-lib-view-rootng/cdk/platform';
import * as i3 from 'cub-lib-view-rootng/component/label';
import * as i4 from 'cub-lib-view-rootng/component/input';
import * as i5 from 'cub-lib-view-rootng/component/input-group';

/** Possible positions for the datetimepicker dropdown along the X axis. */
type CubDatetimepickerDropdownPositionX = 'start' | 'end';
/** Possible positions for the datetimepicker dropdown along the Y axis. */
type CubDatetimepickerDropdownPositionY = 'above' | 'below';
/** Possible types for datetimepicker. */
type CubDatetimepickerType = 'date' | 'time' | 'month' | 'year' | 'datetime';
/** Possible modes for datetimepicker dropdown display. */
type CubDatetimepickerMode = 'auto' | 'portrait' | 'landscape';
/** Possible views for datetimepicker calendar. */
type CubDatetimepickerCalendarView = 'clock' | 'month' | 'year' | 'multi-year';
/** Possible views for datetimepicker clock. */
type CubDatetimepickerClockView = 'hour' | 'minute';
/** Possible types for AM / PM */
type CubDatetimepickerAMPM = 'AM' | 'PM';
type CubDatetimepickerCategory = 'previous' | 'current' | 'next';

declare enum CubDatetimepickerFilterType {
    DATE = 0,
    HOUR = 1,
    MINUTE = 2
}

interface CubDatetimeFormats {
    parse: {
        dateInput?: any;
        monthInput?: any;
        yearInput?: any;
        timeInput?: any;
        datetimeInput?: any;
    };
    display: {
        dateInput: any;
        monthInput: any;
        yearInput?: any;
        timeInput: any;
        datetimeInput: any;
        monthYearLabel: any;
        dateA11yLabel: any;
        monthYearA11yLabel: any;
        popupHeaderDateLabel: any;
    };
}
interface CubCalendarEvent {
    date: any;
    content: any;
}

/**
 * An internal class that represents the data corresponding to a single calendar cell.
 * @docs-private
 */
declare class CubCalendarCell {
    value: number;
    displayValue: string;
    ariaLabel: string;
    enabled: boolean;
    events: CubCalendarEvent[];
    eventsLabel: string;
    category: CubDatetimepickerCategory;
    isToday: boolean;
    isSelected: boolean;
    constructor(value: number, displayValue: string, ariaLabel: string, enabled: boolean, events: CubCalendarEvent[], eventsLabel: string, category: CubDatetimepickerCategory, isToday: boolean, isSelected: boolean);
}
/** Datepicker data that requires internationalization. */
declare class CubDatepickerIntl {
    /**
     * Stream that emits whenever the labels here are changed. Use this to notify
     * components if the labels have changed after initialization.
     */
    readonly changes: Subject<void>;
    /** A label for the calendar popup (used by screen readers). */
    calendarLabel: string;
    /** A label for the button used to open the calendar popup (used by screen readers). */
    openCalendarLabel: string;
    /** Label for the button used to close the calendar popup. */
    closeCalendarLabel: string;
    /** A label for the previous month button (used by screen readers). */
    prevMonthLabel: string;
    /** A label for the next month button (used by screen readers). */
    nextMonthLabel: string;
    /** A label for the previous year button (used by screen readers). */
    prevYearLabel: string;
    /** A label for the next year button (used by screen readers). */
    nextYearLabel: string;
    /** A label for the previous multi-year button (used by screen readers). */
    prevMultiYearLabel: string;
    /** A label for the next multi-year button (used by screen readers). */
    nextMultiYearLabel: string;
    /** A label for the 'switch to month view' button (used by screen readers). */
    switchToMonthViewLabel: string;
    /** A label for the 'switch to year view' button (used by screen readers). */
    switchToMultiYearViewLabel: string;
    /** A label for the first date of a range of dates (used by screen readers). */
    startDateLabel: string;
    /** A label for the last date of a range of dates (used by screen readers). */
    endDateLabel: string;
    /** Formats a range of years (used for visuals). */
    formatYearRange(start: string, end: string): string;
    /** Formats a label for a range of years (used by screen readers). */
    formatYearRangeLabel(start: string, end: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatepickerIntl, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubDatepickerIntl>;
}

/** InjectionToken for datepicker that can be used to override default locale code. */
declare const CUB_DATE_LOCALE: InjectionToken<{}>;
/** @docs-private */
declare function CUB_DATE_LOCALE_FACTORY(): {};
/** Adapts type `D` to be usable as a date by cub-cdk-based components that work with dates. */
declare abstract class CubDateAdapter<D, L = any> {
    /** The locale to use for all dates. */
    protected locale: L;
    protected readonly _localeChanges: Subject<void>;
    /** A stream that emits when the locale changes. */
    readonly localeChanges: Observable<void>;
    /**
     * Gets the year component of the given date.
     * @param date The date to extract the year from.
     * @returns The year component.
     */
    abstract getYear(date: D): number;
    /**
     * Gets the month component of the given date.
     * @param date The date to extract the month from.
     * @returns The month component (0-indexed, 0 = January).
     */
    abstract getMonth(date: D): number;
    /**
     * Gets the date of the month component of the given date.
     * @param date The date to extract the date of the month from.
     * @returns The month component (1-indexed, 1 = first of month).
     */
    abstract getDate(date: D): number;
    /**
     * Gets the day of the week component of the given date.
     * @param date The date to extract the day of the week from.
     * @returns The month component (0-indexed, 0 = Sunday).
     */
    abstract getDayOfWeek(date: D): number;
    /**
     * Gets a list of names for the months.
     * @param style The naming style (e.g. long = 'January', short = 'Jan', narrow = 'J').
     * @returns An ordered list of all month names, starting with January.
     */
    abstract getMonthNames(style: 'long' | 'short' | 'narrow'): string[];
    /**
     * Gets a list of names for the dates of the month.
     * @returns An ordered list of all date of the month names, starting with '1'.
     */
    abstract getDateNames(): string[];
    /**
     * Gets a list of names for the days of the week.
     * @param style The naming style (e.g. long = 'Sunday', short = 'Sun', narrow = 'S').
     * @returns An ordered list of all weekday names, starting with Sunday.
     */
    abstract getDayOfWeekNames(style: 'long' | 'short' | 'narrow'): string[];
    /**
     * Gets the name for the year of the given date.
     * @param date The date to get the year name for.
     * @returns The name of the given year (e.g. '2017').
     */
    abstract getYearName(date: D): string;
    /**
     * Gets the first day of the week.
     * @returns The first day of the week (0-indexed, 0 = Sunday).
     */
    abstract getFirstDayOfWeek(): number;
    /**
     * Gets the number of days in the month of the given date.
     * @param date The date whose month should be checked.
     * @returns The number of days in the month of the given date.
     */
    abstract getNumDaysInMonth(date: D): number;
    /**
     * Clones the given date.
     * @param date The date to clone
     * @returns A new date equal to the given date.
     */
    abstract clone(date: D): D;
    /**
     * Creates a date with the given year, month, and date. Does not allow over/under-flow of the
     * month and date.
     * @param year The full year of the date. (e.g. 89 means the year 89, not the year 1989).
     * @param month The month of the date (0-indexed, 0 = January). Must be an integer 0 - 11.
     * @param date The date of month of the date. Must be an integer 1 - length of the given month.
     * @returns The new date, or null if invalid.
     */
    abstract createDate(year: number, month: number, date: number): D;
    /**
     * Gets today's date.
     * @returns Today's date.
     */
    abstract today(): D;
    /**
     * Parses a date from a user-provided value.
     * @param value The value to parse.
     * @param parseFormat The expected format of the value being parsed
     *     (type is implementation-dependent).
     * @returns The parsed date.
     */
    abstract parse(value: any, parseFormat: any): D | null;
    /**
     * Formats a date as a string according to the given format.
     * @param date The value to format.
     * @param displayFormat The format to use to display the date as a string.
     * @returns The formatted date string.
     */
    abstract format(date: D, displayFormat: any): string;
    /**
     * Adds the given number of years to the date. Years are counted as if flipping 12 pages on the
     * calendar for each year and then finding the closest date in the new month. For example when
     * adding 1 year to Feb 29, 2016, the resulting date will be Feb 28, 2017.
     * @param date The date to add years to.
     * @param years The number of years to add (may be negative).
     * @returns A new date equal to the given one with the specified number of years added.
     */
    abstract addCalendarYears(date: D, years: number): D;
    /**
     * Adds the given number of months to the date. Months are counted as if flipping a page on the
     * calendar for each month and then finding the closest date in the new month. For example when
     * adding 1 month to Jan 31, 2017, the resulting date will be Feb 28, 2017.
     * @param date The date to add months to.
     * @param months The number of months to add (may be negative).
     * @returns A new date equal to the given one with the specified number of months added.
     */
    abstract addCalendarMonths(date: D, months: number): D;
    /**
     * Adds the given number of days to the date. Days are counted as if moving one cell on the
     * calendar for each day.
     * @param date The date to add days to.
     * @param days The number of days to add (may be negative).
     * @returns A new date equal to the given one with the specified number of days added.
     */
    abstract addCalendarDays(date: D, days: number): D;
    /**
     * Gets the RFC 3339 compatible string (https://tools.ietf.org/html/rfc3339) for the given date.
     * This method is used to generate date strings that are compatible with native HTML attributes
     * such as the `min` or `max` attribute of an `<input>`.
     * @param date The date to get the ISO date string for.
     * @returns The ISO date string date string.
     */
    abstract toIso8601(date: D): string;
    /**
     * Checks whether the given object is considered a date instance by this CubDateAdapter.
     * @param obj The object to check
     * @returns Whether the object is a date instance.
     */
    abstract isDateInstance(obj: any): boolean;
    /**
     * Checks whether the given date is valid.
     * @param date The date to check.
     * @returns Whether the date is valid.
     */
    abstract isValid(date: D): boolean;
    /**
     * Gets date instance that is not valid.
     * @returns An invalid date.
     */
    abstract invalid(): D;
    /**
     * Given a potential date object, returns that same date object if it is
     * a valid date, or `null` if it's not a valid date.
     * @param obj The object to check.
     * @returns A date or `null`.
     */
    getValidDateOrNull(obj: unknown): D | null;
    /**
     * Attempts to deserialize a value to a valid date object. This is different from parsing in that
     * deserialize should only accept non-ambiguous, locale-independent formats (e.g. a ISO 8601
     * string). The default implementation does not allow any deserialization, it simply checks that
     * the given value is already a valid date object or null. The `<cub-datetimepicker>` will call this
     * method on all of its `@Input()` properties that accept dates. It is therefore possible to
     * support passing values from your backend directly to these properties by overriding this method
     * to also deserialize the format used by your backend.
     * @param value The value to be deserialized into a date object.
     * @returns The deserialized date object, either a valid date, null if the value can be
     *     deserialized into a null date (e.g. the empty string), or an invalid date.
     */
    deserialize(value: any): D | null;
    /**
     * Sets the locale used for all dates.
     * @param locale The new locale.
     */
    setLocale(locale: L): void;
    /**
     * Compares two dates.
     * @param first The first date to compare.
     * @param second The second date to compare.
     * @returns 0 if the dates are equal, a number less than 0 if the first date is earlier,
     *     a number greater than 0 if the first date is later.
     */
    compareDate(first: D, second: D): number;
    /**
     * Checks if two dates are equal.
     * @param first The first date to check.
     * @param second The second date to check.
     * @returns Whether the two dates are equal.
     *     Null dates are considered equal to other null dates.
     */
    sameDate(first: D | null, second: D | null): boolean;
    /**
     * Clamp the given date between min and max dates.
     * @param date The date to clamp.
     * @param min The minimum value to allow. If null or omitted no min is enforced.
     * @param max The maximum value to allow. If null or omitted no max is enforced.
     * @returns `min` if `date` is less than `min`, `max` if date is greater than `max`,
     *     otherwise `date`.
     */
    clampDate(date: D, min?: D | null, max?: D | null): D;
}

declare abstract class CubDatetimeAdapter<D> extends CubDateAdapter<D> {
    protected _delegate: CubDateAdapter<D>;
    constructor(_delegate: CubDateAdapter<D>);
    abstract getHour(date: D): number;
    abstract getMinute(date: D): number;
    abstract getFirstDateOfMonth(date: D): D;
    abstract isInNextMonth(startDate: D, endDate: D): boolean;
    abstract getHourNames(): string[];
    abstract getMinuteNames(): string[];
    abstract addCalendarHours(date: D, months: number): D;
    abstract addCalendarMinutes(date: D, months: number): D;
    abstract createDatetime(year: number, month: number, date: number, hour: number, minute: number): D;
    getValidDateOrNull(obj: any): D | null;
    clampDate(date: D, min?: D | null, max?: D | null): D;
    compareDatetime(first: D, second: D, respectMinutePart?: boolean): number;
    sameDatetime(first: D | null, second: D | null): boolean;
    sameYear(first: D, second: D): boolean;
    sameDay(first: D, second: D): boolean;
    sameHour(first: D, second: D): boolean;
    sameMinute(first: D, second: D): boolean;
    sameMonthAndYear(first: D | null, second: D | null): boolean;
    clone(date: D): D;
    addCalendarYears(date: D, years: number): D;
    addCalendarMonths(date: D, months: number): D;
    addCalendarDays(date: D, days: number): D;
    getYear(date: D): number;
    getMonth(date: D): number;
    getDate(date: D): number;
    getDayOfWeek(date: D): number;
    getMonthNames(style: any): string[];
    getDateNames(): string[];
    getDayOfWeekNames(style: any): string[];
    getYearName(date: D): string;
    getFirstDayOfWeek(): number;
    getNumDaysInMonth(date: D): number;
    createDate(year: number, month: number, date: number): D;
    today(): D;
    parse(value: any, parseFormat: any): D | null;
    format(date: D, displayFormat: any): string;
    toIso8601(date: D): string;
    isDateInstance(obj: any): boolean;
    isValid(date: D): boolean;
    invalid(): D;
}

declare function CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
declare function isSameMultiYearView<D>(dateAdapter: CubDatetimeAdapter<D>, date1: D, date2: D, minDate: D | null, maxDate: D | null): boolean;
/** @docs-private */
declare function createMissingDateImplError(provider: string): Error;
/** Gets remainder that is non-negative, even if first number is negative */
declare function euclideanModulo(a: number, b: number): number;
/**
 * When the multi-year view is first opened, the active year will be in view.
 * So we compute how many years are between the active year and the *slot* where our
 * "startingYear" will render when paged into view.
 */
declare function getActiveOffset<D>(dateAdapter: CubDatetimeAdapter<D>, activeDate: D, minDate: D | null, maxDate: D | null): number;
/**
 * We pick a "starting" year such that either the maximum year would be at the end
 * or the minimum year would be at the beginning of a page.
 */
declare function getStartingYear<D>(dateAdapter: CubDatetimeAdapter<D>, minDate: D | null, maxDate: D | null): number;
/** Returns whether an event is a touch event. */
declare function isTouchEvent(event: MouseEvent | TouchEvent): event is TouchEvent;
/** Gets the coordinates of a touch or mouse event relative to the document. */
declare function getPointerPositionOnPage(event: MouseEvent | TouchEvent): {
    pageX: number;
    pageY: number;
};

/** Configurable options for {@see CubMomentDateAdapter}. */
interface CubMomentDateAdapterOptions {
    /**
     * When enabled, the dates have to match the format exactly.
     * See https://momentjs.com/guides/#/parsing/strict-mode/.
     */
    strict?: boolean;
    /**
     * Turns the use of utc dates on or off.
     * Changing this will change how components like DatePicker output dates.
     * {@default false}
     */
    useUtc?: boolean;
}
/** InjectionToken for moment date adapter to configure options. */
declare const CUB_MOMENT_DATE_ADAPTER_OPTIONS: InjectionToken<CubMomentDateAdapterOptions>;
/** @docs-private */
declare function CUB_MOMENT_DATE_ADAPTER_OPTIONS_FACTORY(): CubMomentDateAdapterOptions;
declare class CubMomentDateAdapter extends CubDateAdapter<Moment> {
    private _options?;
    private _localeData;
    constructor(dateLocale: string, _options?: CubMomentDateAdapterOptions | undefined);
    setLocale(locale: string): void;
    getYear(date: Moment): number;
    getMonth(date: Moment): number;
    getDate(date: Moment): number;
    getDayOfWeek(date: Moment): number;
    getMonthNames(style: 'long' | 'short' | 'narrow'): string[];
    getDateNames(): string[];
    getDayOfWeekNames(style: 'long' | 'short' | 'narrow'): string[];
    getYearName(date: Moment): string;
    getFirstDayOfWeek(): number;
    getNumDaysInMonth(date: Moment): number;
    clone(date: Moment): Moment;
    createDate(year: number, month: number, date: number): Moment;
    today(): Moment;
    parse(value: any, parseFormat: string | string[]): Moment | null;
    format(date: Moment, displayFormat: string): string;
    addCalendarYears(date: Moment, years: number): Moment;
    addCalendarMonths(date: Moment, months: number): Moment;
    addCalendarDays(date: Moment, days: number): Moment;
    toIso8601(date: Moment): string;
    /**
     * Returns the given value if given a valid Moment or null. Deserializes valid ISO 8601 strings
     * (https://www.ietf.org/rfc/rfc3339.txt) and valid Date objects into valid Moments and empty
     * string into null. Returns an invalid date for all other values.
     */
    deserialize(value: any): Moment | null;
    isDateInstance(obj: any): boolean;
    isValid(date: Moment): boolean;
    invalid(): Moment;
    /** Creates a Moment instance while respecting the current UTC settings. */
    private _createMoment;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMomentDateAdapter, [{ optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubMomentDateAdapter>;
}

declare class CubMomentDatetimeAdapter extends CubDatetimeAdapter<Moment> {
    private _localeData;
    private _useUtc;
    constructor(cubDateLocale: string, cubMomentAdapterOptions: CubMomentDateAdapterOptions, _delegate: CubDateAdapter<Moment>);
    setLocale(locale: string): void;
    deserialize(value: any): Moment | null;
    getHour(date: Moment): number;
    getMinute(date: Moment): number;
    isInNextMonth(startDate: Moment, endDate: Moment): boolean;
    createDatetime(year: number, month: number, date: number, hour: number, minute: number): Moment;
    getFirstDateOfMonth(date: Moment): Moment;
    getHourNames(): string[];
    getMinuteNames(): string[];
    addCalendarHours(date: Moment, hours: number): Moment;
    addCalendarMinutes(date: Moment, minutes: number): Moment;
    private getDateInNextMonth;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMomentDatetimeAdapter, [{ optional: true; }, { optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubMomentDatetimeAdapter>;
}

declare const CLOCK_RADIUS = 50;
declare const CLOCK_INNER_RADIUS = 27.5;
declare const CLOCK_OUTER_RADIUS = 41.25;
declare const CLOCK_TICK_RADIUS = 7.0833;
declare const DAYS_PER_WEEK = 7;
declare const yearsPerPage = 24;
declare const yearsPerRow = 4;
/**
 * Animations used by the Material datepicker.
 * @docs-private
 */
declare const cubDatetimepickerAnimations: {
    readonly transformPanel: AnimationTriggerMetadata;
    readonly fadeInCalendar: AnimationTriggerMetadata;
    readonly slideCalendar: AnimationTriggerMetadata;
};
/** @docs-private */
declare const _CubDatetimepickerContentBase: cub_lib_view_rootng_component_common.Constructor<cub_lib_view_rootng_component_common.CanColor> & cub_lib_view_rootng_component_common.AbstractConstructor<cub_lib_view_rootng_component_common.CanColor> & {
    new (_elementRef: ElementRef): {
        _elementRef: ElementRef;
    };
};
/** Injection token that determines the scroll handling while the calendar is open. */
declare const CUB_DATETIMEPICKER_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
declare const CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY;
};
declare const CUB_DATETIME_FORMATS_CONFIG: {
    parse: {
        dateInput: string;
        monthInput: string;
        yearInput: string;
        timeInput: string;
        datetimeInput: string;
    };
    display: {
        dateInput: string;
        monthInput: string;
        yearInput: string;
        timeInput: string;
        datetimeInput: string;
        monthYearLabel: string;
        dateA11yLabel: string;
        monthYearA11yLabel: string;
        popupHeaderDateLabel: string;
    };
};
declare const CUB_DATETIMEPICKER_FORMATS_PROVIDER: {
    provide: InjectionToken<cub_lib_view_rootng_component_datetimepicker.CubDatetimeFormats>;
    useValue: {
        parse: {
            dateInput: string;
            monthInput: string;
            yearInput: string;
            timeInput: string;
            datetimeInput: string;
        };
        display: {
            dateInput: string;
            monthInput: string;
            yearInput: string;
            timeInput: string;
            datetimeInput: string;
            monthYearLabel: string;
            dateA11yLabel: string;
            monthYearA11yLabel: string;
            popupHeaderDateLabel: string;
        };
    };
};
declare const CUB_DATETIMEPICKER_MOMENT_PROVIDER_LIST: ({
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY;
} | {
    provide: InjectionToken<cub_lib_view_rootng_component_datetimepicker.CubDatetimeFormats>;
    useValue: {
        parse: {
            dateInput: string;
            monthInput: string;
            yearInput: string;
            timeInput: string;
            datetimeInput: string;
        };
        display: {
            dateInput: string;
            monthInput: string;
            yearInput: string;
            timeInput: string;
            datetimeInput: string;
            monthYearLabel: string;
            dateA11yLabel: string;
            monthYearA11yLabel: string;
            popupHeaderDateLabel: string;
        };
    };
} | {
    provide: typeof CubDateAdapter;
    useClass: typeof CubMomentDateAdapter;
    deps: InjectionToken<{}>[];
} | {
    provide: typeof CubDatetimeAdapter;
    useClass: typeof CubMomentDatetimeAdapter;
    deps?: undefined;
})[];

declare const CUB_DATETIMEPICKER_VALUE_ACCESSOR: any;
declare const CUB_DATETIMEPICKER_VALIDATORS: any;
/**
 * An event used for datetimepicker input and change events. We don't always have access to a native
 * input or change event because the event may have been triggered by the user clicking on the
 * calendar popup. For consistency, we always use CubDatetimepickerInputEvent instead.
 */
declare class CubDatetimepickerInputEvent<D> {
    target: CubDatetimepickerInput<D>;
    targetElement: HTMLElement;
    /** The new value for the target datetimepicker input. */
    value: D | null;
    constructor(target: CubDatetimepickerInput<D>, targetElement: HTMLElement);
}
/** Directive used to connect an input to a CubDatetimepicker. */
declare class CubDatetimepickerInput<D> implements AfterContentInit, ControlValueAccessor, OnDestroy, Validator {
    private _elementRef;
    _dateAdapter: CubDatetimeAdapter<D>;
    private _dateFormats;
    private _formField;
    static ngAcceptInputType_disabled: BooleanInput;
    _datetimepicker: CubDatetimepicker<D>;
    /** Emits when the value changes (either due to user input or programmatic change). */
    _valueChange: EventEmitter<D | null>;
    /** Emits when the disabled state has changed */
    _disabledChange: EventEmitter<boolean>;
    _dateFilter: (date: D | null, type: CubDatetimepickerFilterType) => boolean;
    private _datetimepickerSubscription;
    private _localeSubscription;
    private unsubscription;
    /** Whether the last value set on the input was valid. */
    private _lastValueValid;
    private _value;
    private _min;
    private _max;
    private _disabled;
    /** 與此輸入框關聯的選擇器，預設為 undefined。 */
    set datetimepicker(value: CubDatetimepicker<D>);
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    set dateFilter(filter: (date: D | null, type: CubDatetimepickerFilterType) => boolean);
    /** 輸入框的值，預設為 undefined。 */
    get value(): D | null;
    set value(value: D | null);
    /** 最小有效日期時間，預設為 undefined。 */
    get min(): D | null;
    set min(value: D | null);
    /** 最大有效日期時間，預設為 undefined。 */
    get max(): D | null;
    set max(value: D | null);
    /** 是否禁用輸入框，預設為 undefined。 */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** 當此輸入框觸發更改事件時發出通知。 */
    dateChange: EventEmitter<CubDatetimepickerInputEvent<D>>;
    /** 當此輸入框觸發輸入事件時發出通知。 */
    dateInput: EventEmitter<CubDatetimepickerInputEvent<D>>;
    constructor(_elementRef: ElementRef, _dateAdapter: CubDatetimeAdapter<D>, _dateFormats: CubDatetimeFormats, _formField: CubFormField);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    registerOnValidatorChange(fn: () => void): void;
    validate(c: AbstractControl): ValidationErrors | null;
    /**
     * Gets the element that the datetimepicker popup should be connected to.
     * @return The element to connect the popup to.
     */
    getConnectedOverlayOrigin(): ElementRef;
    /** Gets the ID of an element that should be used a description for the calendar overlay. */
    getOverlayLabelId(): string | null;
    writeValue(value: D): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    _onTouched: () => void;
    _onKeydown(event: KeyboardEvent): void;
    _onInput(value: string): void;
    _onChange(): void;
    /** Handles blur events on the input. */
    _onBlur(): void;
    _open(event: Event): void;
    /** The form control validator for whether the input parses. */
    private _parseValidator;
    /** The form control validator for the min date. */
    private _minValidator;
    /** The form control validator for the max date. */
    private _maxValidator;
    /** The form control validator for the date filter. */
    private _filterValidator;
    /** The combined form control validator for this input. */
    private _validator;
    private _cvaOnChange;
    private _validatorOnChange;
    private registerDatetimepicker;
    private getDisplayFormat;
    private getParseFormat;
    /** Formats a value and sets it on the input element. */
    private _formatValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatetimepickerInput<any>, [null, { optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDatetimepickerInput<any>, "input[cubDatetimepickerFor]", ["cubDatetimepickerInput"], { "datetimepicker": { "alias": "cubDatetimepickerFor"; "required": false; }; "dateFilter": { "alias": "cubDatetimepickerFilter"; "required": false; }; "value": { "alias": "value"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "dateChange": "dateChange"; "dateInput": "dateInput"; }, never, never, true, never>;
}

declare class CubDatetimepicker<D> implements OnInit, OnDestroy {
    private _overlay;
    private _ngZone;
    private _viewContainerRef;
    private _scrollStrategy;
    private _dateAdapter;
    private _dir;
    static ngAcceptInputType_multiYearSelector: BooleanInput;
    static ngAcceptInputType_twelvehour: BooleanInput;
    static ngAcceptInputType_preventSameDateTimeSelection: BooleanInput;
    static ngAcceptInputType_disabled: BooleanInput;
    static ngAcceptInputType_opened: BooleanInput;
    static ngAcceptInputType_touchUi: BooleanInput;
    static ngAcceptInputType_restoreFocus: BooleanInput;
    /** The id for the datetimepicker calendar. */
    id: string;
    /** The input element this datetimepicker is associated with. */
    datetimepickerInput: CubDatetimepickerInput<D>;
    /** Emits when the datetimepicker is disabled. */
    _disabledChange: Subject<boolean>;
    _typeChange: Subject<CubDatetimepickerType>;
    /** Whether the clock uses 12 hour format. */
    /** 目前只開放 '24 hour format' Start */
    twelvehour: boolean;
    /** End */
    /** The display mode of datetimepicker. */
    /** 目前只開放 'portrait' Start */
    mode: CubDatetimepickerMode;
    /** End */
    /**
     * Whether the calendar UI is in touch mode. In touch mode the calendar opens in a dialog rather
     * than a popup and elements have more padding to allow for bigger touch targets.
     */
    /** 目前只在 Mobile 開放 'touchUi' Start */
    touchUi: boolean;
    /** End */
    private _document;
    private _validSelected;
    /** A reference to the overlay into which we've rendered the calendar. */
    private _overlayRef;
    /** Reference to the component instance rendered in the overlay. */
    private _componentRef;
    /** The element that was focused before the datetimepicker was opened. */
    private _focusedElementBeforeOpen;
    /** Unique class that will be added to the backdrop so that the test harnesses can look it up. */
    private _backdropHarnessClass;
    private _inputStateChanges;
    private _multiYearSelector;
    private _panelClass;
    private _opened;
    private _color;
    private _startAt;
    private _type;
    private _disabled;
    private _restoreFocus;
    /** The currently selected date. */
    get _selected(): D | null;
    set _selected(value: D | null);
    /** The minimum selectable date. */
    get _minDate(): D | null;
    /** The maximum selectable date. */
    get _maxDate(): D | null;
    get _dateFilter(): (date: D | null, type: CubDatetimepickerFilterType) => boolean;
    /** 是否顯示 multi-year 的畫面，預設為 true。 */
    get multiYearSelector(): boolean;
    set multiYearSelector(value: boolean);
    /** 元件的初始畫面，預設為 'month'。 */
    startView: CubDatetimepickerCalendarView;
    /** 選擇時間時，一次跨幾分鐘，預設為 1。 */
    timeInterval: number;
    /** 是否啟用防止使用者選擇相同的日期時間，預設為 false。 */
    preventSameDateTimeSelection: boolean;
    /** 選擇器的類別樣式，支援與 ngClass 相同的語法，預設為 undefined。 */
    get panelClass(): string | string[];
    set panelClass(value: string | string[]);
    /** 是否選擇器為展開狀態，預設為 false。 */
    get opened(): boolean;
    set opened(value: boolean);
    /** 元件顏色，預設值為 undefined。 */
    get color(): CubThemeColor;
    set color(value: CubThemeColor);
    /** 元件初始顯示的日期時間，預設為 undefined。 */
    get startAt(): D | null;
    set startAt(date: D | null);
    /** 元件的類型，預設為 'date'。 */
    get type(): CubDatetimepickerType;
    set type(value: CubDatetimepickerType);
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 是否禁用展開選擇器，預設為 undefined。 */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** 選擇器在 X 軸上的首選位置，預設為 'start'。 */
    xPosition: CubDatetimepickerDropdownPositionX;
    /** 選擇器在 Y 軸上的首選位置，預設為 'below'。 */
    yPosition: CubDatetimepickerDropdownPositionY;
    /** 是否選擇器收闔時，將焦點恢復到先前獲得焦點的元素上，預設為 true。 */
    get restoreFocus(): boolean;
    set restoreFocus(value: boolean);
    /** 當選定日期時間變更時發出通知。 */
    selectedChange: EventEmitter<D>;
    /** 當選擇器展開時發出通知。 */
    openedStream: EventEmitter<void>;
    /** 當選擇器收闔時發出通知。 */
    closedStream: EventEmitter<void>;
    /** 當元件畫面變更時發出通知。 */
    viewChanged: EventEmitter<CubDatetimepickerCalendarView>;
    onResize(event: any): void;
    constructor(_overlay: Overlay, _ngZone: NgZone, _viewContainerRef: ViewContainerRef, _scrollStrategy: any, _dateAdapter: CubDatetimeAdapter<D>, _dir: Directionality);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Open the calendar. */
    open(): void;
    /** Close the calendar. */
    close(): void;
    _viewChanged(type: CubDatetimepickerCalendarView): void;
    /** Selects the given date */
    _select(date: D): void;
    /**
     * Register an input with this datetimepicker.
     * @param input The datetimepicker input to register with this datetimepicker.
     */
    _registerInput(input: CubDatetimepickerInput<D>): void;
    /**
     * Forwards relevant values from the datetimepicker to the
     * datetimepicker content inside the overlay.
     */
    protected _forwardContentValues(instance: CubDatetimepickerContent<D>): void;
    /** Opens the overlay with the calendar. */
    private _openOverlay;
    /** Destroys the current overlay. */
    private _destroyOverlay;
    /** Gets a position strategy that will open the calendar as a dropdown. */
    private _getDialogStrategy;
    /** Gets a position strategy that will open the calendar as a dropdown. */
    private _getDropdownStrategy;
    /**
     * Sets the positions of the datetimepicker in dropdown mode based on the current configuration.
     */
    private _setConnectedPositions;
    /** Gets an observable that will emit when the overlay is supposed to be closed. */
    private _getCloseStream;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatetimepicker<any>, [null, null, null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDatetimepicker<any>, "cub-datetimepicker", ["cubDatetimepicker"], { "multiYearSelector": { "alias": "multiYearSelector"; "required": false; }; "startView": { "alias": "startView"; "required": false; }; "timeInterval": { "alias": "timeInterval"; "required": false; }; "preventSameDateTimeSelection": { "alias": "preventSameDateTimeSelection"; "required": false; }; "panelClass": { "alias": "panelClass"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "color": { "alias": "color"; "required": false; }; "startAt": { "alias": "startAt"; "required": false; }; "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "xPosition": { "alias": "xPosition"; "required": false; }; "yPosition": { "alias": "yPosition"; "required": false; }; "restoreFocus": { "alias": "restoreFocus"; "required": false; }; }, { "selectedChange": "selectedChange"; "openedStream": "opened"; "closedStream": "closed"; "viewChanged": "viewChanged"; }, never, never, true, never>;
}

/**
 * Component used as the content for the datetimepicker dialog and popup. We use this instead of
 * using CubCalendar directly as the content so we can control the initial focus. This also gives us
 * a place to put additional features of the popup that are not part of the calendar itself in the
 * future. (e.g. confirmation buttons).
 * @docs-private
 */
declare class CubDatetimepickerContent<D> extends _CubDatetimepickerContentBase implements OnInit, OnDestroy, CanColor {
    private _changeDetectorRef;
    datetimepicker: CubDatetimepicker<D>;
    /** Whether the datetimepicker is above or below the input. */
    _isAbove: boolean;
    /** Current state of the animation. */
    _animationState: 'enter-dropdown' | 'enter-dialog' | 'void';
    /** Emits when an animation has finished. */
    readonly _animationDone: Subject<void>;
    _calendar: CubCalendar<D>;
    constructor(elementRef: ElementRef, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    _startExitAnimation(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatetimepickerContent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDatetimepickerContent<any>, "cub-datetimepicker-content", never, { "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * A calendar that is used as part of the datetimepicker.
 * @docs-private
 */
declare class CubCalendar<D> implements AfterContentInit, OnDestroy {
    private _elementRef;
    private _intl;
    private _ngZone;
    private _adapter;
    private _datetimepickerContent;
    private _dateFormats;
    static ngAcceptInputType_multiYearSelector: BooleanInput;
    static ngAcceptInputType_twelvehour: BooleanInput;
    _clockView: CubDatetimepickerClockView;
    _calendarState: string;
    _AMPM: CubDatetimepickerAMPM;
    _currentView: CubDatetimepickerCalendarView;
    private _intlChanges;
    private _clampedActiveDate;
    private _multiYearSelector;
    private _twelvehour;
    private _type;
    private _startAt;
    private _selected;
    private _minDate;
    private _maxDate;
    /**
     * The current active date. This determines which time period is shown and which date is
     * highlighted when using keyboard navigation.
     */
    get _activeDate(): D;
    set _activeDate(value: D);
    /** Whether the calendar is in month view. */
    get currentView(): CubDatetimepickerCalendarView;
    set currentView(view: CubDatetimepickerCalendarView);
    /** The label for the current calendar view. */
    get _yearLabel(): string;
    get _monthYearLabel(): string;
    get _dateLabel(): string;
    get _hoursLabel(): string;
    get _minutesLabel(): string;
    get _ariaLabelNext(): string;
    get _ariaLabelPrev(): string;
    get isInline(): boolean;
    /** 事件清單，預設為 []。 */
    events: CubCalendarEvent[];
    /** 是否顯示 multi-year 的畫面，預設為 true。 */
    get multiYearSelector(): boolean;
    set multiYearSelector(value: boolean);
    /** 是否時間選擇為 12 小時制，預設為 false。 */
    get twelvehour(): boolean;
    set twelvehour(value: boolean);
    /** 元件的初始畫面，預設為 'month'。 */
    startView: CubDatetimepickerCalendarView;
    /** 選擇時間時，一次跨幾分鐘，預設為 1。 */
    timeInterval: number;
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    dateFilter: (date: D, type: CubDatetimepickerFilterType) => boolean;
    /** 是否啟用防止使用者選擇相同的日期時間，預設為 false。 */
    preventSameDateTimeSelection: boolean;
    /** 元件的類型，預設為 'date'。 */
    get type(): CubDatetimepickerType;
    set type(value: CubDatetimepickerType);
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 元件初始顯示的日期時間，預設為 undefined。 */
    get startAt(): D | null;
    set startAt(value: D | null);
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected(): D | null;
    set selected(value: D | null);
    /** 最小可選擇的日期時間，預設為 undefined。 */
    get minDate(): D | null;
    set minDate(value: D | null);
    /** 最大可選擇的日期時間，預設為 undefined。 */
    get maxDate(): D | null;
    set maxDate(value: D | null);
    /** 當選定日期時間變更時發出通知。 */
    selectedChange: EventEmitter<D>;
    /** 當元件畫面變更時發出通知。 */
    viewChanged: EventEmitter<CubDatetimepickerCalendarView>;
    /** 當使用者選擇日期時間時發出通知。 */
    userSelection: EventEmitter<void>;
    constructor(_elementRef: ElementRef, _intl: CubDatepickerIntl, _ngZone: NgZone, _adapter: CubDatetimeAdapter<D>, _datetimepickerContent: CubDatetimepickerContent<D>, _dateFormats: CubDatetimeFormats, changeDetectorRef: ChangeDetectorRef);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Date filter for the month and year views. */
    _dateFilterForViews: (date: D) => boolean;
    _userSelected(): void;
    /** Handles date selection in the month view. */
    _dateSelected(date: D): void;
    /** Handles month selection in the year view. */
    _monthSelected(month: D): void;
    /** Handles year selection in the multi year view. */
    _yearSelected(year: D): void;
    _timeSelected(date: D): void;
    _onActiveDateChange(date: D): void;
    _updateDate(date: D): D;
    _selectAMPM(date: D): void;
    _ampmClicked(source: CubDatetimepickerAMPM): void;
    _yearClicked(): void;
    _handleYearKeydown(event: Event): void;
    _monthClicked(): void;
    _handleMonthKeydown(event: Event): void;
    _dateClicked(): void;
    _handleDateKeydown(event: Event): void;
    _hoursClicked(): void;
    _handleHoursKeydown(event: Event): void;
    _minutesClicked(): void;
    _handleMinutesKeydown(event: Event): void;
    /** Handles user clicks on the previous button. */
    _previousClicked(): void;
    /** Handles user clicks on the next button. */
    _nextClicked(): void;
    /** Whether the previous period button is enabled. */
    _previousEnabled(): boolean;
    /** Whether the next period button is enabled. */
    _nextEnabled(): boolean;
    /** Handles keydown events on the calendar body. */
    _handleCalendarBodyKeydown(event: KeyboardEvent): void;
    _calendarStateDone(): void;
    /** Whether the two dates represent the same view in the current view mode (month or year). */
    private _isSameView;
    /** Handles keydown events on the calendar body when calendar is in month view. */
    private _handleCalendarBodyKeydownInMonthView;
    /** Handles keydown events on the calendar body when calendar is in year view. */
    private _handleCalendarBodyKeydownInYearView;
    /** Handles keydown events on the calendar body when calendar is in multi-year view. */
    private _handleCalendarBodyKeydownInMultiYearView;
    /** Handles keydown events on the calendar body when calendar is in month view. */
    private _handleCalendarBodyKeydownInClockView;
    /**
     * Determine the date for the month that comes before the given month in the same column in the
     * calendar table.
     */
    private _prevMonthInSameCol;
    /**
     * Determine the date for the month that comes after the given month in the same column in the
     * calendar table.
     */
    private _nextMonthInSameCol;
    private calendarState;
    private _2digit;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCalendar<any>, [null, null, null, { optional: true; }, { optional: true; }, { optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCalendar<any>, "cub-calendar", ["cubCalendar"], { "events": { "alias": "events"; "required": false; }; "multiYearSelector": { "alias": "multiYearSelector"; "required": false; }; "twelvehour": { "alias": "twelvehour"; "required": false; }; "startView": { "alias": "startView"; "required": false; }; "timeInterval": { "alias": "timeInterval"; "required": false; }; "dateFilter": { "alias": "dateFilter"; "required": false; }; "preventSameDateTimeSelection": { "alias": "preventSameDateTimeSelection"; "required": false; }; "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "startAt": { "alias": "startAt"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; }, { "selectedChange": "selectedChange"; "viewChanged": "viewChanged"; "userSelection": "userSelection"; }, never, never, true, never>;
}

/**
 * An internal component used to display calendar data in a table.
 * @docs-private
 */
declare class CubCalendarBody {
    /** The number of blank cells to put at the beginning for the first row. */
    get _firstRowOffset(): number;
    /** 表格的標籤，預設為 undefined。 */
    label: string;
    /** 表格中顯示的儲存格，預設為 undefined。 */
    rows: CubCalendarCell[][];
    /** 當日的日期時間，預設為 undefined。 */
    todayValue: number;
    /** 當前選中的日期時間，預設為 undefined。 */
    selectedValue: number;
    /** 第一行標籤所需的最小空閒儲存格數，預設為 undefined。 */
    labelMinRequiredCells: number;
    /** 表格的列數，預設為 7。 */
    numCols: number;
    /** 是否允許選擇已停用的儲存格，預設為 false。 */
    allowDisabledSelection: boolean;
    /** 表格中 Activ 狀態的儲存格編號，預設為 0。 */
    activeCell: number;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 當選定日期時間變更時發出通知。 */
    selectedValueChange: EventEmitter<CubCalendarCell>;
    _cellClicked(cell: CubCalendarCell): void;
    _isActiveCell(rowIndex: number, colIndex: number): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubCalendarBody, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubCalendarBody, "[cub-calendar-body]", ["cubCalendarBody"], { "label": { "alias": "label"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "todayValue": { "alias": "todayValue"; "required": false; }; "selectedValue": { "alias": "selectedValue"; "required": false; }; "labelMinRequiredCells": { "alias": "labelMinRequiredCells"; "required": false; }; "numCols": { "alias": "numCols"; "required": false; }; "allowDisabledSelection": { "alias": "allowDisabledSelection"; "required": false; }; "activeCell": { "alias": "activeCell"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "selectedValueChange": "selectedValueChange"; }, never, never, true, never>;
}

/**
 * A clock that is used as part of the datetimepicker.
 * @docs-private
 */
declare class CubClock<D> implements AfterContentInit, OnDestroy, OnChanges {
    private _elementRef;
    private _adapter;
    private _changeDetectorRef;
    private _document;
    static ngAcceptInputType_twelvehour: BooleanInput;
    /** Whether the clock is in hour view. */
    _hourView: boolean;
    _hours: any[];
    _minutes: any[];
    _selectedHour: number;
    _selectedMinute: number;
    _handOnLevel: boolean;
    private _timeChanged;
    private _activeDate;
    private _selected;
    private _minDate;
    private _maxDate;
    get _hand(): {
        height: string;
        marginTop: string;
        transform: string;
    };
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    dateFilter: (date: D, type: CubDatetimepickerFilterType) => boolean;
    /** 選擇時間時，一次跨幾分鐘，預設為 1。 */
    interval: number;
    /** 是否時間選擇為 12 小時制，預設為 false。 */
    twelvehour: boolean;
    /** 當前時間為 AM 或是 PM，預設為 'AM'。 */
    AMPM: CubDatetimepickerAMPM;
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate(): D;
    set activeDate(value: D);
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected(): D | null;
    set selected(value: D | null);
    /** 最小可選擇的日期時間，預設為 undefined。 */
    get minDate(): D | null;
    set minDate(value: D | null);
    /** 最大可選擇的日期時間，預設為 undefined。 */
    get maxDate(): D | null;
    set maxDate(value: D | null);
    /** 元件的初始畫面，預設為 'month'。 */
    set startView(value: CubDatetimepickerClockView);
    /** 當選定日期時間變更時發出通知。 */
    selectedChange: EventEmitter<D>;
    /** 當日期時間為 Active 狀態時發出通知。 */
    activeDateChange: EventEmitter<D>;
    /** 當使用者選擇日期時間時發出通知。 */
    readonly userSelection: EventEmitter<void>;
    constructor(_elementRef: ElementRef, _adapter: CubDatetimeAdapter<D>, _changeDetectorRef: ChangeDetectorRef, _document: any);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    ngOnChanges(): void;
    getHandOnLevel(): void;
    /** Called when the user has put their pointer down on the clock. */
    private _pointerDown;
    /**
     * Called when the user has moved their pointer after
     * starting to drag. Bound on the document level.
     */
    private _pointerMove;
    /** Called when the user has lifted their pointer. Bound on the document level. */
    private _pointerUp;
    /** Binds our global move and end events. */
    private _bindGlobalEvents;
    /** Removes any global event listeners that we may have added. */
    private _removeGlobalEvents;
    /** Initializes this clock view. */
    private _init;
    /**
     * Set Time
     * @param event
     */
    private setTime;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubClock<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubClock<any>, "cub-clock", ["cubClock"], { "size": { "alias": "size"; "required": false; }; "dateFilter": { "alias": "dateFilter"; "required": false; }; "interval": { "alias": "interval"; "required": false; }; "twelvehour": { "alias": "twelvehour"; "required": false; }; "AMPM": { "alias": "AMPM"; "required": false; }; "activeDate": { "alias": "activeDate"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; "startView": { "alias": "startView"; "required": false; }; }, { "selectedChange": "selectedChange"; "activeDateChange": "activeDateChange"; "userSelection": "userSelection"; }, never, never, true, never>;
}

/** Can be used to override the icon of a `cubDatetimepickerToggle`. */
declare class CubDatetimepickerToggleIcon {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatetimepickerToggleIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDatetimepickerToggleIcon, "[cubDatetimepickerToggleIcon]", never, {}, {}, never, never, true, never>;
}

declare class CubDatetimepickerToggle<D> implements OnInit, AfterContentInit, OnChanges, OnDestroy {
    _intl: CubDatepickerIntl;
    private _changeDetectorRef;
    static ngAcceptInputType_disabled: BooleanInput;
    static ngAcceptInputType_disableRipple: BooleanInput;
    datetimepickerType: CubDatetimepickerType;
    private unsubscription;
    private _stateChanges;
    private _disabled;
    /** 切換選擇器收闔的按鈕，預設為 undefined。 */
    datetimepicker: CubDatetimepicker<D>;
    /** 切換按鈕的 Tabindex，預設為 undefined。 */
    tabIndex: number;
    /** 是否禁用切換按鈕，預設為 undefined。 */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** 是否禁用切換按鈕上的漣漪，預設為 undefined。 */
    disableRipple: boolean;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** Custom icon set by the consumer. */
    _customIcon: CubDatetimepickerToggleIcon;
    /** Underlying button element. */
    _button: CubIconButton;
    constructor(_intl: CubDatepickerIntl, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    _open(event: Event): void;
    private _watchStateChanges;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatetimepickerToggle<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDatetimepickerToggle<any>, "cub-datetimepicker-toggle", ["cubDatetimepickerToggle"], { "datetimepicker": { "alias": "for"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, ["_customIcon"], ["[cubDatetimepickerToggleIcon]"], true, never>;
}

/**
 * An internal component used to display a single month in the datetimepicker.
 * @docs-private
 */
declare class CubMonthView<D> implements AfterContentInit {
    _adapter: CubDatetimeAdapter<D>;
    private _dateFormats;
    numRows: number;
    /** Grid of calendar cells representing the dates of the month. */
    _weeks: CubCalendarCell[][];
    /** The number of blank cells in the first row before the 1st of the month. */
    _firstWeekOffset: number;
    _lastWeekOffset: number;
    /**
     * The date of the month that the currently selected Date falls on.
     * Null if the currently selected Date is in another month.
     */
    _selectedDate: number | null;
    /** The date of the month that today falls on. Null if today is in another month. */
    _todayDate: number | null;
    /** The names of the weekdays. */
    _weekdays: {
        long: string;
        narrow: string;
    }[];
    _calendarState: string;
    private _activeDate;
    private _selected;
    /** 事件清單，預設為 []。 */
    events: CubCalendarEvent[];
    /** 元件的類型，預設為 'date'。 */
    type: CubDatetimepickerType;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    dateFilter: (date: D) => boolean;
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate(): D;
    set activeDate(value: D);
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected(): D;
    set selected(value: D);
    /** 是否為內嵌模式，預設為 false。 */
    isInline: boolean;
    /** 當選定日期時間變更時發出通知。 */
    selectedChange: EventEmitter<D>;
    /** 當使用者選擇日期時間時發出通知。 */
    readonly userSelection: EventEmitter<void>;
    constructor(_adapter: CubDatetimeAdapter<D>, _dateFormats: CubDatetimeFormats);
    ngAfterContentInit(): void;
    /** Handles when a new date is selected. */
    _dateSelected(cell: CubCalendarCell): void;
    _calendarStateDone(): void;
    private calendarState;
    /** Initializes this month view. */
    private _init;
    /** Creates MdCalendarCells for the dates in this month. */
    private _createWeekCells;
    /**
     * Gets the date in this month that the given Date falls on.
     * Returns null if the given Date is in another month.
     */
    private _getDateInCurrentMonth;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMonthView<any>, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubMonthView<any>, "cub-month-view", ["cubMonthView"], { "events": { "alias": "events"; "required": false; }; "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dateFilter": { "alias": "dateFilter"; "required": false; }; "activeDate": { "alias": "activeDate"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "isInline": { "alias": "isInline"; "required": false; }; }, { "selectedChange": "selectedChange"; "userSelection": "userSelection"; }, never, never, true, never>;
}

/**
 * An internal component used to display multiple years in the datetimepicker.
 * @docs-private
 */
declare class CubMultiYearView<D> implements AfterContentInit {
    _adapter: CubDatetimeAdapter<D>;
    private _dateFormats;
    /** Grid of calendar cells representing the years in the range. */
    _years: CubCalendarCell[][];
    /** The label for this year range (e.g. "2000-2020"). */
    _yearLabel: string;
    /** The year in this range that today falls on. Null if today is in a different range. */
    _todayYear: number;
    /**
     * The year in this range that the selected Date falls on.
     * Null if the selected Date is in a different range.
     */
    _selectedYear: number | null;
    _calendarState: string;
    private _activeDate;
    private _selected;
    private _minDate;
    private _maxDate;
    /** 元件的類型，預設為 'date'。 */
    type: CubDatetimepickerType;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    dateFilter: (date: D) => boolean;
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate(): D;
    set activeDate(value: D);
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected(): D;
    set selected(value: D);
    /** 最小可選擇的日期時間，預設為 undefined。 */
    get minDate(): D | null;
    set minDate(value: D | null);
    /** 最大可選擇的日期時間，預設為 undefined。 */
    get maxDate(): D | null;
    set maxDate(value: D | null);
    /** 當選定日期時間變更時發出通知。 */
    selectedChange: EventEmitter<D>;
    /** 當使用者選擇日期時間時發出通知。 */
    readonly userSelection: EventEmitter<void>;
    constructor(_adapter: CubDatetimeAdapter<D>, _dateFormats: CubDatetimeFormats);
    ngAfterContentInit(): void;
    /** Handles when a new year is selected. */
    _yearSelected(cell: CubCalendarCell): void;
    _getActiveCell(): number;
    _calendarStateDone(): void;
    /** Initializes this year view. */
    private _init;
    /** Creates an CubCalendarCell for the given year. */
    private _createCellForYear;
    /** Whether the given year is enabled. */
    private _shouldEnableYear;
    /**
     * Gets the year in this years range that the given Date falls on.
     * Returns null if the given Date is not in this range.
     */
    private _getYearInCurrentRange;
    /**
     * Validate if the current year is in the current range
     * Returns true if is in range else returns false
     */
    private _isInRange;
    /**
     * @param obj The object to check.
     * @returns The given object if it is both a date instance and valid, otherwise null.
     */
    private _getValidDateOrNull;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMultiYearView<any>, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubMultiYearView<any>, "cub-multi-year-view", ["cubMultiYearView"], { "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dateFilter": { "alias": "dateFilter"; "required": false; }; "activeDate": { "alias": "activeDate"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; }, { "selectedChange": "selectedChange"; "userSelection": "userSelection"; }, never, never, true, never>;
}

/**
 * An internal component used to display a single year in the datetimepicker.
 * @docs-private
 */
declare class CubYearView<D> implements AfterContentInit {
    _adapter: CubDatetimeAdapter<D>;
    private _dateFormats;
    /** Grid of calendar cells representing the months of the year. */
    _months: CubCalendarCell[][];
    /** The label for this year (e.g. "2017"). */
    _yearLabel: string;
    /** The month in this year that today falls on. Null if today is in a different year. */
    _todayMonth: number | null;
    /**
     * The month in this year that the selected Date falls on.
     * Null if the selected Date is in a different year.
     */
    _selectedMonth: number | null;
    _calendarState: string;
    private _activeDate;
    private _selected;
    /** 元件的類型，預設為 'date'。 */
    type: CubDatetimepickerType;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    dateFilter: (date: D) => boolean;
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate(): D;
    set activeDate(value: D);
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected(): D;
    set selected(value: D);
    /** 當選定日期時間變更時發出通知。 */
    selectedChange: EventEmitter<D>;
    /** 當使用者選擇日期時間時發出通知。 */
    readonly userSelection: EventEmitter<void>;
    constructor(_adapter: CubDatetimeAdapter<D>, _dateFormats: CubDatetimeFormats);
    ngAfterContentInit(): void;
    /** Handles when a new month is selected. */
    _monthSelected(cell: CubCalendarCell): void;
    _calendarStateDone(): void;
    private calendarState;
    /** Initializes this month view. */
    private _init;
    /**
     * Gets the month in this year that the given Date falls on.
     * Returns null if the given Date is in another year.
     */
    private _getMonthInCurrentYear;
    /** Creates an MdCalendarCell for the given month. */
    private _createCellForMonth;
    /** Whether the given month is enabled. */
    private _isMonthEnabled;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubYearView<any>, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubYearView<any>, "cub-year-view", ["cubYearView"], { "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dateFilter": { "alias": "dateFilter"; "required": false; }; "activeDate": { "alias": "activeDate"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, { "selectedChange": "selectedChange"; "userSelection": "userSelection"; }, never, never, true, never>;
}

type CubDateFormats = {
    parse: {
        dateInput: any;
    };
    display: {
        dateInput: any;
        monthLabel?: any;
        monthYearLabel: any;
        dateA11yLabel: any;
        monthYearA11yLabel: any;
    };
};
declare const CUB_DATE_FORMATS: InjectionToken<CubDateFormats>;

declare const CUB_DATETIME_FORMATS: InjectionToken<CubDatetimeFormats>;

declare const CUB_MOMENT_DATE_FORMATS: CubDateFormats;

declare const CUB_MOMENT_DATETIME_FORMATS: CubDatetimeFormats;

/** Adapts the native JS Date for use with cub-cdk-based components that work with dates. */
declare class CubNativeDateAdapter extends CubDateAdapter<Date> {
    /**
     * @deprecated No longer being used. To be removed.
     * @breaking-change 14.0.0
     */
    useUtcForDisplay: boolean;
    constructor(cubDateLocale: string, 
    /**
     * @deprecated No longer being used. To be removed.
     * @breaking-change 14.0.0
     */
    _platform?: Platform);
    getYear(date: Date): number;
    getMonth(date: Date): number;
    getDate(date: Date): number;
    getDayOfWeek(date: Date): number;
    getMonthNames(style: 'long' | 'short' | 'narrow'): string[];
    getDateNames(): string[];
    getDayOfWeekNames(style: 'long' | 'short' | 'narrow'): string[];
    getYearName(date: Date): string;
    getFirstDayOfWeek(): number;
    getNumDaysInMonth(date: Date): number;
    clone(date: Date): Date;
    createDate(year: number, month: number, date: number): Date;
    today(): Date;
    parse(value: any, parseFormat?: any): Date | null;
    format(date: Date, displayFormat: Object): string;
    addCalendarYears(date: Date, years: number): Date;
    addCalendarMonths(date: Date, months: number): Date;
    addCalendarDays(date: Date, days: number): Date;
    toIso8601(date: Date): string;
    /**
     * Returns the given value if given a valid Date or null. Deserializes valid ISO 8601 strings
     * (https://www.ietf.org/rfc/rfc3339.txt) into valid Dates and empty string into null. Returns an
     * invalid date for all other values.
     */
    deserialize(value: any): Date | null;
    isDateInstance(obj: any): obj is Date;
    isValid(date: Date): boolean;
    invalid(): Date;
    /** Creates a date but allows the month and date to overflow. */
    private _createDateWithOverflow;
    /**
     * Pads a number to make it two digits.
     * @param n The number to pad.
     * @returns The padded number.
     */
    private _2digit;
    /**
     * When converting Date object to string, javascript built-in functions may return wrong
     * results because it applies its internal DST rules. The DST rules around the world change
     * very frequently, and the current valid rule is not always valid in previous years though.
     * We work around this problem building a new Date object which has its internal UTC
     * representation with the local date and time.
     * @param dtf Intl.DateTimeFormat object, containing the desired string format. It must have
     *    timeZone set to 'utc' to work fine.
     * @param date Date from which we want to get the string representation according to dtf
     * @returns A Date object with its UTC representation based on the passed in date info
     */
    private _format;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNativeDateAdapter, [{ optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubNativeDateAdapter>;
}

declare const CUB_NATIVE_DATE_FORMATS: CubDateFormats;

declare class CubNativeDatetimeAdapter extends CubDatetimeAdapter<Date> {
    constructor(cubDateLocale: string, _delegate: CubDateAdapter<Date>);
    clone(date: Date): Date;
    addCalendarYears(date: Date, years: number): Date;
    addCalendarMonths(date: Date, months: number): Date;
    addCalendarDays(date: Date, days: number): Date;
    toIso8601(date: Date): string;
    getHour(date: Date): number;
    getMinute(date: Date): number;
    isInNextMonth(startDate: Date, endDate: Date): boolean;
    createDatetime(year: number, month: number, date: number, hour: number, minute: number): Date;
    getFirstDateOfMonth(date: Date): Date;
    getHourNames(): string[];
    getMinuteNames(): string[];
    addCalendarHours(date: Date, hours: number): Date;
    addCalendarMinutes(date: Date, minutes: number): Date;
    private getDateInNextMonth;
    /**
     * Strip out unicode LTR and RTL characters. Edge and IE insert these into formatted dates while
     * other browsers do not. We remove them to make output consistent and because they interfere with
     * date parsing.
     * @param str The string to strip direction characters from.
     * @returns The stripped string.
     */
    private _stripDirectionalityCharacters;
    /**
     * Pads a number to make it two digits.
     * @param n The number to pad.
     * @returns The padded number.
     */
    private _2digit;
    /** Creates a date but allows the month and date to overflow. */
    private _createDateWithOverflow;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNativeDatetimeAdapter, [{ optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubNativeDatetimeAdapter>;
}

declare const CUB_NATIVE_DATETIME_FORMATS: CubDatetimeFormats;

declare class CubDatetimepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDatetimepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubDatetimepickerModule, never, [typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof i2.CubFormFieldModule, typeof i3.CubLabelModule, typeof i4.CubInputModule, typeof i5.CubInputGroupModule, typeof CubCalendar, typeof CubCalendarBody, typeof CubClock, typeof CubDatetimepicker, typeof CubDatetimepickerToggle, typeof CubDatetimepickerToggleIcon, typeof CubDatetimepickerInput, typeof CubDatetimepickerContent, typeof CubMonthView, typeof CubYearView, typeof CubMultiYearView], [typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof i2.CubFormFieldModule, typeof i3.CubLabelModule, typeof i4.CubInputModule, typeof i5.CubInputGroupModule, typeof CubCalendar, typeof CubCalendarBody, typeof CubClock, typeof CubDatetimepicker, typeof CubDatetimepickerToggle, typeof CubDatetimepickerToggleIcon, typeof CubDatetimepickerInput, typeof CubDatetimepickerContent, typeof CubMonthView, typeof CubYearView, typeof CubMultiYearView]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubDatetimepickerModule>;
}
declare class NativeDateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeDateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeDateModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeDateModule>;
}
declare class CubNativeDateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNativeDateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubNativeDateModule, never, [typeof NativeDateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubNativeDateModule>;
}
declare class MomentDateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MomentDateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MomentDateModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MomentDateModule>;
}
declare class CubMomentDateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMomentDateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubMomentDateModule, never, [typeof MomentDateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubMomentDateModule>;
}
declare class NativeDatetimeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeDatetimeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeDatetimeModule, never, [typeof NativeDateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeDatetimeModule>;
}
declare class CubNativeDatetimeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNativeDatetimeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubNativeDatetimeModule, never, [typeof CubNativeDateModule, typeof NativeDatetimeModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubNativeDatetimeModule>;
}
declare class MomentDatetimeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MomentDatetimeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MomentDatetimeModule, never, [typeof MomentDateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MomentDatetimeModule>;
}
declare class CubMomentDatetimeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMomentDatetimeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubMomentDatetimeModule, never, [typeof CubMomentDateModule, typeof MomentDatetimeModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubMomentDatetimeModule>;
}

export { CLOCK_INNER_RADIUS, CLOCK_OUTER_RADIUS, CLOCK_RADIUS, CLOCK_TICK_RADIUS, CUB_DATETIMEPICKER_FORMATS_PROVIDER, CUB_DATETIMEPICKER_MOMENT_PROVIDER_LIST, CUB_DATETIMEPICKER_SCROLL_STRATEGY, CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY, CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER, CUB_DATETIMEPICKER_VALIDATORS, CUB_DATETIMEPICKER_VALUE_ACCESSOR, CUB_DATETIME_FORMATS, CUB_DATETIME_FORMATS_CONFIG, CUB_DATE_FORMATS, CUB_DATE_LOCALE, CUB_DATE_LOCALE_FACTORY, CUB_MOMENT_DATETIME_FORMATS, CUB_MOMENT_DATE_ADAPTER_OPTIONS, CUB_MOMENT_DATE_ADAPTER_OPTIONS_FACTORY, CUB_MOMENT_DATE_FORMATS, CUB_NATIVE_DATETIME_FORMATS, CUB_NATIVE_DATE_FORMATS, CubCalendar, CubCalendarBody, CubCalendarCell, CubClock, CubDateAdapter, CubDatepickerIntl, CubDatetimeAdapter, CubDatetimepicker, CubDatetimepickerContent, CubDatetimepickerFilterType, CubDatetimepickerInput, CubDatetimepickerInputEvent, CubDatetimepickerModule, CubDatetimepickerToggle, CubDatetimepickerToggleIcon, CubMomentDateAdapter, CubMomentDateModule, CubMomentDatetimeAdapter, CubMomentDatetimeModule, CubMonthView, CubMultiYearView, CubNativeDateAdapter, CubNativeDateModule, CubNativeDatetimeAdapter, CubNativeDatetimeModule, CubYearView, DAYS_PER_WEEK, MomentDateModule, MomentDatetimeModule, NativeDateModule, NativeDatetimeModule, _CubDatetimepickerContentBase, createMissingDateImplError, cubDatetimepickerAnimations, euclideanModulo, getActiveOffset, getPointerPositionOnPage, getStartingYear, isSameMultiYearView, isTouchEvent, yearsPerPage, yearsPerRow };
export type { CubCalendarEvent, CubDateFormats, CubDatetimeFormats, CubDatetimepickerAMPM, CubDatetimepickerCalendarView, CubDatetimepickerCategory, CubDatetimepickerClockView, CubDatetimepickerDropdownPositionX, CubDatetimepickerDropdownPositionY, CubDatetimepickerMode, CubDatetimepickerType, CubMomentDateAdapterOptions };
