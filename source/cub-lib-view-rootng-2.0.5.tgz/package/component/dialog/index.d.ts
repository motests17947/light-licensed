import * as cub_lib_view_rootng_cdk_dialog from 'cub-lib-view-rootng/cdk/dialog';
import { CubCdkDialogContainer, AutoFocusTarget, DialogRef } from 'cub-lib-view-rootng/cdk/dialog';
import * as cub_lib_view_rootng_component_dialog from 'cub-lib-view-rootng/component/dialog';
import * as i0 from '@angular/core';
import { EventEmitter, ElementRef, NgZone, ViewContainerRef, Injector, ComponentFactoryResolver, InjectionToken, OnDestroy, Type, TemplateRef, ChangeDetectorRef, OnInit } from '@angular/core';
import * as cub_lib_view_rootng_cdk_overlay from 'cub-lib-view-rootng/cdk/overlay';
import { OverlayRef, ScrollStrategy, Overlay, OverlayContainer, ComponentType } from 'cub-lib-view-rootng/cdk/overlay';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { Direction } from 'cub-lib-view-rootng/cdk/bidi';
import { FocusTrapFactory, InteractivityChecker, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import { CubThemeColor } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/component/button';
import { CubButtonAppearance } from 'cub-lib-view-rootng/component/button';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';

interface CubDialogPosition {
    top?: string;
    bottom?: string;
    left?: string;
    right?: string;
}
interface CubDialogAnimationEvent {
    state: 'opened' | 'opening' | 'closing' | 'closed';
    totalTime: number;
}
interface CubConfirmDialogOptions {
    title: string;
    description?: string;
    returnCode?: any;
    subButton?: {
        label?: string;
        appearance?: CubButtonAppearance;
        color?: CubThemeColor;
        hidden?: boolean;
    };
    mainButton: {
        label: string;
        appearance?: CubButtonAppearance;
        color?: CubThemeColor;
    };
}

declare abstract class _CubDialogContainerBase extends CubCdkDialogContainer<CubDialogConfig> {
    _animationStateChanged: EventEmitter<CubDialogAnimationEvent>;
    constructor(elementRef: ElementRef, focusTrapFactory: FocusTrapFactory, _document: any, dialogConfig: CubDialogConfig, interactivityChecker: InteractivityChecker, ngZone: NgZone, overlayRef: OverlayRef, focusMonitor?: FocusMonitor);
    abstract _startExitAnimation(): void;
    protected _captureInitialFocus(): void;
    protected _openAnimationDone(totalTime: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDialogContainerBase, [null, null, { optional: true; }, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<_CubDialogContainerBase, "cub-dialog-container-base", never, {}, {}, never, never, true, never>;
}

type CubDialogRole = 'dialog' | 'alertdialog';

declare const enum CubDialogState {
    OPEN = 0,
    CLOSING = 1,
    CLOSED = 2
}

declare const CUB_DIALOG_DEFAULT_OPTIONS: InjectionToken<CubDialogConfig<any>>;
declare class CubDialogConfig<D = any> {
    viewContainerRef?: ViewContainerRef;
    injector?: Injector;
    id?: string;
    role?: CubDialogRole;
    panelClass?: string | string[];
    hasBackdrop?: boolean;
    backdropClass?: string | string[];
    disableClose?: boolean;
    width?: string;
    height?: string;
    minWidth?: number | string;
    minHeight?: number | string;
    maxWidth?: number | string;
    maxHeight?: number | string;
    position?: CubDialogPosition;
    data?: D | null;
    direction?: Direction;
    ariaDescribedBy?: string | null;
    ariaLabelledBy?: string | null;
    ariaLabel?: string | null;
    ariaModal?: boolean;
    autoFocus?: AutoFocusTarget | string | boolean;
    restoreFocus?: boolean;
    delayFocusTrap?: boolean;
    scrollStrategy?: ScrollStrategy;
    closeOnNavigation?: boolean;
    componentFactoryResolver?: ComponentFactoryResolver;
    enterAnimationDuration?: string;
    exitAnimationDuration?: string;
}
declare class CubDialogRef<T, R = any> {
    private _ref;
    _containerInstance: _CubDialogContainerBase;
    componentInstance: T;
    disableClose: boolean | undefined;
    id: string;
    private readonly _afterOpened;
    private readonly _beforeClosed;
    private _result;
    private _closeFallbackTimeout;
    private _state;
    private _closeInteractionType;
    constructor(_ref: DialogRef<R, T>, config: CubDialogConfig, _containerInstance: _CubDialogContainerBase);
    close(dialogResult?: R): void;
    afterOpened(): Observable<void>;
    afterClosed(): Observable<R | undefined>;
    beforeClosed(): Observable<R | undefined>;
    backdropClick(): Observable<MouseEvent>;
    keydownEvents(): Observable<KeyboardEvent>;
    updatePosition(position?: CubDialogPosition): this;
    updateSize(width?: string, height?: string): this;
    addPanelClass(classes: string | string[]): this;
    removePanelClass(classes: string | string[]): this;
    getState(): CubDialogState;
    private _finishDialogClose;
}

declare abstract class _CubDialogBase<C extends _CubDialogContainerBase> implements OnDestroy {
    private _overlay;
    private _defaultOptions;
    private _parentDialog;
    private _dialogRefConstructor;
    private _dialogContainerType;
    private _dialogDataToken;
    readonly afterAllClosed: Observable<void>;
    protected _idPrefix: string;
    private _dialog;
    private _scrollStrategy;
    private readonly _openDialogsAtThisLevel;
    private readonly _afterAllClosedAtThisLevel;
    private readonly _afterOpenedAtThisLevel;
    /** Keeps track of the currently-open dialogs. */
    get openDialogs(): CubDialogRef<any>[];
    /** Stream that emits when a dialog has been opened. */
    get afterOpened(): Subject<CubDialogRef<any>>;
    constructor(_overlay: Overlay, injector: Injector, _defaultOptions: CubDialogConfig | undefined, _parentDialog: _CubDialogBase<C> | undefined, _overlayContainer: OverlayContainer, scrollStrategy: any, _dialogRefConstructor: Type<CubDialogRef<any>>, _dialogContainerType: Type<C>, _dialogDataToken: InjectionToken<any>, _animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    open<T, D = any, R = any>(component: ComponentType<T>, config?: CubDialogConfig<D>): CubDialogRef<T, R>;
    open<T, D = any, R = any>(template: TemplateRef<T>, config?: CubDialogConfig<D>): CubDialogRef<T, R>;
    open<T, D = any, R = any>(template: ComponentType<T> | TemplateRef<T>, config?: CubDialogConfig<D>): CubDialogRef<T, R>;
    closeAll(): void;
    getDialogById(id: string): CubDialogRef<any> | undefined;
    ngOnDestroy(): void;
    private _closeDialogs;
    private _getAfterAllClosed;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDialogBase<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<_CubDialogBase<any>>;
}

declare class CubDialogContainer extends _CubDialogContainerBase {
    private _changeDetectorRef;
    _state: 'void' | 'enter' | 'exit';
    constructor(elementRef: ElementRef, focusTrapFactory: FocusTrapFactory, document: any, dialogConfig: CubDialogConfig, checker: InteractivityChecker, ngZone: NgZone, overlayRef: OverlayRef, _changeDetectorRef: ChangeDetectorRef, focusMonitor?: FocusMonitor);
    _onAnimationDone({ toState, totalTime }: AnimationEvent): void;
    _onAnimationStart({ toState, totalTime }: AnimationEvent): void;
    _startExitAnimation(): void;
    _getAnimationState(): {
        value: "enter" | "void" | "exit";
        params: {
            enterAnimationDuration: string;
            exitAnimationDuration: string;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogContainer, [null, null, { optional: true; }, null, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDialogContainer, "cub-dialog-container", ["cubDialogContainer"], {}, {}, never, never, true, never>;
}

declare class CubDialog extends _CubDialogBase<CubDialogContainer> {
    constructor(overlay: Overlay, injector: Injector, _location: Location, defaultOptions: CubDialogConfig, scrollStrategy: any, parentDialog: CubDialog, overlayContainer: OverlayContainer, animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialog, [null, null, { optional: true; }, { optional: true; }, null, { optional: true; skipSelf: true; }, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubDialog>;
}
declare const CUB_DIALOG_PROVIDER_LIST: ({
    provide: i0.InjectionToken<() => cub_lib_view_rootng_cdk_overlay.ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof cub_lib_view_rootng_component_dialog.CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY;
} | typeof cub_lib_view_rootng_cdk_dialog.Dialog | typeof CubDialog)[];

declare class CubDialogHeader implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDialogHeader, "cub-dialog-header", ["cubDialogHeader"], {}, {}, never, ["cub-dialog-title", "cub-dialog-close"], true, never>;
}

declare class CubDialogTitle implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDialogTitle, "cub-dialog-title", ["cubDialogTitle"], {}, {}, never, ["*", "cub-dialog-code"], true, never>;
}

declare class CubDefaultDialog implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDefaultDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDefaultDialog, "cub-default-dialog", ["cubDefaultDialog"], {}, {}, never, ["cub-dialog-header", "cub-dialog-content", "cub-dialog-actions"], true, never>;
}

declare class CubConfirmDialog implements OnInit {
    dialogRef: CubDialogRef<CubConfirmDialog>;
    dialogData: CubConfirmDialogOptions;
    constructor(dialogRef: CubDialogRef<CubConfirmDialog>, dialogData: CubConfirmDialogOptions);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubConfirmDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubConfirmDialog, "cub-confirm-dialog", ["cubConfirmDialog"], {}, {}, never, never, true, never>;
}

declare class CubDialogCode {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogCode, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDialogCode, "cub-dialog-code", ["cubDialogCode"], {}, {}, never, never, true, never>;
}

declare class CubDialogClose {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogClose, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDialogClose, "cub-dialog-close", ["cubDialogClose"], {}, {}, never, never, true, never>;
}

declare class CubDialogContent {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDialogContent, "cub-dialog-content", ["cubDialogContent"], {}, {}, never, never, true, never>;
}

declare class CubDialogActions {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDialogActions, "cub-dialog-actions", ["cubDialogActions"], {}, {}, never, never, true, never>;
}

declare function CUB_DIALOG_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
declare function CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay: Overlay): () => ScrollStrategy;
declare function getClosestDialog(element: ElementRef<HTMLElement>, openDialogs: CubDialogRef<any>[]): CubDialogRef<any, any> | null | undefined;
declare function _CloseDialogVia<R>(ref: CubDialogRef<R>, interactionType: FocusOrigin, result?: R): void;

declare const CUB_DIALOG_DATA: InjectionToken<any>;
declare const CUB_DIALOG_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
declare const CUB_DIALOG_SCROLL_STRATEGY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY;
};
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
declare const CubDialogDefaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
/**
 * Animations used by CubDialog.
 * @docs-private
 */
declare const CubDialogAnimations: {
    readonly dialogContainer: AnimationTriggerMetadata;
};

declare class CubDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubDialogModule, never, [typeof i1.CubButtonModule, typeof CubDialogContainer, typeof CubDialogHeader, typeof CubDialogTitle, typeof CubDefaultDialog, typeof CubConfirmDialog, typeof CubDialogCode, typeof CubDialogClose, typeof CubDialogContent, typeof CubDialogActions], [typeof i1.CubButtonModule, typeof CubDialogContainer, typeof CubDialogHeader, typeof CubDialogTitle, typeof CubDefaultDialog, typeof CubConfirmDialog, typeof CubDialogCode, typeof CubDialogClose, typeof CubDialogContent, typeof CubDialogActions]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubDialogModule>;
}

export { CUB_DIALOG_DATA, CUB_DIALOG_DEFAULT_OPTIONS, CUB_DIALOG_PROVIDER_LIST, CUB_DIALOG_SCROLL_STRATEGY, CUB_DIALOG_SCROLL_STRATEGY_FACTORY, CUB_DIALOG_SCROLL_STRATEGY_PROVIDER, CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY, CubConfirmDialog, CubDefaultDialog, CubDialog, CubDialogActions, CubDialogAnimations, CubDialogClose, CubDialogCode, CubDialogConfig, CubDialogContainer, CubDialogContent, CubDialogDefaultParams, CubDialogHeader, CubDialogModule, CubDialogRef, CubDialogState, CubDialogTitle, _CloseDialogVia, _CubDialogBase, _CubDialogContainerBase, getClosestDialog };
export type { CubConfirmDialogOptions, CubDialogAnimationEvent, CubDialogPosition, CubDialogRole };
