import * as cub_lib_view_rootng_cdk_dialog from 'cub-lib-view-rootng/cdk/dialog';
import { CubCdkDialogContainer, AutoFocusTarget, DialogRef } from 'cub-lib-view-rootng/cdk/dialog';
import * as cub_lib_view_rootng_component_drawer from 'cub-lib-view-rootng/component/drawer';
import * as i0 from '@angular/core';
import { EventEmitter, ElementRef, NgZone, ViewContainerRef, Injector, ComponentFactoryResolver, InjectionToken, OnDestroy, Type, TemplateRef, ChangeDetectorRef, OnInit } from '@angular/core';
import * as cub_lib_view_rootng_cdk_overlay from 'cub-lib-view-rootng/cdk/overlay';
import { OverlayRef, ScrollStrategy, Overlay, OverlayContainer, ComponentType } from 'cub-lib-view-rootng/cdk/overlay';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { Direction } from 'cub-lib-view-rootng/cdk/bidi';
import { FocusTrapFactory, InteractivityChecker, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import * as i1 from 'cub-lib-view-rootng/component/button';

interface CubDrawerPosition {
    top?: string;
    bottom?: string;
    left?: string;
    right?: string;
}
interface CubDrawerAnimationEvent {
    state: 'opened' | 'opening' | 'closing' | 'closed';
    totalTime: number;
}

declare abstract class _CubDrawerContainerBase extends CubCdkDialogContainer<CubDrawerConfig> {
    _animationStateChanged: EventEmitter<CubDrawerAnimationEvent>;
    constructor(elementRef: ElementRef, focusTrapFactory: FocusTrapFactory, _document: any, drawerConfig: CubDrawerConfig, interactivityChecker: InteractivityChecker, ngZone: NgZone, overlayRef: OverlayRef, focusMonitor?: FocusMonitor);
    abstract _startExitAnimation(): void;
    protected _captureInitialFocus(): void;
    protected _openAnimationDone(totalTime: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDrawerContainerBase, [null, null, { optional: true; }, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<_CubDrawerContainerBase, "cub-drawer-container-base", never, {}, {}, never, never, true, never>;
}

type CubDrawerRole = 'drawer' | 'alertdrawer';

declare const enum CubDrawerState {
    OPEN = 0,
    CLOSING = 1,
    CLOSED = 2
}

declare const CUB_DRAWER_DEFAULT_OPTIONS: InjectionToken<CubDrawerConfig<any>>;
declare class CubDrawerConfig<D = any> {
    viewContainerRef?: ViewContainerRef;
    injector?: Injector;
    id?: string;
    role?: CubDrawerRole;
    panelClass?: string | string[];
    hasBackdrop?: boolean;
    backdropClass?: string | string[];
    disableClose?: boolean;
    width?: string;
    height?: string;
    minWidth?: number | string;
    minHeight?: number | string;
    maxWidth?: number | string;
    maxHeight?: number | string;
    position?: CubDrawerPosition;
    data?: D | null;
    direction?: Direction;
    ariaDescribedBy?: string | null;
    ariaLabelledBy?: string | null;
    ariaLabel?: string | null;
    ariaModal?: boolean;
    autoFocus?: AutoFocusTarget | string | boolean;
    restoreFocus?: boolean;
    delayFocusTrap?: boolean;
    scrollStrategy?: ScrollStrategy;
    closeOnNavigation?: boolean;
    componentFactoryResolver?: ComponentFactoryResolver;
    enterAnimationDuration?: string;
    exitAnimationDuration?: string;
}
declare class CubDrawerRef<T, R = any> {
    private _ref;
    _containerInstance: _CubDrawerContainerBase;
    componentInstance: T;
    disableClose: boolean | undefined;
    id: string;
    private readonly _afterOpened;
    private readonly _beforeClosed;
    private _result;
    private _closeFallbackTimeout;
    private _state;
    private _closeInteractionType;
    constructor(_ref: DialogRef<R, T>, config: CubDrawerConfig, _containerInstance: _CubDrawerContainerBase);
    close(drawerResult?: R): void;
    afterOpened(): Observable<void>;
    afterClosed(): Observable<R | undefined>;
    beforeClosed(): Observable<R | undefined>;
    backdropClick(): Observable<MouseEvent>;
    keydownEvents(): Observable<KeyboardEvent>;
    updatePosition(position?: CubDrawerPosition): this;
    updateSize(width?: string, height?: string): this;
    addPanelClass(classes: string | string[]): this;
    removePanelClass(classes: string | string[]): this;
    getState(): CubDrawerState;
    private _finishDrawerClose;
}

declare abstract class _CubDrawerBase<C extends _CubDrawerContainerBase> implements OnDestroy {
    private _overlay;
    private _defaultOptions;
    private _parentDrawer;
    private _drawerRefConstructor;
    private _drawerContainerType;
    private _drawerDataToken;
    readonly afterAllClosed: Observable<void>;
    protected _idPrefix: string;
    private _drawer;
    private _scrollStrategy;
    private readonly _openDrawersAtThisLevel;
    private readonly _afterAllClosedAtThisLevel;
    private readonly _afterOpenedAtThisLevel;
    /** Keeps track of the currently-open drawers. */
    get openDrawers(): CubDrawerRef<any>[];
    /** Stream that emits when a drawer has been opened. */
    get afterOpened(): Subject<CubDrawerRef<any>>;
    constructor(_overlay: Overlay, injector: Injector, _defaultOptions: CubDrawerConfig | undefined, _parentDrawer: _CubDrawerBase<C> | undefined, _overlayContainer: OverlayContainer, scrollStrategy: any, _drawerRefConstructor: Type<CubDrawerRef<any>>, _drawerContainerType: Type<C>, _drawerDataToken: InjectionToken<any>, _animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    open<T, D = any, R = any>(component: ComponentType<T>, config?: CubDrawerConfig<D>): CubDrawerRef<T, R>;
    open<T, D = any, R = any>(template: TemplateRef<T>, config?: CubDrawerConfig<D>): CubDrawerRef<T, R>;
    open<T, D = any, R = any>(template: ComponentType<T> | TemplateRef<T>, config?: CubDrawerConfig<D>): CubDrawerRef<T, R>;
    closeAll(): void;
    getDrawerById(id: string): CubDrawerRef<any> | undefined;
    ngOnDestroy(): void;
    private _closeDrawers;
    private _getAfterAllClosed;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDrawerBase<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<_CubDrawerBase<any>>;
}

declare class CubDrawerContainer extends _CubDrawerContainerBase {
    private _changeDetectorRef;
    _state: 'void' | 'enter' | 'exit';
    constructor(elementRef: ElementRef, focusTrapFactory: FocusTrapFactory, document: any, drawerConfig: CubDrawerConfig, checker: InteractivityChecker, ngZone: NgZone, overlayRef: OverlayRef, _changeDetectorRef: ChangeDetectorRef, focusMonitor?: FocusMonitor);
    _onAnimationDone({ toState, totalTime }: AnimationEvent): void;
    _onAnimationStart({ toState, totalTime }: AnimationEvent): void;
    _startExitAnimation(): void;
    _getAnimationState(): {
        value: "enter" | "void" | "exit";
        params: {
            enterAnimationDuration: string;
            exitAnimationDuration: string;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerContainer, [null, null, { optional: true; }, null, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDrawerContainer, "cub-drawer-container", ["cubDrawerContainer"], {}, {}, never, never, true, never>;
}

declare class CubDrawer extends _CubDrawerBase<CubDrawerContainer> {
    constructor(overlay: Overlay, injector: Injector, _location: Location, defaultOptions: CubDrawerConfig, scrollStrategy: any, parentDrawer: CubDrawer, overlayContainer: OverlayContainer, animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawer, [null, null, { optional: true; }, { optional: true; }, null, { optional: true; skipSelf: true; }, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubDrawer>;
}
declare const CUB_DRAWER_PROVIDER_LIST: ({
    provide: i0.InjectionToken<() => cub_lib_view_rootng_cdk_overlay.ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof cub_lib_view_rootng_component_drawer.CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY;
} | typeof cub_lib_view_rootng_cdk_dialog.Dialog | typeof CubDrawer)[];

declare class CubDrawerHeader implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDrawerHeader, "cub-drawer-header", ["cubDrawerHeader"], {}, {}, never, ["cub-drawer-title", "cub-drawer-close"], true, never>;
}

declare class CubDrawerTitle implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDrawerTitle, "cub-drawer-title", ["cubDrawerTitle"], {}, {}, never, ["*", "cub-drawer-code"], true, never>;
}

declare class CubDefaultDrawer implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDefaultDrawer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDefaultDrawer, "cub-default-drawer", ["cubDefaultDrawer"], {}, {}, never, ["cub-drawer-header", "cub-drawer-content", "cub-drawer-actions"], true, never>;
}

declare class CubDrawerCode {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerCode, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDrawerCode, "cub-drawer-code", ["cubDrawerCode"], {}, {}, never, never, true, never>;
}

declare class CubDrawerClose {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerClose, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDrawerClose, "cub-drawer-close", ["cubDrawerClose"], {}, {}, never, never, true, never>;
}

declare class CubDrawerContent {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDrawerContent, "cub-drawer-content", ["cubDrawerContent"], {}, {}, never, never, true, never>;
}

declare class CubDrawerActions {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDrawerActions, "cub-drawer-actions", ["cubDrawerActions"], {}, {}, never, never, true, never>;
}

declare function CUB_DRAWER_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
declare function CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay: Overlay): () => ScrollStrategy;
declare function getClosestDrawer(element: ElementRef<HTMLElement>, openDrawers: CubDrawerRef<any>[]): CubDrawerRef<any, any> | null | undefined;
declare function _CloseDrawerVia<R>(ref: CubDrawerRef<R>, interactionType: FocusOrigin, result?: R): void;

declare const CUB_DRAWER_DATA: InjectionToken<any>;
declare const CUB_DRAWER_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
declare const CUB_DRAWER_SCROLL_STRATEGY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY;
};
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
declare const CubDrawerDefaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
/**
 * Animations used by CubDrawer.
 * @docs-private
 */
declare const CubDrawerAnimations: {
    readonly drawerContainer: AnimationTriggerMetadata;
};

declare class CubDrawerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDrawerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubDrawerModule, never, [typeof i1.CubButtonModule, typeof CubDrawerContainer, typeof CubDrawerHeader, typeof CubDrawerTitle, typeof CubDefaultDrawer, typeof CubDrawerCode, typeof CubDrawerClose, typeof CubDrawerContent, typeof CubDrawerActions], [typeof i1.CubButtonModule, typeof CubDrawerContainer, typeof CubDrawerHeader, typeof CubDrawerTitle, typeof CubDefaultDrawer, typeof CubDrawerCode, typeof CubDrawerClose, typeof CubDrawerContent, typeof CubDrawerActions]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubDrawerModule>;
}

export { CUB_DRAWER_DATA, CUB_DRAWER_DEFAULT_OPTIONS, CUB_DRAWER_PROVIDER_LIST, CUB_DRAWER_SCROLL_STRATEGY, CUB_DRAWER_SCROLL_STRATEGY_FACTORY, CUB_DRAWER_SCROLL_STRATEGY_PROVIDER, CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY, CubDefaultDrawer, CubDrawer, CubDrawerActions, CubDrawerAnimations, CubDrawerClose, CubDrawerCode, CubDrawerConfig, CubDrawerContainer, CubDrawerContent, CubDrawerDefaultParams, CubDrawerHeader, CubDrawerModule, CubDrawerRef, CubDrawerState, CubDrawerTitle, _CloseDrawerVia, _CubDrawerBase, _CubDrawerContainerBase, getClosestDrawer };
export type { CubDrawerAnimationEvent, CubDrawerPosition, CubDrawerRole };
