import * as i0 from '@angular/core';
import { OnDestroy, TemplateRef, ComponentFactoryResolver, ApplicationRef, Injector, ViewContainerRef, ChangeDetectorRef, InjectionToken, AfterViewInit, ElementRef, QueryList, EventEmitter, AfterContentInit, OnInit, NgZone, OnChanges, SimpleChanges } from '@angular/core';
import { FocusableOption, FocusMonitor, FocusOrigin, Direction, Overlay, Directionality, ScrollStrategy } from 'cub-lib-view-rootng/cdk';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CanDisableRipple, CanDisable, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import { Subject, Observable } from 'rxjs';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import { FocusOrigin as FocusOrigin$1, FocusableOption as FocusableOption$1 } from 'cub-lib-view-rootng/cdk/a11y';
import { Direction as Direction$1 } from 'cub-lib-view-rootng/cdk/bidi';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { ScrollStrategy as ScrollStrategy$1, Overlay as Overlay$1 } from 'cub-lib-view-rootng/cdk/overlay';

declare abstract class _CubDropDownContentBase implements OnDestroy {
    private _templateRef;
    private _componentFactoryResolver;
    private _appRef;
    private _injector;
    private _viewContainerRef;
    private _document;
    private _changeDetectorRef;
    readonly _attached: Subject<void>;
    private _portal;
    private _outlet;
    constructor(_templateRef: TemplateRef<any>, _componentFactoryResolver: ComponentFactoryResolver, _appRef: ApplicationRef, _injector: Injector, _viewContainerRef: ViewContainerRef, _document: any, _changeDetectorRef: ChangeDetectorRef);
    attach(context?: any): void;
    detach(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDropDownContentBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubDropDownContentBase, "cubDropDownContentBase", never, {}, {}, never, never, true, never>;
}

declare const CUB_DROP_DOWN_CONTENT: InjectionToken<CubDropDownContent>;
declare class CubDropDownContent extends _CubDropDownContentBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDropDownContent, "ng-template[cubDropDownContent]", never, {}, {}, never, never, true, never>;
}

type CubDropDownPositionStart = 'before' | 'after' | 'above' | 'below';
type CubDropDownPositionEnd = 'before' | 'after' | 'above' | 'below';
type CubDropDownCloseReason = void | 'click' | 'keydown' | 'tab';

declare const CUB_DROP_DOWN_ITEM: InjectionToken<unknown>;
declare const _CubDropDownItemBase: cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & {
    new (): {};
};
declare abstract class CubDropDownItem extends _CubDropDownItemBase implements FocusableOption, CanDisable, CanDisableRipple, AfterViewInit, OnDestroy {
    private _elementRef;
    private _document;
    private _focusMonitor;
    _parentDropDown: CubDropDownPanel<CubDropDownItem>;
    _changeDetectorRef: ChangeDetectorRef;
    _dropDownItemsMultiple: boolean;
    _dropDownItemsSelectable: boolean;
    _highlighted: boolean;
    _triggersSubDropDown: boolean;
    _loading: boolean;
    withPrefix: boolean;
    size: CubThemeSize;
    readonly _hovered: Subject<CubDropDownItem>;
    readonly _focused: Subject<CubDropDownItem>;
    protected _value: any;
    private _textElement;
    get prefixSpace(): boolean;
    /**
     * 元件數值，預設為 undefined。
     */
    get value(): any;
    set value(value: any);
    label: string;
    /**
     * 是否為 loading 的狀態，預設值為 false。
     */
    get loading(): boolean;
    set loading(value: boolean);
    prefixContent: TemplateRef<any> | null;
    suffixContent: TemplateRef<any> | null;
    constructor(_elementRef: ElementRef<HTMLElement>, _document: any, _focusMonitor: FocusMonitor, _parentDropDown: CubDropDownPanel<CubDropDownItem>);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    getLabel(): string;
    _getTabIndex(): string;
    _getHostElement(): HTMLElement;
    _checkDisabled(event: Event): void;
    _handleMouseEnter(): void;
    _setHighlighted(isHighlighted: boolean): void;
    _setTriggersSubdropDown(triggersSubdropDown: boolean): void;
    _hasFocus(): boolean;
    _handlePrimaryActionInteraction(...args: Array<unknown>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownItem, [null, null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDropDownItem, "[cubDropDownItem]", ["cubDropDownItem"], { "disabled": { "alias": "disabled"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, {}, ["prefixContent", "suffixContent"], never, true, never>;
}

interface CubDropDownPanel<T = any> {
    positionStart: CubDropDownPositionStart;
    positionEnd: CubDropDownPositionEnd;
    _allItems: QueryList<CubDropDownItem>;
    overlapTrigger: boolean;
    templateRef: TemplateRef<any>;
    readonly closed: EventEmitter<void | 'click' | 'keydown' | 'tab'>;
    parentDropDown?: CubDropDownPanel | undefined;
    prefixSpace: boolean;
    direction?: Direction;
    focusFirstItem: (origin?: FocusOrigin) => void;
    resetActiveItem: () => void;
    setPositionClasses?: (start: CubDropDownPositionStart, end: CubDropDownPositionEnd) => void;
    setElevation?(depth: number): void;
    lazyContent?: CubDropDownContent;
    backdropClass?: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
    readonly panelId?: string;
    addItem?: (item: T) => void;
    removeItem?: (item: T) => void;
    size?: CubThemeSize;
}
interface CubDropDownDefaultOptions {
    positionStart: CubDropDownPositionStart;
    positionEnd: CubDropDownPositionEnd;
    overlapTrigger: boolean;
    backdropClass: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
}
interface CubDropDownFilterOptions<T> {
    label: string;
    value: T;
    selected?: boolean;
    disabled?: boolean;
}

declare class _CubDropDownBase implements AfterContentInit, CubDropDownPanel<CubDropDownItem>, OnInit, OnDestroy {
    private _elementRef;
    private _ngZone;
    private _defaultOptions;
    private _changeDetectorRef;
    _directDescendantItems: QueryList<CubDropDownItem>;
    _classList: {
        [key: string]: boolean;
    };
    _panelAnimationState: 'void' | 'enter';
    _isAnimating: boolean;
    parentDropDown: CubDropDownPanel | undefined;
    direction: Direction$1;
    overlayPanelClass: string | string[];
    readonly panelId: string;
    readonly _animationDone: Subject<AnimationEvent>;
    protected _elevationPrefix: string;
    protected _baseElevation: number;
    private _keyManager;
    private _positionStart;
    private _positionEnd;
    private _firstItemFocusSubscription?;
    private _previousElevation;
    private _prefixSpace;
    private _overlapTrigger;
    private _hasBackdrop;
    private _previousPanelClass;
    size?: CubThemeSize;
    /**
     * 用於設定 backdrop 的 class 名稱，預設為 'cub-cdk-overlay-transparent-backdrop'。
     */
    backdropClass: string;
    /**
     * 用於設定此drop down 是否允許選項或動作前面有 icon 圖示，預設值為 true。
     */
    get prefixSpace(): boolean;
    set prefixSpace(value: boolean);
    /**
     * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabel: string;
    /**
     * 添加 aria-labelledby 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabelledby: string;
    /**
     * 添加 aria-describedby 屬性的值，在標題與欄位型別之後讀的描述內容(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaDescribedby: string;
    /**
     * 設定 dropDown 在 X 軸的顯示位置，預設值為 'after'。
     */
    get positionStart(): CubDropDownPositionStart;
    set positionStart(value: CubDropDownPositionStart);
    /**
     * 設定 dropDown 在 Y 軸的顯示位置，預設值為 'below'。
     */
    get positionEnd(): CubDropDownPositionEnd;
    set positionEnd(value: CubDropDownPositionEnd);
    /**
     * 設定 dropDown 重疊時是否可以觸發，預設值為 false。
     */
    get overlapTrigger(): boolean;
    set overlapTrigger(value: BooleanInput);
    /**
     * 設定 dropDown 是否要有背景遮罩，預設值為 false。
     */
    get hasBackdrop(): boolean | undefined;
    set hasBackdrop(value: BooleanInput);
    /**
     * 設定 class 的名稱，預設值為 ''。
     */
    set panelClass(classes: string);
    /**
     * 當 dropDown 關閉時會送出事件通知。
     */
    readonly closed: EventEmitter<CubDropDownCloseReason>;
    templateRef: TemplateRef<any>;
    items: QueryList<CubDropDownItem>;
    lazyContent: CubDropDownContent;
    _allItems: QueryList<CubDropDownItem>;
    constructor(_elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, _defaultOptions: CubDropDownDefaultOptions, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    addItem(_item: CubDropDownItem): void;
    removeItem(_item: CubDropDownItem): void;
    focusFirstItem(origin?: FocusOrigin$1): void;
    resetActiveItem(): void;
    setElevation(depth: number): void;
    setPositionClasses(start?: CubDropDownPositionStart, end?: CubDropDownPositionEnd): void;
    _hovered(): Observable<CubDropDownItem>;
    _handleKeydown(event: KeyboardEvent): void;
    _startAnimation(): void;
    _resetAnimation(): void;
    _onAnimationDone(event: AnimationEvent): void;
    _onAnimationStart(event: AnimationEvent): void;
    private _updateDirectDescendants;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDropDownBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubDropDownBase, "cubDropDownBase", never, { "size": { "alias": "size"; "required": false; }; "backdropClass": { "alias": "backdropClass"; "required": false; }; "prefixSpace": { "alias": "prefixSpace"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "positionStart": { "alias": "positionStart"; "required": false; }; "positionEnd": { "alias": "positionEnd"; "required": false; }; "overlapTrigger": { "alias": "overlapTrigger"; "required": false; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; }; "panelClass": { "alias": "class"; "required": false; }; }, { "closed": "closed"; }, ["lazyContent", "items", "_allItems"], never, true, never>;
    static ngAcceptInputType_prefixSpace: unknown;
}

declare class CubDropDown extends _CubDropDownBase implements OnChanges {
    private changeDetectorRef;
    constructor(_elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, _defaultOptions: CubDropDownDefaultOptions, changeDetectorRef: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDown, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDropDown, "cub-drop-down", ["cubDropDown"], {}, {}, never, ["cub-drop-down-group"], true, never>;
}

declare class CubDropDownAction extends CubDropDownItem implements FocusableOption$1, CanDisable, CanDisableRipple, AfterViewInit, OnDestroy {
    /**
     * 傳入元件動作，可以是 observable 或 funtion，預設為 undefined。
     */
    action: Observable<any> | (() => void) | undefined;
    /**
     * 當非同步請求完成時送出事件。
     */
    actionCompleted: EventEmitter<any>;
    /**
     * 當非同步請求失敗時送出事件。
     */
    actionFailed: EventEmitter<any>;
    _handlePrimaryActionInteraction(event: unknown): void;
    _handleClick(e: MouseEvent): void;
    _handleKeydown(e: KeyboardEvent): void;
    asyncActionHandler(action: Observable<any>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownAction, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDropDownAction, "[cub-drop-down-action]", never, { "action": { "alias": "action"; "required": false; }; }, { "actionCompleted": "actionCompleted"; "actionFailed": "actionFailed"; }, never, ["[cubPrefix]"], true, never>;
}

/** Event object emitted by MatDrop DownOption when selected or deselected. */
declare class CubDropDownOptionSelectionChange {
    /** Reference to the drop down that emitted the event. */
    source: CubDropDownOption;
    /** Whether the drop down that emitted the event is selected. */
    selected: boolean;
    /** Whether the selection change was a result of a user interaction. */
    isUserInput: boolean;
    constructor(
    /** Reference to the drop down that emitted the event. */
    source: CubDropDownOption, 
    /** Whether the drop down that emitted the event is selected. */
    selected: boolean, 
    /** Whether the selection change was a result of a user interaction. */
    isUserInput?: boolean);
}
declare class CubDropDownOption extends CubDropDownItem implements FocusableOption$1, CanDisable, CanDisableRipple, AfterViewInit, OnDestroy {
    private _selected;
    /**
     * 元件是否被選取狀態，預設值為 false。
     */
    get selected(): boolean;
    set selected(value: boolean);
    /**
     * 當選取狀態改變時，送出事件。
     */
    selectedChange: EventEmitter<boolean>;
    /**
     * 當元件選取狀態改變時送出事件。
     * */
    readonly selectionChange: EventEmitter<CubDropDownOptionSelectionChange>;
    /** Selects the drop down. */
    select(): void;
    /** Deselects the drop down. */
    deselect(): void;
    /** Selects this drop down and emits userInputSelection event */
    selectViaInteraction(): void;
    /** Toggles the current selected state of this drop down. */
    toggleSelected(isUserInput: boolean | undefined, event: Event): void;
    _setSelectedState(isSelected: boolean, isUserInput: boolean, emitEvent: boolean): void;
    _handleKeydown(e: KeyboardEvent): void;
    _handleClick(e: Event): void;
    _handlePrimaryActionInteraction(event: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownOption, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDropDownOption, "[cub-drop-down-option]", never, { "selected": { "alias": "selected"; "required": false; }; }, { "selectedChange": "selectedChange"; "selectionChange": "selectionChange"; }, never, never, true, never>;
    static ngAcceptInputType_selected: unknown;
}

/** Change event object that is emitted when the drop down listbox value has changed. */
declare class CubDropDownOptionGroupChange {
    /** Drop Down listbox that emitted the event. */
    source: CubDropDownGroup;
    /** Value of the drop down listbox when the event was emitted. */
    value: any;
    constructor(
    /** Drop Down listbox that emitted the event. */
    source: CubDropDownGroup, 
    /** Value of the drop down listbox when the event was emitted. */
    value: any);
}
declare const CUB_DROP_DOWN_GROUP: InjectionToken<CubDropDownGroup>;
declare class CubDropDownGroup implements AfterViewInit, OnDestroy {
    _changeDetectorRef: ChangeDetectorRef;
    protected _selectable: boolean;
    protected _value: any;
    /** Subject that emits when the component has been destroyed. */
    protected _destroyed: Subject<void>;
    private _multiple;
    get hasItems(): boolean;
    /** Combined stream of all of the child drop downs' selection change events. */
    get dropDownOptionSelectionChanges(): Observable<CubDropDownOptionSelectionChange | undefined>;
    /** The array of selected drop downs inside the drop down listbox. */
    get selected(): CubDropDownOption[] | CubDropDownOption;
    emptyMessage: string;
    label: string;
    /**
     * 是否開放多選，預設值為 false。
     */
    get multiple(): boolean;
    set multiple(value: boolean);
    /**
     * 元件是否能被選取，預設值為 true。
     */
    get selectable(): boolean;
    set selectable(value: boolean);
    /**
     * 元件的 value ，主要用於紀錄底下被選取的 option 的值，預設值為 undefined。
     */
    get value(): any;
    set value(value: any);
    /**
     * 件比較選項值和選定值的函式，第一個參數是選項中的值，第二個參數是選定的值，並且需要回傳一個布林值，預設為 (o1: any, o2: any) => o1 === o2。
     */
    compareWith: (o1: any, o2: any) => boolean;
    /**
     * 當狀態改變時送出事件。
     */
    readonly change: EventEmitter<CubDropDownOptionGroupChange>;
    optionItems: QueryList<CubDropDownOption>;
    allItems: QueryList<CubDropDownItem>;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Selects all drop downs with value. */
    _setSelectionByValue(value: any, isUserInput?: boolean): void;
    /**
     * Gets a stream of events from all the drop downs within the set.
     * The stream will automatically incorporate any newly-added drop downs.
     */
    protected _getDropDownItemStream<T, C extends CubDropDownOption = CubDropDownOption>(mappingFunction: (item: C) => Observable<T>): Observable<T>;
    /** Emits change event to set the model value. */
    private _propagateChanges;
    /**
     * Finds and selects the drop down based on its value.
     * @returns Drop Down that has the corresponding value.
     */
    private _selectValue;
    /**
     * Deselects every drop down in the listbox.
     * @param skip Drop Down that should not be deselected.
     */
    private _clearSelection;
    private _syncOptionProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubDropDownGroup, "cub-drop-down-group", never, { "emptyMessage": { "alias": "emptyMessage"; "required": false; }; "label": { "alias": "label"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "value": { "alias": "value"; "required": false; }; "compareWith": { "alias": "compareWith"; "required": false; }; }, { "change": "change"; }, ["optionItems", "allItems"], ["[cub-drop-down-option], [cub-drop-down-action]"], true, never>;
    static ngAcceptInputType_multiple: unknown;
    static ngAcceptInputType_selectable: unknown;
}

declare class CubDropDownItemHandle {
    _elementRef: ElementRef<HTMLElement>;
    protected _parentItem: {
        _handlePrimaryActionInteraction(event: unknown): void;
        disabled: boolean;
    };
    private _disabled;
    /** Whether the action is disabled. */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** Tab index of the action. */
    tabIndex: number;
    /**
     * Private API to allow focusing this drop-down when it is disabled.
     */
    private allowFocusWhenDisabled;
    constructor(...args: unknown[]);
    focus(): void;
    _handleClick(event: MouseEvent): void;
    _handleKeydown(event: KeyboardEvent): void;
    /**
     * Determine the value of the disabled attribute for this drop-down action.
     */
    protected _getDisabledAttribute(): string | null;
    /**
     * Determine the value of the tabindex attribute for this drop-down action.
     */
    protected _getTabindex(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownItemHandle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDropDownItemHandle, "[cubDropDownItemHandle]", never, { "disabled": { "alias": "disabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "allowFocusWhenDisabled": { "alias": "allowFocusWhenDisabled"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_disabled: unknown;
    static ngAcceptInputType_tabIndex: unknown;
}

declare abstract class _CubDropDownTriggerBase implements AfterContentInit, OnDestroy {
    private _overlay;
    private _element;
    private _viewContainerRef;
    private _dropDownItemInstance;
    private _dir;
    private _focusMonitor;
    private _ngZone;
    _openedBy: Exclude<FocusOrigin, 'program' | null> | undefined;
    private _dropDown;
    private _portal;
    private _overlayRef;
    private _dropDownOpen;
    private _closingActionsSubscription;
    private _hoverSubscription;
    private _dropDownCloseSubscription;
    private _outsideClickSubscription;
    private _onDestroy;
    private _scrollStrategy;
    private _parentMaterialDropDown;
    private _parentInnerPadding;
    get dropDownOpen(): boolean;
    get dir(): Direction;
    /**
     * 欲於綁定開啟 dropDown 的元件，預設值為 undefined。
     */
    get dropDown(): CubDropDownPanel | null;
    set dropDown(dropDown: CubDropDownPanel | null);
    /**
     * 欲於傳送 dropDown 的內容， 可以是 tempalteRef 或 string，預設值為 undefined。
     */
    dropDownData: any;
    /**
     * dropDown 關閉時是否應恢復焦點，預設值為 true。
     */
    restoreFocus: boolean;
    /**
     * dropDown 打開時送出的事件。
     */
    readonly dropDownOpened: EventEmitter<void>;
    /**
     * dropDown 關閉時送出的事件。
     */
    readonly dropDownClosed: EventEmitter<void>;
    constructor(_overlay: Overlay, _element: ElementRef<HTMLElement>, _viewContainerRef: ViewContainerRef, scrollStrategy: any, parentDropDown: CubDropDownPanel, _dropDownItemInstance: CubDropDownItem, _dir: Directionality, _focusMonitor: FocusMonitor | null, _ngZone: NgZone);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    triggersSubdropDown(): boolean;
    toggleDropDown(): void;
    openDropDown(): void;
    closeDropDown(): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    updatePosition(): void;
    _handleMousedown(event: MouseEvent): void;
    _handleKeydown(event: KeyboardEvent): void;
    _handleClick(event: MouseEvent): void;
    private _handleTouchStart;
    private _destroyDropDown;
    private _initDropDown;
    private _setDropDownElevation;
    private _setIsDropDownOpen;
    private _createOverlay;
    private _getOverlayConfig;
    private _subscribeToPositions;
    private _setPosition;
    private _dropDownClosingActions;
    private _handleHover;
    private _getPortal;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubDropDownTriggerBase, [null, null, null, null, { optional: true; }, { optional: true; self: true; }, { optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubDropDownTriggerBase, never, never, { "dropDown": { "alias": "cubDropDownTriggerFor"; "required": false; }; "dropDownData": { "alias": "cubDropDownTriggerData"; "required": false; }; "restoreFocus": { "alias": "cubDropDownTriggerRestoreFocus"; "required": false; }; }, { "dropDownOpened": "dropDownOpened"; "dropDownClosed": "dropDownClosed"; }, never, never, true, never>;
}

declare class CubDropDownTrigger extends _CubDropDownTriggerBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubDropDownTrigger, "[cubDropDownTriggerFor]", ["cubDropDownTrigger"], {}, {}, never, never, true, never>;
}

declare function throwDropDownInvalidPositionX(): void;
declare function throwDropDownInvalidPositionY(): void;
declare function throwDropDownRecursiveError(): void;
declare function CUB_DROP_DOWN_DEFAULT_OPTIONS_FACTORY(): CubDropDownDefaultOptions;
declare function CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;

declare const CUB_DROP_DOWN_PANEL: InjectionToken<CubDropDownPanel<any>>;
declare const CUB_DROP_DOWN_DEFAULT_OPTIONS: InjectionToken<CubDropDownDefaultOptions>;
declare const CUB_DROP_DOWN_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy$1>;
declare const CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy$1>;
    deps: (typeof Overlay$1)[];
    useFactory: typeof CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY;
};
declare const cubDropDownAnimations: {
    readonly transformDropDown: AnimationTriggerMetadata;
    readonly fadeInItems: AnimationTriggerMetadata;
};
declare const CUB_DROP_DOWN_ITEM_HANDLE: InjectionToken<unknown>;

declare class CubDropDownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubDropDownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubDropDownModule, never, [typeof _CubDropDownBase, typeof CubDropDown, typeof CubDropDownTrigger, typeof _CubDropDownTriggerBase, typeof CubDropDownContent, typeof _CubDropDownContentBase, typeof CubDropDownAction, typeof CubDropDownOption, typeof CubDropDownItem, typeof CubDropDownGroup, typeof CubDropDownItemHandle], [typeof _CubDropDownBase, typeof CubDropDown, typeof CubDropDownTrigger, typeof _CubDropDownTriggerBase, typeof CubDropDownContent, typeof _CubDropDownContentBase, typeof CubDropDownAction, typeof CubDropDownOption, typeof CubDropDownItem, typeof CubDropDownGroup, typeof CubDropDownItemHandle]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubDropDownModule>;
}

export { CUB_DROP_DOWN_CONTENT, CUB_DROP_DOWN_DEFAULT_OPTIONS, CUB_DROP_DOWN_DEFAULT_OPTIONS_FACTORY, CUB_DROP_DOWN_GROUP, CUB_DROP_DOWN_ITEM, CUB_DROP_DOWN_ITEM_HANDLE, CUB_DROP_DOWN_PANEL, CUB_DROP_DOWN_SCROLL_STRATEGY, CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY, CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY_PROVIDER, CubDropDown, CubDropDownAction, CubDropDownContent, CubDropDownGroup, CubDropDownItem, CubDropDownItemHandle, CubDropDownModule, CubDropDownOption, CubDropDownOptionGroupChange, CubDropDownOptionSelectionChange, CubDropDownTrigger, _CubDropDownBase, _CubDropDownContentBase, _CubDropDownTriggerBase, cubDropDownAnimations, throwDropDownInvalidPositionX, throwDropDownInvalidPositionY, throwDropDownRecursiveError };
export type { CubDropDownCloseReason, CubDropDownDefaultOptions, CubDropDownFilterOptions, CubDropDownPanel, CubDropDownPositionEnd, CubDropDownPositionStart };
