import * as i0 from '@angular/core';
import { InjectionToken, AfterViewInit, OnDestroy, QueryList, ElementRef, ChangeDetectorRef } from '@angular/core';
import * as i1 from 'cub-lib-view-rootng/component/common';
import { CubThemeSize, CubPrefix, CubSuffix } from 'cub-lib-view-rootng/component/common';
import * as i2 from 'cub-lib-view-rootng/component/form-field';
import { CubFormFieldControl, CubFormField } from 'cub-lib-view-rootng/component/form-field';
import * as i3 from 'cub-lib-view-rootng/component/label';

declare const CUB_FIELD_SUFFIX: InjectionToken<CubFieldSuffix>;
declare class CubFieldSuffix {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CubFieldSuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubFieldSuffix, "button[appearance=\"filled-outline\"][cubFieldSuffix]", never, {}, {}, never, never, true, never>;
}

declare const CUB_INPUT_GROUP: InjectionToken<CubInputGroup>;
declare class CubInputGroup implements AfterViewInit, OnDestroy {
    private _changeDetectorRef;
    private _formField;
    infixDisabled: boolean;
    private _explicitFormFieldControl;
    get _control(): CubFormFieldControl<any>;
    set _control(value: CubFormFieldControl<any>);
    get _formFieldInvalid(): boolean | boolean[];
    /**
     元件尺寸，預設為 'medium'。
     */
    size: CubThemeSize;
    _controlNonStatic: CubFormFieldControl<any>;
    _controlStatic: CubFormFieldControl<any>;
    _prefixChildren: QueryList<CubPrefix>;
    _suffixChildren: QueryList<CubSuffix>;
    _fieldSuffixChildren: QueryList<CubFieldSuffix>;
    _inputContainerRef: ElementRef;
    constructor(_changeDetectorRef: ChangeDetectorRef, _formField: CubFormField);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubInputGroup, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubInputGroup, "cub-input-group", ["cubInputGroup"], { "size": { "alias": "size"; "required": false; }; }, {}, ["_controlNonStatic", "_controlStatic", "_prefixChildren", "_suffixChildren", "_fieldSuffixChildren"], ["[cubPrefix]", "*", "[cubSuffix]", "[cubFieldSuffix]"], true, never>;
}

declare class CubInputGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubInputGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubInputGroupModule, never, [typeof i1.CubCommonModule, typeof i2.CubFormFieldModule, typeof i3.CubLabelModule, typeof CubInputGroup, typeof CubFieldSuffix], [typeof i1.CubCommonModule, typeof i2.CubFormFieldModule, typeof i3.CubLabelModule, typeof CubInputGroup, typeof CubFieldSuffix]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubInputGroupModule>;
}

export { CUB_FIELD_SUFFIX, CUB_INPUT_GROUP, CubFieldSuffix, CubInputGroup, CubInputGroupModule };
