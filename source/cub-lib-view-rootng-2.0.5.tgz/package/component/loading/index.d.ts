import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';
import { CubThemeColor, CubThemeColorContrast, CubThemeSize } from 'cub-lib-view-rootng/component/common';

type CubLoadingColor = CubThemeColor | CubThemeColorContrast | 'white';

declare class CubLoading implements OnInit {
    get spinnerSecondHalfId(): string;
    get spinnerFirstHalfId(): string;
    get backdropTheme(): string;
    /** 元件顏色，預設為 'brand'。 */
    color: CubLoadingColor;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 是否螢幕滿版顯示，預設為 false。 */
    fullScreen: boolean;
    /** 是否有遮罩，預設為 false。 */
    hasBackdrop: boolean;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubLoading, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubLoading, "cub-loading", never, { "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; }; }, {}, never, never, true, never>;
}

declare const CubLoadingBackdropTheme: any;

declare class CubLoadingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubLoadingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubLoadingModule, never, [typeof CubLoading], [typeof CubLoading]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubLoadingModule>;
}

export { CubLoading, CubLoadingBackdropTheme, CubLoadingModule };
export type { CubLoadingColor };
