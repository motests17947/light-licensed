import * as i0 from '@angular/core';
import { OnInit, OnChanges, OnDestroy, EventEmitter, SimpleChanges } from '@angular/core';

interface CubMaskFormat {
    title: string;
    description: string;
    device: {
        desktop: string;
        laptop: string;
        tabletLandscape: string;
        tabletPortrait: string;
        mobile: string;
    };
    button: {
        label: string;
        command: (event?: any) => void;
    };
}

type CubMaskSupportedDevice = 'desktop' | 'laptop' | 'tabletLandscape' | 'tabletPortrait' | 'mobile';
type CubMaskLanguage = 'zh-TW' | 'en-US';

declare class CubMask implements OnInit, OnChanges, OnDestroy {
    isShowMask: boolean;
    hintText: CubMaskFormat;
    supportedDeviceList: CubMaskSupportedDevice[];
    /** 是否顯示遮罩，預設為 true。 */
    visible: boolean;
    /** 遮罩顯式的最大斷點，預設為 null。可取下列值之一：
     * xxl：螢幕尺寸 > 1920px 時顯示。
     * null：不限制螢幕尺寸。
     */
    maxBreakPoint: 'xxl' | null;
    /** 遮罩顯式的最小斷點，預設為 'lg'。可取下列值之一：
     * xl：螢幕尺寸 < 1440px 時顯示。
     * lg：螢幕尺寸 < 1024px 時顯示。
     * md：螢幕尺寸 < 768px 時顯示。
     * sm：螢幕尺寸 < 576px 時顯示。
     */
    minBreakPoint: 'xl' | 'lg' | 'md' | 'sm';
    /** 是否顯示關閉按鈕，預設為 false。 */
    showCloseButton: boolean;
    /** End */
    /** 提示訊息所支援的顯示語言，預設為 'zh-TW'。可取下列值之一：
     * zh-TW：繁體中文。
     * en-US：英文。
     */
    language: CubMaskLanguage;
    /** 在提示訊息中所支援的裝置類型，預設為 ['desktop','laptop','tabletLandscape','tabletPortrait','mobile']。可取下列值使用：
     * desktop：桌機。
     * laptop：筆電。
     * tabletLandscape：橫式平板。
     * tabletPortrait：直式平板。
     * mobile：手機。
     */
    supportedDevice: CubMaskSupportedDevice[];
    /** End */
    /** 自行關閉遮罩時發出通知。 */
    closed: EventEmitter<any>;
    onResize(event: any): void;
    constructor();
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    closeMask(): void;
    private showMask;
    private hideMask;
    private toggleMask;
    private getBreakPoint;
    private getHintText;
    private updateDeviceList;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMask, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubMask, "cub-mask", never, { "visible": { "alias": "visible"; "required": false; }; "maxBreakPoint": { "alias": "maxBreakPoint"; "required": false; }; "minBreakPoint": { "alias": "minBreakPoint"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "language": { "alias": "language"; "required": false; }; "supportedDevice": { "alias": "supportedDevice"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}

declare const CUB_MASK_LANGUAGE_CONFIG: {
    [param: string]: CubMaskFormat;
};

declare class CubMaskModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMaskModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubMaskModule, never, [typeof CubMask], [typeof CubMask]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubMaskModule>;
}

export { CUB_MASK_LANGUAGE_CONFIG, CubMask, CubMaskModule };
export type { CubMaskFormat, CubMaskLanguage, CubMaskSupportedDevice };
