import * as i0 from '@angular/core';
import { OnDestroy, TemplateRef, ComponentFactoryResolver, ApplicationRef, Injector, ViewContainerRef, ChangeDetectorRef, InjectionToken, AfterViewInit, EventEmitter, ElementRef, QueryList, AfterContentInit, OnInit, NgZone, OnChanges, SimpleChanges } from '@angular/core';
import { Direction, Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { FocusableOption, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import { Subject, Observable } from 'rxjs';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CanDisableRipple, CanDisable, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { Overlay, ScrollStrategy } from 'cub-lib-view-rootng/cdk/overlay';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';

type CubMenuPositionStart = 'before' | 'after' | 'above' | 'below';
type CubMenuPositionEnd = 'before' | 'after' | 'above' | 'below';
type CubMenuCloseReason = void | 'click' | 'keydown' | 'tab';

declare const CUB_MENU_CONTENT: InjectionToken<CubMenuContent>;
declare abstract class _CubMenuContentBase implements OnDestroy {
    private _templateRef;
    private _componentFactoryResolver;
    private _appRef;
    private _injector;
    private _viewContainerRef;
    private _document;
    private _changeDetectorRef;
    readonly _attached: Subject<void>;
    private _portal;
    private _outlet;
    constructor(_templateRef: TemplateRef<any>, _componentFactoryResolver: ComponentFactoryResolver, _appRef: ApplicationRef, _injector: Injector, _viewContainerRef: ViewContainerRef, _document: any, _changeDetectorRef: ChangeDetectorRef);
    attach(context?: any): void;
    detach(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubMenuContentBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubMenuContentBase, never, never, {}, {}, never, never, true, never>;
}
declare class CubMenuContent extends _CubMenuContentBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMenuContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubMenuContent, "ng-template[cubMenuContent]", never, {}, {}, never, never, true, never>;
}

declare const _CubMenuItemBase: cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & {
    new (): {};
};
declare class CubMenuItem extends _CubMenuItemBase implements FocusableOption, CanDisable, CanDisableRipple, AfterViewInit, OnDestroy {
    private _elementRef;
    private _document;
    private _focusMonitor;
    _parentMenu: CubMenuPanel<CubMenuItem>;
    private _changeDetectorRef;
    withPrefix: boolean;
    _loading: boolean;
    _highlighted: boolean;
    _triggersSubmenu: boolean;
    size: CubThemeSize;
    readonly _hovered: Subject<CubMenuItem>;
    readonly _focused: Subject<CubMenuItem>;
    /**
     * 傳入元件動作，可以是 observable 或 funtion，預設為 undefined。
     */
    action: Observable<any> | (() => void) | undefined;
    /**
     * 當非同步請求完成時送出事件。
     */
    actionCompleted: EventEmitter<any>;
    /**
     * 當非同步請求失敗時送出事件。
     */
    actionFailed: EventEmitter<any>;
    /**
     * 是否為 loading 的狀態，預設值為 false。
     */
    get loading(): boolean;
    set loading(value: boolean);
    prefixContent: TemplateRef<any> | null;
    suffixContent: TemplateRef<any> | null;
    constructor(_elementRef: ElementRef<HTMLElement>, _document: any, _focusMonitor: FocusMonitor, _parentMenu: CubMenuPanel<CubMenuItem>, _changeDetectorRef: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    _getTabIndex(): string;
    _getHostElement(): HTMLElement;
    _checkDisabled(event: Event): void;
    _handleMouseEnter(): void;
    getLabel(): string;
    _setHighlighted(isHighlighted: boolean): void;
    _setTriggersSubmenu(triggersSubmenu: boolean): void;
    _hasFocus(): boolean;
    _handleClick(e: MouseEvent): void;
    _handleKeydown(e: KeyboardEvent): void;
    asyncActionHandler(action: Observable<any>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMenuItem, [null, null, null, { optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubMenuItem, "[cub-menu-item]", ["cubMenuItem"], { "disabled": { "alias": "disabled"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "action": { "alias": "action"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "actionCompleted": "actionCompleted"; "actionFailed": "actionFailed"; }, ["prefixContent", "suffixContent"], ["[cubPrefix]", "*"], true, never>;
}

interface CubMenuPanel<T = any> {
    positionStart: CubMenuPositionStart;
    positionEnd: CubMenuPositionEnd;
    overlapTrigger: boolean;
    templateRef: TemplateRef<any>;
    readonly closed: EventEmitter<void | 'click' | 'keydown' | 'tab'>;
    parentMenu?: CubMenuPanel | undefined;
    _allItems: QueryList<CubMenuItem>;
    direction?: Direction;
    focusFirstItem: (origin?: FocusOrigin) => void;
    resetActiveItem: () => void;
    setPositionClasses?: (start: CubMenuPositionStart, end: CubMenuPositionEnd) => void;
    setElevation?(depth: number): void;
    lazyContent?: CubMenuContent;
    backdropClass?: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
    size: CubThemeSize;
    readonly panelId?: string;
    addItem?: (item: T) => void;
    removeItem?: (item: T) => void;
}
interface CubMenuDefaultOptions {
    positionStart: CubMenuPositionStart;
    positionEnd: CubMenuPositionEnd;
    overlapTrigger: boolean;
    backdropClass: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
}

declare class _CubMenuBase implements AfterContentInit, CubMenuPanel<CubMenuItem>, OnInit, OnDestroy {
    private _elementRef;
    private _ngZone;
    private _defaultOptions;
    private _changeDetectorRef;
    parentMenu: CubMenuPanel | undefined;
    direction: Direction;
    overlayPanelClass: string | string[];
    _directDescendantItems: QueryList<CubMenuItem>;
    _classList: {
        [key: string]: boolean;
    };
    _panelAnimationState: 'void' | 'enter';
    _isAnimating: boolean;
    readonly panelId: string;
    readonly _animationDone: Subject<AnimationEvent>;
    protected _elevationPrefix: string;
    protected _baseElevation: number;
    private _keyManager;
    private _positionStart;
    private _positionEnd;
    private _firstItemFocusSubscription?;
    private _previousElevation;
    private _overlapTrigger;
    private _hasBackdrop;
    private _previousPanelClass;
    size: CubThemeSize;
    /**
     * 用於設定 backdrop 的 class 名稱，預設為 'cub-cdk-overlay-transparent-backdrop'。
     */
    backdropClass: string;
    /**
     * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabel: string;
    /**
     * 添加 aria-labelledby 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabelledby: string;
    /**
     * 添加 aria-describedby 屬性的值，在標題與欄位型別之後讀的描述內容(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaDescribedby: string;
    /**
     * 設定 menu 在 X 軸的顯示位置，預設值為 'after'。
     */
    get positionStart(): CubMenuPositionStart;
    set positionStart(value: CubMenuPositionStart);
    /**
     * 設定 menu 在 Y 軸的顯示位置，預設值為 'below'。
     */
    get positionEnd(): CubMenuPositionEnd;
    set positionEnd(value: CubMenuPositionEnd);
    /**
     * 設定 menu 重疊時是否可以觸發，預設值為 false。
     */
    get overlapTrigger(): boolean;
    set overlapTrigger(value: BooleanInput);
    /**
     * 設定 menu 是否要有背景遮罩，預設值為 false。
     */
    get hasBackdrop(): boolean | undefined;
    set hasBackdrop(value: BooleanInput);
    /**
     * 設定 class 的名稱，預設值為 ''。
     */
    set panelClass(classes: string);
    /**
     * 當 menu 關閉時會送出事件通知。
     */
    readonly closed: EventEmitter<CubMenuCloseReason>;
    templateRef: TemplateRef<any>;
    items: QueryList<CubMenuItem>;
    lazyContent: CubMenuContent;
    _allItems: QueryList<CubMenuItem>;
    constructor(_elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, _defaultOptions: CubMenuDefaultOptions, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    addItem(_item: CubMenuItem): void;
    removeItem(_item: CubMenuItem): void;
    focusFirstItem(origin?: FocusOrigin): void;
    resetActiveItem(): void;
    setElevation(depth: number): void;
    setPositionClasses(start?: CubMenuPositionStart, end?: CubMenuPositionEnd): void;
    _getHostElement(): HTMLElement;
    _hovered(): Observable<CubMenuItem>;
    _handleKeydown(event: KeyboardEvent): void;
    _startAnimation(): void;
    _resetAnimation(): void;
    _onAnimationDone(event: AnimationEvent): void;
    _onAnimationStart(event: AnimationEvent): void;
    private _updateDirectDescendants;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubMenuBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubMenuBase, never, never, { "size": { "alias": "size"; "required": false; }; "backdropClass": { "alias": "backdropClass"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "positionStart": { "alias": "positionStart"; "required": false; }; "positionEnd": { "alias": "positionEnd"; "required": false; }; "overlapTrigger": { "alias": "overlapTrigger"; "required": false; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; }; "panelClass": { "alias": "class"; "required": false; }; }, { "closed": "closed"; }, ["lazyContent", "items", "_allItems"], never, true, never>;
}

declare class CubMenu extends _CubMenuBase implements OnChanges {
    private changeDetectorRef;
    constructor(_elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, _defaultOptions: CubMenuDefaultOptions, changeDetectorRef: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubMenu, "cub-menu", ["cubMenu"], {}, {}, never, ["*"], true, never>;
}

declare class CubMenuGroup {
    label: string;
    handleClick(e: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMenuGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubMenuGroup, "cub-menu-item-group", never, { "label": { "alias": "label"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare abstract class _CubMenuTriggerBase implements AfterContentInit, OnDestroy {
    private _overlay;
    private _element;
    private _viewContainerRef;
    private _menuItemInstance;
    private _dir;
    private _focusMonitor;
    private _ngZone;
    _openedBy: Exclude<FocusOrigin, 'program' | null> | undefined;
    private _menu;
    private _portal;
    private _overlayRef;
    private _menuOpen;
    private _closingActionsSubscription;
    private _hoverSubscription;
    private _menuCloseSubscription;
    private _outsideClickSubscription;
    private _onDestroy;
    private _parentMaterialMenu;
    private _parentInnerPadding;
    private _scrollStrategy;
    get menuOpen(): boolean;
    get dir(): Direction;
    /**
     * 欲於綁定開啟 menu 的元件，預設值為 undefined。
     */
    get menu(): CubMenuPanel | null;
    set menu(menu: CubMenuPanel | null);
    /**
     * 欲於傳送 menu 的內容， 可以是 tempalteRef 或 string，預設值為 undefined。
     */
    menuData: any;
    /**
     * menu 關閉時是否應恢復焦點，預設值為 true。
     */
    restoreFocus: boolean;
    /**
     * menu 打開時送出的事件。
     */
    readonly menuOpened: EventEmitter<void>;
    /**
     * menu 關閉時送出的事件。
     */
    readonly menuClosed: EventEmitter<void>;
    constructor(_overlay: Overlay, _element: ElementRef<HTMLElement>, _viewContainerRef: ViewContainerRef, scrollStrategy: any, parentMenu: CubMenuPanel, _menuItemInstance: CubMenuItem, _dir: Directionality, _focusMonitor: FocusMonitor | null, _ngZone: NgZone);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    triggersSubmenu(): boolean;
    toggleMenu(): void;
    openMenu(): void;
    closeMenu(): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    updatePosition(): void;
    _handleMousedown(event: MouseEvent): void;
    _handleKeydown(event: KeyboardEvent): void;
    _handleClick(event: MouseEvent): void;
    private _handleTouchStart;
    private _destroyMenu;
    private _initMenu;
    private _setMenuElevation;
    private _setIsMenuOpen;
    private _createOverlay;
    private _getOverlayConfig;
    private _subscribeToPositions;
    private _setPosition;
    private _menuClosingActions;
    private _handleHover;
    private _getPortal;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubMenuTriggerBase, [null, null, null, null, { optional: true; }, { optional: true; self: true; }, { optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubMenuTriggerBase, never, never, { "menu": { "alias": "cubMenuTriggerFor"; "required": false; }; "menuData": { "alias": "cubMenuTriggerData"; "required": false; }; "restoreFocus": { "alias": "cubMenuTriggerRestoreFocus"; "required": false; }; }, { "menuOpened": "menuOpened"; "menuClosed": "menuClosed"; }, never, never, true, never>;
}
declare class CubMenuTrigger extends _CubMenuTriggerBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMenuTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubMenuTrigger, "[cubMenuTriggerFor]", ["cubMenuTrigger"], {}, {}, never, never, true, never>;
}

declare function throwMenuInvalidPositionStart(): void;
declare function throwMenuInvalidPositionEnd(): void;
declare function throwMenuRecursiveError(): void;
declare function CUB_MENU_DEFAULT_OPTIONS_FACTORY(): CubMenuDefaultOptions;
declare function CUB_MENU_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;

declare const CUB_MENU_PANEL: InjectionToken<CubMenuPanel<any>>;
declare const CUB_MENU_DEFAULT_OPTIONS: InjectionToken<CubMenuDefaultOptions>;
declare const CUB_MENU_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
declare const CUB_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_MENU_SCROLL_STRATEGY_FACTORY;
};
declare const cubMenuAnimations: {
    readonly transformMenu: AnimationTriggerMetadata;
    readonly fadeInItems: AnimationTriggerMetadata;
};

declare class CubMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubMenuModule, never, [typeof i1.CubCdkScrollableModule, typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof CubMenu, typeof CubMenuItem, typeof CubMenuGroup, typeof CubMenuContent, typeof CubMenuTrigger], [typeof i1.CubCdkScrollableModule, typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof CubMenu, typeof CubMenuItem, typeof CubMenuContent, typeof CubMenuTrigger, typeof CubMenuGroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubMenuModule>;
}

export { CUB_MENU_CONTENT, CUB_MENU_DEFAULT_OPTIONS, CUB_MENU_DEFAULT_OPTIONS_FACTORY, CUB_MENU_PANEL, CUB_MENU_SCROLL_STRATEGY, CUB_MENU_SCROLL_STRATEGY_FACTORY, CUB_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER, CubMenu, CubMenuContent, CubMenuGroup, CubMenuItem, CubMenuModule, CubMenuTrigger, _CubMenuContentBase, _CubMenuTriggerBase, cubMenuAnimations, throwMenuInvalidPositionEnd, throwMenuInvalidPositionStart, throwMenuRecursiveError };
export type { CubMenuCloseReason, CubMenuDefaultOptions, CubMenuPanel, CubMenuPositionEnd, CubMenuPositionStart };
