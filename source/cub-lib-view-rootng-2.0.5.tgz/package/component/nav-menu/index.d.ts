import * as i0 from '@angular/core';
import { OnDestroy, TemplateRef, ComponentFactoryResolver, ApplicationRef, Injector, ViewContainerRef, ChangeDetectorRef, InjectionToken, OnInit, AfterViewInit, ElementRef, EventEmitter, QueryList, AfterContentInit, NgZone, OnChanges, SimpleChanges } from '@angular/core';
import { Direction, Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { FocusableOption, FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CanDisableRipple, CanDisable, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import { Subject, Observable } from 'rxjs';
import { Params, QueryParamsHandling, Router, ActivatedRoute } from '@angular/router';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { Overlay, ScrollStrategy } from 'cub-lib-view-rootng/cdk/overlay';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';

type CubNavMenuPositionStart = 'before' | 'after' | 'above' | 'below';
type CubNavMenuPositionEnd = 'before' | 'after' | 'above' | 'below';
type CubNavMenuCloseReason = void | 'click' | 'keydown' | 'tab';

declare const CUB_NAV_MENU_CONTENT: InjectionToken<CubNavMenuContent>;
declare abstract class _CubNavMenuContentBase implements OnDestroy {
    private _templateRef;
    private _componentFactoryResolver;
    private _appRef;
    private _injector;
    private _viewContainerRef;
    private _document;
    private _changeDetectorRef;
    readonly _attached: Subject<void>;
    private _portal;
    private _outlet;
    constructor(_templateRef: TemplateRef<any>, _componentFactoryResolver: ComponentFactoryResolver, _appRef: ApplicationRef, _injector: Injector, _viewContainerRef: ViewContainerRef, _document: any, _changeDetectorRef: ChangeDetectorRef);
    attach(context?: any): void;
    detach(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubNavMenuContentBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubNavMenuContentBase, never, never, {}, {}, never, never, true, never>;
}
declare class CubNavMenuContent extends _CubNavMenuContentBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNavMenuContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubNavMenuContent, "ng-template[cubNavMenuContent]", never, {}, {}, never, never, true, never>;
}

declare const _CubNavMenuItemBase: cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & {
    new (): {};
};
declare class CubNavMenuItem extends _CubNavMenuItemBase implements FocusableOption, CanDisable, CanDisableRipple, OnInit, AfterViewInit, OnDestroy {
    private _elementRef;
    private _document;
    private _focusMonitor;
    _parentMenu: CubNavMenuPanel<CubNavMenuItem>;
    private _changeDetectorRef;
    private _router;
    private _route;
    withPrefix: boolean;
    _active: boolean;
    _highlighted: boolean;
    _triggersSubmenu: boolean;
    size: CubThemeSize;
    readonly _hovered: Subject<CubNavMenuItem>;
    readonly _focused: Subject<CubNavMenuItem>;
    private readonly _destroyed;
    /** 是否為禁用狀態，預設為 undefined。 */
    /** 是否禁用漣漪效果，預設為 undefined。 */
    /** 是否採用路徑精準比對，包含路徑參數比對，預設為 false。 */
    exact: boolean;
    /** 連結路徑，可使用絕對路徑或相對路徑，預設為 null。 */
    routerLink: string | any[] | null;
    /** 路徑參數，預設為 null。 */
    queryParams?: Params | null;
    /** 是否保留路徑參數，預設為 null。 */
    queryParamsHandling: QueryParamsHandling | null;
    /** 連結片段，用於跳轉 HMTL 頁面區塊的錨點，預設為 null。 */
    fragment: string | null;
    /** 連結是否處於活動狀態的選項設定，預設為 { exact: false }。 */
    routerLinkActiveOptions: {
        exact: boolean;
    };
    prefixContent: TemplateRef<any> | null;
    suffixContent: TemplateRef<any> | null;
    constructor(_elementRef: ElementRef<HTMLElement>, _document: any, _focusMonitor: FocusMonitor, _parentMenu: CubNavMenuPanel<CubNavMenuItem>, _changeDetectorRef: ChangeDetectorRef, _router: Router, _route: ActivatedRoute);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    updateActiveState(): void;
    _getTabIndex(): string;
    _getHostElement(): HTMLElement;
    _checkDisabled(event: Event): void;
    getLabel(): string;
    _setHighlighted(isHighlighted: boolean): void;
    _setTriggersSubmenu(triggersSubmenu: boolean): void;
    _hasFocus(): boolean;
    _handleMouseEnter(): void;
    _handleClick(e: MouseEvent): void;
    _handleKeydown(e: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNavMenuItem, [null, null, null, { optional: true; }, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubNavMenuItem, "[cub-nav-menu-item]", ["cubNavMenuItem"], { "disabled": { "alias": "disabled"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "exact": { "alias": "exact"; "required": false; }; "routerLink": { "alias": "routerLink"; "required": false; }; "queryParams": { "alias": "queryParams"; "required": false; }; "queryParamsHandling": { "alias": "queryParamsHandling"; "required": false; }; "fragment": { "alias": "fragment"; "required": false; }; "routerLinkActiveOptions": { "alias": "routerLinkActiveOptions"; "required": false; }; }, {}, ["prefixContent", "suffixContent"], ["[cubPrefix]", "*"], true, never>;
}

interface CubNavMenuPanel<T = any> {
    positionStart: CubNavMenuPositionStart;
    positionEnd: CubNavMenuPositionEnd;
    overlapTrigger: boolean;
    templateRef: TemplateRef<any>;
    readonly closed: EventEmitter<void | 'click' | 'keydown' | 'tab'>;
    parentMenu?: CubNavMenuPanel | undefined;
    _allItems: QueryList<CubNavMenuItem>;
    direction?: Direction;
    focusFirstItem: (origin?: FocusOrigin) => void;
    resetActiveItem: () => void;
    setPositionClasses?: (start: CubNavMenuPositionStart, end: CubNavMenuPositionEnd) => void;
    setElevation?(depth: number): void;
    lazyContent?: CubNavMenuContent;
    backdropClass?: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
    size: CubThemeSize;
    readonly panelId?: string;
    addItem?: (item: T) => void;
    removeItem?: (item: T) => void;
}
interface CubNavMenuDefaultOptions {
    positionStart: CubNavMenuPositionStart;
    positionEnd: CubNavMenuPositionEnd;
    overlapTrigger: boolean;
    backdropClass: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
}

declare class _CubNavMenuBase implements AfterContentInit, CubNavMenuPanel<CubNavMenuItem>, OnInit, OnDestroy {
    private _elementRef;
    private _ngZone;
    private _defaultOptions;
    private _changeDetectorRef;
    parentMenu: CubNavMenuPanel | undefined;
    direction: Direction;
    overlayPanelClass: string | string[];
    _directDescendantItems: QueryList<CubNavMenuItem>;
    _classList: {
        [key: string]: boolean;
    };
    _panelAnimationState: 'void' | 'enter';
    _isAnimating: boolean;
    readonly panelId: string;
    readonly _animationDone: Subject<AnimationEvent>;
    protected _elevationPrefix: string;
    protected _baseElevation: number;
    private _keyManager;
    private _positionStart;
    private _positionEnd;
    private _firstItemFocusSubscription?;
    private _previousElevation;
    private _overlapTrigger;
    private _hasBackdrop;
    private _previousPanelClass;
    size: CubThemeSize;
    /**
     * 用於設定 backdrop 的 class 名稱，預設為 'cub-cdk-overlay-transparent-backdrop'。
     */
    backdropClass: string;
    /**
     * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabel: string;
    /**
     * 添加 aria-labelledby 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabelledby: string;
    /**
     * 添加 aria-describedby 屬性的值，在標題與欄位型別之後讀的描述內容(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaDescribedby: string;
    /**
     * 設定 menu 在 X 軸的顯示位置，預設值為 'after'。
     */
    get positionStart(): CubNavMenuPositionStart;
    set positionStart(value: CubNavMenuPositionStart);
    /**
     * 設定 menu 在 Y 軸的顯示位置，預設值為 'below'。
     */
    get positionEnd(): CubNavMenuPositionEnd;
    set positionEnd(value: CubNavMenuPositionEnd);
    /**
     * 設定 menu 重疊時是否可以觸發，預設值為 false。
     */
    get overlapTrigger(): boolean;
    set overlapTrigger(value: BooleanInput);
    /**
     * 設定 menu 是否要有背景遮罩，預設值為 false。
     */
    get hasBackdrop(): boolean | undefined;
    set hasBackdrop(value: BooleanInput);
    /**
     * 設定 class 的名稱，預設值為 ''。
     */
    set panelClass(classes: string);
    /**
     * 當 menu 關閉時會送出事件通知。
     */
    readonly closed: EventEmitter<CubNavMenuCloseReason>;
    templateRef: TemplateRef<any>;
    items: QueryList<CubNavMenuItem>;
    lazyContent: CubNavMenuContent;
    _allItems: QueryList<CubNavMenuItem>;
    constructor(_elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, _defaultOptions: CubNavMenuDefaultOptions, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    addItem(_item: CubNavMenuItem): void;
    removeItem(_item: CubNavMenuItem): void;
    focusFirstItem(origin?: FocusOrigin): void;
    resetActiveItem(): void;
    setElevation(depth: number): void;
    setPositionClasses(start?: CubNavMenuPositionStart, end?: CubNavMenuPositionEnd): void;
    _getHostElement(): HTMLElement;
    _hovered(): Observable<CubNavMenuItem>;
    _handleKeydown(event: KeyboardEvent): void;
    _startAnimation(): void;
    _resetAnimation(): void;
    _onAnimationDone(event: AnimationEvent): void;
    _onAnimationStart(event: AnimationEvent): void;
    private _updateDirectDescendants;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubNavMenuBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubNavMenuBase, never, never, { "size": { "alias": "size"; "required": false; }; "backdropClass": { "alias": "backdropClass"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "positionStart": { "alias": "positionStart"; "required": false; }; "positionEnd": { "alias": "positionEnd"; "required": false; }; "overlapTrigger": { "alias": "overlapTrigger"; "required": false; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; }; "panelClass": { "alias": "class"; "required": false; }; }, { "closed": "closed"; }, ["lazyContent", "items", "_allItems"], never, true, never>;
}

declare class CubNavMenu extends _CubNavMenuBase implements OnChanges {
    private changeDetectorRef;
    constructor(_elementRef: ElementRef<HTMLElement>, _ngZone: NgZone, _defaultOptions: CubNavMenuDefaultOptions, changeDetectorRef: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNavMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubNavMenu, "cub-nav-menu", ["cubNavMenu"], {}, {}, never, ["*"], true, never>;
}

declare class CubNavMenuGroup {
    label: string;
    handleClick(e: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNavMenuGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubNavMenuGroup, "cub-nav-menu-item-group", ["cubNavMenuGroup"], { "label": { "alias": "label"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare abstract class _CubNavMenuTriggerBase implements AfterContentInit, OnDestroy {
    private _overlay;
    private _element;
    private _viewContainerRef;
    private _menuItemInstance;
    private _dir;
    private _focusMonitor;
    private _ngZone;
    _openedBy: Exclude<FocusOrigin, 'program' | null> | undefined;
    private _menu;
    private _portal;
    private _overlayRef;
    private _menuOpen;
    private _closingActionsSubscription;
    private _hoverSubscription;
    private _menuCloseSubscription;
    private _outsideClickSubscription;
    private _onDestroy;
    private _parentMaterialMenu;
    private _parentInnerPadding;
    private _scrollStrategy;
    get menuOpen(): boolean;
    get dir(): Direction;
    /**
     * 欲於綁定開啟選單的元件，預設值為 undefined。
     */
    get menu(): CubNavMenuPanel | null;
    set menu(menu: CubNavMenuPanel | null);
    /**
     * 傳送至選單的資料， 可以是 tempalteRef 或 string，預設值為 undefined。
     */
    menuData: any;
    /**
     * 關閉時是否應恢復焦點，預設值為 true。
     */
    restoreFocus: boolean;
    /**
     * 打開時送出的事件。
     */
    readonly menuOpened: EventEmitter<void>;
    /**
     * 關閉時送出的事件。
     */
    readonly menuClosed: EventEmitter<void>;
    constructor(_overlay: Overlay, _element: ElementRef<HTMLElement>, _viewContainerRef: ViewContainerRef, scrollStrategy: any, parentMenu: CubNavMenuPanel, _menuItemInstance: CubNavMenuItem, _dir: Directionality, _focusMonitor: FocusMonitor | null, _ngZone: NgZone);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    triggersSubmenu(): boolean;
    toggleMenu(): void;
    openMenu(): void;
    closeMenu(): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    updatePosition(): void;
    _handleMousedown(event: MouseEvent): void;
    _handleKeydown(event: KeyboardEvent): void;
    _handleClick(event: MouseEvent): void;
    private _handleTouchStart;
    private _destroyMenu;
    private _initMenu;
    private _setMenuElevation;
    private _setIsMenuOpen;
    private _createOverlay;
    private _getOverlayConfig;
    private _subscribeToPositions;
    private _setPosition;
    private _menuClosingActions;
    private _handleHover;
    private _getPortal;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubNavMenuTriggerBase, [null, null, null, null, { optional: true; }, { optional: true; self: true; }, { optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubNavMenuTriggerBase, never, never, { "menu": { "alias": "cubNavMenuTriggerFor"; "required": false; }; "menuData": { "alias": "cubNavMenuTriggerData"; "required": false; }; "restoreFocus": { "alias": "cubNavMenuTriggerRestoreFocus"; "required": false; }; }, { "menuOpened": "menuOpened"; "menuClosed": "menuClosed"; }, never, never, true, never>;
}
declare class CubNavMenuTrigger extends _CubNavMenuTriggerBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNavMenuTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubNavMenuTrigger, "[cubNavMenuTriggerFor]", ["cubNavMenuTrigger"], {}, {}, never, never, true, never>;
}

declare function throwNavMenuInvalidPositionStart(): void;
declare function throwNavMenuInvalidPositionEnd(): void;
declare function throwNavMenuRecursiveError(): void;
declare function CUB_NAV_MENU_DEFAULT_OPTIONS_FACTORY(): CubNavMenuDefaultOptions;
declare function CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;

declare const CUB_NAV_MENU_PANEL: InjectionToken<CubNavMenuPanel<any>>;
declare const CUB_NAV_MENU_DEFAULT_OPTIONS: InjectionToken<CubNavMenuDefaultOptions>;
declare const CUB_NAV_MENU_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
declare const CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY;
};
declare const cubNavMenuAnimations: {
    readonly transformMenu: AnimationTriggerMetadata;
    readonly fadeInItems: AnimationTriggerMetadata;
};

declare class CubNavMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNavMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubNavMenuModule, never, [typeof i1.CubCdkScrollableModule, typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof CubNavMenu, typeof CubNavMenuItem, typeof CubNavMenuGroup, typeof CubNavMenuContent, typeof CubNavMenuTrigger], [typeof i1.CubCdkScrollableModule, typeof cub_lib_view_rootng_component_common.CubCommonModule, typeof CubNavMenu, typeof CubNavMenuItem, typeof CubNavMenuContent, typeof CubNavMenuTrigger, typeof CubNavMenuGroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubNavMenuModule>;
}

export { CUB_NAV_MENU_CONTENT, CUB_NAV_MENU_DEFAULT_OPTIONS, CUB_NAV_MENU_DEFAULT_OPTIONS_FACTORY, CUB_NAV_MENU_PANEL, CUB_NAV_MENU_SCROLL_STRATEGY, CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY, CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER, CubNavMenu, CubNavMenuContent, CubNavMenuGroup, CubNavMenuItem, CubNavMenuModule, CubNavMenuTrigger, _CubNavMenuContentBase, _CubNavMenuTriggerBase, cubNavMenuAnimations, throwNavMenuInvalidPositionEnd, throwNavMenuInvalidPositionStart, throwNavMenuRecursiveError };
export type { CubNavMenuCloseReason, CubNavMenuDefaultOptions, CubNavMenuPanel, CubNavMenuPositionEnd, CubNavMenuPositionStart };
