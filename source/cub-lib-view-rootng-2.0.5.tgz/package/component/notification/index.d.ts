import * as i0 from '@angular/core';
import { OnInit, AfterContentInit, OnDestroy, TemplateRef, EventEmitter, ElementRef, QueryList, ChangeDetectorRef } from '@angular/core';
import { CubThemeStatus, CubThemeColor, CubTemplate } from 'cub-lib-view-rootng/component/common';
import * as rxjs from 'rxjs';
import { Observable, Subject } from 'rxjs';

interface CubNotificationOptions {
    status?: CubThemeStatus;
    title?: string;
    message?: string;
    id?: string;
    key?: string;
    closable?: boolean;
    data?: any;
    icon?: string;
    contentStyleClass?: string;
    styleClass?: string;
    mainButton?: {
        label: string;
        color?: CubThemeColor;
        command$?: Observable<any>;
        isCloseButton?: boolean;
    };
    subButton?: {
        label?: string;
        command$?: Observable<any>;
        isCloseButton?: boolean;
    };
}

type CubNotificationId = string;

declare class CubNotificationService {
    notificationSource: Subject<CubNotificationOptions | CubNotificationOptions[]>;
    clearSource: Subject<string | undefined>;
    clearItemSource: Subject<{
        key?: string;
        id: string;
    }>;
    readonly notificationObserver: rxjs.Observable<CubNotificationOptions | CubNotificationOptions[]>;
    readonly clearObserver: rxjs.Observable<string | undefined>;
    readonly clearItemObserver: rxjs.Observable<{
        key?: string;
        id: string;
    }>;
    add(notification: CubNotificationOptions): CubNotificationId;
    addAll(notifications: CubNotificationOptions[]): CubNotificationId[];
    clear(key?: string): void;
    clearItem(id: string, key?: string): void;
    destroy(): void;
    private generateInsecureUuid;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubNotificationService>;
}

declare class CubNotification implements OnInit, AfterContentInit, OnDestroy {
    notificationService: CubNotificationService;
    private changeDetectorRef;
    notifications: CubNotificationOptions[];
    notificationsArchive: CubNotificationOptions[];
    templateRef: TemplateRef<any>;
    readonly preventOpenDuplicates = false;
    readonly preventDuplicates = false;
    readonly showTransformOptions = "translateY(-100%)";
    readonly hideTransformOptions = "translateY(-100%)";
    readonly showTransitionOptions = "300ms ease-out";
    readonly hideTransitionOptions = "250ms ease-in";
    private subscriptions;
    /**
     * 元件標籤值，用來對應指定的 Notification 元件，預設為 undefined。
     */
    key: string;
    /**
     * 元件樣式，預設為 undefined。
     */
    style: any;
    /**
     * 元件類別樣式，預設為 undefined。
     */
    styleClass: string;
    /**
     * 當關閉元件時發出通知。
     */
    closed: EventEmitter<{
        notification: CubNotificationOptions;
    }>;
    containerViewChild: ElementRef;
    templates: QueryList<CubTemplate>;
    constructor(notificationService: CubNotificationService, changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    onNotificationClose(event: {
        notification: CubNotificationOptions;
        index: number;
    }): void;
    private initializeSubscriptions;
    private setupTemplates;
    private handleNewNotifications;
    private handleClearNotifications;
    private handleClearItem;
    private addNotifications;
    private canAddNotification;
    private containsNotification;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNotification, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubNotification, "cub-notification", never, { "key": { "alias": "key"; "required": false; }; "style": { "alias": "style"; "required": false; }; "styleClass": { "alias": "styleClass"; "required": false; }; }, { "closed": "closed"; }, ["templates"], never, true, never>;
}

declare class CubNotificationItem implements OnInit, OnDestroy {
    private destroy$;
    /**
     * 元件訊息，預設為 undefined。
     */
    notification: CubNotificationOptions;
    /**
     * 元件標籤值，用來對應指定的 Notification Item 元件，預設為 undefined。
     */
    index: number;
    /**
     * 元件訊息樣板，預設為 undefined。
     */
    templateRef: TemplateRef<any>;
    /**
     * 元件顯示 Transform 的選項，預設為 undefined。
     */
    showTransformOptions: string;
    /**
     * 元件消失 Transform 的選項，預設為 undefined。
     */
    hideTransformOptions: string;
    /**
     * 元件顯示 Transition 的選項，預設為 undefined。
     */
    showTransitionOptions: string;
    /**
     *  元件消失 Transition 的選項，預設為 undefined。
     */
    hideTransitionOptions: string;
    /**
     * 當關閉元件時發出通知。
     */
    closed: EventEmitter<{
        index: number;
        notification: CubNotificationOptions;
    }>;
    containerViewChild: ElementRef;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * 點擊關閉按鈕
     */
    onCloseIconClick(event: MouseEvent): void;
    /**
     * 點擊主要動作按鈕
     */
    onMainButtonClick(event: MouseEvent): void;
    /**
     * 點擊次要動作按鈕
     */
    onSubButtonClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNotificationItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubNotificationItem, "cub-notification-item", never, { "notification": { "alias": "notification"; "required": false; }; "index": { "alias": "index"; "required": false; }; "templateRef": { "alias": "templateRef"; "required": false; }; "showTransformOptions": { "alias": "showTransformOptions"; "required": false; }; "hideTransformOptions": { "alias": "hideTransformOptions"; "required": false; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}

declare class CubNotificationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNotificationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubNotificationModule, never, [typeof CubNotification, typeof CubNotificationItem], [typeof CubNotification, typeof CubNotificationItem]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubNotificationModule>;
}

export { CubNotification, CubNotificationItem, CubNotificationModule, CubNotificationService };
export type { CubNotificationOptions };
