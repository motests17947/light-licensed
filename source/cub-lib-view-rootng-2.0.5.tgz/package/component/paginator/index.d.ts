import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CanDisable, CanDisableRipple } from 'cub-lib-view-rootng/component/common';
import * as i0 from '@angular/core';
import { ElementRef, OnInit, OnChanges, AfterViewInit, OnDestroy, EventEmitter, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';

interface CubPaginatorState {
    pageIndex: number;
    pageSize: number;
    pageCount?: number;
    first?: number;
    last?: number;
    totalRecords: number;
}

declare const _CubPaginatorMixinBase: cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & {
    new (_elementRef: ElementRef): {
        _elementRef: ElementRef;
    };
};
declare class CubPaginator extends _CubPaginatorMixinBase implements CanDisable, CanDisableRipple, OnInit, OnChanges, AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private _changeDetectorRef;
    pageLinks: number[];
    pageItems: any[];
    pageSizeItems: any[];
    paginatorState: CubPaginatorState;
    currentPageCtrl: FormControl<any>;
    isStreamlined: boolean;
    _pageLinkSize: number;
    _pageLinkSizeByContainerWidth: number;
    _pageIndex: number;
    private readonly _destroyed;
    private readonly _doCheckSubject;
    get pageRange(): string;
    /** 是否為禁用狀態，預設為 undefined。 */
    /** 是否禁用漣漪效果，預設為 undefined。 */
    /** 元件的行內樣式，預設為 undefined。 */
    style: any;
    /** 元件的類別樣式，預設為 undefined。 */
    styleClass: string;
    /** 當總頁數為一頁時是否顯示分頁器，預設為 true。 */
    alwaysShow: boolean;
    /** 頁數資訊的模板，預設為 '{first} - {last} / {totalRecords}'。 */
    pageRangeTemplate: string;
    /** 跳至指定頁數的模板，預設為 '跳至' */
    jumpToTemplate: string;
    /** 是否顯示頁數資訊，預設為 true。 */
    showPageRange: boolean;
    /** 是否顯示往第一頁與往最後一頁的按鈕，預設為 true。 */
    showFirstLastButton: boolean;
    /** 是否自動計算頁數連結的顯示個數，預設為 true。 */
    pageLinkAutoSize: boolean;
    /** 頁數連結的顯示個數，預設為 5。 */
    get pageLinkSize(): number;
    set pageLinkSize(value: number);
    /** 總筆數，預設為 0。 */
    totalRecords: number;
    /** 每頁顯示筆數，預設為 10。 */
    pageSize: number;
    /** 每頁顯示筆數選項，預設為 [10, 20, 30, 50, 100] */
    pageSizeOptions: any[];
    /** 是否隱藏每頁筆數的下拉選單，預設為 false。 */
    hidePageSize: boolean;
    /** 當前頁數的索引值，預設為 0。 */
    get pageIndex(): number;
    set pageIndex(value: number);
    /** 當頁面切換、顯示筆數變更或是排序更動時發出通知。 */
    pageChange: EventEmitter<any>;
    private _pagesContainer;
    onResize(event: any): void;
    constructor(elementRef: ElementRef, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(simpleChange: SimpleChanges): void;
    ngOnDestroy(): void;
    isFirstPage(): boolean;
    isLastPage(): boolean;
    changePage(pageIndex: number): void;
    changePageToFirst(event: any): void;
    changePageToPrev(event: any): void;
    changePageToNext(event: any): void;
    changePageToLast(event: any): void;
    onPageLinkClick(event: any, pageIndex: number): void;
    onPerPageChange(event: any): void;
    onPageBlur(control: FormControl): void;
    onPageKeydown(control: FormControl): void;
    empty(): boolean;
    private verifyControl;
    private getFirst;
    private getPageCount;
    private getCurrentPage;
    private calculatePageLinkBoundaries;
    private calculatePageLinkSizeByContainerWidth;
    private updatePageSizeOptions;
    private updatePageLinks;
    private updatePage;
    private updatePaginatorState;
    private isMobileWidth;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPaginator, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubPaginator, "cub-paginator", ["cubPaginator"], { "disabled": { "alias": "disabled"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "style": { "alias": "style"; "required": false; }; "styleClass": { "alias": "styleClass"; "required": false; }; "alwaysShow": { "alias": "alwaysShow"; "required": false; }; "pageRangeTemplate": { "alias": "pageRangeTemplate"; "required": false; }; "jumpToTemplate": { "alias": "jumpToTemplate"; "required": false; }; "showPageRange": { "alias": "showPageRange"; "required": false; }; "showFirstLastButton": { "alias": "showFirstLastButton"; "required": false; }; "pageLinkAutoSize": { "alias": "pageLinkAutoSize"; "required": false; }; "pageLinkSize": { "alias": "pageLinkSize"; "required": false; }; "totalRecords": { "alias": "totalRecords"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; }; "hidePageSize": { "alias": "hidePageSize"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; }, { "pageChange": "pageChange"; }, never, never, true, never>;
}

declare class CubPaginatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPaginatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubPaginatorModule, never, [typeof CubPaginator], [typeof CubPaginator]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubPaginatorModule>;
}

export { CubPaginator, CubPaginatorModule };
export type { CubPaginatorState };
