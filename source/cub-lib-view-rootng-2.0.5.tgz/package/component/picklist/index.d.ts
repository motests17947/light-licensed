import * as i0 from '@angular/core';
import { OnInit, AfterViewChecked, AfterContentInit, ChangeDetectorRef, TemplateRef, TrackByFunction, EventEmitter, ElementRef, QueryList } from '@angular/core';
import { CubCdkDragDrop } from 'cub-lib-view-rootng/cdk/drag-drop';
import * as i1 from 'cub-lib-view-rootng/component/common';
import { CubFilterService, CubThemeSize, CubTemplate } from 'cub-lib-view-rootng/component/common';
import { CubOption } from 'cub-lib-view-rootng/component/option';
import { CubCheckboxChange } from 'cub-lib-view-rootng/component/checkbox';

interface CubPickListFilterOptions {
    filter?: (value?: any) => void;
    reset?: () => void;
}

declare class CubPicklist implements OnInit, AfterViewChecked, AfterContentInit {
    cd: ChangeDetectorRef;
    filterService: CubFilterService;
    itemTemplateRef: TemplateRef<any>;
    visibleOptionsSource: any[];
    visibleOptionsTarget: any[];
    selectedItemsSource: any[];
    selectedItemsTarget: any[];
    reorderedListElement: any;
    multiple: boolean;
    movedUp: boolean;
    movedDown: boolean;
    filterValueSource: string;
    filterValueTarget: string;
    fromListType: number;
    emptyMessageSourceTemplateRef: TemplateRef<any>;
    emptyFilterMessageSourceTemplateRef: TemplateRef<any>;
    emptyMessageTargetTemplateRef: TemplateRef<any>;
    emptyFilterMessageTargetTemplateRef: TemplateRef<any>;
    sourceTitleTemplateRef: TemplateRef<any>;
    targetTilteTemplateRef: TemplateRef<any>;
    sourceFilterTemplateRef: TemplateRef<any>;
    targetFilterTemplateRef: TemplateRef<any>;
    sourceFilterOptions: CubPickListFilterOptions;
    targetFilterOptions: CubPickListFilterOptions;
    readonly SOURCE_LIST = -1;
    readonly TARGET_LIST = 1;
    get isSelectSourceAll(): boolean;
    get isSelectTargetAll(): boolean;
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 元件全選文字，預設為 '全選'。 */
    selectAllLabel: string;
    /** 來源列表的物件陣列，預設為 undefined。 */
    source: any[];
    /** 目標列表的物件陣列，預設為 undefined。 */
    target: any[];
    /** 來源列表的標題，預設為 undefined。 */
    sourceTitle: string;
    /** 目標列表的標題，預設為 undefined。 */
    targetTilte: string;
    /** 向右移動按鈕的 aria-label 屬性，預設為 undefined。 */
    rightButtonAriaLabel: string;
    /** 向左移動按鈕的 aria-label 屬性，預設為 undefined。 */
    leftButtonAriaLabel: string;
    /** 篩選清單時用來比對的欄位名稱（接受帶有逗號的多個欄位名稱），預設為 undefined。 */
    filterBy: string;
    /** 用於篩選清單的區域設置（預設區域設置是主機環境的當前區域設置），預設為 undefined。 */
    filterLocale: string;
    /**
     篩選清單的比對方式，預設為 'contains'。可取下列值之一：
     'contains'：篩選內容包含輸入值。
     'startsWith'：篩選內容以輸入值開頭。
     'endsWith'：篩選內容以輸入值結尾。
     'equals'：篩選內容與輸入值完全一致。
     'notEquals'：篩選內容與輸入值完全不一致。
     'lt'：篩選內容小於輸入值。
     'lte'：篩選內容小於等於輸入值。
     'gt'：篩選內容大於輸入值。
     'gte'：篩選內容大於等於輸入值。
     */
    filterMatchMode: string;
    /** 當啟用 filterBy 時，是否顯示來源列表的篩選器，預設為 true。 */
    showSourceFilter: boolean;
    /** 當啟用 filterBy 時，是否顯示目標列表的篩選器，預設為 true。 */
    showTargetFilter: boolean;
    /** 來源列表篩選器的 Placeholder，預設為 '請輸入關鍵字查詢'。 */
    sourceFilterPlaceholder: string;
    /** 目標列表篩選器的 Placeholder，預設為 '請輸入關鍵字查詢'。 */
    targetFilterPlaceholder: string;
    /** 來源列表篩選器的 aria-label 屬性，預設為 undefined。 */
    ariaSourceFilterLabel: string;
    /** 目標列表篩選器的 aria-label 屬性，預設為 undefined。 */
    ariaTargetFilterLabel: string;
    /** 來源列表無資料時顯示的文字，預設為 '無資料'。 */
    emptyMessageSource: string;
    /** 來源列表篩選清單無資料時顯示的文字，預設為 '無資料'。 */
    emptyFilterMessageSource: string;
    /** 目標列表無資料時顯示的文字，預設為 '無資料'。 */
    emptyMessageTarget: string;
    /** 目標列表篩選清單無資料時顯示的文字，預設為 '無資料'。 */
    emptyFilterMessageTarget: string;
    /** 透過 ngForTrackBy 來優化操作 dom 的函數，預設算法檢查物件標識（object identity），如果每個列表需要不同的算法，請使用 sourceTrackBy 或 targetTrackBy，預設為 (index: number, item: any) => item。 */
    trackBy: Function;
    /** 將選擇狀態保留在傳輸至的列表中，預設為 false。 */
    keepSelection: boolean;
    /** 是否啟用拖放功能，預設為 true。 */
    dragdrop: boolean;
    /** 元件的內聯樣式，預設為 undefined。 */
    style: any;
    /** 元件的樣式類別，預設為 undefined。 */
    styleClass: string;
    /** 來源列表元素的內聯樣式，預設為 undefined。 */
    sourceStyle: any;
    /** 目標列表元素的內聯樣式，預設為 undefined。 */
    targetStyle: any;
    /** 是否為禁用狀態，預設為 false。 */
    disabled: boolean;
    /** 透過來源列表中的 ngForTrackBy 來優化操作 dom 的函數，預設算法檢查物件標識（object identity），預設為 undefined。 */
    sourceTrackBy: TrackByFunction<any>;
    /** 透過目標列表中的 ngForTrackBy 來優化操作 dom 的函數，預設算法檢查物件標識（object identity），預設為 undefined。 */
    targetTrackBy: TrackByFunction<any>;
    /** 當項目從目標列表移動到來源列表時發出通知。 */
    moveToSource: EventEmitter<any>;
    /** 當項目從來源列表移動到目標列表時發出通知。 */
    moveToTarget: EventEmitter<any>;
    /** 當項目在來源列表中重新排序時發出通知。 */
    sourceReorder: EventEmitter<any>;
    /** 當項目在目標列表中重新排序時發出通知。 */
    targetReorder: EventEmitter<any>;
    /** 在來源列表中選擇項目時發出通知。 */
    sourceSelect: EventEmitter<any>;
    /** 在目標列表中選擇項目時發出通知。 */
    targetSelect: EventEmitter<any>;
    /** 篩選來源列表時發出通知。 */
    sourceFilter: EventEmitter<any>;
    /** 篩選目標列表時發出通知。 */
    targetFilter: EventEmitter<any>;
    listViewSourceChild: ElementRef;
    listViewTargetChild: ElementRef;
    sourceFilterViewChild: ElementRef;
    targetFilterViewChild: ElementRef;
    sourceOption: QueryList<CubOption>;
    targetOption: QueryList<CubOption>;
    templates: QueryList<CubTemplate>;
    constructor(cd: ChangeDetectorRef, filterService: CubFilterService);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngAfterViewChecked(): void;
    selectSourceAll(event: CubCheckboxChange): void;
    selectTargetAll(event: CubCheckboxChange): void;
    isSelectSourcePart(): boolean;
    isSelectTargetPart(): boolean;
    onSourceSelectionChange(item: any): void;
    onTargetSelectionChange(item: any): void;
    onFilter(event: KeyboardEvent, listType: number): void;
    onClear(input: any, listType: number): void;
    filterSource(value?: any): void;
    filterTarget(value?: any): void;
    filter(data: any[], listType: number): void;
    isItemVisible(item: any, listType: number): boolean;
    isEmpty(listType: number): boolean;
    isVisibleInList(data: any[], item: any, filterValue: string): boolean;
    moveRight(): void;
    moveLeft(): void;
    findIndexInSelection(item: any, selectedItems: any[]): number;
    onDrop(event: CubCdkDragDrop<string[]>, listType: number): void;
    getDropIndexes(fromIndex: any, toIndex: any, droppedList: any, isTransfer: any, data: any): {
        previousIndex: any;
        currentIndex: any;
    };
    findFilteredCurrentIndex(visibleOptions: any, index: any, options: any): number;
    resetSourceFilter(): void;
    resetTargetFilter(): void;
    resetFilter(): void;
    onSelectionKeydown(event: KeyboardEvent): void;
    findNextItem(item: any): any;
    findPrevItem(item: any): any;
    moveRightDisabled(): boolean;
    moveLeftDisabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPicklist, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubPicklist, "cub-picklist", never, { "size": { "alias": "size"; "required": false; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; }; "source": { "alias": "source"; "required": false; }; "target": { "alias": "target"; "required": false; }; "sourceTitle": { "alias": "sourceTitle"; "required": false; }; "targetTilte": { "alias": "targetTilte"; "required": false; }; "rightButtonAriaLabel": { "alias": "rightButtonAriaLabel"; "required": false; }; "leftButtonAriaLabel": { "alias": "leftButtonAriaLabel"; "required": false; }; "filterBy": { "alias": "filterBy"; "required": false; }; "filterLocale": { "alias": "filterLocale"; "required": false; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; }; "showSourceFilter": { "alias": "showSourceFilter"; "required": false; }; "showTargetFilter": { "alias": "showTargetFilter"; "required": false; }; "sourceFilterPlaceholder": { "alias": "sourceFilterPlaceholder"; "required": false; }; "targetFilterPlaceholder": { "alias": "targetFilterPlaceholder"; "required": false; }; "ariaSourceFilterLabel": { "alias": "ariaSourceFilterLabel"; "required": false; }; "ariaTargetFilterLabel": { "alias": "ariaTargetFilterLabel"; "required": false; }; "emptyMessageSource": { "alias": "emptyMessageSource"; "required": false; }; "emptyFilterMessageSource": { "alias": "emptyFilterMessageSource"; "required": false; }; "emptyMessageTarget": { "alias": "emptyMessageTarget"; "required": false; }; "emptyFilterMessageTarget": { "alias": "emptyFilterMessageTarget"; "required": false; }; "trackBy": { "alias": "trackBy"; "required": false; }; "keepSelection": { "alias": "keepSelection"; "required": false; }; "dragdrop": { "alias": "dragdrop"; "required": false; }; "style": { "alias": "style"; "required": false; }; "styleClass": { "alias": "styleClass"; "required": false; }; "sourceStyle": { "alias": "sourceStyle"; "required": false; }; "targetStyle": { "alias": "targetStyle"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "sourceTrackBy": { "alias": "sourceTrackBy"; "required": false; }; "targetTrackBy": { "alias": "targetTrackBy"; "required": false; }; }, { "moveToSource": "moveToSource"; "moveToTarget": "moveToTarget"; "sourceReorder": "sourceReorder"; "targetReorder": "targetReorder"; "sourceSelect": "sourceSelect"; "targetSelect": "targetSelect"; "sourceFilter": "sourceFilter"; "targetFilter": "targetFilter"; }, ["templates"], never, true, never>;
}

declare class CubPicklistModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPicklistModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubPicklistModule, never, [typeof i1.CubCommonModule, typeof CubPicklist], [typeof i1.CubCommonModule, typeof CubPicklist]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubPicklistModule>;
}

export { CubPicklist, CubPicklistModule };
export type { CubPickListFilterOptions };
