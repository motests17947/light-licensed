import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import * as i0 from '@angular/core';
import { OnDestroy, TemplateRef, ComponentFactoryResolver, ApplicationRef, Injector, ViewContainerRef, ChangeDetectorRef, InjectionToken, EventEmitter, ElementRef, OnInit, AfterContentInit } from '@angular/core';
import { Subject } from 'rxjs';
import { Direction, Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { OverlayRef, ScrollStrategy, Overlay } from 'cub-lib-view-rootng/cdk/overlay';
import { CubThemeColor } from 'cub-lib-view-rootng/component/common';
import * as cub_lib_view_rootng_component_popover from 'cub-lib-view-rootng/component/popover';
import { FocusOrigin, FocusMonitor } from 'cub-lib-view-rootng/cdk/a11y';

/**
 * Injection token that can be used to reference instances of `CubPopoverContent`. It serves
 * as alternative token to the actual `CubPopoverContent` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
declare const CUB_POPOVER_CONTENT: InjectionToken<CubPopoverContent>;
declare abstract class _CubPopoverContentBase implements OnDestroy {
    private _templateRef;
    private _componentFactoryResolver;
    private _appRef;
    private _injector;
    private _viewContainerRef;
    private _document;
    private _changeDetectorRef?;
    /** Emits when the popover content has been attached. */
    readonly _attached: Subject<void>;
    private _portal;
    private _outlet;
    constructor(_templateRef: TemplateRef<any>, _componentFactoryResolver: ComponentFactoryResolver, _appRef: ApplicationRef, _injector: Injector, _viewContainerRef: ViewContainerRef, _document: any, _changeDetectorRef?: ChangeDetectorRef | undefined);
    /**
     * Attaches the content with a particular context.
     * @docs-private
     */
    attach(context?: any): void;
    /**
     * Detaches the content.
     * @docs-private
     */
    detach(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubPopoverContentBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubPopoverContentBase, never, never, {}, {}, never, never, true, never>;
}
/**
 * Popover content that will be rendered lazily once the popover is opened.
 */
declare class CubPopoverContent extends _CubPopoverContentBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPopoverContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubPopoverContent, "ng-template[cubPopoverContent]", never, {}, {}, never, never, true, never>;
}

/** First value of popover's position. */
type CubPopoverPositionStart = 'above' | 'below' | 'before' | 'after';
/** Second value of popover's position. */
type CubPopoverPositionEnd = CubPopoverPositionStart | 'center';
/** Popover's trigger event. */
type CubPopoverTriggerEvent = 'click' | 'hover' | 'none';
/** Reason why the popover was closed. */
type CubPopoverCloseReason = void | 'click' | 'keydown' | 'tab' | 'actionClick' | 'cancelClick';

/**
 * Interface for a custom popover panel that can be used with `cubPopoverTriggerFor`.
 * @docs-private
 */
interface CubPopoverPanel {
    triggerEvent: CubPopoverTriggerEvent;
    enterDelay: number;
    leaveDelay: number;
    positionStart: CubPopoverPositionStart;
    positionEnd: CubPopoverPositionEnd;
    xOffset: number;
    yOffset: number;
    closeOnPanelClick: boolean;
    closeOnBackdropClick: boolean;
    closeDisabled: boolean;
    backdropClass?: string;
    overlayPanelClass?: string | string[];
    hasBackdrop?: boolean;
    hasArrow?: boolean;
    templateRef: TemplateRef<any>;
    lazyContent?: any;
    direction?: Direction;
    actionButtonText?: string;
    actionButtonColor?: CubThemeColor;
    cancelButtonText?: string;
    readonly panelId?: string;
    readonly closed: EventEmitter<CubPopoverCloseReason>;
    setCurrentStyles: (positionStart?: CubPopoverPositionStart, triggerRef?: ElementRef, overlayRef?: OverlayRef) => void;
    setPositionClasses: (positionStart?: CubPopoverPositionStart, positionEnd?: CubPopoverPositionEnd) => void;
}
/** Default `cub-popover` options that can be overridden. */
interface CubPopoverDefaultOptions {
    triggerEvent?: CubPopoverTriggerEvent;
    enterDelay?: number;
    leaveDelay?: number;
    positionEnd?: CubPopoverPositionEnd;
    positionStart?: CubPopoverPositionStart;
    xOffset?: number;
    yOffset?: number;
    arrowWidth?: number;
    arrowHeight?: number;
    arrowOffsetX?: number;
    arrowOffsetY?: number;
    closeOnPanelClick?: boolean;
    closeOnBackdropClick?: boolean;
    overlayPanelClass?: string;
    backdropClass?: string;
    hasBackdrop?: boolean;
    hasArrow?: boolean;
    autoFocus?: boolean;
}

declare class CubPopover implements CubPopoverPanel, OnInit, OnDestroy {
    protected _elementRef: ElementRef;
    protected _defaultOptions: CubPopoverDefaultOptions;
    /** Closing disabled on popover */
    closeDisabled: boolean;
    /** Layout direction of the popover. */
    direction?: Direction;
    /** Class or list of classes to be added to the overlay panel. */
    overlayPanelClass: string | string[];
    arrowStyles: Record<string, string>;
    arrowWidth: number;
    arrowHeight: number;
    arrowOffsetX: number;
    arrowOffsetY: number;
    /** Config object to be passed into the popover's ngClass. */
    _classList: {
        [key: string]: boolean;
    };
    /** Current state of the panel animation. */
    _panelAnimationState: 'void' | 'enter';
    /** Whether the popover is animating. */
    _isAnimating: boolean;
    /** Emits whenever an animation on the popover completes. */
    readonly _animationDone: Subject<AnimationEvent>;
    readonly panelId: string;
    protected _enterDelay: number;
    protected _leaveDelay: number;
    protected _positionStart: CubPopoverPositionStart;
    protected _positionEnd: CubPopoverPositionEnd;
    protected _panelOffsetX: number;
    protected _panelOffsetY: number;
    protected _autoFocus: boolean;
    protected _hasBackdrop: boolean | undefined;
    protected _hasArrow: boolean | undefined;
    protected _triggerEvent: CubPopoverTriggerEvent;
    protected _closeOnPanelClick: boolean;
    protected _closeOnBackdropClick: boolean;
    /**
     * 添加背景遮罩的Class名稱，預設值為 'cub-cdk-overlay-transparent-backdrop'。
     */
    backdropClass: string | undefined;
    /**
     * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabel?: string;
    /**
     * 添加 aria-labelledby 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaLabelledby?: string;
    /**
     * 添加 aria-describedby 屬性的值，在標題與欄位型別之後讀的描述內容(螢幕閱讀緝讀取用)，預設值為 undefined。
     */
    ariaDescribedby?: string;
    /**
     * 設定延遲開啟的時間(毫秒)，預設值為 100 毫秒。
     */
    get enterDelay(): number;
    set enterDelay(value: number);
    /**
     * 設定延遲關閉的時間(毫秒)，預設值為 100 毫秒。
     */
    get leaveDelay(): number;
    set leaveDelay(value: number);
    /**
     * 設定開啟得顯示位置, 預設為 'above'。
     */
    get positionStart(): CubPopoverPositionStart;
    set positionStart(value: CubPopoverPositionStart);
    /**
     * 設定開啟得對齊位置, 預設為 'center'。
     */
    get positionEnd(): CubPopoverPositionEnd;
    set positionEnd(value: CubPopoverPositionEnd);
    /**
     * 開啟位置X軸偏移，正數離定位點越近負數則越遠，預設值為 0。
     */
    get xOffset(): number;
    set xOffset(value: number);
    /**
     * 開啟位置Y軸偏移，正數離定位點越近負數則越遠，預設值為 0。
     */
    get yOffset(): number;
    set yOffset(value: number);
    /**
     * 是否在開啟時自動聚焦於第一個可聚焦元素。
     * */
    get autoFocus(): boolean;
    set autoFocus(value: boolean);
    /** 是否要有背景遮罩預設為 false 。*/
    get hasBackdrop(): boolean | undefined;
    set hasBackdrop(value: boolean | undefined);
    /** 是否要顯示箭頭，預設為 false 。*/
    get hasArrow(): boolean | undefined;
    set hasArrow(value: boolean | undefined);
    /** popover 開啟的驅動方式，有效值為 'click'、'hover'，預設值為 'click'。 */
    get triggerEvent(): CubPopoverTriggerEvent;
    set triggerEvent(value: CubPopoverTriggerEvent);
    /** 是否可以點擊彈窗面板來關閉彈窗，預設為 false。 */
    get closeOnPanelClick(): boolean;
    set closeOnPanelClick(value: BooleanInput);
    /** 是否可以點擊背景來關閉彈窗，預設為 true。 */
    get closeOnBackdropClick(): boolean;
    set closeOnBackdropClick(value: BooleanInput);
    /**
     * 關閉 popover 時送出關閉的事件。
     */
    closed: EventEmitter<CubPopoverCloseReason>;
    /** @docs-protected */
    templateRef: TemplateRef<any>;
    /**
     * Popover content that will be rendered lazily.
     * @docs-protected
     */
    lazyContent?: CubPopoverContent;
    constructor(_elementRef: ElementRef, _defaultOptions: CubPopoverDefaultOptions);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Starts the enter animation. */
    _startAnimation(): void;
    /** Resets the panel animation to its initial state. */
    _resetAnimation(): void;
    /** Callback that is invoked when the panel animation completes. */
    _onAnimationDone(event: AnimationEvent): void;
    _onAnimationStart(event: AnimationEvent): void;
    /** Handle a keyboard event from the popover, delegating to the appropriate action. */
    _handleKeydown(event: KeyboardEvent): void;
    /** Close popover on click if `closeOnPanelClick` is true. */
    _handleClick(): void;
    /** Disables close of popover when leaving trigger element and mouse over the popover. */
    _handleMouseOver(): void;
    /** Enables close of popover when mouse leaving popover element. */
    _handleMouseLeave(): void;
    /** Sets the current styles for the popover to allow for dynamically changing settings. */
    setCurrentStyles(positionStart?: CubPopoverPositionStart, triggerRef?: ElementRef, overlayRef?: OverlayRef): void;
    /**
     * It's necessary to set position-based classes to ensure the popover panel animation
     * folds out from the correct direction.
     */
    setPositionClasses(positionStart?: CubPopoverPositionStart, positionEnd?: CubPopoverPositionEnd): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPopover, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubPopover, "cub-popover", ["cubPopover"], { "backdropClass": { "alias": "backdropClass"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "enterDelay": { "alias": "enterDelay"; "required": false; }; "leaveDelay": { "alias": "leaveDelay"; "required": false; }; "positionStart": { "alias": "positionStart"; "required": false; }; "positionEnd": { "alias": "positionEnd"; "required": false; }; "xOffset": { "alias": "xOffset"; "required": false; }; "yOffset": { "alias": "yOffset"; "required": false; }; "autoFocus": { "alias": "autoFocus"; "required": false; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; }; "hasArrow": { "alias": "hasArrow"; "required": false; }; "triggerEvent": { "alias": "triggerEvent"; "required": false; }; "closeOnPanelClick": { "alias": "closeOnPanelClick"; "required": false; }; "closeOnBackdropClick": { "alias": "closeOnBackdropClick"; "required": false; }; }, { "closed": "closed"; }, ["lazyContent"], ["*"], true, never>;
}

declare class CubConfirmPopover extends CubPopover implements OnInit, OnDestroy {
    private elementRef;
    private defaultOptions;
    cancelButtonStyle: CubThemeColor;
    _actionButtonText: string;
    _actionButtonColor: CubThemeColor;
    _cancelButtonText: string;
    readonly panelId: string;
    protected _positionStart: cub_lib_view_rootng_component_popover.CubPopoverPositionStart;
    protected _positionEnd: cub_lib_view_rootng_component_popover.CubPopoverPositionEnd;
    protected _closeOnBackdropClick: boolean;
    protected _closeOnPanelClick: boolean;
    get triggerEvent(): CubPopoverTriggerEvent;
    set triggerEvent(value: CubPopoverTriggerEvent);
    get closeOnPanelClick(): boolean;
    get closeOnBackdropClick(): boolean;
    /**
     * 用於設定 cub-popover 元素的 class 預設值為 'cub-popover-above-center。'
     */
    set panelClass(classes: string);
    /**
     * 用於設定動作按鈕的顯示文字，預設值為 '確認'。
     */
    get actionButtonText(): string;
    set actionButtonText(text: string);
    /**
     * 用於設定動作按鈕的顯示樣式，預設值為 'error'。
     */
    get actionButtonColor(): CubThemeColor;
    set actionButtonColor(type: CubThemeColor);
    /**
     * 用於設定取消按鈕的顯示文字，預設值為 '取消'。
     */
    get cancelButtonText(): string;
    set cancelButtonText(text: string);
    panelElement: ElementRef;
    constructor(elementRef: ElementRef, defaultOptions: CubPopoverDefaultOptions);
    onActionClick(event: Event): void;
    onCancelClick(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubConfirmPopover, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubConfirmPopover, "cub-confirm-popover", ["cubConfirmPopover"], { "panelClass": { "alias": "class"; "required": false; }; "actionButtonText": { "alias": "actionButtonText"; "required": false; }; "actionButtonColor": { "alias": "actionButtonColor"; "required": false; }; "cancelButtonText": { "alias": "cancelButtonText"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class CubPopoverConnectedTo {
    elementRef: ElementRef;
    constructor(elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPopoverConnectedTo, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubPopoverConnectedTo, "cub-popover-target, [cubPopoverConnectedTo]", ["cubPopoverConnectedTo"], {}, {}, never, never, true, never>;
}

/** Injection token that determines the scroll handling while the popover is open. */
declare const CUB_POPOVER_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
/** @docs-private */
declare function CUB_POPOVER_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
/** @docs-private */
declare const CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_POPOVER_SCROLL_STRATEGY_FACTORY;
};
/**
 * This directive is intended to be used in conjunction with an `cub-popover` tag. It is
 * responsible for toggling the display of the provided popover instance.
 */
declare class CubPopoverTrigger implements AfterContentInit, OnDestroy {
    private _overlay;
    private _elementRef;
    private _viewContainerRef;
    private _dir;
    private _changeDetectorRef;
    private _focusMonitor?;
    /**
     * 綁定要啟用 popover 的事件，預設為 'click'。
     */
    triggerEvent?: CubPopoverTriggerEvent;
    _openedBy: Exclude<FocusOrigin, 'program' | null> | undefined;
    private _portal?;
    private _overlayRef;
    private _popoverOpen;
    private _halt;
    private _positionSubscription;
    private _popoverCloseSubscription;
    private _closingActionsSubscription;
    private _mouseoverTimer;
    private _popover;
    private _disabled;
    private _scrollStrategy;
    /** Whether the popover is open. */
    get popoverOpen(): boolean;
    /** The text direction of the containing app. */
    get dir(): Direction;
    /**
     * 綁定要顯示的 <cub-popover> 元件 預設為 undefined。
     */
    get popover(): CubPopoverPanel;
    set popover(popover: CubPopoverPanel);
    /**
     * 是否禁用 popover，預設為 false。
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * 要嵌入 <cub-popover> 的內容，預設為 undefined。
     */
    data: any;
    /**
     * 綁定 popover 定位點元件，預設值為 undefiend。
     */
    connectedTo?: CubPopoverConnectedTo;
    /**
     * 設定 popover 箭頭樣式，預設值為 true
     */
    hasArrow?: boolean;
    /**
     * 開啟 popover 時會回傳的事件。
     */
    opened: EventEmitter<void>;
    /**
     * 關閉 popover 時會回傳的事件。
     */
    closed: EventEmitter<CubPopoverCloseReason>;
    constructor(_overlay: Overlay, _elementRef: ElementRef<HTMLElement>, _viewContainerRef: ViewContainerRef, scrollStrategy: any, _dir: Directionality, _changeDetectorRef: ChangeDetectorRef, _focusMonitor?: FocusMonitor | undefined);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Handles mouse click on the trigger. */
    _handleClick(event: MouseEvent): void;
    /** Handles mouse enter on the trigger. */
    _handleMouseEnter(event: MouseEvent): void;
    /** Handles mouse leave on the trigger. */
    _handleMouseLeave(event: MouseEvent): void;
    /** Handles mouse presses on the trigger. */
    _handleMousedown(event: MouseEvent): void;
    /** Handles key presses on the trigger. */
    _handleKeydown(event: KeyboardEvent): void;
    /** Toggles the popover between the open and closed states. */
    togglePopover(): void;
    /** Opens the popover. */
    openPopover(): void;
    /** Closes the popover. */
    closePopover(): void;
    /**
     * Focuses the popover trigger.
     * @param origin Source of the popover trigger's focus.
     */
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    private _setCurrentConfig;
    /** Removes the popover from the DOM. */
    private _destroyPopover;
    /**
     * This method sets the popover state to open.
     */
    private _initPopover;
    private _setIsPopoverOpen;
    /**
     * This method checks that a valid instance of MdPopover has been passed into
     * `cubPopoverTriggerFor`. If not, an exception is thrown.
     */
    private _checkPopover;
    /**
     * This method creates the overlay from the provided popover's template and saves its
     * OverlayRef so that it can be attached to the DOM when openPopover is called.
     */
    private _createOverlay;
    /**
     * This method builds the configuration object needed to create the overlay, the OverlayConfig.
     * @returns OverlayConfig
     */
    private _getOverlayConfig;
    private _getTargetElement;
    /**
     * Listens to changes in the position of the overlay and sets the correct classes
     * on the popover based on the new position. This ensures the animation origin is always
     * correct, even if a fallback position is used for the overlay.
     */
    private _subscribeToPositions;
    /**
     * Sets the appropriate positions on a position strategy
     * so the overlay connects with the trigger correctly.
     * @param positionStrategy Strategy whose position to update.
     */
    private _setPosition;
    /** Returns a stream that emits whenever an action that should close the popover occurs. */
    private _popoverClosingActions;
    /** Gets the portal that should be attached to the overlay. */
    private _getPortal;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPopoverTrigger, [null, null, null, null, { optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubPopoverTrigger, "[cub-popover-trigger-for], [cubPopoverTriggerFor]", ["cubPopoverTrigger"], { "popover": { "alias": "cubPopoverTriggerFor"; "required": false; }; "disabled": { "alias": "cubPopoverDisabled"; "required": false; }; "data": { "alias": "cubPopoverData"; "required": false; }; "connectedTo": { "alias": "cubPopoverConnectedTo"; "required": false; }; "hasArrow": { "alias": "cubPopoverHasArrow"; "required": false; }; }, { "opened": "cubPopoverOpened"; "closed": "cubPopoverClosed"; }, never, never, true, never>;
}

/**
 * Below are all the animations for the cub-popover component.
 * Animation duration and timing values are based on AngularJS Material.
 */

/**
 * This animation controls the popover panel's entry and exit from the page.
 *
 * When the popover panel is added to the DOM, it scales in and fades in its border.
 *
 * When the popover panel is removed from the DOM, it simply fades out after a brief
 * delay to display the ripple.
 */
declare const transformPopover: AnimationTriggerMetadata;
/** Injection token to be used to override the default options for `cub-popover`. */
declare const CUB_POPOVER_DEFAULT_OPTIONS: InjectionToken<CubPopoverDefaultOptions>;
/** Injection token to be used to override the default options for `cub-confirm-popover`. */
declare const CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS: InjectionToken<CubPopoverDefaultOptions>;
declare const CUB_POPOVER_DEFAULT_DELAY_TIME = 100;

declare enum CUB_POPOVER_CLOSE_REASON {
    CLICK = "click",
    KEYDOWN = "keydown",
    TAB = "tab",
    ACTION_CLICK = "actionClick",
    CANCEL_CLICK = "cancelClick"
}

/**
 * Throws an exception for the case when popover trigger doesn't have a valid cub-popover instance
 */
declare function throwCubPopoverMissingError(): void;
/**
 * Throws an exception for the case when popover's positionStart value isn't valid.
 * In other words, it doesn't match 'above', 'below', 'before' or 'after'.
 */
declare function throwCubPopoverInvalidPositionStart(): void;
/**
 * Throws an exception for the case when popover's positionEnd value isn't valid.
 * In other words, it doesn't match 'above', 'below', 'before', 'after' or 'center'.
 */
declare function throwCubPopoverInvalidPositionEnd(): void;
/** @docs-private */
declare function CUB_POPOVER_DEFAULT_OPTIONS_FACTORY(): CubPopoverDefaultOptions;
/** @docs-private */
declare function CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS_FACTORY(): CubPopoverDefaultOptions;

declare class CubPopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubPopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubPopoverModule, never, [typeof CubPopover, typeof CubConfirmPopover, typeof CubPopoverTrigger, typeof CubPopoverConnectedTo, typeof CubPopoverContent], [typeof CubPopover, typeof CubConfirmPopover, typeof CubPopoverTrigger, typeof CubPopoverConnectedTo, typeof CubPopoverContent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubPopoverModule>;
}

export { CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS, CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS_FACTORY, CUB_POPOVER_CLOSE_REASON, CUB_POPOVER_CONTENT, CUB_POPOVER_DEFAULT_DELAY_TIME, CUB_POPOVER_DEFAULT_OPTIONS, CUB_POPOVER_DEFAULT_OPTIONS_FACTORY, CUB_POPOVER_SCROLL_STRATEGY, CUB_POPOVER_SCROLL_STRATEGY_FACTORY, CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER, CubConfirmPopover, CubPopover, CubPopoverConnectedTo, CubPopoverContent, CubPopoverModule, CubPopoverTrigger, _CubPopoverContentBase, throwCubPopoverInvalidPositionEnd, throwCubPopoverInvalidPositionStart, throwCubPopoverMissingError, transformPopover };
export type { CubPopoverCloseReason, CubPopoverDefaultOptions, CubPopoverPanel, CubPopoverPositionEnd, CubPopoverPositionStart, CubPopoverTriggerEvent };
