import * as i0 from '@angular/core';
import { QueryList, EventEmitter, ElementRef } from '@angular/core';
import { CubThemeSize } from 'cub-lib-view-rootng/component/common';
import * as i4 from 'cub-lib-view-rootng/component/button';
import { CubHyperlink } from 'cub-lib-view-rootng/component/button';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';
import * as i3 from 'cub-lib-view-rootng/component/input';

declare class CubResourceItem {
    private host;
    _hyperlinkChildren: QueryList<CubHyperlink>;
    /**
     * 元件 size 屬性，預設為 medium。
     */
    size: CubThemeSize;
    /**
     * 元件 error 狀態，預設為 false。
     */
    hasError: boolean;
    /**
     * 元件是否禁用，預設為 false。
     */
    disabled: boolean;
    /**
     * 元件 loading 狀態，預設為 false。
     */
    loading: boolean;
    /**
     * 元件 extraInfo 字串顯示，預設為 null。
     */
    extraInfo: string | null;
    /**
     * 超連結預設字串，預設為 '連結'。
     */
    hyperlinkText: string;
    /**
     是否隱藏關閉按鈕，預設為 false。
     */
    hideClose: boolean;
    /**
     * 當關閉元件時發出通知。
     */
    closed: EventEmitter<void>;
    constructor(host: ElementRef<HTMLElement>);
    ngAfterContentChecked(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubResourceItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubResourceItem, "cub-resource-item", never, { "size": { "alias": "size"; "required": false; }; "hasError": { "alias": "hasError"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "extraInfo": { "alias": "extraInfo"; "required": false; }; "hyperlinkText": { "alias": "hyperlinkText"; "required": false; }; "hideClose": { "alias": "hideClose"; "required": false; }; }, { "closed": "closed"; }, ["_hyperlinkChildren"], ["a[cub-hyperlink]"], true, never>;
}

declare class CubResourceItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubResourceItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubResourceItemModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof i4.CubButtonModule, typeof CubResourceItem], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof i4.CubButtonModule, typeof CubResourceItem]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubResourceItemModule>;
}

export { CubResourceItem, CubResourceItemModule };
