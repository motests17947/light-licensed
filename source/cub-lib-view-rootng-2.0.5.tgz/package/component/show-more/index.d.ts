import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter } from '@angular/core';

declare class CubShowMore implements OnDestroy {
    private _expanded;
    private _changeDetectorRef;
    private hostElement;
    /**
     * 元件是否為展開狀態，預設值為 false。
     */
    get expanded(): boolean;
    set expanded(expanded: boolean);
    /**
     * 元件是否為禁用狀態，預設值為 false。
     */
    disabled: boolean;
    /**
     * 當元件收起時送出事件。
     */
    readonly closed: EventEmitter<void>;
    /**
     * 當元件展開時送出事件。
     */
    readonly opened: EventEmitter<void>;
    /**
     * 當元件實體被摧毀時送出事件。
     */
    readonly destroyed: EventEmitter<void>;
    /**
     * 當 expanded 狀態改變時送出事件。
     */
    readonly expandedChange: EventEmitter<boolean>;
    onTransitionEnd(event: TransitionEvent): void;
    ngOnDestroy(): void;
    toggle(): void;
    close(): void;
    open(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubShowMore, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubShowMore, "[cubShowMore]", ["cubShowMore"], { "expanded": { "alias": "expanded"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "closed": "closed"; "opened": "opened"; "destroyed": "destroyed"; "expandedChange": "expandedChange"; }, never, never, true, never>;
    static ngAcceptInputType_expanded: unknown;
    static ngAcceptInputType_disabled: unknown;
}

declare class CubShowMoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubShowMoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubShowMoreModule, never, [typeof CubShowMore], [typeof CubShowMore]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubShowMoreModule>;
}

export { CubShowMore, CubShowMoreModule };
