import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CubRipple, CubRippleGlobalOptions, CanDisableRipple, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import * as i0 from '@angular/core';
import { ElementRef, AfterViewInit, OnDestroy, NgZone, ChangeDetectorRef, EventEmitter, QueryList, InjectionToken } from '@angular/core';
import { Platform, Directionality, BooleanInput, NumberInput } from 'cub-lib-view-rootng/cdk';
import { ControlValueAccessor } from '@angular/forms';
import { Subject } from 'rxjs';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';
import * as i3 from 'cub-lib-view-rootng/component/input';

declare const enum _CubThumb {
    START = 1,
    END = 2
}
declare const enum _CubTickMark {
    ACTIVE = 0,
    INACTIVE = 1
}

interface CubSliderDragEvent {
    source: _CubSliderThumb;
    parent: _CubSlider;
    value: number;
}
interface _CubSlider {
    _getInput(thumbPosition: _CubThumb): _CubSliderThumb | _CubSliderRangeThumb | undefined;
    _getThumb(thumbPosition: _CubThumb): _CubSliderVisualThumb;
    min: number;
    max: number;
    step: number;
    disabled: boolean;
    _isRange: boolean;
    _isRtl: boolean;
    _cachedWidth: number;
    _cachedLeft: number;
    _inputPadding: number;
    _inputOffset: number;
    _rippleRadius: number;
    readonly _globalRippleOptions?: CubRippleGlobalOptions;
    _noopAnimations: boolean;
    _hasAnimation: boolean;
    _onValueChange: (source: _CubSliderThumb) => void;
    _onTranslateXChange: (source: _CubSliderThumb) => void;
    _updateDimensions: () => void;
    _updateThumbUI: (source: _CubSliderThumb) => void;
    _setTransition: (withAnimation: boolean) => void;
}
interface _CubSliderThumb {
    min: number;
    max: number;
    step: number;
    value: number;
    translateX: number;
    thumbPosition: _CubThumb;
    fillPercentage: number;
    disabled: boolean;
    _hostElement: HTMLInputElement;
    _isFocused: boolean;
    _valuetext: string;
    _skipUIUpdate: boolean;
    initProps: () => void;
    initUI: () => void;
    _calcTranslateXByValue: () => number;
    _updateThumbUIByValue: () => void;
    _updateThumbUIByPointerEvent: (event: PointerEvent) => void;
}
interface _CubSliderRangeThumb extends _CubSliderThumb {
    _isLeftThumb: boolean;
    getSibling: () => _CubSliderRangeThumb | undefined;
    _setIsLeftThumb: () => void;
    _updateStaticStyles: () => void;
    _updateMinMax: () => void;
}
interface _CubSliderVisualThumb {
    _ripple: CubRipple;
    _isActive: boolean;
    _hostElement: HTMLElement;
    _showValueIndicator: () => void;
    _hideValueIndicator: () => void;
    _isShowingAnyRipple: () => boolean;
}

declare const _CubSliderMixinBase: cub_lib_view_rootng_component_common.Constructor<cub_lib_view_rootng_component_common.CanColor> & cub_lib_view_rootng_component_common.AbstractConstructor<cub_lib_view_rootng_component_common.CanColor> & cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & {
    new (_elementRef: ElementRef<HTMLElement>): {
        _elementRef: ElementRef<HTMLElement>;
    };
};
/** 'disableRipple' 是否禁用漣漪效果，預設為 undefined。 */
declare class CubSlider extends _CubSliderMixinBase implements AfterViewInit, CanDisableRipple, OnDestroy, _CubSlider {
    readonly _ngZone: NgZone;
    readonly _cdr: ChangeDetectorRef;
    readonly _platform: Platform;
    readonly _dir: Directionality;
    readonly _globalRippleOptions?: CubRippleGlobalOptions | undefined;
    _tickMarks: _CubTickMark[];
    _noopAnimations: boolean;
    _cachedWidth: number;
    _cachedLeft: number;
    _rippleRadius: number;
    _endThumbTransform: string;
    _startThumbTransform: string;
    _endTransform: number;
    _isRange: boolean;
    _isRtl: boolean;
    _tickMarkTrackWidth: number;
    _hasAnimation: boolean;
    _knobRadius: number;
    _inputPadding: number;
    _inputOffset: number;
    protected startValueIndicatorText: string;
    protected endValueIndicatorText: string;
    private _disabled;
    private _discrete;
    private _showTickMarks;
    private _min;
    private _max;
    private _tickStep;
    private _step;
    private _hasViewInitialized;
    private _resizeTimer;
    private _dirChangeSubscription;
    private _resizeObserver;
    private _thumbsOverlap;
    /**
     * 用於在元件中顯示數值前進行格式化的函數。
     * 可用於格式化非常大的數字，以便它們能夠適合顯示於標籤內。
     */
    displayWith: number;
    /** 尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    /** 元件是否禁用，預設為 false。 */
    get disabled(): boolean;
    set disabled(v: BooleanInput);
    /** 元件是否在按下時顯示數值標籤，預設為 false。【暫不開放使用】 */
    get discrete(): boolean;
    set discrete(v: BooleanInput);
    /** 元件是否沿著軌道顯示刻度標記，預設為 false。 */
    get showTickMarks(): boolean;
    set showTickMarks(v: BooleanInput);
    /** 元件的最小值，預設為 0。 */
    get min(): number;
    set min(v: NumberInput);
    /** 滑桿可以擁有的最大值，預設為 100。 */
    get max(): number;
    set max(v: NumberInput);
    /** 用於顯示刻度的間隔 (不影響滑動) */
    get tickStep(): number;
    set tickStep(v: NumberInput);
    /** 元件移動時的數值間隔，預設為 0。 */
    get step(): number;
    set step(v: NumberInput);
    displayWithChange: EventEmitter<number>;
    _trackActive: ElementRef<HTMLElement>;
    _thumbs: QueryList<_CubSliderVisualThumb>;
    _input: _CubSliderThumb;
    _inputs: QueryList<_CubSliderRangeThumb>;
    constructor(_ngZone: NgZone, _cdr: ChangeDetectorRef, _platform: Platform, elementRef: ElementRef<HTMLElement>, _dir: Directionality, _globalRippleOptions?: CubRippleGlobalOptions | undefined, animationMode?: string);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    resetToMinValue(): void;
    _updateDimensions(): void;
    _setTrackActiveStyles(styles: {
        left: string;
        right: string;
        transform: string;
        transformOrigin: string;
    }): void;
    _calcTickMarkTransform(index: number): string;
    _onTranslateXChange(source: _CubSliderThumb): void;
    _onTranslateXChangeBySideEffect(input1: _CubSliderRangeThumb, input2: _CubSliderRangeThumb): void;
    _onValueChange(source: _CubSliderThumb): void;
    _onMinMaxOrStepChange(): void;
    _onResize(): void;
    _updateThumbUI(source: _CubSliderThumb): void;
    _updateTrackUI(source: _CubSliderThumb): void;
    _updateValueIndicatorUI(source: _CubSliderThumb): void;
    _updateTickMarkUI(): void;
    _getInput(thumbPosition: _CubThumb): _CubSliderThumb | _CubSliderRangeThumb | undefined;
    _getThumb(thumbPosition: _CubThumb): _CubSliderVisualThumb;
    _setTransition(withAnimation: boolean): void;
    private _isNotMinValue;
    private _updateActiveClass;
    private _updateMax;
    private _updateMin;
    private _updateMinRange;
    private _updateMinNonRange;
    private _updateMaxRange;
    private _updateMaxNonRange;
    private _updateStep;
    private _updateStepRange;
    private _initUINonRange;
    private _initUIRange;
    private _updateStepNonRange;
    private _onDirChange;
    private _onDirChangeRange;
    private _onDirChangeNonRange;
    private _observeHostResize;
    private _isActive;
    private _getValue;
    private _skipUpdate;
    private _areThumbsOverlapping;
    private _updateOverlappingThumbClassNames;
    private _updateOverlappingThumbUI;
    private _updateValueIndicatorUIs;
    private _updateTickMarkTrackUI;
    private _updateTrackUIRange;
    private _updateTrackUINonRange;
    private _updateTickMarkUINonRange;
    private _updateTickMarkUIRange;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSlider, [null, null, null, null, { optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubSlider, "cub-slider", ["cubSlider"], { "disableRipple": { "alias": "disableRipple"; "required": false; }; "displayWith": { "alias": "displayWith"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "showTickMarks": { "alias": "showTickMarks"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "tickStep": { "alias": "tickStep"; "required": false; }; "step": { "alias": "step"; "required": false; }; }, { "displayWithChange": "displayWithChange"; }, ["_input", "_inputs"], ["*"], true, never>;
}

declare class CubSliderVisualThumb implements _CubSliderVisualThumb, AfterViewInit, OnDestroy {
    readonly _cdr: ChangeDetectorRef;
    private _platform;
    private readonly _ngZone;
    private _slider;
    _isActive: boolean;
    _isValueIndicatorVisible: boolean;
    _hostElement: HTMLElement;
    private _sliderInput;
    private _sliderInputEl;
    private _hoverRippleRef;
    private _focusRippleRef;
    private _activeRippleRef;
    private _isHovered;
    get rippleDisabled(): boolean;
    /**
     * 【暫不開放使用，已討論未來會開放】
     * 父層移除 @Input()，內層先保留
     * 是否在按下滑塊時顯示數值標籤，預設為 undefined。 */
    discrete: boolean;
    /** 指示此輸入對應到哪個滑桿滑塊，預設為 undefined。 */
    thumbPosition: _CubThumb;
    /** 元件的顯示數值，預設為 undefined。 */
    valueIndicatorText: string;
    readonly _ripple: CubRipple;
    _knob: ElementRef<HTMLElement>;
    _valueIndicatorContainer: ElementRef<HTMLElement>;
    constructor(_cdr: ChangeDetectorRef, _platform: Platform, _ngZone: NgZone, _elementRef: ElementRef<HTMLElement>, _slider: _CubSlider);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    _showValueIndicator(): void;
    _hideValueIndicator(): void;
    _getSibling(): _CubSliderVisualThumb;
    _getValueIndicatorContainer(): HTMLElement | undefined;
    _getKnob(): HTMLElement;
    _isShowingAnyRipple(): boolean;
    private _onPointerMove;
    private _onMouseLeave;
    private _platformSupportsMouseEvents;
    private _onFocus;
    private _onBlur;
    private _onDragStart;
    private _onDragEnd;
    private _showActiveRipple;
    private _isShowingRipple;
    private _showRipple;
    private _hideRipple;
    private _isSliderThumbHovered;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSliderVisualThumb, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubSliderVisualThumb, "cub-slider-thumb", never, { "discrete": { "alias": "discrete"; "required": false; }; "thumbPosition": { "alias": "thumbPosition"; "required": false; }; "valueIndicatorText": { "alias": "valueIndicatorText"; "required": false; }; }, {}, never, never, true, never>;
}

declare const CUB_SLIDER_THUMB_VALUE_ACCESSOR: any;
declare const CUB_SLIDER_RANGE_THUMB_VALUE_ACCESSOR: any;
declare class CubSliderThumb implements _CubSliderThumb, OnDestroy, ControlValueAccessor {
    readonly _ngZone: NgZone;
    readonly _elementRef: ElementRef<HTMLInputElement>;
    readonly _cdr: ChangeDetectorRef;
    protected _slider: _CubSlider;
    thumbPosition: _CubThumb;
    _hostElement: HTMLInputElement;
    _valuetext: string;
    _knobRadius: number;
    _isActive: boolean;
    _isFocused: boolean;
    _initialValue: string | undefined;
    _skipUIUpdate: boolean;
    protected readonly _destroyed: Subject<void>;
    protected _sibling: CubSliderRangeThumb | undefined;
    private _translateX;
    private _hasSetInitialValue;
    private _formControl;
    get translateX(): number;
    set translateX(v: number);
    get min(): number;
    set min(v: NumberInput);
    get max(): number;
    set max(v: NumberInput);
    get step(): number;
    set step(v: NumberInput);
    get disabled(): boolean;
    set disabled(v: BooleanInput);
    get percentage(): number;
    get fillPercentage(): number;
    /** 元件輸入的當前值，預設為 undefined。 */
    get value(): number;
    set value(value: NumberInput);
    /** 當 `value` 改變時發出的事件。 */
    readonly valueChange: EventEmitter<number>;
    /** 當滑桿滑塊開始被拖拽時發出的事件。 */
    readonly dragStart: EventEmitter<CubSliderDragEvent>;
    /** 當滑桿滑塊停止被拖拽時發出的事件。 */
    readonly dragEnd: EventEmitter<CubSliderDragEvent>;
    constructor(_ngZone: NgZone, _elementRef: ElementRef<HTMLInputElement>, _cdr: ChangeDetectorRef, _slider: _CubSlider);
    ngOnDestroy(): void;
    initProps(): void;
    initUI(): void;
    _initValue(): void;
    _getDefaultValue(): number;
    _onBlur(): void;
    _onFocus(): void;
    _onChange(): void;
    _onInput(): void;
    _onNgControlValueChange(): void;
    _onPointerDown(event: PointerEvent): void;
    _fixValue(event: PointerEvent): void;
    _onPointerMove(event: PointerEvent): void;
    _onPointerUp(): void;
    _clamp(v: number): number;
    _calcTranslateXByValue(): number;
    _calcTranslateXByPointerEvent(event: PointerEvent): number;
    _updateThumbUIByValue(options?: {
        withAnimation: boolean;
    }): void;
    _updateThumbUIByPointerEvent(event: PointerEvent, options?: {
        withAnimation: boolean;
    }): void;
    _updateThumbUI(options?: {
        withAnimation: boolean;
    }): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    focus(): void;
    blur(): void;
    private _onChangeFn;
    private _onTouchedFn;
    private _setIsFocused;
    private _handleValueCorrection;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSliderThumb, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubSliderThumb, "input[cubSliderThumb]", ["cubSliderThumb"], { "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; "dragStart": "dragStart"; "dragEnd": "dragEnd"; }, never, never, true, never>;
}
declare class CubSliderRangeThumb extends CubSliderThumb implements _CubSliderRangeThumb {
    readonly _cdr: ChangeDetectorRef;
    _isLeftThumb: boolean;
    _isEndThumb: boolean;
    constructor(_ngZone: NgZone, _slider: _CubSlider, _elementRef: ElementRef<HTMLInputElement>, _cdr: ChangeDetectorRef);
    getSibling(): _CubSliderRangeThumb | undefined;
    getMinPos(): number;
    getMaxPos(): number;
    _setIsLeftThumb(): void;
    _getDefaultValue(): number;
    _onInput(): void;
    _onNgControlValueChange(): void;
    _onPointerDown(event: PointerEvent): void;
    _onPointerUp(): void;
    _onPointerMove(event: PointerEvent): void;
    _fixValue(event: PointerEvent): void;
    _clamp(v: number): number;
    _updateMinMax(): void;
    writeValue(value: any): void;
    _updateStaticStyles(): void;
    private _updateSibling;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSliderRangeThumb, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubSliderRangeThumb, "input[cubSliderStartThumb], input[cubSliderEndThumb]", ["cubSliderRangeThumb"], {}, {}, never, never, true, never>;
}

declare class CubSliderChange {
    source: _CubSliderThumb;
    parent: _CubSlider;
    value: number;
}

declare const CUB_SLIDER: InjectionToken<object>;
declare const CUB_SLIDER_THUMB: InjectionToken<object>;
declare const CUB_SLIDER_RANGE_THUMB: InjectionToken<object>;
declare const CUB_SLIDER_VISUAL_THUMB: InjectionToken<object>;

declare class CubSliderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSliderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubSliderModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubSlider, typeof CubSliderVisualThumb, typeof CubSliderThumb, typeof CubSliderRangeThumb], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubSlider, typeof CubSliderVisualThumb, typeof CubSliderThumb, typeof CubSliderRangeThumb]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubSliderModule>;
}

export { CUB_SLIDER, CUB_SLIDER_RANGE_THUMB, CUB_SLIDER_RANGE_THUMB_VALUE_ACCESSOR, CUB_SLIDER_THUMB, CUB_SLIDER_THUMB_VALUE_ACCESSOR, CUB_SLIDER_VISUAL_THUMB, CubSlider, CubSliderChange, CubSliderModule, CubSliderRangeThumb, CubSliderThumb, CubSliderVisualThumb, _CubThumb, _CubTickMark };
export type { CubSliderDragEvent, _CubSlider, _CubSliderRangeThumb, _CubSliderThumb, _CubSliderVisualThumb };
