import * as cub_lib_view_rootng_component_common from 'cub-lib-view-rootng/component/common';
import { CubThemeColor, HasTabIndex, CanColor, CanDisableRipple, CanDisable, CubThemeSize } from 'cub-lib-view-rootng/component/common';
import * as i0 from '@angular/core';
import { InjectionToken, ElementRef, OnDestroy, AfterContentInit, ChangeDetectorRef, EventEmitter, Provider } from '@angular/core';
import { ControlValueAccessor, CheckboxRequiredValidator } from '@angular/forms';
import { BooleanInput } from 'cub-lib-view-rootng/cdk/coercion';
import { FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';
import * as i3 from 'cub-lib-view-rootng/component/input';

declare class CubSwitchChange {
    source: CubSwitch;
    checked: boolean;
    constructor(source: CubSwitch, checked: boolean);
}

interface CubSwitchDefaultOptions {
    disableToggleValue?: boolean;
    color?: CubThemeColor;
}
declare const CUB_SWITCH_DEFAULT_OPTIONS: InjectionToken<CubSwitchDefaultOptions>;

declare const CUB_SWITCH_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare const _CubSwitchMixinBase: cub_lib_view_rootng_component_common.Constructor<HasTabIndex> & cub_lib_view_rootng_component_common.AbstractConstructor<HasTabIndex> & cub_lib_view_rootng_component_common.Constructor<CanColor> & cub_lib_view_rootng_component_common.AbstractConstructor<CanColor> & cub_lib_view_rootng_component_common.Constructor<CanDisableRipple> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisableRipple> & cub_lib_view_rootng_component_common.Constructor<CanDisable> & cub_lib_view_rootng_component_common.AbstractConstructor<CanDisable> & {
    new (_elementRef: ElementRef): {
        _elementRef: ElementRef;
    };
};
declare abstract class _CubSwitchBase<T> extends _CubSwitchMixinBase implements OnDestroy, AfterContentInit, ControlValueAccessor, CanDisable, CanColor, HasTabIndex, CanDisableRipple {
    protected _focusMonitor: FocusMonitor;
    protected _changeDetectorRef: ChangeDetectorRef;
    defaults: CubSwitchDefaultOptions;
    _focused: boolean;
    protected _uniqueId: string;
    private _required;
    private _checked;
    abstract focus(options?: FocusOptions, origin?: FocusOrigin): void;
    protected abstract _createChangeEvent(isChecked: boolean): T;
    get inputId(): string;
    /** 元件名稱，用於表單提交，預設為 null。 */
    name: string | null;
    /** 元件唯一識別符，預設為 undefined。 */
    id: string;
    /** 元件尺寸，預設為 'medium' */
    size: CubThemeSize;
    /** 元件標籤顯示位置，預設為 'after' */
    labelPosition: 'before' | 'after';
    /** 元件標題（螢幕閱讀器讀取用），預設為 null。 */
    ariaLabel: string | null;
    /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
    ariaLabelledby: string | null;
    /** 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 undefined。 */
    ariaDescribedby: string;
    /** 元件是否為必填，預設為 false。 */
    get required(): boolean;
    set required(value: BooleanInput);
    /** 元件是否被選中，預設為 false。 */
    get checked(): boolean;
    set checked(value: BooleanInput);
    /** 當元件狀態變更（如 checked 狀態改變）時發出的事件，會帶有變更後的資料。 */
    readonly change: EventEmitter<T>;
    /**  當元件被切換（不論狀態是否真的改變）時發出的事件，不帶任何資料。 */
    readonly toggleChange: EventEmitter<void>;
    constructor(elementRef: ElementRef, _focusMonitor: FocusMonitor, _changeDetectorRef: ChangeDetectorRef, tabIndex: string, defaults: CubSwitchDefaultOptions, idPrefix: string);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    toggle(): void;
    protected _emitChangeEvent(): void;
    protected _onChange: (_: any) => void;
    protected _onTouched: () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_CubSwitchBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_CubSwitchBase<any>, never, never, { "name": { "alias": "name"; "required": false; }; "id": { "alias": "id"; "required": false; }; "size": { "alias": "size"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "required": { "alias": "required"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; }, { "change": "change"; "toggleChange": "toggleChange"; }, never, never, true, never>;
}
declare class CubSwitch extends _CubSwitchBase<CubSwitchChange> {
    _inputElement: ElementRef<HTMLInputElement>;
    constructor(elementRef: ElementRef, focusMonitor: FocusMonitor, changeDetectorRef: ChangeDetectorRef, tabIndex: string, defaults: CubSwitchDefaultOptions);
    focus(options?: FocusOptions, origin?: FocusOrigin): void;
    _onChangeEvent(event: Event): void;
    _onInputClick(event: Event): void;
    _onLabelTextChange(): void;
    _handleKeydown(event: KeyboardEvent): void;
    protected _createChangeEvent(isChecked: boolean): CubSwitchChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSwitch, [null, null, null, { attribute: "tabindex"; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubSwitch, "cub-switch", ["cubSwitch"], { "disabled": { "alias": "disabled"; "required": false; }; "disableRipple": { "alias": "disableRipple"; "required": false; }; "color": { "alias": "color"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare const CUB_SWITCH_BUTTON_REQUIRED_VALIDATOR: Provider;
declare class CubSwitchRequiredValidator extends CheckboxRequiredValidator {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSwitchRequiredValidator, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubSwitchRequiredValidator, "cub-switch-button[required][formControlName],  cub-switch-button[required][formControl], cub-switch-button[required][ngModel]", never, {}, {}, never, never, true, never>;
}

declare class CubSwitchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubSwitchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubSwitchModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubSwitch, typeof CubSwitchRequiredValidator], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubSwitch, typeof CubSwitchRequiredValidator]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubSwitchModule>;
}

export { CUB_SWITCH_BUTTON_REQUIRED_VALIDATOR, CUB_SWITCH_DEFAULT_OPTIONS, CUB_SWITCH_VALUE_ACCESSOR, CubSwitch, CubSwitchChange, CubSwitchModule, CubSwitchRequiredValidator, _CubSwitchBase };
export type { CubSwitchDefaultOptions };
