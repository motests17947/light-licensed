import { CubThemeSize } from 'cub-lib-view-rootng/component/common';
import * as i0 from '@angular/core';

type CubTagColor = 'gray' | 'green' | 'orange' | 'red' | 'blue' | 'purple';

declare class CubTag {
    /** 元件顏色，預設為 'green' */
    color: CubTagColor;
    /** 尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTag, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubTag, "cub-tag", never, { "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class CubTagModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTagModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubTagModule, never, [typeof CubTag], [typeof CubTag]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubTagModule>;
}

export { CubTag, CubTagModule };
export type { CubTagColor };
