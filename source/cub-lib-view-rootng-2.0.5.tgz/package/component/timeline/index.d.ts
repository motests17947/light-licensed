import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import { CubThemeColor } from 'cub-lib-view-rootng/component/common';

interface CubTimelineDataNode {
    icon?: string;
    active: boolean;
    data?: Record<string, any>;
}

declare class CubTimeline {
    /** 元件顯示內容的模板，預設值為 undefined。 */
    itemTemplateRef: TemplateRef<any>;
    /** 元件 Icon 模板，預設值為 undefined。 */
    markerTemplateRef?: TemplateRef<any>;
    /** 元件的資料，預設為 []。 */
    value: CubTimelineDataNode[];
    /** 元件顏色，預設值為 'brand'。 */
    color: CubThemeColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTimeline, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubTimeline, "cub-timeline", never, { "itemTemplateRef": { "alias": "itemTemplateRef"; "required": false; }; "markerTemplateRef": { "alias": "markerTemplateRef"; "required": false; }; "value": { "alias": "value"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubTimelineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTimelineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubTimelineModule, never, [typeof CubTimeline], [typeof CubTimeline]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubTimelineModule>;
}

export { CubTimeline, CubTimelineModule };
export type { CubTimelineDataNode };
