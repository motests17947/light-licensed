import * as i0 from '@angular/core';
import { OnInit, AfterContentInit, OnDestroy, TemplateRef, EventEmitter, ElementRef, QueryList, ChangeDetectorRef, AfterViewInit, NgZone } from '@angular/core';
import * as rxjs from 'rxjs';
import { Subject, Subscription } from 'rxjs';
import { CubThemeStatus, CubTemplate } from 'cub-lib-view-rootng/component/common';

interface CubToastOptions {
    status?: CubThemeStatus;
    title?: string;
    message?: string;
    id?: any;
    key?: string;
    life?: number;
    sticky?: boolean;
    closable?: boolean;
    data?: any;
    icon?: string;
    contentStyleClass?: string;
    styleClass?: string;
}

declare class CubToastService {
    toastSource: Subject<CubToastOptions | CubToastOptions[]>;
    clearSource: Subject<string>;
    toastObserver: rxjs.Observable<CubToastOptions | CubToastOptions[]>;
    clearObserver: rxjs.Observable<string>;
    add(toast: CubToastOptions): void;
    addAll(toasts: CubToastOptions[]): void;
    clear(key?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CubToastService>;
}

declare class CubToast implements OnInit, AfterContentInit, OnDestroy {
    toastService: CubToastService;
    private changeDetectorRef;
    toastSubscription: Subscription;
    clearSubscription: Subscription;
    toasts: CubToastOptions[] | null;
    toastsArchive: CubToastOptions[];
    templateRef: TemplateRef<any>;
    preventOpenDuplicates: boolean;
    preventDuplicates: boolean;
    showTransformOptions: string;
    hideTransformOptions: string;
    showTransitionOptions: string;
    hideTransitionOptions: string;
    /**
     元件標籤值，用來對應指定的 Toast 元件，預設為 undefined。
     */
    key: string;
    /**
     元件樣式，預設為 undefined。
     */
    style: any;
    /**
     元件類別樣式，預設為 undefined。
     */
    styleClass: string;
    /**
     當關閉元件時發出通知。
     */
    closed: EventEmitter<any>;
    containerViewChild: ElementRef;
    templates: QueryList<CubTemplate>;
    constructor(toastService: CubToastService, changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    add(toasts: CubToastOptions[]): void;
    canAdd(toast: CubToastOptions): boolean;
    containsToast(collection: CubToastOptions[] | null, toast: CubToastOptions): boolean;
    onToastClose(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToast, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubToast, "cub-toast", never, { "key": { "alias": "key"; "required": false; }; "style": { "alias": "style"; "required": false; }; "styleClass": { "alias": "styleClass"; "required": false; }; }, { "closed": "closed"; }, ["templates"], never, true, never>;
}

declare class CubToastItem implements AfterViewInit, OnDestroy {
    private zone;
    timeout: any;
    toastLife: number;
    /**
     元件訊息，預設為 undefined。
     */
    toast: CubToastOptions;
    /**
     元件標籤值，用來對應指定的 Toast Item 元件，預設為 undefined。
     */
    index: number;
    /**
     元件訊息樣板，預設為 undefined。
     */
    templateRef: TemplateRef<any>;
    /**
     元件顯示 Transform 的選項，預設為 undefined。
     */
    showTransformOptions: string;
    /**
     元件消失 Transform 的選項，預設為 undefined。
     */
    hideTransformOptions: string;
    /**
     元件顯示 Transition 的選項，預設為 undefined。
     */
    showTransitionOptions: string;
    /**
     元件消失 Transition 的選項，預設為 undefined。
     */
    hideTransitionOptions: string;
    /**
     當關閉元件時發出通知。
     */
    closed: EventEmitter<any>;
    containerViewChild: ElementRef;
    constructor(zone: NgZone);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    initTimeout(): void;
    clearTimeout(): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    onCloseIconClick(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToastItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubToastItem, "cub-toast-item", never, { "toast": { "alias": "toast"; "required": false; }; "index": { "alias": "index"; "required": false; }; "templateRef": { "alias": "templateRef"; "required": false; }; "showTransformOptions": { "alias": "showTransformOptions"; "required": false; }; "hideTransformOptions": { "alias": "hideTransformOptions"; "required": false; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}

declare class CubToastModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToastModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubToastModule, never, [typeof CubToast, typeof CubToastItem], [typeof CubToast, typeof CubToastItem]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubToastModule>;
}

export { CubToast, CubToastItem, CubToastModule, CubToastService };
export type { CubToastOptions };
