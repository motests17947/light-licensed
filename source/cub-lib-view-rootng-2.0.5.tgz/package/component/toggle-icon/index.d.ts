import * as i0 from '@angular/core';
import { AfterViewInit, OnDestroy, ElementRef, ChangeDetectorRef, NgZone } from '@angular/core';
import { FocusMonitor, FocusOrigin } from 'cub-lib-view-rootng/cdk/a11y';
import { CubThemeSize } from 'cub-lib-view-rootng/component/common';
import { _CubCheckboxBase, CubCheckboxChange, CubCheckboxGroup, CubCheckboxDefaultOptions } from 'cub-lib-view-rootng/component/checkbox';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';
import * as i3 from 'cub-lib-view-rootng/component/input';

interface CubToggleIconFormat {
    icon: string;
    color: string;
    toggleOff: string;
    toggleOn: string;
}

type CubToggleIconAppearance = 'star' | 'heart' | 'bookmark' | 'thumbtack';
type CubToggleIconColor = 'red' | 'orange' | 'green' | 'blue' | 'purple' | 'gray';

declare class CubToggleIcon extends _CubCheckboxBase<CubCheckboxChange> implements AfterViewInit, OnDestroy {
    _noopAnimations: boolean;
    private _toggleIconColor?;
    /** 處理 icon 對應開關樣式替換*/
    get iconStates(): CubToggleIconFormat | undefined;
    get currentIcon(): string;
    /** 元件樣式，預設為 'star'。 */
    icon: CubToggleIconAppearance;
    /** 元件顏色，預設為 undefined。 */
    get toggleIconColor(): CubToggleIconColor;
    set toggleIconColor(value: CubToggleIconColor | undefined);
    /** 元件尺寸，預設為 'medium'。 */
    size: CubThemeSize;
    constructor(checkboxGroup: CubCheckboxGroup, elementRef: ElementRef<HTMLElement>, changeDetectorRef: ChangeDetectorRef, _focusMonitor: FocusMonitor, ngZone: NgZone, tabIndex: string, _animationMode?: string, options?: CubCheckboxDefaultOptions);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * 處理標籤上的鍵盤事件。
     * 當使用者按下空白鍵時，會切換選取狀態。
     */
    _onLabelKeydown(event: Event): void;
    _onInputClick(event: Event): void;
    focus(origin?: FocusOrigin, options?: FocusOptions): void;
    protected _createChangeEvent(isChecked: boolean): CubCheckboxChange;
    protected _getAnimationTargetElement(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToggleIcon, [{ optional: true; }, null, null, null, null, { attribute: "tabindex"; }, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubToggleIcon, "cub-toggle-icon", ["cubToggleIcon"], { "disableRipple": { "alias": "disableRipple"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "toggleIconColor": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}

declare const CUB_TOGGLE_ICON_CONFIG: CubToggleIconFormat[];

declare class CubToggleIconModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToggleIconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubToggleIconModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubToggleIcon], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof CubToggleIcon]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubToggleIconModule>;
}

export { CUB_TOGGLE_ICON_CONFIG, CubToggleIcon, CubToggleIconModule };
export type { CubToggleIconAppearance, CubToggleIconColor, CubToggleIconFormat };
