import * as i0 from '@angular/core';
import { ChangeDetectorRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { CubThemeSize } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';
import * as i3 from 'cub-lib-view-rootng/component/input';
import * as i4 from 'cub-lib-view-rootng/component/button';

declare class CubToggleMode implements ControlValueAccessor {
    changeDetectorRef: ChangeDetectorRef;
    checked: boolean;
    get hasOnLabel(): boolean;
    get hasOffLabel(): boolean;
    get toggleLabel(): string;
    /** 元件標題（螢幕閱讀器讀取用），預設為 ''。 */
    ariaLabel: string;
    /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
    ariaLabelledby: string | null;
    /** 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 ''。 */
    ariaDescribedby: string;
    /** 按鈕尺寸，預設為 medium */
    size: CubThemeSize;
    /** 元件開啟狀態的標題，預設為 ''。 */
    onLabel: string;
    /** 元件關閉狀態的標題，預設為 ''。 */
    offLabel: string;
    /** 元件開啟狀態的圖示，預設為 ''。 */
    onIcon: string;
    /** 元件關閉狀態的圖示，預設為 ''。 */
    offIcon: string;
    /** 元件的停用狀態，預設為 false。 */
    disabled: boolean;
    /** Tab 鍵的控制項索引值，預設為 0。 */
    tabindex: number;
    /** 當狀態切換時調用的通知事件。 */
    change: EventEmitter<any>;
    constructor(changeDetectorRef: ChangeDetectorRef);
    onModelChange: Function;
    onModelTouched: Function;
    writeValue(value: any): void;
    registerOnChange(fn: Function): void;
    registerOnTouched(fn: Function): void;
    setDisabledState(val: boolean): void;
    onKeydown(event: KeyboardEvent): void;
    onClick(event: Event): void;
    toggle(event: Event): void;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToggleMode, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubToggleMode, "button[cub-toggle-mode]", ["cubToggleMode"], { "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; "size": { "alias": "size"; "required": false; }; "onLabel": { "alias": "onLabel"; "required": false; }; "offLabel": { "alias": "offLabel"; "required": false; }; "onIcon": { "alias": "onIcon"; "required": false; }; "offIcon": { "alias": "offIcon"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; }, { "change": "change"; }, never, never, true, never>;
}

declare class CubToggleModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubToggleModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubToggleModeModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof i4.CubButtonModule, typeof CubToggleMode], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof i3.CubInputModule, typeof i4.CubButtonModule, typeof CubToggleMode]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubToggleModeModule>;
}

export { CubToggleMode, CubToggleModeModule };
