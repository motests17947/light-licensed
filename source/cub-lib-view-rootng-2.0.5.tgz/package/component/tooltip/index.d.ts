import * as i0 from '@angular/core';
import { OnInit, OnDestroy, TemplateRef, ElementRef, ChangeDetectorRef, Renderer2, AfterViewInit, ViewContainerRef, NgZone, InjectionToken } from '@angular/core';
import { AnimationEvent, AnimationTriggerMetadata } from '@angular/animations';
import { Observable } from 'rxjs';
import { BreakpointState, BreakpointObserver } from 'cub-lib-view-rootng/cdk/layout';
import { BooleanInput, NumberInput } from 'cub-lib-view-rootng/cdk/coercion';
import { OverlayRef, Overlay, ScrollDispatcher, OriginConnectionPosition, OverlayConnectionPosition, ScrollStrategy } from 'cub-lib-view-rootng/cdk/overlay';
import { Platform } from 'cub-lib-view-rootng/cdk/platform';
import { Directionality } from 'cub-lib-view-rootng/cdk/bidi';
import { AriaDescriber, FocusMonitor } from 'cub-lib-view-rootng/cdk/a11y';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';

/** Possible positions for a tooltip. */
type CubTooltipPosition = 'left' | 'right' | 'above' | 'below' | 'before' | 'after';
/**
 * Options for how the tooltip trigger should handle touch gestures.
 * See `CubTooltip.touchGestures` for more information.
 */
type CubTooltipTouchGestures = 'auto' | 'on' | 'off';
/** Possible visibility states of a tooltip. */
type CubTooltipVisibility = 'initial' | 'visible' | 'hidden';
type CubTooltipArrowDirection = 'left' | 'right' | 'up' | 'down' | undefined;

/**
 * Internal component that wraps the tooltip's content.
 * @docs-private
 */
declare class CubTooltip implements OnInit, OnDestroy {
    private _changeDetectorRef;
    private _breakpointObserver;
    private renderer2;
    /** Message to display in the tooltip */
    message: string | TemplateRef<any>;
    /** Classes to be added to the tooltip. Supports the same syntax as `ngClass`. */
    tooltipClass: string | string[] | Set<string> | {
        [key: string]: any;
    };
    /** The timeout ID of any current timer set to show the tooltip */
    _showTimeoutId: number | null;
    /** The timeout ID of any current timer set to hide the tooltip */
    _hideTimeoutId: number | null;
    /** Property watched by the animation framework to show or hide the tooltip */
    _visibility: CubTooltipVisibility;
    /** Stream that emits whether the user has a handset-sized display.  */
    _isHandset: Observable<BreakpointState>;
    /** Element that caused the tooltip to open. */
    _triggerElement: HTMLElement | null;
    /** Amount of milliseconds to delay the closing sequence. */
    _mouseLeaveHideDelay: number;
    arrowDirection: CubTooltipArrowDirection;
    showArrow: boolean;
    _arrowOffset: number;
    /** Whether interactions on the page should close the tooltip */
    private _closeOnInteraction;
    /** Subject for notifying that the tooltip has been hidden from the view */
    private readonly _onHide;
    get arrowOffset(): number;
    set arrowOffset(value: number);
    arrowElement: ElementRef<HTMLElement>;
    constructor(_changeDetectorRef: ChangeDetectorRef, _breakpointObserver: BreakpointObserver, renderer2: Renderer2);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * Shows the tooltip with an animation originating from the provided origin
     * @param delay Amount of milliseconds to the delay showing the tooltip.
     */
    show(delay: number): void;
    /**
     * Begins the animation to hide the tooltip after the provided delay in ms.
     * @param delay Amount of milliseconds to delay showing the tooltip.
     */
    hide(delay: number): void;
    /** Returns an observable that notifies when the tooltip has been hidden from view. */
    afterHidden(): Observable<void>;
    /** Whether the tooltip is being displayed. */
    isVisible(): boolean;
    _isTemplateRef(template: any): template is TemplateRef<any>;
    _animationStart(): void;
    _animationDone(event: AnimationEvent): void;
    /**
     * Interactions on the HTML body should close the tooltip immediately as defined in the
     * material design spec.
     * https://material.io/design/components/tooltips.html#behavior
     */
    _handleBodyInteraction(): void;
    /**
     * Marks that the tooltip needs to be checked in the next change detection run.
     * Mainly used for rendering the initial text before positioning a tooltip, which
     * can be problematic in components with OnPush change detection.
     */
    _markForCheck(): void;
    _handleMouseLeave({ relatedTarget }: MouseEvent): void;
    /** Handles the cleanup after an animation has finished. */
    private _finalizeAnimation;
    private updateArrowPosition;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTooltip, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubTooltip, "cub-tooltip", never, {}, {}, never, never, true, never>;
}

/** Default `cubTooltip` options that can be overridden. */
interface CubTooltipDefaultOptions {
    showDelay: number;
    hideDelay: number;
    touchendHideDelay: number;
    touchGestures?: CubTooltipTouchGestures;
    position?: CubTooltipPosition;
    positionAtOrigin?: boolean;
}

/**
 * Directive that attaches a material design tooltip to the host element. Animates the showing and
 * hiding of a tooltip provided position (defaults to above the element).
 *
 * https://material.io/design/components/tooltips.html
 */
declare class CubTooltipTrigger implements OnDestroy, AfterViewInit {
    private _overlay;
    private _elementRef;
    private _scrollDispatcher;
    private _viewContainerRef;
    private _ngZone;
    private _platform;
    private _ariaDescriber;
    private _focusMonitor;
    private _dir;
    private _defaultOptions;
    static ngAcceptInputType_disabled: BooleanInput;
    static ngAcceptInputType_hideDelay: NumberInput;
    static ngAcceptInputType_showDelay: NumberInput;
    _overlayRef: OverlayRef | null;
    _tooltipInstance: CubTooltip | null;
    private tooltipTouched;
    private _portal;
    private _position;
    private _positionAtOrigin;
    private _disabled;
    private _tooltipClass;
    private _scrollStrategy;
    private _viewInitialized;
    private _pointerExitEventsInitialized;
    private _message;
    private _showArrow;
    private _arrowWidth;
    /** Timer started at the last `touchstart` event. */
    private _touchstartTimeout;
    /** Manually-bound passive event listeners. */
    private readonly _passiveListeners;
    /** Emits when the component is destroyed. */
    private readonly _destroyed;
    /**
     是否顯示箭頭樣式，預設為 true。
    */
    get showArrow(): boolean;
    set showArrow(value: boolean);
    /**
     設置提示框與父元素的相對位置，預設為 'above'。
    */
    get position(): CubTooltipPosition;
    set position(value: CubTooltipPosition);
    /**
    是否啟用提示框改使用游標位置，預設為不啟用。
    */
    get positionAtOrigin(): boolean;
    set positionAtOrigin(value: BooleanInput);
    /**
    是否禁用顯示提示框，預設為不禁用。
    */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
    提示框顯示的延遲時間（毫秒），預設為 0 毫秒。
    */
    showDelay: number;
    /**
    提示框隱藏的延遲時間（毫秒），預設為 0 毫秒。
    */
    hideDelay: number;
    /**
     * 提示框如何處理觸控裝置的手勢行為。可取下列值之一：
     * - `auto` - 啟用觸控手勢，並不停用瀏覽器原生觸控手勢行為。
     * - `on` - 啟用觸控手勢，並停用瀏覽器原生觸控手勢行為。
     * - `off` - 禁用觸控手勢。
     * 預設值為 'auto'。
     */
    touchGestures: CubTooltipTouchGestures;
    /** 提示框顯示的文字，或是自訂內容的 TemplateRef。 預設為 '' */
    get message(): string | TemplateRef<any>;
    set message(value: string | TemplateRef<any>);
    /**
     提示框的類別樣式，支援與 ngClass 相同的語法，預設值為 undefined。
    */
    get tooltipClass(): string | string[] | Set<string> | {
        [key: string]: any;
    };
    set tooltipClass(value: string | string[] | Set<string> | {
        [key: string]: any;
    });
    constructor(_overlay: Overlay, _elementRef: ElementRef<HTMLElement>, _scrollDispatcher: ScrollDispatcher, _viewContainerRef: ViewContainerRef, _ngZone: NgZone, _platform: Platform, _ariaDescriber: AriaDescriber, _focusMonitor: FocusMonitor, scrollStrategy: any, _dir: Directionality, _defaultOptions: CubTooltipDefaultOptions);
    ngAfterViewInit(): void;
    /**
     * Dispose the tooltip when destroyed.
     */
    ngOnDestroy(): void;
    /** Shows the tooltip after the delay in ms, defaults to tooltip-delay-show or 0ms if no input */
    show(delay?: number, origin?: {
        x: number;
        y: number;
    }): void;
    /** Hides the tooltip after the delay in ms, defaults to tooltip-delay-hide or 0ms if no input */
    hide(delay?: number): void;
    /** Shows/hides the tooltip */
    toggle(origin?: {
        x: number;
        y: number;
    }): void;
    /** Returns true if the tooltip is currently visible to the user */
    _isTooltipVisible(): boolean;
    /**
     * Returns the origin position and a fallback position based on the user's position preference.
     * The fallback position is the inverse of the origin (e.g. `'below' -> 'above'`).
     */
    _getOrigin(): {
        main: OriginConnectionPosition;
        fallback: OriginConnectionPosition;
        above: OriginConnectionPosition;
        below: OriginConnectionPosition;
    };
    /** Returns the overlay position and a fallback position based on the user's preference */
    _getOverlayPosition(): {
        main: OverlayConnectionPosition;
        fallback: OverlayConnectionPosition;
        above: OverlayConnectionPosition;
        below: OverlayConnectionPosition;
    };
    /**
     * Handles the keydown events on the host element.
     * Needs to be an arrow function so that we can use it in addEventListener.
     */
    private _handleKeydown;
    /** Create the overlay config and position strategy */
    private _createOverlay;
    /** Detaches the currently-attached tooltip. */
    private _detach;
    /** Updates the position of the current tooltip. */
    private _updatePosition;
    /** Updates the tooltip message and repositions the overlay according to the new message length */
    private _updateTooltipMessage;
    /** Updates the tooltip class */
    private _setTooltipClass;
    /** Inverts an overlay position. */
    private _invertPosition;
    /** Binds the pointer events to the tooltip trigger. */
    private _setupPointerEnterEventsIfNeeded;
    private _setupPointerExitEventsIfNeeded;
    private _addListeners;
    private _platformSupportsMouseEvents;
    /** Disables the native browser gestures, based on how the tooltip has been configured. */
    private _disableNativeGesturesIfNecessary;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTooltipTrigger, [null, null, null, null, null, null, null, null, null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubTooltipTrigger, "[cubTooltip]", ["cubTooltip"], { "showArrow": { "alias": "cubTooltipShowArrow"; "required": false; }; "position": { "alias": "cubTooltipPosition"; "required": false; }; "positionAtOrigin": { "alias": "cubTooltipPositionAtOrigin"; "required": false; }; "disabled": { "alias": "cubTooltipDisabled"; "required": false; }; "showDelay": { "alias": "cubTooltipShowDelay"; "required": false; }; "hideDelay": { "alias": "cubTooltipHideDelay"; "required": false; }; "touchGestures": { "alias": "cubTooltipTouchGestures"; "required": false; }; "message": { "alias": "cubTooltip"; "required": false; }; "tooltipClass": { "alias": "cubTooltipClass"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Creates an error to be thrown if the user supplied an invalid tooltip position.
 * @docs-private
 */
declare function getCubTooltipInvalidPositionError(position: string): Error;
/** @docs-private */
declare function CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
/** @docs-private */
declare function CUB_TOOLTIP_DEFAULT_OPTIONS_FACTORY(): CubTooltipDefaultOptions;
declare function throttle(func: (...args: any[]) => void, limit: number): (...args: any[]) => void;

/** Options used to bind passive event listeners. */
declare const passiveListenerOptions: boolean | AddEventListenerOptions;
/** Time in ms to throttle repositioning after scroll events. */
declare const SCROLL_THROTTLE_MS = 20;
/** CSS class that will be attached to the overlay panel. */
declare const TOOLTIP_PANEL_CLASS = "cub-tooltip-panel";
/**
 * Time between the user putting the pointer on a tooltip
 * trigger and the long press event being fired.
 */
declare const LONGPRESS_DELAY = 100;
/** Injection token that determines the scroll handling while a tooltip is visible. */
declare const CUB_TOOLTIP_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
/** @docs-private */
declare const CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY;
};
/** Injection token to be used to override the default options for `matTooltip`. */
declare const CUB_TOOLTIP_DEFAULT_OPTIONS: InjectionToken<CubTooltipDefaultOptions>;
/**
 * Animations used by CubTooltip.
 * @docs-private
 */
declare const cubTooltipAnimations: {
    readonly tooltipState: AnimationTriggerMetadata;
};

declare class CubTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubTooltipModule, never, [typeof i1.CubCdkScrollableModule, typeof CubTooltip, typeof CubTooltipTrigger], [typeof i1.CubCdkScrollableModule, typeof CubTooltip, typeof CubTooltipTrigger]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubTooltipModule>;
}

export { CUB_TOOLTIP_DEFAULT_OPTIONS, CUB_TOOLTIP_DEFAULT_OPTIONS_FACTORY, CUB_TOOLTIP_SCROLL_STRATEGY, CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY, CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER, CubTooltip, CubTooltipModule, CubTooltipTrigger, LONGPRESS_DELAY, SCROLL_THROTTLE_MS, TOOLTIP_PANEL_CLASS, cubTooltipAnimations, getCubTooltipInvalidPositionError, passiveListenerOptions, throttle };
export type { CubTooltipArrowDirection, CubTooltipDefaultOptions, CubTooltipPosition, CubTooltipTouchGestures, CubTooltipVisibility };
