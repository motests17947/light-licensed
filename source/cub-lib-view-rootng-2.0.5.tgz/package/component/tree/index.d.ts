import { CubCdkTreeNodeOutlet, CubCdkTree, CubCdkTreeNode, CubCdkTreeNodePadding, CubCdkTreeNodeToggle, CubCdkNestedTreeNode, CubCdkTreeNodeDef, TreeControl, FlatTreeControl } from 'cub-lib-view-rootng/cdk/tree';
import * as i0 from '@angular/core';
import { ViewContainerRef, OnInit, OnDestroy, ElementRef, Renderer2, AfterContentInit } from '@angular/core';
import { Observable } from 'rxjs';
import { DataSource, CollectionViewer } from 'cub-lib-view-rootng/cdk/collections';

/**
 * Outlet for nested CdkNode. Put `[cubTreeNodeOutlet]` on a tag to place children dataNodes
 * inside the outlet.
 */
declare class CubTreeNodeOutlet implements CubCdkTreeNodeOutlet {
    viewContainer: ViewContainerRef;
    _node: object | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeNodeOutlet, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubTreeNodeOutlet, "[cubTreeNodeOutlet]", never, {}, {}, never, never, true, never>;
}

/**
 * Wrapper for the CdkTable with Cuberial design styles.
 */
declare class CubTree<T, K = T> extends CubCdkTree<T, K> {
    _nodeOutlet: CubTreeNodeOutlet;
    size: 'small' | 'medium' | 'large';
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTree<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubTree<any, any>, "cub-tree", ["cubTree"], { "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Wrapper for the CdkTable with Cuberial design styles.
 */
declare class CubTreeNodeToggleIcon {
    isExpanded: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeNodeToggleIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubTreeNodeToggleIcon, "cub-tree-node-toggle-icon", never, { "isExpanded": { "alias": "isExpanded"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * activation 為 CubCdkTreeNode 的輸出事件，當樹狀節點被激活時觸發。
 * expandedChange 為 CubCdkTreeNode 的輸出事件，當樹狀節點的展開狀態改變時觸發。
 */
/**
 * Wrapper for the CubCdkTree node with Cuberial design styles.
 */
declare class CubTreeNode<T, K = T> extends CubCdkTreeNode<T, K> implements OnInit, OnDestroy {
    /**
     * The default tabindex of the tree node.
     *
     * @deprecated By default CubTreeNode manages focus using TreeKeyManager instead of tabIndex.
     *   Recommend to avoid setting tabIndex directly to prevent TreeKeyManager form getting into
     *   an unexpected state. Tabindex to be removed in a future version.
     * @breaking-change 21.0.0 Remove this attribute.
     */
    defaultTabIndex: number;
    el: ElementRef<any>;
    renderer: Renderer2;
    private _tabIndexInputBinding;
    appearance: 'plain' | undefined;
    /**
     * Whether the component is disabled.
     *
     * @deprecated This is an alias for `isDisabled`.
     * @breaking-change 21.0.0 Remove this input
     */
    /**
     * 樹狀節點是否被禁用，預設值為 false。
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * The tabindex of the tree node.
     *
     * @deprecated By default CubTreeNode manages focus using TreeKeyManager instead of tabIndex.
     *   Recommend to avoid setting tabIndex directly to prevent TreeKeyManager form getting into
     *   an unexpected state. Tabindex to be removed in a future version.
     * @breaking-change 21.0.0 Remove this attribute.
     */
    /**
     * 樹狀節點的 tabindex，預設值為 0。
     */
    get tabIndexInputBinding(): number;
    set tabIndexInputBinding(value: number);
    constructor(...args: unknown[]);
    ngOnInit(): void;
    ngOnDestroy(): void;
    protected _getTabindexAttribute(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeNode<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubTreeNode<any, any>, "cub-tree-node", ["cubTreeNode"], { "appearance": { "alias": "appearance"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "tabIndexInputBinding": { "alias": "tabIndex"; "required": false; }; }, { "activation": "activation"; "expandedChange": "expandedChange"; }, never, never, true, never>;
    static ngAcceptInputType_disabled: unknown;
    static ngAcceptInputType_tabIndexInputBinding: unknown;
}

/**
 * Wrapper for the CubCdkTree padding with Cuberial design styles.
 */
declare class CubTreeNodePadding<T, K = T> extends CubCdkTreeNodePadding<T, K> {
    /** The level of depth of the tree node. The padding will be `level * indent` pixels. */
    /**
     * 樹狀節點的深度級別。左側空間將是 `level * indent` 像素，預設值為 undefined。
     */
    get level(): number;
    set level(value: number);
    /**
     * 樹狀節點每個級別的縮進。默認值為 40px，來自 cuberial 設計菜單子菜單規範。
     */
    get indent(): number | string;
    set indent(indent: number | string);
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeNodePadding<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubTreeNodePadding<any, any>, "[cubTreeNodePadding]", never, { "level": { "alias": "cubTreeNodePadding"; "required": false; }; "indent": { "alias": "cubTreeNodePaddingIndent"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_level: unknown;
}

/**
 * Wrapper for the CubCdkTree's toggle with Cuberial design styles.
 */
/**
 * recursive 屬性用於控制是否遞歸切換子節點的狀態。
 * 當設置為 true 時，點擊節點將會切換該節點及其所有子節點的狀態。
 */
declare class CubTreeNodeToggle<T, K = T> extends CubCdkTreeNodeToggle<T, K> {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeNodeToggle<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubTreeNodeToggle<any, any>, "[cubTreeNodeToggle]", never, { "recursive": { "alias": "cubTreeNodeToggleRecursive"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Wrapper for the CubCdkTree nested node with Cuberial design styles.
 */
declare class CubNestedTreeNode<T, K = T> extends CubCdkNestedTreeNode<T, K> implements AfterContentInit, OnDestroy, OnInit {
    private _tabIndex;
    /**
     * 樹狀節點的數據模型，預設值為 undefined。
     */
    node: T;
    /**
     * Whether the node is disabled.
     *
     * @deprecated This is an alias for `isDisabled`.
     * @breaking-change 21.0.0 Remove this input
     */
    /**
     * 樹狀節點是否被禁用，預設值為 false。
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** Tabindex of the node. */
    /**
     * 樹狀節點的 tabindex，預設值為 0。
     * 如果節點被禁用，則 tabindex 為 -1。
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubNestedTreeNode<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubNestedTreeNode<any, any>, "cub-nested-tree-node", ["cubNestedTreeNode"], { "node": { "alias": "cubNestedTreeNode"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; }, { "activation": "activation"; "expandedChange": "expandedChange"; }, never, never, true, never>;
    static ngAcceptInputType_disabled: unknown;
    static ngAcceptInputType_tabIndex: unknown;
}

/**
 * Wrapper for the CubCdkTree node definition with Cuberial design styles.
 * Captures the node's template and a when predicate that describes when this node should be used.
 */
/**
 * 樹狀節點定義的指令，使用 Cuberial 設計樣式，預設值為 undefined。
 */
declare class CubTreeNodeDef<T> extends CubCdkTreeNodeDef<T> {
    /**
     * 樹狀節點的數據模型，預設值為 undefined。
     */
    data: T;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeNodeDef<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubTreeNodeDef<any>, "[cubTreeNodeDef]", never, { "when": { "alias": "cubTreeNodeDefWhen"; "required": false; }; "data": { "alias": "cubTreeNode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CubTreeFlattener<T, F, K = F> {
    transformFunction: (node: T, level: number) => F;
    getLevel: (node: F) => number;
    isExpandable: (node: F) => boolean;
    getChildren: (node: T) => Observable<T[]> | T[] | undefined | null;
    constructor(transformFunction: (node: T, level: number) => F, getLevel: (node: F) => number, isExpandable: (node: F) => boolean, getChildren: (node: T) => Observable<T[]> | T[] | undefined | null);
    _flattenNode(node: T, level: number, resultNodes: F[], parentMap: boolean[]): F[];
    _flattenChildren(children: T[], level: number, resultNodes: F[], parentMap: boolean[]): void;
    /**
     * Flatten a list of node type T to flattened version of node F.
     * Please note that type T may be nested, and the length of `structuredData` may be different
     * from that of returned list `F[]`.
     */
    flattenNodes(structuredData: T[]): F[];
    /**
     * Expand flattened node with current expansion status.
     * The returned list may have different length.
     */
    expandFlattenedNodes(nodes: F[], treeControl: TreeControl<F, K>): F[];
}
declare class CubTreeFlatDataSource<T, F, K = F> extends DataSource<F> {
    private _treeControl;
    private _treeFlattener;
    private readonly _data;
    private readonly _flattenedData;
    private readonly _expandedData;
    get data(): T[];
    set data(value: T[]);
    constructor(_treeControl: FlatTreeControl<F, K>, _treeFlattener: CubTreeFlattener<T, F, K>, initialData?: T[]);
    connect(collectionViewer: CollectionViewer): Observable<F[]>;
    disconnect(): void;
}
declare class CubTreeNestedDataSource<T> extends DataSource<T> {
    private readonly _data;
    /**
     * Data for the nested tree
     */
    get data(): T[];
    set data(value: T[]);
    connect(collectionViewer: CollectionViewer): Observable<T[]>;
    disconnect(): void;
}

declare class CubTreeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubTreeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubTreeModule, never, [typeof CubNestedTreeNode, typeof CubTreeNodeDef, typeof CubTreeNodePadding, typeof CubTreeNodeToggle, typeof CubTree, typeof CubTreeNode, typeof CubTreeNodeOutlet, typeof CubTreeNodeToggleIcon], [typeof CubNestedTreeNode, typeof CubTreeNodeDef, typeof CubTreeNodePadding, typeof CubTreeNodeToggle, typeof CubTree, typeof CubTreeNode, typeof CubTreeNodeOutlet, typeof CubTreeNodeToggleIcon]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubTreeModule>;
}

export { CubNestedTreeNode, CubTree, CubTreeFlatDataSource, CubTreeFlattener, CubTreeModule, CubTreeNestedDataSource, CubTreeNode, CubTreeNodeDef, CubTreeNodeOutlet, CubTreeNodePadding, CubTreeNodeToggle, CubTreeNodeToggleIcon };
