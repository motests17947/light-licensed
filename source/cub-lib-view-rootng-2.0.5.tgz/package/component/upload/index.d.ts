import * as i0 from '@angular/core';
import { OnInit, OnDestroy, EventEmitter, ElementRef, Injector } from '@angular/core';
import { ControlValueAccessor, Validator, NgControl, AbstractControlDirective, AbstractControl, ValidationErrors } from '@angular/forms';
import { Subject } from 'rxjs';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import { CubFormFieldControl } from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/component/label';

type CubUploadAppearance = 'area' | 'button' | 'button-small';
type CubUploadErrorType = 'invalidMimeType' | 'exceedsMaxSize' | 'multipleNotAllowed';

interface CubUploadFileValidationError {
    file?: File;
    errorTypes: CubUploadErrorType[];
}

declare class CubUpload implements OnInit, OnDestroy, CubFormFieldControl<File[]>, ControlValueAccessor, Validator {
    private injector;
    static nextId: number;
    controlType: string;
    id: string;
    stateChanges: Subject<void>;
    focused: boolean;
    errorState: boolean;
    required: boolean;
    placeholder: string;
    describedBy: string;
    ngControl: NgControl | AbstractControlDirective | null;
    autofilled?: boolean | undefined;
    ariaDescribedBy?: string | undefined;
    dragging: boolean;
    accept: string | null;
    private _value;
    private _disabled;
    private _acceptableMimeTypes;
    get value(): File[];
    set value(files: File[]);
    get empty(): boolean;
    /**
     * 暫存的檔案清單，預設為 []。
     * 使用 FormControl 來管理值。
     */
    get files(): File[];
    set files(value: File[]);
    /**
     * 元件是否禁用，預設為 false。
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * 元件的視覺樣式選擇，預設為 'area'。
     */
    appearance: CubUploadAppearance;
    /**
     * 可選擇的檔案類型，例如: ['image/jpeg', 'image/png']，
     * 參數 null 表示不限制檔案類型，預設為 null。
     */
    get acceptableMimeTypes(): string[];
    set acceptableMimeTypes(types: string[] | null | undefined);
    /**
     * 限制最大檔案大小，單位為位元組(byte) 如: 5 * 1024 * 1024 (5MB)。
     * 參數 null 表示不限制檔案大小，預設為 null。
     */
    maxFileSize: number | null;
    /**
     * Upload Area 元件的主標題文字，預設為 '點擊或拖曳檔案來上傳'。
     */
    label: string;
    /**
     * Upload Button 元件按鈕上的文字，預設為 '檔案上傳'。
     */
    uploadLabel: string;
    /**
     * 未選取檔案時顯示的說明文字，預設為 ''。
     */
    description: string;
    /**
     * 是否允許選擇多個檔案，預設為 false。
     */
    multiple: boolean;
    /**
     * 設定 loading 狀態，預設為 false。
     */
    loading: boolean;
    /**
     * 表示想由外部來告知元件需要顯示錯誤樣式，預設為 false。
     */
    hasError: boolean;
    /**
     * 檢查檔案格式、檔案大小的成功事件通知。
     */
    validationSuccess: EventEmitter<File[]>;
    /**
     * 檢查檔案格式、檔案大小的錯誤事件通知。
     */
    validationFailed: EventEmitter<CubUploadFileValidationError[]>;
    fileUploder: ElementRef;
    constructor(injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    writeValue(value: File[]): void;
    registerOnChange(fn: (value: File[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    setDescribedByIds(ids: string[]): void;
    onContainerClick(event: MouseEvent): void;
    validate(control: AbstractControl): ValidationErrors | null;
    /**
     * 判斷檔案是否符合接受的格式
     */
    isFileTypeAccepted(file: File): boolean;
    /**
     * 清空輸入框
     */
    reset(): void;
    /**
     * 以選擇的方式上傳檔案
     */
    chooseFile(event: any): void;
    /**
     * 以拖拉的方式上傳檔案
     */
    dropFile(event: any): void;
    /**
     * 拉進去樣式
     */
    dragOver(event: any): void;
    /**
     * 拉出去樣式
     */
    dragLeave(event: any): void;
    private onChange;
    private onTouched;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubUpload, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CubUpload, "cub-upload", ["cubUpload"], { "files": { "alias": "files"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "acceptableMimeTypes": { "alias": "acceptableMimeTypes"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; "label": { "alias": "label"; "required": false; }; "uploadLabel": { "alias": "uploadLabel"; "required": false; }; "description": { "alias": "description"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "hasError": { "alias": "hasError"; "required": false; }; }, { "validationSuccess": "validationSuccess"; "validationFailed": "validationFailed"; }, never, never, true, never>;
}

declare class CubUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubUploadModule, never, [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof CubUpload], [typeof i1.CubFormFieldModule, typeof i2.CubLabelModule, typeof CubUpload]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubUploadModule>;
}

export { CubUpload, CubUploadModule };
export type { CubUploadAppearance, CubUploadErrorType, CubUploadFileValidationError };
