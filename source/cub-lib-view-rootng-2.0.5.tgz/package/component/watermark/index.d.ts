import * as i0 from '@angular/core';
import { OnChanges, OnDestroy, ElementRef, Renderer2 } from '@angular/core';
import { CubThemeSize } from 'cub-lib-view-rootng/component/common';

declare class CubWatermark implements OnChanges, OnDestroy {
    private elementRef;
    private renderer;
    private watermark;
    private watermarkHandler;
    /** 是否螢幕滿版顯示。 false 表示僅在使用的 HTML Tag 內顯示。 預設為 false */
    fullscreen: boolean;
    /** 元件尺寸，預設為 'medium' */
    size: CubThemeSize;
    /** 元件透明度，預設為 0.2 */
    alpha: number;
    /** 元件內文，預設為 '00587000 姓Ｏ名\n 2025/05/13 13:00' */
    text: string;
    constructor(elementRef: ElementRef, renderer: Renderer2);
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private normalState;
    private fullscreenState;
    private clear;
    static ɵfac: i0.ɵɵFactoryDeclaration<CubWatermark, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CubWatermark, "[cubWatermark]", never, { "fullscreen": { "alias": "cubWatermarkFullscreen"; "required": false; }; "size": { "alias": "cubWatermarkSize"; "required": false; }; "alpha": { "alias": "cubWatermarkAlpha"; "required": false; }; "text": { "alias": "cubWatermark"; "required": false; }; }, {}, never, never, true, never>;
}

interface CubWatermarkOptions {
    text?: string;
    width?: number;
    height?: number;
    fontFamily?: string;
    fontSize?: string;
    fontWeight?: 'normal' | 'bold' | 'bolder' | 'lighter' | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900;
    color?: string;
    alpha?: number;
    degree?: number;
    lineHeight?: number;
    textAlign?: 'start' | 'end' | 'center' | 'left' | 'right';
    textBaseline?: 'alphabetic' | 'top' | 'hanging' | 'middle' | 'ideographic' | 'bottom';
    backgroundRepeat?: 'repeat' | 'repeat-x' | 'repeat-y' | 'no-repeat' | 'space' | 'round' | 'initial';
    backgroundPosition?: string;
}

declare class WatermarkHandler {
    readonly DEFAULT_OPTIONS: CubWatermarkOptions;
    private elementRef;
    private renderer;
    constructor(elementRef: ElementRef, renderer: Renderer2);
    generateWatermark(options: CubWatermarkOptions): void;
    private processStyleFromOptions;
    private createDataUrl;
    private generateMultiLineText;
    private setHTMLElementStyle;
}

declare class CubWatermarkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CubWatermarkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CubWatermarkModule, never, [typeof CubWatermark], [typeof CubWatermark]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CubWatermarkModule>;
}

export { CubWatermark, CubWatermarkModule, WatermarkHandler };
export type { CubWatermarkOptions };
