import * as i0 from '@angular/core';
import { InjectionToken, DOCUMENT, Inject, Injectable, Input, Directive, EventEmitter, Output, Optional, SkipSelf, ContentChild, ContentChildren, Self, NgModule } from '@angular/core';
import { normalizePassiveListenerOptions, _getEventTarget, _getShadowRoot } from 'cub-lib-view-rootng/cdk/platform';
import { Subject, Subscription, interval, animationFrameScheduler, Observable, merge } from 'rxjs';
import { takeUntil, startWith, map, take, tap, switchMap } from 'rxjs/operators';
import { coerceBooleanProperty, coerceElement, coerceArray, coerceNumberProperty } from 'cub-lib-view-rootng/cdk/coercion';
import * as i3 from 'cub-lib-view-rootng/cdk/bidi';
import { isFakeTouchstartFromScreenReader, isFakeMousedownFromScreenReader } from 'cub-lib-view-rootng/cdk/a11y';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';
import { CubCdkScrollableModule } from 'cub-lib-view-rootng/cdk/scrolling';

const DRAG_HOST_CLASS = 'cub-cdk-drag';
const passiveEventListenerOptions = normalizePassiveListenerOptions({
    passive: true,
});
const activeEventListenerOptions = normalizePassiveListenerOptions({
    passive: false,
});
const dragImportantProperties = new Set(['position']);
const MOUSE_EVENT_IGNORE_TIME = 800;
const DEFAULT_CONFIG = {
    dragStartThreshold: 5,
    pointerDirectionChangeThreshold: 5,
};
const activeCapturingEventOptions = normalizePassiveListenerOptions({
    passive: false,
    capture: true,
});
const CUB_CDK_DRAG_PREVIEW = new InjectionToken('CubCdkDragPreview');
const CUB_CDK_DRAG_CONFIG = new InjectionToken('CUB_CDK_DRAG_CONFIG');
const CUB_CDK_DRAG_HANDLE = new InjectionToken('CubCdkDragHandle');
const CUB_CDK_DRAG_PARENT = new InjectionToken('CUB_CDK_DRAG_PARENT');
const CUB_CDK_DRAG_PLACEHOLDER = new InjectionToken('CubCdkDragPlaceholder');
const CUB_CDK_DROP_LIST_GROUP = new InjectionToken('CubCdkDropListGroup');
const CUB_CDK_DROP_LIST = new InjectionToken('CubCdkDropList');
const DROP_PROXIMITY_THRESHOLD = 0.05;
const SCROLL_PROXIMITY_THRESHOLD = 0.05;

function assertElementNode(node, name) { }
function moveItemInArray(array, fromIndex, toIndex) {
    const from = clamp$1(fromIndex, array.length - 1);
    const to = clamp$1(toIndex, array.length - 1);
    if (from === to) {
        return;
    }
    const target = array[from];
    const delta = to < from ? -1 : 1;
    for (let i = from; i !== to; i += delta) {
        array[i] = array[i + delta];
    }
    array[to] = target;
}
function transferArrayItem(currentArray, targetArray, currentIndex, targetIndex) {
    const from = clamp$1(currentIndex, currentArray.length - 1);
    const to = clamp$1(targetIndex, targetArray.length);
    if (currentArray.length) {
        targetArray.splice(to, 0, currentArray.splice(from, 1)[0]);
    }
}
function copyArrayItem(currentArray, targetArray, currentIndex, targetIndex) {
    const to = clamp$1(targetIndex, targetArray.length);
    if (currentArray.length) {
        targetArray.splice(to, 0, currentArray[currentIndex]);
    }
}
function getMutableClientRect(element) {
    const clientRect = element.getBoundingClientRect();
    return {
        top: clientRect.top,
        right: clientRect.right,
        bottom: clientRect.bottom,
        left: clientRect.left,
        width: clientRect.width,
        height: clientRect.height,
        x: clientRect.x,
        y: clientRect.y,
    };
}
function isInsideClientRect(clientRect, x, y) {
    const { top, bottom, left, right } = clientRect;
    return y >= top && y <= bottom && x >= left && x <= right;
}
function adjustClientRect(clientRect, top, left) {
    clientRect.top += top;
    clientRect.bottom = clientRect.top + clientRect.height;
    clientRect.left += left;
    clientRect.right = clientRect.left + clientRect.width;
}
function isPointerNearClientRect(rect, threshold, pointerX, pointerY) {
    const { top, right, bottom, left, width, height } = rect;
    const xThreshold = width * threshold;
    const yThreshold = height * threshold;
    return (pointerY > top - yThreshold &&
        pointerY < bottom + yThreshold &&
        pointerX > left - xThreshold &&
        pointerX < right + xThreshold);
}
function extendStyles(dest, source, importantProperties) {
    for (let key in source) {
        if (source.hasOwnProperty(key)) {
            const value = source[key];
            if (value) {
                dest.setProperty(key, value, importantProperties?.has(key) ? 'important' : '');
            }
            else {
                dest.removeProperty(key);
            }
        }
    }
    return dest;
}
function toggleNativeDragInteractions(element, enable) {
    const userSelect = enable ? '' : 'none';
    extendStyles(element.style, {
        'touch-action': enable ? '' : 'none',
        '-webkit-user-drag': enable ? '' : 'none',
        '-webkit-tap-highlight-color': enable ? '' : 'transparent',
        'user-select': userSelect,
        '-ms-user-select': userSelect,
        '-webkit-user-select': userSelect,
        '-moz-user-select': userSelect,
    });
}
function toggleVisibility(element, enable, importantProperties) {
    extendStyles(element.style, {
        position: enable ? '' : 'fixed',
        top: enable ? '' : '0',
        opacity: enable ? '' : '0',
        left: enable ? '' : '-999em',
    }, importantProperties);
}
function combineTransforms(transform, initialTransform) {
    return initialTransform && initialTransform != 'none'
        ? transform + ' ' + initialTransform
        : transform;
}
function getTransformTransitionDurationInMs(element) {
    const computedStyle = getComputedStyle(element);
    const transitionedProperties = parseCssPropertyValue(computedStyle, 'transition-property');
    const property = transitionedProperties.find((prop) => prop === 'transform' || prop === 'all');
    if (!property) {
        return 0;
    }
    const propertyIndex = transitionedProperties.indexOf(property);
    const rawDurations = parseCssPropertyValue(computedStyle, 'transition-duration');
    const rawDelays = parseCssPropertyValue(computedStyle, 'transition-delay');
    return (parseCssTimeUnitsToMs(rawDurations[propertyIndex]) +
        parseCssTimeUnitsToMs(rawDelays[propertyIndex]));
}
function deepCloneNode(node) {
    const clone = node.cloneNode(true);
    const descendantsWithId = clone.querySelectorAll('[id]');
    const nodeName = node.nodeName.toLowerCase();
    clone.removeAttribute('id');
    for (let i = 0; i < descendantsWithId.length; i++) {
        descendantsWithId[i].removeAttribute('id');
    }
    if (nodeName === 'canvas') {
        transferCanvasData(node, clone);
    }
    else if (nodeName === 'input' ||
        nodeName === 'select' ||
        nodeName === 'textarea') {
        transferInputData(node, clone);
    }
    transferData('canvas', node, clone, transferCanvasData);
    transferData('input, textarea, select', node, clone, transferInputData);
    return clone;
}
function transferData(selector, node, clone, callback) {
    const descendantElements = node.querySelectorAll(selector);
    if (descendantElements.length) {
        const cloneElements = clone.querySelectorAll(selector);
        for (let i = 0; i < descendantElements.length; i++) {
            callback(descendantElements[i], cloneElements[i]);
        }
    }
}
let cloneUniqueId = 0;
function transferInputData(source, clone) {
    if (clone.type !== 'file') {
        clone.value = source.value;
    }
    if (clone.type === 'radio' && clone.name) {
        clone.name = `cub-clone-${clone.name}-${cloneUniqueId++}`;
    }
}
function transferCanvasData(source, clone) {
    const context = clone.getContext('2d');
    if (context) {
        try {
            context.drawImage(source, 0, 0);
        }
        catch { }
    }
}
function parseCssTimeUnitsToMs(value) {
    const multiplier = value.toLowerCase().indexOf('ms') > -1 ? 1 : 1000;
    return parseFloat(value) * multiplier;
}
function parseCssPropertyValue(computedStyle, name) {
    const value = computedStyle.getPropertyValue(name);
    return value.split(',').map((part) => part.trim());
}
function clamp$1(value, max) {
    return Math.max(0, Math.min(max, value));
}

class ParentPositionTracker {
    constructor(_document) {
        this._document = _document;
        this.positions = new Map();
    }
    clear() {
        this.positions.clear();
    }
    cache(elements) {
        this.clear();
        this.positions.set(this._document, {
            scrollPosition: this.getViewportScrollPosition(),
        });
        elements.forEach((element) => {
            this.positions.set(element, {
                scrollPosition: { top: element.scrollTop, left: element.scrollLeft },
                clientRect: getMutableClientRect(element),
            });
        });
    }
    handleScroll(event) {
        const target = _getEventTarget(event);
        const cachedPosition = this.positions.get(target);
        if (!cachedPosition) {
            return null;
        }
        const scrollPosition = cachedPosition.scrollPosition;
        let newTop;
        let newLeft;
        if (target === this._document) {
            const viewportScrollPosition = this.getViewportScrollPosition();
            newTop = viewportScrollPosition.top;
            newLeft = viewportScrollPosition.left;
        }
        else {
            newTop = target.scrollTop;
            newLeft = target.scrollLeft;
        }
        const topDifference = scrollPosition.top - newTop;
        const leftDifference = scrollPosition.left - newLeft;
        this.positions.forEach((position, node) => {
            if (position.clientRect && target !== node && target.contains(node)) {
                adjustClientRect(position.clientRect, topDifference, leftDifference);
            }
        });
        scrollPosition.top = newTop;
        scrollPosition.left = newLeft;
        return { top: topDifference, left: leftDifference };
    }
    getViewportScrollPosition() {
        return { top: window.scrollY, left: window.scrollX };
    }
}

class DragRef {
    get disabled() {
        return (this._disabled || !!(this._dropContainer && this._dropContainer.disabled));
    }
    set disabled(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== this._disabled) {
            this._disabled = newValue;
            this._toggleNativeDragInteractions();
            this._handles.forEach((handle) => toggleNativeDragInteractions(handle, newValue));
        }
    }
    constructor(element, _config, _document, _ngZone, _viewportRuler, _dragDropRegistry) {
        this._config = _config;
        this._document = _document;
        this._ngZone = _ngZone;
        this._viewportRuler = _viewportRuler;
        this._dragDropRegistry = _dragDropRegistry;
        this.dragStartDelay = 0;
        this._moveEvents = new Subject();
        this.beforeStarted = new Subject();
        this.started = new Subject();
        this.released = new Subject();
        this.ended = new Subject();
        this.entered = new Subject();
        this.exited = new Subject();
        this.dropped = new Subject();
        this.moved = this._moveEvents;
        this._disabled = false;
        this._passiveTransform = { x: 0, y: 0 };
        this._activeTransform = { x: 0, y: 0 };
        this._hasStartedDragging = false;
        this._pointerMoveSubscription = Subscription.EMPTY;
        this._pointerUpSubscription = Subscription.EMPTY;
        this._scrollSubscription = Subscription.EMPTY;
        this._resizeSubscription = Subscription.EMPTY;
        this._boundaryElement = null;
        this._nativeInteractionsEnabled = true;
        this._handles = [];
        this._disabledHandles = new Set();
        this._direction = 'ltr';
        this._pointerDown = (event) => {
            this.beforeStarted.next();
            if (this._handles.length) {
                const targetHandle = this._getTargetHandle(event);
                if (targetHandle &&
                    !this._disabledHandles.has(targetHandle) &&
                    !this.disabled) {
                    this._initializeDragSequence(targetHandle, event);
                }
            }
            else if (!this.disabled) {
                this._initializeDragSequence(this._rootElement, event);
            }
        };
        this._pointerMove = (event) => {
            const pointerPosition = this._getPointerPositionOnPage(event);
            if (!this._hasStartedDragging) {
                const distanceX = Math.abs(pointerPosition.x - this._pickupPositionOnPage.x);
                const distanceY = Math.abs(pointerPosition.y - this._pickupPositionOnPage.y);
                const isOverThreshold = distanceX + distanceY >= this._config.dragStartThreshold;
                if (isOverThreshold) {
                    const isDelayElapsed = Date.now() >= this._dragStartTime + this._getDragStartDelay(event);
                    const container = this._dropContainer;
                    if (!isDelayElapsed) {
                        this._endDragSequence(event);
                        return;
                    }
                    if (!container ||
                        (!container.isDragging() && !container.isReceiving())) {
                        event.preventDefault();
                        this._hasStartedDragging = true;
                        this._ngZone.run(() => this._startDragSequence(event));
                    }
                }
                return;
            }
            event.preventDefault();
            const constrainedPointerPosition = this._getConstrainedPointerPosition(pointerPosition);
            this._hasMoved = true;
            this._lastKnownPointerPosition = pointerPosition;
            this._updatePointerDirectionDelta(constrainedPointerPosition);
            if (this._dropContainer) {
                this._updateActiveDropContainer(constrainedPointerPosition, pointerPosition);
            }
            else {
                const offset = this.constrainPosition
                    ? this._initialClientRect
                    : this._pickupPositionOnPage;
                const activeTransform = this._activeTransform;
                activeTransform.x =
                    constrainedPointerPosition.x - offset.x + this._passiveTransform.x;
                activeTransform.y =
                    constrainedPointerPosition.y - offset.y + this._passiveTransform.y;
                this._applyRootElementTransform(activeTransform.x, activeTransform.y);
            }
            if (this._moveEvents.observers.length) {
                this._ngZone.run(() => {
                    this._moveEvents.next({
                        source: this,
                        pointerPosition: constrainedPointerPosition,
                        event,
                        distance: this._getDragDistance(constrainedPointerPosition),
                        delta: this._pointerDirectionDelta,
                    });
                });
            }
        };
        this._pointerUp = (event) => {
            this._endDragSequence(event);
        };
        this._nativeDragStart = (event) => {
            if (this._handles.length) {
                const targetHandle = this._getTargetHandle(event);
                if (targetHandle &&
                    !this._disabledHandles.has(targetHandle) &&
                    !this.disabled) {
                    event.preventDefault();
                }
            }
            else if (!this.disabled) {
                event.preventDefault();
            }
        };
        this.withRootElement(element).withParent(_config.parentDragRef || null);
        this._parentPositions = new ParentPositionTracker(_document);
        _dragDropRegistry.registerDragItem(this);
    }
    getPlaceholderElement() {
        return this._placeholder;
    }
    getRootElement() {
        return this._rootElement;
    }
    getVisibleElement() {
        return this.isDragging()
            ? this.getPlaceholderElement()
            : this.getRootElement();
    }
    withHandles(handles) {
        this._handles = handles.map((handle) => coerceElement(handle));
        this._handles.forEach((handle) => toggleNativeDragInteractions(handle, this.disabled));
        this._toggleNativeDragInteractions();
        const disabledHandles = new Set();
        this._disabledHandles.forEach((handle) => {
            if (this._handles.indexOf(handle) > -1) {
                disabledHandles.add(handle);
            }
        });
        this._disabledHandles = disabledHandles;
        return this;
    }
    withPreviewTemplate(template) {
        this._previewTemplate = template;
        return this;
    }
    withPlaceholderTemplate(template) {
        this._placeholderTemplate = template;
        return this;
    }
    withRootElement(rootElement) {
        const element = coerceElement(rootElement);
        if (element !== this._rootElement) {
            if (this._rootElement) {
                this._removeRootElementListeners(this._rootElement);
            }
            this._ngZone.runOutsideAngular(() => {
                element.addEventListener('mousedown', this._pointerDown, activeEventListenerOptions);
                element.addEventListener('touchstart', this._pointerDown, passiveEventListenerOptions);
                element.addEventListener('dragstart', this._nativeDragStart, activeEventListenerOptions);
            });
            this._initialTransform = undefined;
            this._rootElement = element;
        }
        if (typeof SVGElement !== 'undefined' &&
            this._rootElement instanceof SVGElement) {
            this._ownerSVGElement = this._rootElement.ownerSVGElement;
        }
        return this;
    }
    withBoundaryElement(boundaryElement) {
        this._boundaryElement = boundaryElement
            ? coerceElement(boundaryElement)
            : null;
        this._resizeSubscription.unsubscribe();
        if (boundaryElement) {
            this._resizeSubscription = this._viewportRuler
                .change(10)
                .subscribe(() => this._containInsideBoundaryOnResize());
        }
        return this;
    }
    withParent(parent) {
        this._parentDragRef = parent;
        return this;
    }
    dispose() {
        this._removeRootElementListeners(this._rootElement);
        if (this.isDragging()) {
            this._rootElement?.remove();
        }
        this._anchor?.remove();
        this._destroyPreview();
        this._destroyPlaceholder();
        this._dragDropRegistry.removeDragItem(this);
        this._removeSubscriptions();
        this.beforeStarted.complete();
        this.started.complete();
        this.released.complete();
        this.ended.complete();
        this.entered.complete();
        this.exited.complete();
        this.dropped.complete();
        this._moveEvents.complete();
        this._handles = [];
        this._disabledHandles.clear();
        this._dropContainer = undefined;
        this._resizeSubscription.unsubscribe();
        this._parentPositions.clear();
        this._boundaryElement =
            this._rootElement =
                this._ownerSVGElement =
                    this._placeholderTemplate =
                        this._previewTemplate =
                            this._anchor =
                                this._parentDragRef =
                                    null;
    }
    isDragging() {
        return this._hasStartedDragging && this._dragDropRegistry.isDragging(this);
    }
    reset() {
        this._rootElement.style.transform = this._initialTransform || '';
        this._activeTransform = { x: 0, y: 0 };
        this._passiveTransform = { x: 0, y: 0 };
    }
    disableHandle(handle) {
        if (!this._disabledHandles.has(handle) &&
            this._handles.indexOf(handle) > -1) {
            this._disabledHandles.add(handle);
            toggleNativeDragInteractions(handle, true);
        }
    }
    enableHandle(handle) {
        if (this._disabledHandles.has(handle)) {
            this._disabledHandles.delete(handle);
            toggleNativeDragInteractions(handle, this.disabled);
        }
    }
    withDirection(direction) {
        this._direction = direction;
        return this;
    }
    _withDropContainer(container) {
        this._dropContainer = container;
    }
    getFreeDragPosition() {
        const position = this.isDragging()
            ? this._activeTransform
            : this._passiveTransform;
        return { x: position.x, y: position.y };
    }
    setFreeDragPosition(value) {
        this._activeTransform = { x: 0, y: 0 };
        this._passiveTransform.x = value.x;
        this._passiveTransform.y = value.y;
        if (!this._dropContainer) {
            this._applyRootElementTransform(value.x, value.y);
        }
        return this;
    }
    withPreviewContainer(value) {
        this._previewContainer = value;
        return this;
    }
    _sortFromLastPointerPosition() {
        const position = this._lastKnownPointerPosition;
        if (position && this._dropContainer) {
            this._updateActiveDropContainer(this._getConstrainedPointerPosition(position), position);
        }
    }
    _removeSubscriptions() {
        this._pointerMoveSubscription.unsubscribe();
        this._pointerUpSubscription.unsubscribe();
        this._scrollSubscription.unsubscribe();
    }
    _destroyPreview() {
        this._preview?.remove();
        this._previewRef?.destroy();
        this._preview = this._previewRef = null;
    }
    _destroyPlaceholder() {
        this._placeholder?.remove();
        this._placeholderRef?.destroy();
        this._placeholder = this._placeholderRef = null;
    }
    _endDragSequence(event) {
        if (!this._dragDropRegistry.isDragging(this)) {
            return;
        }
        this._removeSubscriptions();
        this._dragDropRegistry.stopDragging(this);
        this._toggleNativeDragInteractions();
        if (this._handles) {
            this._rootElement.style.webkitTapHighlightColor = this._rootElementTapHighlight;
        }
        if (!this._hasStartedDragging) {
            return;
        }
        this.released.next({ source: this, event });
        if (this._dropContainer) {
            this._dropContainer._stopScrolling();
            this._animatePreviewToPlaceholder().then(() => {
                this._cleanupDragArtifacts(event);
                this._cleanupCachedDimensions();
                this._dragDropRegistry.stopDragging(this);
            });
        }
        else {
            this._passiveTransform.x = this._activeTransform.x;
            const pointerPosition = this._getPointerPositionOnPage(event);
            this._passiveTransform.y = this._activeTransform.y;
            this._ngZone.run(() => {
                this.ended.next({
                    source: this,
                    distance: this._getDragDistance(pointerPosition),
                    dropPoint: pointerPosition,
                    event,
                });
            });
            this._cleanupCachedDimensions();
            this._dragDropRegistry.stopDragging(this);
        }
    }
    _startDragSequence(event) {
        if (isTouchEvent(event)) {
            this._lastTouchEventTime = Date.now();
        }
        this._toggleNativeDragInteractions();
        const dropContainer = this._dropContainer;
        if (dropContainer) {
            const element = this._rootElement;
            const parent = element.parentNode;
            const placeholder = (this._placeholder =
                this._createPlaceholderElement());
            const anchor = (this._anchor =
                this._anchor || this._document.createComment(''));
            const shadowRoot = this._getShadowRoot();
            parent.insertBefore(anchor, element);
            this._initialTransform = element.style.transform || '';
            this._preview = this._createPreviewElement();
            toggleVisibility(element, false, dragImportantProperties);
            this._document.body.appendChild(parent.replaceChild(placeholder, element));
            this._getPreviewInsertionPoint(parent, shadowRoot).appendChild(this._preview);
            this.started.next({ source: this, event });
            dropContainer.start();
            this._initialContainer = dropContainer;
            this._initialIndex = dropContainer.getItemIndex(this);
        }
        else {
            this.started.next({ source: this, event });
            this._initialContainer = this._initialIndex = undefined;
        }
        this._parentPositions.cache(dropContainer ? dropContainer.getScrollableParents() : []);
    }
    _initializeDragSequence(referenceElement, event) {
        if (this._parentDragRef) {
            event.stopPropagation();
        }
        const isDragging = this.isDragging();
        const isTouchSequence = isTouchEvent(event);
        const isAuxiliaryMouseButton = !isTouchSequence && event.button !== 0;
        const rootElement = this._rootElement;
        const target = _getEventTarget(event);
        const isSyntheticEvent = !isTouchSequence &&
            this._lastTouchEventTime &&
            this._lastTouchEventTime + MOUSE_EVENT_IGNORE_TIME > Date.now();
        const isFakeEvent = isTouchSequence
            ? isFakeTouchstartFromScreenReader(event)
            : isFakeMousedownFromScreenReader(event);
        if (target &&
            target.draggable &&
            event.type === 'mousedown') {
            event.preventDefault();
        }
        if (isDragging ||
            isAuxiliaryMouseButton ||
            isSyntheticEvent ||
            isFakeEvent) {
            return;
        }
        if (this._handles.length) {
            const rootStyles = rootElement.style;
            this._rootElementTapHighlight = rootStyles.webkitTapHighlightColor || '';
            rootStyles.webkitTapHighlightColor = 'transparent';
        }
        this._hasStartedDragging = this._hasMoved = false;
        this._removeSubscriptions();
        this._initialClientRect = this._rootElement.getBoundingClientRect();
        this._pointerMoveSubscription =
            this._dragDropRegistry.pointerMove.subscribe(this._pointerMove);
        this._pointerUpSubscription = this._dragDropRegistry.pointerUp.subscribe(this._pointerUp);
        this._scrollSubscription = this._dragDropRegistry
            .scrolled(this._getShadowRoot())
            .subscribe((scrollEvent) => this._updateOnScroll(scrollEvent));
        if (this._boundaryElement) {
            this._boundaryRect = getMutableClientRect(this._boundaryElement);
        }
        const previewTemplate = this._previewTemplate;
        this._pickupPositionInElement =
            previewTemplate && previewTemplate.template && !previewTemplate.matchSize
                ? { x: 0, y: 0 }
                : this._getPointerPositionInElement(this._initialClientRect, referenceElement, event);
        const pointerPosition = (this._pickupPositionOnPage =
            this._lastKnownPointerPosition =
                this._getPointerPositionOnPage(event));
        this._pointerDirectionDelta = { x: 0, y: 0 };
        this._pointerPositionAtLastDirectionChange = {
            x: pointerPosition.x,
            y: pointerPosition.y,
        };
        this._dragStartTime = Date.now();
        this._dragDropRegistry.startDragging(this, event);
    }
    _cleanupDragArtifacts(event) {
        toggleVisibility(this._rootElement, true, dragImportantProperties);
        this._anchor.parentNode.replaceChild(this._rootElement, this._anchor);
        this._destroyPreview();
        this._destroyPlaceholder();
        this._initialClientRect =
            this._boundaryRect =
                this._previewRect =
                    this._initialTransform =
                        undefined;
        this._ngZone.run(() => {
            const container = this._dropContainer;
            const currentIndex = container.getItemIndex(this);
            const pointerPosition = this._getPointerPositionOnPage(event);
            const distance = this._getDragDistance(pointerPosition);
            const isPointerOverContainer = container._isOverContainer(pointerPosition.x, pointerPosition.y);
            this.ended.next({
                source: this,
                distance,
                dropPoint: pointerPosition,
                event,
            });
            this.dropped.next({
                item: this,
                currentIndex,
                previousIndex: this._initialIndex,
                container: container,
                previousContainer: this._initialContainer,
                isPointerOverContainer,
                distance,
                dropPoint: pointerPosition,
                event,
            });
            container.drop(this, currentIndex, this._initialIndex, this._initialContainer, isPointerOverContainer, distance, pointerPosition, event);
            this._dropContainer = this._initialContainer;
        });
    }
    _updateActiveDropContainer({ x, y }, { x: rawX, y: rawY }) {
        let newContainer = this._initialContainer._getSiblingContainerFromPosition(this, x, y);
        if (!newContainer &&
            this._dropContainer !== this._initialContainer &&
            this._initialContainer._isOverContainer(x, y)) {
            newContainer = this._initialContainer;
        }
        if (newContainer && newContainer !== this._dropContainer) {
            this._ngZone.run(() => {
                this.exited.next({ item: this, container: this._dropContainer });
                this._dropContainer.exit(this);
                this._dropContainer = newContainer;
                this._dropContainer.enter(this, x, y, newContainer === this._initialContainer &&
                    newContainer.sortingDisabled
                    ? this._initialIndex
                    : undefined);
                this.entered.next({
                    item: this,
                    container: newContainer,
                    currentIndex: newContainer.getItemIndex(this),
                });
            });
        }
        if (this.isDragging()) {
            this._dropContainer._startScrollingIfNecessary(rawX, rawY);
            this._dropContainer._sortItem(this, x, y, this._pointerDirectionDelta);
            if (this.constrainPosition) {
                this._applyPreviewTransform(x, y);
            }
            else {
                this._applyPreviewTransform(x - this._pickupPositionInElement.x, y - this._pickupPositionInElement.y);
            }
        }
    }
    _createPreviewElement() {
        const previewConfig = this._previewTemplate;
        const previewClass = this.previewClass;
        const previewTemplate = previewConfig ? previewConfig.template : null;
        let preview;
        if (previewTemplate && previewConfig) {
            const rootRect = previewConfig.matchSize ? this._initialClientRect : null;
            const viewRef = previewConfig.viewContainer.createEmbeddedView(previewTemplate, previewConfig.context);
            viewRef.detectChanges();
            preview = getRootNode(viewRef, this._document);
            this._previewRef = viewRef;
            if (previewConfig.matchSize) {
                matchElementSize(preview, rootRect);
            }
            else {
                preview.style.transform = getTransform(this._pickupPositionOnPage.x, this._pickupPositionOnPage.y);
            }
        }
        else {
            preview = deepCloneNode(this._rootElement);
            matchElementSize(preview, this._initialClientRect);
            if (this._initialTransform) {
                preview.style.transform = this._initialTransform;
            }
        }
        extendStyles(preview.style, {
            'pointer-events': 'none',
            margin: '0',
            position: 'fixed',
            top: '0',
            left: '0',
            'z-index': `${this._config.zIndex || 1000}`,
        }, dragImportantProperties);
        toggleNativeDragInteractions(preview, false);
        preview.classList.add('cub-cdk-drag-preview');
        preview.setAttribute('dir', this._direction);
        if (previewClass) {
            if (Array.isArray(previewClass)) {
                previewClass.forEach((className) => preview.classList.add(className));
            }
            else {
                preview.classList.add(previewClass);
            }
        }
        return preview;
    }
    _animatePreviewToPlaceholder() {
        if (!this._hasMoved) {
            return Promise.resolve();
        }
        const placeholderRect = this._placeholder.getBoundingClientRect();
        this._preview.classList.add('cub-cdk-drag-animating');
        this._applyPreviewTransform(placeholderRect.left, placeholderRect.top);
        const duration = getTransformTransitionDurationInMs(this._preview);
        if (duration === 0) {
            return Promise.resolve();
        }
        return this._ngZone.runOutsideAngular(() => {
            return new Promise((resolve) => {
                const handler = ((event) => {
                    if (!event ||
                        (_getEventTarget(event) === this._preview &&
                            event.propertyName === 'transform')) {
                        this._preview?.removeEventListener('transitionend', handler);
                        resolve();
                        clearTimeout(timeout);
                    }
                });
                const timeout = setTimeout(handler, duration * 1.5);
                this._preview.addEventListener('transitionend', handler);
            });
        });
    }
    _createPlaceholderElement() {
        const placeholderConfig = this._placeholderTemplate;
        const placeholderTemplate = placeholderConfig
            ? placeholderConfig.template
            : null;
        let placeholder;
        if (placeholderTemplate) {
            this._placeholderRef =
                placeholderConfig.viewContainer.createEmbeddedView(placeholderTemplate, placeholderConfig.context);
            this._placeholderRef.detectChanges();
            placeholder = getRootNode(this._placeholderRef, this._document);
        }
        else {
            placeholder = deepCloneNode(this._rootElement);
        }
        placeholder.style.pointerEvents = 'none';
        placeholder.classList.add('cub-cdk-drag-placeholder');
        return placeholder;
    }
    _getPointerPositionInElement(elementRect, referenceElement, event) {
        const handleElement = referenceElement === this._rootElement ? null : referenceElement;
        const referenceRect = handleElement
            ? handleElement.getBoundingClientRect()
            : elementRect;
        const point = isTouchEvent(event) ? event.targetTouches[0] : event;
        const scrollPosition = this._getViewportScrollPosition();
        const x = point.pageX - referenceRect.left - scrollPosition.left;
        const y = point.pageY - referenceRect.top - scrollPosition.top;
        return {
            x: referenceRect.left - elementRect.left + x,
            y: referenceRect.top - elementRect.top + y,
        };
    }
    _getPointerPositionOnPage(event) {
        const scrollPosition = this._getViewportScrollPosition();
        const point = isTouchEvent(event)
            ? event.touches[0] || event.changedTouches[0] || { pageX: 0, pageY: 0 }
            : event;
        const x = point.pageX - scrollPosition.left;
        const y = point.pageY - scrollPosition.top;
        if (this._ownerSVGElement) {
            const svgMatrix = this._ownerSVGElement.getScreenCTM();
            if (svgMatrix) {
                const svgPoint = this._ownerSVGElement.createSVGPoint();
                svgPoint.x = x;
                svgPoint.y = y;
                return svgPoint.matrixTransform(svgMatrix.inverse());
            }
        }
        return { x, y };
    }
    _getConstrainedPointerPosition(point) {
        const dropContainerLock = this._dropContainer
            ? this._dropContainer.lockAxis
            : null;
        let { x, y } = this.constrainPosition
            ? this.constrainPosition(point, this, this._initialClientRect, this._pickupPositionInElement)
            : point;
        if (this.lockAxis === 'x' || dropContainerLock === 'x') {
            y = this._pickupPositionOnPage.y;
        }
        else if (this.lockAxis === 'y' || dropContainerLock === 'y') {
            x = this._pickupPositionOnPage.x;
        }
        if (this._boundaryRect) {
            const { x: pickupX, y: pickupY } = this._pickupPositionInElement;
            const boundaryRect = this._boundaryRect;
            const { width: previewWidth, height: previewHeight } = this._getPreviewRect();
            const minY = boundaryRect.top + pickupY;
            const maxY = boundaryRect.bottom - (previewHeight - pickupY);
            const minX = boundaryRect.left + pickupX;
            const maxX = boundaryRect.right - (previewWidth - pickupX);
            x = clamp(x, minX, maxX);
            y = clamp(y, minY, maxY);
        }
        return { x, y };
    }
    _updatePointerDirectionDelta(pointerPositionOnPage) {
        const { x, y } = pointerPositionOnPage;
        const delta = this._pointerDirectionDelta;
        const positionSinceLastChange = this._pointerPositionAtLastDirectionChange;
        const changeX = Math.abs(x - positionSinceLastChange.x);
        const changeY = Math.abs(y - positionSinceLastChange.y);
        if (changeX > this._config.pointerDirectionChangeThreshold) {
            delta.x = x > positionSinceLastChange.x ? 1 : -1;
            positionSinceLastChange.x = x;
        }
        if (changeY > this._config.pointerDirectionChangeThreshold) {
            delta.y = y > positionSinceLastChange.y ? 1 : -1;
            positionSinceLastChange.y = y;
        }
        return delta;
    }
    _toggleNativeDragInteractions() {
        if (!this._rootElement || !this._handles) {
            return;
        }
        const shouldEnable = this._handles.length > 0 || !this.isDragging();
        if (shouldEnable !== this._nativeInteractionsEnabled) {
            this._nativeInteractionsEnabled = shouldEnable;
            toggleNativeDragInteractions(this._rootElement, shouldEnable);
        }
    }
    _removeRootElementListeners(element) {
        element.removeEventListener('mousedown', this._pointerDown, activeEventListenerOptions);
        element.removeEventListener('touchstart', this._pointerDown, passiveEventListenerOptions);
        element.removeEventListener('dragstart', this._nativeDragStart, activeEventListenerOptions);
    }
    _applyRootElementTransform(x, y) {
        const transform = getTransform(x, y);
        const styles = this._rootElement.style;
        if (this._initialTransform == null) {
            this._initialTransform =
                styles.transform && styles.transform != 'none' ? styles.transform : '';
        }
        styles.transform = combineTransforms(transform, this._initialTransform);
    }
    _applyPreviewTransform(x, y) {
        const initialTransform = this._previewTemplate?.template
            ? undefined
            : this._initialTransform;
        const transform = getTransform(x, y);
        this._preview.style.transform = combineTransforms(transform, initialTransform);
    }
    _getDragDistance(currentPosition) {
        const pickupPosition = this._pickupPositionOnPage;
        if (pickupPosition) {
            return {
                x: currentPosition.x - pickupPosition.x,
                y: currentPosition.y - pickupPosition.y,
            };
        }
        return { x: 0, y: 0 };
    }
    _cleanupCachedDimensions() {
        this._boundaryRect = this._previewRect = undefined;
        this._parentPositions.clear();
    }
    _containInsideBoundaryOnResize() {
        let { x, y } = this._passiveTransform;
        if ((x === 0 && y === 0) || this.isDragging() || !this._boundaryElement) {
            return;
        }
        const elementRect = this._rootElement.getBoundingClientRect();
        const boundaryRect = this._boundaryElement.getBoundingClientRect();
        if ((boundaryRect.width === 0 && boundaryRect.height === 0) ||
            (elementRect.width === 0 && elementRect.height === 0)) {
            return;
        }
        const leftOverflow = boundaryRect.left - elementRect.left;
        const rightOverflow = elementRect.right - boundaryRect.right;
        const topOverflow = boundaryRect.top - elementRect.top;
        const bottomOverflow = elementRect.bottom - boundaryRect.bottom;
        if (boundaryRect.width > elementRect.width) {
            if (leftOverflow > 0) {
                x += leftOverflow;
            }
            if (rightOverflow > 0) {
                x -= rightOverflow;
            }
        }
        else {
            x = 0;
        }
        if (boundaryRect.height > elementRect.height) {
            if (topOverflow > 0) {
                y += topOverflow;
            }
            if (bottomOverflow > 0) {
                y -= bottomOverflow;
            }
        }
        else {
            y = 0;
        }
        if (x !== this._passiveTransform.x || y !== this._passiveTransform.y) {
            this.setFreeDragPosition({ y, x });
        }
    }
    _getDragStartDelay(event) {
        const value = this.dragStartDelay;
        if (typeof value === 'number') {
            return value;
        }
        else if (isTouchEvent(event)) {
            return value.touch;
        }
        return value ? value.mouse : 0;
    }
    _updateOnScroll(event) {
        const scrollDifference = this._parentPositions.handleScroll(event);
        if (scrollDifference) {
            const target = _getEventTarget(event);
            if (this._boundaryRect &&
                target !== this._boundaryElement &&
                target.contains(this._boundaryElement)) {
                adjustClientRect(this._boundaryRect, scrollDifference.top, scrollDifference.left);
            }
            this._pickupPositionOnPage.x += scrollDifference.left;
            this._pickupPositionOnPage.y += scrollDifference.top;
            if (!this._dropContainer) {
                this._activeTransform.x -= scrollDifference.left;
                this._activeTransform.y -= scrollDifference.top;
                this._applyRootElementTransform(this._activeTransform.x, this._activeTransform.y);
            }
        }
    }
    _getViewportScrollPosition() {
        return (this._parentPositions.positions.get(this._document)?.scrollPosition ||
            this._parentPositions.getViewportScrollPosition());
    }
    _getShadowRoot() {
        if (this._cachedShadowRoot === undefined) {
            this._cachedShadowRoot = _getShadowRoot(this._rootElement);
        }
        return this._cachedShadowRoot;
    }
    _getPreviewInsertionPoint(initialParent, shadowRoot) {
        const previewContainer = this._previewContainer || 'global';
        if (previewContainer === 'parent') {
            return initialParent;
        }
        if (previewContainer === 'global') {
            const documentRef = this._document;
            return (shadowRoot ||
                documentRef.fullscreenElement ||
                documentRef.webkitFullscreenElement ||
                documentRef.mozFullScreenElement ||
                documentRef.msFullscreenElement ||
                documentRef.body);
        }
        return coerceElement(previewContainer);
    }
    _getPreviewRect() {
        if (!this._previewRect ||
            (!this._previewRect.width && !this._previewRect.height)) {
            this._previewRect = this._preview
                ? this._preview.getBoundingClientRect()
                : this._initialClientRect;
        }
        return this._previewRect;
    }
    _getTargetHandle(event) {
        return this._handles.find((handle) => {
            return (event.target &&
                (event.target === handle || handle.contains(event.target)));
        });
    }
}
function getTransform(x, y) {
    return `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
}
function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}
function isTouchEvent(event) {
    return event.type[0] === 't';
}
function getRootNode(viewRef, _document) {
    const rootNodes = viewRef.rootNodes;
    if (rootNodes.length === 1 &&
        rootNodes[0].nodeType === _document.ELEMENT_NODE) {
        return rootNodes[0];
    }
    const wrapper = _document.createElement('div');
    rootNodes.forEach((node) => wrapper.appendChild(node));
    return wrapper;
}
function matchElementSize(target, sourceRect) {
    target.style.width = `${sourceRect.width}px`;
    target.style.height = `${sourceRect.height}px`;
    target.style.transform = getTransform(sourceRect.left, sourceRect.top);
}

class SingleAxisSortStrategy {
    constructor(_element, _dragDropRegistry) {
        this._element = _element;
        this._dragDropRegistry = _dragDropRegistry;
        this.orientation = 'vertical';
        this._itemPositions = [];
        this._previousSwap = {
            drag: null,
            delta: 0,
            overlaps: false,
        };
    }
    start(items) {
        this.withItems(items);
    }
    sort(item, pointerX, pointerY, pointerDelta) {
        const siblings = this._itemPositions;
        const newIndex = this._getItemIndexFromPointerPosition(item, pointerX, pointerY, pointerDelta);
        if (newIndex === -1 && siblings.length > 0) {
            return null;
        }
        const isHorizontal = this.orientation === 'horizontal';
        const currentIndex = siblings.findIndex((currentItem) => currentItem.drag === item);
        const siblingAtNewPosition = siblings[newIndex];
        const currentPosition = siblings[currentIndex].clientRect;
        const newPosition = siblingAtNewPosition.clientRect;
        const delta = currentIndex > newIndex ? 1 : -1;
        const itemOffset = this._getItemOffsetPx(currentPosition, newPosition, delta);
        const siblingOffset = this._getSiblingOffsetPx(currentIndex, siblings, delta);
        const oldOrder = siblings.slice();
        moveItemInArray(siblings, currentIndex, newIndex);
        siblings.forEach((sibling, index) => {
            if (oldOrder[index] === sibling) {
                return;
            }
            const isDraggedItem = sibling.drag === item;
            const offset = isDraggedItem ? itemOffset : siblingOffset;
            const elementToOffset = isDraggedItem
                ? item.getPlaceholderElement()
                : sibling.drag.getRootElement();
            sibling.offset += offset;
            if (isHorizontal) {
                elementToOffset.style.transform = combineTransforms(`translate3d(${Math.round(sibling.offset)}px, 0, 0)`, sibling.initialTransform);
                adjustClientRect(sibling.clientRect, 0, offset);
            }
            else {
                elementToOffset.style.transform = combineTransforms(`translate3d(0, ${Math.round(sibling.offset)}px, 0)`, sibling.initialTransform);
                adjustClientRect(sibling.clientRect, offset, 0);
            }
        });
        this._previousSwap.overlaps = isInsideClientRect(newPosition, pointerX, pointerY);
        this._previousSwap.drag = siblingAtNewPosition.drag;
        this._previousSwap.delta = isHorizontal ? pointerDelta.x : pointerDelta.y;
        return { previousIndex: currentIndex, currentIndex: newIndex };
    }
    enter(item, pointerX, pointerY, index) {
        const newIndex = index == null || index < 0
            ? this._getItemIndexFromPointerPosition(item, pointerX, pointerY)
            : index;
        const activeDraggables = this._activeDraggables;
        const currentIndex = activeDraggables.indexOf(item);
        const placeholder = item.getPlaceholderElement();
        let newPositionReference = activeDraggables[newIndex];
        if (newPositionReference === item) {
            newPositionReference = activeDraggables[newIndex + 1];
        }
        if (!newPositionReference &&
            (newIndex == null ||
                newIndex === -1 ||
                newIndex < activeDraggables.length - 1) &&
            this._shouldEnterAsFirstChild(pointerX, pointerY)) {
            newPositionReference = activeDraggables[0];
        }
        if (currentIndex > -1) {
            activeDraggables.splice(currentIndex, 1);
        }
        if (newPositionReference &&
            !this._dragDropRegistry.isDragging(newPositionReference)) {
            const element = newPositionReference.getRootElement();
            element.parentElement.insertBefore(placeholder, element);
            activeDraggables.splice(newIndex, 0, item);
        }
        else {
            coerceElement(this._element).appendChild(placeholder);
            activeDraggables.push(item);
        }
        placeholder.style.transform = '';
        this._cacheItemPositions();
    }
    withItems(items) {
        this._activeDraggables = items.slice();
        this._cacheItemPositions();
    }
    withSortPredicate(predicate) {
        this._sortPredicate = predicate;
    }
    reset() {
        this._activeDraggables.forEach((item) => {
            const rootElement = item.getRootElement();
            if (rootElement) {
                const initialTransform = this._itemPositions.find((p) => p.drag === item)?.initialTransform;
                rootElement.style.transform = initialTransform || '';
            }
        });
        this._itemPositions = [];
        this._activeDraggables = [];
        this._previousSwap.drag = null;
        this._previousSwap.delta = 0;
        this._previousSwap.overlaps = false;
    }
    getActiveItemsSnapshot() {
        return this._activeDraggables;
    }
    getItemIndex(item) {
        const items = this.orientation === 'horizontal' && this.direction === 'rtl'
            ? this._itemPositions.slice().reverse()
            : this._itemPositions;
        return items.findIndex((currentItem) => currentItem.drag === item);
    }
    updateOnScroll(topDifference, leftDifference) {
        this._itemPositions.forEach(({ clientRect }) => {
            adjustClientRect(clientRect, topDifference, leftDifference);
        });
        this._itemPositions.forEach(({ drag }) => {
            if (this._dragDropRegistry.isDragging(drag)) {
                drag._sortFromLastPointerPosition();
            }
        });
    }
    _cacheItemPositions() {
        const isHorizontal = this.orientation === 'horizontal';
        this._itemPositions = this._activeDraggables
            .map((drag) => {
            const elementToMeasure = drag.getVisibleElement();
            return {
                drag,
                offset: 0,
                initialTransform: elementToMeasure.style.transform || '',
                clientRect: getMutableClientRect(elementToMeasure),
            };
        })
            .sort((a, b) => {
            return isHorizontal
                ? a.clientRect.left - b.clientRect.left
                : a.clientRect.top - b.clientRect.top;
        });
    }
    _getItemOffsetPx(currentPosition, newPosition, delta) {
        const isHorizontal = this.orientation === 'horizontal';
        let itemOffset = isHorizontal
            ? newPosition.left - currentPosition.left
            : newPosition.top - currentPosition.top;
        if (delta === -1) {
            itemOffset += isHorizontal
                ? newPosition.width - currentPosition.width
                : newPosition.height - currentPosition.height;
        }
        return itemOffset;
    }
    _getSiblingOffsetPx(currentIndex, siblings, delta) {
        const isHorizontal = this.orientation === 'horizontal';
        const currentPosition = siblings[currentIndex].clientRect;
        const immediateSibling = siblings[currentIndex + delta * -1];
        let siblingOffset = currentPosition[isHorizontal ? 'width' : 'height'] * delta;
        if (immediateSibling) {
            const start = isHorizontal ? 'left' : 'top';
            const end = isHorizontal ? 'right' : 'bottom';
            if (delta === -1) {
                siblingOffset -=
                    immediateSibling.clientRect[start] - currentPosition[end];
            }
            else {
                siblingOffset +=
                    currentPosition[start] - immediateSibling.clientRect[end];
            }
        }
        return siblingOffset;
    }
    _shouldEnterAsFirstChild(pointerX, pointerY) {
        if (!this._activeDraggables.length) {
            return false;
        }
        const itemPositions = this._itemPositions;
        const isHorizontal = this.orientation === 'horizontal';
        const reversed = itemPositions[0].drag !== this._activeDraggables[0];
        if (reversed) {
            const lastItemRect = itemPositions[itemPositions.length - 1].clientRect;
            return isHorizontal
                ? pointerX >= lastItemRect.right
                : pointerY >= lastItemRect.bottom;
        }
        else {
            const firstItemRect = itemPositions[0].clientRect;
            return isHorizontal
                ? pointerX <= firstItemRect.left
                : pointerY <= firstItemRect.top;
        }
    }
    _getItemIndexFromPointerPosition(item, pointerX, pointerY, delta) {
        const isHorizontal = this.orientation === 'horizontal';
        const index = this._itemPositions.findIndex(({ drag, clientRect }) => {
            if (drag === item) {
                return false;
            }
            if (delta) {
                const direction = isHorizontal ? delta.x : delta.y;
                if (drag === this._previousSwap.drag &&
                    this._previousSwap.overlaps &&
                    direction === this._previousSwap.delta) {
                    return false;
                }
            }
            return isHorizontal
                ? pointerX >= Math.floor(clientRect.left) &&
                    pointerX < Math.floor(clientRect.right)
                : pointerY >= Math.floor(clientRect.top) &&
                    pointerY < Math.floor(clientRect.bottom);
        });
        return index === -1 || !this._sortPredicate(index, item) ? -1 : index;
    }
}

class DropListRef {
    constructor(element, _dragDropRegistry, _document, _ngZone, _viewportRuler) {
        this._dragDropRegistry = _dragDropRegistry;
        this._ngZone = _ngZone;
        this._viewportRuler = _viewportRuler;
        this.disabled = false;
        this.sortingDisabled = false;
        this.autoScrollDisabled = false;
        this.autoScrollStep = 2;
        this.beforeStarted = new Subject();
        this.entered = new Subject();
        this.exited = new Subject();
        this.dropped = new Subject();
        this.sorted = new Subject();
        this._isDragging = false;
        this._draggables = [];
        this._siblings = [];
        this._activeSiblings = new Set();
        this._viewportScrollSubscription = Subscription.EMPTY;
        this._verticalScrollDirection = 0 /* AutoScrollVerticalDirection.NONE */;
        this._horizontalScrollDirection = 0 /* AutoScrollHorizontalDirection.NONE */;
        this._stopScrollTimers = new Subject();
        this._cachedShadowRoot = null;
        this.enterPredicate = () => true;
        this.sortPredicate = () => true;
        this._startScrollInterval = () => {
            this._stopScrolling();
            interval(0, animationFrameScheduler)
                .pipe(takeUntil(this._stopScrollTimers))
                .subscribe(() => {
                const node = this._scrollNode;
                const scrollStep = this.autoScrollStep;
                if (this._verticalScrollDirection === 1 /* AutoScrollVerticalDirection.UP */) {
                    node.scrollBy(0, -scrollStep);
                }
                else if (this._verticalScrollDirection === 2 /* AutoScrollVerticalDirection.DOWN */) {
                    node.scrollBy(0, scrollStep);
                }
                if (this._horizontalScrollDirection === 1 /* AutoScrollHorizontalDirection.LEFT */) {
                    node.scrollBy(-scrollStep, 0);
                }
                else if (this._horizontalScrollDirection ===
                    2 /* AutoScrollHorizontalDirection.RIGHT */) {
                    node.scrollBy(scrollStep, 0);
                }
            });
        };
        this.element = coerceElement(element);
        this._document = _document;
        this.withScrollableParents([this.element]);
        _dragDropRegistry.registerDropContainer(this);
        this._parentPositions = new ParentPositionTracker(_document);
        this._sortStrategy = new SingleAxisSortStrategy(this.element, _dragDropRegistry);
        this._sortStrategy.withSortPredicate((index, item) => this.sortPredicate(index, item, this));
    }
    dispose() {
        this._stopScrolling();
        this._stopScrollTimers.complete();
        this._viewportScrollSubscription.unsubscribe();
        this.beforeStarted.complete();
        this.entered.complete();
        this.exited.complete();
        this.dropped.complete();
        this.sorted.complete();
        this._activeSiblings.clear();
        this._scrollNode = null;
        this._parentPositions.clear();
        this._dragDropRegistry.removeDropContainer(this);
    }
    isDragging() {
        return this._isDragging;
    }
    start() {
        this._draggingStarted();
        this._notifyReceivingSiblings();
    }
    enter(item, pointerX, pointerY, index) {
        this._draggingStarted();
        if (index == null && this.sortingDisabled) {
            index = this._draggables.indexOf(item);
        }
        this._sortStrategy.enter(item, pointerX, pointerY, index);
        this._cacheParentPositions();
        this._notifyReceivingSiblings();
        this.entered.next({
            item,
            container: this,
            currentIndex: this.getItemIndex(item),
        });
    }
    exit(item) {
        this._reset();
        this.exited.next({ item, container: this });
    }
    drop(item, currentIndex, previousIndex, previousContainer, isPointerOverContainer, distance, dropPoint, event = {}) {
        this._reset();
        this.dropped.next({
            item,
            currentIndex,
            previousIndex,
            container: this,
            previousContainer,
            isPointerOverContainer,
            distance,
            dropPoint,
            event,
        });
    }
    withItems(items) {
        const previousItems = this._draggables;
        this._draggables = items;
        items.forEach((item) => item._withDropContainer(this));
        if (this.isDragging()) {
            const draggedItems = previousItems.filter((item) => item.isDragging());
            if (draggedItems.every((item) => items.indexOf(item) === -1)) {
                this._reset();
            }
            else {
                this._sortStrategy.withItems(this._draggables);
            }
        }
        return this;
    }
    withDirection(direction) {
        this._sortStrategy.direction = direction;
        return this;
    }
    connectedTo(connectedTo) {
        this._siblings = connectedTo.slice();
        return this;
    }
    withOrientation(orientation) {
        this._sortStrategy.orientation =
            orientation;
        return this;
    }
    withScrollableParents(elements) {
        const element = coerceElement(this.element);
        this._scrollableElements =
            elements.indexOf(element) === -1
                ? [element, ...elements]
                : elements.slice();
        return this;
    }
    getScrollableParents() {
        return this._scrollableElements;
    }
    getItemIndex(item) {
        return this._isDragging
            ? this._sortStrategy.getItemIndex(item)
            : this._draggables.indexOf(item);
    }
    isReceiving() {
        return this._activeSiblings.size > 0;
    }
    _sortItem(item, pointerX, pointerY, pointerDelta) {
        if (this.sortingDisabled ||
            !this._clientRect ||
            !isPointerNearClientRect(this._clientRect, DROP_PROXIMITY_THRESHOLD, pointerX, pointerY)) {
            return;
        }
        const result = this._sortStrategy.sort(item, pointerX, pointerY, pointerDelta);
        if (result) {
            this.sorted.next({
                previousIndex: result.previousIndex,
                currentIndex: result.currentIndex,
                container: this,
                item,
            });
        }
    }
    _startScrollingIfNecessary(pointerX, pointerY) {
        if (this.autoScrollDisabled) {
            return;
        }
        let scrollNode;
        let verticalScrollDirection = 0 /* AutoScrollVerticalDirection.NONE */;
        let horizontalScrollDirection = 0 /* AutoScrollHorizontalDirection.NONE */;
        this._parentPositions.positions.forEach((position, element) => {
            if (element === this._document || !position.clientRect || scrollNode) {
                return;
            }
            if (isPointerNearClientRect(position.clientRect, DROP_PROXIMITY_THRESHOLD, pointerX, pointerY)) {
                [verticalScrollDirection, horizontalScrollDirection] =
                    getElementScrollDirections(element, position.clientRect, pointerX, pointerY);
                if (verticalScrollDirection || horizontalScrollDirection) {
                    scrollNode = element;
                }
            }
        });
        if (!verticalScrollDirection && !horizontalScrollDirection) {
            const { width, height } = this._viewportRuler.getViewportSize();
            const clientRect = {
                width,
                height,
                top: 0,
                right: width,
                bottom: height,
                left: 0,
            };
            verticalScrollDirection = getVerticalScrollDirection(clientRect, pointerY);
            horizontalScrollDirection = getHorizontalScrollDirection(clientRect, pointerX);
            scrollNode = window;
        }
        if (scrollNode &&
            (verticalScrollDirection !== this._verticalScrollDirection ||
                horizontalScrollDirection !== this._horizontalScrollDirection ||
                scrollNode !== this._scrollNode)) {
            this._verticalScrollDirection = verticalScrollDirection;
            this._horizontalScrollDirection = horizontalScrollDirection;
            this._scrollNode = scrollNode;
            if ((verticalScrollDirection || horizontalScrollDirection) &&
                scrollNode) {
                this._ngZone.runOutsideAngular(this._startScrollInterval);
            }
            else {
                this._stopScrolling();
            }
        }
    }
    _stopScrolling() {
        this._stopScrollTimers.next();
    }
    _isOverContainer(x, y) {
        return (this._clientRect != null && isInsideClientRect(this._clientRect, x, y));
    }
    _getSiblingContainerFromPosition(item, x, y) {
        return this._siblings.find((sibling) => sibling._canReceive(item, x, y));
    }
    _canReceive(item, x, y) {
        if (!this._clientRect ||
            !isInsideClientRect(this._clientRect, x, y) ||
            !this.enterPredicate(item, this)) {
            return false;
        }
        const elementFromPoint = this._getShadowRoot().elementFromPoint(x, y);
        if (!elementFromPoint) {
            return false;
        }
        const nativeElement = coerceElement(this.element);
        return (elementFromPoint === nativeElement ||
            nativeElement.contains(elementFromPoint));
    }
    _startReceiving(sibling, items) {
        const activeSiblings = this._activeSiblings;
        if (!activeSiblings.has(sibling) &&
            items.every((item) => {
                return (this.enterPredicate(item, this) || this._draggables.indexOf(item) > -1);
            })) {
            activeSiblings.add(sibling);
            this._cacheParentPositions();
            this._listenToScrollEvents();
        }
    }
    _stopReceiving(sibling) {
        this._activeSiblings.delete(sibling);
        this._viewportScrollSubscription.unsubscribe();
    }
    _draggingStarted() {
        const styles = coerceElement(this.element).style;
        this.beforeStarted.next();
        this._isDragging = true;
        this._initialScrollSnap =
            styles.msScrollSnapType || styles.scrollSnapType || '';
        styles.scrollSnapType = styles.msScrollSnapType = 'none';
        this._sortStrategy.start(this._draggables);
        this._cacheParentPositions();
        this._viewportScrollSubscription.unsubscribe();
        this._listenToScrollEvents();
    }
    _cacheParentPositions() {
        const element = coerceElement(this.element);
        this._parentPositions.cache(this._scrollableElements);
        this._clientRect =
            this._parentPositions.positions.get(element).clientRect;
    }
    _reset() {
        this._isDragging = false;
        const styles = coerceElement(this.element).style;
        styles.scrollSnapType = styles.msScrollSnapType = this._initialScrollSnap;
        this._siblings.forEach((sibling) => sibling._stopReceiving(this));
        this._sortStrategy.reset();
        this._stopScrolling();
        this._viewportScrollSubscription.unsubscribe();
        this._parentPositions.clear();
    }
    _listenToScrollEvents() {
        this._viewportScrollSubscription = this._dragDropRegistry
            .scrolled(this._getShadowRoot())
            .subscribe((event) => {
            if (this.isDragging()) {
                const scrollDifference = this._parentPositions.handleScroll(event);
                if (scrollDifference) {
                    this._sortStrategy.updateOnScroll(scrollDifference.top, scrollDifference.left);
                }
            }
            else if (this.isReceiving()) {
                this._cacheParentPositions();
            }
        });
    }
    _getShadowRoot() {
        if (!this._cachedShadowRoot) {
            const shadowRoot = _getShadowRoot(coerceElement(this.element));
            this._cachedShadowRoot = (shadowRoot || this._document);
        }
        return this._cachedShadowRoot;
    }
    _notifyReceivingSiblings() {
        const draggedItems = this._sortStrategy
            .getActiveItemsSnapshot()
            .filter((item) => item.isDragging());
        this._siblings.forEach((sibling) => sibling._startReceiving(this, draggedItems));
    }
}
function getVerticalScrollDirection(clientRect, pointerY) {
    const { top, bottom, height } = clientRect;
    const yThreshold = height * SCROLL_PROXIMITY_THRESHOLD;
    if (pointerY >= top - yThreshold && pointerY <= top + yThreshold) {
        return 1 /* AutoScrollVerticalDirection.UP */;
    }
    else if (pointerY >= bottom - yThreshold &&
        pointerY <= bottom + yThreshold) {
        return 2 /* AutoScrollVerticalDirection.DOWN */;
    }
    return 0 /* AutoScrollVerticalDirection.NONE */;
}
function getHorizontalScrollDirection(clientRect, pointerX) {
    const { left, right, width } = clientRect;
    const xThreshold = width * SCROLL_PROXIMITY_THRESHOLD;
    if (pointerX >= left - xThreshold && pointerX <= left + xThreshold) {
        return 1 /* AutoScrollHorizontalDirection.LEFT */;
    }
    else if (pointerX >= right - xThreshold && pointerX <= right + xThreshold) {
        return 2 /* AutoScrollHorizontalDirection.RIGHT */;
    }
    return 0 /* AutoScrollHorizontalDirection.NONE */;
}
function getElementScrollDirections(element, clientRect, pointerX, pointerY) {
    const computedVertical = getVerticalScrollDirection(clientRect, pointerY);
    const computedHorizontal = getHorizontalScrollDirection(clientRect, pointerX);
    let verticalScrollDirection = 0 /* AutoScrollVerticalDirection.NONE */;
    let horizontalScrollDirection = 0 /* AutoScrollHorizontalDirection.NONE */;
    if (computedVertical) {
        const scrollTop = element.scrollTop;
        if (computedVertical === 1 /* AutoScrollVerticalDirection.UP */) {
            if (scrollTop > 0) {
                verticalScrollDirection = 1 /* AutoScrollVerticalDirection.UP */;
            }
        }
        else if (element.scrollHeight - scrollTop > element.clientHeight) {
            verticalScrollDirection = 2 /* AutoScrollVerticalDirection.DOWN */;
        }
    }
    if (computedHorizontal) {
        const scrollLeft = element.scrollLeft;
        if (computedHorizontal === 1 /* AutoScrollHorizontalDirection.LEFT */) {
            if (scrollLeft > 0) {
                horizontalScrollDirection = 1 /* AutoScrollHorizontalDirection.LEFT */;
            }
        }
        else if (element.scrollWidth - scrollLeft > element.clientWidth) {
            horizontalScrollDirection = 2 /* AutoScrollHorizontalDirection.RIGHT */;
        }
    }
    return [verticalScrollDirection, horizontalScrollDirection];
}

class DragDropRegistry {
    constructor(_ngZone, _document) {
        this._ngZone = _ngZone;
        this.pointerMove = new Subject();
        this.pointerUp = new Subject();
        this.scroll = new Subject();
        this._dropInstances = new Set();
        this._dragInstances = new Set();
        this._activeDragInstances = [];
        this._globalListeners = new Map();
        this._draggingPredicate = (item) => item.isDragging();
        this._preventDefaultWhileDragging = (event) => {
            if (this._activeDragInstances.length > 0) {
                event.preventDefault();
            }
        };
        this._persistentTouchmoveListener = (event) => {
            if (this._activeDragInstances.length > 0) {
                if (this._activeDragInstances.some(this._draggingPredicate)) {
                    event.preventDefault();
                }
                this.pointerMove.next(event);
            }
        };
        this._document = _document;
    }
    ngOnDestroy() {
        this._dragInstances.forEach((instance) => this.removeDragItem(instance));
        this._dropInstances.forEach((instance) => this.removeDropContainer(instance));
        this._clearGlobalListeners();
        this.pointerMove.complete();
        this.pointerUp.complete();
    }
    registerDropContainer(drop) {
        if (!this._dropInstances.has(drop)) {
            this._dropInstances.add(drop);
        }
    }
    registerDragItem(drag) {
        this._dragInstances.add(drag);
        if (this._dragInstances.size === 1) {
            this._ngZone.runOutsideAngular(() => {
                this._document.addEventListener('touchmove', this._persistentTouchmoveListener, activeCapturingEventOptions);
            });
        }
    }
    removeDropContainer(drop) {
        this._dropInstances.delete(drop);
    }
    removeDragItem(drag) {
        this._dragInstances.delete(drag);
        this.stopDragging(drag);
        if (this._dragInstances.size === 0) {
            this._document.removeEventListener('touchmove', this._persistentTouchmoveListener, activeCapturingEventOptions);
        }
    }
    startDragging(drag, event) {
        if (this._activeDragInstances.indexOf(drag) > -1) {
            return;
        }
        this._activeDragInstances.push(drag);
        if (this._activeDragInstances.length === 1) {
            const isTouchEvent = event.type.startsWith('touch');
            this._globalListeners
                .set(isTouchEvent ? 'touchend' : 'mouseup', {
                handler: (e) => this.pointerUp.next(e),
                options: true,
            })
                .set('scroll', {
                handler: (e) => this.scroll.next(e),
                options: true,
            })
                .set('selectstart', {
                handler: this._preventDefaultWhileDragging,
                options: activeCapturingEventOptions,
            });
            if (!isTouchEvent) {
                this._globalListeners.set('mousemove', {
                    handler: (e) => this.pointerMove.next(e),
                    options: activeCapturingEventOptions,
                });
            }
            this._ngZone.runOutsideAngular(() => {
                this._globalListeners.forEach((config, name) => {
                    this._document.addEventListener(name, config.handler, config.options);
                });
            });
        }
    }
    stopDragging(drag) {
        const index = this._activeDragInstances.indexOf(drag);
        if (index > -1) {
            this._activeDragInstances.splice(index, 1);
            if (this._activeDragInstances.length === 0) {
                this._clearGlobalListeners();
            }
        }
    }
    isDragging(drag) {
        return this._activeDragInstances.indexOf(drag) > -1;
    }
    scrolled(shadowRoot) {
        const streams = [this.scroll];
        if (shadowRoot && shadowRoot !== this._document) {
            streams.push(new Observable((observer) => {
                return this._ngZone.runOutsideAngular(() => {
                    const eventOptions = true;
                    const callback = (event) => {
                        if (this._activeDragInstances.length) {
                            observer.next(event);
                        }
                    };
                    shadowRoot.addEventListener('scroll', callback, eventOptions);
                    return () => {
                        shadowRoot.removeEventListener('scroll', callback, eventOptions);
                    };
                });
            }));
        }
        return merge(...streams);
    }
    _clearGlobalListeners() {
        this._globalListeners.forEach((config, name) => {
            this._document.removeEventListener(name, config.handler, config.options);
        });
        this._globalListeners.clear();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: DragDropRegistry, deps: [{ token: i0.NgZone }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: DragDropRegistry, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: DragDropRegistry, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

class DragDrop {
    constructor(_document, _ngZone, _viewportRuler, _dragDropRegistry) {
        this._document = _document;
        this._ngZone = _ngZone;
        this._viewportRuler = _viewportRuler;
        this._dragDropRegistry = _dragDropRegistry;
    }
    createDrag(element, config = DEFAULT_CONFIG) {
        return new DragRef(element, config, this._document, this._ngZone, this._viewportRuler, this._dragDropRegistry);
    }
    createDropList(element) {
        return new DropListRef(element, this._dragDropRegistry, this._document, this._ngZone, this._viewportRuler);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: DragDrop, deps: [{ token: DOCUMENT }, { token: i0.NgZone }, { token: i1.ViewportRuler }, { token: DragDropRegistry }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: DragDrop, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: DragDrop, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.NgZone }, { type: i1.ViewportRuler }, { type: DragDropRegistry }] });

class CubCdkDropListGroup {
    constructor() {
        this._items = new Set();
        this._disabled = false;
    }
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    ngOnDestroy() {
        this._items.clear();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDropListGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkDropListGroup, isStandalone: true, selector: "[cubCdkDropListGroup]", inputs: { disabled: ["cubCdkDropListGroupDisabled", "disabled"] }, providers: [
            { provide: CUB_CDK_DROP_LIST_GROUP, useExisting: CubCdkDropListGroup },
        ], exportAs: ["cubCdkDropListGroup"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDropListGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubCdkDropListGroup]',
                    exportAs: 'cubCdkDropListGroup',
                    providers: [
                        { provide: CUB_CDK_DROP_LIST_GROUP, useExisting: CubCdkDropListGroup },
                    ],
                }]
        }], propDecorators: { disabled: [{
                type: Input,
                args: ['cubCdkDropListGroupDisabled']
            }] } });

let _uniqueIdCounter = 0;
class CubCdkDropList {
    static { this._dropLists = []; }
    get disabled() {
        return this._disabled || (!!this._group && this._group.disabled);
    }
    set disabled(value) {
        this._dropListRef.disabled = this._disabled = coerceBooleanProperty(value);
    }
    constructor(element, dragDrop, _changeDetectorRef, _scrollDispatcher, _dir, _group, config) {
        this.element = element;
        this._changeDetectorRef = _changeDetectorRef;
        this._scrollDispatcher = _scrollDispatcher;
        this._dir = _dir;
        this._group = _group;
        this._unsortedItems = new Set();
        this._destroyed = new Subject();
        this.connectedTo = [];
        this.id = `cub-cdk-drop-list-${_uniqueIdCounter++}`;
        this.enterPredicate = () => true;
        this.sortPredicate = () => true;
        this.dropped = new EventEmitter();
        this.entered = new EventEmitter();
        this.exited = new EventEmitter();
        this.sorted = new EventEmitter();
        this._dropListRef = dragDrop.createDropList(element);
        this._dropListRef.data = this;
        if (config) {
            this._assignDefaults(config);
        }
        this._dropListRef.enterPredicate = (drag, drop) => {
            return this.enterPredicate(drag.data, drop.data);
        };
        this._dropListRef.sortPredicate = (index, drag, drop) => {
            return this.sortPredicate(index, drag.data, drop.data);
        };
        this._setupInputSyncSubscription(this._dropListRef);
        this._handleEvents(this._dropListRef);
        CubCdkDropList._dropLists.push(this);
        if (_group) {
            _group._items.add(this);
        }
    }
    addItem(item) {
        this._unsortedItems.add(item);
        if (this._dropListRef.isDragging()) {
            this._syncItemsWithRef();
        }
    }
    removeItem(item) {
        this._unsortedItems.delete(item);
        if (this._dropListRef.isDragging()) {
            this._syncItemsWithRef();
        }
    }
    getSortedItems() {
        return Array.from(this._unsortedItems).sort((a, b) => {
            const documentPosition = a._dragRef
                .getVisibleElement()
                .compareDocumentPosition(b._dragRef.getVisibleElement());
            return documentPosition & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
        });
    }
    ngOnDestroy() {
        const index = CubCdkDropList._dropLists.indexOf(this);
        if (index > -1) {
            CubCdkDropList._dropLists.splice(index, 1);
        }
        if (this._group) {
            this._group._items.delete(this);
        }
        this._unsortedItems.clear();
        this._dropListRef.dispose();
        this._destroyed.next();
        this._destroyed.complete();
    }
    _setupInputSyncSubscription(ref) {
        if (this._dir) {
            this._dir.change
                .pipe(startWith(this._dir.value), takeUntil(this._destroyed))
                .subscribe((value) => ref.withDirection(value));
        }
        ref.beforeStarted.subscribe(() => {
            const siblings = coerceArray(this.connectedTo).map((drop) => {
                if (typeof drop === 'string') {
                    const correspondingDropList = CubCdkDropList._dropLists.find((list) => list.id === drop);
                    return correspondingDropList;
                }
                return drop;
            });
            if (this._group) {
                this._group._items.forEach((drop) => {
                    if (siblings.indexOf(drop) === -1) {
                        siblings.push(drop);
                    }
                });
            }
            if (!this._scrollableParentsResolved) {
                const scrollableParents = this._scrollDispatcher
                    .getAncestorScrollContainers(this.element)
                    .map((scrollable) => scrollable.getElementRef().nativeElement);
                this._dropListRef.withScrollableParents(scrollableParents);
                this._scrollableParentsResolved = true;
            }
            ref.disabled = this.disabled;
            ref.lockAxis = this.lockAxis;
            ref.sortingDisabled = coerceBooleanProperty(this.sortingDisabled);
            ref.autoScrollDisabled = coerceBooleanProperty(this.autoScrollDisabled);
            ref.autoScrollStep = coerceNumberProperty(this.autoScrollStep, 2);
            ref
                .connectedTo(siblings
                .filter((drop) => drop && drop !== this)
                .map((list) => list._dropListRef))
                .withOrientation(this.orientation);
        });
    }
    _handleEvents(ref) {
        ref.beforeStarted.subscribe(() => {
            this._syncItemsWithRef();
            this._changeDetectorRef.markForCheck();
        });
        ref.entered.subscribe((event) => {
            this.entered.emit({
                container: this,
                item: event.item.data,
                currentIndex: event.currentIndex,
            });
        });
        ref.exited.subscribe((event) => {
            this.exited.emit({
                container: this,
                item: event.item.data,
            });
            this._changeDetectorRef.markForCheck();
        });
        ref.sorted.subscribe((event) => {
            this.sorted.emit({
                previousIndex: event.previousIndex,
                currentIndex: event.currentIndex,
                container: this,
                item: event.item.data,
            });
        });
        ref.dropped.subscribe((dropEvent) => {
            this.dropped.emit({
                previousIndex: dropEvent.previousIndex,
                currentIndex: dropEvent.currentIndex,
                previousContainer: dropEvent.previousContainer.data,
                container: dropEvent.container.data,
                item: dropEvent.item.data,
                isPointerOverContainer: dropEvent.isPointerOverContainer,
                distance: dropEvent.distance,
                dropPoint: dropEvent.dropPoint,
                event: dropEvent.event,
            });
            this._changeDetectorRef.markForCheck();
        });
    }
    _assignDefaults(config) {
        const { lockAxis, draggingDisabled, sortingDisabled, listAutoScrollDisabled, listOrientation, } = config;
        this.disabled = draggingDisabled == null ? false : draggingDisabled;
        this.sortingDisabled = sortingDisabled == null ? false : sortingDisabled;
        this.autoScrollDisabled =
            listAutoScrollDisabled == null ? false : listAutoScrollDisabled;
        this.orientation = listOrientation || 'vertical';
        if (lockAxis) {
            this.lockAxis = lockAxis;
        }
    }
    _syncItemsWithRef() {
        this._dropListRef.withItems(this.getSortedItems().map((item) => item._dragRef));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDropList, deps: [{ token: i0.ElementRef }, { token: DragDrop }, { token: i0.ChangeDetectorRef }, { token: i1.ScrollDispatcher }, { token: i3.Directionality, optional: true }, { token: CUB_CDK_DROP_LIST_GROUP, optional: true, skipSelf: true }, { token: CUB_CDK_DRAG_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkDropList, isStandalone: true, selector: "[cubCdkDropList], cub-cdk-drop-list", inputs: { connectedTo: ["cubCdkDropListConnectedTo", "connectedTo"], data: ["cubCdkDropListData", "data"], orientation: ["cubCdkDropListOrientation", "orientation"], id: "id", lockAxis: ["cubCdkDropListLockAxis", "lockAxis"], disabled: ["cubCdkDropListDisabled", "disabled"], sortingDisabled: ["cubCdkDropListSortingDisabled", "sortingDisabled"], enterPredicate: ["cubCdkDropListEnterPredicate", "enterPredicate"], sortPredicate: ["cubCdkDropListSortPredicate", "sortPredicate"], autoScrollDisabled: ["cubCdkDropListAutoScrollDisabled", "autoScrollDisabled"], autoScrollStep: ["cubCdkDropListAutoScrollStep", "autoScrollStep"] }, outputs: { dropped: "cubCdkDropListDropped", entered: "cubCdkDropListEntered", exited: "cubCdkDropListExited", sorted: "cubCdkDropListSorted" }, host: { properties: { "attr.id": "id", "class.cub-cdk-drop-list-disabled": "disabled", "class.cub-cdk-drop-list-dragging": "_dropListRef.isDragging()", "class.cub-cdk-drop-list-receiving": "_dropListRef.isReceiving()" }, classAttribute: "cub-cdk-drop-list" }, providers: [
            { provide: CUB_CDK_DROP_LIST_GROUP, useValue: undefined },
            { provide: CUB_CDK_DROP_LIST, useExisting: CubCdkDropList },
        ], exportAs: ["cubCdkDropList"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDropList, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubCdkDropList], cub-cdk-drop-list',
                    exportAs: 'cubCdkDropList',
                    providers: [
                        { provide: CUB_CDK_DROP_LIST_GROUP, useValue: undefined },
                        { provide: CUB_CDK_DROP_LIST, useExisting: CubCdkDropList },
                    ],
                    host: {
                        class: 'cub-cdk-drop-list',
                        '[attr.id]': 'id',
                        '[class.cub-cdk-drop-list-disabled]': 'disabled',
                        '[class.cub-cdk-drop-list-dragging]': '_dropListRef.isDragging()',
                        '[class.cub-cdk-drop-list-receiving]': '_dropListRef.isReceiving()',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: DragDrop }, { type: i0.ChangeDetectorRef }, { type: i1.ScrollDispatcher }, { type: i3.Directionality, decorators: [{
                    type: Optional
                }] }, { type: CubCdkDropListGroup, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CDK_DROP_LIST_GROUP]
                }, {
                    type: SkipSelf
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CDK_DRAG_CONFIG]
                }] }], propDecorators: { connectedTo: [{
                type: Input,
                args: ['cubCdkDropListConnectedTo']
            }], data: [{
                type: Input,
                args: ['cubCdkDropListData']
            }], orientation: [{
                type: Input,
                args: ['cubCdkDropListOrientation']
            }], id: [{
                type: Input
            }], lockAxis: [{
                type: Input,
                args: ['cubCdkDropListLockAxis']
            }], disabled: [{
                type: Input,
                args: ['cubCdkDropListDisabled']
            }], sortingDisabled: [{
                type: Input,
                args: ['cubCdkDropListSortingDisabled']
            }], enterPredicate: [{
                type: Input,
                args: ['cubCdkDropListEnterPredicate']
            }], sortPredicate: [{
                type: Input,
                args: ['cubCdkDropListSortPredicate']
            }], autoScrollDisabled: [{
                type: Input,
                args: ['cubCdkDropListAutoScrollDisabled']
            }], autoScrollStep: [{
                type: Input,
                args: ['cubCdkDropListAutoScrollStep']
            }], dropped: [{
                type: Output,
                args: ['cubCdkDropListDropped']
            }], entered: [{
                type: Output,
                args: ['cubCdkDropListEntered']
            }], exited: [{
                type: Output,
                args: ['cubCdkDropListExited']
            }], sorted: [{
                type: Output,
                args: ['cubCdkDropListSorted']
            }] } });

class CubCdkDragHandle {
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        this._stateChanges.next(this);
    }
    constructor(element, parentDrag) {
        this.element = element;
        this._stateChanges = new Subject();
        this._disabled = false;
        this._parentDrag = parentDrag;
    }
    ngOnDestroy() {
        this._stateChanges.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragHandle, deps: [{ token: i0.ElementRef }, { token: CUB_CDK_DRAG_PARENT, optional: true, skipSelf: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkDragHandle, isStandalone: true, selector: "[cubCdkDragHandle]", inputs: { disabled: ["cubCdkDragHandleDisabled", "disabled"] }, host: { classAttribute: "cub-cdk-drag-handle" }, providers: [{ provide: CUB_CDK_DRAG_HANDLE, useExisting: CubCdkDragHandle }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragHandle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubCdkDragHandle]',
                    host: {
                        class: 'cub-cdk-drag-handle',
                    },
                    providers: [{ provide: CUB_CDK_DRAG_HANDLE, useExisting: CubCdkDragHandle }],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_CDK_DRAG_PARENT]
                }, {
                    type: Optional
                }, {
                    type: SkipSelf
                }] }], propDecorators: { disabled: [{
                type: Input,
                args: ['cubCdkDragHandleDisabled']
            }] } });

class CubCdkDrag {
    static { this._dragInstances = []; }
    get disabled() {
        return (this._disabled || (this.dropContainer && this.dropContainer.disabled));
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        this._dragRef.disabled = this._disabled;
    }
    constructor(element, dropContainer, _document, _ngZone, _viewContainerRef, config, _dir, dragDrop, _changeDetectorRef, _selfHandle, _parentDrag) {
        this.element = element;
        this.dropContainer = dropContainer;
        this._ngZone = _ngZone;
        this._viewContainerRef = _viewContainerRef;
        this._dir = _dir;
        this._changeDetectorRef = _changeDetectorRef;
        this._selfHandle = _selfHandle;
        this._parentDrag = _parentDrag;
        this._destroyed = new Subject();
        this.started = new EventEmitter();
        this.released = new EventEmitter();
        this.ended = new EventEmitter();
        this.entered = new EventEmitter();
        this.exited = new EventEmitter();
        this.dropped = new EventEmitter();
        this.moved = new Observable((observer) => {
            const subscription = this._dragRef.moved
                .pipe(map((movedEvent) => ({
                source: this,
                pointerPosition: movedEvent.pointerPosition,
                event: movedEvent.event,
                delta: movedEvent.delta,
                distance: movedEvent.distance,
            })))
                .subscribe(observer);
            return () => {
                subscription.unsubscribe();
            };
        });
        this._dragRef = dragDrop.createDrag(element, {
            dragStartThreshold: config && config.dragStartThreshold != null
                ? config.dragStartThreshold
                : 5,
            pointerDirectionChangeThreshold: config && config.pointerDirectionChangeThreshold != null
                ? config.pointerDirectionChangeThreshold
                : 5,
            zIndex: config?.zIndex,
        });
        this._dragRef.data = this;
        CubCdkDrag._dragInstances.push(this);
        if (config) {
            this._assignDefaults(config);
        }
        if (dropContainer) {
            this._dragRef._withDropContainer(dropContainer._dropListRef);
            dropContainer.addItem(this);
        }
        this._syncInputs(this._dragRef);
        this._handleEvents(this._dragRef);
    }
    ngAfterViewInit() {
        this._ngZone.runOutsideAngular(() => {
            this._ngZone.onStable
                .pipe(take(1), takeUntil(this._destroyed))
                .subscribe(() => {
                this._updateRootElement();
                this._setupHandlesListener();
                if (this.freeDragPosition) {
                    this._dragRef.setFreeDragPosition(this.freeDragPosition);
                }
            });
        });
    }
    ngOnChanges(changes) {
        const rootSelectorChange = changes['rootElementSelector'];
        const positionChange = changes['freeDragPosition'];
        if (rootSelectorChange && !rootSelectorChange.firstChange) {
            this._updateRootElement();
        }
        if (positionChange &&
            !positionChange.firstChange &&
            this.freeDragPosition) {
            this._dragRef.setFreeDragPosition(this.freeDragPosition);
        }
    }
    ngOnDestroy() {
        if (this.dropContainer) {
            this.dropContainer.removeItem(this);
        }
        const index = CubCdkDrag._dragInstances.indexOf(this);
        if (index > -1) {
            CubCdkDrag._dragInstances.splice(index, 1);
        }
        this._ngZone.runOutsideAngular(() => {
            this._destroyed.next();
            this._destroyed.complete();
            this._dragRef.dispose();
        });
    }
    getPlaceholderElement() {
        return this._dragRef.getPlaceholderElement();
    }
    getRootElement() {
        return this._dragRef.getRootElement();
    }
    reset() {
        this._dragRef.reset();
    }
    getFreeDragPosition() {
        return this._dragRef.getFreeDragPosition();
    }
    setFreeDragPosition(value) {
        this._dragRef.setFreeDragPosition(value);
    }
    _updateRootElement() {
        const element = this.element.nativeElement;
        let rootElement = element;
        if (this.rootElementSelector) {
            rootElement =
                element.closest !== undefined
                    ? element.closest(this.rootElementSelector)
                    : element.parentElement?.closest(this.rootElementSelector);
        }
        this._dragRef.withRootElement(rootElement || element);
    }
    _getBoundaryElement() {
        const boundary = this.boundaryElement;
        if (!boundary) {
            return null;
        }
        if (typeof boundary === 'string') {
            return this.element.nativeElement.closest(boundary);
        }
        return coerceElement(boundary);
    }
    _syncInputs(ref) {
        ref.beforeStarted.subscribe(() => {
            if (!ref.isDragging()) {
                const dir = this._dir;
                const dragStartDelay = this.dragStartDelay;
                const placeholder = this._placeholderTemplate
                    ? {
                        template: this._placeholderTemplate.templateRef,
                        context: this._placeholderTemplate.data,
                        viewContainer: this._viewContainerRef,
                    }
                    : null;
                const preview = this._previewTemplate
                    ? {
                        template: this._previewTemplate.templateRef,
                        context: this._previewTemplate.data,
                        matchSize: this._previewTemplate.matchSize,
                        viewContainer: this._viewContainerRef,
                    }
                    : null;
                ref.disabled = this.disabled;
                ref.lockAxis = this.lockAxis;
                ref.dragStartDelay =
                    typeof dragStartDelay === 'object' && dragStartDelay
                        ? dragStartDelay
                        : coerceNumberProperty(dragStartDelay);
                ref.constrainPosition = this.constrainPosition;
                ref.previewClass = this.previewClass;
                ref
                    .withBoundaryElement(this._getBoundaryElement())
                    .withPlaceholderTemplate(placeholder)
                    .withPreviewTemplate(preview)
                    .withPreviewContainer(this.previewContainer || 'global');
                if (dir) {
                    ref.withDirection(dir.value);
                }
            }
        });
        ref.beforeStarted.pipe(take(1)).subscribe(() => {
            if (this._parentDrag) {
                ref.withParent(this._parentDrag._dragRef);
                return;
            }
            let parent = this.element.nativeElement.parentElement;
            while (parent) {
                if (parent.classList.contains(DRAG_HOST_CLASS)) {
                    ref.withParent(CubCdkDrag._dragInstances.find((drag) => {
                        return drag.element.nativeElement === parent;
                    })?._dragRef || null);
                    break;
                }
                parent = parent.parentElement;
            }
        });
    }
    _handleEvents(ref) {
        ref.started.subscribe((startEvent) => {
            this.started.emit({ source: this, event: startEvent.event });
            this._changeDetectorRef.markForCheck();
        });
        ref.released.subscribe((releaseEvent) => {
            this.released.emit({ source: this, event: releaseEvent.event });
        });
        ref.ended.subscribe((endEvent) => {
            this.ended.emit({
                source: this,
                distance: endEvent.distance,
                dropPoint: endEvent.dropPoint,
                event: endEvent.event,
            });
            this._changeDetectorRef.markForCheck();
        });
        ref.entered.subscribe((enterEvent) => {
            this.entered.emit({
                container: enterEvent.container.data,
                item: this,
                currentIndex: enterEvent.currentIndex,
            });
        });
        ref.exited.subscribe((exitEvent) => {
            this.exited.emit({
                container: exitEvent.container.data,
                item: this,
            });
        });
        ref.dropped.subscribe((dropEvent) => {
            this.dropped.emit({
                previousIndex: dropEvent.previousIndex,
                currentIndex: dropEvent.currentIndex,
                previousContainer: dropEvent.previousContainer.data,
                container: dropEvent.container.data,
                isPointerOverContainer: dropEvent.isPointerOverContainer,
                item: this,
                distance: dropEvent.distance,
                dropPoint: dropEvent.dropPoint,
                event: dropEvent.event,
            });
        });
    }
    _assignDefaults(config) {
        const { lockAxis, dragStartDelay, constrainPosition, previewClass, boundaryElement, draggingDisabled, rootElementSelector, previewContainer, } = config;
        this.disabled = draggingDisabled == null ? false : draggingDisabled;
        this.dragStartDelay = dragStartDelay || 0;
        if (lockAxis) {
            this.lockAxis = lockAxis;
        }
        if (constrainPosition) {
            this.constrainPosition = constrainPosition;
        }
        if (previewClass) {
            this.previewClass = previewClass;
        }
        if (boundaryElement) {
            this.boundaryElement = boundaryElement;
        }
        if (rootElementSelector) {
            this.rootElementSelector = rootElementSelector;
        }
        if (previewContainer) {
            this.previewContainer = previewContainer;
        }
    }
    _setupHandlesListener() {
        this._handles.changes
            .pipe(startWith(this._handles), tap((handles) => {
            const childHandleElements = handles
                .filter((handle) => handle._parentDrag === this)
                .map((handle) => handle.element);
            if (this._selfHandle && this.rootElementSelector) {
                childHandleElements.push(this.element);
            }
            this._dragRef.withHandles(childHandleElements);
        }), switchMap((handles) => {
            return merge(...handles.map((item) => {
                return item._stateChanges.pipe(startWith(item));
            }));
        }), takeUntil(this._destroyed))
            .subscribe((handleInstance) => {
            const dragRef = this._dragRef;
            const handle = handleInstance.element.nativeElement;
            handleInstance.disabled
                ? dragRef.disableHandle(handle)
                : dragRef.enableHandle(handle);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDrag, deps: [{ token: i0.ElementRef }, { token: CUB_CDK_DROP_LIST, optional: true, skipSelf: true }, { token: DOCUMENT }, { token: i0.NgZone }, { token: i0.ViewContainerRef }, { token: CUB_CDK_DRAG_CONFIG, optional: true }, { token: i3.Directionality, optional: true }, { token: DragDrop }, { token: i0.ChangeDetectorRef }, { token: CUB_CDK_DRAG_HANDLE, optional: true, self: true }, { token: CUB_CDK_DRAG_PARENT, optional: true, skipSelf: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkDrag, isStandalone: true, selector: "[cubCdkDrag]", inputs: { data: ["cubCdkDragData", "data"], lockAxis: ["cubCdkDragLockAxis", "lockAxis"], rootElementSelector: ["cubCdkDragRootElement", "rootElementSelector"], boundaryElement: ["cubCdkDragBoundary", "boundaryElement"], dragStartDelay: ["cubCdkDragStartDelay", "dragStartDelay"], freeDragPosition: ["cubCdkDragFreeDragPosition", "freeDragPosition"], disabled: ["cubCdkDragDisabled", "disabled"], constrainPosition: ["cubCdkDragConstrainPosition", "constrainPosition"], previewClass: ["cubCdkDragPreviewClass", "previewClass"], previewContainer: ["cubCdkDragPreviewContainer", "previewContainer"] }, outputs: { started: "cubCdkDragStarted", released: "cubCdkDragReleased", ended: "cubCdkDragEnded", entered: "cubCdkDragEntered", exited: "cubCdkDragExited", dropped: "cubCdkDragDropped", moved: "cubCdkDragMoved" }, host: { properties: { "class.cub-cdk-drag-disabled": "disabled", "class.cub-cdk-drag-dragging": "_dragRef.isDragging()" }, classAttribute: "cub-cdk-drag" }, providers: [{ provide: CUB_CDK_DRAG_PARENT, useExisting: CubCdkDrag }], queries: [{ propertyName: "_previewTemplate", first: true, predicate: CUB_CDK_DRAG_PREVIEW, descendants: true }, { propertyName: "_placeholderTemplate", first: true, predicate: CUB_CDK_DRAG_PLACEHOLDER, descendants: true }, { propertyName: "_handles", predicate: CUB_CDK_DRAG_HANDLE, descendants: true }], exportAs: ["cubCdkDrag"], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDrag, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubCdkDrag]',
                    exportAs: 'cubCdkDrag',
                    host: {
                        class: DRAG_HOST_CLASS,
                        '[class.cub-cdk-drag-disabled]': 'disabled',
                        '[class.cub-cdk-drag-dragging]': '_dragRef.isDragging()',
                    },
                    providers: [{ provide: CUB_CDK_DRAG_PARENT, useExisting: CubCdkDrag }],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: CubCdkDropList, decorators: [{
                    type: Inject,
                    args: [CUB_CDK_DROP_LIST]
                }, {
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.NgZone }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CDK_DRAG_CONFIG]
                }] }, { type: i3.Directionality, decorators: [{
                    type: Optional
                }] }, { type: DragDrop }, { type: i0.ChangeDetectorRef }, { type: CubCdkDragHandle, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }, {
                    type: Inject,
                    args: [CUB_CDK_DRAG_HANDLE]
                }] }, { type: CubCdkDrag, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }, {
                    type: Inject,
                    args: [CUB_CDK_DRAG_PARENT]
                }] }], propDecorators: { data: [{
                type: Input,
                args: ['cubCdkDragData']
            }], lockAxis: [{
                type: Input,
                args: ['cubCdkDragLockAxis']
            }], rootElementSelector: [{
                type: Input,
                args: ['cubCdkDragRootElement']
            }], boundaryElement: [{
                type: Input,
                args: ['cubCdkDragBoundary']
            }], dragStartDelay: [{
                type: Input,
                args: ['cubCdkDragStartDelay']
            }], freeDragPosition: [{
                type: Input,
                args: ['cubCdkDragFreeDragPosition']
            }], disabled: [{
                type: Input,
                args: ['cubCdkDragDisabled']
            }], constrainPosition: [{
                type: Input,
                args: ['cubCdkDragConstrainPosition']
            }], previewClass: [{
                type: Input,
                args: ['cubCdkDragPreviewClass']
            }], previewContainer: [{
                type: Input,
                args: ['cubCdkDragPreviewContainer']
            }], started: [{
                type: Output,
                args: ['cubCdkDragStarted']
            }], released: [{
                type: Output,
                args: ['cubCdkDragReleased']
            }], ended: [{
                type: Output,
                args: ['cubCdkDragEnded']
            }], entered: [{
                type: Output,
                args: ['cubCdkDragEntered']
            }], exited: [{
                type: Output,
                args: ['cubCdkDragExited']
            }], dropped: [{
                type: Output,
                args: ['cubCdkDragDropped']
            }], moved: [{
                type: Output,
                args: ['cubCdkDragMoved']
            }], _handles: [{
                type: ContentChildren,
                args: [CUB_CDK_DRAG_HANDLE, { descendants: true }]
            }], _previewTemplate: [{
                type: ContentChild,
                args: [CUB_CDK_DRAG_PREVIEW]
            }], _placeholderTemplate: [{
                type: ContentChild,
                args: [CUB_CDK_DRAG_PLACEHOLDER]
            }] } });

class CubCdkDragPlaceholder {
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragPlaceholder, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkDragPlaceholder, isStandalone: true, selector: "ng-template[cubCdkDragPlaceholder]", inputs: { data: "data" }, providers: [
            { provide: CUB_CDK_DRAG_PLACEHOLDER, useExisting: CubCdkDragPlaceholder },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragPlaceholder, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[cubCdkDragPlaceholder]',
                    providers: [
                        { provide: CUB_CDK_DRAG_PLACEHOLDER, useExisting: CubCdkDragPlaceholder },
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { data: [{
                type: Input
            }] } });

class CubCdkDragPreview {
    get matchSize() {
        return this._matchSize;
    }
    set matchSize(value) {
        this._matchSize = coerceBooleanProperty(value);
    }
    constructor(templateRef) {
        this.templateRef = templateRef;
        this._matchSize = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragPreview, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkDragPreview, isStandalone: true, selector: "ng-template[cubCdkDragPreview]", inputs: { data: "data", matchSize: "matchSize" }, providers: [
            { provide: CUB_CDK_DRAG_PREVIEW, useExisting: CubCdkDragPreview },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragPreview, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[cubCdkDragPreview]',
                    providers: [
                        { provide: CUB_CDK_DRAG_PREVIEW, useExisting: CubCdkDragPreview },
                    ],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { data: [{
                type: Input
            }], matchSize: [{
                type: Input
            }] } });

class CubCdkDragDropModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragDropModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragDropModule, imports: [CubCdkDragHandle,
            CubCdkDropList,
            CubCdkDropListGroup,
            CubCdkDrag,
            CubCdkDragPlaceholder,
            CubCdkDragPreview], exports: [CubCdkScrollableModule,
            CubCdkDragHandle,
            CubCdkDropList,
            CubCdkDropListGroup,
            CubCdkDrag,
            CubCdkDragPlaceholder,
            CubCdkDragPreview] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragDropModule, providers: [DragDrop], imports: [CubCdkScrollableModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkDragDropModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkDragHandle,
                        CubCdkDropList,
                        CubCdkDropListGroup,
                        CubCdkDrag,
                        CubCdkDragPlaceholder,
                        CubCdkDragPreview,
                    ],
                    exports: [
                        CubCdkScrollableModule,
                        CubCdkDragHandle,
                        CubCdkDropList,
                        CubCdkDropListGroup,
                        CubCdkDrag,
                        CubCdkDragPlaceholder,
                        CubCdkDragPreview,
                    ],
                    providers: [DragDrop],
                }]
        }] });

// config

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_CDK_DRAG_CONFIG, CUB_CDK_DRAG_HANDLE, CUB_CDK_DRAG_PARENT, CUB_CDK_DRAG_PLACEHOLDER, CUB_CDK_DRAG_PREVIEW, CUB_CDK_DROP_LIST, CUB_CDK_DROP_LIST_GROUP, CubCdkDrag, CubCdkDragDropModule, CubCdkDragHandle, CubCdkDragPlaceholder, CubCdkDragPreview, CubCdkDropList, CubCdkDropListGroup, DEFAULT_CONFIG, DRAG_HOST_CLASS, DROP_PROXIMITY_THRESHOLD, DragDrop, DragDropRegistry, DragRef, DropListRef, MOUSE_EVENT_IGNORE_TIME, ParentPositionTracker, SCROLL_PROXIMITY_THRESHOLD, SingleAxisSortStrategy, activeCapturingEventOptions, activeEventListenerOptions, adjustClientRect, assertElementNode, combineTransforms, copyArrayItem, deepCloneNode, dragImportantProperties, extendStyles, getMutableClientRect, getTransformTransitionDurationInMs, isInsideClientRect, isPointerNearClientRect, moveItemInArray, passiveEventListenerOptions, toggleNativeDragInteractions, toggleVisibility, transferArrayItem };
//# sourceMappingURL=cub-lib-view-rootng-cdk-drag-drop.mjs.map
