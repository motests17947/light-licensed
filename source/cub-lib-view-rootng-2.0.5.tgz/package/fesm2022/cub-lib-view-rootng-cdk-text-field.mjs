import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Output, Directive, HostListener, Input, NgModule } from '@angular/core';
import * as i1 from 'cub-lib-view-rootng/cdk/platform';
import { normalizePassiveListenerOptions } from 'cub-lib-view-rootng/cdk/platform';
import { coerceElement, coerceBooleanProperty, coerceNumberProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { EMPTY, Subject } from 'rxjs';

/** Options to pass to the animationstart listener. */
const listenerOptions = normalizePassiveListenerOptions({ passive: true });
/**
 * An injectable service that can be used to monitor the autofill state of an input.
 * Based on the following blog post:
 * https://medium.com/@brunn/detecting-autofilled-fields-in-javascript-aed598d25da7
 */
class AutofillMonitor {
    constructor(_platform, _ngZone) {
        this._platform = _platform;
        this._ngZone = _ngZone;
        this._monitoredElements = new Map();
    }
    monitor(elementOrRef) {
        if (!this._platform.isBrowser) {
            return EMPTY;
        }
        const element = coerceElement(elementOrRef);
        const info = this._monitoredElements.get(element);
        if (info) {
            return info.subject;
        }
        const result = new Subject();
        const cssClass = 'cub-cdk-text-field-autofilled';
        const listener = ((event) => {
            // Animation events fire on initial element render, we check for the presence of the autofill
            // CSS class to make sure this is a real change in state, not just the initial render before
            // we fire off events.
            if (event.animationName === 'cub-cdk-text-field-autofill-start' &&
                !element.classList.contains(cssClass)) {
                element.classList.add(cssClass);
                this._ngZone.run(() => result.next({ target: event.target, isAutofilled: true }));
            }
            else if (event.animationName === 'cub-cdk-text-field-autofill-end' &&
                element.classList.contains(cssClass)) {
                element.classList.remove(cssClass);
                this._ngZone.run(() => result.next({ target: event.target, isAutofilled: false }));
            }
        });
        this._ngZone.runOutsideAngular(() => {
            element.addEventListener('animationstart', listener, listenerOptions);
            element.classList.add('cub-cdk-text-field-autofill-monitored');
        });
        this._monitoredElements.set(element, {
            subject: result,
            unlisten: () => {
                element.removeEventListener('animationstart', listener, listenerOptions);
            },
        });
        return result;
    }
    stopMonitoring(elementOrRef) {
        const element = coerceElement(elementOrRef);
        const info = this._monitoredElements.get(element);
        if (info) {
            info.unlisten();
            info.subject.complete();
            element.classList.remove('cub-cdk-text-field-autofill-monitored');
            element.classList.remove('cub-cdk-text-field-autofilled');
            this._monitoredElements.delete(element);
        }
    }
    ngOnDestroy() {
        this._monitoredElements.forEach((_info, element) => this.stopMonitoring(element));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: AutofillMonitor, deps: [{ token: i1.Platform }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: AutofillMonitor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: AutofillMonitor, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.Platform }, { type: i0.NgZone }] });
/** A directive that can be used to monitor the autofill state of an input. */
class CubCdkAutofill {
    constructor(_elementRef, _autofillMonitor) {
        this._elementRef = _elementRef;
        this._autofillMonitor = _autofillMonitor;
        /** Emits when the autofill state of the element changes. */
        this.cubCdkAutofill = new EventEmitter();
    }
    ngOnInit() {
        this._autofillMonitor
            .monitor(this._elementRef)
            .subscribe((event) => this.cubCdkAutofill.emit(event));
    }
    ngOnDestroy() {
        this._autofillMonitor.stopMonitoring(this._elementRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkAutofill, deps: [{ token: i0.ElementRef }, { token: AutofillMonitor }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkAutofill, isStandalone: true, selector: "[cubCdkAutofill]", outputs: { cubCdkAutofill: "cubCdkAutofill" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkAutofill, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubCdkAutofill]',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: AutofillMonitor }], propDecorators: { cubCdkAutofill: [{
                type: Output
            }] } });

class WindowRef {
    get nativeWindow() {
        return window;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: WindowRef, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: WindowRef, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: WindowRef, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

const MAX_LOOKUP_RETRIES = 3;
class CubCdkTextareaAutosize {
    /** 是否禁用拖拉調整大小，預設為 false。 */
    get disabledHandleResizing() {
        return this._disabledHandleResizing;
    }
    set disabledHandleResizing(value) {
        this._disabledHandleResizing = coerceBooleanProperty(value);
    }
    /** 控制是否啟用 textarea 自動調整大小功能，預設值為 true。 */
    set _autosize(autosize) {
        this.autosize = typeof autosize === 'boolean' ? autosize : true;
    }
    /** 設定 textarea 的最小行數，預設值為 undefined。 */
    get minRows() {
        return this._minRows;
    }
    set minRows(value) {
        this._minRows = +coerceNumberProperty(value);
        if (this.textAreaEl) {
            this.textAreaEl.rows = this._minRows;
        }
    }
    /** 設定 textarea 的最大行數，預設值為 undefined。 */
    get maxRows() {
        return this._maxRows;
    }
    set maxRows(value) {
        this._maxRows = coerceNumberProperty(value);
    }
    onInput(textArea) {
        this.adjust();
    }
    constructor(element, _window, _zone) {
        this.element = element;
        this._window = _window;
        this._zone = _zone;
        this.autosize = true;
        this.retries = 0;
        this.onlyGrow = false;
        this.useImportant = false;
        this._disabledHandleResizing = false;
        this._destroyed = false;
        this.resized = new EventEmitter();
        if (this.element.nativeElement.tagName !== 'TEXTAREA') {
            this._findNestedTextArea();
        }
        else {
            this.textAreaEl = this.element.nativeElement;
            this._onTextAreaFound();
        }
    }
    ngOnDestroy() {
        this._destroyed = true;
        if (this._windowResizeHandler) {
            this._window.nativeWindow.removeEventListener('resize', this._windowResizeHandler, false);
        }
    }
    ngAfterContentChecked() {
        this.adjust();
    }
    ngOnChanges(changes) {
        this.adjust(true);
    }
    _findNestedTextArea() {
        this.textAreaEl = this.element.nativeElement.querySelector('TEXTAREA');
        if (!this.textAreaEl && this.element.nativeElement.shadowRoot) {
            this.textAreaEl =
                this.element.nativeElement.shadowRoot.querySelector('TEXTAREA');
        }
        if (!this.textAreaEl) {
            if (this.retries >= MAX_LOOKUP_RETRIES) {
                console.warn('cub-autosize: textarea not found');
            }
            else {
                this.retries++;
                setTimeout(() => {
                    this._findNestedTextArea();
                }, 100);
            }
            return;
        }
        this.textAreaEl.style['overflow-y'] = 'hidden';
        this._onTextAreaFound();
    }
    _onTextAreaFound() {
        this._addWindowResizeHandler();
        setTimeout(() => {
            this.adjust();
        });
    }
    _addWindowResizeHandler() {
        this._windowResizeHandler = debounce(() => {
            this._zone.run(() => {
                this.adjust();
            });
        }, 200);
        this._zone.runOutsideAngular(() => {
            this._window.nativeWindow.addEventListener('resize', this._windowResizeHandler, false);
        });
    }
    adjust(inputsChanged = false) {
        if (this.autosize &&
            !this._destroyed &&
            this.textAreaEl &&
            this.textAreaEl.parentNode) {
            const currentText = this.textAreaEl.value;
            if (inputsChanged === false &&
                currentText === this._oldContent &&
                this.textAreaEl.offsetWidth === this._oldWidth) {
                return;
            }
            this._oldContent = currentText;
            this._oldWidth = this.textAreaEl.offsetWidth;
            const clone = this.textAreaEl.cloneNode(true);
            const parent = this.textAreaEl.parentNode;
            clone.style.width = this.textAreaEl.offsetWidth + 'px';
            clone.style.visibility = 'hidden';
            clone.style.position = 'absolute';
            clone.textContent = currentText;
            parent.appendChild(clone);
            clone.style['overflow-y'] = 'hidden';
            clone.style.height = 'auto';
            let height = clone.scrollHeight;
            // add into height top and bottom borders' width
            let computedStyle = this._window.nativeWindow.getComputedStyle(clone, null);
            height += parseInt(computedStyle.getPropertyValue('border-top-width'));
            height += parseInt(computedStyle.getPropertyValue('border-bottom-width'));
            if (computedStyle.getPropertyValue('box-sizing') === 'content-box') {
                height -= parseInt(computedStyle.getPropertyValue('padding-top'));
                height -= parseInt(computedStyle.getPropertyValue('padding-bottom'));
            }
            const oldHeight = this.textAreaEl.offsetHeight;
            const willGrow = height > oldHeight;
            if (this.onlyGrow === false || willGrow) {
                const lineHeight = this._getLineHeight();
                const rowsCount = height / lineHeight;
                if (this._minRows && this._minRows >= rowsCount) {
                    height = this._minRows * lineHeight;
                }
                else if (this.maxRows && this.maxRows <= rowsCount) {
                    // never shrink the textarea if onlyGrow is true
                    const maxHeight = this.maxRows * lineHeight;
                    height = this.onlyGrow ? Math.max(maxHeight, oldHeight) : maxHeight;
                    this.textAreaEl.style['overflow-y'] = 'auto';
                }
                else {
                    this.textAreaEl.style['overflow-y'] = 'hidden';
                }
                const heightStyle = height + 'px';
                const important = this.useImportant ? 'important' : '';
                this.textAreaEl.style.setProperty('height', heightStyle, important);
                this.resized.emit(height);
            }
            parent.removeChild(clone);
        }
    }
    _getLineHeight() {
        let lineHeight = parseInt(this.textAreaEl.style.lineHeight, 10);
        if (isNaN(lineHeight) && this._window.nativeWindow.getComputedStyle) {
            const styles = this._window.nativeWindow.getComputedStyle(this.textAreaEl);
            lineHeight = parseInt(styles.lineHeight, 10);
        }
        if (isNaN(lineHeight)) {
            const fontSize = this._window.nativeWindow
                .getComputedStyle(this.textAreaEl, null)
                .getPropertyValue('font-size');
            lineHeight = Math.floor(parseInt(fontSize.replace('px', ''), 10) * 1.5);
        }
        return lineHeight;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkTextareaAutosize, deps: [{ token: i0.ElementRef }, { token: WindowRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCdkTextareaAutosize, isStandalone: true, selector: "textarea[cubCdkTextareaAutosize]", inputs: { disabledHandleResizing: ["cubCdkTextareaDisabledHandleResizing", "disabledHandleResizing"], _autosize: ["cubCdkTextareaAutosize", "_autosize"], minRows: ["cubCdkAutosizeMinRows", "minRows"], maxRows: ["cubCdkAutosizeMaxRows", "maxRows"] }, outputs: { resized: "resized" }, host: { listeners: { "input": "onInput($event.target)" }, properties: { "class.cub-cdk-textarea-autosize-disabled-handle-resizing": "disabledHandleResizing" }, classAttribute: "cub-cdk-textarea-autosize" }, exportAs: ["cubCdkTextareaAutosize"], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkTextareaAutosize, decorators: [{
            type: Directive,
            args: [{
                    selector: 'textarea[cubCdkTextareaAutosize]',
                    exportAs: 'cubCdkTextareaAutosize',
                    host: {
                        class: 'cub-cdk-textarea-autosize',
                        '[class.cub-cdk-textarea-autosize-disabled-handle-resizing]': 'disabledHandleResizing',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: WindowRef }, { type: i0.NgZone }], propDecorators: { disabledHandleResizing: [{
                type: Input,
                args: ['cubCdkTextareaDisabledHandleResizing']
            }], _autosize: [{
                type: Input,
                args: ['cubCdkTextareaAutosize']
            }], minRows: [{
                type: Input,
                args: ['cubCdkAutosizeMinRows']
            }], maxRows: [{
                type: Input,
                args: ['cubCdkAutosizeMaxRows']
            }], resized: [{
                type: Output
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event.target']]
            }] } });
function debounce(func, timeout) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func(...args);
        }, timeout);
    };
}

class CubCdkTextFieldModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkTextFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubCdkTextFieldModule, imports: [CubCdkAutofill, CubCdkTextareaAutosize], exports: [CubCdkAutofill, CubCdkTextareaAutosize] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkTextFieldModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCdkTextFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubCdkAutofill, CubCdkTextareaAutosize],
                    exports: [CubCdkAutofill, CubCdkTextareaAutosize],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AutofillMonitor, CubCdkAutofill, CubCdkTextFieldModule, CubCdkTextareaAutosize, WindowRef };
//# sourceMappingURL=cub-lib-view-rootng-cdk-text-field.mjs.map
