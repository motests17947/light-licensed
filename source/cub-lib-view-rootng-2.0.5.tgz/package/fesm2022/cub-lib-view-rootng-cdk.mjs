import { Version } from '@angular/core';
export * from 'cub-lib-view-rootng/cdk/a11y';
export * from 'cub-lib-view-rootng/cdk/accordion';
export * from 'cub-lib-view-rootng/cdk/bidi';
export * from 'cub-lib-view-rootng/cdk/clipboard';
export * from 'cub-lib-view-rootng/cdk/coercion';
export * from 'cub-lib-view-rootng/cdk/collections';
export * from 'cub-lib-view-rootng/cdk/dialog';
export * from 'cub-lib-view-rootng/cdk/drag-drop';
export * from 'cub-lib-view-rootng/cdk/keycodes';
export * from 'cub-lib-view-rootng/cdk/layout';
export * from 'cub-lib-view-rootng/cdk/observers';
export * from 'cub-lib-view-rootng/cdk/overlay';
export * from 'cub-lib-view-rootng/cdk/platform';
export * from 'cub-lib-view-rootng/cdk/portal';
export * from 'cub-lib-view-rootng/cdk/scrolling';
export * from 'cub-lib-view-rootng/cdk/stepper';
export * from 'cub-lib-view-rootng/cdk/text-field';
export * from 'cub-lib-view-rootng/cdk/tree';

/*
 * Public API Surface of cub-lib-view-rootng/cdk
 */
const VERSION = new Version('2.0.5');

/**
 * Generated bundle index. Do not edit.
 */

export { VERSION };
//# sourceMappingURL=cub-lib-view-rootng-cdk.mjs.map
