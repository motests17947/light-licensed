import * as i0 from '@angular/core';
import { InjectionToken, Inject, Optional, Directive, EventEmitter, DOCUMENT, ViewChild, ContentChild, Output, SkipSelf, ChangeDetectionStrategy, ViewEncapsulation, Component, inject, NgZone, ContentChildren, Host, Attribute, QueryList, Input, NgModule } from '@angular/core';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { Subject, BehaviorSubject, Subscription, EMPTY, merge } from 'rxjs';
import { distinctUntilChanged, startWith, filter, take, debounceTime, map, takeUntil } from 'rxjs/operators';
import { TemplatePortal, CubCdkPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { CubCdkAccordionItem, CubCdkAccordion } from 'cub-lib-view-rootng/cdk/accordion';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i1 from 'cub-lib-view-rootng/cdk/collections';
import { AsyncPipe } from '@angular/common';
import { ENTER, hasModifierKey, SPACE } from 'cub-lib-view-rootng/cdk/keycodes';
import { mixinTabIndex, CubRipple, CUB_PREFIX, CUB_END, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import * as i2 from 'cub-lib-view-rootng/cdk/a11y';
import { FocusKeyManager } from 'cub-lib-view-rootng/cdk/a11y';

const CUB_ACCORDION = new InjectionToken('CUB_ACCORDION');
const CUB_ACCORDION_PANEL = new InjectionToken('CUB_ACCORDION_PANEL');

/** Time and timing curve for accordion panel animations. */
// Note: Keep this in sync with the Sass variable for the panel header animation.
const CUB_ACCORDION_PANEL_ANIMATION_TIMING = '225ms cubic-bezier(0.4,0.0,0.2,1)';
/**
 * Animations used by the Material accordion panel.

 * Angular 動畫的 `state` 在使用 ViewContainerRef.move() 移動視圖容器時存在一個漏洞，
 * 導致被移動組件的動畫狀態在離開 DOM 時變為 `void`，並且在重新進入 DOM 時不會再次更新。
 * 這可能會導致擴充面板出現一種情況，即面板處於展開 (`expanded`) 或折疊 (`collapsed`) 狀態，
 * 但動畫狀態是 `void`。

 * 為了正確處理動畫到下一個狀態，我們在 `void` 和 `collapsed` 之間進行動畫，
 * 這兩個狀態被定義為具有相同的樣式。由於 Angular 會從目前樣式動畫到目標狀態的樣式定義，
 * 在從 `void` 的樣式移動到 `collapsed` 的情況下，這會起到一個無操作的作用，因為沒有樣式值發生變化。

 * 在 Angular 的動畫狀態與擴充面板狀態不同步的情況下，即擴充面板處於展開 (`expanded`) 狀態，
 * 而 Angular 動畫處於 `void` 狀態，那麼從展開狀態的有效樣式（儘管處於 `void` 動畫狀態）
 * 到折疊狀態的動畫將如預期發生。

 * Angular Bug：https://github.com/angular/angular/issues/18847

 * @docs-private
 */
const cubAccordionAnimations = {
    /** Animation that rotates the indicator arrow. */
    indicatorRotate: trigger('indicatorRotate', [
        state('collapsed, void', style({ transform: 'rotate(0deg)' })),
        state('expanded', style({ transform: 'rotate(180deg)' })),
        transition('expanded <=> collapsed, void => collapsed', animate(CUB_ACCORDION_PANEL_ANIMATION_TIMING)),
    ]),
    /** Animation that expands and collapses the panel content. */
    bodyAccordion: trigger('bodyAccordion', [
        state('collapsed, void', style({ height: '0px', visibility: 'hidden' })),
        state('expanded', style({ height: '*', visibility: 'visible' })),
        transition('expanded <=> collapsed, void => collapsed', animate(CUB_ACCORDION_PANEL_ANIMATION_TIMING)),
    ]),
};

class CubAccordionPanelContent {
    constructor(_template, _accordionPanel) {
        this._template = _template;
        this._accordionPanel = _accordionPanel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelContent, deps: [{ token: i0.TemplateRef }, { token: CUB_ACCORDION_PANEL, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAccordionPanelContent, isStandalone: true, selector: "ng-template[cubAccordionPanelContent]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelContent, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[cubAccordionPanelContent]' }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_ACCORDION_PANEL]
                }, {
                    type: Optional
                }] }] });

const CUB_ACCORDION_PANEL_DEFAULT_OPTIONS = new InjectionToken('CUB_ACCORDION_PANEL_DEFAULT_OPTIONS');

/** Counter for generating unique element ids. */
let uniqueId = 0;
/**
 * disabled 為是否禁用 accordion，預設值為 'false'。
 * expanded 為是否展開，預設值為 'false'。
 */
class CubAccordionPanel extends CubCdkAccordionItem {
    // 目前無此功能
    get hideToggle() {
        return this._hideToggle || (this.accordion && this.accordion.hideToggle);
    }
    set hideToggle(value) {
        this._hideToggle = coerceBooleanProperty(value);
    }
    // 目前無此功能
    get togglePosition() {
        return (this._togglePosition || (this.accordion && this.accordion.togglePosition));
    }
    set togglePosition(value) {
        this._togglePosition = value;
    }
    constructor(accordion, _changeDetectorRef, _uniqueSelectionDispatcher, _viewContainerRef, _document, _animationMode, defaultOptions) {
        super(accordion, _changeDetectorRef, _uniqueSelectionDispatcher);
        this._viewContainerRef = _viewContainerRef;
        this._animationMode = _animationMode;
        this.paddingStyle = {};
        this._headerId = `cub-accordion-panel-header-${uniqueId++}`;
        this._inputChanges = new Subject();
        this._bodyAnimationDone = new Subject();
        this._hideToggle = false;
        /*
         * 展開時會發送事件，值為 undefined。
         */
        this.afterExpand = new EventEmitter();
        /*
         * 關閉時會發送事件，值為 undefined。
         */
        this.afterCollapse = new EventEmitter();
        this.accordion = accordion;
        this._document = _document;
        // We need a Subject with distinctUntilChanged, because the `done` event
        // fires twice on some browsers. See https://github.com/angular/angular/issues/24084
        this._bodyAnimationDone
            .pipe(distinctUntilChanged((x, y) => {
            return x.fromState === y.fromState && x.toState === y.toState;
        }))
            .subscribe((event) => {
            if (event.fromState !== 'void') {
                if (event.toState === 'expanded') {
                    this.afterExpand.emit();
                }
                else if (event.toState === 'collapsed') {
                    this.afterCollapse.emit();
                }
            }
        });
        if (defaultOptions) {
            this.hideToggle = defaultOptions.hideToggle;
        }
    }
    ngAfterContentInit() {
        if (this._lazyContent && this._lazyContent._accordionPanel === this) {
            // Render the content as soon as the panel becomes open.
            this.opened
                .pipe(startWith(null), filter(() => this.expanded && !this._portal), take(1))
                .subscribe(() => {
                this._portal = new TemplatePortal(this._lazyContent._template, this._viewContainerRef);
            });
        }
    }
    ngOnChanges(changes) {
        this._inputChanges.next(changes);
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        this._bodyAnimationDone.complete();
        this._inputChanges.complete();
    }
    toggle() {
        this.expanded = !this.expanded;
    }
    close() {
        this.expanded = false;
    }
    open() {
        this.expanded = true;
    }
    _hasSpacing() {
        if (this.accordion) {
            return this.expanded && this.accordion.displayMode === 'default';
        }
        return false;
    }
    _getExpandedState() {
        return this.expanded ? 'expanded' : 'collapsed';
    }
    _containsFocus() {
        if (this._body) {
            const focusedElement = this._document.activeElement;
            const bodyElement = this._body.nativeElement;
            return (focusedElement === bodyElement || bodyElement.contains(focusedElement));
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanel, deps: [{ token: CUB_ACCORDION, optional: true, skipSelf: true }, { token: i0.ChangeDetectorRef }, { token: i1.UniqueSelectionDispatcher }, { token: i0.ViewContainerRef }, { token: DOCUMENT }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: CUB_ACCORDION_PANEL_DEFAULT_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubAccordionPanel, isStandalone: true, selector: "cub-accordion-panel", inputs: { disabled: "disabled", expanded: "expanded" }, outputs: { opened: "opened", closed: "closed", expandedChange: "expandedChange", afterExpand: "afterExpand", afterCollapse: "afterCollapse" }, host: { properties: { "class.cub-expanded": "expanded", "class.cub-animation-noop-able": "_animationMode === \"NoopAnimations\"", "class.cub-accordion-panel-spacing": "_hasSpacing()" }, classAttribute: "cub-accordion-panel" }, providers: [
            // Provide CubAccordionPanel as undefined to prevent nested accordion panels from registering
            // to the same accordion.
            { provide: CUB_ACCORDION, useValue: undefined },
            { provide: CUB_ACCORDION_PANEL, useExisting: CubAccordionPanel },
        ], queries: [{ propertyName: "_lazyContent", first: true, predicate: CubAccordionPanelContent, descendants: true }], viewQueries: [{ propertyName: "_body", first: true, predicate: ["body"], descendants: true }], exportAs: ["cubAccordionPanel"], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<ng-content select=\"cub-accordion-panel-header\"></ng-content>\n<div\n  class=\"cub-accordion-panel-content\"\n  role=\"region\"\n  [@bodyAccordion]=\"_getExpandedState()\"\n  (@bodyAccordion.done)=\"_bodyAnimationDone.next($event)\"\n  [attr.aria-labelledby]=\"_headerId\"\n  [id]=\"id\"\n  #body\n>\n  <div class=\"cub-accordion-panel-body\">\n    <ng-content></ng-content>\n    <ng-template [cubCdkPortalOutlet]=\"_portal\"></ng-template>\n  </div>\n  <ng-content select=\"cub-action-row\"></ng-content>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkPortalOutlet, selector: "[cubCdkPortalOutlet]", inputs: ["cubCdkPortalOutlet"], outputs: ["attached"], exportAs: ["cubCdkPortalOutlet"] }], animations: [cubAccordionAnimations.bodyAccordion], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanel, decorators: [{
            type: Component,
            args: [{ selector: 'cub-accordion-panel', exportAs: 'cubAccordionPanel', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, inputs: ['disabled', 'expanded'], outputs: ['opened', 'closed', 'expandedChange'], animations: [cubAccordionAnimations.bodyAccordion], providers: [
                        // Provide CubAccordionPanel as undefined to prevent nested accordion panels from registering
                        // to the same accordion.
                        { provide: CUB_ACCORDION, useValue: undefined },
                        { provide: CUB_ACCORDION_PANEL, useExisting: CubAccordionPanel },
                    ], host: {
                        class: 'cub-accordion-panel',
                        '[class.cub-expanded]': 'expanded',
                        '[class.cub-animation-noop-able]': '_animationMode === "NoopAnimations"',
                        '[class.cub-accordion-panel-spacing]': '_hasSpacing()',
                    }, imports: [CubCdkPortalOutlet], template: "<ng-content select=\"cub-accordion-panel-header\"></ng-content>\n<div\n  class=\"cub-accordion-panel-content\"\n  role=\"region\"\n  [@bodyAccordion]=\"_getExpandedState()\"\n  (@bodyAccordion.done)=\"_bodyAnimationDone.next($event)\"\n  [attr.aria-labelledby]=\"_headerId\"\n  [id]=\"id\"\n  #body\n>\n  <div class=\"cub-accordion-panel-body\">\n    <ng-content></ng-content>\n    <ng-template [cubCdkPortalOutlet]=\"_portal\"></ng-template>\n  </div>\n  <ng-content select=\"cub-action-row\"></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }, {
                    type: Inject,
                    args: [CUB_ACCORDION]
                }] }, { type: i0.ChangeDetectorRef }, { type: i1.UniqueSelectionDispatcher }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_ACCORDION_PANEL_DEFAULT_OPTIONS]
                }, {
                    type: Optional
                }] }], propDecorators: { afterExpand: [{
                type: Output
            }], afterCollapse: [{
                type: Output
            }], _lazyContent: [{
                type: ContentChild,
                args: [CubAccordionPanelContent]
            }], _body: [{
                type: ViewChild,
                args: ['body']
            }] } });

// Boilerplate for applying mixins to CubAccordionPanelHeader.
/** @docs-private */
class CubAccordionPanelHeaderBase {
}
const _CubAccordionPanelHeaderMixinBase = mixinTabIndex(CubAccordionPanelHeaderBase);
/*
 * 用於設定 tabIndex 屬性， 預設值為 0。
 */
class CubAccordionPanelHeader extends _CubAccordionPanelHeaderMixinBase {
    get rippleDisabled() {
        return this._rippleDisabled || this.disabled;
    }
    set rippleDisabled(value) {
        this._rippleDisabled = value;
    }
    get disabled() {
        return this.panel.disabled;
    }
    constructor(panel, _element, _focusMonitor, _changeDetectorRef, _animationMode, tabIndex) {
        super();
        this.panel = panel;
        this._element = _element;
        this._focusMonitor = _focusMonitor;
        this._changeDetectorRef = _changeDetectorRef;
        this._animationMode = _animationMode;
        this.fontSize = 24;
        this.toggleAvailable = true;
        this.elementInfo = new BehaviorSubject({
            height: 0,
        });
        this.elementWrap$ = this.elementInfo.asObservable().pipe(debounceTime(50), map((info) => {
            if (info) {
                return info.height > this.fontSize;
            }
            return false;
        }));
        this._rippleDisabled = false;
        this._parentChangeSubscription = Subscription.EMPTY;
        this._destroyed = new Subject();
        this.zone = inject(NgZone);
        const accordionHideToggleChange = panel.accordion
            ? panel.accordion._stateChanges.pipe(filter((changes) => !!changes['hideToggle']))
            : EMPTY;
        this.tabIndex = parseInt(tabIndex || '') || 0;
        this._parentChangeSubscription = merge(panel.opened, panel.closed, accordionHideToggleChange, panel._inputChanges.pipe(filter((changes) => {
            return !!(changes['hideToggle'] || changes['disabled']);
        }))).subscribe(() => {
            this._changeDetectorRef.markForCheck();
        });
        panel.closed
            .pipe(filter(() => panel._containsFocus()))
            .subscribe(() => _focusMonitor.focusVia(_element, 'program'));
    }
    ngAfterViewInit() {
        this._focusMonitor
            .monitor(this._element)
            .pipe(takeUntil(this._destroyed))
            .subscribe((origin) => {
            if (origin && this.panel.accordion) {
                this.panel.accordion._handleHeaderFocus(this);
            }
        });
        // 計算 line height
        const regex = new RegExp('[0-9]*');
        const value = getComputedStyle(this.titleElementRef.nativeElement).lineHeight.match(regex);
        if (value && value[0]) {
            this.fontSize = parseInt(value[0], 10);
        }
        this.resizeObserver = new ResizeObserver((entries) => {
            this.zone.run(() => {
                if (entries[0] && entries[0].contentRect) {
                    this.elementInfo.next(entries[0].contentRect);
                }
            });
        });
        this.resizeObserver.observe(this.titleElementRef.nativeElement);
    }
    ngOnDestroy() {
        this._parentChangeSubscription.unsubscribe();
        this._focusMonitor.stopMonitoring(this._element);
        if (this.resizeObserver && this.titleElementRef?.nativeElement) {
            this.resizeObserver.unobserve(this.titleElementRef.nativeElement);
        }
        this._destroyed.next();
        this._destroyed.complete();
    }
    _toggle(e) {
        const target = e.target;
        if (!this.toggleAvailable) {
            return;
        }
        if (!this.disabled) {
            this.panel.toggle();
        }
    }
    _isExpanded() {
        return this.panel.expanded;
    }
    _getExpandedState() {
        return this.panel._getExpandedState();
    }
    _getPanelId() {
        return this.panel.id;
    }
    _showToggle() {
        return !this.panel.hideToggle && !this.panel.disabled;
    }
    _getHostElement() {
        return this._element.nativeElement;
    }
    _getHeaderHeight() {
        const isExpanded = this._isExpanded();
        if (isExpanded && this.expandedHeight) {
            return this.expandedHeight;
        }
        else if (!isExpanded && this.collapsedHeight) {
            return this.collapsedHeight;
        }
        return null;
    }
    _keydown(event) {
        switch (event.keyCode) {
            // Toggle for space and enter keys.
            case SPACE:
            case ENTER:
                if (!hasModifierKey(event)) {
                    event.preventDefault();
                    if (this.toggleAvailable) {
                        this._toggle(event);
                    }
                    else {
                        this.toggleAvailable = true;
                        return;
                    }
                }
                break;
            default:
                if (this.panel.accordion) {
                    this.panel.accordion._handleHeaderKeydown(event);
                }
                return;
        }
    }
    focus(origin, options) {
        if (origin) {
            this._focusMonitor.focusVia(this._element, origin, options);
        }
        else {
            this._element.nativeElement.focus(options);
        }
    }
    disableRipple() {
        this.rippleDisabled = true;
        this.toggleAvailable = false;
    }
    enableRipple() {
        this.rippleDisabled = false;
        this.toggleAvailable = true;
    }
    stopToggle(e) {
        this.toggleAvailable = false;
        e.stopPropagation();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelHeader, deps: [{ token: CubAccordionPanel, host: true }, { token: i0.ElementRef }, { token: i2.FocusMonitor }, { token: i0.ChangeDetectorRef }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: 'tabindex', attribute: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubAccordionPanelHeader, isStandalone: true, selector: "cub-accordion-panel-header", inputs: { tabIndex: "tabIndex" }, host: { attributes: { "role": "button" }, listeners: { "keydown": "_keydown($event)", "click": "_toggle($event)", "tapend": "_toggle($event)" }, properties: { "attr.id": "panel._headerId", "attr.tabindex": "tabIndex", "attr.aria-controls": "_getPanelId()", "attr.aria-expanded": "_isExpanded()", "attr.aria-disabled": "panel.disabled", "class.cub-disabled": "panel.disabled", "class.cub-expanded": "_isExpanded()", "class.cub-animation-noop-able": "_animationMode === \"NoopAnimations\"", "style.height": "_getHeaderHeight()" }, classAttribute: "cub-accordion-panel-header" }, queries: [{ propertyName: "_prefixChildren", predicate: CUB_PREFIX, descendants: true }, { propertyName: "_endChildren", predicate: CUB_END, descendants: true }], viewQueries: [{ propertyName: "titleElementRef", first: true, predicate: ["title"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<span\n  cubRipple\n  cubRippleClass=\"cub-accordion-ripple\"\n  [cubRippleDisabled]=\"rippleDisabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-accordion-persistent-ripple\"></span>\n<div\n  class=\"cub-accordion-header\"\n  [class.cub-accordion-header-top]=\"elementWrap$ | async\"\n>\n  <div\n    class=\"cub-accordion-header-content\"\n    [class.cub-accordion-header-top]=\"elementWrap$ | async\"\n  >\n    <span\n      [@indicatorRotate]=\"_getExpandedState()\"\n      class=\"cub-icon-chevron-down cub-accordion-indicator\"\n    ></span>\n\n    @if (_prefixChildren.length) {\n    <div class=\"cub-accordion-icon\">\n      <ng-content select=\"[cubPrefix]\"></ng-content>\n    </div>\n    }\n    <div #title class=\"cub-accordion-title\">\n      <ng-content></ng-content>\n      <ng-content select=\"[cubSuffix]\"></ng-content>\n    </div>\n  </div>\n  @if (_endChildren.length) {\n  <div\n    class=\"cub-accordion-action\"\n    (touchstart)=\"stopToggle($event)\"\n    (click)=\"stopToggle($event)\"\n    (mouseenter)=\"disableRipple()\"\n    (mouseleave)=\"enableRipple()\"\n    (focus)=\"disableRipple()\"\n    (blur)=\"enableRipple()\"\n    (keydown)=\"stopToggle($event)\"\n  >\n    <ng-content select=\"[cubEnd]\"></ng-content>\n  </div>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], animations: [cubAccordionAnimations.indicatorRotate], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-accordion-panel-header', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, inputs: ['tabIndex'], animations: [cubAccordionAnimations.indicatorRotate], host: {
                        class: 'cub-accordion-panel-header',
                        role: 'button',
                        '[attr.id]': 'panel._headerId',
                        '[attr.tabindex]': 'tabIndex',
                        '[attr.aria-controls]': '_getPanelId()',
                        '[attr.aria-expanded]': '_isExpanded()',
                        '[attr.aria-disabled]': 'panel.disabled',
                        '[class.cub-disabled]': 'panel.disabled',
                        '[class.cub-expanded]': '_isExpanded()',
                        '[class.cub-animation-noop-able]': '_animationMode === "NoopAnimations"',
                        '[style.height]': '_getHeaderHeight()',
                        '(keydown)': '_keydown($event)',
                        '(click)': '_toggle($event)',
                        '(tapend)': '_toggle($event)',
                    }, imports: [CubRipple, AsyncPipe], template: "<span\n  cubRipple\n  cubRippleClass=\"cub-accordion-ripple\"\n  [cubRippleDisabled]=\"rippleDisabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-accordion-persistent-ripple\"></span>\n<div\n  class=\"cub-accordion-header\"\n  [class.cub-accordion-header-top]=\"elementWrap$ | async\"\n>\n  <div\n    class=\"cub-accordion-header-content\"\n    [class.cub-accordion-header-top]=\"elementWrap$ | async\"\n  >\n    <span\n      [@indicatorRotate]=\"_getExpandedState()\"\n      class=\"cub-icon-chevron-down cub-accordion-indicator\"\n    ></span>\n\n    @if (_prefixChildren.length) {\n    <div class=\"cub-accordion-icon\">\n      <ng-content select=\"[cubPrefix]\"></ng-content>\n    </div>\n    }\n    <div #title class=\"cub-accordion-title\">\n      <ng-content></ng-content>\n      <ng-content select=\"[cubSuffix]\"></ng-content>\n    </div>\n  </div>\n  @if (_endChildren.length) {\n  <div\n    class=\"cub-accordion-action\"\n    (touchstart)=\"stopToggle($event)\"\n    (click)=\"stopToggle($event)\"\n    (mouseenter)=\"disableRipple()\"\n    (mouseleave)=\"enableRipple()\"\n    (focus)=\"disableRipple()\"\n    (blur)=\"enableRipple()\"\n    (keydown)=\"stopToggle($event)\"\n  >\n    <ng-content select=\"[cubEnd]\"></ng-content>\n  </div>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: CubAccordionPanel, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }, { type: i2.FocusMonitor }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }], propDecorators: { _prefixChildren: [{
                type: ContentChildren,
                args: [CUB_PREFIX, { descendants: true }]
            }], _endChildren: [{
                type: ContentChildren,
                args: [CUB_END, { descendants: true }]
            }], titleElementRef: [{
                type: ViewChild,
                args: ['title']
            }] } });

class CubAccordion extends CubCdkAccordion {
    constructor() {
        super(...arguments);
        /*
         * 目前無此樣式，accordion 是否有間隔。
         */
        this.displayMode = 'default';
        /*
         * 目前無此樣式 設定toggle 按鈕位置。
         */
        this.togglePosition = 'after';
        /** Headers belonging to this accordion. */
        this._ownHeaders = new QueryList();
        this._hideToggle = false;
        /*
         * 設定accordion 樣式設定， 預設值為 'dark'。
         */
        this.colorScheme = 'dark';
        /*
         * 設定accordion 樣式大小， 預設值為 'medium'。
         */
        this.size = 'medium';
    }
    /*
     * 目前無此樣式 隱藏toggle 按鈕。
     */
    get hideToggle() {
        return this._hideToggle;
    }
    set hideToggle(show) {
        this._hideToggle = coerceBooleanProperty(show);
    }
    ngAfterContentInit() {
        this._headers.changes
            .pipe(startWith(this._headers))
            .subscribe((headers) => {
            this._ownHeaders.reset(headers.filter((header) => header.panel.accordion === this));
            this._ownHeaders.notifyOnChanges();
        });
        this._keyManager = new FocusKeyManager(this._ownHeaders)
            .withWrap()
            .withHomeAndEnd();
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        this._ownHeaders.destroy();
    }
    /** Handles keyboard events coming in from the panel headers. */
    _handleHeaderKeydown(event) {
        this._keyManager.onKeydown(event);
    }
    _handleHeaderFocus(header) {
        this._keyManager.updateActiveItem(header);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordion, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAccordion, isStandalone: true, selector: "cub-accordion", inputs: { multi: "multi", colorScheme: "colorScheme", size: "size" }, host: { properties: { "class.cub-accordion-multi": "this.multi", "class.cub-accordion-medium": "this.size === \"medium\"", "class.cub-accordion-small": "this.size === \"small\"", "class.cub-accordion-large": "this.size === \"large\"", "class.cub-accordion-dark": "this.colorScheme === \"dark\"", "class.cub-accordion-light": "this.colorScheme === \"light\"" }, classAttribute: "cub-accordion" }, providers: [
            {
                provide: CUB_ACCORDION,
                useExisting: CubAccordion,
            },
        ], queries: [{ propertyName: "_headers", predicate: CubAccordionPanelHeader, descendants: true }], exportAs: ["CubAccordion"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordion, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-accordion',
                    exportAs: 'CubAccordion',
                    inputs: ['multi'],
                    providers: [
                        {
                            provide: CUB_ACCORDION,
                            useExisting: CubAccordion,
                        },
                    ],
                    host: {
                        class: 'cub-accordion',
                        // Class binding which is only used by the test harness as there is no other
                        // way for the harness to detect if multiple panel support is enabled.
                        '[class.cub-accordion-multi]': 'this.multi',
                        '[class.cub-accordion-medium]': 'this.size === "medium"',
                        '[class.cub-accordion-small]': 'this.size === "small"',
                        '[class.cub-accordion-large]': 'this.size === "large"',
                        '[class.cub-accordion-dark]': 'this.colorScheme === "dark"',
                        '[class.cub-accordion-light]': 'this.colorScheme === "light"',
                    },
                }]
        }], propDecorators: { colorScheme: [{
                type: Input
            }], size: [{
                type: Input
            }], _headers: [{
                type: ContentChildren,
                args: [CubAccordionPanelHeader, { descendants: true }]
            }] } });

class CubAccordionPanelActionRow {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelActionRow, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAccordionPanelActionRow, isStandalone: true, selector: "cub-action-row", host: { classAttribute: "cub-action-row" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelActionRow, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-action-row',
                    host: {
                        class: 'cub-action-row',
                    }
                }]
        }], ctorParameters: () => [] });

class CubAccordionPanelDescription {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelDescription, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAccordionPanelDescription, isStandalone: true, selector: "cub-panel-description", host: { classAttribute: "cub-accordion-panel-header-description" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-panel-description',
                    host: {
                        class: 'cub-accordion-panel-header-description',
                    }
                }]
        }], ctorParameters: () => [] });

class CubAccordionPanelTitle {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelTitle, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAccordionPanelTitle, isStandalone: true, selector: "cub-panel-title", host: { classAttribute: "cub-accordion-panel-header-title" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionPanelTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-panel-title',
                    host: {
                        class: 'cub-accordion-panel-header-title',
                    }
                }]
        }], ctorParameters: () => [] });

class CubAccordionModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionModule, imports: [CubCommonModule,
            CubAccordionPanelHeader,
            CubAccordionPanel,
            CubAccordionPanelActionRow,
            CubAccordionPanelDescription,
            CubAccordionPanelTitle,
            CubAccordionPanelContent,
            CubAccordion], exports: [CubCommonModule,
            CubAccordionPanelHeader,
            CubAccordionPanel,
            CubAccordionPanelActionRow,
            CubAccordionPanelDescription,
            CubAccordionPanelTitle,
            CubAccordionPanelContent,
            CubAccordion] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionModule, imports: [CubCommonModule, CubCommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAccordionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        CubAccordionPanelHeader,
                        CubAccordionPanel,
                        CubAccordionPanelActionRow,
                        CubAccordionPanelDescription,
                        CubAccordionPanelTitle,
                        CubAccordionPanelContent,
                        CubAccordion,
                    ],
                    exports: [
                        CubCommonModule,
                        CubAccordionPanelHeader,
                        CubAccordionPanel,
                        CubAccordionPanelActionRow,
                        CubAccordionPanelDescription,
                        CubAccordionPanelTitle,
                        CubAccordionPanelContent,
                        CubAccordion,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/accordion
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_ACCORDION, CUB_ACCORDION_PANEL, CUB_ACCORDION_PANEL_ANIMATION_TIMING, CubAccordion, CubAccordionModule, CubAccordionPanel, CubAccordionPanelActionRow, CubAccordionPanelContent, CubAccordionPanelDescription, CubAccordionPanelHeader, CubAccordionPanelTitle, cubAccordionAnimations };
//# sourceMappingURL=cub-lib-view-rootng-component-accordion.mjs.map
