import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component, NgModule } from '@angular/core';
import { NgSwitch, NgSwitchCase } from '@angular/common';
import { CubIconButton } from 'cub-lib-view-rootng/component/button';

class CubAlert {
    constructor(host) {
        this.host = host;
        /**
         元件狀態，預設為 'error'。
         */
        this.status = 'error';
        /**
         是否顯示關閉按鈕，預設為 true。
         */
        this.showClose = true;
        /**
         當關閉元件時發出通知。
         */
        this.closed = new EventEmitter();
    }
    close() {
        this.host.nativeElement.remove();
        this.closed.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAlert, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubAlert, isStandalone: true, selector: "cub-alert", inputs: { status: "status", showClose: "showClose" }, outputs: { closed: "closed" }, host: { properties: { "class.cub-alert-success": "status === \"success\"", "class.cub-alert-warning": "status === \"warning\"", "class.cub-alert-error": "status === \"error\"", "class.cub-alert-neutral": "status === \"neutral\"" }, classAttribute: "cub-alert" }, ngImport: i0, template: "<div class=\"cub-alert-icon\">\n  <ng-container [ngSwitch]=\"status\">\n    <ng-container *ngSwitchCase=\"'success'\">\n      <span class=\"cub-icon-check-circle-filled\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'warning'\">\n      <span class=\"cub-icon-exclamation-triangle-filled\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'error'\">\n      <span class=\"cub-icon-x-circle-filled\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'neutral'\">\n      <span class=\"cub-icon-info-circle-filled\"></span>\n    </ng-container>\n  </ng-container>\n</div>\n\n<div class=\"cub-alert-content\">\n  <ng-content></ng-content>\n</div>\n\n@if (showClose) {\n<div class=\"cub-alert-close\">\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral-light\"\n    appearance=\"plain\"\n    (click)=\"close()\"\n  >\n    <span class=\"cub-icon-x-small\"></span>\n  </button>\n</div>\n\n}\n", styles: [""], dependencies: [{ kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAlert, decorators: [{
            type: Component,
            args: [{ selector: 'cub-alert', host: {
                        class: 'cub-alert',
                        '[class.cub-alert-success]': 'status === "success"',
                        '[class.cub-alert-warning]': 'status === "warning"',
                        '[class.cub-alert-error]': 'status === "error"',
                        '[class.cub-alert-neutral]': 'status === "neutral"',
                    }, imports: [NgSwitch, NgSwitchCase, CubIconButton], template: "<div class=\"cub-alert-icon\">\n  <ng-container [ngSwitch]=\"status\">\n    <ng-container *ngSwitchCase=\"'success'\">\n      <span class=\"cub-icon-check-circle-filled\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'warning'\">\n      <span class=\"cub-icon-exclamation-triangle-filled\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'error'\">\n      <span class=\"cub-icon-x-circle-filled\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'neutral'\">\n      <span class=\"cub-icon-info-circle-filled\"></span>\n    </ng-container>\n  </ng-container>\n</div>\n\n<div class=\"cub-alert-content\">\n  <ng-content></ng-content>\n</div>\n\n@if (showClose) {\n<div class=\"cub-alert-close\">\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral-light\"\n    appearance=\"plain\"\n    (click)=\"close()\"\n  >\n    <span class=\"cub-icon-x-small\"></span>\n  </button>\n</div>\n\n}\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { status: [{
                type: Input
            }], showClose: [{
                type: Input
            }], closed: [{
                type: Output
            }] } });

class CubAlertModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAlertModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubAlertModule, imports: [
            /** Component */
            CubAlert], exports: [
            /** Component */
            CubAlert] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAlertModule, imports: [
            /** Component */
            CubAlert] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAlertModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        /** Component */
                        CubAlert,
                    ],
                    exports: [
                        /** Component */
                        CubAlert,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/alert
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubAlert, CubAlertModule };
//# sourceMappingURL=cub-lib-view-rootng-component-alert.mjs.map
