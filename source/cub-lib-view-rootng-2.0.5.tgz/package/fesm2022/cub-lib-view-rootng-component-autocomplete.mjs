import * as i0 from '@angular/core';
import { InjectionToken, EventEmitter, TemplateRef, ViewChild, Output, Input, Inject, Directive, ContentChildren, ChangeDetectionStrategy, ViewEncapsulation, Component, DOCUMENT, Optional, Host, forwardRef, NgModule } from '@angular/core';
import { NgClass, NgIf } from '@angular/common';
import { CUB_OPTION_GROUP, CubOption, CUB_OPTION_PARENT, CubOptionSelectionChange, _countGroupLabelsBeforeOption, _getOptionScrollPosition, CubOptionModule } from 'cub-lib-view-rootng/component/option';
import { Subscription, merge, of, defer, Subject, fromEvent } from 'rxjs';
import { ActiveDescendantKeyManager } from 'cub-lib-view-rootng/cdk/a11y';
import { coerceBooleanProperty, coerceStringArray } from 'cub-lib-view-rootng/cdk/coercion';
import * as i1$1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, OverlayConfig, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { mixinDisableRipple, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/cdk/platform';
import { _getEventTarget } from 'cub-lib-view-rootng/cdk/platform';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { filter, map, startWith, switchMap, take, tap, delay } from 'rxjs/operators';
import { hasModifierKey, ESCAPE, ENTER, UP_ARROW, DOWN_ARROW, TAB } from 'cub-lib-view-rootng/cdk/keycodes';
import { TemplatePortal } from 'cub-lib-view-rootng/cdk/portal';
import * as i4 from 'cub-lib-view-rootng/component/form-field';
import { CUB_FORM_FIELD, CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import * as i2 from 'cub-lib-view-rootng/cdk/bidi';
import * as i3 from 'cub-lib-view-rootng/cdk/scrolling';
import { CubCdkScrollableModule } from 'cub-lib-view-rootng/cdk/scrolling';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';
import { CubInputGroupModule } from 'cub-lib-view-rootng/component/input-group';

/** @docs-private */
function CUB_AUTOCOMPLETE_DEFAULT_OPTIONS_FACTORY() {
    return {
        autoActiveFirstOption: false,
        autoSelectActiveOption: false,
        overlayPanelClass: 'cub-autocomplete-panel-container',
    };
}
/** @docs-private */
function CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition();
}
/**
 * Creates an error to be thrown when attempting to use an autocomplete trigger without a panel.
 * @docs-private
 */
function getCubAutocompleteMissingPanelError() {
    return Error('Attempting to open an undefined instance of `cub-autocomplete`. ' +
        'Make sure that the id passed to the `cubAutocomplete` is correct and that ' +
        "you're attempting to open it after the ngAfterContentInit hook.");
}

/** Injection token to be used to override the default options for `cub-autocomplete`. */
const CUB_AUTOCOMPLETE_DEFAULT_OPTIONS = new InjectionToken('cub-autocomplete-default-options', {
    providedIn: 'root',
    factory: CUB_AUTOCOMPLETE_DEFAULT_OPTIONS_FACTORY,
});
// Boilerplate for applying mixins to CubAutocomplete.
/** @docs-private */
const _CubAutocompleteMixinBase = mixinDisableRipple(class {
});
/** Injection token that determines the scroll handling while the autocomplete panel is open. */
const CUB_AUTOCOMPLETE_SCROLL_STRATEGY = new InjectionToken('cub-autocomplete-scroll-strategy');
/** @docs-private */
const CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER = {
    provide: CUB_AUTOCOMPLETE_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY,
};

/**
 * Autocomplete IDs need to be unique across components, so this counter exists outside of
 * the component definition.
 */
let _uniqueAutocompleteIdCounter = 0;
/** Event object that is emitted when an autocomplete option is selected. */
class CubAutocompleteSelectedEvent {
    constructor(
    /** Reference to the autocomplete panel that emitted the event. */
    source, 
    /** Option that was selected. */
    option) {
        this.source = source;
        this.option = option;
    }
}
/** Base class with all of the `CubAutocomplete` functionality. */
class _CubAutocompleteBase extends _CubAutocompleteMixinBase {
    /** Whether the autocomplete panel is open. */
    get isOpen() {
        return this._isOpen && this.showPanel;
    }
    /** 元件 Panel 開啟時，是否 Active 顯示第一個選項，預設為 false */
    get autoActiveFirstOption() {
        return this._autoActiveFirstOption;
    }
    set autoActiveFirstOption(value) {
        this._autoActiveFirstOption = coerceBooleanProperty(value);
    }
    /** 元件在使用導行路由時活動選項是否設定為被選擇狀態，預設為 false */
    get autoSelectActiveOption() {
        return this._autoSelectActiveOption;
    }
    set autoSelectActiveOption(value) {
        this._autoSelectActiveOption = coerceBooleanProperty(value);
    }
    /** 元件下拉選單 Panel 的樣式類別，預設為 undefined。 */
    set panelClass(value) {
        if (value && value.length) {
            this._classList = coerceStringArray(value).reduce((classList, className) => {
                classList[className] = true;
                return classList;
            }, {});
        }
        else {
            this._classList = {};
        }
        this._setVisibilityClasses(this._classList);
        this._elementRef.nativeElement.className = '';
    }
    constructor(_changeDetectorRef, _elementRef, defaults, platform) {
        super();
        this._changeDetectorRef = _changeDetectorRef;
        this._elementRef = _elementRef;
        /** Unique ID to be used by autocomplete trigger's "aria-owns" property. */
        this.id = `cub-autocomplete-${_uniqueAutocompleteIdCounter++}`;
        /** Whether the autocomplete panel should be visible, depending on option length. */
        this.showPanel = false;
        this._isOpen = false;
        this._classList = {};
        this._activeOptionChanges = Subscription.EMPTY;
        this._autoActiveFirstOption = false;
        this._autoSelectActiveOption = false;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 元件查無資料的提示文字，在啟用篩選功能時使用，預設為 '無資料'。 */
        this.emptyFilterMessage = '無資料';
        /** 元件將選項的控制元件值對映到觸發器顯示值的函式，預設為 null */
        this.displayWith = null;
        /** 當從清單中選擇一個選項時發出通知。 */
        this.optionSelected = new EventEmitter();
        /** 當開啟下拉選單 Panel 時發出通知。 */
        this.opened = new EventEmitter();
        /** 當關閉下拉選單 Panel 時發出通知。 */
        this.closed = new EventEmitter();
        /** 當啟用選項時發出通知。 */
        this.optionActivated = new EventEmitter();
        // TODO(crisbeto): the problem that the `inertGroups` option resolves is only present on
        // Safari using VoiceOver. We should occasionally check back to see whether the bug
        // wasn't resolved in VoiceOver, and if it has, we can remove this and the `inertGroups`
        // option altogether.
        this.inertGroups = platform?.SAFARI || false;
        this._autoActiveFirstOption = !!defaults.autoActiveFirstOption;
        this._autoSelectActiveOption = !!defaults.autoSelectActiveOption;
    }
    ngAfterContentInit() {
        this._keyManager = new ActiveDescendantKeyManager(this.options).withWrap();
        this._activeOptionChanges = this._keyManager.change.subscribe((index) => {
            if (this.isOpen) {
                this.optionActivated.emit({
                    source: this,
                    option: this.options.toArray()[index] || null,
                });
            }
        });
        // Set the initial visibility state.
        this._setVisibility();
    }
    ngOnDestroy() {
        this._activeOptionChanges.unsubscribe();
    }
    /**
     * Sets the panel scrollTop. This allows us to manually scroll to display options
     * above or below the fold, as they are not actually being focused when active.
     */
    _setScrollTop(scrollTop) {
        if (this.panel) {
            this.panel.nativeElement.scrollTop = scrollTop;
        }
    }
    /** Returns the panel's scrollTop. */
    _getScrollTop() {
        return this.panel ? this.panel.nativeElement.scrollTop : 0;
    }
    /** Panel should hide itself when the option list is empty. */
    _setVisibility() {
        this.showPanel = !!this.options.length;
        this._setVisibilityClasses(this._classList);
        this._changeDetectorRef.markForCheck();
    }
    /** Emits the `select` event. */
    _emitSelectEvent(option) {
        const event = new CubAutocompleteSelectedEvent(this, option);
        this.optionSelected.emit(event);
    }
    /** Gets the aria-labelledby for the autocomplete panel. */
    _getPanelAriaLabelledby(labelId) {
        if (this.ariaLabel) {
            return null;
        }
        const labelExpression = labelId ? labelId + ' ' : '';
        return this.ariaLabelledby
            ? labelExpression + this.ariaLabelledby
            : labelId;
    }
    /** Sets the autocomplete visibility classes on a classlist based on the panel is visible. */
    _setVisibilityClasses(classList) {
        classList[this._visibleClass] = this.showPanel;
        classList[this._hiddenClass] = !this.showPanel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubAutocompleteBase, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: CUB_AUTOCOMPLETE_DEFAULT_OPTIONS }, { token: i1.Platform }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubAutocompleteBase, isStandalone: true, inputs: { size: "size", emptyFilterMessage: "emptyFilterMessage", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], displayWith: "displayWith", autoActiveFirstOption: "autoActiveFirstOption", autoSelectActiveOption: "autoSelectActiveOption", panelWidth: "panelWidth", panelClass: ["class", "panelClass"] }, outputs: { optionSelected: "optionSelected", opened: "opened", closed: "closed", optionActivated: "optionActivated" }, viewQueries: [{ propertyName: "template", first: true, predicate: TemplateRef, descendants: true, static: true }, { propertyName: "panel", first: true, predicate: ["panel"], descendants: true }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubAutocompleteBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_AUTOCOMPLETE_DEFAULT_OPTIONS]
                }] }, { type: i1.Platform }], propDecorators: { size: [{
                type: Input
            }], emptyFilterMessage: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], displayWith: [{
                type: Input
            }], autoActiveFirstOption: [{
                type: Input
            }], autoSelectActiveOption: [{
                type: Input
            }], panelWidth: [{
                type: Input
            }], panelClass: [{
                type: Input,
                args: ['class']
            }], optionSelected: [{
                type: Output
            }], opened: [{
                type: Output
            }], closed: [{
                type: Output
            }], optionActivated: [{
                type: Output
            }], template: [{
                type: ViewChild,
                args: [TemplateRef, { static: true }]
            }], panel: [{
                type: ViewChild,
                args: ['panel']
            }] } });

class CubAutocomplete extends _CubAutocompleteBase {
    constructor() {
        super(...arguments);
        this._visibleClass = 'cub-autocomplete-visible';
        this._hiddenClass = 'cub-autocomplete-hidden';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocomplete, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubAutocomplete, isStandalone: true, selector: "cub-autocomplete", inputs: { disableRipple: "disableRipple" }, host: { classAttribute: "cub-autocomplete" }, providers: [
            {
                provide: CUB_OPTION_PARENT,
                useExisting: CubAutocomplete,
            },
        ], queries: [{ propertyName: "optionGroups", predicate: CUB_OPTION_GROUP, descendants: true }, { propertyName: "options", predicate: CubOption, descendants: true }], exportAs: ["cubAutocomplete"], usesInheritance: true, ngImport: i0, template: "<ng-template let-formFieldId=\"id\">\n  <div\n    class=\"cub-autocomplete-panel\"\n    [class.cub-autocomplete-panel-small]=\"size === 'small'\"\n    role=\"listbox\"\n    [id]=\"id\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"_getPanelAriaLabelledby(formFieldId)\"\n    [ngClass]=\"_classList\"\n    #panel\n  >\n    <div *ngIf=\"options.length === 0\" class=\"cub-filter-empty-message\">\n      {{ emptyFilterMessage }}\n    </div>\n\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocomplete, decorators: [{
            type: Component,
            args: [{ selector: 'cub-autocomplete', exportAs: 'cubAutocomplete', host: {
                        class: 'cub-autocomplete',
                    }, inputs: ['disableRipple'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: CUB_OPTION_PARENT,
                            useExisting: CubAutocomplete,
                        },
                    ], imports: [NgClass, NgIf], template: "<ng-template let-formFieldId=\"id\">\n  <div\n    class=\"cub-autocomplete-panel\"\n    [class.cub-autocomplete-panel-small]=\"size === 'small'\"\n    role=\"listbox\"\n    [id]=\"id\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"_getPanelAriaLabelledby(formFieldId)\"\n    [ngClass]=\"_classList\"\n    #panel\n  >\n    <div *ngIf=\"options.length === 0\" class=\"cub-filter-empty-message\">\n      {{ emptyFilterMessage }}\n    </div>\n\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n" }]
        }], propDecorators: { optionGroups: [{
                type: ContentChildren,
                args: [CUB_OPTION_GROUP, { descendants: true }]
            }], options: [{
                type: ContentChildren,
                args: [CubOption, { descendants: true }]
            }] } });

/** Base class containing all of the functionality for `CubAutocompleteOrigin`. */
class _CubAutocompleteOriginBase {
    constructor(
    /** Reference to the element on which the directive is applied. */
    elementRef) {
        this.elementRef = elementRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubAutocompleteOriginBase, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubAutocompleteOriginBase, isStandalone: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubAutocompleteOriginBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

/**
 * Directive applied to an element to make it usable
 * as a connection point for an autocomplete panel.
 */
class CubAutocompleteOrigin extends _CubAutocompleteOriginBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteOrigin, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAutocompleteOrigin, isStandalone: true, selector: "[cubAutocompleteOrigin]", exportAs: ["cubAutocompleteOrigin"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteOrigin, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubAutocompleteOrigin]',
                    exportAs: 'cubAutocompleteOrigin'
                }]
        }] });

/** Base class with all of the `CubAutocompleteTrigger` functionality. */
class _CubAutocompleteTriggerBase {
    /** Whether or not the autocomplete panel is open. */
    get panelOpen() {
        return this._overlayAttached && this.autocomplete.showPanel;
    }
    /** The currently active option, coerced to CubOption type. */
    get activeOption() {
        if (this.autocomplete && this.autocomplete._keyManager) {
            return this.autocomplete._keyManager.activeItem;
        }
        return null;
    }
    /**
     * A stream of actions that should close the autocomplete panel, including
     * when an option is selected, on blur, and when TAB is pressed.
     */
    get panelClosingActions() {
        return merge(this.optionSelections, this.autocomplete._keyManager.tabOut.pipe(filter(() => this._overlayAttached)), this._closeKeyEventStream, this._getOutsideClickStream(), this._overlayRef
            ? this._overlayRef
                .detachments()
                .pipe(filter(() => this._overlayAttached))
            : of()).pipe(
        // Normalize the output so we return a consistent type.
        map((event) => (event instanceof CubOptionSelectionChange ? event : null)));
    }
    /** 是否停用元件，當停用時將無法開啟該 Panel，預設為否。 */
    get autocompleteDisabled() {
        return this._autocompleteDisabled;
    }
    set autocompleteDisabled(value) {
        this._autocompleteDisabled = coerceBooleanProperty(value);
    }
    constructor(_element, _overlay, _viewContainerRef, _zone, _changeDetectorRef, scrollStrategy, _dir, _formField, _document, _viewportRuler, _defaults) {
        this._element = _element;
        this._overlay = _overlay;
        this._viewContainerRef = _viewContainerRef;
        this._zone = _zone;
        this._changeDetectorRef = _changeDetectorRef;
        this._dir = _dir;
        this._formField = _formField;
        this._document = _document;
        this._viewportRuler = _viewportRuler;
        this._defaults = _defaults;
        /** Stream of changes to the selection state of the autocomplete options. */
        this.optionSelections = defer(() => {
            const options = this.autocomplete ? this.autocomplete.options : null;
            if (options) {
                return options.changes.pipe(startWith(options), switchMap(() => merge(...options.map((option) => option.selectionChange))));
            }
            // If there are any subscribers before `ngAfterViewInit`, the `autocomplete` will be undefined.
            // Return a stream that we'll replace with the real one once everything is in place.
            return this._zone.onStable.pipe(take(1), switchMap(() => this.optionSelections));
        });
        /** Whether or not the label state is being overridden. */
        this._manuallyFloatingLabel = false;
        /** Subscription to viewport size changes. */
        this._viewportSubscription = Subscription.EMPTY;
        this._componentDestroyed = false;
        this._autocompleteDisabled = false;
        /**
         * Whether the autocomplete can open the next time it is focused. Used to prevent a focused,
         * closed autocomplete from being reopened if the user switches to another browser tab and then
         * comes back.
         */
        this._canOpenOnNextFocus = true;
        this._overlayAttached = false;
        /** Stream of keyboard events that can close the panel. */
        this._closeKeyEventStream = new Subject();
        /** 元件下拉選單 Panel 相對於觸發器元素的位置，預設為 'auto'。可取下列值之一：
         * 'auto'：在觸發器下方還有剩餘空間時，會在觸發器下方渲染；反之下方空間不夠，將會在觸發器上方渲染。
         * 'above'：不論觸發器下方是否還有剩餘空間，都會在觸發器上方渲染。
         * 'below'：不論觸發器下方是否還有剩餘空間，都會在觸發器下方渲染。
         */
        this.position = 'auto';
        /** 設定觸發器 autocomplete 屬性，預設為 'off'。 */
        this.autocompleteAttribute = 'off';
        /** `View -> model callback called when value changes` */
        this._onChange = () => { };
        /** `View -> model callback called when autocomplete has been touched` */
        this._onTouched = () => { };
        /**
         * Event handler for when the window is blurred. Needs to be an
         * arrow function in order to preserve the context.
         */
        this._windowBlurHandler = () => {
            // If the user blurred the window while the autocomplete is focused, it means that it'll be
            // refocused when they come back. In this case we want to skip the first focus event, if the
            // pane was closed, in order to avoid reopening it unintentionally.
            this._canOpenOnNextFocus =
                this._document.activeElement !== this._element.nativeElement ||
                    this.panelOpen;
        };
        this._scrollStrategy = scrollStrategy;
    }
    ngAfterViewInit() {
        const window = this._getWindow();
        if (typeof window !== 'undefined') {
            this._zone.runOutsideAngular(() => window.addEventListener('blur', this._windowBlurHandler));
        }
    }
    ngOnChanges(changes) {
        if (changes['position'] && this._positionStrategy) {
            this._setStrategyPositions(this._positionStrategy);
            if (this.panelOpen) {
                this._overlayRef.updatePosition();
            }
        }
    }
    ngOnDestroy() {
        const window = this._getWindow();
        if (typeof window !== 'undefined') {
            window.removeEventListener('blur', this._windowBlurHandler);
        }
        this._viewportSubscription.unsubscribe();
        this._componentDestroyed = true;
        this._destroyPanel();
        this._closeKeyEventStream.complete();
    }
    /** Opens the autocomplete suggestion panel. */
    openPanel() {
        this._attachOverlay();
        this._floatLabel();
    }
    /** Closes the autocomplete suggestion panel. */
    closePanel() {
        this._resetLabel();
        if (!this._overlayAttached) {
            return;
        }
        if (this.panelOpen) {
            // Only emit if the panel was visible.
            // The `NgZone.onStable` always emits outside of the Angular zone,
            // so all the subscriptions from `_subscribeToClosingActions()` are also outside of the Angular zone.
            // We should manually run in Angular zone to update UI after panel closing.
            this._zone.run(() => {
                this.autocomplete.closed.emit();
            });
        }
        this.autocomplete._isOpen = this._overlayAttached = false;
        this._pendingAutoselectedOption = null;
        if (this._overlayRef && this._overlayRef.hasAttached()) {
            this._overlayRef.detach();
            this._closingActionsSubscription.unsubscribe();
        }
        // Note that in some cases this can end up being called after the component is destroyed.
        // Add a check to ensure that we don't try to run change detection on a destroyed view.
        if (!this._componentDestroyed) {
            // We need to trigger change detection manually, because
            // `fromEvent` doesn't seem to do it at the proper time.
            // This ensures that the label is reset when the
            // user clicks outside.
            this._changeDetectorRef.detectChanges();
        }
    }
    /**
     * Updates the position of the autocomplete suggestion panel to ensure that it fits all options
     * within the viewport.
     */
    updatePosition() {
        if (this._overlayAttached) {
            this._overlayRef.updatePosition();
        }
    }
    // Implemented as part of ControlValueAccessor.
    writeValue(value) {
        Promise.resolve(null).then(() => this._assignOptionValue(value));
    }
    // Implemented as part of ControlValueAccessor.
    registerOnChange(fn) {
        this._onChange = fn;
    }
    // Implemented as part of ControlValueAccessor.
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    // Implemented as part of ControlValueAccessor.
    setDisabledState(isDisabled) {
        this._element.nativeElement.disabled = isDisabled;
    }
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        const hasModifier = hasModifierKey(event);
        // Prevent the default action on all escape key presses. This is here primarily to bring IE
        // in line with other browsers. By default, pressing escape on IE will cause it to revert
        // the input value to the one that it had on focus, however it won't dispatch any events
        // which means that the model value will be out of sync with the view.
        if (keyCode === ESCAPE && !hasModifier) {
            event.preventDefault();
        }
        if (this.activeOption &&
            keyCode === ENTER &&
            this.panelOpen &&
            !hasModifier) {
            this.activeOption._selectViaInteraction();
            this._resetActiveItem();
            event.preventDefault();
        }
        else if (this.autocomplete) {
            const prevActiveItem = this.autocomplete._keyManager.activeItem;
            const isArrowKey = keyCode === UP_ARROW || keyCode === DOWN_ARROW;
            if (keyCode === TAB || (isArrowKey && !hasModifier && this.panelOpen)) {
                this.autocomplete._keyManager.onKeydown(event);
            }
            else if (isArrowKey && this._canOpen()) {
                this.openPanel();
            }
            if (isArrowKey ||
                this.autocomplete._keyManager.activeItem !== prevActiveItem) {
                this._scrollToOption(this.autocomplete._keyManager.activeItemIndex || 0);
                if (this.autocomplete.autoSelectActiveOption && this.activeOption) {
                    if (!this._pendingAutoselectedOption) {
                        this._valueBeforeAutoSelection = this._element.nativeElement.value;
                    }
                    this._pendingAutoselectedOption = this.activeOption;
                    this._assignOptionValue(this.activeOption.value);
                }
            }
        }
        if (this.autocomplete._keyManager.activeItem) {
            this.autocomplete._keyManager.activeItem.isKeydownActive = true;
        }
    }
    _handleInput(event) {
        let target = event.target;
        let value = target.value;
        // Based on `NumberValueAccessor` from forms.
        if (target.type === 'number') {
            value = value == '' ? null : parseFloat(value);
        }
        // If the input has a placeholder, IE will fire the `input` event on page load,
        // focus and blur, in addition to when the user actually changed the value. To
        // filter out all of the extra events, we save the value on focus and between
        // `input` events, and we check whether it changed.
        // See: https://connect.microsoft.com/IE/feedback/details/885747/
        if (this._previousValue !== value) {
            this._previousValue = value;
            this._pendingAutoselectedOption = null;
            this._onChange(value);
            if (this._canOpen() && this._document.activeElement === event.target) {
                this.openPanel();
            }
        }
    }
    _handleFocus() {
        if (!this._canOpenOnNextFocus) {
            this._canOpenOnNextFocus = true;
        }
        else if (this._canOpen()) {
            this._previousValue = this._element.nativeElement.value;
            this._attachOverlay();
            this._floatLabel(true);
        }
    }
    _handleClick() {
        if (this._canOpen() && !this.panelOpen) {
            this.openPanel();
        }
    }
    /** Stream of clicks outside of the autocomplete panel. */
    _getOutsideClickStream() {
        return merge(fromEvent(this._document, 'click'), fromEvent(this._document, 'auxclick'), fromEvent(this._document, 'touchend')).pipe(filter((event) => {
            // If we're in the Shadow DOM, the event target will be the shadow root, so we have to
            // fall back to check the first element in the path of the click event.
            const clickTarget = _getEventTarget(event);
            const formField = this._formField
                ? this._formField._elementRef.nativeElement
                : null;
            const customOrigin = this.connectedTo
                ? this.connectedTo.elementRef.nativeElement
                : null;
            return (this._overlayAttached &&
                clickTarget !== this._element.nativeElement &&
                // Normally focus moves inside `mousedown` so this condition will almost always be
                // true. Its main purpose is to handle the case where the input is focused from an
                // outside click which propagates up to the `body` listener within the same sequence
                // and causes the panel to close immediately (see #3106).
                this._document.activeElement !== this._element.nativeElement &&
                (!formField || !formField.contains(clickTarget)) &&
                (!customOrigin || !customOrigin.contains(clickTarget)) &&
                !!this._overlayRef &&
                !this._overlayRef.overlayElement.contains(clickTarget));
        }));
    }
    /**
     * In "auto" mode, the label will animate down as soon as focus is lost.
     * This causes the value to jump when selecting an option with the mouse.
     * This method manually floats the label until the panel can be closed.
     * @param shouldAnimate Whether the label should be animated when it is floated.
     */
    _floatLabel(shouldAnimate = false) {
        if (this._formField) {
            this._manuallyFloatingLabel = true;
        }
    }
    /** If the label has been manually elevated, return it to its normal state. */
    _resetLabel() {
        if (this._manuallyFloatingLabel) {
            this._manuallyFloatingLabel = false;
        }
    }
    /**
     * This method listens to a stream of panel closing actions and resets the
     * stream every time the option list changes.
     */
    _subscribeToClosingActions() {
        const firstStable = this._zone.onStable.pipe(take(1));
        const optionChanges = this.autocomplete.options.changes.pipe(tap(() => this._positionStrategy.reapplyLastPosition()), 
        // Defer emitting to the stream until the next tick, because changing
        // bindings in here will cause "changed after checked" errors.
        delay(0));
        // When the zone is stable initially, and when the option list changes...
        return (merge(firstStable, optionChanges)
            .pipe(
        // create a new stream of panelClosingActions, replacing any previous streams
        // that were created, and flatten it so our stream only emits closing events...
        switchMap(() => {
            // The `NgZone.onStable` always emits outside of the Angular zone, thus we have to re-enter
            // the Angular zone. This will lead to change detection being called outside of the Angular
            // zone and the `autocomplete.opened` will also emit outside of the Angular.
            this._zone.run(() => {
                const wasOpen = this.panelOpen;
                this._resetActiveItem();
                this.autocomplete._setVisibility();
                this._changeDetectorRef.detectChanges();
                if (this.panelOpen) {
                    this._overlayRef.updatePosition();
                }
                if (wasOpen !== this.panelOpen) {
                    // If the `panelOpen` state changed, we need to make sure to emit the `opened` or
                    // `closed` event, because we may not have emitted it. This can happen
                    // - if the users opens the panel and there are no options, but the
                    //   options come in slightly later or as a result of the value changing,
                    // - if the panel is closed after the user entered a string that did not match any
                    //   of the available options,
                    // - if a valid string is entered after an invalid one.
                    if (this.panelOpen) {
                        this.autocomplete.opened.emit();
                    }
                    else {
                        this.autocomplete.closed.emit();
                    }
                }
            });
            return this.panelClosingActions;
        }), 
        // when the first closing event occurs...
        take(1))
            // set the value, close the panel, and complete.
            .subscribe((event) => this._setValueAndClose(event)));
    }
    /** Destroys the autocomplete suggestion panel. */
    _destroyPanel() {
        if (this._overlayRef) {
            this.closePanel();
            this._overlayRef.dispose();
            this._overlayRef = null;
        }
    }
    _assignOptionValue(value) {
        const toDisplay = this.autocomplete && this.autocomplete.displayWith
            ? this.autocomplete.displayWith(value)
            : value;
        // Simply falling back to an empty string if the display value is falsy does not work properly.
        // The display value can also be the number zero and shouldn't fall back to an empty string.
        this._updateNativeInputValue(toDisplay != null ? toDisplay : '');
    }
    _updateNativeInputValue(value) {
        // If it's used within a `CubFormField`, we should set it through the property so it can go
        // through change detection.
        if (this._formField) {
            this._formField._control.value = value;
        }
        else {
            this._element.nativeElement.value = value;
        }
        this._previousValue = value;
    }
    /**
     * This method closes the panel, and if a value is specified, also sets the associated
     * control to that value. It will also mark the control as dirty if this interaction
     * stemmed from the user.
     */
    _setValueAndClose(event) {
        const toSelect = event ? event.source : this._pendingAutoselectedOption;
        if (toSelect) {
            this._clearPreviousSelectedOption(toSelect);
            this._assignOptionValue(toSelect.value);
            this._onChange(toSelect.value);
            this.autocomplete._emitSelectEvent(toSelect);
            this._element.nativeElement.focus();
        }
        this.closePanel();
    }
    /**
     * Clear any previous selected option and emit a selection change event for this option
     */
    _clearPreviousSelectedOption(skip) {
        this.autocomplete.options.forEach((option) => {
            if (option !== skip && option.selected) {
                option.deselect();
            }
        });
    }
    _attachOverlay() {
        if (!this.autocomplete) {
            throw getCubAutocompleteMissingPanelError();
        }
        let overlayRef = this._overlayRef;
        if (!overlayRef) {
            this._portal = new TemplatePortal(this.autocomplete.template, this._viewContainerRef, {
                id: this._formField?._label._labelId,
            });
            overlayRef = this._overlay.create(this._getOverlayConfig());
            this._overlayRef = overlayRef;
            this._handleOverlayEvents(overlayRef);
            this._viewportSubscription = this._viewportRuler
                .change()
                .subscribe(() => {
                if (this.panelOpen && overlayRef) {
                    overlayRef.updateSize({ width: this._getPanelWidth() });
                }
            });
        }
        else {
            // Update the trigger, panel width and direction, in case anything has changed.
            this._positionStrategy.setOrigin(this._getConnectedElement());
            overlayRef.updateSize({ width: this._getPanelWidth() });
        }
        if (overlayRef && !overlayRef.hasAttached()) {
            overlayRef.attach(this._portal);
            this._closingActionsSubscription = this._subscribeToClosingActions();
        }
        const wasOpen = this.panelOpen;
        this.autocomplete._setVisibility();
        this.autocomplete._isOpen = this._overlayAttached = true;
        // We need to do an extra `panelOpen` check in here, because the
        // autocomplete won't be shown if there are no options.
        if (this.panelOpen && wasOpen !== this.panelOpen) {
            this.autocomplete.opened.emit();
        }
    }
    _getOverlayConfig() {
        return new OverlayConfig({
            positionStrategy: this._getOverlayPosition(),
            scrollStrategy: this._scrollStrategy(),
            width: this._getPanelWidth(),
            direction: this._dir,
            panelClass: this._defaults?.overlayPanelClass,
        });
    }
    _getOverlayPosition() {
        const strategy = this._overlay
            .position()
            .flexibleConnectedTo(this._getConnectedElement())
            .withFlexibleDimensions(false)
            .withDefaultOffsetY(2)
            .withPush(false);
        this._setStrategyPositions(strategy);
        this._positionStrategy = strategy;
        return strategy;
    }
    /** Sets the positions on a position strategy based on the directive's input state. */
    _setStrategyPositions(positionStrategy) {
        // Note that we provide horizontal fallback positions, even though by default the dropdown
        // width matches the input, because consumers can override the width. See #18854.
        const belowPositions = [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
            },
            { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top' },
        ];
        // The overlay edge connected to the trigger should have squared corners, while
        // the opposite end has rounded corners. We apply a CSS class to swap the
        // border-radius based on the overlay position.
        const panelClass = this._aboveClass;
        const abovePositions = [
            {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'bottom',
                panelClass,
            },
            {
                originX: 'end',
                originY: 'top',
                overlayX: 'end',
                overlayY: 'bottom',
                panelClass,
            },
        ];
        let positions;
        if (this.position === 'above') {
            positions = abovePositions;
        }
        else if (this.position === 'below') {
            positions = belowPositions;
        }
        else {
            positions = [...belowPositions, ...abovePositions];
        }
        positionStrategy.withPositions(positions);
    }
    _getConnectedElement() {
        if (this.connectedTo) {
            return this.connectedTo.elementRef;
        }
        return this._element;
    }
    _getPanelWidth() {
        return this.autocomplete.panelWidth || this._getHostWidth();
    }
    /** Returns the width of the input element, so the panel width can match it. */
    _getHostWidth() {
        return this._getConnectedElement().nativeElement.getBoundingClientRect()
            .width;
    }
    /**
     * Resets the active item to -1 so arrow events will activate the
     * correct options, or to 0 if the consumer opted into it.
     */
    _resetActiveItem() {
        const autocomplete = this.autocomplete;
        if (autocomplete.autoActiveFirstOption) {
            // Note that we go through `setFirstItemActive`, rather than `setActiveItem(0)`, because
            // the former will find the next enabled option, if the first one is disabled.
            autocomplete._keyManager.setFirstItemActive();
        }
        else {
            autocomplete._keyManager.setActiveItem(-1);
        }
    }
    /** Determines whether the panel can be opened. */
    _canOpen() {
        const element = this._element.nativeElement;
        return (!element.readOnly && !element.disabled && !this._autocompleteDisabled);
    }
    /** Use defaultView of injected document if available or fallback to global window reference */
    _getWindow() {
        return this._document?.defaultView || window;
    }
    /** Scrolls to a particular option in the list. */
    _scrollToOption(index) {
        // Given that we are not actually focusing active options, we must manually adjust scroll
        // to reveal options below the fold. First, we find the offset of the option from the top
        // of the panel. If that offset is below the fold, the new scrollTop will be the offset -
        // the panel height + the option height, so the active option will be just visible at the
        // bottom of the panel. If that offset is above the top of the visible panel, the new scrollTop
        // will become the offset. If that offset is visible within the panel already, the scrollTop is
        // not adjusted.
        const autocomplete = this.autocomplete;
        const labelCount = _countGroupLabelsBeforeOption(index, autocomplete.options, autocomplete.optionGroups);
        if (index === 0 && labelCount === 1) {
            // If we've got one group label before the option and we're at the top option,
            // scroll the list to the top. This is better UX than scrolling the list to the
            // top of the option, because it allows the user to read the top group's label.
            autocomplete._setScrollTop(0);
        }
        else if (autocomplete.panel) {
            const option = autocomplete.options.toArray()[index];
            if (option) {
                const element = option._getHostElement();
                const newScrollPosition = _getOptionScrollPosition(element.offsetTop, element.offsetHeight, autocomplete._getScrollTop(), autocomplete.panel.nativeElement.offsetHeight);
                autocomplete._setScrollTop(newScrollPosition);
            }
        }
    }
    /** Handles keyboard events coming from the overlay panel. */
    _handleOverlayEvents(overlayRef) {
        // Use the `keydownEvents` in order to take advantage of
        // the overlay event targeting provided by the CUB CDK overlay.
        overlayRef.keydownEvents().subscribe((event) => {
            // Close when pressing ESCAPE or ALT + UP_ARROW, based on the a11y guidelines.
            // See: https://www.w3.org/TR/wai-aria-practices-1.1/#textbox-keyboard-interaction
            if ((event.keyCode === ESCAPE && !hasModifierKey(event)) ||
                (event.keyCode === UP_ARROW && hasModifierKey(event, 'altKey'))) {
                // If the user had typed something in before we autoselected an option, and they decided
                // to cancel the selection, restore the input value to the one they had typed in.
                if (this._pendingAutoselectedOption) {
                    this._updateNativeInputValue(this._valueBeforeAutoSelection ?? '');
                    this._pendingAutoselectedOption = null;
                }
                this._closeKeyEventStream.next();
                this._resetActiveItem();
                // We need to stop propagation, otherwise the event will eventually
                // reach the input itself and cause the overlay to be reopened.
                event.stopPropagation();
                event.preventDefault();
            }
        });
        // Subscribe to the pointer events stream so that it doesn't get picked up by other overlays.
        // TODO(crisbeto): we should switch `_getOutsideClickStream` eventually to use this stream,
        // but the behvior isn't exactly the same and it ends up breaking some internal tests.
        overlayRef.outsidePointerEvents().subscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubAutocompleteTriggerBase, deps: [{ token: i0.ElementRef }, { token: i1$1.Overlay }, { token: i0.ViewContainerRef }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: CUB_AUTOCOMPLETE_SCROLL_STRATEGY }, { token: i2.Directionality, optional: true }, { token: CUB_FORM_FIELD, host: true, optional: true }, { token: DOCUMENT, optional: true }, { token: i3.ViewportRuler }, { token: CUB_AUTOCOMPLETE_DEFAULT_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubAutocompleteTriggerBase, isStandalone: true, inputs: { autocomplete: ["cubAutocompleteFor", "autocomplete"], position: ["cubAutocompletePosition", "position"], connectedTo: ["cubAutocompleteConnectedTo", "connectedTo"], autocompleteDisabled: ["cubAutocompleteDisabled", "autocompleteDisabled"], autocompleteAttribute: ["autocomplete", "autocompleteAttribute"] }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubAutocompleteTriggerBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.Overlay }, { type: i0.ViewContainerRef }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_AUTOCOMPLETE_SCROLL_STRATEGY]
                }] }, { type: i2.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i4.CubFormField, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_FORM_FIELD]
                }, {
                    type: Host
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i3.ViewportRuler }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_AUTOCOMPLETE_DEFAULT_OPTIONS]
                }] }], propDecorators: { autocomplete: [{
                type: Input,
                args: ['cubAutocompleteFor']
            }], position: [{
                type: Input,
                args: ['cubAutocompletePosition']
            }], connectedTo: [{
                type: Input,
                args: ['cubAutocompleteConnectedTo']
            }], autocompleteDisabled: [{
                type: Input,
                args: ['cubAutocompleteDisabled']
            }], autocompleteAttribute: [{
                type: Input,
                args: ['autocomplete']
            }] } });

/**
 * Provider that allows the autocomplete to register as a ControlValueAccessor.
 * @docs-private
 */
const CUB_AUTOCOMPLETE_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubAutocompleteTrigger),
    multi: true,
};
class CubAutocompleteTrigger extends _CubAutocompleteTriggerBase {
    constructor() {
        super(...arguments);
        this._aboveClass = 'cub-autocomplete-panel-above';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteTrigger, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubAutocompleteTrigger, isStandalone: true, selector: "input[cubAutocompleteFor], textarea[cubAutocompleteFor]", host: { listeners: { "focusin": "_handleFocus()", "blur": "_onTouched()", "input": "_handleInput($event)", "keydown": "_handleKeydown($event)", "click": "_handleClick()" }, properties: { "attr.autocomplete": "autocompleteAttribute", "attr.role": "autocompleteDisabled ? null : \"combobox\"", "attr.aria-autocomplete": "autocompleteDisabled ? null : \"list\"", "attr.aria-activedescendant": "(panelOpen && activeOption) ? activeOption.id : null", "attr.aria-expanded": "autocompleteDisabled ? null : panelOpen.toString()", "attr.aria-owns": "(autocompleteDisabled || !panelOpen) ? null : autocomplete?.id", "attr.aria-haspopup": "autocompleteDisabled ? null : \"listbox\"" }, classAttribute: "cub-autocomplete-trigger" }, providers: [CUB_AUTOCOMPLETE_VALUE_ACCESSOR], exportAs: ["cubAutocompleteTrigger"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: `input[cubAutocompleteFor], textarea[cubAutocompleteFor]`,
                    host: {
                        class: 'cub-autocomplete-trigger',
                        '[attr.autocomplete]': 'autocompleteAttribute',
                        '[attr.role]': 'autocompleteDisabled ? null : "combobox"',
                        '[attr.aria-autocomplete]': 'autocompleteDisabled ? null : "list"',
                        '[attr.aria-activedescendant]': '(panelOpen && activeOption) ? activeOption.id : null',
                        '[attr.aria-expanded]': 'autocompleteDisabled ? null : panelOpen.toString()',
                        '[attr.aria-owns]': '(autocompleteDisabled || !panelOpen) ? null : autocomplete?.id',
                        '[attr.aria-haspopup]': 'autocompleteDisabled ? null : "listbox"',
                        // Note: we use `focusin`, as opposed to `focus`, in order to open the panel
                        // a little earlier. This avoids issues where IE delays the focusing of the input.
                        '(focusin)': '_handleFocus()',
                        '(blur)': '_onTouched()',
                        '(input)': '_handleInput($event)',
                        '(keydown)': '_handleKeydown($event)',
                        '(click)': '_handleClick()',
                    },
                    exportAs: 'cubAutocompleteTrigger',
                    providers: [CUB_AUTOCOMPLETE_VALUE_ACCESSOR],
                }]
        }] });

class CubAutocompleteModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteModule, imports: [CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule,
            CubAutocomplete,
            CubAutocompleteOrigin,
            CubAutocompleteTrigger], exports: [CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule,
            CubAutocomplete,
            CubAutocompleteOrigin,
            CubAutocompleteTrigger] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule, CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubAutocompleteModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkScrollableModule,
                        CubCommonModule,
                        CubOptionModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubInputGroupModule,
                        CubAutocomplete,
                        CubAutocompleteOrigin,
                        CubAutocompleteTrigger,
                    ],
                    exports: [
                        CubCdkScrollableModule,
                        CubCommonModule,
                        CubOptionModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubInputGroupModule,
                        CubAutocomplete,
                        CubAutocompleteOrigin,
                        CubAutocompleteTrigger,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/autocomplete
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_AUTOCOMPLETE_DEFAULT_OPTIONS, CUB_AUTOCOMPLETE_DEFAULT_OPTIONS_FACTORY, CUB_AUTOCOMPLETE_SCROLL_STRATEGY, CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY, CUB_AUTOCOMPLETE_SCROLL_STRATEGY_FACTORY_PROVIDER, CUB_AUTOCOMPLETE_VALUE_ACCESSOR, CubAutocomplete, CubAutocompleteModule, CubAutocompleteOrigin, CubAutocompleteSelectedEvent, CubAutocompleteTrigger, _CubAutocompleteBase, _CubAutocompleteMixinBase, _CubAutocompleteOriginBase, _CubAutocompleteTriggerBase, getCubAutocompleteMissingPanelError };
//# sourceMappingURL=cub-lib-view-rootng-component-autocomplete.mjs.map
