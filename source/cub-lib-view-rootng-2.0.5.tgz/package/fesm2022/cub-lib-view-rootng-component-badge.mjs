import * as i0 from '@angular/core';
import { Input, Directive, NgModule } from '@angular/core';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';

class CubBadge {
    /** 元件顏色，預設值為 'brand'。 */
    get color() {
        return this._color;
    }
    set color(value) {
        if (value === this._color)
            return;
        // 如果有舊的顏色，先移除舊的 class
        if (this._color) {
            this.elementRef.nativeElement.classList.remove(`cub-badge-${this._color}`);
        }
        // 如果傳入 undefined 或 null，使用 'brand' 作為預設
        this._color = value || 'brand';
        this.elementRef.nativeElement.classList.add(`cub-badge-${this._color}`);
    }
    /** 徽章內顯示文字，當數值為 ''、undefined、null 時則不顯示為右上角的徽章樣式，預設值為 null。 */
    get content() {
        return this._content;
    }
    set content(newContent) {
        this.updateRenderedContent(newContent);
    }
    /** 徽章的顯示形狀，預設值為 圓形。 */
    get shape() {
        return this._shape;
    }
    set shape(value) {
        this.setShape(value || false);
        this._shape = value || false;
    }
    /** 是否隱藏徽章，預設值為不隱藏。 */
    get hidden() {
        return this._hidden;
    }
    set hidden(value) {
        this._hidden = coerceBooleanProperty(value);
    }
    constructor(elementRef, renderer) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this._color = 'brand';
        this._shape = 'circle';
        this._hidden = false;
        this.isInitialized = false;
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 徽章內顯示的數值最大值，當超過設定數值時，會以"最大值+"顯示。
        例如：設定最大值為 99，在數值大於 99 時以 99+ 顯示，預設值為 99。*/
        this.max = 99;
        /** 徽章的顯示位置，預設值為 'after'。 */
        this.position = 'after';
        this.elementRef.nativeElement.classList.add(`cub-badge-${this._color}`);
    }
    ngOnInit() {
        this.clearExistingBadges();
        // 幫元件加上 position，不寫在 host 裡是因為 classlist.remove 會有bug。
        this.elementRef.nativeElement.classList.add(`cub-badge-${this.position}`);
        // 確認 host element 有沒有其他子元素
        const elementHasChild = this.elementRef.nativeElement.childNodes.length > 0;
        // 如果 badge 有值但沒有 text 時，先移除 badge 的 class 並把 badge 的值添加到 text。
        if (this.content && !elementHasChild) {
            this.elementRef.nativeElement.classList.remove(`cub-badge-${this.position}`);
            this.elementRef.nativeElement.textContent = this.checkRenderedContent(this.content);
            // 如果形狀是 dot，建立 dot 元素。
        }
        else if (this.shape === 'dot') {
            this.createDotBadgeElement();
            // 如果 badge 有值 text 也有時，創立 badge 元素。
        }
        else if (this.content && !this.badgeElement) {
            this.badgeElement = this.createBadgeElement();
            this.updateRenderedContent(this.content);
        }
        this.isInitialized = true;
    }
    ngOnDestroy() {
        if (this.renderer.destroyNode) {
            this.renderer.destroyNode(this.badgeElement);
        }
    }
    isAfter() {
        return this.position.indexOf('before') === -1;
    }
    /* 確認內容是否有超過限制大小或長度 */
    checkRenderedContent(newContent) {
        const newContentNormalized = `${newContent ?? ''}`.trim();
        let newContentAbbrNormalized = newContentNormalized;
        /* 設置最大值或最大長度時，將顯示內容以縮寫顯示 */
        if (newContentNormalized.length > 0 && this.max) {
            /* 判斷是數字還是字串 */
            const isString = isNaN(Number(newContentNormalized));
            if (!isString && this.max && Number(newContentNormalized) > this.max) {
                /* 數字以 '最大值+' 顯示內容 */
                newContentAbbrNormalized = `${this.max}+`;
            }
        }
        return newContentAbbrNormalized;
    }
    /* 建立徽章 */
    createBadgeElement() {
        const badgeElement = this.renderer.createElement('span');
        badgeElement.classList.add('cub-badge-content');
        this.elementRef.nativeElement.appendChild(badgeElement);
        return badgeElement;
    }
    /* 建立圓點 */
    createDotBadgeElement() {
        const badgeElement = this.renderer.createElement('span');
        badgeElement.classList.add('cub-badge-dot');
        this.elementRef.nativeElement.appendChild(badgeElement);
        return badgeElement;
    }
    /* 更新顯示內容 */
    updateRenderedContent(newContent) {
        const newContentNormalized = this.checkRenderedContent(newContent);
        if (this.isInitialized && newContentNormalized && !this.badgeElement) {
            this.badgeElement = this.createBadgeElement();
        }
        if (this.badgeElement) {
            this.badgeElement.textContent = newContentNormalized;
        }
        this._content = newContentNormalized;
    }
    /* 設定樣式 */
    setShape(shape) {
        const badges = this.elementRef.nativeElement.querySelectorAll(`:scope > .cub-badge`);
        for (const badgeElement of Array.from(badges)) {
            const classList = badgeElement.classList;
            if (this._shape !== 'circle') {
                classList.remove(`cub-badge-${this._shape}`);
            }
            if (shape !== 'circle') {
                classList.add(`cub-badge-${shape}`);
            }
        }
    }
    /* 清除既有徽章 */
    clearExistingBadges() {
        const badges = this.elementRef.nativeElement.querySelectorAll(`:scope > .cub-badge`);
        for (const badgeElement of Array.from(badges)) {
            if (badgeElement !== this.badgeElement) {
                badgeElement.remove();
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBadge, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubBadge, isStandalone: true, selector: "[cubBadge]", inputs: { size: ["cubBadgeSize", "size"], color: ["cubBadgeColor", "color"], max: ["cubBadgeMax", "max"], position: ["cubBadgePosition", "position"], content: ["cubBadge", "content"], shape: ["cubBadgeShape", "shape"], hidden: ["cubBadgeHidden", "hidden"] }, host: { properties: { "class.cub-badge-disabled": "disabled", "class.cub-badge-hidden": "hidden", "class.cub-badge-small": "size === \"small\"" }, classAttribute: "cub-badge" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBadge, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubBadge]',
                    host: {
                        class: 'cub-badge',
                        '[class.cub-badge-disabled]': 'disabled',
                        '[class.cub-badge-hidden]': 'hidden',
                        '[class.cub-badge-small]': 'size === "small"',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { size: [{
                type: Input,
                args: ['cubBadgeSize']
            }], color: [{
                type: Input,
                args: ['cubBadgeColor']
            }], max: [{
                type: Input,
                args: ['cubBadgeMax']
            }], position: [{
                type: Input,
                args: ['cubBadgePosition']
            }], content: [{
                type: Input,
                args: ['cubBadge']
            }], shape: [{
                type: Input,
                args: ['cubBadgeShape']
            }], hidden: [{
                type: Input,
                args: ['cubBadgeHidden']
            }] } });

class CubBadgeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBadgeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubBadgeModule, imports: [CubBadge], exports: [CubBadge] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBadgeModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBadgeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubBadge],
                    exports: [CubBadge],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/badge
 */
/* Directive */

/**
 * Generated bundle index. Do not edit.
 */

export { CubBadge, CubBadgeModule };
//# sourceMappingURL=cub-lib-view-rootng-component-badge.mjs.map
