import * as i0 from '@angular/core';
import { InjectionToken, Directive, Injectable, TemplateRef, HostListener, ContentChild, Component, NgModule } from '@angular/core';
import { NgTemplateOutlet, AsyncPipe } from '@angular/common';
import * as i1 from '@angular/router';
import { NavigationStart, NavigationEnd, RouterLink } from '@angular/router';
import { BehaviorSubject, distinctUntilChanged, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DEVICE_BREAKPOINT } from 'cub-lib-view-rootng/component/common';
import { CubHyperlink } from 'cub-lib-view-rootng/component/button';

const CUB_BREADCRUMB_ITEM = new InjectionToken('cubBreadcrumbItem');
class CubBreadcrumbItem {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbItem, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubBreadcrumbItem, isStandalone: true, selector: "[cubBreadcrumbItem]", providers: [{ provide: CUB_BREADCRUMB_ITEM, useExisting: CubBreadcrumbItem }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubBreadcrumbItem]',
                    providers: [{ provide: CUB_BREADCRUMB_ITEM, useExisting: CubBreadcrumbItem }]
                }]
        }], ctorParameters: () => [] });

const CUB_BREADCRUMB_CHILD = new InjectionToken('cubBreadcrumbChild');
class CubBreadcrumbChild {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbChild, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubBreadcrumbChild, isStandalone: true, selector: "[cubBreadcrumbChild]", providers: [
            { provide: CUB_BREADCRUMB_CHILD, useExisting: CubBreadcrumbChild },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbChild, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubBreadcrumbChild]',
                    providers: [
                        { provide: CUB_BREADCRUMB_CHILD, useExisting: CubBreadcrumbChild },
                    ]
                }]
        }], ctorParameters: () => [] });

class CubBreadcrumbService {
    constructor() {
        this._breadcrumbItem = new BehaviorSubject([]);
        this.breadcrumbItem$ = this._breadcrumbItem.asObservable();
        this.isInitialized = false;
    }
    /**
     * 不按照 Router Data 的全自訂麵包屑
     * @param customBreadcrumb 自定義的麵包屑陣列
     */
    customBreadcrumb(customBreadcrumb) {
        if (customBreadcrumb && customBreadcrumb.length > 0) {
            for (let index = 0; index < customBreadcrumb.length; index++) {
                if (customBreadcrumb[index].routerLink) {
                    customBreadcrumb[index].isCustom = true;
                }
            }
            this._breadcrumbItem.next(customBreadcrumb);
        }
    }
    /**
     * 覆寫指定的麵包屑節點
     * @param overrideItem 指定的覆寫節點
     * @param overrideIndex 指定覆寫的索引值
     */
    overrideItem(overrideItem, overrideIndex) {
        const breadcrumb = this._breadcrumbItem.value;
        let index = breadcrumb.length - 1;
        if (overrideIndex && !!breadcrumb[overrideIndex]) {
            index = overrideIndex;
        }
        if (!!breadcrumb[index]) {
            if (overrideItem.routerLink) {
                overrideItem.isCustom = true;
            }
            breadcrumb[index] = overrideItem;
            this._breadcrumbItem.next(breadcrumb);
        }
    }
    /**
     * 在當前 Router Data 階層中新增麵包屑節點
     * @param newBreadcrumb 要新增的麵包屑陣列
     */
    appendItem(newBreadcrumb) {
        if (newBreadcrumb && newBreadcrumb.length > 0) {
            const breadcrumb = this._breadcrumbItem.value;
            for (let index = 0; index < newBreadcrumb.length; index++) {
                if (newBreadcrumb[index].routerLink) {
                    newBreadcrumb[index].isCustom = true;
                }
            }
            this._breadcrumbItem.next([...breadcrumb, ...newBreadcrumb]);
        }
    }
    /**
     * 不修改當前的 Router Data 階層，只新增功能代碼
     * @param label 功能代碼
     * @param appendIndex 指定新增的索引值
     */
    appendChild(label, appendIndex) {
        const breadcrumb = this._breadcrumbItem.value;
        let index = breadcrumb.length - 1;
        if (appendIndex && !!breadcrumb[appendIndex]) {
            index = appendIndex;
        }
        const item = breadcrumb[index];
        if (!!item.children && item.children.length > 0) {
            item.children.push({ label: label });
        }
        else {
            item.children = [{ label: label }];
        }
        this._breadcrumbItem.next(breadcrumb);
    }
    /** 取得路由資料 */
    getBreadcrumbItem() {
        return this._breadcrumbItem.value;
    }
    /**
     * 設定路由資料
     * @param breadcrumb 依照路由 Data 建置的麵包屑陣列
     */
    setBreadcrumbItem(breadcrumb) {
        if (!this.isInitialized) {
            this.isInitialized = true;
        }
        this._breadcrumbItem.next(breadcrumb);
    }
    /** 清空路由資料與麵包屑設定 */
    reset() {
        this._breadcrumbItem.next([]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class CubBreadcrumb {
    /* 調整瀏覽器視窗，判斷是否顯示精簡版樣式 */
    onResize(event) {
        const windowWidth = event.target.innerWidth;
        this.isStreamlined = this.isMobileWidth(windowWidth);
    }
    constructor(router, activatedRoute, breadcrumbService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.breadcrumbService = breadcrumbService;
        /* 是否精簡顯示版本，樣式僅保留倒數第二層麵包屑 */
        this.isStreamlined = false;
        /* 當前麵包屑 */
        this.breadcrumbItem$ = this.breadcrumbService.breadcrumbItem$.pipe(distinctUntilChanged());
        this._destroyed = new Subject();
    }
    ngOnInit() {
        /* 初始化判斷是否顯示精簡版樣式 */
        const windowWidth = window.innerWidth;
        this.isStreamlined = this.isMobileWidth(windowWidth);
        /* 初始化建置，若頁面上已有使用麵包屑元件，則不重複執行初始化項目 */
        if (!this.breadcrumbService.isInitialized) {
            this._generateBreadcrumbs();
            /* 路由切換時重新更新麵包屑 */
            this.router.events
                .pipe(distinctUntilChanged(), takeUntil(this._destroyed))
                .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    this.breadcrumbService.reset();
                }
                if (event instanceof NavigationEnd) {
                    this._generateBreadcrumbs();
                }
            });
        }
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    /* 產生麵包屑 */
    _generateBreadcrumbs() {
        const root = this.activatedRoute.root;
        const breadcrumb = this._createBreadcrumbsByData(root);
        this.breadcrumbService.setBreadcrumbItem(breadcrumb);
    }
    /* 根據 Route Data 創建麵包屑 */
    _createBreadcrumbsByData(route, url = '', breadcrumbs = []) {
        const children = route.firstChild;
        if (!children) {
            return breadcrumbs;
        }
        const routeLink = children.snapshot.url
            .map((segment) => segment.path)
            .join('/');
        const routeConfig = children.snapshot.routeConfig;
        const data = routeConfig && routeConfig.data ? routeConfig.data : {};
        const label = data['breadcrumb'];
        const labelChildren = data['breadcrumbChildren'];
        const specifyRouterLink = data['breadcrumbRouterLink'];
        if (!label) {
            return this._createBreadcrumbsByData(children, url, breadcrumbs);
        }
        if (specifyRouterLink && specifyRouterLink.length > 0) {
            url += `/${specifyRouterLink}`;
        }
        else {
            url += `/${routeLink}`;
        }
        const breadcrumb = {
            label: label,
            isCustom: false,
            hasComponent: !!children.snapshot.component,
            params: children.snapshot.params,
            queryParams: children.snapshot.queryParams,
            routerLink: url,
            children: labelChildren,
        };
        for (let index = 0; index < breadcrumbs.length; index++) {
            const breadcrumbItem = breadcrumbs[index];
            const isSameLabel = breadcrumbItem.label === breadcrumb.label;
            const hasLink = !breadcrumbItem.hasComponent &&
                !!breadcrumbItem.routerLink &&
                !!breadcrumb.routerLink &&
                breadcrumb.routerLink.indexOf(breadcrumbItem.routerLink) > -1;
            if (isSameLabel && hasLink) {
                breadcrumbs.splice(breadcrumbs.indexOf(breadcrumbItem), 1);
            }
        }
        return this._createBreadcrumbsByData(children, url, [
            ...breadcrumbs,
            breadcrumb,
        ]);
    }
    /* 判斷螢幕尺寸是否小於 768px */
    isMobileWidth(windowWidth) {
        return windowWidth < DEVICE_BREAKPOINT.TABLET_PORTRAIT;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumb, deps: [{ token: i1.Router }, { token: i1.ActivatedRoute }, { token: CubBreadcrumbService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubBreadcrumb, isStandalone: true, selector: "cub-breadcrumb", host: { listeners: { "window:resize": "onResize($event)" }, properties: { "class.cub-breadcrumb-streamline": "isStreamlined" }, classAttribute: "cub-breadcrumb" }, queries: [{ propertyName: "itemTemplateRef", first: true, predicate: CubBreadcrumbItem, descendants: true, read: TemplateRef }, { propertyName: "childTemplateRef", first: true, predicate: CubBreadcrumbChild, descendants: true, read: TemplateRef }], ngImport: i0, template: "<ul>\n  @if (breadcrumbItem$ | async; as breadcrumbItem) { @for (breadcrumb of\n  breadcrumbItem; track index; let index = $index; let first = $first; let last\n  = $last) {\n  <!-- \u7BAD\u982D Icon\uFF08PC \u7248\u7B2C\u4E00\u5C64\u4E0D\u986F\u793A\uFF0CMobile \u53EA\u986F\u793A\u5012\u6578\u7B2C\u4E8C\u5C64\uFF09 -->\n  @if ((!isStreamlined && !first) || (isStreamlined && index ===\n  breadcrumbItem.length - 2)) {\n\n  <li class=\"cub-breadcrumb-indicator\">\n    <span\n      [class.cub-icon-caret-left-filled]=\"isStreamlined\"\n      [class.cub-icon-caret-right-filled]=\"!isStreamlined\"\n    ></span>\n  </li>\n  }\n  <!-- \u9805\u76EE\u6A19\u7C64\uFF08PC \u7248\u5168\u986F\u793A\uFF0CMobile \u53EA\u986F\u793A\u5012\u6578\u7B2C\u4E8C\u5C64\uFF09 -->\n  @if (!isStreamlined || (isStreamlined && index === breadcrumbItem.length - 2))\n  {\n\n  <li class=\"cub-breadcrumb-item\">\n    @if (!last && ((!breadcrumb.isCustom && breadcrumb.hasComponent) ||\n    (breadcrumb.isCustom && !!breadcrumb.routerLink));) {\n    <!-- \u8D85\u9023\u7D50\uFF08\u5728 routeConfig \u6709\u8A2D\u5B9A Component or \u5BA2\u88FD\u8986\u5BEB\u4E14\u8A2D\u5B9A routerLink \u6642\u986F\u793A\uFF09 -->\n    <a\n      cub-hyperlink\n      [color]=\"\n        isStreamlined && index === breadcrumbItem.length - 2\n          ? 'neutral'\n          : 'neutral-light'\n      \"\n      size=\"small\"\n      [routerLink]=\"[breadcrumb?.routerLink]\"\n      [queryParams]=\"breadcrumb?.queryParams\"\n    >\n      <ng-container\n        *ngTemplateOutlet=\"\n          breadcrumbTemplate;\n          context: { $implicit: breadcrumb }\n        \"\n      ></ng-container>\n    </a>\n    } @else {\n    <!-- \u7D14\u6587\u5B57 -->\n    <ng-container\n      *ngTemplateOutlet=\"breadcrumbTemplate; context: { $implicit: breadcrumb }\"\n    ></ng-container>\n    }\n  </li>\n  } } }\n</ul>\n\n<!-- \u6A19\u7C64\u6A21\u677F -->\n<ng-template #breadcrumbTemplate let-breadcrumb>\n  <!-- \u8DEF\u5F91\u540D\u7A31 -->\n  @if (itemTemplateRef) {\n  <ng-container\n    *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: breadcrumb }\"\n  ></ng-container>\n  } @else {\n  <!-- \u9810\u8A2D\u8DEF\u5F91\u540D\u7A31\u7684\u6392\u7248\u683C\u5F0F -->\n  {{ breadcrumb.label }}\n  }\n\n  <!-- \u529F\u80FD\u4EE3\u78BC -->\n  @if (breadcrumb.children && breadcrumb.children.length > 0) { @for (child of\n  breadcrumb.children; track index; let index = $index) { (@if\n  (childTemplateRef) {\n  <ng-container\n    *ngTemplateOutlet=\"childTemplateRef; context: { $implicit: child }\"\n  ></ng-container>\n  } @else {\n  <!-- \u9810\u8A2D\u8DEF\u5F91\u540D\u7A31\u7684\u6392\u7248\u683C\u5F0F -->\n  {{ child.label }}\n  }) } }\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubHyperlink, selector: "a[cub-hyperlink]", inputs: ["disabled", "color", "appearance", "tabIndex"], exportAs: ["cubHyperlink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumb, decorators: [{
            type: Component,
            args: [{ selector: 'cub-breadcrumb', host: {
                        '[class.cub-breadcrumb-streamline]': 'isStreamlined',
                        class: 'cub-breadcrumb',
                    }, imports: [RouterLink, NgTemplateOutlet, AsyncPipe, CubHyperlink], template: "<ul>\n  @if (breadcrumbItem$ | async; as breadcrumbItem) { @for (breadcrumb of\n  breadcrumbItem; track index; let index = $index; let first = $first; let last\n  = $last) {\n  <!-- \u7BAD\u982D Icon\uFF08PC \u7248\u7B2C\u4E00\u5C64\u4E0D\u986F\u793A\uFF0CMobile \u53EA\u986F\u793A\u5012\u6578\u7B2C\u4E8C\u5C64\uFF09 -->\n  @if ((!isStreamlined && !first) || (isStreamlined && index ===\n  breadcrumbItem.length - 2)) {\n\n  <li class=\"cub-breadcrumb-indicator\">\n    <span\n      [class.cub-icon-caret-left-filled]=\"isStreamlined\"\n      [class.cub-icon-caret-right-filled]=\"!isStreamlined\"\n    ></span>\n  </li>\n  }\n  <!-- \u9805\u76EE\u6A19\u7C64\uFF08PC \u7248\u5168\u986F\u793A\uFF0CMobile \u53EA\u986F\u793A\u5012\u6578\u7B2C\u4E8C\u5C64\uFF09 -->\n  @if (!isStreamlined || (isStreamlined && index === breadcrumbItem.length - 2))\n  {\n\n  <li class=\"cub-breadcrumb-item\">\n    @if (!last && ((!breadcrumb.isCustom && breadcrumb.hasComponent) ||\n    (breadcrumb.isCustom && !!breadcrumb.routerLink));) {\n    <!-- \u8D85\u9023\u7D50\uFF08\u5728 routeConfig \u6709\u8A2D\u5B9A Component or \u5BA2\u88FD\u8986\u5BEB\u4E14\u8A2D\u5B9A routerLink \u6642\u986F\u793A\uFF09 -->\n    <a\n      cub-hyperlink\n      [color]=\"\n        isStreamlined && index === breadcrumbItem.length - 2\n          ? 'neutral'\n          : 'neutral-light'\n      \"\n      size=\"small\"\n      [routerLink]=\"[breadcrumb?.routerLink]\"\n      [queryParams]=\"breadcrumb?.queryParams\"\n    >\n      <ng-container\n        *ngTemplateOutlet=\"\n          breadcrumbTemplate;\n          context: { $implicit: breadcrumb }\n        \"\n      ></ng-container>\n    </a>\n    } @else {\n    <!-- \u7D14\u6587\u5B57 -->\n    <ng-container\n      *ngTemplateOutlet=\"breadcrumbTemplate; context: { $implicit: breadcrumb }\"\n    ></ng-container>\n    }\n  </li>\n  } } }\n</ul>\n\n<!-- \u6A19\u7C64\u6A21\u677F -->\n<ng-template #breadcrumbTemplate let-breadcrumb>\n  <!-- \u8DEF\u5F91\u540D\u7A31 -->\n  @if (itemTemplateRef) {\n  <ng-container\n    *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: breadcrumb }\"\n  ></ng-container>\n  } @else {\n  <!-- \u9810\u8A2D\u8DEF\u5F91\u540D\u7A31\u7684\u6392\u7248\u683C\u5F0F -->\n  {{ breadcrumb.label }}\n  }\n\n  <!-- \u529F\u80FD\u4EE3\u78BC -->\n  @if (breadcrumb.children && breadcrumb.children.length > 0) { @for (child of\n  breadcrumb.children; track index; let index = $index) { (@if\n  (childTemplateRef) {\n  <ng-container\n    *ngTemplateOutlet=\"childTemplateRef; context: { $implicit: child }\"\n  ></ng-container>\n  } @else {\n  <!-- \u9810\u8A2D\u8DEF\u5F91\u540D\u7A31\u7684\u6392\u7248\u683C\u5F0F -->\n  {{ child.label }}\n  }) } }\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.Router }, { type: i1.ActivatedRoute }, { type: CubBreadcrumbService }], propDecorators: { itemTemplateRef: [{
                type: ContentChild,
                args: [CubBreadcrumbItem, { read: TemplateRef }]
            }], childTemplateRef: [{
                type: ContentChild,
                args: [CubBreadcrumbChild, { read: TemplateRef }]
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }] } });

class CubBreadcrumbModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbModule, imports: [CubBreadcrumb, CubBreadcrumbItem, CubBreadcrumbChild], exports: [CubBreadcrumb, CubBreadcrumbItem, CubBreadcrumbChild] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbModule, imports: [CubBreadcrumb] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubBreadcrumbModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubBreadcrumb, CubBreadcrumbItem, CubBreadcrumbChild],
                    exports: [CubBreadcrumb, CubBreadcrumbItem, CubBreadcrumbChild],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/breadcrumb
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_BREADCRUMB_CHILD, CUB_BREADCRUMB_ITEM, CubBreadcrumb, CubBreadcrumbChild, CubBreadcrumbItem, CubBreadcrumbModule, CubBreadcrumbService };
//# sourceMappingURL=cub-lib-view-rootng-component-breadcrumb.mjs.map
