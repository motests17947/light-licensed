import * as i0 from '@angular/core';
import { Input, ViewChild, Directive, ContentChildren, Optional, Inject, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { ENTER, SPACE } from 'cub-lib-view-rootng/cdk/keycodes';
import { mixinColor, mixinDisabled, mixinDisableRipple, CubRipple, CUB_PREFIX, CUB_SUFFIX, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';
import { CubMenuModule } from 'cub-lib-view-rootng/component/menu';

const _CubButtonMixinBase = mixinColor(mixinDisabled(mixinDisableRipple(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
})), 'brand');
class _CubButtonBase extends _CubButtonMixinBase {
    constructor(elementRef, _focusMonitor) {
        super(elementRef);
        this.elementRef = elementRef;
        this._focusMonitor = _focusMonitor;
        /** 是否為載入狀態，預設為否 */
        this.loading = false;
        /** 按鈕尺寸，預設為 medium */
        this.size = 'medium';
    }
    focus(origin, options) {
        if (origin) {
            this._focusMonitor.focusVia(this._getHostElement(), origin, options);
        }
        else {
            this._getHostElement().focus(options);
        }
    }
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    _hasHostAttributes(...attributes) {
        return attributes.some((attribute) => this._getHostElement().hasAttribute(attribute));
    }
    _monitorFocus() {
        this._focusMonitor.monitor(this._elementRef, true);
    }
    _stopFocusMonitoring() {
        this._focusMonitor.stopMonitoring(this._elementRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubButtonBase, deps: [{ token: i0.ElementRef }, { token: i1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubButtonBase, isStandalone: true, inputs: { loading: "loading", size: "size" }, viewQueries: [{ propertyName: "ripple", first: true, predicate: CubRipple, descendants: true }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubButtonBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }], propDecorators: { ripple: [{
                type: ViewChild,
                args: [CubRipple]
            }], loading: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

class CubHyperlink extends _CubButtonBase {
    constructor(elementRef, focusMonitor, _renderer, _animationMode, _ngZone) {
        super(elementRef, focusMonitor);
        this._renderer = _renderer;
        this._animationMode = _animationMode;
        this._ngZone = _ngZone;
        /** 是否為禁用狀態。 */
        /** 主題顏色，預設為 'brand'。 */
        /** 外觀樣式，預設為 'plain' */
        this.appearance = 'plain';
        /** Tab 鍵的控制項索引值 */
        this.tabIndex = 0;
        this._haltDisabledEvents = (event) => {
            if (this.disabled) {
                event.preventDefault();
                event.stopImmediatePropagation();
            }
        };
        this._KeyboardHaltDisabledEvents = (event) => {
            if (event.keyCode === ENTER || event.keyCode === SPACE) {
                this._haltDisabledEvents(event);
            }
        };
        /* 設定預設為主題色 */
        this.color = this.defaultColor = 'brand';
        this._renderer.addClass(elementRef.nativeElement, 'cub-hyperlink');
    }
    ngAfterViewInit() {
        this._monitorFocus();
        if (this._ngZone) {
            this._ngZone.runOutsideAngular(() => {
                this._elementRef.nativeElement.addEventListener('click', this._haltDisabledEvents);
                this._elementRef.nativeElement.addEventListener('keydown', this._KeyboardHaltDisabledEvents);
            });
        }
        else {
            this._elementRef.nativeElement.addEventListener('click', this._haltDisabledEvents);
            this._elementRef.nativeElement.addEventListener('keydown', this._KeyboardHaltDisabledEvents);
        }
    }
    ngOnDestroy() {
        this._stopFocusMonitoring();
        this._elementRef.nativeElement.removeEventListener('click', this._haltDisabledEvents);
        this._elementRef.nativeElement.removeEventListener('keydown', this._KeyboardHaltDisabledEvents);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubHyperlink, deps: [{ token: i0.ElementRef }, { token: i1.FocusMonitor }, { token: i0.Renderer2 }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: i0.NgZone, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubHyperlink, isStandalone: true, selector: "a[cub-hyperlink]", inputs: { disabled: "disabled", color: "color", appearance: "appearance", tabIndex: "tabIndex" }, host: { properties: { "attr.tabindex": "disabled ? -1 : tabIndex", "attr.disabled": "disabled || null", "attr.aria-disabled": "disabled.toString()", "class.cub-hyperlink-disabled": "disabled", "class.cub-hyperlink-sup": "appearance === \"sup\"", "class.cub-hyperlink-sub": "appearance === \"sub\"", "class.cub-hyperlink-small": "size === \"small\"" }, classAttribute: "cub-focus-indicator" }, queries: [{ propertyName: "_prefixChildren", predicate: CUB_PREFIX, descendants: true }, { propertyName: "_suffixChildren", predicate: CUB_SUFFIX, descendants: true }], exportAs: ["cubHyperlink"], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-hyperlink-wrapper\">\n  @if (_prefixChildren.length || appearance === 'file' || appearance === 'link')\n  {\n  <span class=\"cub-hyperlink-prefix\">\n    @switch (appearance) { @case ('file') {\n    <span class=\"cub-icon-paperclip-vertical\"></span>\n    } @case ('link') {\n    <span class=\"cub-icon-arrow-up-right-from-square\"></span>\n    } @default {\n    <ng-content select=\"[cubPrefix]\"></ng-content>\n    } }\n  </span>\n  }\n\n  <span class=\"cub-hyperlink-content\">\n    <ng-content></ng-content>\n  </span>\n\n  @if (_suffixChildren.length) {\n  <span class=\"cub-hyperlink-suffix\">\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </span>\n  }\n</span>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubHyperlink, decorators: [{
            type: Component,
            args: [{ selector: `a[cub-hyperlink]`, exportAs: 'cubHyperlink', host: {
                        '[attr.tabindex]': 'disabled ? -1 : tabIndex',
                        '[attr.disabled]': 'disabled || null',
                        '[attr.aria-disabled]': 'disabled.toString()',
                        '[class.cub-hyperlink-disabled]': 'disabled',
                        '[class.cub-hyperlink-sup]': 'appearance === "sup"',
                        '[class.cub-hyperlink-sub]': 'appearance === "sub"',
                        '[class.cub-hyperlink-small]': 'size === "small"',
                        class: 'cub-focus-indicator',
                    }, inputs: ['disabled', 'color'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"cub-hyperlink-wrapper\">\n  @if (_prefixChildren.length || appearance === 'file' || appearance === 'link')\n  {\n  <span class=\"cub-hyperlink-prefix\">\n    @switch (appearance) { @case ('file') {\n    <span class=\"cub-icon-paperclip-vertical\"></span>\n    } @case ('link') {\n    <span class=\"cub-icon-arrow-up-right-from-square\"></span>\n    } @default {\n    <ng-content select=\"[cubPrefix]\"></ng-content>\n    } }\n  </span>\n  }\n\n  <span class=\"cub-hyperlink-content\">\n    <ng-content></ng-content>\n  </span>\n\n  @if (_suffixChildren.length) {\n  <span class=\"cub-hyperlink-suffix\">\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </span>\n  }\n</span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: i0.NgZone, decorators: [{
                    type: Optional
                }] }], propDecorators: { _prefixChildren: [{
                type: ContentChildren,
                args: [CUB_PREFIX, { descendants: true }]
            }], _suffixChildren: [{
                type: ContentChildren,
                args: [CUB_SUFFIX, { descendants: true }]
            }], appearance: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }] } });

class CubButton extends _CubButtonBase {
    get loadingColor() {
        return this.appearance === 'filled'
            ? `${this.color}-contrast`
            : this.color;
    }
    constructor(elementRef, focusMonitor, _renderer, _animationMode) {
        super(elementRef, focusMonitor);
        this._renderer = _renderer;
        this._animationMode = _animationMode;
        /** 是否為禁用狀態。 */
        /** 是否禁用漣漪效果。 */
        /** 主題顏色，預設為 'brand'。 */
        /** 外觀樣式，預設為 'text'。 */
        this.appearance = 'text';
        /** 是否滿版顯示，預設為否。  */
        this.block = false;
        /** 是否設置最小寬度，預設為否。  */
        this.withMinWidth = false;
        this._renderer.addClass(elementRef.nativeElement, 'cub-button-base');
        this._renderer.addClass(elementRef.nativeElement, 'cub-button');
    }
    ngAfterViewInit() {
        this._monitorFocus();
    }
    ngOnDestroy() {
        this._stopFocusMonitoring();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButton, deps: [{ token: i0.ElementRef }, { token: i1.FocusMonitor }, { token: i0.Renderer2 }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubButton, isStandalone: true, selector: "button[cub-button]", inputs: { disabled: "disabled", disableRipple: "disableRipple", color: "color", appearance: "appearance", block: "block", withMinWidth: "withMinWidth" }, host: { properties: { "attr.tabindex": "disabled || loading ? -1 : 0", "attr.disabled": "disabled || loading || null", "class.cub-animation-noop-able": "_animationMode === \"NoopAnicubions\"", "class.cub-disabled": "disabled || loading", "class.cub-button-loading": "!disabled && loading", "class.cub-button-filled": "appearance === \"filled\"", "class.cub-button-filled-outline": "appearance === \"filled-outline\"", "class.cub-button-outline": "appearance === \"outline\"", "class.cub-button-text": "appearance === \"text\"", "class.cub-button-plain": "appearance === \"plain\"", "class.cub-button-small": "size === \"small\"", "class.cub-button-block": "block", "class.cub-button-with-min-width": "withMinWidth" }, classAttribute: "cub-focus-indicator" }, queries: [{ propertyName: "_prefixChildren", predicate: CUB_PREFIX, descendants: true }, { propertyName: "_suffixChildren", predicate: CUB_SUFFIX, descendants: true }], exportAs: ["cubButton"], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-loading-wrapper\">\n  <cub-loading [size]=\"size\" [color]=\"loadingColor\"></cub-loading>\n</span>\n<span class=\"cub-button-wrapper\">\n  @if (_prefixChildren.length) {\n  <span class=\"cub-button-prefix\">\n    <ng-content select=\"[cubPrefix]\"></ng-content>\n  </span>\n  }\n\n  <span class=\"cub-button-content\">\n    <ng-content></ng-content>\n  </span>\n\n  @if (_suffixChildren.length) {\n  <span class=\"cub-button-suffix\">\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </span>\n  }\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-button-ripple\"\n  [cubRippleDisabled]=\"\n    this.disableRipple || this.disabled || appearance === 'plain'\n  \"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-button-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButton, decorators: [{
            type: Component,
            args: [{ selector: `button[cub-button]`, exportAs: 'cubButton', host: {
                        '[attr.tabindex]': 'disabled || loading ? -1 : 0',
                        '[attr.disabled]': 'disabled || loading || null',
                        '[class.cub-animation-noop-able]': '_animationMode === "NoopAnicubions"',
                        '[class.cub-disabled]': 'disabled || loading',
                        '[class.cub-button-loading]': '!disabled && loading',
                        '[class.cub-button-filled]': 'appearance === "filled"',
                        '[class.cub-button-filled-outline]': 'appearance === "filled-outline"',
                        '[class.cub-button-outline]': 'appearance === "outline"',
                        '[class.cub-button-text]': 'appearance === "text"',
                        '[class.cub-button-plain]': 'appearance === "plain"',
                        '[class.cub-button-small]': 'size === "small"',
                        '[class.cub-button-block]': 'block',
                        '[class.cub-button-with-min-width]': 'withMinWidth',
                        class: 'cub-focus-indicator',
                    }, inputs: ['disabled', 'disableRipple', 'color'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubLoading, CubRipple], template: "<span class=\"cub-loading-wrapper\">\n  <cub-loading [size]=\"size\" [color]=\"loadingColor\"></cub-loading>\n</span>\n<span class=\"cub-button-wrapper\">\n  @if (_prefixChildren.length) {\n  <span class=\"cub-button-prefix\">\n    <ng-content select=\"[cubPrefix]\"></ng-content>\n  </span>\n  }\n\n  <span class=\"cub-button-content\">\n    <ng-content></ng-content>\n  </span>\n\n  @if (_suffixChildren.length) {\n  <span class=\"cub-button-suffix\">\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </span>\n  }\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-button-ripple\"\n  [cubRippleDisabled]=\"\n    this.disableRipple || this.disabled || appearance === 'plain'\n  \"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-button-persistent-ripple\"></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { _prefixChildren: [{
                type: ContentChildren,
                args: [CUB_PREFIX, { descendants: true }]
            }], _suffixChildren: [{
                type: ContentChildren,
                args: [CUB_SUFFIX, { descendants: true }]
            }], appearance: [{
                type: Input
            }], block: [{
                type: Input
            }], withMinWidth: [{
                type: Input
            }] } });

class CubIconButton extends _CubButtonBase {
    get loadingColor() {
        return this.appearance === 'filled'
            ? `${this.color}-contrast`
            : this.color;
    }
    constructor(elementRef, focusMonitor, _renderer, _animationMode) {
        super(elementRef, focusMonitor);
        this._renderer = _renderer;
        this._animationMode = _animationMode;
        /** 是否為禁用狀態。 */
        /** 是否禁用漣漪效果。 */
        /** 主題顏色，預設為 'brand'。 */
        /** 外觀樣式，預設為 Text Button  */
        this.appearance = 'text';
        this._renderer.addClass(elementRef.nativeElement, 'cub-button-base');
        this._renderer.addClass(elementRef.nativeElement, 'cub-button-icon');
    }
    ngAfterViewInit() {
        this._monitorFocus();
    }
    ngOnDestroy() {
        this._stopFocusMonitoring();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubIconButton, deps: [{ token: i0.ElementRef }, { token: i1.FocusMonitor }, { token: i0.Renderer2 }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubIconButton, isStandalone: true, selector: "button[cub-icon-button]", inputs: { disabled: "disabled", disableRipple: "disableRipple", color: "color", appearance: "appearance" }, host: { properties: { "attr.tabindex": "disabled || loading ? -1 : 0", "attr.disabled": "disabled || loading || null", "class.cub-animation-noop-able": "_animationMode === \"NoopAnicubions\"", "class.cub-disabled": "disabled || loading", "class.cub-button-loading": "!disabled && loading", "class.cub-button-filled": "appearance === \"filled\"", "class.cub-button-filled-outline": "appearance === \"filled-outline\"", "class.cub-button-outline": "appearance === \"outline\"", "class.cub-button-text": "appearance === \"text\"", "class.cub-button-plain": "appearance === \"plain\"", "class.cub-button-small": "size === \"small\"" }, classAttribute: "cub-focus-indicator" }, exportAs: ["cubIconButton"], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-loading-wrapper\">\n  <cub-loading [size]=\"size\" [color]=\"loadingColor\"></cub-loading>\n</span>\n<span class=\"cub-button-wrapper\">\n  <ng-content></ng-content>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-button-ripple\"\n  [cubRippleDisabled]=\"\n    this.disableRipple || this.disabled || appearance === 'plain'\n  \"\n  [cubRippleCentered]=\"true\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-button-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubIconButton, decorators: [{
            type: Component,
            args: [{ selector: `button[cub-icon-button]`, exportAs: 'cubIconButton', host: {
                        '[attr.tabindex]': 'disabled || loading ? -1 : 0',
                        '[attr.disabled]': 'disabled || loading || null',
                        '[class.cub-animation-noop-able]': '_animationMode === "NoopAnicubions"',
                        '[class.cub-disabled]': 'disabled || loading',
                        '[class.cub-button-loading]': '!disabled && loading',
                        '[class.cub-button-filled]': 'appearance === "filled"',
                        '[class.cub-button-filled-outline]': 'appearance === "filled-outline"',
                        '[class.cub-button-outline]': 'appearance === "outline"',
                        '[class.cub-button-text]': 'appearance === "text"',
                        '[class.cub-button-plain]': 'appearance === "plain"',
                        '[class.cub-button-small]': 'size === "small"',
                        class: 'cub-focus-indicator',
                    }, inputs: ['disabled', 'disableRipple', 'color'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubLoading, CubRipple], template: "<span class=\"cub-loading-wrapper\">\n  <cub-loading [size]=\"size\" [color]=\"loadingColor\"></cub-loading>\n</span>\n<span class=\"cub-button-wrapper\">\n  <ng-content></ng-content>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-button-ripple\"\n  [cubRippleDisabled]=\"\n    this.disableRipple || this.disabled || appearance === 'plain'\n  \"\n  [cubRippleCentered]=\"true\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-button-persistent-ripple\"></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { appearance: [{
                type: Input
            }] } });

class CubFloatingActionButton extends _CubButtonBase {
    get loadingColor() {
        return this.colorScheme === 'dark' ? 'neutral-contrast' : 'neutral';
    }
    constructor(elementRef, focusMonitor, _renderer, _animationMode) {
        super(elementRef, focusMonitor);
        this._renderer = _renderer;
        this._animationMode = _animationMode;
        /** 是否為禁用狀態。 */
        /** 是否禁用漣漪效果。 */
        /** 外觀樣式，預設為 'dark'。 */
        this.colorScheme = 'dark';
        this._renderer.addClass(elementRef.nativeElement, 'cub-button-base');
        this._renderer.addClass(elementRef.nativeElement, 'cub-floating-action-button');
    }
    ngAfterViewInit() {
        this._monitorFocus();
    }
    ngOnDestroy() {
        this._stopFocusMonitoring();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFloatingActionButton, deps: [{ token: i0.ElementRef }, { token: i1.FocusMonitor }, { token: i0.Renderer2 }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubFloatingActionButton, isStandalone: true, selector: "button[cub-floating-action-button]", inputs: { disabled: "disabled", disableRipple: "disableRipple", colorScheme: "colorScheme" }, host: { properties: { "attr.tabindex": "disabled || loading ? -1 : 0", "attr.disabled": "disabled || loading || null", "class.cub-animation-noop-able": "_animationMode === \"NoopAnicubions\"", "class.cub-disabled": "disabled || loading", "class.cub-button-loading": "!disabled && loading", "class.cub-button-dark": "colorScheme === \"dark\"", "class.cub-button-light": "colorScheme === \"light\"", "class.cub-button-small": "size === \"small\"" }, classAttribute: "cub-focus-indicator" }, exportAs: ["cubFloatingActionButton"], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-loading-wrapper\">\n  <cub-loading [size]=\"size\" [color]=\"loadingColor\"></cub-loading>\n</span>\n<span class=\"cub-button-wrapper\">\n  <ng-content></ng-content>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-button-ripple\"\n  [cubRippleDisabled]=\"this.disableRipple || this.disabled\"\n  [cubRippleCentered]=\"true\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-button-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFloatingActionButton, decorators: [{
            type: Component,
            args: [{ selector: `button[cub-floating-action-button]`, exportAs: 'cubFloatingActionButton', host: {
                        '[attr.tabindex]': 'disabled || loading ? -1 : 0',
                        '[attr.disabled]': 'disabled || loading || null',
                        '[class.cub-animation-noop-able]': '_animationMode === "NoopAnicubions"',
                        '[class.cub-disabled]': 'disabled || loading',
                        '[class.cub-button-loading]': '!disabled && loading',
                        '[class.cub-button-dark]': 'colorScheme === "dark"',
                        '[class.cub-button-light]': 'colorScheme === "light"',
                        '[class.cub-button-small]': 'size === "small"',
                        class: 'cub-focus-indicator',
                    }, inputs: ['disabled', 'disableRipple'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubLoading, CubRipple], template: "<span class=\"cub-loading-wrapper\">\n  <cub-loading [size]=\"size\" [color]=\"loadingColor\"></cub-loading>\n</span>\n<span class=\"cub-button-wrapper\">\n  <ng-content></ng-content>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-button-ripple\"\n  [cubRippleDisabled]=\"this.disableRipple || this.disabled\"\n  [cubRippleCentered]=\"true\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-button-persistent-ripple\"></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { colorScheme: [{
                type: Input
            }] } });

class CubButtonGroup {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButtonGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubButtonGroup, isStandalone: true, selector: "cub-button-group", host: { classAttribute: "cub-button-group" }, exportAs: ["cubButtonGroup"], ngImport: i0, template: "<div class=\"cub-button-group-container\">\n  <ng-content></ng-content>\n</div>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButtonGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-button-group', exportAs: 'cubButtonGroup', host: {
                        class: 'cub-button-group',
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"cub-button-group-container\">\n  <ng-content></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [] });

class CubButtonModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubButtonModule, imports: [CubCommonModule,
            CubMenuModule,
            CubButton,
            CubIconButton,
            CubFloatingActionButton,
            CubHyperlink,
            CubButtonGroup], exports: [CubCommonModule,
            CubMenuModule,
            CubButton,
            CubIconButton,
            CubFloatingActionButton,
            CubHyperlink,
            CubButtonGroup] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButtonModule, imports: [CubCommonModule,
            CubMenuModule,
            CubButton,
            CubIconButton,
            CubFloatingActionButton, CubCommonModule,
            CubMenuModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        CubMenuModule,
                        CubButton,
                        CubIconButton,
                        CubFloatingActionButton,
                        CubHyperlink,
                        CubButtonGroup,
                    ],
                    exports: [
                        CubCommonModule,
                        CubMenuModule,
                        CubButton,
                        CubIconButton,
                        CubFloatingActionButton,
                        CubHyperlink,
                        CubButtonGroup,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/button
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubButton, CubButtonGroup, CubButtonModule, CubFloatingActionButton, CubHyperlink, CubIconButton };
//# sourceMappingURL=cub-lib-view-rootng-component-button.mjs.map
