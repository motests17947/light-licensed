import * as i0 from '@angular/core';
import { Optional, Inject, Component, ContentChild, Input, ContentChildren, NgModule } from '@angular/core';
import { CubDivider, CUB_SUFFIX, CUB_END, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import { CubLoadingModule } from 'cub-lib-view-rootng/component/loading';

class CubCardContent {
    get contentColorScheme() {
        return this.parentCard?.contentColorScheme || 'light';
    }
    constructor(parentCard) {
        this.parentCard = parentCard;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardContent, deps: [{ token: CubCard, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubCardContent, isStandalone: true, selector: "cub-card-content", host: { properties: { "class.cub-card-content-dark": "contentColorScheme === \"dark\"" }, classAttribute: "cub-card-content" }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardContent, decorators: [{
            type: Component,
            args: [{ selector: 'cub-card-content', host: {
                        class: 'cub-card-content',
                        '[class.cub-card-content-dark]': 'contentColorScheme === "dark"',
                    }, template: "<ng-content></ng-content>\n" }]
        }], ctorParameters: () => [{ type: CubCard, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CubCard]
                }] }] });

class CubCard {
    constructor() {
        /** 元件標題背景顏色，預設值為 'light'。 */
        this.headerColorScheme = 'light';
        /** 元件內容背景顏色，預設值為 'light'。 */
        this.contentColorScheme = 'light';
        /** 元件是否可選取，預設值為 false。 */
        this.interactive = false;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCard, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCard, isStandalone: true, selector: "cub-card", inputs: { headerColorScheme: "headerColorScheme", contentColorScheme: "contentColorScheme", interactive: "interactive" }, host: { properties: { "class.cub-interactive": "interactive" }, classAttribute: "cub-card" }, queries: [{ propertyName: "_contentStatic", first: true, predicate: CubCardContent, descendants: true, static: true }], ngImport: i0, template: "<ng-content select=\"cub-card-header\"></ng-content>\n\n@if (_contentStatic) {\n<ng-content select=\"cub-card-content\"></ng-content>\n} @else {\n<div\n  class=\"cub-card-content\"\n  [class.cub-card-content-dark]=\"contentColorScheme === 'dark'\"\n>\n  <ng-content></ng-content>\n</div>\n}\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCard, decorators: [{
            type: Component,
            args: [{ selector: 'cub-card', host: {
                        class: 'cub-card',
                        '[class.cub-interactive]': 'interactive',
                    }, template: "<ng-content select=\"cub-card-header\"></ng-content>\n\n@if (_contentStatic) {\n<ng-content select=\"cub-card-content\"></ng-content>\n} @else {\n<div\n  class=\"cub-card-content\"\n  [class.cub-card-content-dark]=\"contentColorScheme === 'dark'\"\n>\n  <ng-content></ng-content>\n</div>\n}\n" }]
        }], ctorParameters: () => [], propDecorators: { headerColorScheme: [{
                type: Input
            }], contentColorScheme: [{
                type: Input
            }], interactive: [{
                type: Input
            }], _contentStatic: [{
                type: ContentChild,
                args: [CubCardContent, { static: true }]
            }] } });

class CubCardHeader {
    get headerColorScheme() {
        return this.parentCard?.headerColorScheme || 'light';
    }
    constructor(parentCard) {
        this.parentCard = parentCard;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardHeader, deps: [{ token: CubCard, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCardHeader, isStandalone: true, selector: "cub-card-header", host: { classAttribute: "cub-card-header" }, queries: [{ propertyName: "_headerSuffixChildren", predicate: CUB_SUFFIX, descendants: true }, { propertyName: "_headerEndChildren", predicate: CUB_END, descendants: true }], ngImport: i0, template: "<div\n  class=\"cub-card-header-content\"\n  [class.cub-card-header-dark]=\"headerColorScheme === 'dark'\"\n>\n  <div class=\"cub-card-header-appended\">\n    <div class=\"cub-card-header-title\">\n      <ng-content></ng-content>\n    </div>\n\n    @if (_headerSuffixChildren.length) {\n    <span class=\"cub-card-header-suffix\">\n      <ng-content select=\"[cubSuffix]\"></ng-content>\n    </span>\n    }\n  </div>\n\n  @if (_headerEndChildren.length) {\n  <span class=\"cub-card-header-end\">\n    <ng-content select=\"[cubEnd]\"></ng-content>\n  </span>\n  }\n</div>\n<cub-divider></cub-divider>\n", styles: [""], dependencies: [{ kind: "directive", type: CubDivider, selector: "[cubDivider], cub-divider", inputs: ["appearance", "orientation"], exportAs: ["cubDivider"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-card-header', host: {
                        class: 'cub-card-header',
                    }, imports: [CubDivider], template: "<div\n  class=\"cub-card-header-content\"\n  [class.cub-card-header-dark]=\"headerColorScheme === 'dark'\"\n>\n  <div class=\"cub-card-header-appended\">\n    <div class=\"cub-card-header-title\">\n      <ng-content></ng-content>\n    </div>\n\n    @if (_headerSuffixChildren.length) {\n    <span class=\"cub-card-header-suffix\">\n      <ng-content select=\"[cubSuffix]\"></ng-content>\n    </span>\n    }\n  </div>\n\n  @if (_headerEndChildren.length) {\n  <span class=\"cub-card-header-end\">\n    <ng-content select=\"[cubEnd]\"></ng-content>\n  </span>\n  }\n</div>\n<cub-divider></cub-divider>\n" }]
        }], ctorParameters: () => [{ type: CubCard, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CubCard]
                }] }], propDecorators: { _headerSuffixChildren: [{
                type: ContentChildren,
                args: [CUB_SUFFIX, { descendants: true }]
            }], _headerEndChildren: [{
                type: ContentChildren,
                args: [CUB_END, { descendants: true }]
            }] } });

class CubCardModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubCardModule, imports: [CubCommonModule,
            CubLoadingModule,
            CubCard,
            CubCardContent,
            CubCardHeader], exports: [CubCommonModule,
            CubLoadingModule,
            CubCard,
            CubCardContent,
            CubCardHeader] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardModule, imports: [CubCommonModule,
            CubLoadingModule, CubCommonModule,
            CubLoadingModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCardModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        CubLoadingModule,
                        CubCard,
                        CubCardContent,
                        CubCardHeader,
                    ],
                    exports: [
                        CubCommonModule,
                        CubLoadingModule,
                        CubCard,
                        CubCardContent,
                        CubCardHeader,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/card
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubCard, CubCardContent, CubCardHeader, CubCardModule };
//# sourceMappingURL=cub-lib-view-rootng-component-card.mjs.map
