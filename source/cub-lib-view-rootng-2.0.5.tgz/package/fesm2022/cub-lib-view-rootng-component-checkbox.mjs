import * as i0 from '@angular/core';
import { InjectionToken, EventEmitter, Output, Input, Directive, ViewChild, forwardRef, ContentChildren, Optional, Inject, Attribute, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR, CheckboxRequiredValidator, NG_VALIDATORS } from '@angular/forms';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { mixinTabIndex, mixinColor, mixinDisableRipple, mixinDisabled, CubRipple } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';

function CUB_CHECKBOX_DEFAULT_OPTIONS_FACTORY() {
    return {
        color: 'brand',
        clickAction: 'check-indeterminate',
    };
}

const CUB_CHECKBOX_DEFAULT_OPTIONS = new InjectionToken('cub-checkbox-default-options', {
    providedIn: 'root',
    factory: CUB_CHECKBOX_DEFAULT_OPTIONS_FACTORY,
});

let nextUniqueId = 0;
const defaults = CUB_CHECKBOX_DEFAULT_OPTIONS_FACTORY();
const _CubCheckboxMixinBase = mixinTabIndex(mixinColor(mixinDisableRipple(mixinDisabled(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}))));
class CubCheckboxChange {
    constructor() {
        this.checked = false;
    }
}
class CubCheckboxGroupChange {
    constructor(source, value) {
        this.source = source;
        this.value = value;
    }
}
const CUB_CHECKBOX = new InjectionToken('Checkbox');
const CUB_CHECKBOX_GROUP = new InjectionToken('CheckboxGroup');
class _CubCheckboxGroupBase {
    /** 元件名稱，用於表單提交，預設為 undefined。 */
    get name() {
        return this._name;
    }
    set name(value) {
        this._name = value;
        this._updateCheckboxNames();
    }
    /** 元件標籤位置，預設值為 'after'。 */
    get labelPosition() {
        return this._labelPosition;
    }
    set labelPosition(v) {
        this._labelPosition = v === 'before' ? 'before' : 'after';
        this.markCheckboxesForCheck();
    }
    /** 元件輸入的的當前值，預設為 undefined。 */
    get value() {
        return this._value;
    }
    set value(value) {
        if (!this.compareArray(this._value, value)) {
            this._value = value;
            this._updateSelectedCheckboxFromValue();
            if (!this._isUpdatingFromModel && this._isInitialized) {
                this._controlValueAccessorChangeFn(this._value);
            }
        }
    }
    /**
     * 元件的選中項目。
     * 此屬性用於設定或取得目前被選中的項目列表。
     * 預設值為 []。
     */
    get selected() {
        return this._selected;
    }
    set selected(selected) {
        this._selected = selected;
        this._updateValueFromSelectedCheckbox();
    }
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        this.markCheckboxesForCheck();
        this._checkSelectedCheckbox();
    }
    /** 元件是否為必填，預設為 false。 */
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
        this.markCheckboxesForCheck();
        this._checkSelectedCheckbox();
    }
    constructor(_changeDetector) {
        this._changeDetector = _changeDetector;
        this._isUpdatingFromModel = false;
        this._isInitialized = false;
        this._name = `cub-checkbox-group-${nextUniqueId++}`;
        this._labelPosition = 'after';
        this._value = [];
        this._selected = [];
        this._disabled = false;
        this._required = false;
        /** 當元件值發生變化時觸發的事件。傳遞一個 `CubCheckboxChange` 物件，包含元件的來源和選中狀態。 */
        this.change = new EventEmitter();
        this.onTouched = () => { };
        this._controlValueAccessorChangeFn = () => { };
    }
    ngAfterContentInit() {
        this._isInitialized = true;
    }
    writeValue(value) {
        this._isUpdatingFromModel = true;
        this.value = value || [];
        this._changeDetector.markForCheck();
        this._isUpdatingFromModel = false;
    }
    registerOnChange(fn) {
        this._controlValueAccessorChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._changeDetector.markForCheck();
    }
    emitChangeEvent() {
        if (this._isInitialized) {
            this.change.emit(new CubCheckboxGroupChange(this._selected, this._value));
            if (!this._isUpdatingFromModel) {
                this._controlValueAccessorChangeFn(this._value);
            }
        }
    }
    markCheckboxesTouched() {
        if (this.onTouched) {
            this.onTouched();
        }
    }
    markCheckboxesForCheck() {
        if (this._checkboxes) {
            this._checkboxes.forEach((checkbox) => checkbox.markForCheck());
        }
    }
    _checkSelectedCheckbox() {
        if (this._checkboxes) {
            this._checkboxes.forEach((checkbox) => {
                if (this.value.includes(checkbox.value) && !checkbox.checked) {
                    checkbox.checked = true;
                }
            });
        }
    }
    _updateCheckboxNames() {
        if (this._checkboxes) {
            this._checkboxes.forEach((checkbox) => {
                checkbox.name = this.name;
                checkbox.markForCheck();
            });
        }
    }
    _updateSelectedCheckboxFromValue() {
        if (this._checkboxes) {
            this._selected = this.value.map((value) => this._checkboxes.filter((checkbox) => value === checkbox.value)[0]);
            // 同步更新每個 checkbox 的選取狀態
            this._checkboxes.forEach((checkbox) => {
                if (checkbox.value) {
                    const shouldBeChecked = this.value.includes(checkbox.value);
                    if (checkbox.checked !== shouldBeChecked) {
                        checkbox.checked = shouldBeChecked;
                    }
                }
            });
        }
    }
    _updateValueFromSelectedCheckbox() {
        this._value = this.selected
            .filter((checkbox) => checkbox.checked)
            .map((checkbox) => checkbox.value);
    }
    compareArray(prevArray, nextArray) {
        if (prevArray.length !== nextArray.length)
            return false;
        prevArray.sort();
        nextArray.sort();
        for (let index = 0; index < prevArray.length; index++) {
            if (prevArray[index] !== nextArray[index])
                return false;
        }
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubCheckboxGroupBase, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubCheckboxGroupBase, isStandalone: true, inputs: { name: "name", labelPosition: "labelPosition", value: "value", selected: "selected", disabled: "disabled", required: "required" }, outputs: { change: "change" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubCheckboxGroupBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { name: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], value: [{
                type: Input
            }], selected: [{
                type: Input
            }], disabled: [{
                type: Input
            }], required: [{
                type: Input
            }], change: [{
                type: Output
            }] } });
class _CubCheckboxBase extends _CubCheckboxMixinBase {
    get inputId() {
        return `${this.id || this._uniqueId}-input`;
    }
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        return (this._disabled ||
            (this.checkboxGroup !== null && this.checkboxGroup.disabled));
    }
    set disabled(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== this.disabled) {
            this._disabled = newValue;
            this._changeDetectorRef.markForCheck();
        }
    }
    /** 元件標籤位置，預設值為 'after'。 */
    get labelPosition() {
        return (this._labelPosition ||
            (this.checkboxGroup && this.checkboxGroup.labelPosition) ||
            'after');
    }
    set labelPosition(value) {
        this._labelPosition = value;
    }
    /** 元件是否被選中，預設為 false。 */
    get checked() {
        return this._checked;
    }
    set checked(value) {
        const newCheckedState = coerceBooleanProperty(value);
        if (this._checked !== newCheckedState) {
            this._checked = newCheckedState;
            if (newCheckedState &&
                this.checkboxGroup &&
                !this.checkboxGroup.value.includes(this.value)) {
                this.checkboxGroup.selected = this.checkboxGroup.selected.concat(this);
            }
            else if (!newCheckedState &&
                this.checkboxGroup &&
                this.checkboxGroup.value.includes(this.value)) {
                this.checkboxGroup.selected = this.checkboxGroup.selected.filter((checkbox) => checkbox === this);
            }
            this._changeDetectorRef.markForCheck();
        }
    }
    /** 元件的當前值，預設為 ''。 */
    get value() {
        return this._value;
    }
    set value(value) {
        if (this._value !== value) {
            this._value = value;
            if (this.checkboxGroup !== null) {
                if (!this.checked) {
                    this.checked = this.checkboxGroup.value.includes(value);
                }
                if (this.checked) {
                    this.checkboxGroup.selected.push(this);
                }
            }
        }
    }
    /** 元件是否為必填，預設為 false。 */
    get required() {
        return (this._required ||
            (this.checkboxGroup !== null && this.checkboxGroup.required));
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    /** 元件部分選取狀態，預設值為 false。 */
    get indeterminate() {
        return this._indeterminate;
    }
    set indeterminate(value) {
        const changed = value != this._indeterminate;
        this._indeterminate = coerceBooleanProperty(value);
        if (changed) {
            this.indeterminateChange.emit(this._indeterminate);
        }
        this._syncIndeterminate(this._indeterminate);
    }
    constructor(idPrefix, checkboxGroup, elementRef, _changeDetectorRef, _focusMonitor, _ngZone, tabIndex, _options) {
        super(elementRef);
        this._changeDetectorRef = _changeDetectorRef;
        this._focusMonitor = _focusMonitor;
        this._ngZone = _ngZone;
        this._options = _options;
        this._checked = false;
        this._value = '';
        this._disabled = false;
        this._required = false;
        this._indeterminate = false;
        this._labelPosition = 'after';
        /** 元件標題（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaLabel = '';
        /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
        this.ariaLabelledby = null;
        /** 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaDescribedby = '';
        /** 元件名稱，用於表單提交，預設為 undefined。 */
        this.name = null;
        /** 當元件值發生變化時觸發的事件。傳遞一個 `CubCheckboxChange` 物件，包含元件的來源和選中狀態。 */
        this.change = new EventEmitter();
        /** 當元件的部分選取狀態發生變化時觸發的事件。傳遞一個布林值，表示新的狀態。 */
        this.indeterminateChange = new EventEmitter();
        this._onTouched = () => { };
        this._controlValueAccessorChangeFn = () => { };
        this.checkboxGroup = checkboxGroup;
        this._options = this._options || defaults;
        this.tabIndex = parseInt(tabIndex) || 0;
        this.id = this._uniqueId = `${idPrefix}${++nextUniqueId}`;
    }
    ngOnInit() {
        if (this.checkboxGroup) {
            this.checked = this.checkboxGroup.value.includes(this.value);
            if (this.checked) {
                this.checkboxGroup.selected.push(this);
            }
            this.name = this.checkboxGroup.name;
        }
    }
    ngDoCheck() {
        this._syncIndeterminate(this._indeterminate);
    }
    ngAfterViewInit() {
        this._syncIndeterminate(this._indeterminate);
        this._focusMonitor
            .monitor(this._elementRef, true)
            .subscribe((focusOrigin) => {
            if (!focusOrigin && this.checkboxGroup) {
                this.checkboxGroup.markCheckboxesTouched();
            }
        });
    }
    writeValue(value) {
        this.checked = !!value;
    }
    registerOnChange(fn) {
        this._controlValueAccessorChangeFn = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    toggle() {
        this.checked = !this.checked;
        this._controlValueAccessorChangeFn(this.checked);
    }
    markForCheck() {
        this._changeDetectorRef.markForCheck();
    }
    _isRippleDisabled() {
        return this.disableRipple || this.disabled;
    }
    _onLabelTextChange() {
        this._changeDetectorRef.detectChanges();
    }
    _getAriaChecked() {
        if (this.checked) {
            return 'true';
        }
        return this.indeterminate ? 'mixed' : 'false';
    }
    _onInteractionEvent(event) {
        event.stopPropagation();
    }
    _onBlur() {
        Promise.resolve().then(() => {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        });
    }
    _handleInputClick() {
        const clickAction = this._options?.clickAction;
        if (!this.disabled && clickAction !== 'noop') {
            if (this.indeterminate && clickAction !== 'check') {
                Promise.resolve().then(() => {
                    this._indeterminate = false;
                    this.indeterminateChange.emit(this._indeterminate);
                });
            }
            this._checked = !this._checked;
            this._emitChangeEvent();
        }
        else if (!this.disabled && clickAction === 'noop') {
            this._inputElement.nativeElement.checked = this.checked;
            this._inputElement.nativeElement.indeterminate = this.indeterminate;
        }
        if (this.checkboxGroup) {
            let groupValue = this.checkboxGroup.value;
            if (this._checked && !groupValue.includes(this.value)) {
                groupValue = groupValue.concat(this.value);
            }
            else if (!this._checked && groupValue.includes(this.value)) {
                groupValue = groupValue.filter((value) => value !== this.value);
            }
            this.checkboxGroup.value = groupValue;
            this.checkboxGroup._controlValueAccessorChangeFn(groupValue);
            this.checkboxGroup.emitChangeEvent();
        }
        // 觸發驗證狀態更新
        if (this._onTouched) {
            this._onTouched();
        }
        if (this.checkboxGroup) {
            this.checkboxGroup.markCheckboxesTouched();
        }
    }
    _emitChangeEvent() {
        this._controlValueAccessorChangeFn(this.checked);
        this.change.emit(this._createChangeEvent(this.checked));
        if (this._inputElement) {
            this._inputElement.nativeElement.checked = this.checked;
        }
    }
    _syncIndeterminate(value) {
        const nativeCheckbox = this._inputElement;
        if (nativeCheckbox) {
            nativeCheckbox.nativeElement.indeterminate = value;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubCheckboxBase, deps: "invalid", target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubCheckboxBase, isStandalone: true, inputs: { disabled: "disabled", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], id: "id", name: "name", labelPosition: "labelPosition", checked: "checked", value: "value", required: "required", indeterminate: "indeterminate" }, outputs: { change: "change", indeterminateChange: "indeterminateChange" }, viewQueries: [{ propertyName: "_inputElement", first: true, predicate: ["input"], descendants: true }, { propertyName: "_labelElement", first: true, predicate: ["label"], descendants: true }, { propertyName: "ripple", first: true, predicate: CubRipple, descendants: true }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubCheckboxBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: undefined }, { type: _CubCheckboxGroupBase }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.FocusMonitor }, { type: i0.NgZone }, { type: undefined }, { type: undefined }], propDecorators: { disabled: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], id: [{
                type: Input
            }], name: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], checked: [{
                type: Input
            }], value: [{
                type: Input
            }], required: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], change: [{
                type: Output
            }], indeterminateChange: [{
                type: Output
            }], _inputElement: [{
                type: ViewChild,
                args: ['input']
            }], _labelElement: [{
                type: ViewChild,
                args: ['label']
            }], ripple: [{
                type: ViewChild,
                args: [CubRipple]
            }] } });
class CubCheckboxGroup extends _CubCheckboxGroupBase {
    constructor() {
        super(...arguments);
        /** 群組排列方向，預設為 'horizontal'。 */
        this.orientation = 'horizontal';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxGroup, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCheckboxGroup, isStandalone: true, selector: "cub-checkbox-group", inputs: { orientation: "orientation" }, host: { attributes: { "role": "checkboxgroup" }, properties: { "class.cub-checkbox-group-horizontal": "orientation === \"horizontal\"", "class.cub-checkbox-group-vertical": "orientation === \"vertical\"" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CubCheckboxGroup),
                multi: true,
            },
            { provide: CUB_CHECKBOX_GROUP, useExisting: CubCheckboxGroup },
        ], queries: [{ propertyName: "_checkboxes", predicate: i0.forwardRef(() => CubCheckbox), descendants: true }], exportAs: ["cubCheckboxGroup"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-checkbox-group',
                    exportAs: 'cubCheckboxGroup',
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CubCheckboxGroup),
                            multi: true,
                        },
                        { provide: CUB_CHECKBOX_GROUP, useExisting: CubCheckboxGroup },
                    ],
                    host: {
                        role: 'checkboxgroup',
                        '[class.cub-checkbox-group-horizontal]': 'orientation === "horizontal"',
                        '[class.cub-checkbox-group-vertical]': 'orientation === "vertical"',
                    },
                }]
        }], propDecorators: { orientation: [{
                type: Input
            }], _checkboxes: [{
                type: ContentChildren,
                args: [forwardRef(() => CubCheckbox), {
                        descendants: true,
                    }]
            }] } });
class CubCheckbox extends _CubCheckboxBase {
    constructor(checkboxGroup, elementRef, changeDetectorRef, _focusMonitor, ngZone, tabIndex, _animationMode, options) {
        super('cub-checkbox-', checkboxGroup, elementRef, changeDetectorRef, _focusMonitor, ngZone, tabIndex, options);
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        this._noopAnimations = _animationMode === 'NoopAnimations';
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this._focusMonitor
            .monitor(this._elementRef, true)
            .subscribe((focusOrigin) => {
            if (!focusOrigin) {
                this._onBlur();
            }
        });
    }
    ngOnDestroy() {
        this._focusMonitor.stopMonitoring(this._elementRef);
    }
    /**
     * 處理標籤上的鍵盤事件。
     * 當使用者按下空白鍵時，會切換選取狀態，與顯示 Ripple 漣漪。
     */
    _onLabelKeydown(event, rippleRef) {
        if (event instanceof KeyboardEvent) {
            /* 空白鍵以外操作不顯示 Ripple */
            rippleRef.disabled = event.code !== 'Space';
            if (event.code === 'Space' || event.key === ' ') {
                event.preventDefault();
                event.stopPropagation();
                this._handleInputClick();
            }
        }
    }
    _onInputClick(event) {
        event.stopPropagation();
        super._handleInputClick();
    }
    focus(origin, options) {
        if (origin) {
            this._focusMonitor.focusVia(this._inputElement, origin, options);
        }
        else {
            this._inputElement.nativeElement.focus(options);
        }
    }
    _createChangeEvent(isChecked) {
        const event = new CubCheckboxChange();
        event.source = this;
        event.checked = isChecked;
        return event;
    }
    _getAnimationTargetElement() {
        return this._elementRef.nativeElement;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckbox, deps: [{ token: CUB_CHECKBOX_GROUP, optional: true }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.FocusMonitor }, { token: i0.NgZone }, { token: 'tabindex', attribute: true }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: CUB_CHECKBOX_DEFAULT_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCheckbox, isStandalone: true, selector: "cub-checkbox", inputs: { disableRipple: "disableRipple", tabIndex: "tabIndex", size: "size" }, host: { properties: { "id": "id", "class.cub-checkbox-indeterminate": "indeterminate", "class.cub-checked": "checked", "class.cub-disabled": "disabled", "class.cub-checkbox-small": "size === \"small\"", "attr.tabindex": "null", "attr.aria-label": "null", "attr.aria-labelledby": "null" }, classAttribute: "cub-checkbox-base cub-checkbox" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CubCheckbox),
                multi: true,
            },
        ], exportAs: ["cubCheckbox"], usesInheritance: true, ngImport: i0, template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  [tabIndex]=\"tabIndex\"\n  class=\"cub-checkbox-label\"\n  [class.cub-checkbox-label-before]=\"labelPosition == 'before'\"\n  [class.cub-checkbox-label-empty]=\"\n    !checkboxLabel.textContent || !checkboxLabel.textContent.trim()\n  \"\n  (keydown)=\"_onLabelKeydown($event, rippleRef)\"\n>\n  <span class=\"cub-checkbox-container\">\n    <input\n      #input\n      class=\"cub-checkbox-input cub-cdk-visually-hidden\"\n      type=\"checkbox\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [attr.value]=\"value\"\n      [disabled]=\"disabled\"\n      [attr.name]=\"name\"\n      [tabIndex]=\"-1\"\n      [attr.aria-label]=\"ariaLabel || null\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-checked]=\"_getAriaChecked()\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"_onInteractionEvent($event)\"\n      (click)=\"_onInputClick($event)\"\n    />\n    <span class=\"cub-checkbox-frame\"></span>\n    <span class=\"cub-checkbox-background\">\n      @if (indeterminate) {\n        <span class=\"cub-checkbox-mixedmark\"></span>\n      }\n      @if (checked) {\n        <span class=\"cub-checkbox-checkmark\"></span>\n      }\n    </span>\n    <span\n      #rippleRef=\"cubRipple\"\n      class=\"cub-focus-indicator\"\n      cubRipple\n      cubRippleClass=\"cub-checkbox-ripple\"\n      [cubRippleTrigger]=\"label\"\n      [cubRippleDisabled]=\"_isRippleDisabled()\"\n      [cubRippleCentered]=\"true\"\n      [cubRippleAnimation]=\"{\n        enterDuration: _noopAnimations ? 0 : 150,\n      }\"\n    >\n    </span>\n    <span class=\"cub-persistent-ripple cub-checkbox-persistent-ripple\"></span>\n  </span>\n  <span\n    class=\"cub-checkbox-label-content\"\n    (cubCdkObserveContent)=\"_onLabelTextChange()\"\n    #checkboxLabel\n  >\n    <span style=\"display: none\">&nbsp;</span>\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckbox, decorators: [{
            type: Component,
            args: [{ selector: 'cub-checkbox', exportAs: 'cubCheckbox', host: {
                        class: 'cub-checkbox-base cub-checkbox',
                        '[id]': 'id',
                        '[class.cub-checkbox-indeterminate]': 'indeterminate',
                        '[class.cub-checked]': 'checked',
                        '[class.cub-disabled]': 'disabled',
                        '[class.cub-checkbox-small]': 'size === "small"',
                        '[attr.tabindex]': 'null',
                        '[attr.aria-label]': 'null',
                        '[attr.aria-labelledby]': 'null',
                    }, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CubCheckbox),
                            multi: true,
                        },
                    ], inputs: ['disableRipple', 'tabIndex'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubRipple], template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  [tabIndex]=\"tabIndex\"\n  class=\"cub-checkbox-label\"\n  [class.cub-checkbox-label-before]=\"labelPosition == 'before'\"\n  [class.cub-checkbox-label-empty]=\"\n    !checkboxLabel.textContent || !checkboxLabel.textContent.trim()\n  \"\n  (keydown)=\"_onLabelKeydown($event, rippleRef)\"\n>\n  <span class=\"cub-checkbox-container\">\n    <input\n      #input\n      class=\"cub-checkbox-input cub-cdk-visually-hidden\"\n      type=\"checkbox\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [attr.value]=\"value\"\n      [disabled]=\"disabled\"\n      [attr.name]=\"name\"\n      [tabIndex]=\"-1\"\n      [attr.aria-label]=\"ariaLabel || null\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-checked]=\"_getAriaChecked()\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"_onInteractionEvent($event)\"\n      (click)=\"_onInputClick($event)\"\n    />\n    <span class=\"cub-checkbox-frame\"></span>\n    <span class=\"cub-checkbox-background\">\n      @if (indeterminate) {\n        <span class=\"cub-checkbox-mixedmark\"></span>\n      }\n      @if (checked) {\n        <span class=\"cub-checkbox-checkmark\"></span>\n      }\n    </span>\n    <span\n      #rippleRef=\"cubRipple\"\n      class=\"cub-focus-indicator\"\n      cubRipple\n      cubRippleClass=\"cub-checkbox-ripple\"\n      [cubRippleTrigger]=\"label\"\n      [cubRippleDisabled]=\"_isRippleDisabled()\"\n      [cubRippleCentered]=\"true\"\n      [cubRippleAnimation]=\"{\n        enterDuration: _noopAnimations ? 0 : 150,\n      }\"\n    >\n    </span>\n    <span class=\"cub-persistent-ripple cub-checkbox-persistent-ripple\"></span>\n  </span>\n  <span\n    class=\"cub-checkbox-label-content\"\n    (cubCdkObserveContent)=\"_onLabelTextChange()\"\n    #checkboxLabel\n  >\n    <span style=\"display: none\">&nbsp;</span>\n    <ng-content></ng-content>\n  </span>\n</label>\n" }]
        }], ctorParameters: () => [{ type: CubCheckboxGroup, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CHECKBOX_GROUP]
                }] }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.FocusMonitor }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CHECKBOX_DEFAULT_OPTIONS]
                }] }], propDecorators: { size: [{
                type: Input
            }] } });

class CubCheckboxRequiredValidator extends CheckboxRequiredValidator {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxRequiredValidator, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCheckboxRequiredValidator, isStandalone: true, selector: "cub-checkbox[required][formControlName],\n             cub-checkbox[required][formControl], cub-checkbox[required][ngModel]", providers: [
            {
                provide: NG_VALIDATORS,
                useExisting: forwardRef(() => CheckboxRequiredValidator),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxRequiredValidator, decorators: [{
            type: Directive,
            args: [{
                    selector: `cub-checkbox[required][formControlName],
             cub-checkbox[required][formControl], cub-checkbox[required][ngModel]`,
                    providers: [
                        {
                            provide: NG_VALIDATORS,
                            useExisting: forwardRef(() => CheckboxRequiredValidator),
                            multi: true,
                        },
                    ]
                }]
        }] });

class CubCheckboxModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubCheckbox,
            CubCheckboxGroup,
            CubCheckboxRequiredValidator], exports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubCheckbox,
            CubCheckboxGroup,
            CubCheckboxRequiredValidator] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule, CubFormFieldModule,
            CubLabelModule,
            CubInputModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCheckboxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubCheckbox,
                        CubCheckboxGroup,
                        CubCheckboxRequiredValidator,
                    ],
                    exports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubCheckbox,
                        CubCheckboxGroup,
                        CubCheckboxRequiredValidator,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/checkbox
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_CHECKBOX, CUB_CHECKBOX_DEFAULT_OPTIONS, CUB_CHECKBOX_DEFAULT_OPTIONS_FACTORY, CUB_CHECKBOX_GROUP, CubCheckbox, CubCheckboxChange, CubCheckboxGroup, CubCheckboxGroupChange, CubCheckboxModule, CubCheckboxRequiredValidator, _CubCheckboxBase, _CubCheckboxGroupBase };
//# sourceMappingURL=cub-lib-view-rootng-component-checkbox.mjs.map
