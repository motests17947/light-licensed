import * as i0 from '@angular/core';
import { InjectionToken, inject, ElementRef, numberAttribute, booleanAttribute, Input, Directive, ChangeDetectorRef, Injector, NgZone, DOCUMENT, EventEmitter, ContentChildren, ContentChild, Output, ChangeDetectionStrategy, ViewEncapsulation, Component, QueryList, forwardRef, Inject, Optional, Attribute, Self, NgModule } from '@angular/core';
import { Subject, merge } from 'rxjs';
import { ENTER, FocusMonitor, BACKSPACE, DELETE, Directionality, FocusKeyManager, BreakpointObserver, TAB } from 'cub-lib-view-rootng/cdk';
import * as i3 from 'cub-lib-view-rootng/component/common';
import { CubRipple, CubPrefix, CubSuffix, mixinTabIndex, mixinColor, mixinDisableRipple, mixinErrorState } from 'cub-lib-view-rootng/component/common';
import { ENTER as ENTER$1, SPACE, BACKSPACE as BACKSPACE$1, DELETE as DELETE$1, TAB as TAB$1, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { NgTemplateOutlet, AsyncPipe } from '@angular/common';
import * as i2 from '@angular/forms';
import { NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { startWith, switchMap, takeUntil, take } from 'rxjs/operators';
import { CubButton, CubIconButton } from 'cub-lib-view-rootng/component/button';
import { FocusKeyManager as FocusKeyManager$1 } from 'cub-lib-view-rootng/cdk/a11y';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { SelectionModel } from 'cub-lib-view-rootng/cdk/collections';
import { CubFormFieldControl, CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import * as i1 from 'cub-lib-view-rootng/cdk/platform';
import * as i1$1 from 'cub-lib-view-rootng/cdk/bidi';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';

// /** Injection token to be used to override the default options for the chips module. */
const CUB_CHIP_DEFAULT_OPTIONS = new InjectionToken('cub-chips-default-options', {
    providedIn: 'root',
    factory: () => ({
        separatorKeyCodes: [ENTER],
    }),
});
//  */
const CUB_CHIP_REMOVE = new InjectionToken('CubChipRemove');
/**
 * Injection token used to avoid a circular dependency between the `MatChip` and `MatChipAction`.
 */
const CUB_CHIP = new InjectionToken('CubChipBase');
const CUB_CHIPS_DEFAULT_OPTIONS = new InjectionToken('cub-chips-default-options');
const CUB_CHIP_DEFAULT_OPTIONS_PROVIDER = {
    provide: CUB_CHIPS_DEFAULT_OPTIONS,
    useValue: {
        separatorKeyCodes: [ENTER],
    },
};

/**
 * Section within a chip.
 * @docs-private
 */
class CubChipBaseAction {
    /**
     * 是否停用元件狀態，預設值為 false。
     */
    get disabled() {
        return this._disabled || this._parentChip?.disabled || false;
    }
    set disabled(value) {
        this._disabled = value;
    }
    constructor() {
        this._elementRef = inject(ElementRef);
        /** Whether this is the primary action in the chip. */
        this._isPrimary = true;
        this._parentChip = inject(CUB_CHIP);
        this._disabled = false;
        /**
         * 是否可以互動，預設值為 true。
         */
        this.interactive = true;
        /**
         * 添加 tabIndex 屬性，預設值為 -1。
         */
        this.tabIndex = 0;
        /**
         * 當元件為停用狀態時，是否還能 Focus，預設值為 false。
         */
        this.allowFocusWhenDisabled = false;
        if (this._elementRef.nativeElement.nodeName === 'BUTTON') {
            this._elementRef.nativeElement.setAttribute('type', 'button');
        }
    }
    focus() {
        this._elementRef.nativeElement.focus();
    }
    _handleClick(event) {
        if (!this.disabled && this.interactive && this._isPrimary) {
            event.preventDefault();
            this._parentChip._handlePrimaryActionInteraction();
        }
    }
    _handleKeydown(event) {
        if ((event.keyCode === ENTER$1 || event.keyCode === SPACE) &&
            !this.disabled &&
            this.interactive &&
            this._isPrimary &&
            !this._parentChip._isEditing) {
            event.preventDefault();
            this._parentChip._handlePrimaryActionInteraction();
        }
    }
    /**
     * Determine the value of the tabindex attribute for this chip action.
     */
    _getTabindex() {
        return (this.disabled && !this.allowFocusWhenDisabled) || !this.interactive
            ? null
            : this.tabIndex.toString();
    }
    /**
     * Determine the value of the disabled attribute for this chip action.
     */
    _getDisabledAttribute() {
        // When this chip action is disabled and focusing disabled chips is not permitted, return empty
        // string to indicate that disabled attribute should be included.
        return this.disabled && !this.allowFocusWhenDisabled ? '' : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipBaseAction, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubChipBaseAction, isStandalone: true, selector: "[CubChipBaseAction]", inputs: { interactive: "interactive", disabled: ["disabled", "disabled", booleanAttribute], tabIndex: ["tabIndex", "tabIndex", (value) => value == null ? -1 : numberAttribute(value)], allowFocusWhenDisabled: "allowFocusWhenDisabled" }, host: { listeners: { "click": "_handleClick($event)", "keydown": "_handleKeydown($event)" }, properties: { "attr.tabindex": "_getTabindex()", "attr.disabled": "_getDisabledAttribute()", "attr.aria-disabled": "disabled" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipBaseAction, decorators: [{
            type: Directive,
            args: [{
                    selector: '[CubChipBaseAction]',
                    host: {
                        '[attr.tabindex]': '_getTabindex()',
                        '[attr.disabled]': '_getDisabledAttribute()',
                        '[attr.aria-disabled]': 'disabled',
                        '(click)': '_handleClick($event)',
                        '(keydown)': '_handleKeydown($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { interactive: [{
                type: Input
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], tabIndex: [{
                type: Input,
                args: [{
                        transform: (value) => value == null ? -1 : numberAttribute(value),
                    }]
            }], allowFocusWhenDisabled: [{
                type: Input
            }] } });

let CubChipBaseElementId = 0;
/**
 * Material design styled Chip base component. Used inside the MatChipSet component.
 *
 * Extended by MatChipOption and MatChipRow for different interaction patterns.
 */
class CubChipBase {
    /**
     添加元件的 value 會自動去掉前後的空白，預設值為 undefined。
     */
    get value() {
        return this._value !== undefined
            ? this._value
            : this._textElement.textContent.trim();
    }
    set value(value) {
        this._value = value;
    }
    /**
     * 元件是否為停用狀態，預設值為 false。
     */
    get disabled() {
        return this._disabled || this._chipListDisabled;
    }
    set disabled(value) {
        this._disabled = value;
    }
    constructor() {
        /** Whether the chip list is disabled. */
        this._chipListDisabled = false;
        this._changeDetectorRef = inject(ChangeDetectorRef);
        this._elementRef = inject(ElementRef);
        /** Emits when the chip is focused. */
        this._onFocus = new Subject();
        /** Emits when the chip is blurred. */
        this._onBlur = new Subject();
        /** The unstyled chip selector for this component. */
        this.basicChipAttrName = 'cub-basic-chip';
        this._injector = inject(Injector);
        this._ngZone = inject(NgZone);
        this._document = inject(DOCUMENT);
        this._focusMonitor = inject(FocusMonitor);
        /** Whether the chip has focus. */
        this._hasFocusInternal = false;
        this._disabled = false;
        /**
         * 設定元件 role 屬性，預設值為 null。
         */
        this.role = null;
        /**
         * 設定元件尺寸，預設值為 'medium'。
         */
        this.size = 'medium';
        /**
         * 設定 id 屬性確保 chip 有一個 unique 的 id 名，預設為 'cub-chip-0'。
         */
        this.id = `cub-chip-${CubChipBaseElementId++}`;
        /**
         * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 null。
         */
        this.ariaLabel = null;
        /**
         * 添加 aria-description 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 null。
         */
        this.ariaDescription = null;
        /**
         * 元件是否可移除，預設值為 true。
         */
        this.removable = true;
        /**
         * 元件是否要關閉漣漪效果，預設值為 false。
         */
        this.disableRipple = false;
        /** 送出刪除元件事件 */
        this.removed = new EventEmitter();
        /** 當元件實體被移除時送出 */
        this.destroyed = new EventEmitter();
        /* eslint-disable */
        /** Id of a span that contains this chip's aria description. */
        this._ariaDescriptionId = `${this.id}-aria-description`;
        this._monitorFocus();
    }
    ngOnInit() {
        // This check needs to happen in `ngOnInit` so the overridden value of
        // `basicChipAttrName` coming from base classes can be picked up.
        const element = this._elementRef.nativeElement;
        this._isBasicChip =
            element.hasAttribute(this.basicChipAttrName) ||
                element.tagName.toLowerCase() === this.basicChipAttrName;
    }
    ngAfterViewInit() {
        this._textElement = this._elementRef.nativeElement.querySelector('.cub-selectable-chip-label');
        if (this._pendingFocus) {
            this._pendingFocus = false;
            this.focus();
        }
    }
    ngAfterContentInit() {
        // Since the styling depends on the presence of some
        // actions, we have to mark for check on changes.
        this._actionChanges = merge(this._allLeadingIcons.changes, this._allRemoveIcons.changes).subscribe(() => this._changeDetectorRef.markForCheck());
    }
    ngOnDestroy() {
        this._focusMonitor.stopMonitoring(this._elementRef);
        this._actionChanges?.unsubscribe();
        this.destroyed.emit({ chip: this });
        this.destroyed.complete();
    }
    _hasFocus() {
        return this._hasFocusInternal;
    }
    /**
     * Allows for programmatic removal of the chip.
     *
     * Informs any listeners of the removal request. Does not remove the chip from the DOM.
     */
    remove() {
        if (this.removable) {
            this.removed.emit({ chip: this });
        }
    }
    /** Whether or not the ripple should be disabled. */
    _isRippleDisabled() {
        return this.disabled || this.disableRipple || this._isBasicChip;
    }
    /** Handles keyboard events on the chip. */
    _handleKeydown(event) {
        // Ignore backspace events where the user is holding down the key
        // so that we don't accidentally remove too many chips.
        if ((event.keyCode === BACKSPACE && !event.repeat) ||
            event.keyCode === DELETE) {
            event.preventDefault();
            this.remove();
        }
    }
    /** Allows for programmatic focusing of the chip. */
    focus() {
        if (!this.disabled) {
            // If `focus` is called before `ngAfterViewInit`, we won't have access to the primary action.
            // This can happen if the consumer tries to focus a chip immediately after it is added.
            // Queue the method to be called again on init.
            this._pendingFocus = true;
        }
    }
    /** Gets the action that contains a specific target node. */
    _getSourceAction(target) {
        return this._getActions().find((action) => {
            const element = action._elementRef.nativeElement;
            return element === target || element.contains(target);
        });
    }
    /** Gets all of the actions within the chip. */
    _getActions() {
        const result = [];
        return result;
    }
    /** Handles interactions with the primary action of the chip. */
    _handlePrimaryActionInteraction() {
        // Empty here, but is overwritten in child classes.
    }
    /** Starts the focus monitoring process on the chip. */
    _monitorFocus() {
        this._focusMonitor.monitor(this._elementRef, true).subscribe((origin) => {
            const hasFocus = origin !== null;
            if (hasFocus !== this._hasFocusInternal) {
                this._hasFocusInternal = hasFocus;
                if (hasFocus) {
                    this._onFocus.next({ chip: this });
                }
                else {
                    // When animations are enabled, Angular may end up removing the chip from the DOM a little
                    // earlier than usual, causing it to be blurred and throwing off the logic in the chip list
                    // that moves focus to the next item. To work around the issue, we defer marking the chip
                    // as not focused until after the next render.
                    this._changeDetectorRef.markForCheck();
                    setTimeout(() => this._ngZone.run(() => this._onBlur.next({ chip: this })));
                }
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipBase, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "20.3.3", type: CubChipBase, isStandalone: true, selector: "cub-chip-base", inputs: { role: "role", size: "size", id: "id", ariaLabel: ["aria-label", "ariaLabel"], ariaDescription: ["aria-description", "ariaDescription"], value: "value", removable: ["removable", "removable", booleanAttribute], disableRipple: ["disableRipple", "disableRipple", booleanAttribute], disabled: ["disabled", "disabled", booleanAttribute] }, outputs: { removed: "removed", destroyed: "destroyed" }, host: { listeners: { "keydown": "_handleKeydown($event)" }, properties: { "id": "id", "attr.role": "role", "attr.aria-label": "ariaLabel" } }, providers: [{ provide: CUB_CHIP, useExisting: CubChipBase }], queries: [{ propertyName: "leadingIcon", first: true, predicate: CubPrefix, descendants: true }, { propertyName: "_allLeadingIcons", predicate: CubPrefix, descendants: true }, { propertyName: "_allRemoveIcons", predicate: CubSuffix, descendants: true }], exportAs: ["CubChipBase"], ngImport: i0, template: "<div class=\"cub-chip-outter\">\n  <span\n    class=\"cub-chip-container\"\n    cubRipple\n    [cubRippleDisabled]=\"_isRippleDisabled()\"\n    [class.cub-disabled]=\"disabled\"\n    [class.cub-chip-small]=\"size === 'small'\"\n    (click)=\"remove()\"\n    cubRippleClass=\"cub-chip-ripple\"\n  >\n    <span CubChipBaseAction [interactive]=\"false\" class=\"cub-chip-label\">\n      <ng-content></ng-content>\n    </span>\n    <span class=\"cub-icon-x cub-chip-icon\"> </span>\n    <span class=\"cub-persistent-ripple cub-chip-persistent-ripple\"></span>\n  </span>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: CubChipBaseAction, selector: "[CubChipBaseAction]", inputs: ["interactive", "disabled", "tabIndex", "allowFocusWhenDisabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipBase, decorators: [{
            type: Component,
            args: [{ selector: 'cub-chip-base', exportAs: 'CubChipBase', host: {
                        '[id]': 'id',
                        '[attr.role]': 'role',
                        '[attr.aria-label]': 'ariaLabel',
                        '(keydown)': '_handleKeydown($event)',
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: CUB_CHIP, useExisting: CubChipBase }], imports: [CubRipple, CubChipBaseAction], template: "<div class=\"cub-chip-outter\">\n  <span\n    class=\"cub-chip-container\"\n    cubRipple\n    [cubRippleDisabled]=\"_isRippleDisabled()\"\n    [class.cub-disabled]=\"disabled\"\n    [class.cub-chip-small]=\"size === 'small'\"\n    (click)=\"remove()\"\n    cubRippleClass=\"cub-chip-ripple\"\n  >\n    <span CubChipBaseAction [interactive]=\"false\" class=\"cub-chip-label\">\n      <ng-content></ng-content>\n    </span>\n    <span class=\"cub-icon-x cub-chip-icon\"> </span>\n    <span class=\"cub-persistent-ripple cub-chip-persistent-ripple\"></span>\n  </span>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { role: [{
                type: Input
            }], size: [{
                type: Input
            }], id: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaDescription: [{
                type: Input,
                args: ['aria-description']
            }], value: [{
                type: Input
            }], removable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], disableRipple: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], removed: [{
                type: Output
            }], destroyed: [{
                type: Output
            }], leadingIcon: [{
                type: ContentChild,
                args: [CubPrefix]
            }], _allLeadingIcons: [{
                type: ContentChildren,
                args: [CubPrefix, { descendants: true }]
            }], _allRemoveIcons: [{
                type: ContentChildren,
                args: [CubSuffix, { descendants: true }]
            }] } });

/**
 * Basic container component for the CubChipBase component.
 *
 * Extended by CubSelectableChipGroup and CubChipBaseGrid for different interaction patterns.
 */
class CubChipGroupBase {
    /** Whether the chip list contains chips or not. */
    get empty() {
        return !this._chips || this._chips.length === 0;
    }
    /** Whether any of the chips inside of this chip-set has focus. */
    get focused() {
        return this._hasFocusedChip();
    }
    /** Combined stream of all of the child chips' focus events. */
    get chipFocusChanges() {
        return this._getChipStream((chip) => chip._onFocus);
    }
    /** Combined stream of all of the child chips' destroy events. */
    get chipDestroyedChanges() {
        return this._getChipStream((chip) => chip.destroyed);
    }
    /** Combined stream of all of the child chips' remove events. */
    get chipRemovedChanges() {
        return this._getChipStream((chip) => chip.removed);
    }
    /** 元件是否為停用狀態，預設值為 false。 */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = value;
        this._syncChipsState();
    }
    /** 添加 aria-role 的值，預設為 null。 */
    get role() {
        if (this._explicitRole) {
            return this._explicitRole;
        }
        return this.empty ? null : this._defaultRole;
    }
    set role(value) {
        this._explicitRole = value;
    }
    constructor() {
        /** Flat list of all the actions contained within the chips. */
        this._chipActions = new QueryList();
        this._elementRef = inject(ElementRef);
        this._changeDetectorRef = inject(ChangeDetectorRef);
        /** Subject that emits when the component has been destroyed. */
        this._destroyed = new Subject();
        /** Role to use if it hasn't been overwritten by the user. */
        this._defaultRole = 'presentation';
        this._disabled = false;
        this._explicitRole = null;
        this._dir = inject(Directionality, { optional: true });
        /** Index of the last destroyed chip that had focus. */
        this._lastDestroyedFocusedChipIndex = null;
        /**
         *
         * 添加 tabIndex 屬性，預設值為 0。
         */
        this.tabIndex = 0;
    }
    ngAfterViewInit() {
        this._setUpFocusManagement();
        this._trackChipSetChanges();
        this._trackDestroyedFocusedChip();
    }
    ngOnDestroy() {
        this._keyManager?.destroy();
        this._chipActions.destroy();
        this._destroyed.next();
        this._destroyed.complete();
    }
    /** Dummy method for subclasses to override. Base chip set cannot be focused. */
    focus() { }
    /** Handles keyboard events on the chip set. */
    _handleKeydown(event) {
        if (this._originatesFromChip(event)) {
            this._keyManager.onKeydown(event);
        }
    }
    /** Checks whether any of the chips is focused. */
    _hasFocusedChip() {
        return this._chips && this._chips.some((chip) => chip._hasFocus());
    }
    /** Syncs the chip-set's state with the individual chips. */
    _syncChipsState() {
        this._chips?.forEach((chip) => {
            chip._chipListDisabled = this._disabled;
            chip._changeDetectorRef.markForCheck();
        });
    }
    /**
     * Utility to ensure all indexes are valid.
     *
     * @param index The index to be checked.
     * @returns True if the index is valid for our list of chips.
     */
    _isValidIndex(index) {
        return index >= 0 && index < this._chips.length;
    }
    /**
     * Removes the `tabindex` from the chip set and resets it back afterwards, allowing the
     * user to tab out of it. This prevents the set from capturing focus and redirecting
     * it back to the first chip, creating a focus trap, if it user tries to tab away.
     */
    _allowFocusEscape() {
        const previous = this._elementRef.nativeElement.tabIndex;
        if (previous !== -1) {
            // Set the tabindex directly on the element, instead of going through
            // the data binding, because we aren't guaranteed that change detection
            // will run quickly enough to allow focus to escape.
            this._elementRef.nativeElement.tabIndex = -1;
            // Note that this needs to be a `setTimeout`, because a `Promise.resolve`
            // doesn't allow enough time for the focus to escape.
            setTimeout(() => (this._elementRef.nativeElement.tabIndex = previous));
        }
    }
    /**
     * Gets a stream of events from all the chips within the set.
     * The stream will autocubically incorporate any newly-added chips.
     */
    _getChipStream(mappingFunction) {
        return this._chips.changes.pipe(startWith(null), switchMap(() => merge(...this._chips.map(mappingFunction))));
    }
    /** Checks whether an event comes from inside a chip element. */
    _originatesFromChip(event) {
        let currentElement = event.target;
        while (currentElement &&
            currentElement !== this._elementRef.nativeElement) {
            if (currentElement.classList.contains('cub-mdc-chip')) {
                return true;
            }
            currentElement = currentElement.parentElement;
        }
        return false;
    }
    /**
     * Determines if key manager should avoid putting a given chip action in the tab index. Skip
     * non-interactive and disabled actions since the user can't do anything with them.
     */
    _skipPredicate(action) {
        // Skip chips that the user cannot interact with. `cub-chip-group-base` does not permit focusing disabled
        // chips.
        return !action.interactive || action.disabled;
    }
    /** Sets up the chip set's focus management logic. */
    _setUpFocusManagement() {
        // Create a flat `QueryList` containing the actions of all of the chips.
        // This allows us to navigate both within the chip and move to the next/previous
        // one using the existing `ListKeyManager`.
        this._chips.changes
            .pipe(startWith(this._chips))
            .subscribe((chips) => {
            const actions = [];
            chips.forEach((chip) => chip._getActions().forEach((action) => actions.push(action)));
            this._chipActions.reset(actions);
            this._chipActions.notifyOnChanges();
        });
        this._keyManager = new FocusKeyManager(this._chipActions)
            .withVerticalOrientation()
            .withHorizontalOrientation(this._dir ? this._dir.value : 'ltr')
            .withHomeAndEnd()
            .skipPredicate((action) => this._skipPredicate(action));
        // Keep the manager active index in sync so that navigation picks
        // up from the current chip if the user clicks into the list directly.
        this.chipFocusChanges
            .pipe(takeUntil(this._destroyed))
            .subscribe(({ chip }) => {
            const action = chip._getSourceAction(document.activeElement);
            if (action) {
                this._keyManager.updateActiveItem(action);
            }
        });
        this._dir?.change
            .pipe(takeUntil(this._destroyed))
            .subscribe((direction) => this._keyManager.withHorizontalOrientation(direction));
    }
    /** Listens to changes in the chip set and syncs up the state of the individual chips. */
    _trackChipSetChanges() {
        this._chips.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            if (this.disabled) {
                // Since this happens after the content has been
                // checked, we need to defer it to the next tick.
                Promise.resolve().then(() => this._syncChipsState());
            }
            this._redirectDestroyedChipFocus();
        });
    }
    /** Starts tracking the destroyed chips in order to capture the focused one. */
    _trackDestroyedFocusedChip() {
        this.chipDestroyedChanges
            .pipe(takeUntil(this._destroyed))
            .subscribe((event) => {
            const chipArray = this._chips.toArray();
            const chipIndex = chipArray.indexOf(event.chip);
            // If the focused chip is destroyed, save its index so that we can move focus to the next
            // chip. We only save the index here, rather than move the focus immediately, because we want
            // to wait until the chip is removed from the chip list before focusing the next one. This
            // allows us to keep focus on the same index if the chip gets swapped out.
            if (this._isValidIndex(chipIndex) && event.chip._hasFocus()) {
                this._lastDestroyedFocusedChipIndex = chipIndex;
            }
        });
    }
    /**
     * Finds the next appropriate chip to move focus to,
     * if the currently-focused chip is destroyed.
     */
    _redirectDestroyedChipFocus() {
        if (this._lastDestroyedFocusedChipIndex == null) {
            return;
        }
        if (this._chips.length) {
            const newIndex = Math.min(this._lastDestroyedFocusedChipIndex, this._chips.length - 1);
            const chipToFocus = this._chips.toArray()[newIndex];
            if (chipToFocus.disabled) {
                // If we're down to one disabled chip, move focus back to the set.
                if (this._chips.length === 1) {
                    this.focus();
                }
                else {
                    this._keyManager.setPreviousItemActive();
                }
            }
            else {
                chipToFocus.focus();
            }
        }
        else {
            this.focus();
        }
        this._lastDestroyedFocusedChipIndex = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipGroupBase, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "20.3.3", type: CubChipGroupBase, isStandalone: true, selector: "cub-chip-group-base", inputs: { disabled: ["disabled", "disabled", booleanAttribute], role: "role", tabIndex: ["tabIndex", "tabIndex", (value) => (value == null ? 0 : numberAttribute(value))] }, host: { listeners: { "keydown": "_handleKeydown($event)" }, properties: { "attr.role": "role" }, classAttribute: "cub-chip-group-base" }, queries: [{ propertyName: "_chips", predicate: CubChipBase, descendants: true }], ngImport: i0, template: "<div role=\"presentation\">\n  <ng-content></ng-content>\n</div>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipGroupBase, decorators: [{
            type: Component,
            args: [{ selector: 'cub-chip-group-base', host: {
                        class: 'cub-chip-group-base',
                        '(keydown)': '_handleKeydown($event)',
                        '[attr.role]': 'role',
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div role=\"presentation\">\n  <ng-content></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], role: [{
                type: Input
            }], tabIndex: [{
                type: Input,
                args: [{
                        transform: (value) => (value == null ? 0 : numberAttribute(value)),
                    }]
            }], _chips: [{
                type: ContentChildren,
                args: [CubChipBase, {
                        // We need to use `descendants: true`, because Ivy will no longer cubch
                        // indirect descendants if it's left as false.
                        descendants: true,
                    }]
            }] } });

/** Event object emitted by MatChipOption when selected or deselected. */
class CubChipBaseSelectionChange {
    constructor(
    /** Reference to the chip that emitted the event. */
    source, 
    /** Whether the chip that emitted the event is selected. */
    selected, 
    /** Whether the selection change was a result of a user interaction. */
    isUserInput = false) {
        this.source = source;
        this.selected = selected;
        this.isUserInput = isUserInput;
    }
}
/**
 * An extension of the MatChip component that supports chip selection. Used with MatChipListbox.
 *
 * Unlike other chips, the user can focus on disabled chip options inside a MatChipListbox. The
 * user cannot click disabled chips.
 */
class CubSelectableChip extends CubChipBase {
    constructor() {
        super(...arguments);
        /** Whether the chip list is selectable. */
        this.chipListSelectable = true;
        /** Whether the chip list is in multi-selection mode. */
        this._chipListMultiple = false;
        /** Default chip options. */
        this._defaultOptions = inject(CUB_CHIP_DEFAULT_OPTIONS, {
            optional: true,
        });
        // 必須再 _defaultOptions 才能拿到值。
        /** Whether the chip list hides single-selection indicator. */
        this._chipListHideSingleSelectionIndicator = this._defaultOptions?.hideSingleSelectionIndicator ?? false;
        /** The unstyled chip selector for this component. */
        this.basicChipAttrName = 'cub-basic-chip-option';
        this._selectable = true;
        this._selected = false;
        /** 當元件選取狀態改變時送出事件。 */
        this.selectionChange = new EventEmitter();
    }
    /**
     * The ARIA selected applied to the chip. Conforms to WAI ARIA best practices for listbox
     * interaction patterns.
     *
     * From [WAI ARIA Listbox authoring practices guide](
     * https://www.w3.org/WAI/ARIA/apg/patterns/listbox/):
     *  "If any options are selected, each selected option has either aria-selected or aria-checked
     *  set to true. All options that are selectable but not selected have either aria-selected or
     *  aria-checked set to false."
     *
     * Set `aria-selected="false"` on not-selected listbox options that are selectable to fix
     * VoiceOver reading every option as "selected" (#25736).
     */
    get ariaSelected() {
        return this.selectable ? this.selected.toString() : null;
    }
    /**
     * 元件是否能夠被選取，預設值為 true。
     */
    get selectable() {
        return this._selectable && this.chipListSelectable;
    }
    set selectable(value) {
        this._selectable = value;
        this._changeDetectorRef.markForCheck();
    }
    /**
     * 元件目前的選取狀態，預設值為 false。
     */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._setSelectedState(value, false, true);
    }
    ngOnInit() {
        super.ngOnInit();
        this.role = 'presentation';
    }
    _handlePrimaryActionInteraction() {
        if (!this.disabled) {
            // Interacting with the primary action implies that the chip already has focus, however
            // there's a bug in Safari where focus ends up lingering on the previous chip (see #27544).
            // We work around it by explicitly focusing the primary action of the current chip.
            this.focus();
            if (this.selectable) {
                this.toggleSelected(true);
            }
        }
    }
    /** Selects the chip. */
    select() {
        this._setSelectedState(true, false, true);
    }
    /** Deselects the chip. */
    deselect() {
        this._setSelectedState(false, false, true);
    }
    /** Selects this chip and emits userInputSelection event */
    selectViaInteraction() {
        this._setSelectedState(true, true, true);
    }
    /** Toggles the current selected state of this chip. */
    toggleSelected(isUserInput = false) {
        this._setSelectedState(!this.selected, isUserInput, true);
        return this.selected;
    }
    _hasLeadingGraphic() {
        if (this.leadingIcon) {
            return true;
        }
        // The checkmark graphic communicates selected state for both single-select and multi-select.
        // Include checkmark in single-select to fix a11y issue where selected state is communicated
        // visually only using color (#25886).
        return (!this._chipListHideSingleSelectionIndicator || this._chipListMultiple);
    }
    _setSelectedState(isSelected, isUserInput, emitEvent) {
        if (isSelected !== this.selected) {
            this._selected = isSelected;
            if (emitEvent) {
                this.selectionChange.emit({
                    source: this,
                    isUserInput,
                    selected: this.selected,
                });
            }
            this._changeDetectorRef.markForCheck();
        }
    }
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableChip, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubSelectableChip, isStandalone: true, selector: "cub-selectable-chip", inputs: { selectable: ["selectable", "selectable", booleanAttribute], selected: ["selected", "selected", booleanAttribute] }, outputs: { selectionChange: "selectionChange" }, host: { properties: { "class.cub-selected": "selected", "class.cub-disabled": "disabled", "attr.tabindex": "null", "attr.aria-label": "null", "attr.aria-description": "null", "attr.role": "role", "id": "id" }, classAttribute: "cub-selectable-chip" }, providers: [
            { provide: CubChipBase, useExisting: CubSelectableChip },
            { provide: CUB_CHIP, useExisting: CubSelectableChip },
        ], usesInheritance: true, ngImport: i0, template: "<div class=\"cub-selectable-chip-container\">\n  <button\n    CubChipBaseAction\n    [attr.aria-selected]=\"ariaSelected\"\n    [attr.aria-label]=\"ariaLabel\"\n    [attr.aria-describedby]=\"_ariaDescriptionId\"\n    [disabled]=\"disabled\"\n    class=\"cub-selectable-chip-button\"\n    role=\"option\"\n  >\n    @if (_chipListMultiple) {\n      <span class=\"cub-icon-check-small cub-chip-prefix-icon\"></span>\n    }\n    <span class=\"cub-selectable-chip-label\">\n      <ng-content></ng-content>\n    </span>\n  </button>\n</div>\n<span\n  cubRipple\n  cubRippleClass=\"cub-selectable-chip-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span\n  class=\"cub-persistent-ripple cub-selectable-chip-persistent-ripple\"\n></span>\n", styles: [""], dependencies: [{ kind: "directive", type: CubChipBaseAction, selector: "[CubChipBaseAction]", inputs: ["interactive", "disabled", "tabIndex", "allowFocusWhenDisabled"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableChip, decorators: [{
            type: Component,
            args: [{ selector: 'cub-selectable-chip', host: {
                        class: 'cub-selectable-chip',
                        '[class.cub-selected]': 'selected',
                        '[class.cub-disabled]': 'disabled',
                        '[attr.tabindex]': 'null',
                        '[attr.aria-label]': 'null',
                        '[attr.aria-description]': 'null',
                        '[attr.role]': 'role',
                        '[id]': 'id',
                    }, providers: [
                        { provide: CubChipBase, useExisting: CubSelectableChip },
                        { provide: CUB_CHIP, useExisting: CubSelectableChip },
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubChipBaseAction, CubRipple], template: "<div class=\"cub-selectable-chip-container\">\n  <button\n    CubChipBaseAction\n    [attr.aria-selected]=\"ariaSelected\"\n    [attr.aria-label]=\"ariaLabel\"\n    [attr.aria-describedby]=\"_ariaDescriptionId\"\n    [disabled]=\"disabled\"\n    class=\"cub-selectable-chip-button\"\n    role=\"option\"\n  >\n    @if (_chipListMultiple) {\n      <span class=\"cub-icon-check-small cub-chip-prefix-icon\"></span>\n    }\n    <span class=\"cub-selectable-chip-label\">\n      <ng-content></ng-content>\n    </span>\n  </button>\n</div>\n<span\n  cubRipple\n  cubRippleClass=\"cub-selectable-chip-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span\n  class=\"cub-persistent-ripple cub-selectable-chip-persistent-ripple\"\n></span>\n" }]
        }], propDecorators: { selectable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], selected: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], selectionChange: [{
                type: Output
            }] } });

/** Change event object that is emitted when the chip listbox value has changed. */
class CubSelectableChipGroupChange {
    constructor(
    /** Chip listbox that emitted the event. */
    source, 
    /** Value of the chip listbox when the event was emitted. */
    value) {
        this.source = source;
        this.value = value;
    }
}
/**
 * Provider Expression that allows mat-chip-listbox to register as a ControlValueAccessor.
 * This allows it to support [(ngModel)].
 * @docs-private
 */
const CUB_SELECTABLE_CHIP_GROUP_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubSelectableChipGroup),
    multi: true,
};
/**
 * An extension of the MatChipSet component that supports chip selection.
 * Used with MatChipOption chips.
 */
class CubSelectableChipGroup extends CubChipGroupBase {
    constructor() {
        super(...arguments);
        this.breakpointObserver = inject(BreakpointObserver);
        this.windowSizeChange = this.breakpointObserver.observe(['(max-width: 768px)']);
        // TODO: MDC uses `grid` here
        this._defaultRole = 'listbox';
        this._selectable = true;
        this._multiple = false;
        /**
         * 添加 aria-orientation 屬性的值，用於告訴螢幕閱讀器元件排列方向。
         */
        this.ariaOrientation = 'horizontal';
        /**
         * 添加元件的 label， 預設值為 ''。
         */
        this.label = '';
        /**
         * 添加清除按鈕的文字， 預設值為 '清除'。
         */
        this.clearButtonText = '清除';
        /**
         * 是否顯示清除的按鈕，預設值為 false。
         */
        this.showClearButton = false;
        /**
         * 選擇元件的尺寸，預設值為 'medium'。
         */
        this.size = 'medium';
        /**
         * 將選項值與選取值進行比較的函數。第1個參數是來自選項的值。第2個是來自選擇的值需要返回一個布林值。
         */
        this.compareWith = (o1, o2) => o1 === o2;
        /**
         * 此輸入項是否為必填，預設值為 false。
         */
        this.required = false;
        /**
         * 當列表的值被改動時會送出事件。
         */
        this.change = new EventEmitter();
        this._chips = undefined;
        /**
         * Function when touched. Set as part of ControlValueAccessor implementation.
         * @docs-private
         */
        this._onTouched = () => { };
        /**
         * Function when changed. Set as part of ControlValueAccessor implementation.
         * @docs-private
         */
        this._onChange = () => { };
    }
    /** Combined stream of all of the child chips' selection change events. */
    get chipSelectionChanges() {
        return this._getChipStream((chip) => chip.selectionChange);
    }
    /** Combined stream of all of the child chips' blur events. */
    get chipBlurChanges() {
        return this._getChipStream((chip) => chip._onBlur);
    }
    /** The array of selected chips inside the chip listbox. */
    get selected() {
        const selectedChips = this._chips.toArray().filter((chip) => chip.selected);
        return this.multiple ? selectedChips : selectedChips[0];
    }
    /**
     * 是否開放多選，預設值為 false。
     */
    get multiple() {
        return this._multiple;
    }
    set multiple(value) {
        this._multiple = value;
        this._syncListboxProperties();
    }
    /**
     * 元件是否可以被選取，如果不行，底下的chip選取狀態將被忽略，預設值為 true。
     */
    get selectable() {
        return this._selectable;
    }
    set selectable(value) {
        this._selectable = value;
        this._syncListboxProperties();
    }
    /** 元件的值，會與底下被選取的 chip 連動，預設值為 undefined。 */
    get value() {
        return this._value;
    }
    set value(value) {
        if (this._chips && this._chips.length) {
            this._setSelectionByValue(value, false);
        }
        this._value = value;
    }
    // We need an initializer here to avoid a TS error. The value will be set in `ngAfterViewInit`.
    ngAfterContentInit() {
        this._chips.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            if (this.value !== undefined) {
                Promise.resolve().then(() => {
                    this._setSelectionByValue(this.value, false);
                });
            }
            // Update listbox selectable/multiple properties on chips
            this._syncListboxProperties();
        });
        this.chipBlurChanges
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => this._blur());
        this.chipSelectionChanges
            .pipe(takeUntil(this._destroyed))
            .subscribe((event) => {
            if (!this.multiple) {
                this._chips.forEach((chip) => {
                    if (chip !== event.source) {
                        chip._setSelectedState(false, false, false);
                    }
                });
            }
            if (event.isUserInput) {
                this._propagateChanges();
            }
        });
    }
    /**
     * Focuses the first selected chip in this chip listbox, or the first non-disabled chip when there
     * are no selected chips.
     */
    focus() {
        if (this.disabled) {
            return;
        }
        const firstSelectedChip = this._getFirstSelectedChip();
        if (firstSelectedChip && !firstSelectedChip.disabled) {
            firstSelectedChip.focus();
        }
        else if (this._chips.length > 0) {
            this._keyManager.setFirstItemActive();
        }
        else {
            this._elementRef.nativeElement.focus();
        }
    }
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    writeValue(value) {
        if (value != null) {
            this.value = value;
        }
        else {
            this.value = undefined;
        }
    }
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    registerOnChange(fn) {
        this._onChange = fn;
    }
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    /**
     * Implemented as part of ControlValueAccessor.
     * @docs-private
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    /** Selects all chips with value. */
    _setSelectionByValue(value, isUserInput = true) {
        this._clearSelection();
        if (Array.isArray(value)) {
            value.forEach((currentValue) => this._selectValue(currentValue, isUserInput));
        }
        else {
            this._selectValue(value, isUserInput);
        }
    }
    /** When blurred, marks the field as touched when focus moved outside the chip listbox. */
    _blur() {
        if (!this.disabled) {
            // Wait to see if focus moves to an individual chip.
            setTimeout(() => {
                if (!this.focused) {
                    this._markAsTouched();
                }
            });
        }
    }
    _keydown(event) {
        if (event.keyCode === TAB) {
            super._allowFocusEscape();
        }
    }
    clearOptions() {
        for (let chip of this._chips) {
            chip.selected = false;
        }
    }
    /**
     * Determines if key manager should avoid putting a given chip action in the tab index. Skip
     * non-interactive actions since the user can't do anything with them.
     */
    _skipPredicate(action) {
        // Override the skip predicate in the base class to avoid skipping disabled chips. Allow
        // disabled chip options to receive focus to align with WAI ARIA recommendation. Normally WAI
        // ARIA's instructions are to exclude disabled items from the tab order, but it makes a few
        // exceptions for compound widgets.
        //
        // From [Developing a Keyboard Interface](
        // https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/):
        //   "For the following composite widget elements, keep them focusable when disabled: Options in a
        //   Listbox..."
        return !action.interactive;
    }
    /** Marks the field as touched */
    _markAsTouched() {
        this._onTouched();
        this._changeDetectorRef.markForCheck();
    }
    /** Emits change event to set the model value. */
    _propagateChanges() {
        let valueToEmit = null;
        if (Array.isArray(this.selected)) {
            valueToEmit = this.selected.map((chip) => chip.value);
        }
        else {
            valueToEmit = this.selected ? this.selected.value : undefined;
        }
        this._value = valueToEmit;
        this.change.emit(new CubSelectableChipGroupChange(this, valueToEmit));
        this._onChange(valueToEmit);
        this._changeDetectorRef.markForCheck();
    }
    /**
     * Deselects every chip in the listbox.
     * @param skip Chip that should not be deselected.
     */
    _clearSelection(skip) {
        this._chips.forEach((chip) => {
            if (chip !== skip) {
                chip.deselect();
            }
        });
    }
    /**
     * Finds and selects the chip based on its value.
     * @returns Chip that has the corresponding value.
     */
    _selectValue(value, isUserInput) {
        const correspondingChip = this._chips.find((chip) => {
            return chip.value != null && this.compareWith(chip.value, value);
        });
        if (correspondingChip) {
            isUserInput
                ? correspondingChip.selectViaInteraction()
                : correspondingChip.select();
        }
        return correspondingChip;
    }
    /** Syncs the chip-listbox selection state with the individual chips. */
    _syncListboxProperties() {
        if (this._chips) {
            // Defer setting the value in order to avoid the "Expression
            // has changed after it was checked" errors from Angular.
            Promise.resolve().then(() => {
                this._chips.forEach((chip) => {
                    chip._chipListMultiple = this.multiple;
                    chip.chipListSelectable = this._selectable;
                    chip._changeDetectorRef.markForCheck();
                });
            });
        }
    }
    /** Returns the first selected chip in this listbox, or undefined if no chips are selected. */
    _getFirstSelectedChip() {
        if (Array.isArray(this.selected)) {
            return this.selected.length ? this.selected[0] : undefined;
        }
        else {
            return this.selected;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableChipGroup, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubSelectableChipGroup, isStandalone: true, selector: "cub-selectable-chip-group", inputs: { multiple: ["multiple", "multiple", booleanAttribute], ariaOrientation: ["aria-orientation", "ariaOrientation"], label: "label", clearButtonText: "clearButtonText", showClearButton: "showClearButton", size: "size", selectable: ["selectable", "selectable", booleanAttribute], compareWith: "compareWith", required: ["required", "required", booleanAttribute], value: "value" }, outputs: { change: "change" }, host: { listeners: { "focus": "focus()", "blur": "_blur()", "keydown": "_keydown($event)" }, properties: { "attr.role": "role", "tabIndex": "(disabled || empty) ? -1 : tabIndex", "attr.aria-required": "role ? required : null", "attr.aria-disabled": "disabled.toString()", "attr.aria-multiselectable": "multiple", "attr.aria-orientation": "ariaOrientation", "class.cub-chip-small": "size === \"small\"" } }, providers: [CUB_SELECTABLE_CHIP_GROUP_VALUE_ACCESSOR], queries: [{ propertyName: "_chips", predicate: CubSelectableChip, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div class=\"cub-selectable-chip-group\" role=\"presentation\">\n  <ng-content></ng-content>\n  @if(showClearButton && !(windowSizeChange | async)?.matches) {\n  <ng-container *ngTemplateOutlet=\"clearButtonTemplate\"></ng-container>\n  }\n</div>\n@if(showClearButton && (windowSizeChange | async)?.matches) {\n<ng-container *ngTemplateOutlet=\"clearButtonTemplate\"></ng-container>\n}\n\n<ng-template #clearButtonTemplate>\n  <span class=\"cub-selectable-chip-group-clear-button\">\n    <button\n      tabindex=\"0\"\n      cub-button\n      appearance=\"plain\"\n      [size]=\"size\"\n      (click)=\"clearOptions()\"\n    >\n      {{ clearButtonText }}\n    </button>\n  </span>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableChipGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-selectable-chip-group', host: {
                        '[attr.role]': 'role',
                        '[tabIndex]': '(disabled || empty) ? -1 : tabIndex',
                        '[attr.aria-required]': 'role ? required : null',
                        '[attr.aria-disabled]': 'disabled.toString()',
                        '[attr.aria-multiselectable]': 'multiple',
                        '[attr.aria-orientation]': 'ariaOrientation',
                        '[class.cub-chip-small]': 'size === "small"',
                        '(focus)': 'focus()',
                        '(blur)': '_blur()',
                        '(keydown)': '_keydown($event)',
                    }, providers: [CUB_SELECTABLE_CHIP_GROUP_VALUE_ACCESSOR], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, CubButton, AsyncPipe], template: "<div class=\"cub-selectable-chip-group\" role=\"presentation\">\n  <ng-content></ng-content>\n  @if(showClearButton && !(windowSizeChange | async)?.matches) {\n  <ng-container *ngTemplateOutlet=\"clearButtonTemplate\"></ng-container>\n  }\n</div>\n@if(showClearButton && (windowSizeChange | async)?.matches) {\n<ng-container *ngTemplateOutlet=\"clearButtonTemplate\"></ng-container>\n}\n\n<ng-template #clearButtonTemplate>\n  <span class=\"cub-selectable-chip-group-clear-button\">\n    <button\n      tabindex=\"0\"\n      cub-button\n      appearance=\"plain\"\n      [size]=\"size\"\n      (click)=\"clearOptions()\"\n    >\n      {{ clearButtonText }}\n    </button>\n  </span>\n</ng-template>\n" }]
        }], propDecorators: { multiple: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], ariaOrientation: [{
                type: Input,
                args: ['aria-orientation']
            }], label: [{
                type: Input,
                args: ['label']
            }], clearButtonText: [{
                type: Input
            }], showClearButton: [{
                type: Input
            }], size: [{
                type: Input
            }], selectable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], compareWith: [{
                type: Input
            }], required: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], value: [{
                type: Input
            }], change: [{
                type: Output
            }], _chips: [{
                type: ContentChildren,
                args: [CubSelectableChip, {
                        // We need to use `descendants: true`, because Ivy will no longer match
                        // indirect descendants if it's left as false.
                        descendants: true,
                    }]
            }] } });

/** Event object emitted by CubInputChip when selected or deselected. */
class CubInputChipSelectionChange {
    constructor(
    /** Reference to the chip that emitted the event. */
    source, 
    /** Whether the chip that emitted the event is selected. */
    selected, 
    /** Whether the selection change was a result of a user interaction. */
    isUserInput = false) {
        this.source = source;
        this.selected = selected;
        this.isUserInput = isUserInput;
    }
}
/**
 * Injection token that can be used to reference instances of `CubInputChipRemove`. It serves as
 * alternative token to the actual `CubInputChipRemove` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
const CUB_INPUT_CHIP_REMOVE = new InjectionToken('CubInputChipRemove');
// Boilerplate for applying mixins to CubInputChip.
/** @docs-private */
class CubInputChipBase {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}
const _CubInputChipMixinBase = mixinTabIndex(mixinColor(mixinDisableRipple(CubInputChipBase), 'brand'), -1);
/** Material Design styled chip directive. Used inside the CubInputChipList component. */
class CubInputChip extends _CubInputChipMixinBase {
    /**
     * 設定元件的 value， 預設值為 undefined。
     */
    get value() {
        return this._value !== undefined
            ? this._value
            : this._elementRef.nativeElement.textContent;
    }
    set value(value) {
        this._value = value;
    }
    /** 元件是否被停用，預設值為 false。 */
    get disabled() {
        return this._chipListDisabled || this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    /**
     * 元件是否能被刪除，預設值為 true。
     */
    get removable() {
        return this._removable;
    }
    set removable(value) {
        this._removable = coerceBooleanProperty(value);
    }
    /**
     * 設定元件此吋，預設值為 'medium'。
     */
    get size() {
        return this._size;
    }
    set size(value) {
        this._size = value;
    }
    constructor(elementRef, _ngZone, platform, _changeDetectorRef, _document, animationMode, tabIndex) {
        super(elementRef);
        this._ngZone = _ngZone;
        this._changeDetectorRef = _changeDetectorRef;
        /** Whether the chip has focus. */
        this._hasFocus = false;
        /** Whether the chip list is selectable */
        this.chipListSelectable = true;
        /** Whether the chip list is in multi-selection mode. */
        this._chipListMultiple = false;
        /** Whether the chip list as a whole is disabled. */
        this._chipListDisabled = false;
        /** Emits when the chip is focused. */
        this._onFocus = new Subject();
        /** Emits when the chip is blurred. */
        this._onBlur = new Subject();
        this._disabled = false;
        this._removable = true;
        this._size = 'medium';
        /**
         * 設定元件 role 屬性名稱，預設值為 'tag'。
         */
        this.role = 'tag';
        /**
         * 元件被選取時送出事件。
         */
        this.selectionChange = new EventEmitter();
        /** 元件實體被移除時送出事件。 */
        this.destroyed = new EventEmitter();
        /** 元件要被刪除時送出事件。 */
        this.removed = new EventEmitter();
        this.tabIndex = tabIndex != null ? parseInt(tabIndex) || -1 : -1;
    }
    ngOnDestroy() {
        this.destroyed.emit({ chip: this });
    }
    /** Toggles the current selected state of this chip. */
    /** Allows for programmatic focusing of the chip. */
    focus() {
        if (!this._hasFocus) {
            this._elementRef.nativeElement.focus();
            this._onFocus.next({ chip: this });
        }
        this._hasFocus = true;
    }
    /**
     * Allows for programmatic removal of the chip. Called by the CubInputChipList when the DELETE or
     * BACKSPACE keys are pressed.
     *
     * Informs any listeners of the removal request. Does not remove the chip from the DOM.
     */
    remove() {
        if (this.removable) {
            this.removed.emit({ chip: this });
        }
    }
    /** Handles click events on the chip. */
    _handleClick(event) {
        if (this.disabled) {
            event.preventDefault();
        }
    }
    /** Handle custom key presses. */
    _handleKeydown(event) {
        if (this.disabled) {
            return;
        }
        switch (event.keyCode) {
            case DELETE$1:
            case BACKSPACE$1:
                // If we are removable, remove the focused chip
                this.remove();
                // Always prevent so page navigation does not occur
                event.preventDefault();
                break;
        }
    }
    _blur() {
        // When animations are enabled, Angular may end up removing the chip from the DOM a little
        // earlier than usual, causing it to be blurred and throwing off the logic in the chip list
        // that moves focus not the next item. To work around the issue, we defer marking the chip
        // as not focused until the next time the zone stabilizes.
        this._ngZone.onStable.pipe(take(1)).subscribe(() => {
            this._ngZone.run(() => {
                this._hasFocus = false;
                this._onBlur.next({ chip: this });
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChip, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.Platform }, { token: i0.ChangeDetectorRef }, { token: DOCUMENT }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: 'tabindex', attribute: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubInputChip, isStandalone: true, selector: "cub-basic-chip, [cub-basic-chip], cub-input-chip, [cub-input-chip]", inputs: { color: "color", tabIndex: "tabIndex", role: "role", value: "value", disabled: "disabled", removable: "removable", size: "size" }, outputs: { selectionChange: "selectionChange", destroyed: "destroyed", removed: "removed" }, host: { listeners: { "click": "_handleClick($event)", "keydown": "_handleKeydown($event)", "focus": "focus()", "blur": "_blur()" }, properties: { "attr.tabindex": "disabled ? null : tabIndex", "attr.role": "role", "class.cub-input-chip-with-avatar": "avatar", "class.cub-input-chip-with-trailing-icon": "trailingIcon || removeIcon", "class.cub-animation-noop-able": "_animationsDisabled", "attr.disabled": "disabled || null", "attr.aria-disabled": "disabled.toString()" }, classAttribute: "cub-input-chip cub-focus-indicator" }, queries: [{ propertyName: "removeIcon", first: true, predicate: CUB_INPUT_CHIP_REMOVE, descendants: true }], exportAs: ["cubChip"], usesInheritance: true, ngImport: i0, template: "<div class=\"cub-input-chip-outter\">\n  <span class=\"cub-input-chip-container\" [class.cub-disabled]=\"disabled\">\n    <span class=\"cub-input-chip-tag-label\">\n      <ng-content></ng-content>\n    </span>\n\n    <button\n      cubChipRemove\n      cub-icon-button\n      appearance=\"plain\"\n      color=\"neutral-light\"\n      [disabled]=\"disabled\"\n      [size]=\"size\"\n    >\n      <span class=\"cub-icon-x\"></span>\n    </button>\n  </span>\n</div>\n", dependencies: [{ kind: "component", type: i0.forwardRef(() => CubIconButton), selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "directive", type: i0.forwardRef(() => CubInputChipRemove), selector: "[cubChipRemove]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChip, decorators: [{
            type: Component,
            args: [{ selector: `cub-basic-chip, [cub-basic-chip], cub-input-chip, [cub-input-chip]`, inputs: ['color', 'tabIndex'], exportAs: 'cubChip', host: {
                        class: 'cub-input-chip cub-focus-indicator',
                        '[attr.tabindex]': 'disabled ? null : tabIndex',
                        '[attr.role]': 'role',
                        '[class.cub-input-chip-with-avatar]': 'avatar',
                        '[class.cub-input-chip-with-trailing-icon]': 'trailingIcon || removeIcon',
                        '[class.cub-animation-noop-able]': '_animationsDisabled',
                        '[attr.disabled]': 'disabled || null',
                        '[attr.aria-disabled]': 'disabled.toString()',
                        '(click)': '_handleClick($event)',
                        '(keydown)': '_handleKeydown($event)',
                        '(focus)': 'focus()',
                        '(blur)': '_blur()',
                    }, imports: [CubIconButton, forwardRef(() => CubInputChipRemove)], template: "<div class=\"cub-input-chip-outter\">\n  <span class=\"cub-input-chip-container\" [class.cub-disabled]=\"disabled\">\n    <span class=\"cub-input-chip-tag-label\">\n      <ng-content></ng-content>\n    </span>\n\n    <button\n      cubChipRemove\n      cub-icon-button\n      appearance=\"plain\"\n      color=\"neutral-light\"\n      [disabled]=\"disabled\"\n      [size]=\"size\"\n    >\n      <span class=\"cub-icon-x\"></span>\n    </button>\n  </span>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.Platform }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }], propDecorators: { role: [{
                type: Input
            }], value: [{
                type: Input
            }], disabled: [{
                type: Input
            }], removable: [{
                type: Input
            }], size: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }], destroyed: [{
                type: Output
            }], removed: [{
                type: Output
            }], removeIcon: [{
                type: ContentChild,
                args: [CUB_INPUT_CHIP_REMOVE]
            }] } });
/**
 * Applies proper (click) support and adds styling for use with the Material Design "cancel" icon
 * available at https://material.io/icons/#ic_cancel.
 *
 * Example:
 *
 *     `<cub-input-chip>
 *       <cub-icon cubChipRemove>cancel</cub-icon>
 *     </cub-input-chip>`
 *
 * You *may* use a custom icon, but you may need to override the `cub-input-chip-remove` positioning
 * styles to properly center the icon within the chip.
 */
class CubInputChipRemove {
    constructor(_parentChip, elementRef) {
        this._parentChip = _parentChip;
        if (elementRef.nativeElement.nodeName === 'BUTTON') {
            elementRef.nativeElement.setAttribute('type', 'button');
        }
    }
    /** Calls the parent chip's public `remove()` method if applicable. */
    _handleClick(event) {
        const parentChip = this._parentChip;
        if (parentChip.removable && !parentChip.disabled) {
            parentChip.remove();
        }
        // We need to stop event propagation because otherwise the event will bubble up to the
        // form field and cause the `onContainerClick` method to be invoked. This method would then
        // reset the focused chip that has been focused after chip removal. Usually the parent
        // the parent click listener of the `CubInputChip` would prevent propagation, but it can happen
        // that the chip is being removed before the event bubbles up.
        event.stopPropagation();
        event.preventDefault();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChipRemove, deps: [{ token: CubInputChip }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubInputChipRemove, isStandalone: true, selector: "[cubChipRemove]", host: { listeners: { "click": "_handleClick($event)" }, classAttribute: "cub-input-chip-remove" }, providers: [
            { provide: CUB_INPUT_CHIP_REMOVE, useExisting: CubInputChipRemove },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChipRemove, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubChipRemove]',
                    host: {
                        class: 'cub-input-chip-remove',
                        '(click)': '_handleClick($event)',
                    },
                    providers: [
                        { provide: CUB_INPUT_CHIP_REMOVE, useExisting: CubInputChipRemove },
                    ],
                }]
        }], ctorParameters: () => [{ type: CubInputChip }, { type: i0.ElementRef }] });

// Boilerplate for applying mixins to CubChipBaseList.
// Boilerplate for applying mixins to CubInputChipList.
/** @docs-private */
const _CubInputChipGroupBase = mixinErrorState(class {
    constructor(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, 
    /**
     * Form control bound to the component.
     * Implemented as part of `MatFormFieldControl`.
     * @docs-private
     */
    ngControl) {
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
        /**
         * Emits whenever the component state changes and should cause the parent
         * form-field to update. Implemented as part of `MatFormFieldControl`.
         * @docs-private
         */
        this.stateChanges = new Subject();
    }
});
// Increasing integer for generating unique ids for chip-list components.
let nextUniqueId$1 = 0;
/** Change event object that is emitted when the chip list value has changed. */
class CubInputChipGroupChange {
    constructor(
    /** Chip list that emitted the event. */
    source, 
    /** Value of the chip list when the event was emitted. */
    value) {
        this.source = source;
        this.value = value;
    }
}
class CubInputChipGroup extends _CubInputChipGroupBase {
    /**
     * 設定元件的 value， 預設值為 'cub-input-chip-group-${nextUniqueId++}'。
     */
    get id() {
        return this._chipInput ? this._chipInput.id : this._uid;
    }
    /** Whether any chips or the cubChipInput inside of this chip-list has focus. */
    get focused() {
        return ((this._chipInput && this._chipInput.focused) || this._hasFocusedChip());
    }
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    get empty() {
        return ((!this._chipInput || this._chipInput.empty) &&
            (!this.chips || this.chips.length === 0));
    }
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    get shouldLabelFloat() {
        return !this.empty || this.focused;
    }
    /** Combined stream of all of the child chips' selection change events. */
    get chipSelectionChanges() {
        return merge(...this.chips.map((chip) => chip.selectionChange));
    }
    /** Combined stream of all of the child chips' focus change events. */
    get chipFocusChanges() {
        return merge(...this.chips.map((chip) => chip._onFocus));
    }
    /** Combined stream of all of the child chips' blur change events. */
    get chipBlurChanges() {
        return merge(...this.chips.map((chip) => chip._onBlur));
    }
    /** Combined stream of all of the child chips' remove change events. */
    get chipRemoveChanges() {
        return merge(...this.chips.map((chip) => chip.destroyed));
    }
    /**
     * 設定元件 role 屬性名稱，預設值為 'chip-group'
     */
    get role() {
        if (this._explicitRole) {
            return this._explicitRole;
        }
        return this.empty ? null : 'chip-group';
    }
    set role(role) {
        this._explicitRole = role;
    }
    /**
     * 是否開放多選，預設值為 false。
     */
    get multiple() {
        return this._multiple;
    }
    set multiple(value) {
        this._multiple = coerceBooleanProperty(value);
        this._syncChipsState();
    }
    /**
     * 將選項值與選取值進行比較的函數。第1個參數是來自選項的值。第2個是來自選擇的值需要返回一個布林值。
     */
    get compareWith() {
        return this._compareWith;
    }
    set compareWith(fn) {
        this._compareWith = fn;
        if (this._selectionModel) {
            // A different comparator means the selection could change.
            this._initializeSelection();
        }
    }
    /**
     * 設定元件的 value， 預設值為 undefined。
     */
    get value() {
        return this._value;
    }
    set value(value) {
        this.writeValue(value);
        this._onChange(value);
        this._value = value;
    }
    /**
     * 是否為必填，用於 formfield，預設值為 fales。
     */
    get required() {
        return (this._required ??
            this.ngControl?.control?.hasValidator(Validators.required) ??
            false);
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
        this.stateChanges.next();
    }
    /**
     * 設定元件的提示字元，預設值為 ''。
     */
    get placeholder() {
        return this._chipInput ? this._chipInput.placeholder : this._placeholder;
    }
    set placeholder(value) {
        this._placeholder = value;
        this.stateChanges.next();
    }
    /**
     * 元件是否為停用狀態，預設值為 false。
     */
    get disabled() {
        return this.ngControl ? !!this.ngControl.disabled : this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        this._syncChipsState();
    }
    /**
     * 設定元件 tabindex 預設值為 0。
     */
    set tabIndex(value) {
        this._userTabIndex = value;
        this._tabIndex = value;
    }
    constructor(_elementRef, _changeDetectorRef, _dir, _parentForm, _parentFormGroup, _defaultErrorStateMatcher, ngControl) {
        super(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl);
        this._elementRef = _elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._dir = _dir;
        /** Uid of the chip list */
        this._uid = `cub-input-chip-group-${nextUniqueId$1++}`;
        /** Tab index for the chip list. */
        this._tabIndex = 0;
        /**
         * User defined tab index.
         * When it is not null, use user defined tab index. Otherwise use _tabIndex
         */
        this._userTabIndex = null;
        /**
         * Implemented as part of MatFormFieldControl.
         * @docs-private
         */
        this.controlType = 'cub-input-chip-group';
        this._disabled = false;
        /**
         * When a chip is destroyed, we store the index of the destroyed chip until the chips
         * query list notifies about the update. This is necessary because we cannot determine an
         * appropriate chip that should receive focus until the array of chips updated completely.
         */
        this._lastDestroyedChipIndex = null;
        /** Subject that emits when the component has been destroyed. */
        this._destroyed = new Subject();
        this._multiple = true;
        /**
         * 設定元件尺寸，預設值為 'medium'。
         */
        this.size = 'medium';
        /**
         * 添加 aria-orientation 屬性的值，用於告訴螢幕閱讀器元件排列方向。
         */
        this.ariaOrientation = 'horizontal';
        /**
         * 當元件有變動時會送出事件。
         */
        this.change = new EventEmitter();
        /**
         * 當值有變動時會送出事件。
         */
        this.valueChange = new EventEmitter();
        /** Function when touched */
        this._onTouched = () => { };
        /** Function when changed */
        this._onChange = () => { };
        this._compareWith = (o1, o2) => o1 === o2;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngAfterContentInit() {
        this._keyManager = new FocusKeyManager$1(this.chips)
            .withWrap()
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withHorizontalOrientation(this._dir ? this._dir.value : 'ltr');
        if (this._dir) {
            this._dir.change
                .pipe(takeUntil(this._destroyed))
                .subscribe((dir) => this._keyManager.withHorizontalOrientation(dir));
        }
        this._keyManager.tabOut.pipe(takeUntil(this._destroyed)).subscribe(() => {
            this._allowFocusEscape();
        });
        // When the list changes, re-subscribe
        this.chips.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            if (this.disabled) {
                // Since this happens after the content has been
                // checked, we need to defer it to the next tick.
                Promise.resolve().then(() => {
                    this._syncChipsState();
                });
            }
            this._resetChips();
            // Reset chips selected/deselected status
            this._initializeSelection();
            // Check to see if we need to update our tab index
            this._updateTabIndex();
            // Check to see if we have a destroyed chip and need to refocus
            this._updateFocusForDestroyedChips();
            this.stateChanges.next();
        });
        this.chips.forEach((chip) => (chip.size = this.size));
    }
    ngOnInit() {
        this._selectionModel = new SelectionModel(this.multiple, undefined, false);
        this.stateChanges.next();
    }
    ngDoCheck() {
        if (this.ngControl) {
            // We need to re-evaluate this on every change detection cycle, because there are some
            // error triggers that we can't subscribe to (e.g. parent form submissions). This means
            // that whatever logic is in here has to be super lean or we risk destroying the performance.
            this.updateErrorState();
            if (this.ngControl.disabled !== this._disabled) {
                this.disabled = !!this.ngControl.disabled;
            }
        }
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
        this.stateChanges.complete();
        this._dropSubscriptions();
    }
    /** Associates an HTML input element with this chip list. */
    registerInput(inputElement) {
        this._chipInput = inputElement;
        // We use this attribute to cubch the chip list to its input in test harnesses.
        // Set the attribute directly here to avoid "changed after checked" errors.
        this._elementRef.nativeElement.setAttribute('data-cub-input-chip-input', inputElement.id);
    }
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    setDescribedByIds(ids) {
        if (ids.length) {
            this._elementRef.nativeElement.setAttribute('aria-describedby', ids.join(' '));
        }
        else {
            this._elementRef.nativeElement.removeAttribute('aria-describedby');
        }
    }
    // Implemented as part of ControlValueAccessor.
    writeValue(value) {
        if (this.chips) {
            this._setSelectionByValue(value, false);
        }
    }
    // Implemented as part of ControlValueAccessor.
    registerOnChange(fn) {
        this._onChange = fn;
    }
    // Implemented as part of ControlValueAccessor.
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    // Implemented as part of ControlValueAccessor.
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this.stateChanges.next();
    }
    /**
     * Implemented as part of MatFormFieldControl.
     * @docs-private
     */
    onContainerClick(event) {
        if (!this._originatesFromChip(event)) {
            this.focus();
        }
    }
    /**
     * Focuses the first non-disabled chip in this chip list, or the associated input when there
     * are no eligible chips.
     */
    focus(options) {
        if (this.disabled) {
            return;
        }
        // TODO: ARIA says this should focus the first `selected` chip if any are selected.
        // Focus on first element if there's no chipInput inside chip-list
        if (this._chipInput && this._chipInput.focused) {
            // do nothing
        }
        else if (this.chips.length > 0) {
            this._keyManager.setFirstItemActive();
            this.stateChanges.next();
        }
        else {
            this._focusInput(options);
            this.stateChanges.next();
        }
    }
    /** Attempt to focus an input if we have one. */
    _focusInput(options) {
        if (this._chipInput) {
            this._chipInput.focus(options);
        }
    }
    /**
     * Pass events to the keyboard manager. Available here for tests.
     */
    _keydown(event) {
        const target = event.target;
        if (target && target.classList.contains('cub-input-chip')) {
            this._keyManager.onKeydown(event);
            this.stateChanges.next();
        }
    }
    _setSelectionByValue(value, isUserInput = true) {
        if (Array.isArray(value)) {
            value.forEach((currentValue) => this._selectValue(currentValue, isUserInput));
        }
        else {
            const correspondingChip = this._selectValue(value, isUserInput);
            // Shift focus to the active item. Note that we shouldn't do this in multiple
            // mode, because we don't know what chip the user interacted with last.
            if (correspondingChip) {
                if (isUserInput) {
                    this._keyManager.setActiveItem(correspondingChip);
                }
            }
        }
    }
    /** When blurred, mark the field as touched when focus moved outside the chip list. */
    _blur() {
        if (!this._hasFocusedChip()) {
            this._keyManager.setActiveItem(-1);
        }
        if (!this.disabled) {
            if (this._chipInput) {
                // If there's a chip input, we should check whether the focus moved to chip input.
                // If the focus is not moved to chip input, mark the field as touched. If the focus moved
                // to chip input, do nothing.
                // Timeout is needed to wait for the focus() event trigger on chip input.
                setTimeout(() => {
                    if (!this.focused) {
                        this._markAsTouched();
                    }
                });
            }
            else {
                // If there's no chip input, then mark the field as touched.
                this._markAsTouched();
            }
        }
    }
    /** Mark the field as touched */
    _markAsTouched() {
        this._onTouched();
        this._changeDetectorRef.markForCheck();
        this.stateChanges.next();
    }
    /**
     * Removes the `tabindex` from the chip list and resets it back afterwards, allowing the
     * user to tab out of it. This prevents the list from capturing focus and redirecting
     * it back to the first chip, creating a focus trap, if it user tries to tab away.
     */
    _allowFocusEscape() {
        if (this._tabIndex !== -1) {
            this._tabIndex = -1;
            setTimeout(() => {
                this._tabIndex = this._userTabIndex || 0;
                this._changeDetectorRef.markForCheck();
            });
        }
    }
    /**
     * Check the tab index as you should not be allowed to focus an empty list.
     */
    _updateTabIndex() {
        // If we have 0 chips, we should not allow keyboard focus
        this._tabIndex = this._userTabIndex || (this.chips.length === 0 ? -1 : 0);
    }
    /**
     * If the amount of chips changed, we need to update the
     * key manager state and focus the next closest chip.
     */
    _updateFocusForDestroyedChips() {
        // Move focus to the closest chip. If no other chips remain, focus the chip-list itself.
        if (this._lastDestroyedChipIndex != null) {
            if (this.chips.length) {
                const newChipIndex = Math.min(this._lastDestroyedChipIndex, this.chips.length - 1);
                this._keyManager.setActiveItem(newChipIndex);
            }
            else {
                this.focus();
            }
        }
        this._lastDestroyedChipIndex = null;
    }
    /**
     * Utility to ensure all indexes are valid.
     *
     * @param index The index to be checked.
     * @returns True if the index is valid for our list of chips.
     */
    _isValidIndex(index) {
        return index >= 0 && index < this.chips.length;
    }
    /**
     * Finds and selects the chip based on its value.
     * @returns Chip that has the corresponding value.
     */
    _selectValue(value, isUserInput = true) {
        const correspondingChip = this.chips.find((chip) => {
            return chip.value != null && this._compareWith(chip.value, value);
        });
        return correspondingChip;
    }
    _initializeSelection() {
        // Defer setting the value in order to avoid the "Expression
        // has changed after it was checked" errors from Angular.
        Promise.resolve().then(() => {
            if (this.ngControl || this._value) {
                this._setSelectionByValue(this.ngControl ? this.ngControl.value : this._value, false);
                this.stateChanges.next();
            }
        });
    }
    _resetChips() {
        this._dropSubscriptions();
        this._listenToChipsFocus();
        this._listenToChipsRemoved();
    }
    _dropSubscriptions() {
        if (this._chipFocusSubscription) {
            this._chipFocusSubscription.unsubscribe();
            this._chipFocusSubscription = null;
        }
        if (this._chipBlurSubscription) {
            this._chipBlurSubscription.unsubscribe();
            this._chipBlurSubscription = null;
        }
        if (this._chipSelectionSubscription) {
            this._chipSelectionSubscription.unsubscribe();
            this._chipSelectionSubscription = null;
        }
        if (this._chipRemoveSubscription) {
            this._chipRemoveSubscription.unsubscribe();
            this._chipRemoveSubscription = null;
        }
    }
    /** Listens to user-generated selection events on each chip. */
    _listenToChipsFocus() {
        this._chipFocusSubscription = this.chipFocusChanges.subscribe((event) => {
            let chipIndex = this.chips.toArray().indexOf(event.chip);
            if (this._isValidIndex(chipIndex)) {
                this._keyManager.updateActiveItem(chipIndex);
            }
            this.stateChanges.next();
        });
        this._chipBlurSubscription = this.chipBlurChanges.subscribe(() => {
            this._blur();
            this.stateChanges.next();
        });
    }
    _listenToChipsRemoved() {
        this._chipRemoveSubscription = this.chipRemoveChanges.subscribe((event) => {
            const chip = event.chip;
            const chipIndex = this.chips.toArray().indexOf(event.chip);
            // In case the chip that will be removed is currently focused, we temporarily store
            // the index in order to be able to determine an appropriate sibling chip that will
            // receive focus.
            if (this._isValidIndex(chipIndex) && chip._hasFocus) {
                this._lastDestroyedChipIndex = chipIndex;
            }
        });
    }
    /** Checks whether an event comes from inside a chip element. */
    _originatesFromChip(event) {
        let currentElement = event.target;
        while (currentElement &&
            currentElement !== this._elementRef.nativeElement) {
            if (currentElement.classList.contains('cub-input-chip')) {
                return true;
            }
            currentElement = currentElement.parentElement;
        }
        return false;
    }
    /** Checks whether any of the chips is focused. */
    _hasFocusedChip() {
        return this.chips && this.chips.some((chip) => chip._hasFocus);
    }
    /** Syncs the list's state with the individual chips. */
    _syncChipsState() {
        if (this.chips) {
            this.chips.forEach((chip) => {
                chip._chipListDisabled = this._disabled;
                chip._chipListMultiple = this.multiple;
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChipGroup, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1$1.Directionality, optional: true }, { token: i2.NgForm, optional: true }, { token: i2.FormGroupDirective, optional: true }, { token: i3.ErrorStateMatcher }, { token: i2.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubInputChipGroup, isStandalone: true, selector: "cub-input-chip-group", inputs: { role: "role", size: "size", ariaDescribedBy: ["aria-describedby", "ariaDescribedBy"], errorStateMatcher: "errorStateMatcher", multiple: "multiple", compareWith: "compareWith", value: "value", required: "required", placeholder: "placeholder", disabled: "disabled", ariaOrientation: ["aria-orientation", "ariaOrientation"], tabIndex: "tabIndex" }, outputs: { change: "change", valueChange: "valueChange" }, host: { listeners: { "focus": "focus()", "blur": "_blur()", "keydown": "_keydown($event)" }, properties: { "attr.tabindex": "disabled ? null : _tabIndex", "attr.aria-required": "role ? required : null", "attr.aria-disabled": "disabled.toString()", "attr.aria-invalid": "errorState", "attr.aria-multiselectable": "multiple", "attr.role": "role", "class.cub-chip-small": "size === \"small\"", "class.cub-input-chip-list-invalid": "errorState", "class.cub-input-chip-list-required": "required", "attr.aria-orientation": "ariaOrientation", "id": "_uid" }, classAttribute: "cub-input-chip-group" }, providers: [{ provide: CubFormFieldControl, useExisting: CubInputChipGroup }], queries: [{ propertyName: "chips", predicate: CubInputChip, descendants: true }], exportAs: ["cubInputChipGroup"], usesInheritance: true, ngImport: i0, template: "<div class=\"cub-input-chip-group-container\" [class.cub-disabled]=\"disabled\">\n  <ng-content></ng-content>\n</div>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChipGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-input-chip-group', exportAs: 'cubInputChipGroup', host: {
                        '[attr.tabindex]': 'disabled ? null : _tabIndex',
                        '[attr.aria-required]': 'role ? required : null',
                        '[attr.aria-disabled]': 'disabled.toString()',
                        '[attr.aria-invalid]': 'errorState',
                        '[attr.aria-multiselectable]': 'multiple',
                        '[attr.role]': 'role',
                        '[class.cub-chip-small]': 'size === "small"',
                        '[class.cub-input-chip-list-invalid]': 'errorState',
                        '[class.cub-input-chip-list-required]': 'required',
                        '[attr.aria-orientation]': 'ariaOrientation',
                        class: 'cub-input-chip-group',
                        '(focus)': 'focus()',
                        '(blur)': '_blur()',
                        '(keydown)': '_keydown($event)',
                        '[id]': '_uid',
                    }, providers: [{ provide: CubFormFieldControl, useExisting: CubInputChipGroup }], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"cub-input-chip-group-container\" [class.cub-disabled]=\"disabled\">\n  <ng-content></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i2.NgForm, decorators: [{
                    type: Optional
                }] }, { type: i2.FormGroupDirective, decorators: [{
                    type: Optional
                }] }, { type: i3.ErrorStateMatcher }, { type: i2.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { role: [{
                type: Input
            }], size: [{
                type: Input
            }], ariaDescribedBy: [{
                type: Input,
                args: ['aria-describedby']
            }], errorStateMatcher: [{
                type: Input
            }], multiple: [{
                type: Input
            }], compareWith: [{
                type: Input
            }], value: [{
                type: Input
            }], required: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], disabled: [{
                type: Input
            }], ariaOrientation: [{
                type: Input,
                args: ['aria-orientation']
            }], tabIndex: [{
                type: Input
            }], change: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], chips: [{
                type: ContentChildren,
                args: [CubInputChip, {
                        // We need to use `descendants: true`, because Ivy will no longer cubch
                        // indirect descendants if it's left as false.
                        descendants: true,
                    }]
            }] } });

// Increasing integer for generating unique ids.
let nextUniqueId = 0;
class CubInputChipControl {
    /** Whether the input is empty. */
    get empty() {
        return !this.inputElement.value;
    }
    /**
     * 註冊用於 chip 的群組，預設值為 undefiend。
     */
    set chipList(value) {
        if (value) {
            this._chipList = value;
            this._chipList.registerInput(this);
        }
    }
    /**
     * 當 input 觸發 blur 事件時，是否該送出，預設值為 false。
     */
    get addOnBlur() {
        return this._addOnBlur;
    }
    set addOnBlur(value) {
        this._addOnBlur = coerceBooleanProperty(value);
    }
    /**
     * 元件是否為停用狀態，預設值為 false。
     */
    get disabled() {
        return this._disabled || (this._chipList && this._chipList.disabled);
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    constructor(_elementRef, _defaultOptions) {
        this._elementRef = _elementRef;
        this._defaultOptions = _defaultOptions;
        /** Whether the control is focused. */
        this.focused = false;
        this._addOnBlur = false;
        this._disabled = false;
        /**
         * 訂定元件用的提示字元，預設值為 ''。
         */
        this.placeholder = '';
        /**
         * 定定元件的 id，預設值為 'cub-input-chip-control-${nextUniqueId++}'。
         */
        this.id = `cub-input-chip-control-${nextUniqueId++}`;
        /**
         * 設定輸入框創建 chip 的 key，預設值為 enter。
         */
        this.separatorKeyCodes = this._defaultOptions.separatorKeyCodes;
        /**
         * 當創建 chip 時送出事件。
         */
        this.chipEnd = new EventEmitter();
        this.inputElement = this._elementRef.nativeElement;
    }
    ngOnChanges() {
        this._chipList.stateChanges.next();
    }
    ngOnDestroy() {
        this.chipEnd.complete();
    }
    ngAfterContentInit() {
        this._focusLastChipOnBackspace = this.empty;
    }
    /** Utility method to make host definition/tests more clear. */
    _keydown(event) {
        if (event) {
            // Allow the user's focus to escape when they're tabbing forward. Note that we don't
            // want to do this when going backwards, because focus should go back to the first chip.
            if (event.keyCode === TAB$1 && !hasModifierKey(event, 'shiftKey')) {
                this._chipList._allowFocusEscape();
            }
            // To prevent the user from accidentally deleting chips when pressing BACKSPACE continuously,
            // We focus the last chip on backspace only after the user has released the backspace button,
            // and the input is empty (see behaviour in _keyup)
            if (event.keyCode === BACKSPACE$1 && this._focusLastChipOnBackspace) {
                this._chipList._keyManager.setLastItemActive();
                event.preventDefault();
                return;
            }
            else {
                this._focusLastChipOnBackspace = false;
            }
        }
        this._emitChipEnd(event);
    }
    /**
     * Pass events to the keyboard manager. Available here for tests.
     */
    _keyup(event) {
        // Allow user to move focus to chips next time he presses backspace
        if (!this._focusLastChipOnBackspace &&
            event.keyCode === BACKSPACE$1 &&
            this.empty) {
            this._focusLastChipOnBackspace = true;
            event.preventDefault();
        }
    }
    /** Checks to see if the blur should emit the (chipEnd) event. */
    _blur() {
        if (this.addOnBlur) {
            this._emitChipEnd();
        }
        this.focused = false;
        // Blur the chip list if it is not focused
        if (!this._chipList.focused) {
            this._chipList._blur();
        }
        this._chipList.stateChanges.next();
    }
    _focus() {
        this.focused = true;
        this._focusLastChipOnBackspace = this.empty;
        this._chipList.stateChanges.next();
    }
    /** Checks to see if the (chipEnd) event needs to be emitted. */
    _emitChipEnd(event) {
        if (!this.inputElement.value && !!event) {
            this._chipList._keydown(event);
        }
        if (!event || this._isSeparatorKey(event)) {
            this.chipEnd.emit({
                input: this.inputElement,
                value: this.inputElement.value,
                chipInput: this,
            });
            event?.preventDefault();
        }
    }
    _onInput() {
        // Let chip list know whenever the value changes.
        this._chipList.stateChanges.next();
    }
    /** Focuses the input. */
    focus(options) {
        this.inputElement.focus(options);
    }
    /** Clears the input */
    clear() {
        this.inputElement.value = '';
        this._focusLastChipOnBackspace = true;
    }
    /** Checks whether a keycode is one of the configured separators. */
    _isSeparatorKey(event) {
        return (!hasModifierKey(event) &&
            new Set(this.separatorKeyCodes).has(event.keyCode));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChipControl, deps: [{ token: i0.ElementRef }, { token: CUB_CHIPS_DEFAULT_OPTIONS }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubInputChipControl, isStandalone: true, selector: "input[cubInputChipFor]", inputs: { chipList: ["cubInputChipFor", "chipList"], addOnBlur: ["cubInputChipAddOnBlur", "addOnBlur"], placeholder: "placeholder", id: "id", disabled: "disabled", separatorKeyCodes: ["cubInputChipSeparatorKeyCodes", "separatorKeyCodes"] }, outputs: { chipEnd: "cubInputChipTokenEnd" }, host: { listeners: { "keydown": "_keydown($event)", "keyup": "_keyup($event)", "blur": "_blur()", "focus": "_focus()", "input": "_onInput()" }, properties: { "id": "id", "attr.disabled": "disabled || null", "attr.placeholder": "placeholder || null", "attr.aria-invalid": "_chipList && _chipList.ngControl ? _chipList.ngControl.invalid : null", "attr.aria-required": "_chipList && _chipList.required || null", "class.cub-disabled": "disabled" }, classAttribute: "cub-input-chip-control" }, exportAs: ["cubInputChipFor"], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputChipControl, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[cubInputChipFor]',
                    exportAs: 'cubInputChipFor',
                    host: {
                        class: 'cub-input-chip-control',
                        '(keydown)': '_keydown($event)',
                        '(keyup)': '_keyup($event)',
                        '(blur)': '_blur()',
                        '(focus)': '_focus()',
                        '(input)': '_onInput()',
                        '[id]': 'id',
                        '[attr.disabled]': 'disabled || null',
                        '[attr.placeholder]': 'placeholder || null',
                        '[attr.aria-invalid]': '_chipList && _chipList.ngControl ? _chipList.ngControl.invalid : null',
                        '[attr.aria-required]': '_chipList && _chipList.required || null',
                        '[class.cub-disabled]': 'disabled',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_CHIPS_DEFAULT_OPTIONS]
                }] }], propDecorators: { chipList: [{
                type: Input,
                args: ['cubInputChipFor']
            }], addOnBlur: [{
                type: Input,
                args: ['cubInputChipAddOnBlur']
            }], placeholder: [{
                type: Input
            }], id: [{
                type: Input
            }], disabled: [{
                type: Input
            }], separatorKeyCodes: [{
                type: Input,
                args: ['cubInputChipSeparatorKeyCodes']
            }], chipEnd: [{
                type: Output,
                args: ['cubInputChipTokenEnd']
            }] } });

const CHIP_DECLARATIONS = [
    CubChipBase,
    CubChipBaseAction,
    CubSelectableChip,
    CubSelectableChipGroup,
    CubInputChipControl,
    CubInputChipRemove,
    CubInputChipGroup,
    CubInputChip,
];
class CubChipModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubChipModule, imports: [CubFormFieldModule, CubLabelModule, CubChipBase,
            CubChipBaseAction,
            CubSelectableChip,
            CubSelectableChipGroup,
            CubInputChipControl,
            CubInputChipRemove,
            CubInputChipGroup,
            CubInputChip], exports: [CubFormFieldModule, CubLabelModule, CubChipBase,
            CubChipBaseAction,
            CubSelectableChip,
            CubSelectableChipGroup,
            CubInputChipControl,
            CubInputChipRemove,
            CubInputChipGroup,
            CubInputChip] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipModule, providers: [CUB_CHIP_DEFAULT_OPTIONS_PROVIDER], imports: [CubFormFieldModule, CubLabelModule, CubSelectableChipGroup,
            CubInputChip, CubFormFieldModule, CubLabelModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubChipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubFormFieldModule, CubLabelModule, ...CHIP_DECLARATIONS],
                    exports: [CubFormFieldModule, CubLabelModule, ...CHIP_DECLARATIONS],
                    providers: [CUB_CHIP_DEFAULT_OPTIONS_PROVIDER],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/chip
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_CHIP, CUB_CHIPS_DEFAULT_OPTIONS, CUB_CHIP_DEFAULT_OPTIONS, CUB_CHIP_DEFAULT_OPTIONS_PROVIDER, CUB_CHIP_REMOVE, CUB_INPUT_CHIP_REMOVE, CUB_SELECTABLE_CHIP_GROUP_VALUE_ACCESSOR, CubChipBase, CubChipBaseAction, CubChipBaseSelectionChange, CubChipGroupBase, CubChipModule, CubInputChip, CubInputChipControl, CubInputChipGroup, CubInputChipGroupChange, CubInputChipRemove, CubInputChipSelectionChange, CubSelectableChip, CubSelectableChipGroup, CubSelectableChipGroupChange };
//# sourceMappingURL=cub-lib-view-rootng-component-chip.mjs.map
