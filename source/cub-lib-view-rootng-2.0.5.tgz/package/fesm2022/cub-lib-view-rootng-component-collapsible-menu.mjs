import * as i0 from '@angular/core';
import { Input, Directive, Injectable, Optional, Inject, ChangeDetectionStrategy, ViewEncapsulation, Component, ViewChild, HostListener, HostBinding, EventEmitter, ViewChildren, Output, NgModule } from '@angular/core';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/router';
import { RouterLink, RouterLinkActive, NavigationEnd } from '@angular/router';
import { BehaviorSubject, Subject, debounceTime, takeUntil, filter, throttleTime } from 'rxjs';
import { CubNavMenuItem, CubNavMenu, CubNavMenuTrigger, CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER } from 'cub-lib-view-rootng/component/nav-menu';
import { CubTooltipTrigger, CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER } from 'cub-lib-view-rootng/component/tooltip';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { ENTER, SPACE } from 'cub-lib-view-rootng/cdk/keycodes';
import { mixinDisabled, mixinDisableRipple, CubPrefix, CubRipple } from 'cub-lib-view-rootng/component/common';
import * as i2 from 'cub-lib-view-rootng/cdk/a11y';
import { trigger, state, transition, style, animate } from '@angular/animations';
import { CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';

class CubCollapsibleMenuCount {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        /** 元件傳入的計數數值，預設值為 0。 */
        this.count = 0;
        /** 元件傳入的計數數值，判斷 0 是否隱藏，預設值為 true。 */
        this.countHidden = true;
        /** 顯示的數值最大值，當超過設定數值時，會以"最大值+"顯示，預設值 99。 */
        this.max = 99;
        this.countElement = this.renderer.createElement('span');
    }
    ngOnInit() {
        this.renderer.addClass(this.countElement, 'cub-collapsible-menu-count');
        this.renderer.appendChild(this.el.nativeElement, this.countElement);
        this.updateRenderedContent(this.count);
    }
    ngOnChanges(changes) {
        if (changes['count'] || changes['max']) {
            this.updateRenderedContent(this.count);
        }
    }
    /* 確認內容是否有超過限制大小 */
    checkRenderedContent(newContent) {
        const value = Number(newContent ?? 0);
        const max = Number(this.max);
        if (max != null && value > max) {
            return `${max}+`;
        }
        return `${value}`;
    }
    /* 更新顯示內容 */
    updateRenderedContent(newContent) {
        // 如果 countHidden 為 true 且 count 為 0，不顯示
        if (this.countHidden && (!newContent || Number(newContent) === 0)) {
            this.countElement.style.display = 'none';
        }
        else {
            this.countElement.style.display = '';
            const newContentNormalized = this.checkRenderedContent(newContent);
            this.countElement.textContent = newContentNormalized;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuCount, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubCollapsibleMenuCount, isStandalone: true, selector: "[cubCollapsibleMenuCount]", inputs: { count: ["cubCollapsibleMenuCount", "count"], countHidden: ["cubCollapsibleMenuCountHidden", "countHidden"], max: ["cubCollapsibleMenuCountMax", "max"] }, exportAs: ["CubCollapsibleMenuCount"], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuCount, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubCollapsibleMenuCount]',
                    exportAs: 'CubCollapsibleMenuCount',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { count: [{
                type: Input,
                args: ['cubCollapsibleMenuCount']
            }], countHidden: [{
                type: Input,
                args: ['cubCollapsibleMenuCountHidden']
            }], max: [{
                type: Input,
                args: ['cubCollapsibleMenuCountMax']
            }] } });

class CubCollapsibleMenuService {
    constructor(_router, _route) {
        this._router = _router;
        this._route = _route;
        /* 頁面刷新時重整 */
        this.refreshMenuEvent = new BehaviorSubject(null);
        this.refreshUrlEvent = new Subject();
        /* 管理選單收合、選取狀態 */
        this.menuItemsSubject = new BehaviorSubject([]);
        this.selectedItemSubject = new BehaviorSubject(null);
        this.expandedItemsSubject = new BehaviorSubject(new Set());
        this.multipleExpandSubject = new BehaviorSubject(false);
        /* 頁面刷新時重整 */
        this.refreshMenuEvent$ = this.refreshMenuEvent.asObservable();
        this.refreshUrlEvent$ = this.refreshUrlEvent.asObservable();
        /* 管理選單收合、選取狀態 */
        this.menuItems$ = this.menuItemsSubject.asObservable();
        this.selectedItem$ = this.selectedItemSubject.asObservable();
        this.expandedItems$ = this.expandedItemsSubject.asObservable();
        this.multipleExpand$ = this.multipleExpandSubject.asObservable();
    }
    /* 更新選單狀態 */
    refreshMenu() {
        this.refreshMenuEvent.next(null);
    }
    /* 刷新網址 */
    refreshUrl(url) {
        this.refreshUrlEvent.next(url);
    }
    /* 設定初始清單 */
    setMenuItems(items) {
        this.menuItemsSubject.next(items);
    }
    /* 設定是否允許複選展開 */
    setMultipleExpand(multiple) {
        this.multipleExpandSubject.next(multiple);
    }
    /* 取得當前複選設定 */
    getMultipleExpand() {
        return this.multipleExpandSubject.value;
    }
    /* 根據當前路由自動選取項目 */
    selectByCurrentRoute() {
        const item = this.findMenuItemByRoute();
        if (item) {
            this.selectItem(item.id);
        }
    }
    /* 根據 ID 取得當前選取項目 */
    findMenuItemById(id) {
        return this.findItemRecursive(this.menuItemsSubject.value, id);
    }
    /* 根據選取項目取得父層項目路徑 */
    getParentPath(targetId) {
        return this.findPathRecursive(this.menuItemsSubject.value, targetId) || [];
    }
    /* 根據路由配對比對出對應的選取項目 */
    findMenuItemByRoute() {
        return this.findByRouteRecursive(this.menuItemsSubject.value);
    }
    /* 選取項目並展開父層 */
    selectItem(id) {
        const item = this.findMenuItemById(id);
        if (item) {
            this.selectedItemSubject.next(item);
            this.expandParents(id);
        }
    }
    /* 取得當前選取的項目 */
    getSelectedItem() {
        return this.selectedItemSubject.value;
    }
    /* 切換節點展開狀態 */
    toggleExpanded(id) {
        const isMultiple = this.multipleExpandSubject.value;
        const expandedIds = new Set(this.expandedItemsSubject.value);
        const targetItem = this.findMenuItemById(id);
        if (!targetItem)
            return;
        // 如果目標項目有子選項
        if (targetItem.children && targetItem.children.length > 0) {
            if (expandedIds.has(id)) {
                // 收合目標項目
                expandedIds.delete(id);
            }
            else {
                // 展開目標項目
                expandedIds.add(id);
                // 非複選模式下，關閉同層其他有子選項的項目
                if (!isMultiple) {
                    this.closeSiblingExpandedItems(id, expandedIds);
                }
            }
        }
        // 如果目標項目沒有子選項，在非複選模式下不執行任何操作
        this.expandedItemsSubject.next(expandedIds);
    }
    /* 重置選取狀態 */
    clearSelection() {
        this.selectedItemSubject.next(null);
    }
    /* 檢查項目是否展開 */
    isExpanded(id) {
        return this.expandedItemsSubject.value.has(id);
    }
    /* 檢查項目是否選取 */
    isSelected(id) {
        const selected = this.selectedItemSubject.value;
        return selected ? selected.id === id : false;
    }
    /* 檢查項目是否為當前激活的路由 */
    isActive(id) {
        const item = this.findMenuItemById(id);
        return item ? this.isRouterActive(item) : false;
    }
    /* 遞迴：根據 ID 取得當前選取項目 */
    findItemRecursive(items, id) {
        for (const item of items) {
            if (item.id === id) {
                return item;
            }
            if (item.children) {
                const found = this.findItemRecursive(item.children, id);
                if (found)
                    return found;
            }
        }
        return null;
    }
    /* 遞迴：根據選取項目取得父層項目路徑 */
    findPathRecursive(items, targetId, path = []) {
        for (const item of items) {
            const currentPath = [...path, item];
            if (item.id === targetId) {
                return currentPath;
            }
            if (item.children) {
                const found = this.findPathRecursive(item.children, targetId, currentPath);
                if (found)
                    return found;
            }
        }
        return null;
    }
    /* 遞迴：根據路由配對比對出對應的選取項目 */
    findByRouteRecursive(items) {
        for (const item of items) {
            if (this.isRouterActive(item)) {
                return item;
            }
            if (item.children) {
                const found = this.findByRouteRecursive(item.children);
                if (found)
                    return found;
            }
        }
        return null;
    }
    /* 展開父層節點 */
    expandParents(targetId) {
        const parentPath = this.getParentPath(targetId);
        const expandedIds = new Set(this.expandedItemsSubject.value);
        // 展開所有父層節點（除了目標節點本身）
        parentPath.slice(0, -1).forEach((parent) => {
            expandedIds.add(parent.id);
        });
        this.expandedItemsSubject.next(expandedIds);
    }
    /* 取得同層項目 */
    getSiblingItems(targetId) {
        const parentPath = this.getParentPath(targetId);
        // 如果是根層項目
        if (parentPath.length <= 1) {
            return this.menuItemsSubject.value;
        }
        // 如果是子項目，取得父項目的子選項
        const parent = parentPath[parentPath.length - 2];
        return parent.children || [];
    }
    /* 關閉同層其他展開的項目（僅限有子選項的項目） */
    closeSiblingExpandedItems(targetId, expandedIds) {
        const siblings = this.getSiblingItems(targetId);
        siblings.forEach((sibling) => {
            // 只關閉有子選項的同層項目
            if (sibling.children &&
                sibling.children.length > 0 &&
                sibling.id !== targetId) {
                expandedIds.delete(sibling.id);
                // 關閉該項目的所有子項目
                this.closeAllExpandedSubitems(sibling, expandedIds);
            }
        });
    }
    /* 遞迴：關閉該項目的所有子項目 */
    closeAllExpandedSubitems(item, expandedIds) {
        if (item.children) {
            item.children.forEach((child) => {
                expandedIds.delete(child.id);
                this.closeAllExpandedSubitems(child, expandedIds);
            });
        }
    }
    /* 依據路由判斷是否被選取 */
    isRouterActive(item) {
        if (!item.routerLink) {
            return false;
        }
        const exact = item.routerLinkActiveOptions
            ? item.routerLinkActiveOptions.exact
            : false;
        const urlTree = this._router
            .createUrlTree([item.routerLink], {
            queryParams: item.queryParams,
            relativeTo: this._route,
        })
            .toString();
        return this._router.isActive(urlTree, exact);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuService, deps: [{ token: i1.Router }, { token: i1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.Router }, { type: i1.ActivatedRoute }] });

const _CubCollapsibleMenuInlineItemMixinBase = mixinDisabled(mixinDisableRipple(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}));
class CubCollapsibleMenuInlineItem extends _CubCollapsibleMenuInlineItemMixinBase {
    get spacingText() {
        const length = this.level;
        if (length <= 0)
            return '';
        return this.indentCharacter.repeat(length);
    }
    constructor(elementRef, CollapsibleMenuService, _focusMonitor, _changeDetectorRef, _animationMode, _ngZone) {
        super(elementRef);
        this.CollapsibleMenuService = CollapsibleMenuService;
        this._focusMonitor = _focusMonitor;
        this._changeDetectorRef = _changeDetectorRef;
        this._animationMode = _animationMode;
        this._ngZone = _ngZone;
        this._expanded = false;
        this._selected = false;
        this.indentCharacter = '中';
        this._destroyed = new Subject();
        this.level = 0;
        this._haltDisabledEvents = (event) => {
            if (this.disabled) {
                event.preventDefault();
                event.stopImmediatePropagation();
                return;
            }
        };
        this._KeyboardHaltDisabledEvents = (event) => {
            if (event.keyCode === ENTER || event.keyCode === SPACE) {
                this._haltDisabledEvents(event);
            }
        };
    }
    ngAfterViewInit() {
        /* 更新選取狀態 */
        this.CollapsibleMenuService.selectedItem$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe(() => {
            const selected = this.isSelected();
            if (this._selected !== selected) {
                this._selected = selected;
                this._changeDetectorRef.markForCheck();
            }
        });
        /* 更新收合狀態 For Toggle Icon */
        this.CollapsibleMenuService.expandedItems$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe(() => {
            const expanded = this.isExpanded();
            if (this._expanded !== expanded) {
                this._expanded = expanded;
                this._changeDetectorRef.markForCheck();
            }
        });
        this._monitorFocus();
        if (this._ngZone) {
            this._ngZone.runOutsideAngular(() => {
                this._elementRef.nativeElement.addEventListener('click', this._haltDisabledEvents);
                this._elementRef.nativeElement.addEventListener('keydown', this._KeyboardHaltDisabledEvents);
            });
        }
        else {
            this._elementRef.nativeElement.addEventListener('click', this._haltDisabledEvents);
            this._elementRef.nativeElement.addEventListener('keydown', this._KeyboardHaltDisabledEvents);
        }
    }
    ngOnDestroy() {
        this._stopFocusMonitoring();
        this._elementRef.nativeElement.removeEventListener('click', this._haltDisabledEvents);
        this._elementRef.nativeElement.removeEventListener('keydown', this._KeyboardHaltDisabledEvents);
    }
    isSelected() {
        return this.CollapsibleMenuService.isSelected(this.item.id);
    }
    isExpanded() {
        return this.CollapsibleMenuService.isExpanded(this.item.id);
    }
    focus(origin, options) {
        if (origin) {
            this._focusMonitor.focusVia(this._getHostElement(), origin, options);
        }
        else {
            this._getHostElement().focus(options);
        }
    }
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    _hasHostAttributes(...attributes) {
        return attributes.some((attribute) => this._getHostElement().hasAttribute(attribute));
    }
    _monitorFocus() {
        this._focusMonitor.monitor(this._elementRef, true);
    }
    _stopFocusMonitoring() {
        this._focusMonitor.stopMonitoring(this._elementRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuInlineItem, deps: [{ token: i0.ElementRef }, { token: CubCollapsibleMenuService }, { token: i2.FocusMonitor }, { token: i0.ChangeDetectorRef }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: i0.NgZone, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCollapsibleMenuInlineItem, isStandalone: true, selector: "[cubCollapsibleMenuInlineItem]", inputs: { disableRipple: "disableRipple", item: ["cubCollapsibleMenuInlineItem", "item"], level: ["cubCollapsibleMenuInlineItemLevel", "level"], itemTemplateRef: ["cubCollapsibleMenuInlineItemTemplateRef", "itemTemplateRef"] }, host: { properties: { "id": "item.id || null", "attr.tabindex": "item.disabled ? -1 : item.tabIndex || 0", "attr.disabled": "item.disabled || null", "attr.aria-disabled": "item.disabled", "class.cub-disabled": "item.disabled || null", "class.cub-selected": "_selected" }, classAttribute: "cub-collapsible-menu-item cub-focus-indicator" }, exportAs: ["cubCollapsibleMenuInlineItem"], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-collapsible-menu-item-wrapper\">\n  <span\n    cubPrefix\n    class=\"cub-collapsible-menu-item-icon\"\n    [ngClass]=\"item.icon\"\n  ></span>\n\n  <span\n    class=\"cub-collapsible-menu-item-content\"\n    [cubCollapsibleMenuCount]=\"item.count || 0\"\n  >\n    <span class=\"cub-collapsible-menu-item-text\">\n      <span class=\"cub-collapsible-menu-item-spacer\" aria-hidden=\"true\">{{\n        spacingText\n      }}</span>\n      <ng-container\n        *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n      ></ng-container>\n    </span>\n  </span>\n\n  @if(item.children && item.children.length > 0) {\n  <svg\n    xmlns=\"http://www.w3.org/2000/svg\"\n    xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n    width=\"16\"\n    height=\"24\"\n    viewBox=\"0 0 16 24\"\n    class=\"cub-collapsible-menu-item-toggle\"\n    [class.cub-expanded]=\"_expanded\"\n  >\n    <defs>\n      <clipPath id=\"clip-path\">\n        <rect\n          id=\"Rectangle_5004\"\n          data-name=\"Rectangle 5004\"\n          width=\"16\"\n          height=\"24\"\n          transform=\"translate(8)\"\n          fill=\"none\"\n        />\n      </clipPath>\n    </defs>\n    <g id=\"arorw_down_outlined\" transform=\"translate(-8)\">\n      <g id=\"Group_23046\" data-name=\"Group 23046\">\n        <g id=\"Group_23045\" data-name=\"Group 23045\" clip-path=\"url(#clip-path)\">\n          <path\n            id=\"Path_3545\"\n            data-name=\"Path 3545\"\n            d=\"M11.995,14.746a.822.822,0,0,1-.3-.053.792.792,0,0,1-.268-.183L7.041,10.121a.509.509,0,0,1-.15-.344.472.472,0,0,1,.15-.364.474.474,0,0,1,.708,0l4.246,4.246,4.246-4.246a.5.5,0,0,1,.344-.149.468.468,0,0,1,.364.149.474.474,0,0,1,0,.708L12.56,14.51a.779.779,0,0,1-.267.183.822.822,0,0,1-.3.053\"\n            transform=\"translate(4.109)\"\n            fill=\"gray\"\n          />\n        </g>\n      </g>\n    </g>\n  </svg>\n  }\n</span>\n\n<span\n  cubRipple\n  cubRippleClass=\"cub-collapsible-menu-ripple\"\n  [cubRippleDisabled]=\"disableRipple || item.disabled || false\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span\n  class=\"cub-persistent-ripple cub-collapsible-menu-persistent-ripple\"\n></span>\n", styles: [""], dependencies: [{ kind: "directive", type: CubPrefix, selector: "[cubPrefix]" }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: CubCollapsibleMenuCount, selector: "[cubCollapsibleMenuCount]", inputs: ["cubCollapsibleMenuCount", "cubCollapsibleMenuCountHidden", "cubCollapsibleMenuCountMax"], exportAs: ["CubCollapsibleMenuCount"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuInlineItem, decorators: [{
            type: Component,
            args: [{ selector: `[cubCollapsibleMenuInlineItem]`, exportAs: 'cubCollapsibleMenuInlineItem', host: {
                        class: 'cub-collapsible-menu-item cub-focus-indicator',
                        '[id]': 'item.id || null',
                        '[attr.tabindex]': 'item.disabled ? -1 : item.tabIndex || 0',
                        '[attr.disabled]': 'item.disabled || null',
                        '[attr.aria-disabled]': 'item.disabled',
                        '[class.cub-disabled]': 'item.disabled || null',
                        '[class.cub-selected]': '_selected',
                    }, inputs: ['disableRipple'], imports: [
                        CubPrefix,
                        NgClass,
                        CubCollapsibleMenuCount,
                        NgTemplateOutlet,
                        CubRipple,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"cub-collapsible-menu-item-wrapper\">\n  <span\n    cubPrefix\n    class=\"cub-collapsible-menu-item-icon\"\n    [ngClass]=\"item.icon\"\n  ></span>\n\n  <span\n    class=\"cub-collapsible-menu-item-content\"\n    [cubCollapsibleMenuCount]=\"item.count || 0\"\n  >\n    <span class=\"cub-collapsible-menu-item-text\">\n      <span class=\"cub-collapsible-menu-item-spacer\" aria-hidden=\"true\">{{\n        spacingText\n      }}</span>\n      <ng-container\n        *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n      ></ng-container>\n    </span>\n  </span>\n\n  @if(item.children && item.children.length > 0) {\n  <svg\n    xmlns=\"http://www.w3.org/2000/svg\"\n    xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n    width=\"16\"\n    height=\"24\"\n    viewBox=\"0 0 16 24\"\n    class=\"cub-collapsible-menu-item-toggle\"\n    [class.cub-expanded]=\"_expanded\"\n  >\n    <defs>\n      <clipPath id=\"clip-path\">\n        <rect\n          id=\"Rectangle_5004\"\n          data-name=\"Rectangle 5004\"\n          width=\"16\"\n          height=\"24\"\n          transform=\"translate(8)\"\n          fill=\"none\"\n        />\n      </clipPath>\n    </defs>\n    <g id=\"arorw_down_outlined\" transform=\"translate(-8)\">\n      <g id=\"Group_23046\" data-name=\"Group 23046\">\n        <g id=\"Group_23045\" data-name=\"Group 23045\" clip-path=\"url(#clip-path)\">\n          <path\n            id=\"Path_3545\"\n            data-name=\"Path 3545\"\n            d=\"M11.995,14.746a.822.822,0,0,1-.3-.053.792.792,0,0,1-.268-.183L7.041,10.121a.509.509,0,0,1-.15-.344.472.472,0,0,1,.15-.364.474.474,0,0,1,.708,0l4.246,4.246,4.246-4.246a.5.5,0,0,1,.344-.149.468.468,0,0,1,.364.149.474.474,0,0,1,0,.708L12.56,14.51a.779.779,0,0,1-.267.183.822.822,0,0,1-.3.053\"\n            transform=\"translate(4.109)\"\n            fill=\"gray\"\n          />\n        </g>\n      </g>\n    </g>\n  </svg>\n  }\n</span>\n\n<span\n  cubRipple\n  cubRippleClass=\"cub-collapsible-menu-ripple\"\n  [cubRippleDisabled]=\"disableRipple || item.disabled || false\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span\n  class=\"cub-persistent-ripple cub-collapsible-menu-persistent-ripple\"\n></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: CubCollapsibleMenuService }, { type: i2.FocusMonitor }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: i0.NgZone, decorators: [{
                    type: Optional
                }] }], propDecorators: { item: [{
                type: Input,
                args: ['cubCollapsibleMenuInlineItem']
            }], level: [{
                type: Input,
                args: ['cubCollapsibleMenuInlineItemLevel']
            }], itemTemplateRef: [{
                type: Input,
                args: ['cubCollapsibleMenuInlineItemTemplateRef']
            }] } });

class CubCollapsibleMenuOverlayContent {
    constructor(CollapsibleMenuService, _changeDetectorRef) {
        this.CollapsibleMenuService = CollapsibleMenuService;
        this._changeDetectorRef = _changeDetectorRef;
    }
    ngOnInit() { }
    openSubMenu(menu) {
        menu.openMenu();
    }
    selectItem(event, item) {
        if (!item.routerLink && item.command) {
            item.command({
                originalEvent: event,
                item,
            });
        }
        else {
            this.CollapsibleMenuService.selectItem(item.id);
        }
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuOverlayContent, deps: [{ token: CubCollapsibleMenuService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCollapsibleMenuOverlayContent, isStandalone: true, selector: "cub-collapsible-menu-overlay-content", inputs: { item: "item", itemTemplateRef: "itemTemplateRef" }, viewQueries: [{ propertyName: "menu", first: true, predicate: ["menu"], descendants: true }], ngImport: i0, template: "<cub-nav-menu #menu size=\"medium\" positionStart=\"after\" positionEnd=\"above\">\n  @for (item of item.children; track item.id) { @if (item.children &&\n  item.children.length > 0) {\n  <button\n    cub-nav-menu-item\n    [cubNavMenuTriggerFor]=\"subMenu.menu\"\n    #parentMenu=\"cubNavMenuTrigger\"\n    (mouseenter)=\"openSubMenu(parentMenu)\"\n    (keydown.enter)=\"openSubMenu(parentMenu)\"\n  >\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </button>\n  <cub-collapsible-menu-overlay-content\n    #subMenu\n    [item]=\"item\"\n    [itemTemplateRef]=\"itemTemplateRef\"\n  ></cub-collapsible-menu-overlay-content>\n  } @else {\n  <button\n    cub-nav-menu-item\n    [routerLink]=\"item.routerLink\"\n    [queryParams]=\"item.queryParams\"\n    [cubTooltip]=\"tooltipTemplate\"\n    [cubTooltipShowDelay]=\"100\"\n    [cubTooltipPosition]=\"'right'\"\n    (click)=\"selectItem($event, item)\"\n    (keydown.enter)=\"selectItem($event, item)\"\n  >\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </button>\n  }\n  <ng-template #tooltipTemplate>\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container> </ng-template\n  >}\n</cub-nav-menu>\n", styles: [""], dependencies: [{ kind: "component", type: CubCollapsibleMenuOverlayContent, selector: "cub-collapsible-menu-overlay-content", inputs: ["item", "itemTemplateRef"] }, { kind: "component", type: CubNavMenuItem, selector: "[cub-nav-menu-item]", inputs: ["disabled", "disableRipple", "exact", "routerLink", "queryParams", "queryParamsHandling", "fragment", "routerLinkActiveOptions"], exportAs: ["cubNavMenuItem"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: CubTooltipTrigger, selector: "[cubTooltip]", inputs: ["cubTooltipShowArrow", "cubTooltipPosition", "cubTooltipPositionAtOrigin", "cubTooltipDisabled", "cubTooltipShowDelay", "cubTooltipHideDelay", "cubTooltipTouchGestures", "cubTooltip", "cubTooltipClass"], exportAs: ["cubTooltip"] }, { kind: "component", type: CubNavMenu, selector: "cub-nav-menu", exportAs: ["cubNavMenu"] }, { kind: "directive", type: CubNavMenuTrigger, selector: "[cubNavMenuTriggerFor]", exportAs: ["cubNavMenuTrigger"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuOverlayContent, decorators: [{
            type: Component,
            args: [{ selector: 'cub-collapsible-menu-overlay-content', imports: [
                        CubNavMenuItem,
                        NgTemplateOutlet,
                        RouterLink,
                        CubTooltipTrigger,
                        CubNavMenu,
                        CubNavMenuTrigger,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<cub-nav-menu #menu size=\"medium\" positionStart=\"after\" positionEnd=\"above\">\n  @for (item of item.children; track item.id) { @if (item.children &&\n  item.children.length > 0) {\n  <button\n    cub-nav-menu-item\n    [cubNavMenuTriggerFor]=\"subMenu.menu\"\n    #parentMenu=\"cubNavMenuTrigger\"\n    (mouseenter)=\"openSubMenu(parentMenu)\"\n    (keydown.enter)=\"openSubMenu(parentMenu)\"\n  >\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </button>\n  <cub-collapsible-menu-overlay-content\n    #subMenu\n    [item]=\"item\"\n    [itemTemplateRef]=\"itemTemplateRef\"\n  ></cub-collapsible-menu-overlay-content>\n  } @else {\n  <button\n    cub-nav-menu-item\n    [routerLink]=\"item.routerLink\"\n    [queryParams]=\"item.queryParams\"\n    [cubTooltip]=\"tooltipTemplate\"\n    [cubTooltipShowDelay]=\"100\"\n    [cubTooltipPosition]=\"'right'\"\n    (click)=\"selectItem($event, item)\"\n    (keydown.enter)=\"selectItem($event, item)\"\n  >\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </button>\n  }\n  <ng-template #tooltipTemplate>\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container> </ng-template\n  >}\n</cub-nav-menu>\n" }]
        }], ctorParameters: () => [{ type: CubCollapsibleMenuService }, { type: i0.ChangeDetectorRef }], propDecorators: { menu: [{
                type: ViewChild,
                args: ['menu']
            }], item: [{
                type: Input
            }], itemTemplateRef: [{
                type: Input
            }] } });

class CubCollapsibleMenuInlineContent {
    get toggleState() {
        return this._expanded
            ? {
                value: 'expanded',
                params: {
                    transitionParams: this._animating ? this.transitionOptions : '0ms',
                    height: '*',
                },
            }
            : {
                value: 'collapsed',
                params: { transitionParams: this.transitionOptions, height: '0' },
            };
    }
    toggleDone() {
        this._animating = false;
    }
    constructor(CollapsibleMenuService, _changeDetectorRef) {
        this.CollapsibleMenuService = CollapsibleMenuService;
        this._changeDetectorRef = _changeDetectorRef;
        this._animating = false;
        this._expanded = false;
        this._destroyed = new Subject();
        /** 展開收合的轉場動畫設定，預設值為 '400ms cubic-bezier(0.86, 0, 0.07, 1)'。 */
        this.transitionOptions = '400ms cubic-bezier(0.86, 0, 0.07, 1)';
        /** 項目的巢狀層級，預設值為 1。 */
        this.level = 1;
    }
    ngOnInit() {
        this.CollapsibleMenuService.expandedItems$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe(() => {
            const expanded = this.isExpanded();
            if (this._expanded !== expanded) {
                this._animating = true;
                this._expanded = expanded;
                this._changeDetectorRef.markForCheck();
            }
        });
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    expandedSubMenu(event, item) {
        this.CollapsibleMenuService.toggleExpanded(item.id);
        this._changeDetectorRef.markForCheck();
    }
    selectItem(event, item) {
        if (!item.routerLink && item.command) {
            item.command({
                originalEvent: event,
                item,
            });
        }
        else {
            this.CollapsibleMenuService.selectItem(item.id);
        }
        this._changeDetectorRef.markForCheck();
    }
    isExpanded() {
        return this.CollapsibleMenuService.isExpanded(this.item.id);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuInlineContent, deps: [{ token: CubCollapsibleMenuService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCollapsibleMenuInlineContent, isStandalone: true, selector: "cub-collapsible-menu-inline-content", inputs: { item: "item", itemTemplateRef: "itemTemplateRef", transitionOptions: "transitionOptions", level: "level" }, host: { listeners: { "@toggleAnimation.done": "toggleDone()" }, properties: { "class.cub-collapsed": "!_expanded", "@toggleAnimation": "this.toggleState" }, classAttribute: "cub-collapsible-menu-inline-content" }, ngImport: i0, template: "<ul class=\"cub-collapsible-menu-list-group\">\n  @for (item of item.children; track item.id) {\n  <li class=\"cub-collapsible-menu-list\">\n    @if (item.children && item.children.length > 0) {\n    <div\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemLevel]=\"level - 1\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"itemTemplateRef\"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"expandedSubMenu($event, item)\"\n      (keydown.enter)=\"expandedSubMenu($event, item)\"\n    ></div>\n    <cub-collapsible-menu-inline-content\n      [item]=\"item\"\n      [itemTemplateRef]=\"itemTemplateRef\"\n      [level]=\"level + 1\"\n    ></cub-collapsible-menu-inline-content>\n    } @else {\n    <a\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemLevel]=\"level - 1\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"itemTemplateRef\"\n      [routerLink]=\"item.routerLink\"\n      [queryParams]=\"item.queryParams\"\n      [routerLinkActive]=\"item.routerLink ? 'cub-selected' : ''\"\n      [routerLinkActiveOptions]=\"\n        item.routerLinkActiveOptions || { exact: false }\n      \"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"selectItem($event, item)\"\n      (keydown.enter)=\"selectItem($event, item)\"\n    ></a>\n    }\n  </li>\n  <ng-template #tooltipTemplate>\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </ng-template>\n  }\n</ul>\n", styles: [""], dependencies: [{ kind: "component", type: CubCollapsibleMenuInlineContent, selector: "cub-collapsible-menu-inline-content", inputs: ["item", "itemTemplateRef", "transitionOptions", "level"] }, { kind: "component", type: CubCollapsibleMenuInlineItem, selector: "[cubCollapsibleMenuInlineItem]", inputs: ["disableRipple", "cubCollapsibleMenuInlineItem", "cubCollapsibleMenuInlineItemLevel", "cubCollapsibleMenuInlineItemTemplateRef"], exportAs: ["cubCollapsibleMenuInlineItem"] }, { kind: "directive", type: CubTooltipTrigger, selector: "[cubTooltip]", inputs: ["cubTooltipShowArrow", "cubTooltipPosition", "cubTooltipPositionAtOrigin", "cubTooltipDisabled", "cubTooltipShowDelay", "cubTooltipHideDelay", "cubTooltipTouchGestures", "cubTooltip", "cubTooltipClass"], exportAs: ["cubTooltip"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], animations: [
            trigger('toggleAnimation', [
                state('collapsed', style({ height: '0' })),
                state('expanded', style({ height: '*' })),
                transition('expanded <=> collapsed', [animate('{{transitionParams}}')]),
                transition('void => *', animate(0)),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuInlineContent, decorators: [{
            type: Component,
            args: [{ selector: 'cub-collapsible-menu-inline-content', host: {
                        class: 'cub-collapsible-menu-inline-content',
                        '[class.cub-collapsed]': '!_expanded',
                    }, animations: [
                        trigger('toggleAnimation', [
                            state('collapsed', style({ height: '0' })),
                            state('expanded', style({ height: '*' })),
                            transition('expanded <=> collapsed', [animate('{{transitionParams}}')]),
                            transition('void => *', animate(0)),
                        ]),
                    ], imports: [
                        CubCollapsibleMenuInlineItem,
                        CubTooltipTrigger,
                        RouterLink,
                        RouterLinkActive,
                        NgTemplateOutlet,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ul class=\"cub-collapsible-menu-list-group\">\n  @for (item of item.children; track item.id) {\n  <li class=\"cub-collapsible-menu-list\">\n    @if (item.children && item.children.length > 0) {\n    <div\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemLevel]=\"level - 1\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"itemTemplateRef\"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"expandedSubMenu($event, item)\"\n      (keydown.enter)=\"expandedSubMenu($event, item)\"\n    ></div>\n    <cub-collapsible-menu-inline-content\n      [item]=\"item\"\n      [itemTemplateRef]=\"itemTemplateRef\"\n      [level]=\"level + 1\"\n    ></cub-collapsible-menu-inline-content>\n    } @else {\n    <a\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemLevel]=\"level - 1\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"itemTemplateRef\"\n      [routerLink]=\"item.routerLink\"\n      [queryParams]=\"item.queryParams\"\n      [routerLinkActive]=\"item.routerLink ? 'cub-selected' : ''\"\n      [routerLinkActiveOptions]=\"\n        item.routerLinkActiveOptions || { exact: false }\n      \"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"selectItem($event, item)\"\n      (keydown.enter)=\"selectItem($event, item)\"\n    ></a>\n    }\n  </li>\n  <ng-template #tooltipTemplate>\n    <ng-container\n      *ngTemplateOutlet=\"itemTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </ng-template>\n  }\n</ul>\n" }]
        }], ctorParameters: () => [{ type: CubCollapsibleMenuService }, { type: i0.ChangeDetectorRef }], propDecorators: { item: [{
                type: Input
            }], itemTemplateRef: [{
                type: Input
            }], transitionOptions: [{
                type: Input
            }], level: [{
                type: Input
            }], toggleState: [{
                type: HostBinding,
                args: ['@toggleAnimation']
            }], toggleDone: [{
                type: HostListener,
                args: ['@toggleAnimation.done']
            }] } });

class CubCollapsibleMenu {
    get labelTemplateRef() {
        return this.itemTemplateRef || this.defaultTemplateRef;
    }
    constructor(_changeDetectorRef, _router, CollapsibleMenuService) {
        this._changeDetectorRef = _changeDetectorRef;
        this._router = _router;
        this.CollapsibleMenuService = CollapsibleMenuService;
        this.currentUrl = '';
        this._destroyed = new Subject();
        /** 導航選單的項目清單，預設值為 []。 */
        this.items = [];
        /** 點選相同路徑刷新頁面時，重新定向所使用的轉導路徑，預設值為 '/'。 */
        this.baseRedirectPath = '/';
        /** 是否可同時展開多個子選單，預設值為 true。 */
        this.multiple = true;
        /** 是否折疊導航選單，預設值為 true。 */
        this.collapsed = true;
        this.itemClick = new EventEmitter();
        /* 開啟重新載入，才會觸發 router.events 事件 */
        this._router.onSameUrlNavigation = 'reload';
        this._router.events
            .pipe(filter((event) => event instanceof NavigationEnd), takeUntil(this._destroyed))
            .subscribe((_) => {
            const url = this._router.url;
            /* 判斷是否跳轉到相同路由 */
            if (this.currentUrl === url) {
                this.CollapsibleMenuService.refreshUrl(url);
            }
            else {
                this.currentUrl = url;
            }
            /* 每次頁面跳轉時更新選單狀態 */
            this.CollapsibleMenuService.refreshMenu();
        });
    }
    ngAfterViewInit() {
        this.CollapsibleMenuService.setMenuItems(this.items);
        this.CollapsibleMenuService.expandedItems$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe(() => {
            this._changeDetectorRef.markForCheck();
        });
        this.CollapsibleMenuService.selectedItem$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe((item) => {
            if (item) {
                this.itemClick.emit(item);
            }
            this._changeDetectorRef.markForCheck();
        });
        this.CollapsibleMenuService.refreshUrlEvent$
            .pipe(throttleTime(1000), takeUntil(this._destroyed))
            .subscribe((url) => {
            this.refreshPage(url);
        });
        this.CollapsibleMenuService.refreshMenuEvent$
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => {
            this.CollapsibleMenuService.selectByCurrentRoute();
            this._changeDetectorRef.markForCheck();
        });
    }
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('items')) {
            this.CollapsibleMenuService.refreshMenu();
            this.CollapsibleMenuService.setMenuItems(this.items);
            this._changeDetectorRef.markForCheck();
        }
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    openSubMenu(menu) {
        this.menuTriggers.forEach((trigger) => {
            if (trigger === menu) {
                trigger.openMenu();
            }
            else {
                trigger.closeMenu();
            }
        });
    }
    expandedSubMenu(event, item) {
        this.CollapsibleMenuService.toggleExpanded(item.id);
        this._changeDetectorRef.markForCheck();
    }
    selectItem(event, item) {
        if (!item.routerLink && item.command) {
            item.command({
                originalEvent: event,
                item,
            });
        }
        else {
            this.CollapsibleMenuService.selectItem(item.id);
        }
        this._changeDetectorRef.markForCheck();
    }
    /* 點選同路由時，透過跳轉首頁模擬重整頁面的效果 */
    refreshPage(url) {
        this._router
            .navigateByUrl(this.baseRedirectPath, { skipLocationChange: true })
            .then(() => {
            this._router.navigateByUrl(`/${url}`).then(() => {
                this.currentUrl = url;
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenu, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.Router }, { token: CubCollapsibleMenuService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubCollapsibleMenu, isStandalone: true, selector: "cub-collapsible-menu", inputs: { items: "items", itemTemplateRef: "itemTemplateRef", baseRedirectPath: "baseRedirectPath", multiple: "multiple", collapsed: "collapsed" }, outputs: { itemClick: "itemClick" }, host: { properties: { "class.cub-collapsed": "collapsed" }, classAttribute: "cub-collapsible-menu" }, viewQueries: [{ propertyName: "defaultTemplateRef", first: true, predicate: ["defaultTemplateRef"], descendants: true }, { propertyName: "menuTriggers", predicate: CubNavMenuTrigger, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<ul class=\"cub-collapsible-menu-list-group\">\n  @for (item of items; track item.id) {\n  <li class=\"cub-collapsible-menu-list\">\n    @if (item.children && item.children.length > 0) { @if (collapsed) {\n    <div\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"labelTemplateRef\"\n      [cubNavMenuTriggerFor]=\"subMenu.menu\"\n      #parentMenu=\"cubNavMenuTrigger\"\n      (mouseenter)=\"openSubMenu(parentMenu)\"\n      (keydown.enter)=\"openSubMenu(parentMenu)\"\n    ></div>\n    <cub-collapsible-menu-overlay-content\n      #subMenu\n      [item]=\"item\"\n      [itemTemplateRef]=\"labelTemplateRef\"\n    ></cub-collapsible-menu-overlay-content>\n    } @else {\n    <div\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"labelTemplateRef\"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"expandedSubMenu($event, item)\"\n      (keydown.enter)=\"expandedSubMenu($event, item)\"\n    ></div>\n    <cub-collapsible-menu-inline-content\n      [item]=\"item\"\n      [itemTemplateRef]=\"labelTemplateRef\"\n    ></cub-collapsible-menu-inline-content>\n    } } @else {\n    <a\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"labelTemplateRef\"\n      [routerLink]=\"item.routerLink\"\n      [queryParams]=\"item.queryParams\"\n      [routerLinkActive]=\"item.routerLink ? 'cub-selected' : ''\"\n      [routerLinkActiveOptions]=\"\n        item.routerLinkActiveOptions || { exact: false }\n      \"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"selectItem($event, item)\"\n      (keydown.enter)=\"selectItem($event, item)\"\n    ></a>\n    }\n  </li>\n\n  <ng-template #tooltipTemplate>\n    <ng-container\n      *ngTemplateOutlet=\"labelTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </ng-template>\n  }\n</ul>\n\n<ng-template #defaultTemplateRef let-item>\n  {{ item.label }}\n</ng-template>\n", styles: [""], dependencies: [{ kind: "component", type: CubCollapsibleMenuInlineItem, selector: "[cubCollapsibleMenuInlineItem]", inputs: ["disableRipple", "cubCollapsibleMenuInlineItem", "cubCollapsibleMenuInlineItemLevel", "cubCollapsibleMenuInlineItemTemplateRef"], exportAs: ["cubCollapsibleMenuInlineItem"] }, { kind: "directive", type: CubNavMenuTrigger, selector: "[cubNavMenuTriggerFor]", exportAs: ["cubNavMenuTrigger"] }, { kind: "component", type: CubCollapsibleMenuOverlayContent, selector: "cub-collapsible-menu-overlay-content", inputs: ["item", "itemTemplateRef"] }, { kind: "directive", type: CubTooltipTrigger, selector: "[cubTooltip]", inputs: ["cubTooltipShowArrow", "cubTooltipPosition", "cubTooltipPositionAtOrigin", "cubTooltipDisabled", "cubTooltipShowDelay", "cubTooltipHideDelay", "cubTooltipTouchGestures", "cubTooltip", "cubTooltipClass"], exportAs: ["cubTooltip"] }, { kind: "component", type: CubCollapsibleMenuInlineContent, selector: "cub-collapsible-menu-inline-content", inputs: ["item", "itemTemplateRef", "transitionOptions", "level"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenu, decorators: [{
            type: Component,
            args: [{ selector: 'cub-collapsible-menu', host: {
                        class: 'cub-collapsible-menu',
                        '[class.cub-collapsed]': 'collapsed',
                    }, imports: [
                        CubCollapsibleMenuInlineItem,
                        CubNavMenuTrigger,
                        CubCollapsibleMenuOverlayContent,
                        CubTooltipTrigger,
                        CubCollapsibleMenuInlineContent,
                        RouterLink,
                        RouterLinkActive,
                        NgTemplateOutlet,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ul class=\"cub-collapsible-menu-list-group\">\n  @for (item of items; track item.id) {\n  <li class=\"cub-collapsible-menu-list\">\n    @if (item.children && item.children.length > 0) { @if (collapsed) {\n    <div\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"labelTemplateRef\"\n      [cubNavMenuTriggerFor]=\"subMenu.menu\"\n      #parentMenu=\"cubNavMenuTrigger\"\n      (mouseenter)=\"openSubMenu(parentMenu)\"\n      (keydown.enter)=\"openSubMenu(parentMenu)\"\n    ></div>\n    <cub-collapsible-menu-overlay-content\n      #subMenu\n      [item]=\"item\"\n      [itemTemplateRef]=\"labelTemplateRef\"\n    ></cub-collapsible-menu-overlay-content>\n    } @else {\n    <div\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"labelTemplateRef\"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"expandedSubMenu($event, item)\"\n      (keydown.enter)=\"expandedSubMenu($event, item)\"\n    ></div>\n    <cub-collapsible-menu-inline-content\n      [item]=\"item\"\n      [itemTemplateRef]=\"labelTemplateRef\"\n    ></cub-collapsible-menu-inline-content>\n    } } @else {\n    <a\n      [cubCollapsibleMenuInlineItem]=\"item\"\n      [cubCollapsibleMenuInlineItemTemplateRef]=\"labelTemplateRef\"\n      [routerLink]=\"item.routerLink\"\n      [queryParams]=\"item.queryParams\"\n      [routerLinkActive]=\"item.routerLink ? 'cub-selected' : ''\"\n      [routerLinkActiveOptions]=\"\n        item.routerLinkActiveOptions || { exact: false }\n      \"\n      [cubTooltip]=\"tooltipTemplate\"\n      [cubTooltipShowDelay]=\"100\"\n      [cubTooltipPosition]=\"'right'\"\n      (click)=\"selectItem($event, item)\"\n      (keydown.enter)=\"selectItem($event, item)\"\n    ></a>\n    }\n  </li>\n\n  <ng-template #tooltipTemplate>\n    <ng-container\n      *ngTemplateOutlet=\"labelTemplateRef; context: { $implicit: item }\"\n    ></ng-container>\n  </ng-template>\n  }\n</ul>\n\n<ng-template #defaultTemplateRef let-item>\n  {{ item.label }}\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.Router }, { type: CubCollapsibleMenuService }], propDecorators: { items: [{
                type: Input
            }], itemTemplateRef: [{
                type: Input
            }], baseRedirectPath: [{
                type: Input
            }], multiple: [{
                type: Input
            }], collapsed: [{
                type: Input
            }], itemClick: [{
                type: Output
            }], defaultTemplateRef: [{
                type: ViewChild,
                args: ['defaultTemplateRef']
            }], menuTriggers: [{
                type: ViewChildren,
                args: [CubNavMenuTrigger]
            }] } });

class CubCollapsibleMenuModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuModule, imports: [CubCollapsibleMenu,
            CubCollapsibleMenuInlineItem,
            CubCollapsibleMenuInlineContent,
            CubCollapsibleMenuOverlayContent,
            CubCollapsibleMenuCount], exports: [CubCollapsibleMenu,
            CubCollapsibleMenuInlineItem,
            CubCollapsibleMenuInlineContent,
            CubCollapsibleMenuOverlayContent,
            CubCollapsibleMenuCount] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER,
            CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubCollapsibleMenu,
            CubCollapsibleMenuOverlayContent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCollapsibleMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCollapsibleMenu,
                        CubCollapsibleMenuInlineItem,
                        CubCollapsibleMenuInlineContent,
                        CubCollapsibleMenuOverlayContent,
                        CubCollapsibleMenuCount,
                    ],
                    exports: [
                        CubCollapsibleMenu,
                        CubCollapsibleMenuInlineItem,
                        CubCollapsibleMenuInlineContent,
                        CubCollapsibleMenuOverlayContent,
                        CubCollapsibleMenuCount,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_NAV_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER,
                        CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/collapsible-menu
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubCollapsibleMenu, CubCollapsibleMenuCount, CubCollapsibleMenuInlineContent, CubCollapsibleMenuInlineItem, CubCollapsibleMenuModule, CubCollapsibleMenuOverlayContent, CubCollapsibleMenuService };
//# sourceMappingURL=cub-lib-view-rootng-component-collapsible-menu.mjs.map
