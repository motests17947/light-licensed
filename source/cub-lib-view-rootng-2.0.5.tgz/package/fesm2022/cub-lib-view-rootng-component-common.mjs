import { coerceBooleanProperty, coerceNumberProperty, coerceElement } from 'cub-lib-view-rootng/cdk/coercion';
import * as i0 from '@angular/core';
import { Input, Directive, NgModule, Injectable, InjectionToken, booleanAttribute, HostBinding, Optional, Inject } from '@angular/core';
import { isFakeMousedownFromScreenReader, isFakeTouchstartFromScreenReader } from 'cub-lib-view-rootng/cdk/a11y';
import { ENTER, SPACE } from 'cub-lib-view-rootng/cdk/keycodes';
import * as i1 from 'cub-lib-view-rootng/cdk/platform';
import { normalizePassiveListenerOptions } from 'cub-lib-view-rootng/cdk/platform';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { Subject } from 'rxjs';

function mixinColor(base, defaultColor) {
    return class extends base {
        /* eslint-enable */
        get color() {
            return this._color;
        }
        set color(value) {
            const colorPalette = value || this.defaultColor;
            if (colorPalette !== this._color) {
                if (this._color) {
                    this._elementRef.nativeElement.classList.remove(`cub-${this._color}`);
                }
                if (colorPalette) {
                    this._elementRef.nativeElement.classList.add(`cub-${colorPalette}`);
                }
                this._color = colorPalette;
            }
        }
        constructor(...args) {
            super(...args);
            this.defaultColor = defaultColor;
            // Set the default color that can be specified from the mixin.
            this.color = defaultColor;
        }
    };
}

function mixinDisableRipple(base) {
    return class extends base {
        /** Whether the ripple effect is disabled or not. */
        get disableRipple() {
            return this._disableRipple;
        }
        set disableRipple(value) {
            this._disableRipple = coerceBooleanProperty(value);
        }
        constructor(...args) {
            super(...args);
            this._disableRipple = false;
        }
    };
}

function mixinDisabled(base) {
    return class extends base {
        get disabled() {
            return this._disabled;
        }
        set disabled(value) {
            this._disabled = coerceBooleanProperty(value);
        }
        constructor(...args) {
            super(...args);
            this._disabled = false;
        }
    };
}

function mixinErrorState(base) {
    return class extends base {
        constructor(...args) {
            super(...args);
            /** Whether the component is in an error state. */
            this.errorState = false;
        }
        /** Updates the error state based on the provided error state matcher. */
        updateErrorState() {
            const oldState = this.errorState;
            const parent = this._parentFormGroup || this._parentForm;
            const matcher = this.errorStateMatcher || this._defaultErrorStateMatcher;
            const control = this.ngControl
                ? this.ngControl.control
                : null;
            const newState = matcher.isErrorState(control, parent);
            if (newState !== oldState) {
                this.errorState = newState;
                this.stateChanges.next();
            }
        }
    };
}

function mixinTabIndex(base, defaultTabIndex = 0) {
    return class extends base {
        /* eslint-enable */
        get tabIndex() {
            return this.disabled ? -1 : this._tabIndex;
        }
        set tabIndex(value) {
            // If the specified tabIndex value is null or undefined, fall back to the default value.
            this._tabIndex =
                value != null ? coerceNumberProperty(value) : this.defaultTabIndex;
        }
        constructor(...args) {
            super(...args);
            /* eslint-disable */
            this._tabIndex = defaultTabIndex;
            this.defaultTabIndex = defaultTabIndex;
        }
    };
}

var DEVICE_BREAKPOINT;
(function (DEVICE_BREAKPOINT) {
    DEVICE_BREAKPOINT[DEVICE_BREAKPOINT["MOBILE"] = 375] = "MOBILE";
    DEVICE_BREAKPOINT[DEVICE_BREAKPOINT["TABLET_PORTRAIT"] = 768] = "TABLET_PORTRAIT";
    DEVICE_BREAKPOINT[DEVICE_BREAKPOINT["TABLET_LANDSCAPE"] = 1024] = "TABLET_LANDSCAPE";
    DEVICE_BREAKPOINT[DEVICE_BREAKPOINT["DESKTOP"] = 1440] = "DESKTOP";
    DEVICE_BREAKPOINT[DEVICE_BREAKPOINT["LARGE_DESKTOP"] = 1920] = "LARGE_DESKTOP";
})(DEVICE_BREAKPOINT || (DEVICE_BREAKPOINT = {}));
var GRID_BREAKPOINT;
(function (GRID_BREAKPOINT) {
    GRID_BREAKPOINT[GRID_BREAKPOINT["SM"] = 576] = "SM";
    GRID_BREAKPOINT[GRID_BREAKPOINT["MD"] = 768] = "MD";
    GRID_BREAKPOINT[GRID_BREAKPOINT["LG"] = 1024] = "LG";
    GRID_BREAKPOINT[GRID_BREAKPOINT["XL"] = 1440] = "XL";
    GRID_BREAKPOINT[GRID_BREAKPOINT["XXL"] = 1920] = "XXL";
})(GRID_BREAKPOINT || (GRID_BREAKPOINT = {}));

/* --- 判斷是否是觸控裝置 --- */
const isMobileDevice = () => {
    const mobileDevices = [
        'Android',
        'webOS',
        'iPhone',
        'iPad',
        'iPod',
        'BlackBerry',
        'Windows Phone',
    ];
    for (var i = 0; i < mobileDevices.length; i++) {
        if (navigator.userAgent.match(mobileDevices[i])) {
            return true;
        }
    }
    return false;
};
/* --- 判斷是否是 IOS 觸控裝置 --- */
const isIOSMobileDevice = () => {
    const mobileDevices = [
        'iPhone',
        'iPad',
        'iPod',
        /* 以下為 IOS 觸控裝置開啟 Safari 進階設定「網頁檢閱器」功能時的 userAgent */
        'Macintosh',
    ];
    for (var i = 0; i < mobileDevices.length; i++) {
        if (navigator.userAgent.match(mobileDevices[i])) {
            return true;
        }
    }
    return false;
};

/* --- 偵測螢幕高度（扣掉觸控裝置下方導航列高） --- */
const setViewHeight = () => {
    const viewHeight = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', viewHeight + 'px');
};
/* --- 偵測螢幕寬度（扣掉卷軸寬）--- */
const setViewWidth = () => {
    const viewWidth = document.documentElement.clientWidth * 0.01;
    document.documentElement.style.setProperty('--vw', viewWidth + 'px');
};

class CubDivider {
    /* 元件樣式，預設值為 'solid'。 */
    get appearance() {
        return this._appearance;
    }
    set appearance(value) {
        this._appearance = value;
    }
    get isVertical() {
        return this.orientation === 'vertical';
    }
    constructor() {
        this._appearance = 'solid';
        /* 元件是否垂直方向，預設值為 'horizontal'。 */
        this.orientation = 'horizontal';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDivider, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDivider, isStandalone: true, selector: "[cubDivider], cub-divider", inputs: { appearance: "appearance", orientation: "orientation" }, host: { attributes: { "role": "separator" }, properties: { "attr.aria-orientation": "orientation", "class.cub-divider-vertical": "isVertical", "class.cub-divider-horizontal": "!isVertical", "style.border-top-style": "isVertical ? \"\" : appearance", "style.border-right-style": "isVertical ? appearance : \"\"" }, classAttribute: "cub-divider" }, exportAs: ["cubDivider"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDivider, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubDivider], cub-divider',
                    exportAs: 'cubDivider',
                    host: {
                        class: 'cub-divider',
                        role: 'separator',
                        '[attr.aria-orientation]': 'orientation',
                        '[class.cub-divider-vertical]': 'isVertical',
                        '[class.cub-divider-horizontal]': '!isVertical',
                        '[style.border-top-style]': 'isVertical ? "" : appearance',
                        '[style.border-right-style]': 'isVertical ? appearance : ""',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { appearance: [{
                type: Input
            }], orientation: [{
                type: Input
            }] } });

class CubDividerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDividerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubDividerModule, imports: [CubDivider], exports: [CubDivider] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDividerModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDividerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubDivider],
                    exports: [CubDivider],
                }]
        }] });

// 該檔案由 PrimeNG v14.2.3 複製而來
/**
 * @dynamic is for runtime initializing DomHandler.browser
 *
 * If delete below comment, we can see this error message:
 *  Metadata collected contains an error that will be reported at runtime:
 *  Only initialized variables and constants can be referenced
 *  because the value of this variable is needed by the template compiler.
 */
// @dynamic
class DomHandler {
    static { this.zindex = 1000; }
    static { this.calculatedScrollbarWidth = null; }
    static { this.calculatedScrollbarHeight = null; }
    static addClass(element, className) {
        if (element && className) {
            if (element.classList)
                element.classList.add(className);
            else
                element.className += ' ' + className;
        }
    }
    static addMultipleClasses(element, className) {
        if (element && className) {
            if (element.classList) {
                let styles = className.trim().split(' ');
                for (let index = 0; index < styles.length; index++) {
                    element.classList.add(styles[index]);
                }
            }
            else {
                let styles = className.split(' ');
                for (let index = 0; index < styles.length; index++) {
                    element.className += ' ' + styles[index];
                }
            }
        }
    }
    static removeClass(element, className) {
        if (element && className) {
            if (element.classList)
                element.classList.remove(className);
            else
                element.className = element.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
        }
    }
    static hasClass(element, className) {
        if (element && className) {
            if (element.classList)
                return element.classList.contains(className);
            else
                return new RegExp('(^| )' + className + '( |$)', 'gi').test(element.className);
        }
        return false;
    }
    static siblings(element) {
        return Array.prototype.filter.call(element.parentNode.children, function (child) {
            return child !== element;
        });
    }
    static find(element, selector) {
        return Array.from(element.querySelectorAll(selector));
    }
    static findSingle(element, selector) {
        if (element) {
            return element.querySelector(selector);
        }
        return null;
    }
    static index(element) {
        let children = element.parentNode.childNodes;
        let num = 0;
        for (var index = 0; index < children.length; index++) {
            if (children[index] == element)
                return num;
            if (children[index].nodeType == 1)
                num++;
        }
        return -1;
    }
    static indexWithinGroup(element, attributeName) {
        let children = element.parentNode ? element.parentNode.childNodes : [];
        let num = 0;
        for (var index = 0; index < children.length; index++) {
            if (children[index] == element)
                return num;
            if (children[index].attributes &&
                children[index].attributes[attributeName] &&
                children[index].nodeType == 1)
                num++;
        }
        return -1;
    }
    static appendOverlay(overlay, target, appendTo = 'self') {
        if (appendTo !== 'self' && overlay && target) {
            this.appendChild(overlay, target);
        }
    }
    static alignOverlay(overlay, target, appendTo = 'self', calculateMinWidth = true) {
        if (overlay && target) {
            calculateMinWidth &&
                (overlay.style.minWidth ||
                    (overlay.style.minWidth = DomHandler.getOuterWidth(target) + 'px'));
            if (appendTo === 'self') {
                this.relativePosition(overlay, target);
            }
            else {
                this.absolutePosition(overlay, target);
            }
        }
    }
    static relativePosition(element, target) {
        const getClosestRelativeElement = (sourceElement) => {
            if (!sourceElement)
                return;
            return getComputedStyle(sourceElement).getPropertyValue('position') ===
                'relative'
                ? sourceElement
                : getClosestRelativeElement(sourceElement.parentElement);
        };
        const elementDimensions = element.offsetParent
            ? { width: element.offsetWidth, height: element.offsetHeight }
            : this.getHiddenElementDimensions(element);
        const targetHeight = target.offsetHeight;
        const targetOffset = target.getBoundingClientRect();
        const windowScrollTop = this.getWindowScrollTop();
        const windowScrollLeft = this.getWindowScrollLeft();
        const viewport = this.getViewport();
        const relativeElement = getClosestRelativeElement(element);
        const relativeElementOffset = relativeElement?.getBoundingClientRect() || {
            top: -1 * windowScrollTop,
            left: -1 * windowScrollLeft,
        };
        let top, left;
        if (targetOffset.top + targetHeight + elementDimensions.height >
            viewport.height) {
            top =
                targetOffset.top - relativeElementOffset.top - elementDimensions.height;
            element.style.transformOrigin = 'bottom';
            if (targetOffset.top + top < 0) {
                top = -1 * targetOffset.top;
            }
        }
        else {
            top = targetHeight + targetOffset.top - relativeElementOffset.top;
            element.style.transformOrigin = 'top';
        }
        if (elementDimensions.width > viewport.width) {
            // element wider then viewport and cannot fit on screen (align at left side of viewport)
            left = (targetOffset.left - relativeElementOffset.left) * -1;
        }
        else if (targetOffset.left - relativeElementOffset.left + elementDimensions.width >
            viewport.width) {
            // element wider then viewport but can be fit on screen (align at right side of viewport)
            left =
                (targetOffset.left -
                    relativeElementOffset.left +
                    elementDimensions.width -
                    viewport.width) *
                    -1;
        }
        else {
            // element fits on screen (align with target)
            left = targetOffset.left - relativeElementOffset.left;
        }
        element.style.top = top + 'px';
        element.style.left = left + 'px';
    }
    static absolutePosition(element, target) {
        const elementDimensions = element.offsetParent
            ? { width: element.offsetWidth, height: element.offsetHeight }
            : this.getHiddenElementDimensions(element);
        const elementOuterHeight = elementDimensions.height;
        const elementOuterWidth = elementDimensions.width;
        const targetOuterHeight = target.offsetHeight;
        const targetOuterWidth = target.offsetWidth;
        const targetOffset = target.getBoundingClientRect();
        const windowScrollTop = this.getWindowScrollTop();
        const windowScrollLeft = this.getWindowScrollLeft();
        const viewport = this.getViewport();
        let top, left;
        if (targetOffset.top + targetOuterHeight + elementOuterHeight >
            viewport.height) {
            top = targetOffset.top + windowScrollTop - elementOuterHeight;
            element.style.transformOrigin = 'bottom';
            if (top < 0) {
                top = windowScrollTop;
            }
        }
        else {
            top = targetOuterHeight + targetOffset.top + windowScrollTop;
            element.style.transformOrigin = 'top';
        }
        if (targetOffset.left + elementOuterWidth > viewport.width)
            left = Math.max(0, targetOffset.left +
                windowScrollLeft +
                targetOuterWidth -
                elementOuterWidth);
        else
            left = targetOffset.left + windowScrollLeft;
        element.style.top = top + 'px';
        element.style.left = left + 'px';
    }
    static getParents(element, parents = []) {
        return element['parentNode'] === null
            ? parents
            : this.getParents(element.parentNode, parents.concat([element.parentNode]));
    }
    static getScrollableParents(element) {
        let scrollableParents = [];
        if (element) {
            let parents = this.getParents(element);
            const overflowRegex = /(auto|scroll)/;
            const overflowCheck = (node) => {
                let styleDeclaration = window['getComputedStyle'](node, null);
                return (overflowRegex.test(styleDeclaration.getPropertyValue('overflow')) ||
                    overflowRegex.test(styleDeclaration.getPropertyValue('overflowX')) ||
                    overflowRegex.test(styleDeclaration.getPropertyValue('overflowY')));
            };
            for (let parent of parents) {
                let scrollSelectors = parent.nodeType === 1 && parent.dataset['scrollselectors'];
                if (scrollSelectors) {
                    let selectors = scrollSelectors.split(',');
                    for (let selector of selectors) {
                        let el = this.findSingle(parent, selector);
                        if (el && overflowCheck(el)) {
                            scrollableParents.push(el);
                        }
                    }
                }
                if (parent.nodeType !== 9 && overflowCheck(parent)) {
                    scrollableParents.push(parent);
                }
            }
        }
        return scrollableParents;
    }
    static getHiddenElementOuterHeight(element) {
        element.style.visibility = 'hidden';
        element.style.display = 'block';
        let elementHeight = element.offsetHeight;
        element.style.display = 'none';
        element.style.visibility = 'visible';
        return elementHeight;
    }
    static getHiddenElementOuterWidth(element) {
        element.style.visibility = 'hidden';
        element.style.display = 'block';
        let elementWidth = element.offsetWidth;
        element.style.display = 'none';
        element.style.visibility = 'visible';
        return elementWidth;
    }
    static getHiddenElementDimensions(element) {
        let dimensions = {};
        element.style.visibility = 'hidden';
        element.style.display = 'block';
        dimensions.width = element.offsetWidth;
        dimensions.height = element.offsetHeight;
        element.style.display = 'none';
        element.style.visibility = 'visible';
        return dimensions;
    }
    static scrollInView(container, item) {
        let borderTopValue = getComputedStyle(container).getPropertyValue('borderTopWidth');
        let borderTop = borderTopValue ? parseFloat(borderTopValue) : 0;
        let paddingTopValue = getComputedStyle(container).getPropertyValue('paddingTop');
        let paddingTop = paddingTopValue ? parseFloat(paddingTopValue) : 0;
        let containerRect = container.getBoundingClientRect();
        let itemRect = item.getBoundingClientRect();
        let offset = itemRect.top +
            document.body.scrollTop -
            (containerRect.top + document.body.scrollTop) -
            borderTop -
            paddingTop;
        let scroll = container.scrollTop;
        let elementHeight = container.clientHeight;
        let itemHeight = this.getOuterHeight(item);
        if (offset < 0) {
            container.scrollTop = scroll + offset;
        }
        else if (offset + itemHeight > elementHeight) {
            container.scrollTop = scroll + offset - elementHeight + itemHeight;
        }
    }
    static fadeIn(element, duration) {
        element.style.opacity = 0;
        let last = +new Date();
        let opacity = 0;
        let tick = function () {
            opacity =
                +element.style.opacity.replace(',', '.') +
                    (new Date().getTime() - last) / duration;
            element.style.opacity = opacity;
            last = +new Date();
            if (+opacity < 1) {
                (Boolean(window.requestAnimationFrame) &&
                    requestAnimationFrame(tick)) ||
                    setTimeout(tick, 16);
            }
        };
        tick();
    }
    static fadeOut(element, ms) {
        var opacity = 1, interval = 50, duration = ms, gap = interval / duration;
        let fading = setInterval(() => {
            opacity = opacity - gap;
            if (opacity <= 0) {
                opacity = 0;
                clearInterval(fading);
            }
            element.style.opacity = opacity;
        }, interval);
    }
    static getWindowScrollTop() {
        let doc = document.documentElement;
        return (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    }
    static getWindowScrollLeft() {
        let doc = document.documentElement;
        return (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
    }
    // this 的紅字問題後續再調整
    // public static matches(element: any, selector: string): boolean {
    //   var p: any = Element.prototype;
    //   var f =
    //     p['matches'] ||
    //     p.webkitMatchesSelector ||
    //     p['mozMatchesSelector'] ||
    //     p['msMatchesSelector'] ||
    //     function (s: any) {
    //       return [].indexOf.call(document.querySelectorAll(s), this) !== -1;
    //     };
    //   return f.call(element, selector);
    // }
    static getOuterWidth(el, margin) {
        let width = el.offsetWidth;
        if (margin) {
            let style = getComputedStyle(el);
            width += parseFloat(style.marginLeft) + parseFloat(style.marginRight);
        }
        return width;
    }
    static getHorizontalPadding(el) {
        let style = getComputedStyle(el);
        return parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
    }
    static getHorizontalMargin(el) {
        let style = getComputedStyle(el);
        return parseFloat(style.marginLeft) + parseFloat(style.marginRight);
    }
    static innerWidth(el) {
        let width = el.offsetWidth;
        let style = getComputedStyle(el);
        width += parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
        return width;
    }
    static width(el) {
        let width = el.offsetWidth;
        let style = getComputedStyle(el);
        width -= parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
        return width;
    }
    static getInnerHeight(el) {
        let height = el.offsetHeight;
        let style = getComputedStyle(el);
        height += parseFloat(style.paddingTop) + parseFloat(style.paddingBottom);
        return height;
    }
    static getOuterHeight(el, margin) {
        let height = el.offsetHeight;
        if (margin) {
            let style = getComputedStyle(el);
            height += parseFloat(style.marginTop) + parseFloat(style.marginBottom);
        }
        return height;
    }
    static getHeight(el) {
        let height = el.offsetHeight;
        let style = getComputedStyle(el);
        height -=
            parseFloat(style.paddingTop) +
                parseFloat(style.paddingBottom) +
                parseFloat(style.borderTopWidth) +
                parseFloat(style.borderBottomWidth);
        return height;
    }
    static getWidth(el) {
        let width = el.offsetWidth;
        let style = getComputedStyle(el);
        width -=
            parseFloat(style.paddingLeft) +
                parseFloat(style.paddingRight) +
                parseFloat(style.borderLeftWidth) +
                parseFloat(style.borderRightWidth);
        return width;
    }
    static getViewport() {
        let win = window, d = document, e = d.documentElement, g = d.getElementsByTagName('body')[0], w = win.innerWidth || e.clientWidth || g.clientWidth, h = win.innerHeight || e.clientHeight || g.clientHeight;
        return { width: w, height: h };
    }
    static getOffset(el) {
        var rect = el.getBoundingClientRect();
        return {
            top: rect.top +
                (window.pageYOffset ||
                    document.documentElement.scrollTop ||
                    document.body.scrollTop ||
                    0),
            left: rect.left +
                (window.pageXOffset ||
                    document.documentElement.scrollLeft ||
                    document.body.scrollLeft ||
                    0),
        };
    }
    static replaceElementWith(element, replacementElement) {
        let parentNode = element.parentNode;
        if (!parentNode)
            throw `Can't replace element`;
        return parentNode.replaceChild(replacementElement, element);
    }
    static getUserAgent() {
        return navigator.userAgent;
    }
    static isIE() {
        var ua = window.navigator.userAgent;
        var msie = ua.indexOf('MSIE ');
        if (msie > 0) {
            // IE 10 or older => return version number
            return true;
        }
        var trident = ua.indexOf('Trident/');
        if (trident > 0) {
            // IE 11 => return version number
            var rv = ua.indexOf('rv:');
            return true;
        }
        var edge = ua.indexOf('Edge/');
        if (edge > 0) {
            // Edge (IE 12+) => return version number
            return true;
        }
        // other browser
        return false;
    }
    static isIOS() {
        return (/iPad|iPhone|iPod/.test(navigator.userAgent) &&
            !window['MSStream']);
    }
    static isAndroid() {
        return /(android)/i.test(navigator.userAgent);
    }
    static isTouchDevice() {
        return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    }
    static appendChild(element, target) {
        if (this.isElement(target))
            target.appendChild(element);
        else if (target.el && target.el.nativeElement)
            target.el.nativeElement.appendChild(element);
        else
            throw 'Cannot append ' + target + ' to ' + element;
    }
    static removeChild(element, target) {
        if (this.isElement(target))
            target.removeChild(element);
        else if (target.el && target.el.nativeElement)
            target.el.nativeElement.removeChild(element);
        else
            throw 'Cannot remove ' + element + ' from ' + target;
    }
    static removeElement(element) {
        if (!('remove' in Element.prototype))
            element.parentNode.removeChild(element);
        else
            element.remove();
    }
    static isElement(obj) {
        return typeof HTMLElement === 'object'
            ? obj instanceof HTMLElement
            : obj &&
                typeof obj === 'object' &&
                obj !== null &&
                obj.nodeType === 1 &&
                typeof obj.nodeName === 'string';
    }
    static calculateScrollbarWidth(el) {
        if (el) {
            let style = getComputedStyle(el);
            return (el.offsetWidth -
                el.clientWidth -
                parseFloat(style.borderLeftWidth) -
                parseFloat(style.borderRightWidth));
        }
        else {
            if (this.calculatedScrollbarWidth !== null)
                return this.calculatedScrollbarWidth;
            let scrollDiv = document.createElement('div');
            scrollDiv.className = 'cub-scrollbar-measure';
            document.body.appendChild(scrollDiv);
            let scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
            document.body.removeChild(scrollDiv);
            this.calculatedScrollbarWidth = scrollbarWidth;
            return scrollbarWidth;
        }
    }
    static calculateScrollbarHeight() {
        if (this.calculatedScrollbarHeight !== null)
            return this.calculatedScrollbarHeight;
        let scrollDiv = document.createElement('div');
        scrollDiv.className = 'cub-scrollbar-measure';
        document.body.appendChild(scrollDiv);
        let scrollbarHeight = scrollDiv.offsetHeight - scrollDiv.clientHeight;
        document.body.removeChild(scrollDiv);
        this.calculatedScrollbarWidth = scrollbarHeight;
        return scrollbarHeight;
    }
    static invokeElementMethod(element, methodName, args) {
        element[methodName].apply(element, args);
    }
    static clearSelection() {
        if (window.getSelection) {
            if (Boolean(window.getSelection().empty)) {
                window.getSelection().empty();
            }
            else if (Boolean(window.getSelection().removeAllRanges) &&
                window.getSelection().rangeCount > 0 &&
                window.getSelection().getRangeAt(0).getClientRects().length > 0) {
                window.getSelection().removeAllRanges();
            }
        }
        // selection 的紅字問題後續再調整
        // else if (document['selection'] && document['selection'].empty) {
        //   try {
        //     document['selection'].empty();
        //   } catch (error) {
        //     //ignore IE bug
        //   }
        // }
    }
    static getBrowser() {
        if (!this.browser) {
            let matched = this.resolveUserAgent();
            this.browser = {};
            if (matched.browser) {
                this.browser[matched.browser] = true;
                this.browser['version'] = matched.version;
            }
            if (this.browser['chrome']) {
                this.browser['webkit'] = true;
            }
            else if (this.browser['webkit']) {
                this.browser['safari'] = true;
            }
        }
        return this.browser;
    }
    static resolveUserAgent() {
        let ua = navigator.userAgent.toLowerCase();
        let match = /(chrome)[ \/]([\w.]+)/.exec(ua) ||
            /(webkit)[ \/]([\w.]+)/.exec(ua) ||
            /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) ||
            /(msie) ([\w.]+)/.exec(ua) ||
            (ua.indexOf('compatible') < 0 &&
                /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua)) ||
            [];
        return {
            browser: match[1] || '',
            version: match[2] || '0',
        };
    }
    static isInteger(value) {
        if (Number.isInteger) {
            return Number.isInteger(value);
        }
        else {
            return (typeof value === 'number' &&
                isFinite(value) &&
                Math.floor(value) === value);
        }
    }
    static isHidden(element) {
        return !element || element.offsetParent === null;
    }
    static isVisible(element) {
        return element && element.offsetParent != null;
    }
    static isExist(element) {
        return (element !== null &&
            typeof element !== 'undefined' &&
            element.nodeName &&
            element.parentNode);
    }
    static focus(element, options) {
        element && document.activeElement !== element && element.focus(options);
    }
    static getFocusableElements(element) {
        let focusableElements = DomHandler.find(element, `button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]),
                [href][clientHeight][clientWidth]:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]),
                input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]), select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]),
                textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]), [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]),
                [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden]):not(.cub-disabled)`);
        let visibleFocusableElements = [];
        for (let focusableElement of focusableElements) {
            if (getComputedStyle(focusableElement).display != 'none' &&
                getComputedStyle(focusableElement).visibility != 'hidden')
                visibleFocusableElements.push(focusableElement);
        }
        return visibleFocusableElements;
    }
    static generateZIndex() {
        this.zindex = this.zindex || 999;
        return ++this.zindex;
    }
    static getSelection() {
        if (window.getSelection)
            return window.getSelection().toString();
        else if (document.getSelection)
            return document.getSelection().toString();
        // selection 的紅字問題後續再調整
        // else if (document['selection'])
        //   return document['selection'].createRange().text;
        return null;
    }
    static getTargetElement(target, el) {
        if (!target)
            return null;
        switch (target) {
            case 'document':
                return document;
            case 'window':
                return window;
            case '@next':
                return el?.nextElementSibling;
            case '@prev':
                return el?.previousElementSibling;
            case '@parent':
                return el?.parentElement;
            case '@grandparent':
                return el?.parentElement.parentElement;
            default:
                const type = typeof target;
                if (type === 'string') {
                    return document.querySelector(target);
                }
                else if (type === 'object' &&
                    target.hasOwnProperty('nativeElement')) {
                    return this.isExist(target.nativeElement)
                        ? target.nativeElement
                        : undefined;
                }
                const isFunction = (obj) => !!(obj && obj.constructor && obj.call && obj.apply);
                const element = isFunction(target) ? target() : target;
                return (element && element.nodeType === 9) || this.isExist(element)
                    ? element
                    : null;
        }
    }
}

/** Error state matcher that matches when a control is invalid and dirty. */
class ShowOnDirtyErrorStateMatcher {
    isErrorState(control, form) {
        return !!(control &&
            control.invalid &&
            (control.dirty || (form && form.submitted)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: ShowOnDirtyErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: ShowOnDirtyErrorStateMatcher }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: ShowOnDirtyErrorStateMatcher, decorators: [{
            type: Injectable
        }] });
/** Provider that defines how form controls behave with regards to displaying error messages. */
class ErrorStateMatcher {
    isErrorState(control, form) {
        return !!(control &&
            control.invalid &&
            (control.touched || (form && form.submitted)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: ErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: ErrorStateMatcher, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: ErrorStateMatcher, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

// 該檔案由 PrimeNG v14.2.3 複製而來
class ObjectUtils {
    static equals(obj1, obj2, field) {
        if (field)
            return (this.resolveFieldData(obj1, field) ===
                this.resolveFieldData(obj2, field));
        else
            return this.equalsByValue(obj1, obj2);
    }
    static equalsByValue(obj1, obj2) {
        if (obj1 === obj2)
            return true;
        if (obj1 && obj2 && typeof obj1 == 'object' && typeof obj2 == 'object') {
            var arrA = Array.isArray(obj1), arrB = Array.isArray(obj2), i, length, key;
            if (arrA && arrB) {
                length = obj1.length;
                if (length != obj2.length)
                    return false;
                for (i = length; i-- !== 0;)
                    if (!this.equalsByValue(obj1[i], obj2[i]))
                        return false;
                return true;
            }
            if (arrA != arrB)
                return false;
            var dateA = obj1 instanceof Date, dateB = obj2 instanceof Date;
            if (dateA != dateB)
                return false;
            if (dateA && dateB)
                return obj1.getTime() == obj2.getTime();
            var regexpA = obj1 instanceof RegExp, regexpB = obj2 instanceof RegExp;
            if (regexpA != regexpB)
                return false;
            if (regexpA && regexpB)
                return obj1.toString() == obj2.toString();
            var keys = Object.keys(obj1);
            length = keys.length;
            if (length !== Object.keys(obj2).length)
                return false;
            for (i = length; i-- !== 0;)
                if (!Object.prototype.hasOwnProperty.call(obj2, keys[i]))
                    return false;
            for (i = length; i-- !== 0;) {
                key = keys[i];
                if (!this.equalsByValue(obj1[key], obj2[key]))
                    return false;
            }
            return true;
        }
        return obj1 !== obj1 && obj2 !== obj2;
    }
    static resolveFieldData(data, field) {
        if (data && field) {
            if (this.isFunction(field)) {
                return field(data);
            }
            else if (field.indexOf('.') == -1) {
                return data[field];
            }
            else {
                let fields = field.split('.');
                let value = data;
                for (let i = 0, len = fields.length; i < len; ++i) {
                    if (value == null) {
                        return null;
                    }
                    value = value[fields[i]];
                }
                return value;
            }
        }
        else {
            return null;
        }
    }
    static isFunction(obj) {
        return !!(obj && obj.constructor && obj.call && obj.apply);
    }
    static reorderArray(value, from, to) {
        let target;
        if (value && from !== to) {
            if (to >= value.length) {
                to %= value.length;
                from %= value.length;
            }
            value.splice(to, 0, value.splice(from, 1)[0]);
        }
    }
    static insertIntoOrderedArray(item, index, arr, sourceArr) {
        if (arr.length > 0) {
            let injected = false;
            for (let i = 0; i < arr.length; i++) {
                let currentItemIndex = this.findIndexInList(arr[i], sourceArr);
                if (currentItemIndex > index) {
                    arr.splice(i, 0, item);
                    injected = true;
                    break;
                }
            }
            if (!injected) {
                arr.push(item);
            }
        }
        else {
            arr.push(item);
        }
    }
    static findIndexInList(item, list) {
        let index = -1;
        if (list) {
            for (let i = 0; i < list.length; i++) {
                if (list[i] == item) {
                    index = i;
                    break;
                }
            }
        }
        return index;
    }
    static contains(value, list) {
        if (value != null && list && list.length) {
            for (let val of list) {
                if (this.equals(value, val))
                    return true;
            }
        }
        return false;
    }
    static removeAccents(str) {
        if (str && str.search(/[\xC0-\xFF]/g) > -1) {
            str = str
                .replace(/[\xC0-\xC5]/g, 'A')
                .replace(/[\xC6]/g, 'AE')
                .replace(/[\xC7]/g, 'C')
                .replace(/[\xC8-\xCB]/g, 'E')
                .replace(/[\xCC-\xCF]/g, 'I')
                .replace(/[\xD0]/g, 'D')
                .replace(/[\xD1]/g, 'N')
                .replace(/[\xD2-\xD6\xD8]/g, 'O')
                .replace(/[\xD9-\xDC]/g, 'U')
                .replace(/[\xDD]/g, 'Y')
                .replace(/[\xDE]/g, 'P')
                .replace(/[\xE0-\xE5]/g, 'a')
                .replace(/[\xE6]/g, 'ae')
                .replace(/[\xE7]/g, 'c')
                .replace(/[\xE8-\xEB]/g, 'e')
                .replace(/[\xEC-\xEF]/g, 'i')
                .replace(/[\xF1]/g, 'n')
                .replace(/[\xF2-\xF6\xF8]/g, 'o')
                .replace(/[\xF9-\xFC]/g, 'u')
                .replace(/[\xFE]/g, 'p')
                .replace(/[\xFD\xFF]/g, 'y');
        }
        return str;
    }
    static isEmpty(value) {
        return (value === null ||
            value === undefined ||
            value === '' ||
            (Array.isArray(value) && value.length === 0) ||
            (!(value instanceof Date) &&
                typeof value === 'object' &&
                Object.keys(value).length === 0));
    }
    static isNotEmpty(value) {
        return !this.isEmpty(value);
    }
    static compare(value1, value2, locale, order = 1) {
        let result = -1;
        const emptyValue1 = this.isEmpty(value1);
        const emptyValue2 = this.isEmpty(value2);
        if (emptyValue1 && emptyValue2)
            result = 0;
        else if (emptyValue1)
            result = order;
        else if (emptyValue2)
            result = -order;
        else if (typeof value1 === 'string' && typeof value2 === 'string')
            result = value1.localeCompare(value2, locale, { numeric: true });
        else
            result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
        return result;
    }
    static sort(value1, value2, order = 1, locale, nullSortOrder = 1) {
        const result = ObjectUtils.compare(value1, value2, locale, order);
        // nullSortOrder == 1 means Excel like sort nulls at bottom
        const finalSortOrder = nullSortOrder === 1 ? order : nullSortOrder;
        return finalSortOrder * result;
    }
    static merge(obj1, obj2) {
        if ((obj1 == undefined || typeof obj1 === 'object') &&
            (obj2 == undefined || typeof obj2 === 'object')) {
            return { ...(obj1 || {}), ...(obj2 || {}) };
        }
        else if ((obj1 == undefined || typeof obj1 === 'string') &&
            (obj2 == undefined || typeof obj2 === 'string')) {
            return [obj1 || '', obj2 || ''].join(' ');
        }
        return obj2 || obj1;
    }
}

// 該檔案由 PrimeNG v14.2.3 複製而來
class CubFilterService {
    constructor() {
        this.filters = {
            startsWith: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null || filter.trim() === '') {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                let filterValue = ObjectUtils.removeAccents(filter.toString()).toLocaleLowerCase(filterLocale);
                let stringValue = ObjectUtils.removeAccents(value.toString()).toLocaleLowerCase(filterLocale);
                return stringValue.slice(0, filterValue.length) === filterValue;
            },
            contains: (value, filter, filterLocale) => {
                if (filter === undefined ||
                    filter === null ||
                    (typeof filter === 'string' && filter.trim() === '')) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                let filterValue = ObjectUtils.removeAccents(filter.toString()).toLocaleLowerCase(filterLocale);
                let stringValue = ObjectUtils.removeAccents(value.toString()).toLocaleLowerCase(filterLocale);
                return stringValue.indexOf(filterValue) !== -1;
            },
            notContains: (value, filter, filterLocale) => {
                if (filter === undefined ||
                    filter === null ||
                    (typeof filter === 'string' && filter.trim() === '')) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                let filterValue = ObjectUtils.removeAccents(filter.toString()).toLocaleLowerCase(filterLocale);
                let stringValue = ObjectUtils.removeAccents(value.toString()).toLocaleLowerCase(filterLocale);
                return stringValue.indexOf(filterValue) === -1;
            },
            endsWith: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null || filter.trim() === '') {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                let filterValue = ObjectUtils.removeAccents(filter.toString()).toLocaleLowerCase(filterLocale);
                let stringValue = ObjectUtils.removeAccents(value.toString()).toLocaleLowerCase(filterLocale);
                return (stringValue.indexOf(filterValue, stringValue.length - filterValue.length) !== -1);
            },
            equals: (value, filter, filterLocale) => {
                if (filter === undefined ||
                    filter === null ||
                    (typeof filter === 'string' && filter.trim() === '')) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                if (value.getTime && filter.getTime)
                    return value.getTime() === filter.getTime();
                else
                    return (ObjectUtils.removeAccents(value.toString()).toLocaleLowerCase(filterLocale) ==
                        ObjectUtils.removeAccents(filter.toString()).toLocaleLowerCase(filterLocale));
            },
            notEquals: (value, filter, filterLocale) => {
                if (filter === undefined ||
                    filter === null ||
                    (typeof filter === 'string' && filter.trim() === '')) {
                    return false;
                }
                if (value === undefined || value === null) {
                    return true;
                }
                if (value.getTime && filter.getTime)
                    return value.getTime() !== filter.getTime();
                else
                    return (ObjectUtils.removeAccents(value.toString()).toLocaleLowerCase(filterLocale) !=
                        ObjectUtils.removeAccents(filter.toString()).toLocaleLowerCase(filterLocale));
            },
            in: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null || filter.length === 0) {
                    return true;
                }
                for (let i = 0; i < filter.length; i++) {
                    if (ObjectUtils.equals(value, filter[i])) {
                        return true;
                    }
                }
                return false;
            },
            between: (value, filter, filterLocale) => {
                if (filter == null || filter[0] == null || filter[1] == null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                if (value.getTime)
                    return (filter[0].getTime() <= value.getTime() &&
                        value.getTime() <= filter[1].getTime());
                else
                    return filter[0] <= value && value <= filter[1];
            },
            lt: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                if (value.getTime && filter.getTime)
                    return value.getTime() < filter.getTime();
                else
                    return value < filter;
            },
            lte: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                if (value.getTime && filter.getTime)
                    return value.getTime() <= filter.getTime();
                else
                    return value <= filter;
            },
            gt: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                if (value.getTime && filter.getTime)
                    return value.getTime() > filter.getTime();
                else
                    return value > filter;
            },
            gte: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                if (value.getTime && filter.getTime)
                    return value.getTime() >= filter.getTime();
                else
                    return value >= filter;
            },
            is: (value, filter, filterLocale) => {
                return this.filters.equals(value, filter, filterLocale);
            },
            isNot: (value, filter, filterLocale) => {
                return this.filters.notEquals(value, filter, filterLocale);
            },
            before: (value, filter, filterLocale) => {
                return this.filters.lt(value, filter, filterLocale);
            },
            after: (value, filter, filterLocale) => {
                return this.filters.gt(value, filter, filterLocale);
            },
            dateIs: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                return value.toDateString() === filter.toDateString();
            },
            dateIsNot: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                return value.toDateString() !== filter.toDateString();
            },
            dateBefore: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                return value.getTime() < filter.getTime();
            },
            dateAfter: (value, filter, filterLocale) => {
                if (filter === undefined || filter === null) {
                    return true;
                }
                if (value === undefined || value === null) {
                    return false;
                }
                return value.getTime() > filter.getTime();
            },
        };
    }
    filter(value, fields, filterValue, filterMatchMode, filterLocale) {
        let filteredItems = [];
        if (value) {
            for (let item of value) {
                for (let field of fields) {
                    let fieldValue = ObjectUtils.resolveFieldData(item, field);
                    if (this.filters[filterMatchMode](fieldValue, filterValue, filterLocale)) {
                        filteredItems.push(item);
                        break;
                    }
                }
            }
        }
        return filteredItems;
    }
    register(rule, fn) {
        this.filters[rule] = fn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFilterService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFilterService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

// 該檔案由 PrimeNG v14.2.3 複製而來
/** Filter 功能篩選模式文字轉換 */
class FilterMatchMode {
    static { this.STARTS_WITH = 'startsWith'; }
    static { this.CONTAINS = 'contains'; }
    static { this.NOT_CONTAINS = 'notContains'; }
    static { this.ENDS_WITH = 'endsWith'; }
    static { this.EQUALS = 'equals'; }
    static { this.NOT_EQUALS = 'notEquals'; }
    static { this.IN = 'in'; }
    static { this.LESS_THAN = 'lt'; }
    static { this.LESS_THAN_OR_EQUAL_TO = 'lte'; }
    static { this.GREATER_THAN = 'gt'; }
    static { this.GREATER_THAN_OR_EQUAL_TO = 'gte'; }
    static { this.BETWEEN = 'between'; }
    static { this.IS = 'is'; }
    static { this.IS_NOT = 'isNot'; }
    static { this.BEFORE = 'before'; }
    static { this.AFTER = 'after'; }
    static { this.DATE_IS = 'dateIs'; }
    static { this.DATE_IS_NOT = 'dateIsNot'; }
    static { this.DATE_BEFORE = 'dateBefore'; }
    static { this.DATE_AFTER = 'dateAfter'; }
}

const CUB_PREFIX = new InjectionToken('CubPrefix');
class CubPrefix {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPrefix, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubPrefix, isStandalone: true, selector: "[cubPrefix]", providers: [{ provide: CUB_PREFIX, useExisting: CubPrefix }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPrefix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubPrefix]',
                    providers: [{ provide: CUB_PREFIX, useExisting: CubPrefix }]
                }]
        }] });

const CUB_SUFFIX = new InjectionToken('CubSuffix');
class CubSuffix {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSuffix, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSuffix, isStandalone: true, selector: "[cubSuffix]", providers: [{ provide: CUB_SUFFIX, useExisting: CubSuffix }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSuffix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubSuffix]',
                    providers: [{ provide: CUB_SUFFIX, useExisting: CubSuffix }]
                }]
        }] });

const CUB_END = new InjectionToken('CubEnd');
class CubEnd {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubEnd, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubEnd, isStandalone: true, selector: "[cubEnd]", providers: [{ provide: CUB_END, useExisting: CubEnd }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubEnd, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubEnd]',
                    providers: [{ provide: CUB_END, useExisting: CubEnd }],
                }]
        }] });

class CubPositionModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubPositionModule, imports: [CubPrefix, CubSuffix, CubEnd], exports: [CubPrefix, CubSuffix, CubEnd] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPositionModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubPrefix, CubSuffix, CubEnd],
                    exports: [CubPrefix, CubSuffix, CubEnd],
                }]
        }] });

class CubRequired {
    constructor() {
        this.required = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRequired, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubRequired, isStandalone: true, selector: "[cubRequired]", inputs: { required: ["cubRequired", "required", booleanAttribute] }, host: { properties: { "class.cub-label-required": "required", "attr.aria-required": "\"true\"" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRequired, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubRequired]',
                    host: {
                        '[class.cub-label-required]': 'required',
                        '[attr.aria-required]': '"true"',
                    },
                }]
        }], propDecorators: { required: [{
                type: Input,
                args: [{ alias: 'cubRequired', transform: booleanAttribute }]
            }] } });

class CubRequiredModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRequiredModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubRequiredModule, imports: [CubRequired], exports: [CubRequired] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRequiredModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRequiredModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubRequired],
                    exports: [CubRequired],
                }]
        }] });

const CUB_RIPPLE_GLOBAL_OPTIONS = new InjectionToken('cub-ripple-global-options');
const defaultRippleAnimationConfig = {
    enterDuration: 225,
    exitDuration: 150,
};
const defaultRippleClassConfig = {
    ripple: 'cub-ripple',
    rippleElement: 'cub-ripple-element',
};
const ignoreMouseEventsTimeout = 800;
const passiveEventOptions = normalizePassiveListenerOptions({
    passive: true,
});
const pointerDownEvents = ['mousedown', 'touchstart', 'keydown'];
const pointerUpEvents = [
    'mouseup',
    'mouseleave',
    'touchend',
    'touchcancel',
    'keyup',
];

function distanceToFurthestCorner(x, y, rect) {
    const distX = Math.max(Math.abs(x - rect.left), Math.abs(x - rect.right));
    const distY = Math.max(Math.abs(y - rect.top), Math.abs(y - rect.bottom));
    return Math.sqrt(distX * distX + distY * distY);
}

class RippleRef {
    constructor(_renderer, element, config, _animationForciblyDisabledThroughCss = false) {
        this._renderer = _renderer;
        this.element = element;
        this.config = config;
        this._animationForciblyDisabledThroughCss = _animationForciblyDisabledThroughCss;
        this.state = 3 /* CubRippleState.HIDDEN */;
    }
    fadeOut() {
        this._renderer.fadeOutRipple(this);
    }
}
class RippleRenderer {
    constructor(_target, _ngZone, elementOrElementRef, platform) {
        this._target = _target;
        this._ngZone = _ngZone;
        this._isPointerDown = false;
        this._activeRipples = new Map();
        this._pointerUpEventsRegistered = false;
        if (platform.isBrowser) {
            this._containerElement = coerceElement(elementOrElementRef);
        }
    }
    fadeInRipple(x, y, config = {}) {
        const rippleClassConfig = {
            ...defaultRippleClassConfig,
            ...config.rippleClass,
        };
        const rippleContainer = this._containerElement.querySelector(`.${rippleClassConfig.ripple}`);
        let containerRect;
        if (rippleContainer) {
            containerRect = this._containerRect =
                this._containerRect || rippleContainer.getBoundingClientRect();
        }
        else {
            containerRect = this._containerRect =
                this._containerRect || this._containerElement.getBoundingClientRect();
        }
        const animationConfig = {
            ...defaultRippleAnimationConfig,
            ...config.animation,
        };
        if (config.centered) {
            x = containerRect.left + containerRect.width / 2;
            y = containerRect.top + containerRect.height / 2;
        }
        const radius = config.radius || distanceToFurthestCorner(x, y, containerRect);
        const offsetX = x - containerRect.left;
        const offsetY = y - containerRect.top;
        const enterDuration = animationConfig.enterDuration;
        const ripple = document.createElement('div');
        ripple.classList.add(`${rippleClassConfig.rippleElement}`);
        ripple.style.left = `${offsetX - radius}px`;
        ripple.style.top = `${offsetY - radius}px`;
        ripple.style.height = `${radius * 2}px`;
        ripple.style.width = `${radius * 2}px`;
        if (config.color != null) {
            ripple.style.backgroundColor = config.color;
        }
        ripple.style.transitionDuration = `${enterDuration}ms`;
        if (rippleContainer) {
            rippleContainer.appendChild(ripple);
        }
        else {
            this._containerElement.appendChild(ripple);
        }
        const computedStyles = window.getComputedStyle(ripple);
        const userTransitionProperty = computedStyles.transitionProperty;
        const userTransitionDuration = computedStyles.transitionDuration;
        const animationForciblyDisabledThroughCss = userTransitionProperty === 'none' ||
            userTransitionDuration === '0s' ||
            userTransitionDuration === '0s, 0s';
        const rippleRef = new RippleRef(this, ripple, config, animationForciblyDisabledThroughCss);
        ripple.style.transform = 'scale3d(1, 1, 1)';
        rippleRef.state = 0 /* CubRippleState.FADING_IN */;
        if (!config.persistent) {
            this._mostRecentTransientRipple = rippleRef;
        }
        let eventListeners = null;
        if (!animationForciblyDisabledThroughCss &&
            (enterDuration || animationConfig.exitDuration)) {
            this._ngZone.runOutsideAngular(() => {
                const onTransitionEnd = () => this._finishRippleTransition(rippleRef);
                const onTransitionCancel = () => this._destroyRipple(rippleRef);
                ripple.addEventListener('transitionend', onTransitionEnd);
                ripple.addEventListener('transitioncancel', onTransitionCancel);
                eventListeners = { onTransitionEnd, onTransitionCancel };
            });
        }
        this._activeRipples.set(rippleRef, eventListeners);
        if (animationForciblyDisabledThroughCss || !enterDuration) {
            this._finishRippleTransition(rippleRef);
        }
        return rippleRef;
    }
    fadeOutRipple(rippleRef) {
        if (rippleRef.state === 2 /* CubRippleState.FADING_OUT */ ||
            rippleRef.state === 3 /* CubRippleState.HIDDEN */) {
            return;
        }
        const rippleEl = rippleRef.element;
        const animationConfig = {
            ...defaultRippleAnimationConfig,
            ...rippleRef.config.animation,
        };
        rippleEl.style.transitionDuration = `${animationConfig.exitDuration}ms`;
        rippleEl.style.opacity = '0';
        rippleRef.state = 2 /* CubRippleState.FADING_OUT */;
        if (rippleRef._animationForciblyDisabledThroughCss ||
            !animationConfig.exitDuration) {
            this._finishRippleTransition(rippleRef);
        }
    }
    fadeOutAll() {
        this._getActiveRipples().forEach((ripple) => ripple.fadeOut());
    }
    fadeOutAllNonPersistent() {
        this._getActiveRipples().forEach((ripple) => {
            if (!ripple.config.persistent) {
                ripple.fadeOut();
            }
        });
    }
    setupTriggerEvents(elementOrElementRef) {
        const element = coerceElement(elementOrElementRef);
        if (!element || element === this._triggerElement) {
            return;
        }
        this._removeTriggerEvents();
        this._triggerElement = element;
        this._registerEvents(pointerDownEvents);
    }
    handleEvent(event) {
        if (event.type === 'mousedown') {
            this._onMousedown(event);
        }
        else if (event.type === 'touchstart') {
            this._onTouchStart(event);
        }
        else if (event.type === 'keydown') {
            this._onKeyDown(event);
        }
        else {
            this._onPointerUp();
        }
        if (!this._pointerUpEventsRegistered) {
            this._registerEvents(pointerUpEvents);
            this._pointerUpEventsRegistered = true;
        }
    }
    _removeTriggerEvents() {
        if (this._triggerElement) {
            pointerDownEvents.forEach((type) => {
                this._triggerElement.removeEventListener(type, this, passiveEventOptions);
            });
            if (this._pointerUpEventsRegistered) {
                pointerUpEvents.forEach((type) => {
                    this._triggerElement.removeEventListener(type, this, passiveEventOptions);
                });
            }
        }
    }
    _finishRippleTransition(rippleRef) {
        if (rippleRef.state === 0 /* CubRippleState.FADING_IN */) {
            this._startFadeOutTransition(rippleRef);
        }
        else if (rippleRef.state === 2 /* CubRippleState.FADING_OUT */) {
            this._destroyRipple(rippleRef);
        }
    }
    _startFadeOutTransition(rippleRef) {
        const isMostRecentTransientRipple = rippleRef === this._mostRecentTransientRipple;
        const { persistent } = rippleRef.config;
        rippleRef.state = 1 /* CubRippleState.VISIBLE */;
        if (!persistent && (!isMostRecentTransientRipple || !this._isPointerDown)) {
            rippleRef.fadeOut();
        }
    }
    _destroyRipple(rippleRef) {
        const eventListeners = this._activeRipples.get(rippleRef) ?? null;
        this._activeRipples.delete(rippleRef);
        if (!this._activeRipples.size) {
            this._containerRect = null;
        }
        if (rippleRef === this._mostRecentTransientRipple) {
            this._mostRecentTransientRipple = null;
        }
        rippleRef.state = 3 /* CubRippleState.HIDDEN */;
        if (eventListeners !== null) {
            rippleRef.element.removeEventListener('transitionend', eventListeners.onTransitionEnd);
            rippleRef.element.removeEventListener('transitioncancel', eventListeners.onTransitionCancel);
        }
        rippleRef.element.remove();
    }
    _onMousedown(event) {
        const isFakeMousedown = isFakeMousedownFromScreenReader(event);
        const isSyntheticEvent = this._lastTouchStartEvent &&
            Date.now() < this._lastTouchStartEvent + ignoreMouseEventsTimeout;
        if (!this._target.rippleDisabled && !isFakeMousedown && !isSyntheticEvent) {
            this._isPointerDown = true;
            this.fadeInRipple(event.clientX, event.clientY, this._target.rippleConfig);
        }
    }
    _onTouchStart(event) {
        if (!this._target.rippleDisabled &&
            !isFakeTouchstartFromScreenReader(event)) {
            this._lastTouchStartEvent = Date.now();
            this._isPointerDown = true;
            const touches = event.changedTouches;
            for (let i = 0; i < touches.length; i++) {
                this.fadeInRipple(touches[i].clientX, touches[i].clientY, this._target.rippleConfig);
            }
        }
    }
    _onKeyDown(event) {
        const isEnterOrSpace = event.keyCode === ENTER || event.keyCode === SPACE;
        const isSyntheticEvent = this._lastTouchStartEvent &&
            Date.now() < this._lastTouchStartEvent + ignoreMouseEventsTimeout;
        if (!this._target.rippleDisabled && isEnterOrSpace && !isSyntheticEvent) {
            this._isPointerDown = true;
            this.fadeInRipple(0, 0, {
                ...this._target.rippleConfig,
                centered: true,
            });
        }
    }
    _onPointerUp() {
        if (!this._isPointerDown) {
            return;
        }
        this._isPointerDown = false;
        this._getActiveRipples().forEach((ripple) => {
            const isVisible = ripple.state === 1 /* CubRippleState.VISIBLE */ ||
                (ripple.config.terminateOnPointerUp &&
                    ripple.state === 0 /* CubRippleState.FADING_IN */);
            if (!ripple.config.persistent && isVisible) {
                ripple.fadeOut();
            }
        });
    }
    _registerEvents(eventTypes) {
        this._ngZone.runOutsideAngular(() => {
            eventTypes.forEach((type) => {
                this._triggerElement.addEventListener(type, this, passiveEventOptions);
            });
        });
    }
    _getActiveRipples() {
        return Array.from(this._activeRipples.keys());
    }
}

class CubRipple {
    get rippleConfig() {
        return {
            centered: this.centered,
            radius: this.radius,
            color: this.color,
            animation: {
                ...this._globalOptions.animation,
                ...(this._animationMode === 'NoopAnimations'
                    ? { enterDuration: 0, exitDuration: 0 }
                    : {}),
                ...this.animation,
            },
            terminateOnPointerUp: this._globalOptions.terminateOnPointerUp,
            rippleClass: {
                ripple: this.specifyClass || 'cub-ripple',
                rippleElement: 'cub-ripple-element',
            },
        };
    }
    get rippleDisabled() {
        return this.disabled || !!this._globalOptions.disabled;
    }
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        if (value) {
            this.fadeOutAllNonPersistent();
        }
        this._disabled = value;
        this._setupTriggerEventsIfEnabled();
    }
    get trigger() {
        return this._trigger || this._elementRef.nativeElement;
    }
    set trigger(trigger) {
        this._trigger = trigger;
        this._setupTriggerEventsIfEnabled();
    }
    get rippleClass() {
        return this.specifyClass;
    }
    constructor(_elementRef, ngZone, platform, globalOptions, _animationMode) {
        this._elementRef = _elementRef;
        this._animationMode = _animationMode;
        this._isInitialized = false;
        this._disabled = false;
        this.specifyClass = '';
        this.color = '';
        this.unbounded = false;
        this.centered = false;
        this.radius = 0;
        this._globalOptions = globalOptions || {};
        this._rippleRenderer = new RippleRenderer(this, ngZone, _elementRef, platform);
    }
    ngOnInit() {
        this._isInitialized = true;
        this._setupTriggerEventsIfEnabled();
    }
    ngOnDestroy() {
        this._rippleRenderer._removeTriggerEvents();
    }
    fadeOutAll() {
        this._rippleRenderer.fadeOutAll();
    }
    fadeOutAllNonPersistent() {
        this._rippleRenderer.fadeOutAllNonPersistent();
    }
    launch(configOrX, y = 0, config) {
        if (typeof configOrX === 'number') {
            return this._rippleRenderer.fadeInRipple(configOrX, y, {
                ...this.rippleConfig,
                ...config,
            });
        }
        else {
            return this._rippleRenderer.fadeInRipple(0, 0, {
                ...this.rippleConfig,
                ...configOrX,
            });
        }
    }
    _setupTriggerEventsIfEnabled() {
        if (!this.disabled && this._isInitialized) {
            this._rippleRenderer.setupTriggerEvents(this.trigger);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRipple, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.Platform }, { token: CUB_RIPPLE_GLOBAL_OPTIONS, optional: true }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubRipple, isStandalone: true, selector: "[cub-ripple], [cubRipple]", inputs: { specifyClass: ["cubRippleClass", "specifyClass"], color: ["cubRippleColor", "color"], unbounded: ["cubRippleUnbounded", "unbounded"], centered: ["cubRippleCentered", "centered"], radius: ["cubRippleRadius", "radius"], animation: ["cubRippleAnimation", "animation"], disabled: ["cubRippleDisabled", "disabled"], trigger: ["cubRippleTrigger", "trigger"] }, host: { properties: { "class.cub-ripple-disabled": "disabled", "class.cub-ripple-unbounded": "unbounded", "class": "this.rippleClass" }, classAttribute: "cub-ripple" }, exportAs: ["cubRipple"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRipple, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cub-ripple], [cubRipple]',
                    exportAs: 'cubRipple',
                    host: {
                        class: 'cub-ripple',
                        '[class.cub-ripple-disabled]': 'disabled',
                        '[class.cub-ripple-unbounded]': 'unbounded',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.Platform }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_RIPPLE_GLOBAL_OPTIONS]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { specifyClass: [{
                type: Input,
                args: ['cubRippleClass']
            }], color: [{
                type: Input,
                args: ['cubRippleColor']
            }], unbounded: [{
                type: Input,
                args: ['cubRippleUnbounded']
            }], centered: [{
                type: Input,
                args: ['cubRippleCentered']
            }], radius: [{
                type: Input,
                args: ['cubRippleRadius']
            }], animation: [{
                type: Input,
                args: ['cubRippleAnimation']
            }], disabled: [{
                type: Input,
                args: ['cubRippleDisabled']
            }], trigger: [{
                type: Input,
                args: ['cubRippleTrigger']
            }], rippleClass: [{
                type: HostBinding,
                args: ['class']
            }] } });

class CubRippleModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRippleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubRippleModule, imports: [CubRipple], exports: [CubRipple] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRippleModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRippleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubRipple],
                    exports: [CubRipple],
                }]
        }] });

class CubTemplate {
    constructor(template) {
        this.template = template;
    }
    getType() {
        return this.name;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTemplate, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTemplate, isStandalone: true, selector: "[cubTemplate]", inputs: { name: ["cubTemplate", "name"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTemplate, decorators: [{
            type: Directive,
            args: [{ selector: '[cubTemplate]' }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { name: [{
                type: Input,
                args: ['cubTemplate']
            }] } });

class CubTemplateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTemplateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTemplateModule, imports: [CubTemplate], exports: [CubTemplate] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTemplateModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTemplateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubTemplate],
                    exports: [CubTemplate],
                }]
        }] });

class CubDarkModeToggler {
    constructor() {
        this.isDark = false;
        this.disabled = false;
    }
    toggle(event) {
        if (this.isEnabled()) {
            this.isDark = !this.isDark;
            document.documentElement.setAttribute('theme-mode', this.isDark ? 'dark' : 'light');
            event.preventDefault();
        }
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDarkModeToggler, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDarkModeToggler, isStandalone: true, selector: "[cubDarkModeToggler]", inputs: { isDark: "isDark", disabled: "disabled" }, host: { attributes: { "tabindex": "0" }, listeners: { "click": "toggle($event)", "keydown.enter": "toggle($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDarkModeToggler, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubDarkModeToggler]',
                    host: {
                        tabindex: '0',
                        '(click)': 'toggle($event)',
                        '(keydown.enter)': 'toggle($event)',
                    }
                }]
        }], ctorParameters: () => [], propDecorators: { isDark: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/**
 * Copied from https://github.com/angular/material.angular.io/blob/master/src/app/shared/style-manager/style-manager.ts
 * TODO(@SiddAjmera): Give proper attribution here
 */
class CubStyleManagerService {
    constructor() { }
    /**
     * Set the stylesheet with the specified key.
     */
    setStyle(key, href) {
        getLinkElementForKey(key).setAttribute('href', href);
    }
    /**
     * Remove the stylesheet with the specified key.
     */
    removeStyle(key) {
        const existingLinkElement = getExistingLinkElementByKey(key);
        if (existingLinkElement) {
            document.head.removeChild(existingLinkElement);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStyleManagerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStyleManagerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStyleManagerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
function getLinkElementForKey(key) {
    return getExistingLinkElementByKey(key) || createLinkElementWithKey(key);
}
function getExistingLinkElementByKey(key) {
    return document.head.querySelector(`link[rel="stylesheet"].${getClassNameForKey(key)}`);
}
function createLinkElementWithKey(key) {
    const linkEl = document.createElement('link');
    linkEl.setAttribute('rel', 'stylesheet');
    linkEl.classList.add(getClassNameForKey(key));
    document.head.appendChild(linkEl);
    return linkEl;
}
function getClassNameForKey(key) {
    return `style-manager-${key}`;
}

class CubThemeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubThemeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubThemeModule, imports: [CubDarkModeToggler], exports: [CubDarkModeToggler] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubThemeModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubThemeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubDarkModeToggler],
                    exports: [CubDarkModeToggler],
                }]
        }] });

// 該檔案由 PrimeNG v14.2.3 複製而來
class TranslationKeys {
    static { this.STARTS_WITH = 'startsWith'; }
    static { this.CONTAINS = 'contains'; }
    static { this.NOT_CONTAINS = 'notContains'; }
    static { this.ENDS_WITH = 'endsWith'; }
    static { this.EQUALS = 'equals'; }
    static { this.NOT_EQUALS = 'notEquals'; }
    static { this.NO_FILTER = 'noFilter'; }
    static { this.LT = 'lt'; }
    static { this.LTE = 'lte'; }
    static { this.GT = 'gt'; }
    static { this.GTE = 'gte'; }
    static { this.IS = 'is'; }
    static { this.IS_NOT = 'isNot'; }
    static { this.BEFORE = 'before'; }
    static { this.AFTER = 'after'; }
    static { this.CLEAR = 'clear'; }
    static { this.APPLY = 'apply'; }
    static { this.MATCH_ALL = 'matchAll'; }
    static { this.MATCH_ANY = 'matchAny'; }
    static { this.ADD_RULE = 'addRule'; }
    static { this.REMOVE_RULE = 'removeRule'; }
    static { this.ACCEPT = 'accept'; }
    static { this.REJECT = 'reject'; }
    static { this.CHOOSE = 'choose'; }
    static { this.UPLOAD = 'upload'; }
    static { this.CANCEL = 'cancel'; }
    static { this.DAY_NAMES = 'dayNames'; }
    static { this.DAY_NAMES_SHORT = 'dayNamesShort'; }
    static { this.DAY_NAMES_MIN = 'dayNamesMin'; }
    static { this.MONTH_NAMES = 'monthNames'; }
    static { this.MONTH_NAMES_SHORT = 'monthNamesShort'; }
    static { this.FIRST_DAY_OF_WEEK = 'firstDayOfWeek'; }
    static { this.TODAY = 'today'; }
    static { this.WEEK_HEADER = 'weekHeader'; }
    static { this.WEAK = 'weak'; }
    static { this.MEDIUM = 'medium'; }
    static { this.STRONG = 'strong'; }
    static { this.PASSWORD_PROMPT = 'passwordPrompt'; }
    static { this.EMPTY_MESSAGE = 'emptyMessage'; }
    static { this.EMPTY_FILTER_MESSAGE = 'emptyFilterMessage'; }
}
class TranslationConfig {
    constructor() {
        this.translationSource = new Subject();
        this.translationObserver = this.translationSource.asObservable();
        this.filterMatchModeOptions = {
            text: [
                FilterMatchMode.STARTS_WITH,
                FilterMatchMode.CONTAINS,
                FilterMatchMode.NOT_CONTAINS,
                FilterMatchMode.ENDS_WITH,
                FilterMatchMode.EQUALS,
                FilterMatchMode.NOT_EQUALS,
            ],
            numeric: [
                FilterMatchMode.EQUALS,
                FilterMatchMode.NOT_EQUALS,
                FilterMatchMode.LESS_THAN,
                FilterMatchMode.LESS_THAN_OR_EQUAL_TO,
                FilterMatchMode.GREATER_THAN,
                FilterMatchMode.GREATER_THAN_OR_EQUAL_TO,
            ],
            date: [
                FilterMatchMode.DATE_IS,
                FilterMatchMode.DATE_IS_NOT,
                FilterMatchMode.DATE_BEFORE,
                FilterMatchMode.DATE_AFTER,
            ],
        };
        this.translation = {
            startsWith: 'Starts with',
            contains: 'Contains',
            notContains: 'Not contains',
            endsWith: 'Ends with',
            equals: 'Equals',
            notEquals: 'Not equals',
            noFilter: 'No Filter',
            lt: 'Less than',
            lte: 'Less than or equal to',
            gt: 'Greater than',
            gte: 'Greater than or equal to',
            is: 'Is',
            isNot: 'Is not',
            before: 'Before',
            after: 'After',
            dateIs: 'Date is',
            dateIsNot: 'Date is not',
            dateBefore: 'Date is before',
            dateAfter: 'Date is after',
            clear: 'Clear',
            apply: 'Apply',
            matchAll: 'Match All',
            matchAny: 'Match Any',
            addRule: 'Add Rule',
            removeRule: 'Remove Rule',
            accept: 'Yes',
            reject: 'No',
            choose: 'Choose',
            upload: 'Upload',
            cancel: 'Cancel',
            dayNames: [
                'Sunday',
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
            ],
            dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            dayNamesMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            monthNames: [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December',
            ],
            monthNamesShort: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec',
            ],
            dateFormat: 'mm/dd/yy',
            firstDayOfWeek: 0,
            today: 'Today',
            weekHeader: 'Wk',
            weak: 'Weak',
            medium: 'Medium',
            strong: 'Strong',
            passwordPrompt: 'Enter a password',
            emptyMessage: 'No results found',
            emptyFilterMessage: 'No results found',
        };
    }
    getTranslation(key) {
        return this.translation[key];
    }
    setTranslation(value) {
        this.translation = { ...this.translation, ...value };
        this.translationSource.next(this.translation);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: TranslationConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: TranslationConfig, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: TranslationConfig, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

// 該檔案由 PrimeNG v14.2.3 複製而來
var lastId = 0;
function UniqueComponentId() {
    let prefix = 'pr_id_';
    lastId++;
    return `${prefix}${lastId}`;
}

class CubCommonModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCommonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubCommonModule, exports: [CubDividerModule,
            CubRippleModule,
            CubTemplateModule,
            CubThemeModule,
            CubPositionModule,
            CubRequiredModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCommonModule, imports: [CubDividerModule,
            CubRippleModule,
            CubTemplateModule,
            CubThemeModule,
            CubPositionModule,
            CubRequiredModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCommonModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: [
                        CubDividerModule,
                        CubRippleModule,
                        CubTemplateModule,
                        CubThemeModule,
                        CubPositionModule,
                        CubRequiredModule
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/common
 */
/* Behaviors */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_END, CUB_PREFIX, CUB_RIPPLE_GLOBAL_OPTIONS, CUB_SUFFIX, CubCommonModule, CubDarkModeToggler, CubDivider, CubDividerModule, CubEnd, CubFilterService, CubPositionModule, CubPrefix, CubRequired, CubRequiredModule, CubRipple, CubRippleModule, CubStyleManagerService, CubSuffix, CubTemplate, CubTemplateModule, CubThemeModule, DEVICE_BREAKPOINT, DomHandler, ErrorStateMatcher, FilterMatchMode, GRID_BREAKPOINT, ObjectUtils, RippleRef, RippleRenderer, ShowOnDirtyErrorStateMatcher, TranslationConfig, TranslationKeys, UniqueComponentId, defaultRippleAnimationConfig, defaultRippleClassConfig, distanceToFurthestCorner, ignoreMouseEventsTimeout, isIOSMobileDevice, isMobileDevice, lastId, mixinColor, mixinDisableRipple, mixinDisabled, mixinErrorState, mixinTabIndex, passiveEventOptions, pointerDownEvents, pointerUpEvents, setViewHeight, setViewWidth };
//# sourceMappingURL=cub-lib-view-rootng-component-common.mjs.map
