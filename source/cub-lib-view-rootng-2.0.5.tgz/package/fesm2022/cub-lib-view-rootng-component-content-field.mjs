import * as i0 from '@angular/core';
import { ContentChild, Input, Component, NgModule } from '@angular/core';
import { NgIf } from '@angular/common';
import { CubLabel, CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubCommonModule } from 'cub-lib-view-rootng/component/common';

class CubContentField {
    constructor() {
        /**
           元件方向，預設為 'vertical'。
           */
        this.orientation = 'vertical';
        /**
             元件尺寸，預設為 'medium'。
             */
        this.size = 'medium';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubContentField, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubContentField, isStandalone: true, selector: "cub-content-field", inputs: { orientation: "orientation", size: "size" }, host: { properties: { "class.cub-content-field-horizontal": "orientation === \"horizontal\"", "class.cub-content-field-small": "size === \"small\"" }, classAttribute: "cub-content-field" }, queries: [{ propertyName: "_labelChildStatic", first: true, predicate: CubLabel, descendants: true, static: true }], exportAs: ["cubContentField"], ngImport: i0, template: "<ng-container *ngIf=\"_labelChildStatic\">\n  <ng-content select=\"cub-label\"></ng-content>\n</ng-container>\n\n<div class=\"cub-content-field-content\">\n  <ng-content></ng-content>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubContentField, decorators: [{
            type: Component,
            args: [{ selector: 'cub-content-field', exportAs: 'cubContentField', host: {
                        class: 'cub-content-field',
                        '[class.cub-content-field-horizontal]': 'orientation === "horizontal"',
                        '[class.cub-content-field-small]': 'size === "small"',
                    }, imports: [NgIf], template: "<ng-container *ngIf=\"_labelChildStatic\">\n  <ng-content select=\"cub-label\"></ng-content>\n</ng-container>\n\n<div class=\"cub-content-field-content\">\n  <ng-content></ng-content>\n</div>\n" }]
        }], propDecorators: { orientation: [{
                type: Input
            }], size: [{
                type: Input
            }], _labelChildStatic: [{
                type: ContentChild,
                args: [CubLabel, { static: true }]
            }] } });

class CubContentFieldModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubContentFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubContentFieldModule, imports: [CubCommonModule, CubLabelModule, CubContentField], exports: [CubCommonModule, CubLabelModule, CubContentField] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubContentFieldModule, imports: [CubCommonModule, CubLabelModule, CubCommonModule, CubLabelModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubContentFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubCommonModule, CubLabelModule, CubContentField],
                    exports: [CubCommonModule, CubLabelModule, CubContentField],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/content-field
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubContentField, CubContentFieldModule };
//# sourceMappingURL=cub-lib-view-rootng-component-content-field.mjs.map
