import * as i0 from '@angular/core';
import { InjectionToken, inject, LOCALE_ID, Optional, Inject, Injectable, EventEmitter, Output, Input, ChangeDetectionStrategy, ViewEncapsulation, Component, DOCUMENT, ViewChild, HostListener, Directive, ContentChild, forwardRef, NgModule } from '@angular/core';
import { NgIf, NgFor, NgStyle, NgClass, NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';
import { ENTER, PAGE_DOWN, PAGE_UP, END, HOME, DOWN_ARROW, UP_ARROW, RIGHT_ARROW, LEFT_ARROW, hasModifierKey, ESCAPE } from 'cub-lib-view-rootng/cdk/keycodes';
import { coerceBooleanProperty, coerceStringArray } from 'cub-lib-view-rootng/cdk/coercion';
import { mixinColor, CubRipple, CubDivider, DEVICE_BREAKPOINT, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import { CubIconButton } from 'cub-lib-view-rootng/component/button';
import { trigger, transition, animate, keyframes, style, state } from '@angular/animations';
import * as i1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, OverlayConfig, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { Subject, Subscription, merge, takeUntil, of } from 'rxjs';
import * as _moment from 'moment';
import _moment__default from 'moment';
import { CubPopover, CubPopoverTrigger, CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER } from 'cub-lib-view-rootng/component/popover';
import * as i1$1 from 'cub-lib-view-rootng/cdk/platform';
import { normalizePassiveListenerOptions, _getFocusedElementPierceShadowDom } from 'cub-lib-view-rootng/cdk/platform';
import { CubCdkTrapFocus } from 'cub-lib-view-rootng/cdk/a11y';
import { take, filter } from 'rxjs/operators';
import { ComponentPortal } from 'cub-lib-view-rootng/cdk/portal';
import * as i3 from 'cub-lib-view-rootng/cdk/bidi';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, Validators } from '@angular/forms';
import { CUB_INPUT_VALUE_ACCESSOR, CubInputModule } from 'cub-lib-view-rootng/component/input';
import * as i2 from 'cub-lib-view-rootng/component/form-field';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputGroupModule } from 'cub-lib-view-rootng/component/input-group';

function CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition();
}
function isSameMultiYearView(dateAdapter, date1, date2, minDate, maxDate) {
    const year1 = dateAdapter.getYear(date1);
    const year2 = dateAdapter.getYear(date2);
    const startingYear = getStartingYear(dateAdapter, minDate, maxDate);
    return (Math.floor((year1 - startingYear) / yearsPerPage) ===
        Math.floor((year2 - startingYear) / yearsPerPage));
}
/** @docs-private */
function createMissingDateImplError(provider) {
    return Error(`CubDatetimepicker: No provider found for ${provider}. You must import one of the following ` +
        `modules at your application root: CubNativeDatetimeModule, CubMomentDatetimeModule, or provide a ` +
        `custom implementation.`);
}
/** Gets remainder that is non-negative, even if first number is negative */
function euclideanModulo(a, b) {
    return ((a % b) + b) % b;
}
/**
 * When the multi-year view is first opened, the active year will be in view.
 * So we compute how many years are between the active year and the *slot* where our
 * "startingYear" will render when paged into view.
 */
function getActiveOffset(dateAdapter, activeDate, minDate, maxDate) {
    const activeYear = dateAdapter.getYear(activeDate);
    return euclideanModulo(activeYear - getStartingYear(dateAdapter, minDate, maxDate), yearsPerPage);
}
/**
 * We pick a "starting" year such that either the maximum year would be at the end
 * or the minimum year would be at the beginning of a page.
 */
function getStartingYear(dateAdapter, minDate, maxDate) {
    let startingYear = 0;
    if (maxDate) {
        const maxYear = dateAdapter.getYear(maxDate);
        startingYear = maxYear - yearsPerPage + 1;
    }
    else if (minDate) {
        startingYear = dateAdapter.getYear(minDate);
    }
    return startingYear;
}
/** Returns whether an event is a touch event. */
function isTouchEvent(event) {
    // This function is called for every pixel that the user has dragged so we need it to be
    // as fast as possible. Since we only bind mouse events and touch events, we can assume
    // that if the event's name starts with `t`, it's a touch event.
    return event.type[0] === 't';
}
/** Gets the coordinates of a touch or mouse event relative to the document. */
function getPointerPositionOnPage(event) {
    let point;
    if (isTouchEvent(event)) {
        // `touches` will be empty for start/end events so we have to fall back to `changedTouches`.
        point = event.touches[0] || event.changedTouches[0];
    }
    else {
        point = event;
    }
    return point;
}

/** InjectionToken for datepicker that can be used to override default locale code. */
const CUB_DATE_LOCALE = new InjectionToken('CUB_DATE_LOCALE', {
    providedIn: 'root',
    factory: CUB_DATE_LOCALE_FACTORY,
});
/** @docs-private */
function CUB_DATE_LOCALE_FACTORY() {
    return inject(LOCALE_ID);
}
/** Adapts type `D` to be usable as a date by cub-cdk-based components that work with dates. */
class CubDateAdapter {
    constructor() {
        this._localeChanges = new Subject();
        /* eslint-disable */
        /** A stream that emits when the locale changes. */
        this.localeChanges = this._localeChanges;
    }
    /**
     * Given a potential date object, returns that same date object if it is
     * a valid date, or `null` if it's not a valid date.
     * @param obj The object to check.
     * @returns A date or `null`.
     */
    getValidDateOrNull(obj) {
        return this.isDateInstance(obj) && this.isValid(obj)
            ? obj
            : null;
    }
    /**
     * Attempts to deserialize a value to a valid date object. This is different from parsing in that
     * deserialize should only accept non-ambiguous, locale-independent formats (e.g. a ISO 8601
     * string). The default implementation does not allow any deserialization, it simply checks that
     * the given value is already a valid date object or null. The `<cub-datetimepicker>` will call this
     * method on all of its `@Input()` properties that accept dates. It is therefore possible to
     * support passing values from your backend directly to these properties by overriding this method
     * to also deserialize the format used by your backend.
     * @param value The value to be deserialized into a date object.
     * @returns The deserialized date object, either a valid date, null if the value can be
     *     deserialized into a null date (e.g. the empty string), or an invalid date.
     */
    deserialize(value) {
        if (value == null || (this.isDateInstance(value) && this.isValid(value))) {
            return value;
        }
        return this.invalid();
    }
    /**
     * Sets the locale used for all dates.
     * @param locale The new locale.
     */
    setLocale(locale) {
        this.locale = locale;
        this._localeChanges.next();
    }
    /**
     * Compares two dates.
     * @param first The first date to compare.
     * @param second The second date to compare.
     * @returns 0 if the dates are equal, a number less than 0 if the first date is earlier,
     *     a number greater than 0 if the first date is later.
     */
    compareDate(first, second) {
        return (this.getYear(first) - this.getYear(second) ||
            this.getMonth(first) - this.getMonth(second) ||
            this.getDate(first) - this.getDate(second));
    }
    /**
     * Checks if two dates are equal.
     * @param first The first date to check.
     * @param second The second date to check.
     * @returns Whether the two dates are equal.
     *     Null dates are considered equal to other null dates.
     */
    sameDate(first, second) {
        if (first && second) {
            let firstValid = this.isValid(first);
            let secondValid = this.isValid(second);
            if (firstValid && secondValid) {
                return !this.compareDate(first, second);
            }
            return firstValid == secondValid;
        }
        return first == second;
    }
    /**
     * Clamp the given date between min and max dates.
     * @param date The date to clamp.
     * @param min The minimum value to allow. If null or omitted no min is enforced.
     * @param max The maximum value to allow. If null or omitted no max is enforced.
     * @returns `min` if `date` is less than `min`, `max` if date is greater than `max`,
     *     otherwise `date`.
     */
    clampDate(date, min, max) {
        if (min && this.compareDate(date, min) < 0) {
            return min;
        }
        if (max && this.compareDate(date, max) > 0) {
            return max;
        }
        return date;
    }
}

const CUB_DATETIME_FORMATS = new InjectionToken('cub-datetime-formats');

const moment$1 = _moment__default || _moment;
/** InjectionToken for moment date adapter to configure options. */
const CUB_MOMENT_DATE_ADAPTER_OPTIONS = new InjectionToken('CUB_MOMENT_DATE_ADAPTER_OPTIONS', {
    providedIn: 'root',
    factory: CUB_MOMENT_DATE_ADAPTER_OPTIONS_FACTORY,
});
/** @docs-private */
function CUB_MOMENT_DATE_ADAPTER_OPTIONS_FACTORY() {
    return {
        useUtc: false,
    };
}
/** Creates an array and fills it with values. */
function range$3(length, valueFunction) {
    const valuesArray = Array(length);
    for (let i = 0; i < length; i++) {
        valuesArray[i] = valueFunction(i);
    }
    return valuesArray;
}
class CubMomentDateAdapter extends CubDateAdapter {
    constructor(dateLocale, _options) {
        super();
        this._options = _options;
        this.setLocale(dateLocale || moment$1.locale());
    }
    setLocale(locale) {
        super.setLocale(locale);
        let momentLocaleData = moment$1.localeData(locale);
        this._localeData = {
            firstDayOfWeek: momentLocaleData.firstDayOfWeek(),
            longMonths: momentLocaleData.months(),
            shortMonths: momentLocaleData.monthsShort(),
            dates: range$3(31, (i) => this.createDate(2017, 0, i + 1).format('D')),
            longDaysOfWeek: momentLocaleData.weekdays(),
            shortDaysOfWeek: momentLocaleData.weekdaysShort(),
            narrowDaysOfWeek: momentLocaleData.weekdaysMin(),
        };
    }
    getYear(date) {
        return this.clone(date).year();
    }
    getMonth(date) {
        return this.clone(date).month();
    }
    getDate(date) {
        return this.clone(date).date();
    }
    getDayOfWeek(date) {
        return this.clone(date).day();
    }
    getMonthNames(style) {
        // Moment.js doesn't support narrow month names, so we just use short if narrow is requested.
        return style == 'long'
            ? this._localeData.longMonths
            : this._localeData.shortMonths;
    }
    getDateNames() {
        return this._localeData.dates;
    }
    getDayOfWeekNames(style) {
        if (style == 'long') {
            return this._localeData.longDaysOfWeek;
        }
        if (style == 'short') {
            return this._localeData.shortDaysOfWeek;
        }
        return this._localeData.narrowDaysOfWeek;
    }
    getYearName(date) {
        return this.clone(date).format('YYYY');
    }
    getFirstDayOfWeek() {
        return this._localeData.firstDayOfWeek;
    }
    getNumDaysInMonth(date) {
        return this.clone(date).daysInMonth();
    }
    clone(date) {
        return date.clone().locale(this.locale);
    }
    createDate(year, month, date) {
        // Moment.js will create an invalid date if any of the components are out of bounds, but we
        // explicitly check each case so we can throw more descriptive errors.
        if (month < 0 || month > 11) {
            throw Error(`Invalid month index "${month}". Month index has to be between 0 and 11.`);
        }
        if (date < 1) {
            throw Error(`Invalid date "${date}". Date has to be greater than 0.`);
        }
        const result = this._createMoment({ year, month, date }).locale(this.locale);
        // If the result isn't valid, the date must have been out of bounds for this month.
        if (!result.isValid()) {
            throw Error(`Invalid date "${date}" for month with index "${month}".`);
        }
        return result;
    }
    today() {
        return this._createMoment().locale(this.locale);
    }
    parse(value, parseFormat) {
        if (value && typeof value == 'string') {
            return this._createMoment(value, parseFormat, this.locale);
        }
        return value ? this._createMoment(value).locale(this.locale) : null;
    }
    format(date, displayFormat) {
        date = this.clone(date);
        if (!this.isValid(date)) {
            throw Error('CubMomentDateAdapter: Cannot format invalid date.');
        }
        return date.format(displayFormat);
    }
    addCalendarYears(date, years) {
        return this.clone(date).add({ years });
    }
    addCalendarMonths(date, months) {
        return this.clone(date).add({ months });
    }
    addCalendarDays(date, days) {
        return this.clone(date).add({ days });
    }
    toIso8601(date) {
        return this.clone(date).format();
    }
    /**
     * Returns the given value if given a valid Moment or null. Deserializes valid ISO 8601 strings
     * (https://www.ietf.org/rfc/rfc3339.txt) and valid Date objects into valid Moments and empty
     * string into null. Returns an invalid date for all other values.
     */
    deserialize(value) {
        let date;
        if (value instanceof Date) {
            date = this._createMoment(value).locale(this.locale);
        }
        else if (this.isDateInstance(value)) {
            // Note: assumes that cloning also sets the correct locale.
            return this.clone(value);
        }
        if (typeof value === 'string') {
            if (!value) {
                return null;
            }
            date = this._createMoment(value, moment$1.ISO_8601).locale(this.locale);
        }
        if (date && this.isValid(date)) {
            return this._createMoment(date).locale(this.locale);
        }
        return super.deserialize(value);
    }
    isDateInstance(obj) {
        return moment$1.isMoment(obj);
    }
    isValid(date) {
        return this.clone(date).isValid();
    }
    invalid() {
        return moment$1.invalid();
    }
    /** Creates a Moment instance while respecting the current UTC settings. */
    _createMoment(date, format, locale) {
        const { strict, useUtc } = this._options || {};
        return useUtc
            ? moment$1.utc(date, format, locale, strict)
            : moment$1(date, format, locale, strict);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateAdapter, deps: [{ token: CUB_DATE_LOCALE, optional: true }, { token: CUB_MOMENT_DATE_ADAPTER_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATE_LOCALE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_MOMENT_DATE_ADAPTER_OPTIONS]
                }] }] });

class CubDatetimeAdapter extends CubDateAdapter {
    constructor(_delegate) {
        super();
        this._delegate = _delegate;
    }
    getValidDateOrNull(obj) {
        return this.isDateInstance(obj) && this.isValid(obj) ? obj : null;
    }
    clampDate(date, min, max) {
        if (min && this.compareDatetime(date, min) < 0) {
            return min;
        }
        if (max && this.compareDatetime(date, max) > 0) {
            return max;
        }
        return date;
    }
    compareDatetime(first, second, respectMinutePart = true) {
        if (respectMinutePart) {
            return (this.compareDate(first, second) ||
                this.getHour(first) - this.getHour(second) ||
                this.getMinute(first) - this.getMinute(second));
        }
        else {
            return (this.compareDate(first, second) ||
                this.getHour(first) - this.getHour(second));
        }
    }
    sameDatetime(first, second) {
        if (first && second) {
            const firstValid = this.isValid(first);
            const secondValid = this.isValid(second);
            if (firstValid && secondValid) {
                return !this.compareDatetime(first, second);
            }
            return firstValid === secondValid;
        }
        return first === second;
    }
    sameYear(first, second) {
        return first && second && this.getYear(first) === this.getYear(second);
    }
    sameDay(first, second) {
        return (first &&
            second &&
            this.getDate(first) === this.getDate(second) &&
            this.sameMonthAndYear(first, second));
    }
    sameHour(first, second) {
        return (first &&
            second &&
            this.getHour(first) === this.getHour(second) &&
            this.sameDay(first, second));
    }
    sameMinute(first, second) {
        return (first &&
            second &&
            this.getMinute(first) === this.getMinute(second) &&
            this.sameHour(first, second));
    }
    sameMonthAndYear(first, second) {
        if (first && second) {
            const firstValid = this.isValid(first);
            const secondValid = this.isValid(second);
            if (firstValid && secondValid) {
                return !(this.getYear(first) - this.getYear(second) ||
                    this.getMonth(first) - this.getMonth(second));
            }
            return firstValid === secondValid;
        }
        return first === second;
    }
    // delegate
    clone(date) {
        return this._delegate.clone(date);
    }
    addCalendarYears(date, years) {
        return this._delegate.addCalendarYears(date, years);
    }
    addCalendarMonths(date, months) {
        return this._delegate.addCalendarMonths(date, months);
    }
    addCalendarDays(date, days) {
        return this._delegate.addCalendarDays(date, days);
    }
    getYear(date) {
        return this._delegate.getYear(date);
    }
    getMonth(date) {
        return this._delegate.getMonth(date);
    }
    getDate(date) {
        return this._delegate.getDate(date);
    }
    getDayOfWeek(date) {
        return this._delegate.getDayOfWeek(date);
    }
    getMonthNames(style) {
        return this._delegate.getMonthNames(style);
    }
    getDateNames() {
        return this._delegate.getDateNames();
    }
    getDayOfWeekNames(style) {
        return this._delegate.getDayOfWeekNames(style);
    }
    getYearName(date) {
        return this._delegate.getYearName(date);
    }
    getFirstDayOfWeek() {
        return this._delegate.getFirstDayOfWeek();
    }
    getNumDaysInMonth(date) {
        return this._delegate.getNumDaysInMonth(date);
    }
    createDate(year, month, date) {
        return this._delegate.createDate(year, month, date);
    }
    today() {
        return this._delegate.today();
    }
    parse(value, parseFormat) {
        return this._delegate.parse(value, parseFormat);
    }
    format(date, displayFormat) {
        return this._delegate.format(date, displayFormat);
    }
    toIso8601(date) {
        return this._delegate.toIso8601(date);
    }
    isDateInstance(obj) {
        return this._delegate.isDateInstance(obj);
    }
    isValid(date) {
        return this._delegate.isValid(date);
    }
    invalid() {
        return this._delegate.invalid();
    }
}

const moment = 'default' in _moment ? _moment.default : _moment;
function range$2(length, valueFunction) {
    const valuesArray = Array(length);
    for (let i = 0; i < length; i++) {
        valuesArray[i] = valueFunction(i);
    }
    return valuesArray;
}
class CubMomentDatetimeAdapter extends CubDatetimeAdapter {
    constructor(cubDateLocale, cubMomentAdapterOptions, _delegate) {
        super(_delegate);
        this._useUtc = false;
        this.setLocale(cubDateLocale || moment.locale());
        this._useUtc = cubMomentAdapterOptions.useUtc;
    }
    setLocale(locale) {
        super.setLocale(locale);
        const momentLocaleData = moment.localeData(locale);
        this._localeData = {
            firstDayOfWeek: momentLocaleData.firstDayOfWeek(),
            longMonths: momentLocaleData.months(),
            shortMonths: momentLocaleData.monthsShort(),
            dates: range$2(31, (i) => super.createDate(2017, 0, i + 1).format('D')),
            hours: range$2(24, (i) => this.createDatetime(2017, 0, 1, i, 0).format('H')),
            minutes: range$2(60, (i) => this.createDatetime(2017, 0, 1, 1, i).format('m')),
            longDaysOfWeek: momentLocaleData.weekdays(),
            shortDaysOfWeek: momentLocaleData.weekdaysShort(),
            narrowDaysOfWeek: momentLocaleData.weekdaysMin(),
        };
    }
    deserialize(value) {
        return this._delegate.deserialize(value);
    }
    getHour(date) {
        return super.clone(date).hour();
    }
    getMinute(date) {
        return super.clone(date).minute();
    }
    isInNextMonth(startDate, endDate) {
        const nextMonth = this.getDateInNextMonth(startDate);
        return super.sameMonthAndYear(nextMonth, endDate);
    }
    createDatetime(year, month, date, hour, minute) {
        // Check for invalid month and date (except upper bound on date which we have to check after
        // creating the Date).
        if (month < 0 || month > 11) {
            throw Error(`Invalid month index "${month}". Month index has to be between 0 and 11.`);
        }
        if (date < 1) {
            throw Error(`Invalid date "${date}". Date has to be greater than 0.`);
        }
        if (hour < 0 || hour > 23) {
            throw Error(`Invalid hour "${hour}". Hour has to be between 0 and 23.`);
        }
        if (minute < 0 || minute > 59) {
            throw Error(`Invalid minute "${minute}". Minute has to be between 0 and 59.`);
        }
        let result = moment({ year, month, date, hour, minute });
        if (this._useUtc) {
            result = result.utc();
        }
        // If the result isn't valid, the date must have been out of bounds for this month.
        if (!result.isValid()) {
            throw Error(`Invalid date "${date}" for month with index "${month}".`);
        }
        return result;
    }
    getFirstDateOfMonth(date) {
        return super.clone(date).startOf('month');
    }
    getHourNames() {
        return this._localeData.hours;
    }
    getMinuteNames() {
        return this._localeData.minutes;
    }
    addCalendarHours(date, hours) {
        return super.clone(date).add({ hours });
    }
    addCalendarMinutes(date, minutes) {
        return super.clone(date).add({ minutes });
    }
    getDateInNextMonth(date) {
        return super.clone(date).date(1).add({ month: 1 });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeAdapter, deps: [{ token: CUB_DATE_LOCALE, optional: true }, { token: CUB_MOMENT_DATE_ADAPTER_OPTIONS, optional: true }, { token: CubDateAdapter }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATE_LOCALE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_MOMENT_DATE_ADAPTER_OPTIONS]
                }] }, { type: CubDateAdapter }] });

const CLOCK_RADIUS = 50;
const CLOCK_INNER_RADIUS = 27.5;
const CLOCK_OUTER_RADIUS = 41.25;
const CLOCK_TICK_RADIUS = 7.0833;
const DAYS_PER_WEEK = 7;
const yearsPerPage = 24;
const yearsPerRow = 4;
/**
 * Animations used by the Material datepicker.
 * @docs-private
 */
const cubDatetimepickerAnimations = {
    /** Transforms the height of the datepicker's calendar. */
    transformPanel: trigger('transformPanel', [
        transition('void => enter-dropdown', animate('0ms cubic-bezier(0, 0, 0.2, 1)', keyframes([
            style({ opacity: 0, transform: 'scale(1, 0.8)' }),
            style({ opacity: 1, transform: 'scale(1, 1)' }),
        ]))),
        transition('void => enter-dialog', animate('150ms cubic-bezier(0, 0, 0.2, 1)', keyframes([
            style({ opacity: 0, transform: 'scale(0.7)' }),
            style({ transform: 'none', opacity: 1 }),
        ]))),
        transition('* => void', animate('100ms linear', style({ opacity: 0 }))),
    ]),
    /** Fades in the content of the calendar. */
    fadeInCalendar: trigger('fadeInCalendar', [
        state('void', style({ opacity: 0 })),
        state('enter', style({ opacity: 1 })),
        // TODO(crisbeto): this animation should be removed since it isn't quite on spec, but we
        // need to keep it until #12440 gets in, otherwise the exit animation will look glitchy.
        transition('void => *', animate('120ms 100ms cubic-bezier(0.55, 0, 0.55, 0.2)')),
    ]),
    slideCalendar: trigger('slideCalendar', [
        transition('* => left', [
            animate(180, keyframes([
                style({ transform: 'translateX(100%)', offset: 0.5 }),
                style({ transform: 'translateX(-100%)', offset: 0.51 }),
                style({ transform: 'translateX(0)', offset: 1 }),
            ])),
        ]),
        transition('* => right', [
            animate(180, keyframes([
                style({ transform: 'translateX(-100%)', offset: 0.5 }),
                style({ transform: 'translateX(100%)', offset: 0.51 }),
                style({ transform: 'translateX(0)', offset: 1 }),
            ])),
        ]),
    ]),
};
// Boilerplate for applying mixins to CubDatetimepickerContent.
/** @docs-private */
const _CubDatetimepickerContentBase = mixinColor(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
});
/** Injection token that determines the scroll handling while the calendar is open. */
const CUB_DATETIMEPICKER_SCROLL_STRATEGY = new InjectionToken('cub-datetimepicker-scroll-strategy');
const CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER = {
    provide: CUB_DATETIMEPICKER_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY,
};
const CUB_DATETIME_FORMATS_CONFIG = {
    parse: {
        dateInput: 'YYYY/MM/DD',
        monthInput: 'YYYY/MM',
        yearInput: 'YYYY',
        timeInput: 'HH:mm',
        datetimeInput: 'YYYY/MM/DD HH:mm',
    },
    display: {
        dateInput: 'YYYY/MM/DD',
        monthInput: 'YYYY/MM',
        yearInput: 'YYYY',
        timeInput: 'HH:mm',
        datetimeInput: 'YYYY/MM/DD HH:mm',
        monthYearLabel: 'YYYY MMMM',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
        popupHeaderDateLabel: 'MM/DD (ddd)',
    },
};
const CUB_DATETIMEPICKER_FORMATS_PROVIDER = {
    provide: CUB_DATETIME_FORMATS,
    useValue: CUB_DATETIME_FORMATS_CONFIG,
};
const CUB_DATETIMEPICKER_MOMENT_PROVIDER_LIST = [
    CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER,
    CUB_DATETIMEPICKER_FORMATS_PROVIDER,
    {
        provide: CubDateAdapter,
        useClass: CubMomentDateAdapter,
        deps: [CUB_DATE_LOCALE, CUB_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    {
        provide: CubDatetimeAdapter,
        useClass: CubMomentDatetimeAdapter,
    },
];

var CubDatetimepickerFilterType;
(function (CubDatetimepickerFilterType) {
    CubDatetimepickerFilterType[CubDatetimepickerFilterType["DATE"] = 0] = "DATE";
    CubDatetimepickerFilterType[CubDatetimepickerFilterType["HOUR"] = 1] = "HOUR";
    CubDatetimepickerFilterType[CubDatetimepickerFilterType["MINUTE"] = 2] = "MINUTE";
})(CubDatetimepickerFilterType || (CubDatetimepickerFilterType = {}));

/**
 * An internal class that represents the data corresponding to a single calendar cell.
 * @docs-private
 */
class CubCalendarCell {
    constructor(value, displayValue, ariaLabel, enabled, events, eventsLabel, category, isToday, isSelected) {
        this.value = value;
        this.displayValue = displayValue;
        this.ariaLabel = ariaLabel;
        this.enabled = enabled;
        this.events = events;
        this.eventsLabel = eventsLabel;
        this.category = category;
        this.isToday = isToday;
        this.isSelected = isSelected;
    }
}
/** Datepicker data that requires internationalization. */
class CubDatepickerIntl {
    constructor() {
        /**
         * Stream that emits whenever the labels here are changed. Use this to notify
         * components if the labels have changed after initialization.
         */
        this.changes = new Subject();
        /** A label for the calendar popup (used by screen readers). */
        this.calendarLabel = 'Calendar';
        /** A label for the button used to open the calendar popup (used by screen readers). */
        this.openCalendarLabel = 'Open calendar';
        /** Label for the button used to close the calendar popup. */
        this.closeCalendarLabel = 'Close calendar';
        /** A label for the previous month button (used by screen readers). */
        this.prevMonthLabel = 'Previous month';
        /** A label for the next month button (used by screen readers). */
        this.nextMonthLabel = 'Next month';
        /** A label for the previous year button (used by screen readers). */
        this.prevYearLabel = 'Previous year';
        /** A label for the next year button (used by screen readers). */
        this.nextYearLabel = 'Next year';
        /** A label for the previous multi-year button (used by screen readers). */
        this.prevMultiYearLabel = 'Previous 24 years';
        /** A label for the next multi-year button (used by screen readers). */
        this.nextMultiYearLabel = 'Next 24 years';
        /** A label for the 'switch to month view' button (used by screen readers). */
        this.switchToMonthViewLabel = 'Choose date';
        /** A label for the 'switch to year view' button (used by screen readers). */
        this.switchToMultiYearViewLabel = 'Choose month and year';
        /** A label for the first date of a range of dates (used by screen readers). */
        this.startDateLabel = 'Start date';
        /** A label for the last date of a range of dates (used by screen readers). */
        this.endDateLabel = 'End date';
    }
    /** Formats a range of years (used for visuals). */
    formatYearRange(start, end) {
        return `${start} \u2013 ${end}`;
    }
    /** Formats a label for a range of years (used by screen readers). */
    formatYearRangeLabel(start, end) {
        return `${start} to ${end}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatepickerIntl, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatepickerIntl, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatepickerIntl, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * An internal component used to display calendar data in a table.
 * @docs-private
 */
class CubCalendarBody {
    constructor() {
        /** 表格的列數，預設為 7。 */
        this.numCols = 7;
        /** 是否允許選擇已停用的儲存格，預設為 false。 */
        this.allowDisabledSelection = false;
        /** 表格中 Activ 狀態的儲存格編號，預設為 0。 */
        this.activeCell = 0;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 當選定日期時間變更時發出通知。 */
        this.selectedValueChange = new EventEmitter();
    }
    /** The number of blank cells to put at the beginning for the first row. */
    get _firstRowOffset() {
        return this.rows && this.rows.length && this.rows[0].length
            ? this.numCols - this.rows[0].length
            : 0;
    }
    _cellClicked(cell) {
        if (!this.allowDisabledSelection && !cell.enabled) {
            return;
        }
        this.selectedValueChange.emit(cell);
    }
    _isActiveCell(rowIndex, colIndex) {
        let cellNumber = rowIndex * this.numCols + colIndex;
        // Account for the fact that the first row may not have as many cells.
        if (rowIndex) {
            cellNumber -= this._firstRowOffset;
        }
        return cellNumber === this.activeCell;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCalendarBody, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubCalendarBody, isStandalone: true, selector: "[cub-calendar-body]", inputs: { label: "label", rows: "rows", todayValue: "todayValue", selectedValue: "selectedValue", labelMinRequiredCells: "labelMinRequiredCells", numCols: "numCols", allowDisabledSelection: "allowDisabledSelection", activeCell: "activeCell", size: "size" }, outputs: { selectedValueChange: "selectedValueChange" }, host: { properties: { "class.cub-calendar-body-small": "size === \"small\"" }, classAttribute: "cub-calendar-body" }, exportAs: ["cubCalendarBody"], ngImport: i0, template: "<!--\n  If there's not enough space in the first row, create a separate label row. We mark this row as\n  aria-hidden because we don't want it to be read out as one of the weeks in the month.\n-->\n<tr *ngIf=\"_firstRowOffset < labelMinRequiredCells\" aria-hidden=\"true\">\n  <td class=\"cub-calendar-body-label\" [attr.colspan]=\"numCols\">\n    <!-- \u76EE\u524D\u4E0D\u9700\u8981 label -->\n    <!-- {{ label }} -->\n  </td>\n</tr>\n\n<!-- Create the first row separately so we can include a special spacer cell. -->\n<tr *ngFor=\"let row of rows; let rowIndex = index\" role=\"row\">\n  <!--\n    We mark this cell as aria-hidden so it doesn't get read out as one of the days in the week.\n  -->\n  <td\n    *ngIf=\"rowIndex === 0 && _firstRowOffset\"\n    class=\"cub-calendar-body-label\"\n    aria-hidden=\"true\"\n    [attr.colspan]=\"_firstRowOffset\"\n  >\n    <!-- \u76EE\u524D\u4E0D\u9700\u8981 label -->\n    <!-- {{ _firstRowOffset >= labelMinRequiredCells ? label : \"\" }} -->\n  </td>\n  <td\n    *ngFor=\"let item of row; let colIndex = index\"\n    role=\"gridcell\"\n    class=\"cub-calendar-body-cell\"\n    [tabindex]=\"-1\"\n    [class.cub-active]=\"_isActiveCell(rowIndex, colIndex)\"\n    [class.cub-disabled]=\"!item.enabled\"\n    [attr.data-cub-row]=\"rowIndex\"\n    [attr.data-cub-col]=\"colIndex\"\n    [attr.aria-label]=\"item.ariaLabel\"\n    [attr.aria-disabled]=\"!item.enabled || null\"\n    (click)=\"_cellClicked(item)\"\n  >\n    <div\n      cubRipple\n      class=\"cub-calendar-body-cell-content\"\n      cubRippleClass=\"cub-calendar-body-cell-content-ripple\"\n      [class.cub-selected]=\"item.isSelected\"\n      [class.cub-calendar-body-today]=\"item.isToday\"\n      [class.cub-calendar-body-event]=\"item.events.length > 0\"\n      [class.cub-calendar-body-other]=\"item.category !== 'current'\"\n      [attr.aria-selected]=\"item.isSelected\"\n      [cubPopoverTriggerFor]=\"eventPopover\"\n      [cubPopoverDisabled]=\"item.events.length === 0\"\n    >\n      {{ item.displayValue }}\n\n      <cub-popover\n        #eventPopover\n        positionStart=\"after\"\n        positionEnd=\"center\"\n        triggerEvent=\"hover\"\n        [xOffset]=\"12\"\n      >\n        <div class=\"cub-overlay-calendar-event\">\n          <div class=\"cub-overlay-calendar-event-label\">\n            {{ item.eventsLabel }}\n          </div>\n          <ul class=\"cub-unordered-list-small cub-overlay-calendar-event-list\">\n            <li *ngFor=\"let event of item.events; let rowIndex = index\">\n              {{ event }}\n            </li>\n          </ul>\n        </div>\n      </cub-popover>\n\n      <span\n        class=\"cub-persistent-ripple cub-calendar-body-cell-content-persistent-ripple\"\n      ></span>\n    </div>\n  </td>\n</tr>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "component", type: CubPopover, selector: "cub-popover", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "enterDelay", "leaveDelay", "positionStart", "positionEnd", "xOffset", "yOffset", "autoFocus", "hasBackdrop", "hasArrow", "triggerEvent", "closeOnPanelClick", "closeOnBackdropClick"], outputs: ["closed"], exportAs: ["cubPopover"] }, { kind: "directive", type: CubPopoverTrigger, selector: "[cub-popover-trigger-for], [cubPopoverTriggerFor]", inputs: ["cubPopoverTriggerFor", "cubPopoverDisabled", "cubPopoverData", "cubPopoverConnectedTo", "cubPopoverHasArrow"], outputs: ["cubPopoverOpened", "cubPopoverClosed"], exportAs: ["cubPopoverTrigger"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCalendarBody, decorators: [{
            type: Component,
            args: [{ selector: '[cub-calendar-body]', host: {
                        class: 'cub-calendar-body',
                        '[class.cub-calendar-body-small]': 'size === "small"',
                    }, exportAs: 'cubCalendarBody', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, CubRipple, CubPopover, CubPopoverTrigger], template: "<!--\n  If there's not enough space in the first row, create a separate label row. We mark this row as\n  aria-hidden because we don't want it to be read out as one of the weeks in the month.\n-->\n<tr *ngIf=\"_firstRowOffset < labelMinRequiredCells\" aria-hidden=\"true\">\n  <td class=\"cub-calendar-body-label\" [attr.colspan]=\"numCols\">\n    <!-- \u76EE\u524D\u4E0D\u9700\u8981 label -->\n    <!-- {{ label }} -->\n  </td>\n</tr>\n\n<!-- Create the first row separately so we can include a special spacer cell. -->\n<tr *ngFor=\"let row of rows; let rowIndex = index\" role=\"row\">\n  <!--\n    We mark this cell as aria-hidden so it doesn't get read out as one of the days in the week.\n  -->\n  <td\n    *ngIf=\"rowIndex === 0 && _firstRowOffset\"\n    class=\"cub-calendar-body-label\"\n    aria-hidden=\"true\"\n    [attr.colspan]=\"_firstRowOffset\"\n  >\n    <!-- \u76EE\u524D\u4E0D\u9700\u8981 label -->\n    <!-- {{ _firstRowOffset >= labelMinRequiredCells ? label : \"\" }} -->\n  </td>\n  <td\n    *ngFor=\"let item of row; let colIndex = index\"\n    role=\"gridcell\"\n    class=\"cub-calendar-body-cell\"\n    [tabindex]=\"-1\"\n    [class.cub-active]=\"_isActiveCell(rowIndex, colIndex)\"\n    [class.cub-disabled]=\"!item.enabled\"\n    [attr.data-cub-row]=\"rowIndex\"\n    [attr.data-cub-col]=\"colIndex\"\n    [attr.aria-label]=\"item.ariaLabel\"\n    [attr.aria-disabled]=\"!item.enabled || null\"\n    (click)=\"_cellClicked(item)\"\n  >\n    <div\n      cubRipple\n      class=\"cub-calendar-body-cell-content\"\n      cubRippleClass=\"cub-calendar-body-cell-content-ripple\"\n      [class.cub-selected]=\"item.isSelected\"\n      [class.cub-calendar-body-today]=\"item.isToday\"\n      [class.cub-calendar-body-event]=\"item.events.length > 0\"\n      [class.cub-calendar-body-other]=\"item.category !== 'current'\"\n      [attr.aria-selected]=\"item.isSelected\"\n      [cubPopoverTriggerFor]=\"eventPopover\"\n      [cubPopoverDisabled]=\"item.events.length === 0\"\n    >\n      {{ item.displayValue }}\n\n      <cub-popover\n        #eventPopover\n        positionStart=\"after\"\n        positionEnd=\"center\"\n        triggerEvent=\"hover\"\n        [xOffset]=\"12\"\n      >\n        <div class=\"cub-overlay-calendar-event\">\n          <div class=\"cub-overlay-calendar-event-label\">\n            {{ item.eventsLabel }}\n          </div>\n          <ul class=\"cub-unordered-list-small cub-overlay-calendar-event-list\">\n            <li *ngFor=\"let event of item.events; let rowIndex = index\">\n              {{ event }}\n            </li>\n          </ul>\n        </div>\n      </cub-popover>\n\n      <span\n        class=\"cub-persistent-ripple cub-calendar-body-cell-content-persistent-ripple\"\n      ></span>\n    </div>\n  </td>\n</tr>\n" }]
        }], propDecorators: { label: [{
                type: Input
            }], rows: [{
                type: Input
            }], todayValue: [{
                type: Input
            }], selectedValue: [{
                type: Input
            }], labelMinRequiredCells: [{
                type: Input
            }], numCols: [{
                type: Input
            }], allowDisabledSelection: [{
                type: Input
            }], activeCell: [{
                type: Input
            }], size: [{
                type: Input
            }], selectedValueChange: [{
                type: Output
            }] } });

/**
 * An internal component used to display a single month in the datetimepicker.
 * @docs-private
 */
class CubMonthView {
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate() {
        return this._activeDate;
    }
    set activeDate(value) {
        const oldActiveDate = this._activeDate;
        this._activeDate = value || this._adapter.today();
        if (oldActiveDate &&
            this._activeDate &&
            !this._adapter.sameMonthAndYear(oldActiveDate, this._activeDate)) {
            this._init();
            if (this._adapter.isInNextMonth(oldActiveDate, this._activeDate)) {
                this.calendarState('right');
            }
            else {
                this.calendarState('left');
            }
        }
    }
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = value;
        this._selectedDate = this._getDateInCurrentMonth(this.selected);
        this._createWeekCells();
    }
    constructor(_adapter, _dateFormats) {
        this._adapter = _adapter;
        this._dateFormats = _dateFormats;
        this.numRows = 6;
        /** 事件清單，預設為 []。 */
        this.events = [];
        /** 元件的類型，預設為 'date'。 */
        this.type = 'date';
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 是否為內嵌模式，預設為 false。 */
        this.isInline = false;
        /** 當選定日期時間變更時發出通知。 */
        this.selectedChange = new EventEmitter();
        /** 當使用者選擇日期時間時發出通知。 */
        this.userSelection = new EventEmitter();
        if (!this._adapter) {
            throw createMissingDateImplError('CubDatetimeAdapter');
        }
        if (!this._dateFormats) {
            throw createMissingDateImplError('CUB_DATETIME_FORMATS');
        }
        const firstDayOfWeek = this._adapter.getFirstDayOfWeek();
        const narrowWeekdays = this._adapter.getDayOfWeekNames('narrow');
        const longWeekdays = this._adapter.getDayOfWeekNames('long');
        // Rotate the labels for days of the week based on the configured first day of the week.
        const weekdays = longWeekdays.map((long, i) => {
            return { long, narrow: narrowWeekdays[i] };
        });
        this._weekdays = weekdays
            .slice(firstDayOfWeek)
            .concat(weekdays.slice(0, firstDayOfWeek));
        this._activeDate = this._adapter.today();
    }
    ngAfterContentInit() {
        this._init();
    }
    /** Handles when a new date is selected. */
    _dateSelected(cell) {
        let date = cell.value;
        if (cell.category === 'previous') {
            this.activeDate = this._adapter.addCalendarMonths(this.activeDate, -1);
        }
        else if (cell.category === 'next') {
            this.activeDate = this._adapter.addCalendarMonths(this.activeDate, 1);
        }
        this.selectedChange.emit(this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), date, this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate)));
        if (this.type === 'date') {
            this.userSelection.emit();
        }
    }
    _calendarStateDone() {
        this._calendarState = '';
    }
    calendarState(direction) {
        this._calendarState = direction;
    }
    /** Initializes this month view. */
    _init() {
        this._selectedDate = this._getDateInCurrentMonth(this.selected);
        this._todayDate = this._getDateInCurrentMonth(this._adapter.today());
        const firstOfMonth = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), 1, this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate));
        const lastOfMonth = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), this._adapter.getNumDaysInMonth(this.activeDate), this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate));
        this._firstWeekOffset =
            (DAYS_PER_WEEK +
                this._adapter.getDayOfWeek(firstOfMonth) -
                this._adapter.getFirstDayOfWeek()) %
                DAYS_PER_WEEK;
        this._lastWeekOffset =
            DAYS_PER_WEEK - this._adapter.getDayOfWeek(lastOfMonth) - 1;
        this._createWeekCells();
    }
    /** Creates MdCalendarCells for the dates in this month. */
    _createWeekCells() {
        const daysInMonth = this._adapter.getNumDaysInMonth(this.activeDate);
        const daysInPreviousMonth = this._adapter.getNumDaysInMonth(this._adapter.addCalendarMonths(this.activeDate, -1));
        const dateNames = this._adapter.getDateNames();
        this._weeks = [[]];
        for (let i = 0, cell = this._firstWeekOffset; i < daysInMonth; i++, cell++) {
            if (cell === DAYS_PER_WEEK) {
                this._weeks.push([]);
                cell = 0;
            }
            const date = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), i + 1, this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate));
            const enabled = !this.dateFilter || this.dateFilter(date);
            const ariaLabel = this._adapter.format(date, this._dateFormats.display.dateA11yLabel);
            const eventsLabel = this._adapter.format(date, this._dateFormats.display.dateInput);
            let events = [];
            this.events.forEach((event) => {
                if (this._adapter.sameDate(event.date, date)) {
                    events.push(event.content);
                }
            });
            const isToday = this._adapter.sameDate(date, this._adapter.today());
            const isSelected = this._adapter.sameDate(date, this.selected);
            this._weeks[this._weeks.length - 1].push(new CubCalendarCell(i + 1, dateNames[i], ariaLabel, enabled, events, eventsLabel, 'current', isToday, isSelected));
        }
        if (this.isInline) {
            for (let i = 0; i < this._firstWeekOffset; i++) {
                const date = this._adapter.createDatetime(this._adapter.getYear(this._adapter.addCalendarMonths(this.activeDate, -1)), this._adapter.getMonth(this._adapter.addCalendarMonths(this.activeDate, -1)), daysInPreviousMonth - i, this._adapter.getHour(this._adapter.addCalendarMonths(this.activeDate, -1)), this._adapter.getMinute(this._adapter.addCalendarMonths(this.activeDate, -1)));
                const enabled = !this.dateFilter || this.dateFilter(date);
                const ariaLabel = this._adapter.format(date, this._dateFormats.display.dateA11yLabel);
                const eventsLabel = this._adapter.format(date, this._dateFormats.display.dateInput);
                let events = [];
                this.events.forEach((event) => {
                    if (this._adapter.sameDate(event.date, date)) {
                        events.push(event.content);
                    }
                });
                const isToday = this._adapter.sameDate(date, this._adapter.today());
                const isSelected = this._adapter.sameDate(date, this.selected);
                this._weeks[0].unshift(new CubCalendarCell(daysInPreviousMonth - i, dateNames[daysInPreviousMonth - i - 1], ariaLabel, enabled, events, eventsLabel, 'previous', isToday, isSelected));
            }
            for (let i = 0, cell = this._weeks[this._weeks.length - 1].length, lastOffset = this._lastWeekOffset +
                (this.numRows - this._weeks.length) * DAYS_PER_WEEK; i < lastOffset; i++, cell++) {
                if (cell === DAYS_PER_WEEK) {
                    this._weeks.push([]);
                    cell = 0;
                }
                const date = this._adapter.createDatetime(this._adapter.getYear(this._adapter.addCalendarMonths(this.activeDate, 1)), this._adapter.getMonth(this._adapter.addCalendarMonths(this.activeDate, 1)), i + 1, this._adapter.getHour(this._adapter.addCalendarMonths(this.activeDate, 1)), this._adapter.getMinute(this._adapter.addCalendarMonths(this.activeDate, 1)));
                const enabled = !this.dateFilter || this.dateFilter(date);
                const ariaLabel = this._adapter.format(date, this._dateFormats.display.dateA11yLabel);
                const eventsLabel = this._adapter.format(date, this._dateFormats.display.dateInput);
                let events = [];
                this.events.forEach((event) => {
                    if (this._adapter.sameDate(event.date, date)) {
                        events.push(event.content);
                    }
                });
                const isToday = this._adapter.sameDate(date, this._adapter.today());
                const isSelected = this._adapter.sameDate(date, this.selected);
                this._weeks[this._weeks.length - 1].push(new CubCalendarCell(i + 1, dateNames[i], ariaLabel, enabled, events, eventsLabel, 'next', isToday, isSelected));
            }
        }
    }
    /**
     * Gets the date in this month that the given Date falls on.
     * Returns null if the given Date is in another month.
     */
    _getDateInCurrentMonth(date) {
        return this._adapter.sameMonthAndYear(date, this.activeDate)
            ? this._adapter.getDate(date)
            : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMonthView, deps: [{ token: CubDatetimeAdapter, optional: true }, { token: CUB_DATETIME_FORMATS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubMonthView, isStandalone: true, selector: "cub-month-view", inputs: { events: "events", type: "type", size: "size", dateFilter: "dateFilter", activeDate: "activeDate", selected: "selected", isInline: "isInline" }, outputs: { selectedChange: "selectedChange", userSelection: "userSelection" }, exportAs: ["cubMonthView"], ngImport: i0, template: "<table class=\"cub-calendar-table\" role=\"grid\">\n  <thead class=\"cub-calendar-table-header\">\n    <tr>\n      <th *ngFor=\"let day of _weekdays\" [attr.aria-label]=\"day.long\">\n        {{ day.narrow }}\n      </th>\n    </tr>\n  </thead>\n  <tbody\n    cub-calendar-body\n    class=\"cub-calendar-body-month\"\n    [rows]=\"_weeks\"\n    [todayValue]=\"_todayDate!\"\n    [activeCell]=\"_adapter.getDate(activeDate) - 1\"\n    [selectedValue]=\"_selectedDate!\"\n    [size]=\"size\"\n    [@slideCalendar]=\"_calendarState\"\n    (@slideCalendar.done)=\"_calendarStateDone()\"\n    (selectedValueChange)=\"_dateSelected($event)\"\n  ></tbody>\n</table>\n", styles: [""], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CubCalendarBody, selector: "[cub-calendar-body]", inputs: ["label", "rows", "todayValue", "selectedValue", "labelMinRequiredCells", "numCols", "allowDisabledSelection", "activeCell", "size"], outputs: ["selectedValueChange"], exportAs: ["cubCalendarBody"] }], animations: [cubDatetimepickerAnimations.slideCalendar], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMonthView, decorators: [{
            type: Component,
            args: [{ selector: 'cub-month-view', exportAs: 'cubMonthView', animations: [cubDatetimepickerAnimations.slideCalendar], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgFor, CubCalendarBody], template: "<table class=\"cub-calendar-table\" role=\"grid\">\n  <thead class=\"cub-calendar-table-header\">\n    <tr>\n      <th *ngFor=\"let day of _weekdays\" [attr.aria-label]=\"day.long\">\n        {{ day.narrow }}\n      </th>\n    </tr>\n  </thead>\n  <tbody\n    cub-calendar-body\n    class=\"cub-calendar-body-month\"\n    [rows]=\"_weeks\"\n    [todayValue]=\"_todayDate!\"\n    [activeCell]=\"_adapter.getDate(activeDate) - 1\"\n    [selectedValue]=\"_selectedDate!\"\n    [size]=\"size\"\n    [@slideCalendar]=\"_calendarState\"\n    (@slideCalendar.done)=\"_calendarStateDone()\"\n    (selectedValueChange)=\"_dateSelected($event)\"\n  ></tbody>\n</table>\n" }]
        }], ctorParameters: () => [{ type: CubDatetimeAdapter, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATETIME_FORMATS]
                }] }], propDecorators: { events: [{
                type: Input
            }], type: [{
                type: Input
            }], size: [{
                type: Input
            }], dateFilter: [{
                type: Input
            }], activeDate: [{
                type: Input
            }], selected: [{
                type: Input
            }], isInline: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], userSelection: [{
                type: Output
            }] } });

/**
 * An internal component used to display a single year in the datetimepicker.
 * @docs-private
 */
class CubYearView {
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate() {
        return this._activeDate;
    }
    set activeDate(value) {
        const oldActiveDate = this._activeDate;
        this._activeDate = value || this._adapter.today();
        if (oldActiveDate &&
            this._activeDate &&
            !this._adapter.sameYear(oldActiveDate, this._activeDate)) {
            this._init();
            if (oldActiveDate < this._activeDate) {
                this.calendarState('right');
            }
            else {
                this.calendarState('left');
            }
        }
    }
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = value;
        this._selectedMonth = this._getMonthInCurrentYear(this.selected);
        this._init();
    }
    constructor(_adapter, _dateFormats) {
        this._adapter = _adapter;
        this._dateFormats = _dateFormats;
        /** 元件的類型，預設為 'date'。 */
        this.type = 'date';
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 當選定日期時間變更時發出通知。 */
        this.selectedChange = new EventEmitter();
        /** 當使用者選擇日期時間時發出通知。 */
        this.userSelection = new EventEmitter();
        if (!this._adapter) {
            throw createMissingDateImplError('CubDatetimeAdapter');
        }
        if (!this._dateFormats) {
            throw createMissingDateImplError('CUB_DATETIME_FORMATS');
        }
        this._activeDate = this._adapter.today();
    }
    ngAfterContentInit() {
        this._init();
    }
    /** Handles when a new month is selected. */
    _monthSelected(cell) {
        let month = cell.value;
        const normalizedDate = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), month, 1, 0, 0);
        this.selectedChange.emit(this._adapter.createDatetime(this._adapter.getYear(this.activeDate), month, Math.min(this._adapter.getDate(this.activeDate), this._adapter.getNumDaysInMonth(normalizedDate)), this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate)));
        if (this.type === 'month') {
            this.userSelection.emit();
        }
    }
    _calendarStateDone() {
        this._calendarState = '';
    }
    calendarState(direction) {
        this._calendarState = direction;
    }
    /** Initializes this month view. */
    _init() {
        this._selectedMonth = this._getMonthInCurrentYear(this.selected);
        this._todayMonth = this._getMonthInCurrentYear(this._adapter.today());
        this._yearLabel = this._adapter.getYearName(this.activeDate);
        const monthNames = this._adapter.getMonthNames('short');
        // First row of months only contains 5 elements so we can fit the year label on the same row.
        this._months = [
            [0, 1, 2, 3],
            [4, 5, 6, 7],
            [8, 9, 10, 11],
        ].map((row) => row.map((month) => this._createCellForMonth(month, monthNames[month])));
    }
    /**
     * Gets the month in this year that the given Date falls on.
     * Returns null if the given Date is in another year.
     */
    _getMonthInCurrentYear(date) {
        return this._adapter.sameYear(date, this.activeDate)
            ? this._adapter.getMonth(date)
            : null;
    }
    /** Creates an MdCalendarCell for the given month. */
    _createCellForMonth(month, monthName) {
        const ariaLabel = this._adapter.format(this._adapter.createDatetime(this._adapter.getYear(this.activeDate), month, 1, this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate)), this._dateFormats.display.monthYearA11yLabel);
        return new CubCalendarCell(month, monthName.toLocaleUpperCase(), ariaLabel, this._isMonthEnabled(month), [], '', 'current', month === this._todayMonth, month === this._selectedMonth);
    }
    /** Whether the given month is enabled. */
    _isMonthEnabled(month) {
        if (!this.dateFilter) {
            return true;
        }
        const firstOfMonth = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), month, 1, this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate));
        // If any date in the month is enabled count the month as enabled.
        for (let date = firstOfMonth; this._adapter.getMonth(date) === month; date = this._adapter.addCalendarDays(date, 1)) {
            if (this.dateFilter(date)) {
                return true;
            }
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubYearView, deps: [{ token: CubDatetimeAdapter, optional: true }, { token: CUB_DATETIME_FORMATS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubYearView, isStandalone: true, selector: "cub-year-view", inputs: { type: "type", size: "size", dateFilter: "dateFilter", activeDate: "activeDate", selected: "selected" }, outputs: { selectedChange: "selectedChange", userSelection: "userSelection" }, exportAs: ["cubYearView"], ngImport: i0, template: "<table class=\"cub-calendar-table\" role=\"grid\">\n  <thead class=\"cub-calendar-table-header\"></thead>\n  <tbody\n    cub-calendar-body\n    class=\"cub-calendar-body-year\"\n    [label]=\"_yearLabel\"\n    [rows]=\"_months\"\n    [todayValue]=\"_todayMonth!\"\n    [labelMinRequiredCells]=\"2\"\n    [numCols]=\"4\"\n    [activeCell]=\"_adapter.getMonth(activeDate)\"\n    [selectedValue]=\"_selectedMonth!\"\n    [size]=\"size\"\n    [@slideCalendar]=\"_calendarState\"\n    (@slideCalendar.done)=\"_calendarStateDone()\"\n    (selectedValueChange)=\"_monthSelected($event)\"\n  ></tbody>\n</table>\n", styles: [""], dependencies: [{ kind: "component", type: CubCalendarBody, selector: "[cub-calendar-body]", inputs: ["label", "rows", "todayValue", "selectedValue", "labelMinRequiredCells", "numCols", "allowDisabledSelection", "activeCell", "size"], outputs: ["selectedValueChange"], exportAs: ["cubCalendarBody"] }], animations: [cubDatetimepickerAnimations.slideCalendar], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubYearView, decorators: [{
            type: Component,
            args: [{ selector: 'cub-year-view', exportAs: 'cubYearView', animations: [cubDatetimepickerAnimations.slideCalendar], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubCalendarBody], template: "<table class=\"cub-calendar-table\" role=\"grid\">\n  <thead class=\"cub-calendar-table-header\"></thead>\n  <tbody\n    cub-calendar-body\n    class=\"cub-calendar-body-year\"\n    [label]=\"_yearLabel\"\n    [rows]=\"_months\"\n    [todayValue]=\"_todayMonth!\"\n    [labelMinRequiredCells]=\"2\"\n    [numCols]=\"4\"\n    [activeCell]=\"_adapter.getMonth(activeDate)\"\n    [selectedValue]=\"_selectedMonth!\"\n    [size]=\"size\"\n    [@slideCalendar]=\"_calendarState\"\n    (@slideCalendar.done)=\"_calendarStateDone()\"\n    (selectedValueChange)=\"_monthSelected($event)\"\n  ></tbody>\n</table>\n" }]
        }], ctorParameters: () => [{ type: CubDatetimeAdapter, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATETIME_FORMATS]
                }] }], propDecorators: { type: [{
                type: Input
            }], size: [{
                type: Input
            }], dateFilter: [{
                type: Input
            }], activeDate: [{
                type: Input
            }], selected: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], userSelection: [{
                type: Output
            }] } });

/**
 * An internal component used to display multiple years in the datetimepicker.
 * @docs-private
 */
class CubMultiYearView {
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate() {
        return this._activeDate;
    }
    set activeDate(value) {
        const oldActiveDate = this._activeDate;
        this._activeDate = value || this._adapter.today();
        if (oldActiveDate &&
            this._activeDate &&
            !isSameMultiYearView(this._adapter, oldActiveDate, this._activeDate, this.minDate, this.maxDate)) {
            this._init();
        }
    }
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = value;
        this._selectedYear =
            this._selected && this._adapter.getYear(this._selected);
        this._init();
    }
    /** 最小可選擇的日期時間，預設為 undefined。 */
    get minDate() {
        return this._minDate;
    }
    set minDate(value) {
        this._minDate = this._getValidDateOrNull(this._adapter.deserialize(value));
    }
    /** 最大可選擇的日期時間，預設為 undefined。 */
    get maxDate() {
        return this._maxDate;
    }
    set maxDate(value) {
        this._maxDate = this._getValidDateOrNull(this._adapter.deserialize(value));
    }
    constructor(_adapter, _dateFormats) {
        this._adapter = _adapter;
        this._dateFormats = _dateFormats;
        /** 元件的類型，預設為 'date'。 */
        this.type = 'date';
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 當選定日期時間變更時發出通知。 */
        this.selectedChange = new EventEmitter();
        /** 當使用者選擇日期時間時發出通知。 */
        this.userSelection = new EventEmitter();
        if (!this._adapter) {
            throw createMissingDateImplError('CubDatetimeAdapter');
        }
        if (!this._dateFormats) {
            throw createMissingDateImplError('CUB_DATETIME_FORMATS');
        }
        this._activeDate = this._adapter.today();
    }
    ngAfterContentInit() {
        this._init();
    }
    /** Handles when a new year is selected. */
    _yearSelected(cell) {
        let year = cell.value;
        const month = this._adapter.getMonth(this.activeDate);
        const normalizedDate = this._adapter.createDatetime(year, month, 1, 0, 0);
        this.selectedChange.emit(this._adapter.createDatetime(year, month, Math.min(this._adapter.getDate(this.activeDate), this._adapter.getNumDaysInMonth(normalizedDate)), this._adapter.getHour(this.activeDate), this._adapter.getMinute(this.activeDate)));
        if (this.type === 'year') {
            this.userSelection.emit();
        }
    }
    _getActiveCell() {
        return getActiveOffset(this._adapter, this.activeDate, this.minDate, this.maxDate);
    }
    _calendarStateDone() {
        this._calendarState = '';
    }
    /** Initializes this year view. */
    _init() {
        this._todayYear = this._adapter.getYear(this._adapter.today());
        this._yearLabel = this._adapter.getYearName(this.activeDate);
        const activeYear = this._adapter.getYear(this.activeDate);
        const minYearOfPage = activeYear -
            getActiveOffset(this._adapter, this.activeDate, this.minDate, this.maxDate);
        this._years = [];
        for (let i = 0, row = []; i < yearsPerPage; i++) {
            row.push(minYearOfPage + i);
            if (row.length === yearsPerRow) {
                this._years.push(row.map((year) => this._createCellForYear(year)));
                row = [];
            }
        }
    }
    /** Creates an CubCalendarCell for the given year. */
    _createCellForYear(year) {
        const yearName = this._adapter.getYearName(this._adapter.createDate(year, 0, 1));
        return new CubCalendarCell(year, yearName, yearName, this._shouldEnableYear(year), [], '', 'current', year === this._todayYear, year === this._selectedYear);
    }
    /** Whether the given year is enabled. */
    _shouldEnableYear(year) {
        // disable if the year is greater than maxDate lower than minDate
        if (year === undefined ||
            year === null ||
            (this.maxDate && year > this._adapter.getYear(this.maxDate)) ||
            (this.minDate && year < this._adapter.getYear(this.minDate))) {
            return false;
        }
        // enable if it reaches here and there's no filter defined
        if (!this.dateFilter) {
            return true;
        }
        const firstOfYear = this._adapter.createDate(year, 0, 1);
        // If any date in the year is enabled count the year as enabled.
        for (let date = firstOfYear; this._adapter.getYear(date) === year; date = this._adapter.addCalendarDays(date, 1)) {
            if (this.dateFilter(date)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Gets the year in this years range that the given Date falls on.
     * Returns null if the given Date is not in this range.
     */
    _getYearInCurrentRange(date) {
        const year = this._adapter.getYear(date);
        return this._isInRange(year) ? year : null;
    }
    /**
     * Validate if the current year is in the current range
     * Returns true if is in range else returns false
     */
    _isInRange(year) {
        return true;
    }
    /**
     * @param obj The object to check.
     * @returns The given object if it is both a date instance and valid, otherwise null.
     */
    _getValidDateOrNull(obj) {
        return this._adapter.isDateInstance(obj) && this._adapter.isValid(obj)
            ? obj
            : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMultiYearView, deps: [{ token: CubDatetimeAdapter, optional: true }, { token: CUB_DATETIME_FORMATS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubMultiYearView, isStandalone: true, selector: "cub-multi-year-view", inputs: { type: "type", size: "size", dateFilter: "dateFilter", activeDate: "activeDate", selected: "selected", minDate: "minDate", maxDate: "maxDate" }, outputs: { selectedChange: "selectedChange", userSelection: "userSelection" }, exportAs: ["cubMultiYearView"], ngImport: i0, template: "<table class=\"cub-calendar-table\" role=\"grid\">\n  <thead class=\"cub-calendar-table-header\"></thead>\n  <tbody\n    cub-calendar-body\n    class=\"cub-calendar-body-multi-year\"\n    [todayValue]=\"_todayYear\"\n    [rows]=\"_years\"\n    [numCols]=\"4\"\n    [activeCell]=\"_getActiveCell()\"\n    [selectedValue]=\"_selectedYear!\"\n    [size]=\"size\"\n    [@slideCalendar]=\"_calendarState\"\n    (@slideCalendar.done)=\"_calendarStateDone()\"\n    (selectedValueChange)=\"_yearSelected($event)\"\n  ></tbody>\n</table>\n", styles: [""], dependencies: [{ kind: "component", type: CubCalendarBody, selector: "[cub-calendar-body]", inputs: ["label", "rows", "todayValue", "selectedValue", "labelMinRequiredCells", "numCols", "allowDisabledSelection", "activeCell", "size"], outputs: ["selectedValueChange"], exportAs: ["cubCalendarBody"] }], animations: [cubDatetimepickerAnimations.slideCalendar], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMultiYearView, decorators: [{
            type: Component,
            args: [{ selector: 'cub-multi-year-view', exportAs: 'cubMultiYearView', animations: [cubDatetimepickerAnimations.slideCalendar], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubCalendarBody], template: "<table class=\"cub-calendar-table\" role=\"grid\">\n  <thead class=\"cub-calendar-table-header\"></thead>\n  <tbody\n    cub-calendar-body\n    class=\"cub-calendar-body-multi-year\"\n    [todayValue]=\"_todayYear\"\n    [rows]=\"_years\"\n    [numCols]=\"4\"\n    [activeCell]=\"_getActiveCell()\"\n    [selectedValue]=\"_selectedYear!\"\n    [size]=\"size\"\n    [@slideCalendar]=\"_calendarState\"\n    (@slideCalendar.done)=\"_calendarStateDone()\"\n    (selectedValueChange)=\"_yearSelected($event)\"\n  ></tbody>\n</table>\n" }]
        }], ctorParameters: () => [{ type: CubDatetimeAdapter, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATETIME_FORMATS]
                }] }], propDecorators: { type: [{
                type: Input
            }], size: [{
                type: Input
            }], dateFilter: [{
                type: Input
            }], activeDate: [{
                type: Input
            }], selected: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], userSelection: [{
                type: Output
            }] } });

const activeEventOptions = normalizePassiveListenerOptions({ passive: false });
/**
 * A clock that is used as part of the datetimepicker.
 * @docs-private
 */
class CubClock {
    get _hand() {
        const hour = this._adapter.getHour(this.activeDate);
        this._selectedHour = hour;
        this._selectedMinute = this._adapter.getMinute(this.activeDate);
        let deg = 0;
        let radius = CLOCK_OUTER_RADIUS;
        if (this._hourView) {
            const outer = this._selectedHour > 0 && this._selectedHour < 13;
            radius = outer ? CLOCK_OUTER_RADIUS : CLOCK_INNER_RADIUS;
            if (this.twelvehour) {
                radius = CLOCK_OUTER_RADIUS;
            }
            deg = Math.round(this._selectedHour * (360 / (24 / 2)));
        }
        else {
            deg = Math.round(this._selectedMinute * (360 / 60));
        }
        if (deg % 30 === 0) {
            radius -= 7;
        }
        this.getHandOnLevel();
        return {
            height: `${radius}%`,
            marginTop: `${50 - radius}%`,
            transform: `rotate(${deg}deg)`,
        };
    }
    /** 顯示的日期時間，預設為 undefined。 */
    get activeDate() {
        return this._activeDate;
    }
    set activeDate(value) {
        const oldActiveDate = this._activeDate;
        this._activeDate = this._adapter.clampDate(value, this.minDate, this.maxDate);
        if (!this._adapter.sameMinute(oldActiveDate, this._activeDate)) {
            this._init();
        }
    }
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = this._adapter.getValidDateOrNull(this._adapter.deserialize(value));
        if (this._selected) {
            this.activeDate = this._selected;
        }
    }
    /** 最小可選擇的日期時間，預設為 undefined。 */
    get minDate() {
        return this._minDate;
    }
    set minDate(value) {
        this._minDate = this._adapter.getValidDateOrNull(this._adapter.deserialize(value));
    }
    /** 最大可選擇的日期時間，預設為 undefined。 */
    get maxDate() {
        return this._maxDate;
    }
    set maxDate(value) {
        this._maxDate = this._adapter.getValidDateOrNull(this._adapter.deserialize(value));
    }
    /** 元件的初始畫面，預設為 'month'。 */
    set startView(value) {
        this._hourView = value !== 'minute';
    }
    constructor(_elementRef, _adapter, _changeDetectorRef, _document) {
        this._elementRef = _elementRef;
        this._adapter = _adapter;
        this._changeDetectorRef = _changeDetectorRef;
        this._document = _document;
        /** Whether the clock is in hour view. */
        this._hourView = true;
        this._hours = [];
        this._minutes = [];
        this._handOnLevel = false;
        this._timeChanged = false;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 選擇時間時，一次跨幾分鐘，預設為 1。 */
        this.interval = 1;
        /** 是否時間選擇為 12 小時制，預設為 false。 */
        this.twelvehour = false;
        /** 當前時間為 AM 或是 PM，預設為 'AM'。 */
        this.AMPM = 'AM';
        /** 當選定日期時間變更時發出通知。 */
        this.selectedChange = new EventEmitter();
        /** 當日期時間為 Active 狀態時發出通知。 */
        this.activeDateChange = new EventEmitter();
        /** 當使用者選擇日期時間時發出通知。 */
        this.userSelection = new EventEmitter();
        /** Called when the user has put their pointer down on the clock. */
        this._pointerDown = (event) => {
            this._timeChanged = false;
            this.setTime(event);
            this._bindGlobalEvents(event);
        };
        /**
         * Called when the user has moved their pointer after
         * starting to drag. Bound on the document level.
         */
        this._pointerMove = (event) => {
            if (event.cancelable) {
                event.preventDefault();
            }
            this.setTime(event);
        };
        /** Called when the user has lifted their pointer. Bound on the document level. */
        this._pointerUp = (event) => {
            if (event.cancelable) {
                event.preventDefault();
            }
            this._removeGlobalEvents();
            if (this._timeChanged) {
                this.selectedChange.emit(this.activeDate);
                if (!this._hourView) {
                    this.userSelection.emit();
                }
            }
        };
    }
    ngAfterContentInit() {
        this.activeDate = this._activeDate || this._adapter.today();
        this._init();
    }
    ngOnDestroy() {
        this._removeGlobalEvents();
    }
    ngOnChanges() {
        this._init();
    }
    getHandOnLevel() {
        let deg = 0;
        if (this._hourView) {
            deg = Math.round(this._selectedHour * (360 / (24 / 2)));
        }
        else {
            deg = Math.round(this._selectedMinute * (360 / 60));
        }
        this._handOnLevel = deg % 30 === 0;
        setTimeout(() => {
            this._changeDetectorRef.markForCheck();
        }, 0);
    }
    /** Binds our global move and end events. */
    _bindGlobalEvents(triggerEvent) {
        // Note that we bind the events to the `document`, because it allows us to capture
        // drag cancel events where the user's pointer is outside the browser window.
        const document = this._document;
        const isTouch = isTouchEvent(triggerEvent);
        const moveEventName = isTouch ? 'touchmove' : 'mousemove';
        const endEventName = isTouch ? 'touchend' : 'mouseup';
        document.addEventListener(moveEventName, this._pointerMove, activeEventOptions);
        document.addEventListener(endEventName, this._pointerUp, activeEventOptions);
        if (isTouch) {
            document.addEventListener('touchcancel', this._pointerUp, activeEventOptions);
        }
    }
    /** Removes any global event listeners that we may have added. */
    _removeGlobalEvents() {
        const document = this._document;
        document.removeEventListener('mousemove', this._pointerMove, activeEventOptions);
        document.removeEventListener('mouseup', this._pointerUp, activeEventOptions);
        document.removeEventListener('touchmove', this._pointerMove, activeEventOptions);
        document.removeEventListener('touchend', this._pointerUp, activeEventOptions);
        document.removeEventListener('touchcancel', this._pointerUp, activeEventOptions);
    }
    /** Initializes this clock view. */
    _init() {
        this._hours.length = 0;
        this._minutes.length = 0;
        const hourNames = this._adapter.getHourNames();
        const minuteNames = this._adapter.getMinuteNames();
        if (this.twelvehour) {
            const hours = [];
            for (let i = 0; i < hourNames.length; i++) {
                const radian = (i / 6) * Math.PI;
                const radius = CLOCK_OUTER_RADIUS;
                const hour = i;
                const date = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), this._adapter.getDate(this.activeDate), hour, 0);
                // Check if the date is enabled, no need to respect the minute setting here
                const enabled = (!this.minDate ||
                    this._adapter.compareDatetime(date, this.minDate, false) >= 0) &&
                    (!this.maxDate ||
                        this._adapter.compareDatetime(date, this.maxDate, false) <= 0) &&
                    (!this.dateFilter ||
                        this.dateFilter(date, CubDatetimepickerFilterType.HOUR));
                // display value for twelvehour clock should be from 1-12 not including 0 and not above 12
                hours.push({
                    value: i,
                    displayValue: i % 12 === 0 ? '12' : hourNames[i % 12],
                    enabled,
                    top: CLOCK_RADIUS - Math.cos(radian) * radius - CLOCK_TICK_RADIUS,
                    left: CLOCK_RADIUS + Math.sin(radian) * radius - CLOCK_TICK_RADIUS,
                });
            }
            // filter out AM or PM hours based on AMPM
            if (this.AMPM === 'AM') {
                this._hours = hours.filter((x) => x.value < 12);
            }
            else {
                this._hours = hours.filter((x) => x.value >= 12);
            }
        }
        else {
            for (let i = 0; i < hourNames.length; i++) {
                const radian = (i / 6) * Math.PI;
                const outer = i > 0 && i < 13;
                const radius = outer ? CLOCK_OUTER_RADIUS : CLOCK_INNER_RADIUS;
                const date = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), this._adapter.getDate(this.activeDate), i, 0);
                // Check if the date is enabled, no need to respect the minute setting here
                const enabled = (!this.minDate ||
                    this._adapter.compareDatetime(date, this.minDate, false) >= 0) &&
                    (!this.maxDate ||
                        this._adapter.compareDatetime(date, this.maxDate, false) <= 0) &&
                    (!this.dateFilter ||
                        this.dateFilter(date, CubDatetimepickerFilterType.HOUR));
                this._hours.push({
                    value: i,
                    displayValue: i === 0 ? '00' : hourNames[i],
                    enabled,
                    top: CLOCK_RADIUS - Math.cos(radian) * radius - CLOCK_TICK_RADIUS,
                    left: CLOCK_RADIUS + Math.sin(radian) * radius - CLOCK_TICK_RADIUS,
                    fontSize: i > 0 && i < 13 ? '' : '80%',
                });
            }
        }
        for (let i = 0; i < minuteNames.length; i += 5) {
            const radian = (i / 30) * Math.PI;
            const date = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), this._adapter.getDate(this.activeDate), this._adapter.getHour(this.activeDate), i);
            const enabled = (!this.minDate ||
                this._adapter.compareDatetime(date, this.minDate) >= 0) &&
                (!this.maxDate ||
                    this._adapter.compareDatetime(date, this.maxDate) <= 0) &&
                (!this.dateFilter ||
                    this.dateFilter(date, CubDatetimepickerFilterType.MINUTE));
            this._minutes.push({
                value: i,
                displayValue: i === 0 ? '00' : minuteNames[i],
                enabled,
                top: CLOCK_RADIUS -
                    Math.cos(radian) * CLOCK_OUTER_RADIUS -
                    CLOCK_TICK_RADIUS,
                left: CLOCK_RADIUS +
                    Math.sin(radian) * CLOCK_OUTER_RADIUS -
                    CLOCK_TICK_RADIUS,
            });
        }
    }
    /**
     * Set Time
     * @param event
     */
    setTime(event) {
        const trigger = this._elementRef.nativeElement;
        const triggerRect = trigger.getBoundingClientRect();
        const width = trigger.offsetWidth;
        const height = trigger.offsetHeight;
        const { pageX, pageY } = getPointerPositionOnPage(event);
        const x = width / 2 - (pageX - triggerRect.left - window.pageXOffset);
        const y = height / 2 - (pageY - triggerRect.top - window.pageYOffset);
        let radian = Math.atan2(-x, y);
        const unit = Math.PI / (this._hourView ? 6 : this.interval ? 30 / this.interval : 30);
        const z = Math.sqrt(x * x + y * y);
        const outer = this._hourView &&
            z >
                (width * (CLOCK_OUTER_RADIUS / 100) +
                    width * (CLOCK_INNER_RADIUS / 100)) /
                    2;
        if (radian < 0) {
            radian = Math.PI * 2 + radian;
        }
        let value = Math.round(radian / unit);
        let date;
        if (this._hourView) {
            if (this.twelvehour) {
                if (this.AMPM === 'AM') {
                    value = value === 12 ? 0 : value;
                }
                else {
                    value = value === 12 ? 12 : value + 12;
                }
            }
            else {
                if (value === 12) {
                    value = 0;
                }
                value = outer
                    ? value === 0
                        ? 12
                        : value
                    : value === 0
                        ? 0
                        : value + 12;
            }
            date = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), this._adapter.getDate(this.activeDate), value, this._adapter.getMinute(this.activeDate));
        }
        else {
            if (this.interval) {
                value *= this.interval;
            }
            if (value === 60) {
                value = 0;
            }
            date = this._adapter.createDatetime(this._adapter.getYear(this.activeDate), this._adapter.getMonth(this.activeDate), this._adapter.getDate(this.activeDate), this._adapter.getHour(this.activeDate), value);
        }
        // if there is a dateFilter, check if the date is allowed if it is not then do not set/emit new date
        if (this.dateFilter &&
            !this.dateFilter(date, this._hourView
                ? CubDatetimepickerFilterType.HOUR
                : CubDatetimepickerFilterType.MINUTE)) {
            return;
        }
        this._timeChanged = true;
        this.activeDate = date;
        this._changeDetectorRef.markForCheck();
        this.activeDateChange.emit(this.activeDate);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubClock, deps: [{ token: i0.ElementRef }, { token: CubDatetimeAdapter }, { token: i0.ChangeDetectorRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubClock, isStandalone: true, selector: "cub-clock", inputs: { size: "size", dateFilter: "dateFilter", interval: "interval", twelvehour: "twelvehour", AMPM: "AMPM", activeDate: "activeDate", selected: "selected", minDate: "minDate", maxDate: "maxDate", startView: "startView" }, outputs: { selectedChange: "selectedChange", activeDateChange: "activeDateChange", userSelection: "userSelection" }, host: { attributes: { "role": "clock" }, listeners: { "mousedown": "_pointerDown($event)", "touchstart": "_pointerDown($event)" }, properties: { "class.cub-clock": "true", "class.cub-clock-small": "size === \"small\"" } }, exportAs: ["cubClock"], usesOnChanges: true, ngImport: i0, template: "<div class=\"cub-clock-wrapper\">\n  <div class=\"cub-clock-center\"></div>\n  <div\n    class=\"cub-clock-hand\"\n    [ngStyle]=\"_hand\"\n    [class.cub-clock-hand-on-level]=\"_handOnLevel\"\n  ></div>\n  <div class=\"cub-clock-hours\" [class.cub-active]=\"_hourView\">\n    <div\n      *ngFor=\"let item of _hours\"\n      cubRipple\n      class=\"cub-clock-cell\"\n      cubRippleClass=\"cub-clock-cell-ripple\"\n      [class.cub-disabled]=\"!item.enabled\"\n      [class.cub-selected]=\"_selectedHour === item.value\"\n      [style.fontSize]=\"item.fontSize\"\n      [style.left]=\"item.left + '%'\"\n      [style.top]=\"item.top + '%'\"\n    >\n      {{ item.displayValue }}\n\n      <span\n        class=\"cub-persistent-ripple cub-clock-cell-persistent-ripple\"\n      ></span>\n    </div>\n  </div>\n  <div class=\"cub-clock-minutes\" [class.cub-active]=\"!_hourView\">\n    <div\n      *ngFor=\"let item of _minutes\"\n      cubRipple\n      class=\"cub-clock-cell\"\n      cubRippleClass=\"cub-clock-cell-ripple\"\n      [class.cub-disabled]=\"!item.enabled\"\n      [class.cub-selected]=\"_selectedMinute === item.value\"\n      [style.left]=\"item.left + '%'\"\n      [style.top]=\"item.top + '%'\"\n    >\n      {{ item.displayValue }}\n\n      <span\n        class=\"cub-persistent-ripple cub-clock-cell-persistent-ripple\"\n      ></span>\n    </div>\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubClock, decorators: [{
            type: Component,
            args: [{ selector: 'cub-clock', host: {
                        role: 'clock',
                        '[class.cub-clock]': 'true',
                        '[class.cub-clock-small]': 'size === "small"',
                        '(mousedown)': '_pointerDown($event)',
                        '(touchstart)': '_pointerDown($event)',
                    }, exportAs: 'cubClock', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgStyle, NgFor, CubRipple], template: "<div class=\"cub-clock-wrapper\">\n  <div class=\"cub-clock-center\"></div>\n  <div\n    class=\"cub-clock-hand\"\n    [ngStyle]=\"_hand\"\n    [class.cub-clock-hand-on-level]=\"_handOnLevel\"\n  ></div>\n  <div class=\"cub-clock-hours\" [class.cub-active]=\"_hourView\">\n    <div\n      *ngFor=\"let item of _hours\"\n      cubRipple\n      class=\"cub-clock-cell\"\n      cubRippleClass=\"cub-clock-cell-ripple\"\n      [class.cub-disabled]=\"!item.enabled\"\n      [class.cub-selected]=\"_selectedHour === item.value\"\n      [style.fontSize]=\"item.fontSize\"\n      [style.left]=\"item.left + '%'\"\n      [style.top]=\"item.top + '%'\"\n    >\n      {{ item.displayValue }}\n\n      <span\n        class=\"cub-persistent-ripple cub-clock-cell-persistent-ripple\"\n      ></span>\n    </div>\n  </div>\n  <div class=\"cub-clock-minutes\" [class.cub-active]=\"!_hourView\">\n    <div\n      *ngFor=\"let item of _minutes\"\n      cubRipple\n      class=\"cub-clock-cell\"\n      cubRippleClass=\"cub-clock-cell-ripple\"\n      [class.cub-disabled]=\"!item.enabled\"\n      [class.cub-selected]=\"_selectedMinute === item.value\"\n      [style.left]=\"item.left + '%'\"\n      [style.top]=\"item.top + '%'\"\n    >\n      {{ item.displayValue }}\n\n      <span\n        class=\"cub-persistent-ripple cub-clock-cell-persistent-ripple\"\n      ></span>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: CubDatetimeAdapter }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { size: [{
                type: Input
            }], dateFilter: [{
                type: Input
            }], interval: [{
                type: Input
            }], twelvehour: [{
                type: Input
            }], AMPM: [{
                type: Input
            }], activeDate: [{
                type: Input
            }], selected: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], startView: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], activeDateChange: [{
                type: Output
            }], userSelection: [{
                type: Output
            }] } });

/**
 * Component used as the content for the datetimepicker dialog and popup. We use this instead of
 * using CubCalendar directly as the content so we can control the initial focus. This also gives us
 * a place to put additional features of the popup that are not part of the calendar itself in the
 * future. (e.g. confirmation buttons).
 * @docs-private
 */
class CubDatetimepickerContent extends _CubDatetimepickerContentBase {
    constructor(elementRef, _changeDetectorRef) {
        super(elementRef);
        this._changeDetectorRef = _changeDetectorRef;
        /** Emits when an animation has finished. */
        this._animationDone = new Subject();
    }
    ngOnInit() {
        this._animationState = this.datetimepicker.touchUi
            ? 'enter-dialog'
            : 'enter-dropdown';
    }
    ngOnDestroy() {
        this._animationDone.complete();
    }
    _startExitAnimation() {
        this._animationState = 'void';
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerContent, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDatetimepickerContent, isStandalone: true, selector: "cub-datetimepicker-content", inputs: { color: "color" }, host: { listeners: { "@transformPanel.done": "_animationDone.next()" }, properties: { "class.cub-datetimepicker-content-small": "datetimepicker?.size === \"small\"", "class.cub-datetimepicker-content-touch": "datetimepicker?.touchUi", "class.cub-datetimepicker-content-touch-small": "datetimepicker?.touchUi && datetimepicker?.size === \"small\"", "attr.mode": "datetimepicker.mode", "@transformPanel": "_animationState" }, classAttribute: "cub-datetimepicker-content" }, viewQueries: [{ propertyName: "_calendar", first: true, predicate: CubCalendar, descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<div\n  cubCdkTrapFocus\n  class=\"cub-datetimepicker-content-container\"\n  [attr.mode]=\"datetimepicker.mode\"\n>\n  <cub-calendar\n    [id]=\"datetimepicker.id\"\n    [ngClass]=\"datetimepicker.panelClass\"\n    [attr.mode]=\"datetimepicker.mode\"\n    [type]=\"datetimepicker.type\"\n    [startAt]=\"datetimepicker.startAt\"\n    [startView]=\"datetimepicker.startView\"\n    [maxDate]=\"datetimepicker._maxDate\"\n    [minDate]=\"datetimepicker._minDate\"\n    [dateFilter]=\"datetimepicker._dateFilter\"\n    [multiYearSelector]=\"datetimepicker.multiYearSelector\"\n    [preventSameDateTimeSelection]=\"datetimepicker.preventSameDateTimeSelection\"\n    [timeInterval]=\"datetimepicker.timeInterval\"\n    [twelvehour]=\"datetimepicker.twelvehour\"\n    [selected]=\"datetimepicker._selected\"\n    [size]=\"datetimepicker.size\"\n    [@fadeInCalendar]=\"'enter'\"\n    (selectedChange)=\"datetimepicker._select($event)\"\n    (viewChanged)=\"datetimepicker._viewChanged($event)\"\n    (userSelection)=\"datetimepicker.close()\"\n  >\n  </cub-calendar>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkTrapFocus, selector: "[cubCdkTrapFocus]", inputs: ["cubCdkTrapFocus", "cubCdkTrapFocusAutoCapture"], exportAs: ["cubCdkTrapFocus"] }, { kind: "component", type: CubCalendar, selector: "cub-calendar", inputs: ["events", "multiYearSelector", "twelvehour", "startView", "timeInterval", "dateFilter", "preventSameDateTimeSelection", "type", "size", "startAt", "selected", "minDate", "maxDate"], outputs: ["selectedChange", "viewChanged", "userSelection"], exportAs: ["cubCalendar"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], animations: [
            cubDatetimepickerAnimations.transformPanel,
            cubDatetimepickerAnimations.fadeInCalendar,
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerContent, decorators: [{
            type: Component,
            args: [{ selector: 'cub-datetimepicker-content', host: {
                        class: 'cub-datetimepicker-content',
                        '[class.cub-datetimepicker-content-small]': 'datetimepicker?.size === "small"',
                        '[class.cub-datetimepicker-content-touch]': 'datetimepicker?.touchUi',
                        '[class.cub-datetimepicker-content-touch-small]': 'datetimepicker?.touchUi && datetimepicker?.size === "small"',
                        '[attr.mode]': 'datetimepicker.mode',
                        '[@transformPanel]': '_animationState',
                        '(@transformPanel.done)': '_animationDone.next()',
                    }, animations: [
                        cubDatetimepickerAnimations.transformPanel,
                        cubDatetimepickerAnimations.fadeInCalendar,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, inputs: ['color'], imports: [CubCdkTrapFocus, CubCalendar, NgClass], template: "<div\n  cubCdkTrapFocus\n  class=\"cub-datetimepicker-content-container\"\n  [attr.mode]=\"datetimepicker.mode\"\n>\n  <cub-calendar\n    [id]=\"datetimepicker.id\"\n    [ngClass]=\"datetimepicker.panelClass\"\n    [attr.mode]=\"datetimepicker.mode\"\n    [type]=\"datetimepicker.type\"\n    [startAt]=\"datetimepicker.startAt\"\n    [startView]=\"datetimepicker.startView\"\n    [maxDate]=\"datetimepicker._maxDate\"\n    [minDate]=\"datetimepicker._minDate\"\n    [dateFilter]=\"datetimepicker._dateFilter\"\n    [multiYearSelector]=\"datetimepicker.multiYearSelector\"\n    [preventSameDateTimeSelection]=\"datetimepicker.preventSameDateTimeSelection\"\n    [timeInterval]=\"datetimepicker.timeInterval\"\n    [twelvehour]=\"datetimepicker.twelvehour\"\n    [selected]=\"datetimepicker._selected\"\n    [size]=\"datetimepicker.size\"\n    [@fadeInCalendar]=\"'enter'\"\n    (selectedChange)=\"datetimepicker._select($event)\"\n    (viewChanged)=\"datetimepicker._viewChanged($event)\"\n    (userSelection)=\"datetimepicker.close()\"\n  >\n  </cub-calendar>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { _calendar: [{
                type: ViewChild,
                args: [CubCalendar, { static: true }]
            }] } });

/**
 * A calendar that is used as part of the datetimepicker.
 * @docs-private
 */
class CubCalendar {
    /**
     * The current active date. This determines which time period is shown and which date is
     * highlighted when using keyboard navigation.
     */
    get _activeDate() {
        return this._clampedActiveDate;
    }
    set _activeDate(value) {
        const oldActiveDate = this._clampedActiveDate;
        this._clampedActiveDate = this._adapter.clampDate(value, this.minDate, this.maxDate);
        if (oldActiveDate &&
            this._clampedActiveDate &&
            this.currentView === 'month' &&
            !this._adapter.sameMonthAndYear(oldActiveDate, this._clampedActiveDate)) {
            if (this._adapter.isInNextMonth(oldActiveDate, this._clampedActiveDate)) {
                this.calendarState('right');
            }
            else {
                this.calendarState('left');
            }
        }
    }
    /** Whether the calendar is in month view. */
    get currentView() {
        return this._currentView;
    }
    set currentView(view) {
        this._currentView = view;
        this.viewChanged.emit(view);
    }
    /** The label for the current calendar view. */
    get _yearLabel() {
        return this._adapter.getYearName(this._activeDate);
    }
    get _monthYearLabel() {
        if (this.currentView === 'multi-year') {
            // The offset from the active year to the "slot" for the starting year is the
            // *actual* first rendered year in the multi-year view, and the last year is
            // just yearsPerPage - 1 away.
            const activeYear = this._adapter.getYear(this._activeDate);
            const minYearOfPage = activeYear -
                getActiveOffset(this._adapter, this._activeDate, this.minDate, this.maxDate);
            const maxYearOfPage = minYearOfPage + yearsPerPage - 1;
            const minYearName = this._adapter.getYearName(this._adapter.createDate(minYearOfPage, 0, 1));
            const maxYearName = this._adapter.getYearName(this._adapter.createDate(maxYearOfPage, 0, 1));
            return this._intl.formatYearRange(minYearName, maxYearName);
        }
        return this.currentView === 'month'
            ? this._adapter.getMonthNames('short')[this._adapter.getMonth(this._activeDate)]
            : this._adapter.getYearName(this._activeDate);
    }
    get _dateLabel() {
        switch (this.type) {
            case 'month':
                return this._adapter.getMonthNames('short')[this._adapter.getMonth(this._activeDate)];
            default:
                return this._adapter.format(this._activeDate, this._dateFormats.display.popupHeaderDateLabel);
        }
    }
    get _hoursLabel() {
        let hour = this._adapter.getHour(this._activeDate);
        if (this.twelvehour) {
            if (hour === 0) {
                hour = 24;
            }
            hour = hour > 12 ? hour - 12 : hour;
        }
        return this._2digit(hour);
    }
    get _minutesLabel() {
        return this._2digit(this._adapter.getMinute(this._activeDate));
    }
    get _ariaLabelNext() {
        switch (this._currentView) {
            case 'month':
                return this._intl.nextMonthLabel;
            case 'year':
                return this._intl.nextYearLabel;
            case 'multi-year':
                return this._intl.nextMultiYearLabel;
            default:
                return '';
        }
    }
    get _ariaLabelPrev() {
        switch (this._currentView) {
            case 'month':
                return this._intl.prevMonthLabel;
            case 'year':
                return this._intl.prevYearLabel;
            case 'multi-year':
                return this._intl.prevMultiYearLabel;
            default:
                return '';
        }
    }
    get isInline() {
        return !this._datetimepickerContent;
    }
    /** 是否顯示 multi-year 的畫面，預設為 true。 */
    get multiYearSelector() {
        return this._multiYearSelector;
    }
    set multiYearSelector(value) {
        this._multiYearSelector = coerceBooleanProperty(value);
    }
    /** 是否時間選擇為 12 小時制，預設為 false。 */
    get twelvehour() {
        return this._twelvehour;
    }
    set twelvehour(value) {
        this._twelvehour = coerceBooleanProperty(value);
    }
    /** 元件的類型，預設為 'date'。 */
    get type() {
        return this._type;
    }
    set type(value) {
        this._type = value || 'date';
        if (this.type === 'year') {
            this.multiYearSelector = true;
        }
    }
    /** 元件初始顯示的日期時間，預設為 undefined。 */
    get startAt() {
        return this._startAt;
    }
    set startAt(value) {
        this._startAt = this._adapter.getValidDateOrNull(value);
    }
    /** 當前選中的日期時間，預設為 undefined。 */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = this._adapter.getValidDateOrNull(value);
    }
    /** 最小可選擇的日期時間，預設為 undefined。 */
    get minDate() {
        return this._minDate;
    }
    set minDate(value) {
        this._minDate = this._adapter.getValidDateOrNull(value);
    }
    /** 最大可選擇的日期時間，預設為 undefined。 */
    get maxDate() {
        return this._maxDate;
    }
    set maxDate(value) {
        this._maxDate = this._adapter.getValidDateOrNull(value);
    }
    constructor(_elementRef, _intl, _ngZone, _adapter, _datetimepickerContent, _dateFormats, changeDetectorRef) {
        this._elementRef = _elementRef;
        this._intl = _intl;
        this._ngZone = _ngZone;
        this._adapter = _adapter;
        this._datetimepickerContent = _datetimepickerContent;
        this._dateFormats = _dateFormats;
        this._clockView = 'hour';
        this._multiYearSelector = true;
        this._twelvehour = false;
        this._type = 'date';
        /** 事件清單，預設為 []。 */
        this.events = [];
        /** 元件的初始畫面，預設為 'month'。 */
        this.startView = 'month';
        /** 選擇時間時，一次跨幾分鐘，預設為 1。 */
        this.timeInterval = 1;
        /** 是否啟用防止使用者選擇相同的日期時間，預設為 false。 */
        this.preventSameDateTimeSelection = false;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 當選定日期時間變更時發出通知。 */
        this.selectedChange = new EventEmitter();
        /** 當元件畫面變更時發出通知。 */
        this.viewChanged = new EventEmitter();
        /** 當使用者選擇日期時間時發出通知。 */
        this.userSelection = new EventEmitter();
        /** Date filter for the month and year views. */
        this._dateFilterForViews = (date) => {
            return (!!date &&
                (!this.dateFilter ||
                    this.dateFilter(date, CubDatetimepickerFilterType.DATE)) &&
                (!this.minDate || this._adapter.compareDate(date, this.minDate) >= 0) &&
                (!this.maxDate || this._adapter.compareDate(date, this.maxDate) <= 0));
        };
        if (!this._adapter) {
            throw createMissingDateImplError('CubDatetimeAdapter');
        }
        if (!this._dateFormats) {
            throw createMissingDateImplError('CUB_DATETIME_FORMATS');
        }
        this._intlChanges = _intl.changes.subscribe(() => changeDetectorRef.markForCheck());
    }
    ngAfterContentInit() {
        this._activeDate = this.startAt || this._adapter.today();
        this._selectAMPM(this._activeDate);
        if (this.type === 'year') {
            this.currentView = 'multi-year';
        }
        else if (this.type === 'month') {
            this.currentView = 'year';
        }
        else if (this.type === 'time') {
            this.currentView = 'clock';
        }
        else {
            this.currentView = this.startView || 'month';
        }
    }
    ngOnDestroy() {
        this._intlChanges.unsubscribe();
    }
    _userSelected() {
        this.userSelection.emit();
    }
    /** Handles date selection in the month view. */
    _dateSelected(date) {
        if (this.type === 'date') {
            if (!this._adapter.sameDate(date, this.selected) ||
                !this.preventSameDateTimeSelection) {
                this._activeDate = date;
                this.selectedChange.emit(date);
            }
        }
        else {
            this._activeDate = date;
            this.currentView = 'clock';
        }
    }
    /** Handles month selection in the year view. */
    _monthSelected(month) {
        if (this.type === 'month') {
            if (!this._adapter.sameMonthAndYear(month, this.selected) ||
                !this.preventSameDateTimeSelection) {
                this.selectedChange.emit(this._adapter.getFirstDateOfMonth(month));
            }
        }
        else {
            this._activeDate = month;
            this.currentView = 'month';
            this._clockView = 'hour';
        }
    }
    /** Handles year selection in the multi year view. */
    _yearSelected(year) {
        if (this.type === 'year') {
            if (!this._adapter.sameYear(year, this.selected) ||
                !this.preventSameDateTimeSelection) {
                const normalizedDate = this._adapter.createDatetime(this._adapter.getYear(year), 0, 1, 0, 0);
                this.selectedChange.emit(normalizedDate);
            }
        }
        else {
            this._activeDate = year;
            this.currentView = 'year';
        }
    }
    _timeSelected(date) {
        if (this._clockView !== 'minute') {
            const enabled = (!this.minDate ||
                this._adapter.compareDatetime(date, this.minDate, false) >= 0) &&
                (!this.maxDate ||
                    this._adapter.compareDatetime(date, this.maxDate, false) <= 0) &&
                (!this.dateFilter ||
                    this.dateFilter(date, CubDatetimepickerFilterType.HOUR));
            if (!enabled) {
                return;
            }
            this._activeDate = this._updateDate(date);
            this._clockView = 'minute';
        }
        else {
            const enabled = (!this.minDate ||
                this._adapter.compareDatetime(date, this.minDate) >= 0) &&
                (!this.maxDate ||
                    this._adapter.compareDatetime(date, this.maxDate) <= 0) &&
                (!this.dateFilter ||
                    this.dateFilter(date, CubDatetimepickerFilterType.MINUTE));
            if (!enabled) {
                return;
            }
            if (!this._adapter.sameDatetime(date, this.selected) ||
                !this.preventSameDateTimeSelection) {
                this.selectedChange.emit(date);
            }
        }
    }
    _onActiveDateChange(date) {
        this._activeDate = date;
    }
    _updateDate(date) {
        return date;
    }
    _selectAMPM(date) {
        if (this._adapter.getHour(date) > 11) {
            this._AMPM = 'PM';
        }
        else {
            this._AMPM = 'AM';
        }
    }
    _ampmClicked(source) {
        if (source === this._AMPM) {
            return;
        }
        this._AMPM = source;
        if (this._AMPM === 'AM') {
            this._activeDate = this._adapter.addCalendarHours(this._activeDate, -12);
        }
        else {
            this._activeDate = this._adapter.addCalendarHours(this._activeDate, 12);
        }
    }
    _yearClicked() {
        if (this.type === 'year' || this.multiYearSelector) {
            this.currentView = 'multi-year';
            return;
        }
        this.currentView = 'year';
    }
    _handleYearKeydown(event) {
        this._yearClicked();
        event.preventDefault();
    }
    _monthClicked() {
        this.currentView = 'year';
    }
    _handleMonthKeydown(event) {
        this._monthClicked();
        event.preventDefault();
    }
    _dateClicked() {
        if (this.type !== 'month') {
            this.currentView = 'month';
        }
    }
    _handleDateKeydown(event) {
        this._dateClicked();
        event.preventDefault();
    }
    _hoursClicked() {
        this.currentView = 'clock';
        this._clockView = 'hour';
    }
    _handleHoursKeydown(event) {
        this._hoursClicked();
        event.preventDefault();
    }
    _minutesClicked() {
        this.currentView = 'clock';
        this._clockView = 'minute';
    }
    _handleMinutesKeydown(event) {
        this._minutesClicked();
        event.preventDefault();
    }
    /** Handles user clicks on the previous button. */
    _previousClicked() {
        this._activeDate =
            this.currentView === 'month'
                ? this._adapter.addCalendarMonths(this._activeDate, -1)
                : this._adapter.addCalendarYears(this._activeDate, this.currentView === 'year' ? -1 : -yearsPerPage);
    }
    /** Handles user clicks on the next button. */
    _nextClicked() {
        this._activeDate =
            this.currentView === 'month'
                ? this._adapter.addCalendarMonths(this._activeDate, 1)
                : this._adapter.addCalendarYears(this._activeDate, this.currentView === 'year' ? 1 : yearsPerPage);
    }
    /** Whether the previous period button is enabled. */
    _previousEnabled() {
        if (!this.minDate) {
            return true;
        }
        return !this.minDate || !this._isSameView(this._activeDate, this.minDate);
    }
    /** Whether the next period button is enabled. */
    _nextEnabled() {
        return !this.maxDate || !this._isSameView(this._activeDate, this.maxDate);
    }
    /** Handles keydown events on the calendar body. */
    _handleCalendarBodyKeydown(event) {
        if (document.activeElement?.tagName !== 'CUB-CALENDAR') {
            return;
        }
        // TODO(mmalerba): We currently allow keyboard navigation to disabled dates, but just prevent
        // disabled ones from being selected. This may not be ideal, we should look into whether
        // navigation should skip over disabled dates, and if so, how to implement that efficiently.
        if (this.currentView === 'month') {
            this._handleCalendarBodyKeydownInMonthView(event);
        }
        else if (this.currentView === 'year') {
            this._handleCalendarBodyKeydownInYearView(event);
        }
        else if (this.currentView === 'multi-year') {
            this._handleCalendarBodyKeydownInMultiYearView(event);
        }
        else {
            this._handleCalendarBodyKeydownInClockView(event);
        }
    }
    _calendarStateDone() {
        this._calendarState = '';
    }
    /** Whether the two dates represent the same view in the current view mode (month or year). */
    _isSameView(date1, date2) {
        if (this.currentView === 'month') {
            return (this._adapter.getYear(date1) === this._adapter.getYear(date2) &&
                this._adapter.getMonth(date1) === this._adapter.getMonth(date2));
        }
        if (this.currentView === 'year') {
            return this._adapter.getYear(date1) === this._adapter.getYear(date2);
        }
        // Otherwise we are in 'multi-year' view.
        return isSameMultiYearView(this._adapter, date1, date2, this.minDate, this.maxDate);
    }
    /** Handles keydown events on the calendar body when calendar is in month view. */
    _handleCalendarBodyKeydownInMonthView(event) {
        switch (event.keyCode) {
            case LEFT_ARROW:
                this._activeDate = this._adapter.addCalendarDays(this._activeDate, -1);
                break;
            case RIGHT_ARROW:
                this._activeDate = this._adapter.addCalendarDays(this._activeDate, 1);
                break;
            case UP_ARROW:
                this._activeDate = this._adapter.addCalendarDays(this._activeDate, -7);
                break;
            case DOWN_ARROW:
                this._activeDate = this._adapter.addCalendarDays(this._activeDate, 7);
                break;
            case HOME:
                this._activeDate = this._adapter.addCalendarDays(this._activeDate, 1 - this._adapter.getDate(this._activeDate));
                break;
            case END:
                this._activeDate = this._adapter.addCalendarDays(this._activeDate, this._adapter.getNumDaysInMonth(this._activeDate) -
                    this._adapter.getDate(this._activeDate));
                break;
            case PAGE_UP:
                this._activeDate = event.altKey
                    ? this._adapter.addCalendarYears(this._activeDate, -1)
                    : this._adapter.addCalendarMonths(this._activeDate, -1);
                break;
            case PAGE_DOWN:
                this._activeDate = event.altKey
                    ? this._adapter.addCalendarYears(this._activeDate, 1)
                    : this._adapter.addCalendarMonths(this._activeDate, 1);
                break;
            case ENTER:
                if (this._dateFilterForViews(this._activeDate)) {
                    this._dateSelected(this._activeDate);
                    // Prevent unexpected default actions such as form submission.
                    event.preventDefault();
                }
                return;
            default:
                // Don't prevent default or focus active cell on keys that we don't explicitly handle.
                return;
        }
        // Prevent unexpected default actions such as form submission.
        event.preventDefault();
    }
    /** Handles keydown events on the calendar body when calendar is in year view. */
    _handleCalendarBodyKeydownInYearView(event) {
        switch (event.keyCode) {
            case LEFT_ARROW:
                this._activeDate = this._adapter.addCalendarMonths(this._activeDate, -1);
                break;
            case RIGHT_ARROW:
                this._activeDate = this._adapter.addCalendarMonths(this._activeDate, 1);
                break;
            case UP_ARROW:
                this._activeDate = this._prevMonthInSameCol(this._activeDate);
                break;
            case DOWN_ARROW:
                this._activeDate = this._nextMonthInSameCol(this._activeDate);
                break;
            case HOME:
                this._activeDate = this._adapter.addCalendarMonths(this._activeDate, -this._adapter.getMonth(this._activeDate));
                break;
            case END:
                this._activeDate = this._adapter.addCalendarMonths(this._activeDate, 11 - this._adapter.getMonth(this._activeDate));
                break;
            case PAGE_UP:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, event.altKey ? -10 : -1);
                break;
            case PAGE_DOWN:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, event.altKey ? 10 : 1);
                break;
            case ENTER:
                this._monthSelected(this._activeDate);
                break;
            default:
                // Don't prevent default or focus active cell on keys that we don't explicitly handle.
                return;
        }
        // Prevent unexpected default actions such as form submission.
        event.preventDefault();
    }
    /** Handles keydown events on the calendar body when calendar is in multi-year view. */
    _handleCalendarBodyKeydownInMultiYearView(event) {
        switch (event.keyCode) {
            case LEFT_ARROW:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, -1);
                break;
            case RIGHT_ARROW:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, 1);
                break;
            case UP_ARROW:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, -yearsPerRow);
                break;
            case DOWN_ARROW:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, yearsPerRow);
                break;
            case HOME:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, -getActiveOffset(this._adapter, this._activeDate, this.minDate, this.maxDate));
                break;
            case END:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, yearsPerPage -
                    getActiveOffset(this._adapter, this._activeDate, this.minDate, this.maxDate) -
                    1);
                break;
            case PAGE_UP:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, event.altKey ? -yearsPerPage * 10 : -yearsPerPage);
                break;
            case PAGE_DOWN:
                this._activeDate = this._adapter.addCalendarYears(this._activeDate, event.altKey ? yearsPerPage * 10 : yearsPerPage);
                break;
            case ENTER:
                this._yearSelected(this._activeDate);
                break;
            default:
                // Don't prevent default or focus active cell on keys that we don't explicitly handle.
                return;
        }
    }
    /** Handles keydown events on the calendar body when calendar is in month view. */
    _handleCalendarBodyKeydownInClockView(event) {
        switch (event.keyCode) {
            case UP_ARROW:
                this._activeDate =
                    this._clockView === 'hour'
                        ? this._adapter.addCalendarHours(this._activeDate, 1)
                        : this._adapter.addCalendarMinutes(this._activeDate, 1);
                break;
            case DOWN_ARROW:
                this._activeDate =
                    this._clockView === 'hour'
                        ? this._adapter.addCalendarHours(this._activeDate, -1)
                        : this._adapter.addCalendarMinutes(this._activeDate, -1);
                break;
            case ENTER:
                this._timeSelected(this._activeDate);
                return;
            default:
                // Don't prevent default or focus active cell on keys that we don't explicitly handle.
                return;
        }
        // Prevent unexpected default actions such as form submission.
        event.preventDefault();
    }
    /**
     * Determine the date for the month that comes before the given month in the same column in the
     * calendar table.
     */
    _prevMonthInSameCol(date) {
        // Determine how many months to jump forward given that there are 2 empty slots at the beginning
        // of each year.
        const increment = this._adapter.getMonth(date) <= 4
            ? -5
            : this._adapter.getMonth(date) >= 7
                ? -7
                : -12;
        return this._adapter.addCalendarMonths(date, increment);
    }
    /**
     * Determine the date for the month that comes after the given month in the same column in the
     * calendar table.
     */
    _nextMonthInSameCol(date) {
        // Determine how many months to jump forward given that there are 2 empty slots at the beginning
        // of each year.
        const increment = this._adapter.getMonth(date) <= 4
            ? 7
            : this._adapter.getMonth(date) >= 7
                ? 5
                : 12;
        return this._adapter.addCalendarMonths(date, increment);
    }
    calendarState(direction) {
        this._calendarState = direction;
    }
    _2digit(n) {
        return ('00' + n).slice(-2);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCalendar, deps: [{ token: i0.ElementRef }, { token: CubDatepickerIntl }, { token: i0.NgZone }, { token: CubDatetimeAdapter, optional: true }, { token: CubDatetimepickerContent, optional: true }, { token: CUB_DATETIME_FORMATS, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubCalendar, isStandalone: true, selector: "cub-calendar", inputs: { events: "events", multiYearSelector: "multiYearSelector", twelvehour: "twelvehour", startView: "startView", timeInterval: "timeInterval", dateFilter: "dateFilter", preventSameDateTimeSelection: "preventSameDateTimeSelection", type: "type", size: "size", startAt: "startAt", selected: "selected", minDate: "minDate", maxDate: "maxDate" }, outputs: { selectedChange: "selectedChange", viewChanged: "viewChanged", userSelection: "userSelection" }, host: { attributes: { "tabindex": "0" }, listeners: { "keydown": "_handleCalendarBodyKeydown($event)" }, properties: { "class.cub-calendar-small": "size === \"small\"", "class.cub-calendar-inline": "isInline" }, classAttribute: "cub-calendar" }, exportAs: ["cubCalendar"], ngImport: i0, template: "<div class=\"cub-calendar-header\">\n  <ng-container *ngIf=\"!isInline; else inlineHeaderTemplate\">\n    <div\n      *ngIf=\"type !== 'time'\"\n      cubRipple\n      role=\"button\"\n      class=\"cub-calendar-header-year\"\n      cubRippleClass=\"cub-calendar-header-year-ripple\"\n      [class.cub-active]=\"\n        currentView === 'year' || currentView === 'multi-year'\n      \"\n      [class.clickable]=\"multiYearSelector && currentView === 'year'\"\n      [attr.tabindex]=\"0\"\n      (click)=\"_yearClicked()\"\n      (keydown.enter)=\"_handleYearKeydown($event)\"\n    >\n      <span>{{ _yearLabel }}</span>\n\n      <ng-container *ngIf=\"multiYearSelector || type === 'year'\">\n        <span\n          class=\"cub-calendar-header-year-dropdown cub-icon-caret-down-filled\"\n        ></span>\n      </ng-container>\n\n      <span\n        class=\"cub-persistent-ripple cub-calendar-header-year-persistent-ripple\"\n      ></span>\n    </div>\n    <div class=\"cub-calendar-header-date-time\">\n      <span\n        *ngIf=\"type !== 'time' && type !== 'year'\"\n        cubRipple\n        role=\"button\"\n        class=\"cub-calendar-header-date\"\n        cubRippleClass=\"cub-calendar-header-date-ripple\"\n        [class.cub-active]=\"currentView === 'month'\"\n        [class.not-clickable]=\"type === 'month'\"\n        [attr.tabindex]=\"0\"\n        (click)=\"_dateClicked()\"\n        (keydown.enter)=\"_handleDateKeydown($event)\"\n      >\n        {{ _dateLabel }}\n\n        <span\n          class=\"cub-persistent-ripple cub-calendar-header-date-persistent-ripple\"\n        ></span>\n      </span>\n      <span\n        *ngIf=\"type.endsWith('time')\"\n        class=\"cub-calendar-header-time\"\n        [class.cub-active]=\"currentView === 'clock'\"\n      >\n        <span class=\"cub-calendar-header-hour-minute-container\">\n          <span\n            cubRipple\n            role=\"button\"\n            class=\"cub-calendar-header-hours\"\n            cubRippleClass=\"cub-calendar-header-hours-ripple\"\n            [class.cub-active]=\"_clockView === 'hour'\"\n            [attr.tabindex]=\"0\"\n            (click)=\"_hoursClicked()\"\n            (keydown.enter)=\"_handleHoursKeydown($event)\"\n          >\n            {{ _hoursLabel }}\n\n            <span\n              class=\"cub-persistent-ripple cub-calendar-header-hours-persistent-ripple\"\n            ></span>\n          </span>\n          <span class=\"cub-calendar-header-hour-minute-separator\">:</span>\n          <span\n            cubRipple\n            role=\"button\"\n            class=\"cub-calendar-header-minutes\"\n            cubRippleClass=\"cub-calendar-header-minutes-ripple\"\n            [class.cub-active]=\"_clockView === 'minute'\"\n            [attr.tabindex]=\"0\"\n            (click)=\"_minutesClicked()\"\n            (keydown.enter)=\"_handleMinutesKeydown($event)\"\n          >\n            {{ _minutesLabel }}\n\n            <span\n              class=\"cub-persistent-ripple cub-calendar-header-minutes-persistent-ripple\"\n            ></span>\n          </span>\n        </span>\n        <span *ngIf=\"twelvehour\" class=\"cub-calendar-header-ampm-container\">\n          <span\n            role=\"button\"\n            class=\"cub-calendar-header-ampm\"\n            [class.active]=\"_AMPM === 'AM'\"\n            (click)=\"_ampmClicked('AM')\"\n          >\n            AM\n          </span>\n          <span\n            role=\"button\"\n            class=\"cub-calendar-header-ampm\"\n            [class.active]=\"_AMPM === 'PM'\"\n            (click)=\"_ampmClicked('PM')\"\n          >\n            PM\n          </span>\n        </span>\n      </span>\n    </div>\n  </ng-container>\n\n  <ng-template #inlineHeaderTemplate>\n    <div class=\"cub-calendar-header-year-month-container\">\n      <div\n        *ngIf=\"type !== 'time'\"\n        cubRipple\n        role=\"button\"\n        class=\"cub-calendar-header-year\"\n        cubRippleClass=\"cub-calendar-header-year-ripple\"\n        [class.clickable]=\"multiYearSelector && currentView === 'year'\"\n        [attr.tabindex]=\"0\"\n        (click)=\"_yearClicked()\"\n        (keydown.enter)=\"_handleYearKeydown($event)\"\n      >\n        <span>{{\n          currentView === \"multi-year\" ? _monthYearLabel : _yearLabel\n        }}</span>\n\n        <ng-container *ngIf=\"currentView === 'month'\">\n          <span\n            class=\"cub-calendar-header-year-dropdown cub-icon-caret-down-filled\"\n          ></span>\n        </ng-container>\n\n        <span\n          class=\"cub-persistent-ripple cub-calendar-header-year-persistent-ripple\"\n        ></span>\n      </div>\n\n      <div\n        *ngIf=\"type !== 'time' && type !== 'year' && currentView === 'month'\"\n        cubRipple\n        role=\"button\"\n        class=\"cub-calendar-header-month\"\n        cubRippleClass=\"cub-calendar-header-month-ripple\"\n        [class.not-clickable]=\"type === 'month'\"\n        [attr.tabindex]=\"0\"\n        (click)=\"_monthClicked()\"\n        (keydown.enter)=\"_handleMonthKeydown($event)\"\n      >\n        <span>{{ _monthYearLabel }}</span>\n\n        <span\n          class=\"cub-calendar-header-month-dropdown cub-icon-caret-down-filled\"\n        ></span>\n\n        <span\n          class=\"cub-persistent-ripple cub-calendar-header-month-persistent-ripple\"\n        ></span>\n      </div>\n    </div>\n\n    <div class=\"cub-calendar-controls\">\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-previous-button\"\n        [disabled]=\"!_previousEnabled()\"\n        [attr.aria-label]=\"_ariaLabelPrev\"\n        [attr.aria-disabled]=\"!_previousEnabled()\"\n        (click)=\"_previousClicked()\"\n      >\n        <span class=\"cub-icon-chevron-left\"></span>\n      </button>\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-next-button\"\n        [disabled]=\"!_nextEnabled()\"\n        [attr.aria-label]=\"_ariaLabelNext\"\n        [attr.aria-disabled]=\"!_nextEnabled()\"\n        (click)=\"_nextClicked()\"\n      >\n        <span class=\"cub-icon-chevron-right\"></span>\n      </button>\n    </div>\n  </ng-template>\n</div>\n\n<cub-divider></cub-divider>\n\n<div class=\"cub-calendar-content\" [ngSwitch]=\"currentView\">\n  <div\n    *ngIf=\"\n      !isInline &&\n      (currentView === 'month' ||\n        currentView === 'year' ||\n        currentView === 'multi-year')\n    \"\n    class=\"cub-month-content\"\n  >\n    <div class=\"cub-calendar-controls\">\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-previous-button\"\n        [disabled]=\"!_previousEnabled()\"\n        [attr.aria-label]=\"_ariaLabelPrev\"\n        [attr.aria-disabled]=\"!_previousEnabled()\"\n        (click)=\"_previousClicked()\"\n      >\n        <span class=\"cub-icon-chevron-left\"></span>\n      </button>\n      <div\n        class=\"cub-calendar-period-button\"\n        [@slideCalendar]=\"_calendarState\"\n        (@slideCalendar.done)=\"_calendarStateDone()\"\n      >\n        {{ _monthYearLabel }}\n      </div>\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-next-button\"\n        [disabled]=\"!_nextEnabled()\"\n        [attr.aria-label]=\"_ariaLabelNext\"\n        [attr.aria-disabled]=\"!_nextEnabled()\"\n        (click)=\"_nextClicked()\"\n      >\n        <span class=\"cub-icon-chevron-right\"></span>\n      </button>\n    </div>\n  </div>\n  <cub-month-view\n    *ngSwitchCase=\"'month'\"\n    [activeDate]=\"_activeDate\"\n    [dateFilter]=\"_dateFilterForViews\"\n    [selected]=\"selected!\"\n    [type]=\"type\"\n    [size]=\"size\"\n    [isInline]=\"isInline\"\n    [events]=\"events\"\n    (selectedChange)=\"_dateSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-month-view>\n  <cub-year-view\n    *ngSwitchCase=\"'year'\"\n    [activeDate]=\"_activeDate\"\n    [dateFilter]=\"_dateFilterForViews\"\n    [selected]=\"selected!\"\n    [type]=\"type\"\n    [size]=\"size\"\n    (selectedChange)=\"_monthSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-year-view>\n  <cub-multi-year-view\n    *ngSwitchCase=\"'multi-year'\"\n    [activeDate]=\"_activeDate\"\n    [dateFilter]=\"_dateFilterForViews\"\n    [maxDate]=\"maxDate\"\n    [minDate]=\"minDate\"\n    [selected]=\"selected!\"\n    [type]=\"type\"\n    [size]=\"size\"\n    (selectedChange)=\"_yearSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-multi-year-view>\n  <cub-clock\n    *ngSwitchDefault\n    [AMPM]=\"_AMPM\"\n    [dateFilter]=\"dateFilter\"\n    [interval]=\"timeInterval\"\n    [maxDate]=\"maxDate\"\n    [minDate]=\"minDate\"\n    [selected]=\"_activeDate\"\n    [startView]=\"_clockView\"\n    [twelvehour]=\"twelvehour\"\n    [size]=\"size\"\n    (activeDateChange)=\"_onActiveDateChange($event)\"\n    (selectedChange)=\"_timeSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-clock>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: CubDivider, selector: "[cubDivider], cub-divider", inputs: ["appearance", "orientation"], exportAs: ["cubDivider"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "component", type: CubMonthView, selector: "cub-month-view", inputs: ["events", "type", "size", "dateFilter", "activeDate", "selected", "isInline"], outputs: ["selectedChange", "userSelection"], exportAs: ["cubMonthView"] }, { kind: "component", type: CubYearView, selector: "cub-year-view", inputs: ["type", "size", "dateFilter", "activeDate", "selected"], outputs: ["selectedChange", "userSelection"], exportAs: ["cubYearView"] }, { kind: "component", type: CubMultiYearView, selector: "cub-multi-year-view", inputs: ["type", "size", "dateFilter", "activeDate", "selected", "minDate", "maxDate"], outputs: ["selectedChange", "userSelection"], exportAs: ["cubMultiYearView"] }, { kind: "directive", type: NgSwitchDefault, selector: "[ngSwitchDefault]" }, { kind: "component", type: CubClock, selector: "cub-clock", inputs: ["size", "dateFilter", "interval", "twelvehour", "AMPM", "activeDate", "selected", "minDate", "maxDate", "startView"], outputs: ["selectedChange", "activeDateChange", "userSelection"], exportAs: ["cubClock"] }], animations: [cubDatetimepickerAnimations.slideCalendar], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubCalendar, decorators: [{
            type: Component,
            args: [{ selector: 'cub-calendar', host: {
                        class: 'cub-calendar',
                        tabindex: '0',
                        '[class.cub-calendar-small]': 'size === "small"',
                        '[class.cub-calendar-inline]': 'isInline',
                        '(keydown)': '_handleCalendarBodyKeydown($event)',
                    }, exportAs: 'cubCalendar', animations: [cubDatetimepickerAnimations.slideCalendar], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        CubRipple,
                        CubDivider,
                        NgSwitch,
                        CubIconButton,
                        NgSwitchCase,
                        CubMonthView,
                        CubYearView,
                        CubMultiYearView,
                        NgSwitchDefault,
                        CubClock,
                    ], template: "<div class=\"cub-calendar-header\">\n  <ng-container *ngIf=\"!isInline; else inlineHeaderTemplate\">\n    <div\n      *ngIf=\"type !== 'time'\"\n      cubRipple\n      role=\"button\"\n      class=\"cub-calendar-header-year\"\n      cubRippleClass=\"cub-calendar-header-year-ripple\"\n      [class.cub-active]=\"\n        currentView === 'year' || currentView === 'multi-year'\n      \"\n      [class.clickable]=\"multiYearSelector && currentView === 'year'\"\n      [attr.tabindex]=\"0\"\n      (click)=\"_yearClicked()\"\n      (keydown.enter)=\"_handleYearKeydown($event)\"\n    >\n      <span>{{ _yearLabel }}</span>\n\n      <ng-container *ngIf=\"multiYearSelector || type === 'year'\">\n        <span\n          class=\"cub-calendar-header-year-dropdown cub-icon-caret-down-filled\"\n        ></span>\n      </ng-container>\n\n      <span\n        class=\"cub-persistent-ripple cub-calendar-header-year-persistent-ripple\"\n      ></span>\n    </div>\n    <div class=\"cub-calendar-header-date-time\">\n      <span\n        *ngIf=\"type !== 'time' && type !== 'year'\"\n        cubRipple\n        role=\"button\"\n        class=\"cub-calendar-header-date\"\n        cubRippleClass=\"cub-calendar-header-date-ripple\"\n        [class.cub-active]=\"currentView === 'month'\"\n        [class.not-clickable]=\"type === 'month'\"\n        [attr.tabindex]=\"0\"\n        (click)=\"_dateClicked()\"\n        (keydown.enter)=\"_handleDateKeydown($event)\"\n      >\n        {{ _dateLabel }}\n\n        <span\n          class=\"cub-persistent-ripple cub-calendar-header-date-persistent-ripple\"\n        ></span>\n      </span>\n      <span\n        *ngIf=\"type.endsWith('time')\"\n        class=\"cub-calendar-header-time\"\n        [class.cub-active]=\"currentView === 'clock'\"\n      >\n        <span class=\"cub-calendar-header-hour-minute-container\">\n          <span\n            cubRipple\n            role=\"button\"\n            class=\"cub-calendar-header-hours\"\n            cubRippleClass=\"cub-calendar-header-hours-ripple\"\n            [class.cub-active]=\"_clockView === 'hour'\"\n            [attr.tabindex]=\"0\"\n            (click)=\"_hoursClicked()\"\n            (keydown.enter)=\"_handleHoursKeydown($event)\"\n          >\n            {{ _hoursLabel }}\n\n            <span\n              class=\"cub-persistent-ripple cub-calendar-header-hours-persistent-ripple\"\n            ></span>\n          </span>\n          <span class=\"cub-calendar-header-hour-minute-separator\">:</span>\n          <span\n            cubRipple\n            role=\"button\"\n            class=\"cub-calendar-header-minutes\"\n            cubRippleClass=\"cub-calendar-header-minutes-ripple\"\n            [class.cub-active]=\"_clockView === 'minute'\"\n            [attr.tabindex]=\"0\"\n            (click)=\"_minutesClicked()\"\n            (keydown.enter)=\"_handleMinutesKeydown($event)\"\n          >\n            {{ _minutesLabel }}\n\n            <span\n              class=\"cub-persistent-ripple cub-calendar-header-minutes-persistent-ripple\"\n            ></span>\n          </span>\n        </span>\n        <span *ngIf=\"twelvehour\" class=\"cub-calendar-header-ampm-container\">\n          <span\n            role=\"button\"\n            class=\"cub-calendar-header-ampm\"\n            [class.active]=\"_AMPM === 'AM'\"\n            (click)=\"_ampmClicked('AM')\"\n          >\n            AM\n          </span>\n          <span\n            role=\"button\"\n            class=\"cub-calendar-header-ampm\"\n            [class.active]=\"_AMPM === 'PM'\"\n            (click)=\"_ampmClicked('PM')\"\n          >\n            PM\n          </span>\n        </span>\n      </span>\n    </div>\n  </ng-container>\n\n  <ng-template #inlineHeaderTemplate>\n    <div class=\"cub-calendar-header-year-month-container\">\n      <div\n        *ngIf=\"type !== 'time'\"\n        cubRipple\n        role=\"button\"\n        class=\"cub-calendar-header-year\"\n        cubRippleClass=\"cub-calendar-header-year-ripple\"\n        [class.clickable]=\"multiYearSelector && currentView === 'year'\"\n        [attr.tabindex]=\"0\"\n        (click)=\"_yearClicked()\"\n        (keydown.enter)=\"_handleYearKeydown($event)\"\n      >\n        <span>{{\n          currentView === \"multi-year\" ? _monthYearLabel : _yearLabel\n        }}</span>\n\n        <ng-container *ngIf=\"currentView === 'month'\">\n          <span\n            class=\"cub-calendar-header-year-dropdown cub-icon-caret-down-filled\"\n          ></span>\n        </ng-container>\n\n        <span\n          class=\"cub-persistent-ripple cub-calendar-header-year-persistent-ripple\"\n        ></span>\n      </div>\n\n      <div\n        *ngIf=\"type !== 'time' && type !== 'year' && currentView === 'month'\"\n        cubRipple\n        role=\"button\"\n        class=\"cub-calendar-header-month\"\n        cubRippleClass=\"cub-calendar-header-month-ripple\"\n        [class.not-clickable]=\"type === 'month'\"\n        [attr.tabindex]=\"0\"\n        (click)=\"_monthClicked()\"\n        (keydown.enter)=\"_handleMonthKeydown($event)\"\n      >\n        <span>{{ _monthYearLabel }}</span>\n\n        <span\n          class=\"cub-calendar-header-month-dropdown cub-icon-caret-down-filled\"\n        ></span>\n\n        <span\n          class=\"cub-persistent-ripple cub-calendar-header-month-persistent-ripple\"\n        ></span>\n      </div>\n    </div>\n\n    <div class=\"cub-calendar-controls\">\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-previous-button\"\n        [disabled]=\"!_previousEnabled()\"\n        [attr.aria-label]=\"_ariaLabelPrev\"\n        [attr.aria-disabled]=\"!_previousEnabled()\"\n        (click)=\"_previousClicked()\"\n      >\n        <span class=\"cub-icon-chevron-left\"></span>\n      </button>\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-next-button\"\n        [disabled]=\"!_nextEnabled()\"\n        [attr.aria-label]=\"_ariaLabelNext\"\n        [attr.aria-disabled]=\"!_nextEnabled()\"\n        (click)=\"_nextClicked()\"\n      >\n        <span class=\"cub-icon-chevron-right\"></span>\n      </button>\n    </div>\n  </ng-template>\n</div>\n\n<cub-divider></cub-divider>\n\n<div class=\"cub-calendar-content\" [ngSwitch]=\"currentView\">\n  <div\n    *ngIf=\"\n      !isInline &&\n      (currentView === 'month' ||\n        currentView === 'year' ||\n        currentView === 'multi-year')\n    \"\n    class=\"cub-month-content\"\n  >\n    <div class=\"cub-calendar-controls\">\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-previous-button\"\n        [disabled]=\"!_previousEnabled()\"\n        [attr.aria-label]=\"_ariaLabelPrev\"\n        [attr.aria-disabled]=\"!_previousEnabled()\"\n        (click)=\"_previousClicked()\"\n      >\n        <span class=\"cub-icon-chevron-left\"></span>\n      </button>\n      <div\n        class=\"cub-calendar-period-button\"\n        [@slideCalendar]=\"_calendarState\"\n        (@slideCalendar.done)=\"_calendarStateDone()\"\n      >\n        {{ _monthYearLabel }}\n      </div>\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"text\"\n        class=\"cub-calendar-next-button\"\n        [disabled]=\"!_nextEnabled()\"\n        [attr.aria-label]=\"_ariaLabelNext\"\n        [attr.aria-disabled]=\"!_nextEnabled()\"\n        (click)=\"_nextClicked()\"\n      >\n        <span class=\"cub-icon-chevron-right\"></span>\n      </button>\n    </div>\n  </div>\n  <cub-month-view\n    *ngSwitchCase=\"'month'\"\n    [activeDate]=\"_activeDate\"\n    [dateFilter]=\"_dateFilterForViews\"\n    [selected]=\"selected!\"\n    [type]=\"type\"\n    [size]=\"size\"\n    [isInline]=\"isInline\"\n    [events]=\"events\"\n    (selectedChange)=\"_dateSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-month-view>\n  <cub-year-view\n    *ngSwitchCase=\"'year'\"\n    [activeDate]=\"_activeDate\"\n    [dateFilter]=\"_dateFilterForViews\"\n    [selected]=\"selected!\"\n    [type]=\"type\"\n    [size]=\"size\"\n    (selectedChange)=\"_monthSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-year-view>\n  <cub-multi-year-view\n    *ngSwitchCase=\"'multi-year'\"\n    [activeDate]=\"_activeDate\"\n    [dateFilter]=\"_dateFilterForViews\"\n    [maxDate]=\"maxDate\"\n    [minDate]=\"minDate\"\n    [selected]=\"selected!\"\n    [type]=\"type\"\n    [size]=\"size\"\n    (selectedChange)=\"_yearSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-multi-year-view>\n  <cub-clock\n    *ngSwitchDefault\n    [AMPM]=\"_AMPM\"\n    [dateFilter]=\"dateFilter\"\n    [interval]=\"timeInterval\"\n    [maxDate]=\"maxDate\"\n    [minDate]=\"minDate\"\n    [selected]=\"_activeDate\"\n    [startView]=\"_clockView\"\n    [twelvehour]=\"twelvehour\"\n    [size]=\"size\"\n    (activeDateChange)=\"_onActiveDateChange($event)\"\n    (selectedChange)=\"_timeSelected($event)\"\n    (userSelection)=\"_userSelected()\"\n  >\n  </cub-clock>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: CubDatepickerIntl }, { type: i0.NgZone }, { type: CubDatetimeAdapter, decorators: [{
                    type: Optional
                }] }, { type: CubDatetimepickerContent, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATETIME_FORMATS]
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { events: [{
                type: Input
            }], multiYearSelector: [{
                type: Input
            }], twelvehour: [{
                type: Input
            }], startView: [{
                type: Input
            }], timeInterval: [{
                type: Input
            }], dateFilter: [{
                type: Input
            }], preventSameDateTimeSelection: [{
                type: Input
            }], type: [{
                type: Input
            }], size: [{
                type: Input
            }], startAt: [{
                type: Input
            }], selected: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], viewChanged: [{
                type: Output
            }], userSelection: [{
                type: Output
            }] } });

/** Used to generate a unique ID for each datetimepicker instance. */
let datetimepickerUid = 0;
class CubDatetimepicker {
    /** The currently selected date. */
    get _selected() {
        return this._validSelected;
    }
    set _selected(value) {
        this._validSelected = value;
    }
    /** The minimum selectable date. */
    get _minDate() {
        return this.datetimepickerInput && this.datetimepickerInput.min;
    }
    /** The maximum selectable date. */
    get _maxDate() {
        return this.datetimepickerInput && this.datetimepickerInput.max;
    }
    get _dateFilter() {
        return this.datetimepickerInput && this.datetimepickerInput._dateFilter;
    }
    /** 是否顯示 multi-year 的畫面，預設為 true。 */
    get multiYearSelector() {
        return this._multiYearSelector;
    }
    set multiYearSelector(value) {
        this._multiYearSelector = coerceBooleanProperty(value);
    }
    /** 選擇器的類別樣式，支援與 ngClass 相同的語法，預設為 undefined。 */
    get panelClass() {
        return this._panelClass;
    }
    set panelClass(value) {
        this._panelClass = coerceStringArray(value);
    }
    /** 是否選擇器為展開狀態，預設為 false。 */
    get opened() {
        return this._opened;
    }
    set opened(value) {
        coerceBooleanProperty(value) ? this.open() : this.close();
    }
    /** 元件顏色，預設值為 undefined。 */
    get color() {
        return this._color;
    }
    set color(value) {
        this._color = value;
    }
    /** 元件初始顯示的日期時間，預設為 undefined。 */
    get startAt() {
        // If an explicit startAt is set we start there, otherwise we start at whatever the currently
        // selected value is.
        return (this._startAt ||
            (this.datetimepickerInput ? this.datetimepickerInput.value : null));
    }
    set startAt(date) {
        this._startAt = this._dateAdapter.getValidDateOrNull(date);
    }
    /** 元件的類型，預設為 'date'。 */
    get type() {
        return this._type;
    }
    set type(value) {
        this._type = value || 'date';
        this._typeChange.next(this._type);
    }
    /** 是否禁用展開選擇器，預設為 undefined。 */
    get disabled() {
        return this._disabled === undefined && this.datetimepickerInput
            ? this.datetimepickerInput.disabled
            : !!this._disabled;
    }
    set disabled(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== this._disabled) {
            this._disabled = newValue;
            this._disabledChange.next(newValue);
        }
    }
    /** 是否選擇器收闔時，將焦點恢復到先前獲得焦點的元素上，預設為 true。 */
    get restoreFocus() {
        return this._restoreFocus;
    }
    set restoreFocus(value) {
        this._restoreFocus = coerceBooleanProperty(value);
    }
    // 調整瀏覽器視窗，判斷是否開啟 touchUi
    onResize(event) {
        const windowWidth = event.target.innerWidth;
        this.touchUi = windowWidth < DEVICE_BREAKPOINT.TABLET_PORTRAIT;
    }
    constructor(_overlay, _ngZone, _viewContainerRef, _scrollStrategy, _dateAdapter, _dir) {
        this._overlay = _overlay;
        this._ngZone = _ngZone;
        this._viewContainerRef = _viewContainerRef;
        this._scrollStrategy = _scrollStrategy;
        this._dateAdapter = _dateAdapter;
        this._dir = _dir;
        /** The id for the datetimepicker calendar. */
        this.id = `cub-datetimepicker-${datetimepickerUid++}`;
        /** Emits when the datetimepicker is disabled. */
        this._disabledChange = new Subject();
        this._typeChange = new Subject();
        /** Whether the clock uses 12 hour format. */
        /** 目前只開放 '24 hour format' Start */
        // @Input()
        // get twelvehour(): boolean {
        //   return this._twelvehour;
        // }
        // set twelvehour(value: boolean) {
        //   this._twelvehour = coerceBooleanProperty(value);
        // }
        // private _twelvehour = false;
        this.twelvehour = false;
        /** End */
        /** The display mode of datetimepicker. */
        /** 目前只開放 'portrait' Start */
        // @Input() mode: CubDatetimepickerMode = 'auto';
        this.mode = 'portrait';
        /** End */
        /**
         * Whether the calendar UI is in touch mode. In touch mode the calendar opens in a dialog rather
         * than a popup and elements have more padding to allow for bigger touch targets.
         */
        /** 目前只在 Mobile 開放 'touchUi' Start */
        // @Input()
        // get touchUi(): boolean {
        //   return this._touchUi;
        // }
        // set touchUi(value: boolean) {
        //   this._touchUi = coerceBooleanProperty(value);
        // }
        // private _touchUi = false;
        this.touchUi = false;
        /** End */
        this._document = inject(DOCUMENT);
        this._validSelected = null;
        /** The element that was focused before the datetimepicker was opened. */
        this._focusedElementBeforeOpen = null;
        /** Unique class that will be added to the backdrop so that the test harnesses can look it up. */
        this._backdropHarnessClass = `${this.id}-backdrop`;
        this._inputStateChanges = Subscription.EMPTY;
        this._multiYearSelector = true;
        this._opened = false;
        this._type = 'date';
        this._restoreFocus = true;
        /** 元件的初始畫面，預設為 'month'。 */
        this.startView = 'month';
        /** 選擇時間時，一次跨幾分鐘，預設為 1。 */
        this.timeInterval = 1;
        /** 是否啟用防止使用者選擇相同的日期時間，預設為 false。 */
        this.preventSameDateTimeSelection = false;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 選擇器在 X 軸上的首選位置，預設為 'start'。 */
        this.xPosition = 'start';
        /** 選擇器在 Y 軸上的首選位置，預設為 'below'。 */
        this.yPosition = 'below';
        /** 當選定日期時間變更時發出通知。 */
        this.selectedChange = new EventEmitter();
        /** 當選擇器展開時發出通知。 */
        this.openedStream = new EventEmitter();
        /** 當選擇器收闔時發出通知。 */
        this.closedStream = new EventEmitter();
        /** 當元件畫面變更時發出通知。 */
        this.viewChanged = new EventEmitter();
        if (!this._dateAdapter) {
            throw createMissingDateImplError('CubDateAdapter');
        }
    }
    ngOnInit() {
        const windowWidth = window.innerWidth;
        this.touchUi = windowWidth < DEVICE_BREAKPOINT.TABLET_PORTRAIT;
    }
    ngOnDestroy() {
        this._destroyOverlay();
        this.close();
        this._inputStateChanges.unsubscribe();
        this._disabledChange.complete();
        this._typeChange.complete();
    }
    /** Open the calendar. */
    open() {
        if (this._opened || this.disabled) {
            return;
        }
        if (!this.datetimepickerInput) {
            throw Error('Attempted to open an CubDatetimepicker with no associated input.');
        }
        this._focusedElementBeforeOpen = _getFocusedElementPierceShadowDom();
        this._openOverlay();
        this._opened = true;
        this.openedStream.emit();
    }
    /** Close the calendar. */
    close() {
        if (!this._opened) {
            return;
        }
        const canRestoreFocus = this._restoreFocus &&
            this._focusedElementBeforeOpen &&
            typeof this._focusedElementBeforeOpen.focus === 'function';
        const completeClose = () => {
            // The `_opened` could've been reset already if
            // we got two events in quick succession.
            if (this._opened) {
                this._opened = false;
                this.closedStream.emit();
            }
        };
        if (this._componentRef) {
            const { instance, location } = this._componentRef;
            instance._startExitAnimation();
            instance._animationDone.pipe(take(1)).subscribe(() => {
                const activeElement = this._document.activeElement;
                // Since we restore focus after the exit animation, we have to check that
                // the user didn't move focus themselves inside the `close` handler.
                if (canRestoreFocus &&
                    (!activeElement ||
                        activeElement === this._document.activeElement ||
                        location.nativeElement.contains(activeElement))) {
                    this._focusedElementBeforeOpen.focus();
                }
                this._focusedElementBeforeOpen = null;
                this._destroyOverlay();
            });
        }
        if (canRestoreFocus) {
            // Because IE moves focus asynchronously, we can't count on it being restored before we've
            // marked the datepicker as closed. If the event fires out of sequence and the element that
            // we're refocusing opens the datepicker on focus, the user could be stuck with not being
            // able to close the calendar at all. We work around it by making the logic, that marks
            // the datepicker as closed, async as well.
            setTimeout(completeClose);
        }
        else {
            completeClose();
        }
    }
    _viewChanged(type) {
        this.viewChanged.emit(type);
    }
    /** Selects the given date */
    _select(date) {
        const oldValue = this._selected;
        this._selected = date;
        if (!this._dateAdapter.sameDatetime(oldValue, this._selected)) {
            this.selectedChange.emit(date);
        }
    }
    /**
     * Register an input with this datetimepicker.
     * @param input The datetimepicker input to register with this datetimepicker.
     */
    _registerInput(input) {
        if (this.datetimepickerInput) {
            throw Error('A CubDatetimepicker can only be associated with a single input.');
        }
        this.datetimepickerInput = input;
        this._inputStateChanges = this.datetimepickerInput._valueChange.subscribe((value) => (this._selected = value));
    }
    /**
     * Forwards relevant values from the datetimepicker to the
     * datetimepicker content inside the overlay.
     */
    _forwardContentValues(instance) {
        instance.datetimepicker = this;
        instance.color = this.color;
    }
    /** Opens the overlay with the calendar. */
    _openOverlay() {
        this._destroyOverlay();
        const isDialog = this.touchUi;
        const labelId = this.datetimepickerInput.getOverlayLabelId();
        const portal = new ComponentPortal(CubDatetimepickerContent, this._viewContainerRef);
        const overlayRef = (this._overlayRef = this._overlay.create(new OverlayConfig({
            positionStrategy: isDialog
                ? this._getDialogStrategy()
                : this._getDropdownStrategy(),
            hasBackdrop: true,
            backdropClass: [
                isDialog
                    ? 'cub-cdk-overlay-dark-backdrop'
                    : 'cub-cdk-overlay-transparent-backdrop',
                this._backdropHarnessClass,
            ],
            direction: this._dir,
            scrollStrategy: isDialog
                ? this._overlay.scrollStrategies.block()
                : this._scrollStrategy(),
            panelClass: `cub-datetimepicker-${isDialog ? 'dialog' : 'popup'}`,
        })));
        const overlayElement = overlayRef.overlayElement;
        overlayElement.setAttribute('role', 'dialog');
        if (labelId) {
            overlayElement.setAttribute('aria-labelledby', labelId);
        }
        if (isDialog) {
            overlayElement.setAttribute('aria-modal', 'true');
        }
        this._getCloseStream(overlayRef).subscribe((event) => {
            if (event) {
                event.preventDefault();
            }
            this.close();
        });
        this._componentRef = overlayRef.attach(portal);
        this._forwardContentValues(this._componentRef.instance);
        // Update the position once the calendar has rendered. Only relevant in dropdown mode.
        if (!isDialog) {
            this._ngZone.onStable
                .pipe(take(1))
                .subscribe(() => overlayRef.updatePosition());
        }
    }
    /** Destroys the current overlay. */
    _destroyOverlay() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef = this._componentRef = null;
        }
    }
    /** Gets a position strategy that will open the calendar as a dropdown. */
    _getDialogStrategy() {
        return this._overlay
            .position()
            .global()
            .centerHorizontally()
            .centerVertically();
    }
    /** Gets a position strategy that will open the calendar as a dropdown. */
    _getDropdownStrategy() {
        const strategy = this._overlay
            .position()
            .flexibleConnectedTo(this.datetimepickerInput.getConnectedOverlayOrigin())
            .withTransformOriginOn('.cub-datetimepicker-content')
            .withFlexibleDimensions(false)
            .withViewportMargin(8)
            .withLockedPosition()
            .withDefaultOffsetY(2);
        return this._setConnectedPositions(strategy);
    }
    /**
     * Sets the positions of the datetimepicker in dropdown mode based on the current configuration.
     */
    _setConnectedPositions(strategy) {
        const primaryX = this.xPosition === 'end' ? 'end' : 'start';
        const secondaryX = primaryX === 'start' ? 'end' : 'start';
        const primaryY = this.yPosition === 'above' ? 'bottom' : 'top';
        const secondaryY = primaryY === 'top' ? 'bottom' : 'top';
        return strategy.withPositions([
            {
                originX: primaryX,
                originY: secondaryY,
                overlayX: primaryX,
                overlayY: primaryY,
            },
            {
                originX: primaryX,
                originY: primaryY,
                overlayX: primaryX,
                overlayY: secondaryY,
            },
            {
                originX: secondaryX,
                originY: secondaryY,
                overlayX: secondaryX,
                overlayY: primaryY,
            },
            {
                originX: secondaryX,
                originY: primaryY,
                overlayX: secondaryX,
                overlayY: secondaryY,
            },
        ]);
    }
    /** Gets an observable that will emit when the overlay is supposed to be closed. */
    _getCloseStream(overlayRef) {
        return merge(overlayRef.backdropClick(), overlayRef.detachments(), overlayRef.keydownEvents().pipe(filter((event) => {
            // Closing on alt + up is only valid when there's an input associated with the datetimepicker.
            return ((event.keyCode === ESCAPE && !hasModifierKey(event)) ||
                (this.datetimepickerInput &&
                    hasModifierKey(event, 'altKey') &&
                    event.keyCode === UP_ARROW));
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepicker, deps: [{ token: i1.Overlay }, { token: i0.NgZone }, { token: i0.ViewContainerRef }, { token: CUB_DATETIMEPICKER_SCROLL_STRATEGY }, { token: CubDatetimeAdapter, optional: true }, { token: i3.Directionality, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDatetimepicker, isStandalone: true, selector: "cub-datetimepicker", inputs: { multiYearSelector: "multiYearSelector", startView: "startView", timeInterval: "timeInterval", preventSameDateTimeSelection: "preventSameDateTimeSelection", panelClass: "panelClass", opened: "opened", color: "color", startAt: "startAt", type: "type", size: "size", disabled: "disabled", xPosition: "xPosition", yPosition: "yPosition", restoreFocus: "restoreFocus" }, outputs: { selectedChange: "selectedChange", openedStream: "opened", closedStream: "closed", viewChanged: "viewChanged" }, host: { listeners: { "window:resize": "onResize($event)" }, classAttribute: "cub-datetimepicker" }, exportAs: ["cubDatetimepicker"], ngImport: i0, template: "", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepicker, decorators: [{
            type: Component,
            args: [{ selector: 'cub-datetimepicker', exportAs: 'cubDatetimepicker', host: {
                        class: 'cub-datetimepicker',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, preserveWhitespaces: false, template: "" }]
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.NgZone }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DATETIMEPICKER_SCROLL_STRATEGY]
                }] }, { type: CubDatetimeAdapter, decorators: [{
                    type: Optional
                }] }, { type: i3.Directionality, decorators: [{
                    type: Optional
                }] }], propDecorators: { multiYearSelector: [{
                type: Input
            }], startView: [{
                type: Input
            }], timeInterval: [{
                type: Input
            }], preventSameDateTimeSelection: [{
                type: Input
            }], panelClass: [{
                type: Input
            }], opened: [{
                type: Input
            }], color: [{
                type: Input
            }], startAt: [{
                type: Input
            }], type: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], xPosition: [{
                type: Input
            }], yPosition: [{
                type: Input
            }], restoreFocus: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], openedStream: [{
                type: Output,
                args: ['opened']
            }], closedStream: [{
                type: Output,
                args: ['closed']
            }], viewChanged: [{
                type: Output
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }] } });

/** Can be used to override the icon of a `cubDatetimepickerToggle`. */
class CubDatetimepickerToggleIcon {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerToggleIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDatetimepickerToggleIcon, isStandalone: true, selector: "[cubDatetimepickerToggleIcon]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerToggleIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[cubDatetimepickerToggleIcon]' }]
        }], ctorParameters: () => [] });

class CubDatetimepickerToggle {
    /** 是否禁用切換按鈕，預設為 undefined。 */
    get disabled() {
        return this._disabled === undefined
            ? this.datetimepicker.disabled
            : !!this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    constructor(_intl, _changeDetectorRef) {
        this._intl = _intl;
        this._changeDetectorRef = _changeDetectorRef;
        this.datetimepickerType = 'date';
        this.unsubscription = new Subject();
        this._stateChanges = Subscription.EMPTY;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
    }
    ngOnInit() {
        this.datetimepickerType = this.datetimepicker.type;
        this.datetimepicker._typeChange
            .pipe(takeUntil(this.unsubscription))
            .subscribe((type) => {
            this.datetimepickerType = type;
            this._changeDetectorRef.markForCheck();
        });
    }
    ngAfterContentInit() {
        this._watchStateChanges();
    }
    ngOnDestroy() {
        this._stateChanges.unsubscribe();
        this.unsubscription.next();
        this.unsubscription.complete();
    }
    ngOnChanges(changes) {
        if (changes['datetimepicker']) {
            this._watchStateChanges();
        }
    }
    _open(event) {
        if (this.datetimepicker && !this.disabled) {
            this.datetimepicker.open();
        }
        event.stopPropagation();
    }
    _watchStateChanges() {
        const datetimepickerDisabled = this.datetimepicker
            ? this.datetimepicker._disabledChange
            : of();
        const inputDisabled = this.datetimepicker && this.datetimepicker.datetimepickerInput
            ? this.datetimepicker.datetimepickerInput._disabledChange
            : of();
        this._stateChanges.unsubscribe();
        this._stateChanges = merge([
            this._intl.changes,
            datetimepickerDisabled,
            inputDisabled,
        ]).subscribe(() => this._changeDetectorRef.markForCheck());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerToggle, deps: [{ token: CubDatepickerIntl }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDatetimepickerToggle, isStandalone: true, selector: "cub-datetimepicker-toggle", inputs: { datetimepicker: ["for", "datetimepicker"], tabIndex: "tabIndex", disabled: "disabled", disableRipple: "disableRipple", size: "size" }, host: { listeners: { "focus": "_button.focus()" }, properties: { "class.cub-datetimepicker-toggle-active": "datetimepicker && datetimepicker.opened", "class.cub-datetimepicker-toggle-small": "size === \"small\"", "class.cub-disabled": "disabled", "attr.tabindex": "disabled ? null : -1" }, classAttribute: "cub-datetimepicker-toggle" }, queries: [{ propertyName: "_customIcon", first: true, predicate: CubDatetimepickerToggleIcon, descendants: true }], viewQueries: [{ propertyName: "_button", first: true, predicate: ["button"], descendants: true }], exportAs: ["cubDatetimepickerToggle"], usesOnChanges: true, ngImport: i0, template: "<button\n  #button\n  cub-icon-button\n  type=\"button\"\n  color=\"neutral\"\n  appearance=\"plain\"\n  [attr.aria-haspopup]=\"datetimepicker ? 'dialog' : null\"\n  [attr.aria-label]=\"_intl.openCalendarLabel\"\n  [attr.tabindex]=\"disabled ? -1 : tabIndex\"\n  [disabled]=\"disabled\"\n  [disableRipple]=\"disableRipple\"\n  [size]=\"size\"\n  (click)=\"_open($event)\"\n>\n  <ng-container *ngIf=\"!_customIcon\" [ngSwitch]=\"datetimepickerType\">\n    <ng-container *ngSwitchCase=\"'time'\">\n      <span class=\"cub-icon-clock\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'datetime'\">\n      <span class=\"cub-icon-calendar-clock\"></span>\n    </ng-container>\n    <ng-container *ngSwitchDefault>\n      <span class=\"cub-icon-calendar\"></span>\n    </ng-container>\n  </ng-container>\n\n  <ng-content select=\"[cubDatetimepickerToggleIcon]\"></ng-content>\n</button>\n", styles: [""], dependencies: [{ kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: NgSwitchDefault, selector: "[ngSwitchDefault]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerToggle, decorators: [{
            type: Component,
            args: [{ selector: 'cub-datetimepicker-toggle', host: {
                        class: 'cub-datetimepicker-toggle',
                        // Always set the tabindex to -1 so that it doesn't overlap with any custom tabindex the
                        // consumer may have provided, while still being able to receive focus.
                        '[class.cub-datetimepicker-toggle-active]': 'datetimepicker && datetimepicker.opened',
                        '[class.cub-datetimepicker-toggle-small]': 'size === "small"',
                        '[class.cub-disabled]': 'disabled',
                        '[attr.tabindex]': 'disabled ? null : -1',
                        '(focus)': '_button.focus()',
                    }, exportAs: 'cubDatetimepickerToggle', encapsulation: ViewEncapsulation.None, preserveWhitespaces: false, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubIconButton, NgIf, NgSwitch, NgSwitchCase, NgSwitchDefault], template: "<button\n  #button\n  cub-icon-button\n  type=\"button\"\n  color=\"neutral\"\n  appearance=\"plain\"\n  [attr.aria-haspopup]=\"datetimepicker ? 'dialog' : null\"\n  [attr.aria-label]=\"_intl.openCalendarLabel\"\n  [attr.tabindex]=\"disabled ? -1 : tabIndex\"\n  [disabled]=\"disabled\"\n  [disableRipple]=\"disableRipple\"\n  [size]=\"size\"\n  (click)=\"_open($event)\"\n>\n  <ng-container *ngIf=\"!_customIcon\" [ngSwitch]=\"datetimepickerType\">\n    <ng-container *ngSwitchCase=\"'time'\">\n      <span class=\"cub-icon-clock\"></span>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'datetime'\">\n      <span class=\"cub-icon-calendar-clock\"></span>\n    </ng-container>\n    <ng-container *ngSwitchDefault>\n      <span class=\"cub-icon-calendar\"></span>\n    </ng-container>\n  </ng-container>\n\n  <ng-content select=\"[cubDatetimepickerToggleIcon]\"></ng-content>\n</button>\n" }]
        }], ctorParameters: () => [{ type: CubDatepickerIntl }, { type: i0.ChangeDetectorRef }], propDecorators: { datetimepicker: [{
                type: Input,
                args: ['for']
            }], tabIndex: [{
                type: Input
            }], disabled: [{
                type: Input
            }], disableRipple: [{
                type: Input
            }], size: [{
                type: Input
            }], _customIcon: [{
                type: ContentChild,
                args: [CubDatetimepickerToggleIcon]
            }], _button: [{
                type: ViewChild,
                args: ['button']
            }] } });

const CUB_DATETIMEPICKER_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubDatetimepickerInput),
    multi: true,
};
const CUB_DATETIMEPICKER_VALIDATORS = {
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => CubDatetimepickerInput),
    multi: true,
};
/**
 * An event used for datetimepicker input and change events. We don't always have access to a native
 * input or change event because the event may have been triggered by the user clicking on the
 * calendar popup. For consistency, we always use CubDatetimepickerInputEvent instead.
 */
class CubDatetimepickerInputEvent {
    constructor(target, targetElement) {
        this.target = target;
        this.targetElement = targetElement;
        this.value = this.target.value;
    }
}
/** Directive used to connect an input to a CubDatetimepicker. */
class CubDatetimepickerInput {
    /** 與此輸入框關聯的選擇器，預設為 undefined。 */
    set datetimepicker(value) {
        this.registerDatetimepicker(value);
    }
    /** 用於篩選日期時間的函數，預設為 undefined。 */
    set dateFilter(filter) {
        this._dateFilter = filter;
        this._validatorOnChange();
    }
    /** 輸入框的值，預設為 undefined。 */
    get value() {
        return this._value;
    }
    set value(value) {
        value = this._dateAdapter.deserialize(value);
        this._lastValueValid = !value || this._dateAdapter.isValid(value);
        value = this._dateAdapter.getValidDateOrNull(value);
        const oldDate = this.value;
        this._value = value;
        // use timeout to ensure the datetimepicker is instantiated and we get the correct format
        setTimeout(() => {
            this._formatValue(value);
            if (!this._dateAdapter.sameDatetime(oldDate, value)) {
                this._valueChange.emit(value);
            }
        });
    }
    /** 最小有效日期時間，預設為 undefined。 */
    get min() {
        return this._min;
    }
    set min(value) {
        this._min = this._dateAdapter.getValidDateOrNull(this._dateAdapter.deserialize(value));
        this._validatorOnChange();
    }
    /** 最大有效日期時間，預設為 undefined。 */
    get max() {
        return this._max;
    }
    set max(value) {
        this._max = this._dateAdapter.getValidDateOrNull(this._dateAdapter.deserialize(value));
        this._validatorOnChange();
    }
    /** 是否禁用輸入框，預設為 undefined。 */
    get disabled() {
        return !!this._disabled;
    }
    set disabled(value) {
        const newValue = coerceBooleanProperty(value);
        if (this._disabled !== newValue) {
            this._disabled = newValue;
            this._disabledChange.emit(newValue);
        }
    }
    constructor(_elementRef, _dateAdapter, _dateFormats, _formField) {
        this._elementRef = _elementRef;
        this._dateAdapter = _dateAdapter;
        this._dateFormats = _dateFormats;
        this._formField = _formField;
        /** Emits when the value changes (either due to user input or programmatic change). */
        this._valueChange = new EventEmitter();
        /** Emits when the disabled state has changed */
        this._disabledChange = new EventEmitter();
        this._datetimepickerSubscription = Subscription.EMPTY;
        this._localeSubscription = Subscription.EMPTY;
        this.unsubscription = new Subject();
        /** Whether the last value set on the input was valid. */
        this._lastValueValid = false;
        /** 當此輸入框觸發更改事件時發出通知。 */
        this.dateChange = new EventEmitter();
        /** 當此輸入框觸發輸入事件時發出通知。 */
        this.dateInput = new EventEmitter();
        this._onTouched = () => { };
        /** The form control validator for whether the input parses. */
        this._parseValidator = () => {
            return this._lastValueValid
                ? null
                : {
                    cubDatetimepickerParse: {
                        text: this._elementRef.nativeElement.value,
                    },
                };
        };
        /** The form control validator for the min date. */
        this._minValidator = (control) => {
            const controlValue = this._dateAdapter.getValidDateOrNull(this._dateAdapter.deserialize(control.value));
            return !this.min ||
                !controlValue ||
                this._dateAdapter.compareDatetime(this.min, controlValue) <= 0
                ? null
                : { cubDatetimepickerMin: { min: this.min, actual: controlValue } };
        };
        /** The form control validator for the max date. */
        this._maxValidator = (control) => {
            const controlValue = this._dateAdapter.getValidDateOrNull(this._dateAdapter.deserialize(control.value));
            return !this.max ||
                !controlValue ||
                this._dateAdapter.compareDatetime(this.max, controlValue) >= 0
                ? null
                : { cubDatetimepickerMax: { max: this.max, actual: controlValue } };
        };
        /** The form control validator for the date filter. */
        this._filterValidator = (control) => {
            const controlValue = this._dateAdapter.getValidDateOrNull(this._dateAdapter.deserialize(control.value));
            return !this._dateFilter ||
                !controlValue ||
                this._dateFilter(controlValue, CubDatetimepickerFilterType.DATE)
                ? null
                : { dateFilter: true };
        };
        /* eslint-disable */
        /** The combined form control validator for this input. */
        this._validator = Validators.compose([
            this._parseValidator,
            this._minValidator,
            this._maxValidator,
            this._filterValidator,
        ]);
        /* eslint-enable */
        this._cvaOnChange = () => { };
        this._validatorOnChange = () => { };
        if (!this._dateAdapter) {
            throw createMissingDateImplError('CubDatetimeAdapter');
        }
        if (!this._dateFormats) {
            throw createMissingDateImplError('CUB_DATETIME_FORMATS');
        }
        // Update the displayed date when the locale changes.
        this._localeSubscription = _dateAdapter.localeChanges.subscribe(() => {
            this.value = this._dateAdapter.deserialize(this.value);
        });
    }
    ngAfterContentInit() {
        if (this._datetimepicker) {
            this._datetimepickerSubscription =
                this._datetimepicker.selectedChange.subscribe((selected) => {
                    this.value = selected;
                    this._cvaOnChange(selected);
                    this._onTouched();
                    this.dateInput.emit(new CubDatetimepickerInputEvent(this, this._elementRef.nativeElement));
                    this.dateChange.emit(new CubDatetimepickerInputEvent(this, this._elementRef.nativeElement));
                });
            this._datetimepicker._typeChange
                .pipe(takeUntil(this.unsubscription))
                .subscribe((type) => {
                this._formatValue(this.value);
            });
        }
    }
    ngOnDestroy() {
        this._datetimepickerSubscription.unsubscribe();
        this._localeSubscription.unsubscribe();
        this.unsubscription.next();
        this.unsubscription.complete();
        this._valueChange.complete();
        this._disabledChange.complete();
    }
    registerOnValidatorChange(fn) {
        this._validatorOnChange = fn;
    }
    validate(c) {
        return this._validator ? this._validator(c) : null;
    }
    /**
     * Gets the element that the datetimepicker popup should be connected to.
     * @return The element to connect the popup to.
     */
    getConnectedOverlayOrigin() {
        return this._elementRef;
    }
    /** Gets the ID of an element that should be used a description for the calendar overlay. */
    getOverlayLabelId() {
        if (this._formField) {
            return this._formField._label._labelId;
        }
        return this._elementRef.nativeElement.getAttribute('aria-labelledby');
    }
    // Implemented as part of ControlValueAccessor
    writeValue(value) {
        this.value = value;
    }
    // Implemented as part of ControlValueAccessor
    registerOnChange(fn) {
        this._cvaOnChange = fn;
    }
    // Implemented as part of ControlValueAccessor
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    // Implemented as part of ControlValueAccessor
    setDisabledState(disabled) {
        this.disabled = disabled;
    }
    _onKeydown(event) {
        if (event.altKey && event.keyCode === DOWN_ARROW) {
            this._datetimepicker.open();
            event.preventDefault();
        }
    }
    _onInput(value) {
        let date = this._dateAdapter.parse(value, this.getParseFormat());
        this._lastValueValid = !date || this._dateAdapter.isValid(date);
        date = this._dateAdapter.getValidDateOrNull(date);
        this._value = date;
        this._cvaOnChange(date);
        this._valueChange.emit(date);
        this.dateInput.emit(new CubDatetimepickerInputEvent(this, this._elementRef.nativeElement));
        this._datetimepicker.close();
    }
    _onChange() {
        this.dateChange.emit(new CubDatetimepickerInputEvent(this, this._elementRef.nativeElement));
    }
    /** Handles blur events on the input. */
    _onBlur() {
        // Reformat the input only if we have a valid value.
        if (this.value) {
            this._formatValue(this.value);
        }
        this._onTouched();
    }
    _open(event) {
        if (this._datetimepicker && !this.disabled) {
            this._datetimepicker.open();
        }
    }
    registerDatetimepicker(value) {
        if (value) {
            this._datetimepicker = value;
            this._datetimepicker._registerInput(this);
        }
    }
    getDisplayFormat() {
        switch (this._datetimepicker.type) {
            case 'date':
                return this._dateFormats.display.dateInput;
            case 'datetime':
                return this._dateFormats.display.datetimeInput;
            case 'time':
                return this._dateFormats.display.timeInput;
            case 'month':
                return this._dateFormats.display.monthInput;
            case 'year':
                return this._dateFormats.display.yearInput;
        }
    }
    getParseFormat() {
        let parseFormat;
        switch (this._datetimepicker.type) {
            case 'date':
                parseFormat = this._dateFormats.parse.dateInput;
                break;
            case 'datetime':
                parseFormat = this._dateFormats.parse.datetimeInput;
                break;
            case 'time':
                parseFormat = this._dateFormats.parse.timeInput;
                break;
            case 'month':
                parseFormat = this._dateFormats.parse.monthInput;
                break;
            case 'year':
                parseFormat = this._dateFormats.parse.yearInput;
                break;
        }
        if (!parseFormat) {
            parseFormat = this._dateFormats.parse.dateInput;
        }
        return parseFormat;
    }
    /** Formats a value and sets it on the input element. */
    _formatValue(value) {
        this._elementRef.nativeElement.value = value
            ? this._dateAdapter.format(value, this.getDisplayFormat())
            : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerInput, deps: [{ token: i0.ElementRef }, { token: CubDatetimeAdapter, optional: true }, { token: CUB_DATETIME_FORMATS, optional: true }, { token: i2.CubFormField, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDatetimepickerInput, isStandalone: true, selector: "input[cubDatetimepickerFor]", inputs: { datetimepicker: ["cubDatetimepickerFor", "datetimepicker"], dateFilter: ["cubDatetimepickerFilter", "dateFilter"], value: "value", min: "min", max: "max", disabled: "disabled" }, outputs: { dateChange: "dateChange", dateInput: "dateInput" }, host: { listeners: { "input": "_onInput($event.target.value)", "change": "_onChange()", "blur": "_onBlur()", "keydown": "_onKeydown($event)", "click": "_open($event)" }, properties: { "class.cub-datetimepicker-input-active": "_datetimepicker && _datetimepicker.opened", "attr.aria-haspopup": "true", "attr.aria-owns": "(_datetimepicker?.opened && _datetimepicker.id) || null", "attr.min": "min ? _dateAdapter.toIso8601(min) : null", "attr.max": "max ? _dateAdapter.toIso8601(max) : null", "disabled": "disabled" }, classAttribute: "cub-input cub-datetimepicker-input" }, providers: [
            CUB_DATETIMEPICKER_VALUE_ACCESSOR,
            CUB_DATETIMEPICKER_VALIDATORS,
            {
                provide: CUB_INPUT_VALUE_ACCESSOR,
                useExisting: CubDatetimepickerInput,
            },
        ], exportAs: ["cubDatetimepickerInput"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerInput, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[cubDatetimepickerFor]',
                    providers: [
                        CUB_DATETIMEPICKER_VALUE_ACCESSOR,
                        CUB_DATETIMEPICKER_VALIDATORS,
                        {
                            provide: CUB_INPUT_VALUE_ACCESSOR,
                            useExisting: CubDatetimepickerInput,
                        },
                    ],
                    host: {
                        class: 'cub-input cub-datetimepicker-input',
                        '[class.cub-datetimepicker-input-active]': '_datetimepicker && _datetimepicker.opened',
                        '[attr.aria-haspopup]': 'true',
                        '[attr.aria-owns]': '(_datetimepicker?.opened && _datetimepicker.id) || null',
                        '[attr.min]': 'min ? _dateAdapter.toIso8601(min) : null',
                        '[attr.max]': 'max ? _dateAdapter.toIso8601(max) : null',
                        '[disabled]': 'disabled',
                        '(input)': '_onInput($event.target.value)',
                        '(change)': '_onChange()',
                        '(blur)': '_onBlur()',
                        '(keydown)': '_onKeydown($event)',
                        '(click)': '_open($event)',
                    },
                    exportAs: 'cubDatetimepickerInput',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: CubDatetimeAdapter, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATETIME_FORMATS]
                }] }, { type: i2.CubFormField, decorators: [{
                    type: Optional
                }] }], propDecorators: { datetimepicker: [{
                type: Input,
                args: ['cubDatetimepickerFor']
            }], dateFilter: [{
                type: Input,
                args: ['cubDatetimepickerFilter']
            }], value: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dateChange: [{
                type: Output
            }], dateInput: [{
                type: Output
            }] } });

const CUB_DATE_FORMATS = new InjectionToken('cub-date-formats');

const CUB_MOMENT_DATE_FORMATS = {
    parse: {
        dateInput: 'l',
    },
    display: {
        dateInput: 'l',
        monthYearLabel: 'MMM YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
    },
};

const CUB_MOMENT_DATETIME_FORMATS = {
    parse: {
        dateInput: 'L',
        monthInput: 'MMMM',
        yearInput: 'YYYY',
        datetimeInput: 'L LT',
        timeInput: 'LT',
    },
    display: {
        dateInput: 'L',
        monthInput: 'MMMM',
        yearInput: 'YYYY',
        datetimeInput: 'L LT',
        timeInput: 'LT',
        monthYearLabel: 'MMM YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
        popupHeaderDateLabel: 'ddd, DD MMM',
    },
};

/**
 * Matches strings that have the form of a valid RFC 3339 string
 * (https://tools.ietf.org/html/rfc3339). Note that the string may not actually be a valid date
 * because the regex will match strings an with out of bounds month, date, etc.
 */
const ISO_8601_REGEX = /^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|(?:(?:\+|-)\d{2}:\d{2}))?)?$/;
/** Creates an array and fills it with values. */
function range$1(length, valueFunction) {
    const valuesArray = Array(length);
    for (let i = 0; i < length; i++) {
        valuesArray[i] = valueFunction(i);
    }
    return valuesArray;
}
/** Adapts the native JS Date for use with cub-cdk-based components that work with dates. */
class CubNativeDateAdapter extends CubDateAdapter {
    constructor(cubDateLocale, 
    /**
     * @deprecated No longer being used. To be removed.
     * @breaking-change 14.0.0
     */
    _platform) {
        super();
        /**
         * @deprecated No longer being used. To be removed.
         * @breaking-change 14.0.0
         */
        this.useUtcForDisplay = false;
        super.setLocale(cubDateLocale);
    }
    getYear(date) {
        return date.getFullYear();
    }
    getMonth(date) {
        return date.getMonth();
    }
    getDate(date) {
        return date.getDate();
    }
    getDayOfWeek(date) {
        return date.getDay();
    }
    getMonthNames(style) {
        const dtf = new Intl.DateTimeFormat(this.locale, {
            month: style,
            timeZone: 'utc',
        });
        return range$1(12, (i) => this._format(dtf, new Date(2017, i, 1)));
    }
    getDateNames() {
        const dtf = new Intl.DateTimeFormat(this.locale, {
            day: 'numeric',
            timeZone: 'utc',
        });
        return range$1(31, (i) => this._format(dtf, new Date(2017, 0, i + 1)));
    }
    getDayOfWeekNames(style) {
        const dtf = new Intl.DateTimeFormat(this.locale, {
            weekday: style,
            timeZone: 'utc',
        });
        return range$1(7, (i) => this._format(dtf, new Date(2017, 0, i + 1)));
    }
    getYearName(date) {
        const dtf = new Intl.DateTimeFormat(this.locale, {
            year: 'numeric',
            timeZone: 'utc',
        });
        return this._format(dtf, date);
    }
    getFirstDayOfWeek() {
        // We can't tell using native JS Date what the first day of the week is, we default to Sunday.
        return 0;
    }
    getNumDaysInMonth(date) {
        return this.getDate(this._createDateWithOverflow(this.getYear(date), this.getMonth(date) + 1, 0));
    }
    clone(date) {
        return new Date(date.getTime());
    }
    createDate(year, month, date) {
        // Check for invalid month and date (except upper bound on date which we have to check after
        // creating the Date).
        if (month < 0 || month > 11) {
            throw Error(`Invalid month index "${month}". Month index has to be between 0 and 11.`);
        }
        if (date < 1) {
            throw Error(`Invalid date "${date}". Date has to be greater than 0.`);
        }
        let result = this._createDateWithOverflow(year, month, date);
        // Check that the date wasn't above the upper bound for the month, causing the month to overflow
        if (result.getMonth() != month) {
            throw Error(`Invalid date "${date}" for month with index "${month}".`);
        }
        return result;
    }
    today() {
        return new Date();
    }
    parse(value, parseFormat) {
        // We have no way using the native JS Date to set the parse format or locale, so we ignore these
        // parameters.
        if (typeof value == 'number') {
            return new Date(value);
        }
        return value ? new Date(Date.parse(value)) : null;
    }
    format(date, displayFormat) {
        if (!this.isValid(date)) {
            throw Error('CubNativeDateAdapter: Cannot format invalid date.');
        }
        const dtf = new Intl.DateTimeFormat(this.locale, {
            ...displayFormat,
            timeZone: 'utc',
        });
        return this._format(dtf, date);
    }
    addCalendarYears(date, years) {
        return this.addCalendarMonths(date, years * 12);
    }
    addCalendarMonths(date, months) {
        let newDate = this._createDateWithOverflow(this.getYear(date), this.getMonth(date) + months, this.getDate(date));
        // It's possible to wind up in the wrong month if the original month has more days than the new
        // month. In this case we want to go to the last day of the desired month.
        // Note: the additional + 12 % 12 ensures we end up with a positive number, since JS % doesn't
        // guarantee this.
        if (this.getMonth(newDate) !=
            (((this.getMonth(date) + months) % 12) + 12) % 12) {
            newDate = this._createDateWithOverflow(this.getYear(newDate), this.getMonth(newDate), 0);
        }
        return newDate;
    }
    addCalendarDays(date, days) {
        return this._createDateWithOverflow(this.getYear(date), this.getMonth(date), this.getDate(date) + days);
    }
    toIso8601(date) {
        return [
            date.getUTCFullYear(),
            this._2digit(date.getUTCMonth() + 1),
            this._2digit(date.getUTCDate()),
        ].join('-');
    }
    /**
     * Returns the given value if given a valid Date or null. Deserializes valid ISO 8601 strings
     * (https://www.ietf.org/rfc/rfc3339.txt) into valid Dates and empty string into null. Returns an
     * invalid date for all other values.
     */
    deserialize(value) {
        if (typeof value === 'string') {
            if (!value) {
                return null;
            }
            // The `Date` constructor accepts formats other than ISO 8601, so we need to make sure the
            // string is the right format first.
            if (ISO_8601_REGEX.test(value)) {
                let date = new Date(value);
                if (this.isValid(date)) {
                    return date;
                }
            }
        }
        return super.deserialize(value);
    }
    isDateInstance(obj) {
        return obj instanceof Date;
    }
    isValid(date) {
        return !isNaN(date.getTime());
    }
    invalid() {
        return new Date(NaN);
    }
    /** Creates a date but allows the month and date to overflow. */
    _createDateWithOverflow(year, month, date) {
        // Passing the year to the constructor causes year numbers <100 to be converted to 19xx.
        // To work around this we use `setFullYear` and `setHours` instead.
        const d = new Date();
        d.setFullYear(year, month, date);
        d.setHours(0, 0, 0, 0);
        return d;
    }
    /**
     * Pads a number to make it two digits.
     * @param n The number to pad.
     * @returns The padded number.
     */
    _2digit(n) {
        return ('00' + n).slice(-2);
    }
    /**
     * When converting Date object to string, javascript built-in functions may return wrong
     * results because it applies its internal DST rules. The DST rules around the world change
     * very frequently, and the current valid rule is not always valid in previous years though.
     * We work around this problem building a new Date object which has its internal UTC
     * representation with the local date and time.
     * @param dtf Intl.DateTimeFormat object, containing the desired string format. It must have
     *    timeZone set to 'utc' to work fine.
     * @param date Date from which we want to get the string representation according to dtf
     * @returns A Date object with its UTC representation based on the passed in date info
     */
    _format(dtf, date) {
        // Passing the year to the constructor causes year numbers <100 to be converted to 19xx.
        // To work around this we use `setUTCFullYear` and `setUTCHours` instead.
        const d = new Date();
        d.setUTCFullYear(date.getFullYear(), date.getMonth(), date.getDate());
        d.setUTCHours(date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
        return dtf.format(d);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateAdapter, deps: [{ token: CUB_DATE_LOCALE, optional: true }, { token: i1$1.Platform }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATE_LOCALE]
                }] }, { type: i1$1.Platform }] });

const CUB_NATIVE_DATE_FORMATS = {
    parse: {
        dateInput: null,
    },
    display: {
        dateInput: { year: 'numeric', month: 'numeric', day: 'numeric' },
        monthYearLabel: { year: 'numeric', month: 'short' },
        dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
        monthYearA11yLabel: { year: 'numeric', month: 'long' },
    },
};

/** The default hour names to use if Intl API is not available. */
const DEFAULT_HOUR_NAMES = range(24, (i) => String(i));
/** The default minute names to use if Intl API is not available. */
const DEFAULT_MINUTE_NAMES = range(60, (i) => String(i));
function range(length, valueFunction) {
    const valuesArray = Array(length);
    for (let i = 0; i < length; i++) {
        valuesArray[i] = valueFunction(i);
    }
    return valuesArray;
}
class CubNativeDatetimeAdapter extends CubDatetimeAdapter {
    constructor(cubDateLocale, _delegate) {
        super(_delegate);
        this.setLocale(cubDateLocale);
    }
    clone(date) {
        return this.createDatetime(this.getYear(date), this.getMonth(date), this.getDate(date), this.getHour(date), this.getMinute(date));
    }
    addCalendarYears(date, years) {
        return this.addCalendarMonths(date, years * 12);
    }
    addCalendarMonths(date, months) {
        let newDate = this._createDateWithOverflow(this.getYear(date), this.getMonth(date) + months, this.getDate(date), this.getHour(date), this.getMinute(date));
        // It's possible to wind up in the wrong month if the original month has more days than the new
        // month. In this case we want to go to the last day of the desired month.
        // Note: the additional + 12 % 12 ensures we end up with a positive number, since JS % doesn't
        // guarantee this.
        if (this.getMonth(newDate) !==
            (((this.getMonth(date) + months) % 12) + 12) % 12) {
            newDate = this._createDateWithOverflow(this.getYear(newDate), this.getMonth(newDate), 0, this.getHour(date), this.getMinute(date));
        }
        return newDate;
    }
    addCalendarDays(date, days) {
        return this._createDateWithOverflow(this.getYear(date), this.getMonth(date), this.getDate(date) + days, this.getHour(date), this.getMinute(date));
    }
    toIso8601(date) {
        return (super.toIso8601(date) +
            'T' +
            [
                this._2digit(date.getUTCHours()),
                this._2digit(date.getUTCMinutes()),
            ].join(':'));
    }
    getHour(date) {
        return date.getHours();
    }
    getMinute(date) {
        return date.getMinutes();
    }
    isInNextMonth(startDate, endDate) {
        const nextMonth = this.getDateInNextMonth(startDate);
        return this.sameMonthAndYear(nextMonth, endDate);
    }
    createDatetime(year, month, date, hour, minute) {
        // Check for invalid month and date (except upper bound on date which we have to check after
        // creating the Date).
        if (month < 0 || month > 11) {
            throw Error(`Invalid month index "${month}". Month index has to be between 0 and 11.`);
        }
        if (date < 1) {
            throw Error(`Invalid date "${date}". Date has to be greater than 0.`);
        }
        if (hour < 0 || hour > 23) {
            throw Error(`Invalid hour "${hour}". Hour has to be between 0 and 23.`);
        }
        if (minute < 0 || minute > 59) {
            throw Error(`Invalid minute "${minute}". Minute has to be between 0 and 59.`);
        }
        const result = this._createDateWithOverflow(year, month, date, hour, minute);
        // Check that the date wasn't above the upper bound for the month, causing the month to overflow
        if (result.getMonth() !== month) {
            throw Error(`Invalid date "${date}" for month with index "${month}".`);
        }
        return result;
    }
    getFirstDateOfMonth(date) {
        const result = new Date();
        result.setFullYear(date.getFullYear(), date.getMonth(), 1);
        return result;
    }
    getHourNames() {
        return DEFAULT_HOUR_NAMES;
    }
    getMinuteNames() {
        return DEFAULT_MINUTE_NAMES;
    }
    addCalendarHours(date, hours) {
        return this._createDateWithOverflow(this.getYear(date), this.getMonth(date), this.getDate(date), this.getHour(date) + hours, this.getMinute(date));
    }
    addCalendarMinutes(date, minutes) {
        return this._createDateWithOverflow(this.getYear(date), this.getMonth(date), this.getDate(date), this.getHour(date), this.getMinute(date) + minutes);
    }
    getDateInNextMonth(date) {
        return new Date(date.getFullYear(), date.getMonth() + 1, 1, date.getHours(), date.getMinutes());
    }
    /**
     * Strip out unicode LTR and RTL characters. Edge and IE insert these into formatted dates while
     * other browsers do not. We remove them to make output consistent and because they interfere with
     * date parsing.
     * @param str The string to strip direction characters from.
     * @returns The stripped string.
     */
    _stripDirectionalityCharacters(str) {
        return str.replace(/[\u200e\u200f]/g, '');
    }
    /**
     * Pads a number to make it two digits.
     * @param n The number to pad.
     * @returns The padded number.
     */
    _2digit(n) {
        return ('00' + n).slice(-2);
    }
    /** Creates a date but allows the month and date to overflow. */
    _createDateWithOverflow(year, month, date, hours, minutes) {
        const result = new Date(year, month, date, hours, minutes);
        // We need to correct for the fact that JS native Date treats years in range [0, 99] as
        // abbreviations for 19xx.
        if (year >= 0 && year < 100) {
            result.setFullYear(this.getYear(result) - 1900);
        }
        return result;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeAdapter, deps: [{ token: CUB_DATE_LOCALE, optional: true }, { token: CubDateAdapter }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DATE_LOCALE]
                }] }, { type: CubDateAdapter }] });

const CUB_NATIVE_DATETIME_FORMATS = {
    parse: {},
    display: {
        dateInput: { year: 'numeric', month: '2-digit', day: '2-digit' },
        monthInput: { month: 'long' },
        datetimeInput: {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
        },
        timeInput: { hour: '2-digit', minute: '2-digit' },
        monthYearLabel: { year: 'numeric', month: 'short' },
        dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
        monthYearA11yLabel: { year: 'numeric', month: 'long' },
        popupHeaderDateLabel: { weekday: 'short', month: 'short', day: '2-digit' },
    },
};

class CubDatetimepickerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerModule, imports: [CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule,
            CubCalendar,
            CubCalendarBody,
            CubClock,
            CubDatetimepicker,
            CubDatetimepickerToggle,
            CubDatetimepickerToggleIcon,
            CubDatetimepickerInput,
            CubDatetimepickerContent,
            CubMonthView,
            CubYearView,
            CubMultiYearView], exports: [CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule,
            CubCalendar,
            CubCalendarBody,
            CubClock,
            CubDatetimepicker,
            CubDatetimepickerToggle,
            CubDatetimepickerToggleIcon,
            CubDatetimepickerInput,
            CubDatetimepickerContent,
            CubMonthView,
            CubYearView,
            CubMultiYearView] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            ...CUB_DATETIMEPICKER_MOMENT_PROVIDER_LIST,
            CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule,
            CubCalendar,
            CubCalendarBody,
            CubDatetimepickerToggle,
            CubDatetimepickerContent,
            CubMonthView,
            CubYearView,
            CubMultiYearView, CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubInputGroupModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDatetimepickerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubInputGroupModule,
                        CubCalendar,
                        CubCalendarBody,
                        CubClock,
                        CubDatetimepicker,
                        CubDatetimepickerToggle,
                        CubDatetimepickerToggleIcon,
                        CubDatetimepickerInput,
                        CubDatetimepickerContent,
                        CubMonthView,
                        CubYearView,
                        CubMultiYearView,
                    ],
                    exports: [
                        CubCommonModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubInputGroupModule,
                        CubCalendar,
                        CubCalendarBody,
                        CubClock,
                        CubDatetimepicker,
                        CubDatetimepickerToggle,
                        CubDatetimepickerToggleIcon,
                        CubDatetimepickerInput,
                        CubDatetimepickerContent,
                        CubMonthView,
                        CubYearView,
                        CubMultiYearView,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        ...CUB_DATETIMEPICKER_MOMENT_PROVIDER_LIST,
                        CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });
class NativeDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: NativeDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: NativeDateModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: NativeDateModule, providers: [{ provide: CubDateAdapter, useClass: CubNativeDateAdapter }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: NativeDateModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [{ provide: CubDateAdapter, useClass: CubNativeDateAdapter }],
                }]
        }] });
class CubNativeDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateModule, imports: [NativeDateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateModule, providers: [{ provide: CUB_DATE_FORMATS, useValue: CUB_NATIVE_DATE_FORMATS }], imports: [NativeDateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [NativeDateModule],
                    providers: [{ provide: CUB_DATE_FORMATS, useValue: CUB_NATIVE_DATE_FORMATS }],
                }]
        }] });
class MomentDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: MomentDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: MomentDateModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: MomentDateModule, providers: [
            {
                provide: CubDateAdapter,
                useClass: CubMomentDateAdapter,
                deps: [CUB_DATE_LOCALE, CUB_MOMENT_DATE_ADAPTER_OPTIONS],
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: MomentDateModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: CubDateAdapter,
                            useClass: CubMomentDateAdapter,
                            deps: [CUB_DATE_LOCALE, CUB_MOMENT_DATE_ADAPTER_OPTIONS],
                        },
                    ],
                }]
        }] });
class CubMomentDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateModule, imports: [MomentDateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateModule, providers: [{ provide: CUB_DATE_FORMATS, useValue: CUB_MOMENT_DATE_FORMATS }], imports: [MomentDateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [MomentDateModule],
                    providers: [{ provide: CUB_DATE_FORMATS, useValue: CUB_MOMENT_DATE_FORMATS }],
                }]
        }] });
class NativeDatetimeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: NativeDatetimeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: NativeDatetimeModule, imports: [NativeDateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: NativeDatetimeModule, providers: [
            {
                provide: CubDatetimeAdapter,
                useClass: CubNativeDatetimeAdapter,
            },
        ], imports: [NativeDateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: NativeDatetimeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [NativeDateModule],
                    providers: [
                        {
                            provide: CubDatetimeAdapter,
                            useClass: CubNativeDatetimeAdapter,
                        },
                    ],
                }]
        }] });
class CubNativeDatetimeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeModule, imports: [CubNativeDateModule, NativeDatetimeModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeModule, providers: [
            { provide: CUB_DATETIME_FORMATS, useValue: CUB_NATIVE_DATETIME_FORMATS },
        ], imports: [CubNativeDateModule, NativeDatetimeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNativeDatetimeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubNativeDateModule, NativeDatetimeModule],
                    providers: [
                        { provide: CUB_DATETIME_FORMATS, useValue: CUB_NATIVE_DATETIME_FORMATS },
                    ],
                }]
        }] });
class MomentDatetimeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: MomentDatetimeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: MomentDatetimeModule, imports: [MomentDateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: MomentDatetimeModule, providers: [
            {
                provide: CubDatetimeAdapter,
                useClass: CubMomentDatetimeAdapter,
            },
        ], imports: [MomentDateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: MomentDatetimeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [MomentDateModule],
                    providers: [
                        {
                            provide: CubDatetimeAdapter,
                            useClass: CubMomentDatetimeAdapter,
                        },
                    ],
                }]
        }] });
class CubMomentDatetimeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeModule, imports: [CubMomentDateModule, MomentDatetimeModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeModule, providers: [
            { provide: CUB_DATETIME_FORMATS, useValue: CUB_MOMENT_DATETIME_FORMATS },
        ], imports: [CubMomentDateModule, MomentDatetimeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMomentDatetimeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubMomentDateModule, MomentDatetimeModule],
                    providers: [
                        { provide: CUB_DATETIME_FORMATS, useValue: CUB_MOMENT_DATETIME_FORMATS },
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/datetimepicker
 */
/* 參考來源：https://github.com/ng-matero/extensions/tree/v14.5.0/projects/extensions/datetimepicker */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CLOCK_INNER_RADIUS, CLOCK_OUTER_RADIUS, CLOCK_RADIUS, CLOCK_TICK_RADIUS, CUB_DATETIMEPICKER_FORMATS_PROVIDER, CUB_DATETIMEPICKER_MOMENT_PROVIDER_LIST, CUB_DATETIMEPICKER_SCROLL_STRATEGY, CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY, CUB_DATETIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER, CUB_DATETIMEPICKER_VALIDATORS, CUB_DATETIMEPICKER_VALUE_ACCESSOR, CUB_DATETIME_FORMATS, CUB_DATETIME_FORMATS_CONFIG, CUB_DATE_FORMATS, CUB_DATE_LOCALE, CUB_DATE_LOCALE_FACTORY, CUB_MOMENT_DATETIME_FORMATS, CUB_MOMENT_DATE_ADAPTER_OPTIONS, CUB_MOMENT_DATE_ADAPTER_OPTIONS_FACTORY, CUB_MOMENT_DATE_FORMATS, CUB_NATIVE_DATETIME_FORMATS, CUB_NATIVE_DATE_FORMATS, CubCalendar, CubCalendarBody, CubCalendarCell, CubClock, CubDateAdapter, CubDatepickerIntl, CubDatetimeAdapter, CubDatetimepicker, CubDatetimepickerContent, CubDatetimepickerFilterType, CubDatetimepickerInput, CubDatetimepickerInputEvent, CubDatetimepickerModule, CubDatetimepickerToggle, CubDatetimepickerToggleIcon, CubMomentDateAdapter, CubMomentDateModule, CubMomentDatetimeAdapter, CubMomentDatetimeModule, CubMonthView, CubMultiYearView, CubNativeDateAdapter, CubNativeDateModule, CubNativeDatetimeAdapter, CubNativeDatetimeModule, CubYearView, DAYS_PER_WEEK, MomentDateModule, MomentDatetimeModule, NativeDateModule, NativeDatetimeModule, _CubDatetimepickerContentBase, createMissingDateImplError, cubDatetimepickerAnimations, euclideanModulo, getActiveOffset, getPointerPositionOnPage, getStartingYear, isSameMultiYearView, isTouchEvent, yearsPerPage, yearsPerRow };
//# sourceMappingURL=cub-lib-view-rootng-component-datetimepicker.mjs.map
