import * as i0 from '@angular/core';
import { InjectionToken, Inject, Injectable, EventEmitter, DOCUMENT, Optional, Component, ChangeDetectionStrategy, ViewEncapsulation, SkipSelf, Directive, NgModule } from '@angular/core';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { Dialog, DialogConfig, CubCdkDialogContainer, CUB_CDK_DIALOG_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/dialog';
import { Subject, merge, defer } from 'rxjs';
import { filter, take, startWith } from 'rxjs/operators';
import { ESCAPE, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { trigger, state, transition, style, group, animate, query, animateChild } from '@angular/animations';
import * as i1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { CubCdkPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import * as i1$1 from 'cub-lib-view-rootng/cdk/a11y';
import * as i2 from '@angular/common';
import { NgIf } from '@angular/common';
import { CubIconButton, CubButton, CubButtonModule } from 'cub-lib-view-rootng/component/button';

function CUB_DIALOG_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.block();
}
function CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay) {
    return () => overlay.scrollStrategies.block();
}
function getClosestDialog(element, openDialogs) {
    let parent = element.nativeElement.parentElement;
    while (parent && !parent.classList.contains('cub-dialog-container')) {
        parent = parent.parentElement;
    }
    return parent ? openDialogs.find((dialog) => dialog.id === parent.id) : null;
}
function _CloseDialogVia(ref, interactionType, result) {
    ref._closeInteractionType = interactionType;
    return ref.close(result);
}

const CUB_DIALOG_DATA = new InjectionToken('CubDialogData');
const CUB_DIALOG_SCROLL_STRATEGY = new InjectionToken('cub-dialog-scroll-strategy');
const CUB_DIALOG_SCROLL_STRATEGY_PROVIDER = {
    provide: CUB_DIALOG_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
};
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
const CubDialogDefaultParams = {
    params: { enterAnimationDuration: '150ms', exitAnimationDuration: '75ms' },
};
/**
 * Animations used by CubDialog.
 * @docs-private
 */
const CubDialogAnimations = {
    /** Animation that is applied on the dialog container by default. */
    dialogContainer: trigger('dialogContainer', [
        // Note: The `enter` animation transitions to `transform: none`, because for some reason
        // specifying the transform explicitly, causes IE both to blur the dialog content and
        // decimate the animation performance. Leaving it as `none` solves both issues.
        state('void, exit', style({ opacity: 0, transform: 'scale(0.7)' })),
        state('enter', style({ transform: 'none' })),
        transition('* => enter', group([
            animate('{{enterAnimationDuration}} cubic-bezier(0, 0, 0.2, 1)', style({ transform: 'none', opacity: 1 })),
            query('@*', animateChild(), { optional: true }),
        ]), CubDialogDefaultParams),
        transition('* => void, * => exit', group([
            animate('{{exitAnimationDuration}} cubic-bezier(0.4, 0.0, 0.2, 1)', style({ opacity: 0 })),
            query('@*', animateChild(), { optional: true }),
        ]), CubDialogDefaultParams),
    ]),
};

const CUB_DIALOG_DEFAULT_OPTIONS = new InjectionToken('cub-dialog-default-options');
class CubDialogConfig {
    constructor() {
        this.role = 'dialog';
        this.panelClass = '';
        this.hasBackdrop = true;
        this.backdropClass = '';
        this.disableClose = true;
        this.width = '';
        this.height = '';
        this.data = null;
        this.ariaDescribedBy = null;
        this.ariaLabelledBy = null;
        this.ariaLabel = null;
        this.ariaModal = true;
        this.autoFocus = 'cub-dialog-title';
        this.restoreFocus = false;
        this.delayFocusTrap = false;
        this.closeOnNavigation = true;
        this.enterAnimationDuration = CubDialogDefaultParams.params.enterAnimationDuration;
        this.exitAnimationDuration = CubDialogDefaultParams.params.exitAnimationDuration;
    }
}
class CubDialogRef {
    constructor(_ref, config, _containerInstance) {
        this._ref = _ref;
        this._containerInstance = _containerInstance;
        this._afterOpened = new Subject();
        this._beforeClosed = new Subject();
        this._state = 0 /* CubDialogState.OPEN */;
        this.disableClose = config.disableClose;
        this.id = _ref.id;
        _containerInstance._animationStateChanged
            .pipe(filter((event) => event.state === 'opened'), take(1))
            .subscribe(() => {
            this._afterOpened.next();
            this._afterOpened.complete();
        });
        _containerInstance._animationStateChanged
            .pipe(filter((event) => event.state === 'closed'), take(1))
            .subscribe(() => {
            clearTimeout(this._closeFallbackTimeout);
            this._finishDialogClose();
        });
        _ref.overlayRef.detachments().subscribe(() => {
            this._beforeClosed.next(this._result);
            this._beforeClosed.complete();
            this._finishDialogClose();
        });
        merge(this.backdropClick(), this.keydownEvents().pipe(filter((event) => event.keyCode === ESCAPE &&
            !this.disableClose &&
            !hasModifierKey(event)))).subscribe((event) => {
            if (!this.disableClose) {
                event.preventDefault();
                _CloseDialogVia(this, event.type === 'keydown' ? 'keyboard' : 'mouse');
            }
        });
    }
    close(dialogResult) {
        this._result = dialogResult;
        this._containerInstance._animationStateChanged
            .pipe(filter((event) => event.state === 'closing'), take(1))
            .subscribe((event) => {
            this._beforeClosed.next(dialogResult);
            this._beforeClosed.complete();
            this._ref.overlayRef.detachBackdrop();
            this._closeFallbackTimeout = setTimeout(() => this._finishDialogClose(), event.totalTime + 100);
        });
        this._state = 1 /* CubDialogState.CLOSING */;
        this._containerInstance._startExitAnimation();
    }
    afterOpened() {
        return this._afterOpened;
    }
    afterClosed() {
        return this._ref.closed;
    }
    beforeClosed() {
        return this._beforeClosed;
    }
    backdropClick() {
        return this._ref.backdropClick;
    }
    keydownEvents() {
        return this._ref.keydownEvents;
    }
    updatePosition(position) {
        let strategy = this._ref.config.positionStrategy;
        if (position && (position.left || position.right)) {
            position.left
                ? strategy.left(position.left)
                : strategy.right(position.right);
        }
        else {
            strategy.centerHorizontally();
        }
        if (position && (position.top || position.bottom)) {
            position.top
                ? strategy.top(position.top)
                : strategy.bottom(position.bottom);
        }
        else {
            strategy.centerVertically();
        }
        this._ref.updatePosition();
        return this;
    }
    updateSize(width = '', height = '') {
        this._ref.updateSize(width, height);
        return this;
    }
    addPanelClass(classes) {
        this._ref.addPanelClass(classes);
        return this;
    }
    removePanelClass(classes) {
        this._ref.removePanelClass(classes);
        return this;
    }
    getState() {
        return this._state;
    }
    _finishDialogClose() {
        this._state = 2 /* CubDialogState.CLOSED */;
        this._ref.close(this._result, { focusOrigin: this._closeInteractionType });
        this.componentInstance = null;
    }
}

let uniqueId = 0;
class _CubDialogBase {
    /** Keeps track of the currently-open dialogs. */
    get openDialogs() {
        return this._parentDialog
            ? this._parentDialog.openDialogs
            : this._openDialogsAtThisLevel;
    }
    /** Stream that emits when a dialog has been opened. */
    get afterOpened() {
        return this._parentDialog
            ? this._parentDialog.afterOpened
            : this._afterOpenedAtThisLevel;
    }
    constructor(_overlay, injector, _defaultOptions, _parentDialog, _overlayContainer, scrollStrategy, _dialogRefConstructor, _dialogContainerType, _dialogDataToken, _animationMode) {
        this._overlay = _overlay;
        this._defaultOptions = _defaultOptions;
        this._parentDialog = _parentDialog;
        this._dialogRefConstructor = _dialogRefConstructor;
        this._dialogContainerType = _dialogContainerType;
        this._dialogDataToken = _dialogDataToken;
        this.afterAllClosed = defer(() => this.openDialogs.length
            ? this._getAfterAllClosed()
            : this._getAfterAllClosed().pipe(startWith(undefined)));
        this._idPrefix = 'cub-dialog-';
        this._openDialogsAtThisLevel = [];
        this._afterAllClosedAtThisLevel = new Subject();
        this._afterOpenedAtThisLevel = new Subject();
        this._scrollStrategy = scrollStrategy;
        this._dialog = injector.get(Dialog);
    }
    open(componentOrTemplateRef, config) {
        let dialogRef;
        config = { ...(this._defaultOptions || new CubDialogConfig()), ...config };
        config.id = config.id || `${this._idPrefix}${uniqueId++}`;
        config.scrollStrategy = config.scrollStrategy || this._scrollStrategy();
        const cdkRef = this._dialog.open(componentOrTemplateRef, {
            ...config,
            positionStrategy: this._overlay
                .position()
                .global()
                .centerHorizontally()
                .top(),
            disableClose: true,
            closeOnDestroy: false,
            container: {
                type: this._dialogContainerType,
                providers: () => [
                    { provide: CubDialogConfig, useValue: config },
                    { provide: DialogConfig, useValue: config },
                ],
            },
            templateContext: () => ({ dialogRef }),
            providers: (ref, cdkConfig, dialogContainer) => {
                dialogRef = new this._dialogRefConstructor(ref, config, dialogContainer);
                return [
                    { provide: this._dialogContainerType, useValue: dialogContainer },
                    { provide: this._dialogDataToken, useValue: cdkConfig.data },
                    { provide: this._dialogRefConstructor, useValue: dialogRef },
                ];
            },
        });
        dialogRef.componentInstance = cdkRef.componentInstance;
        this.openDialogs.push(dialogRef);
        this.afterOpened.next(dialogRef);
        dialogRef.afterClosed().subscribe(() => {
            const index = this.openDialogs.indexOf(dialogRef);
            if (index > -1) {
                this.openDialogs.splice(index, 1);
                if (!this.openDialogs.length) {
                    this._getAfterAllClosed().next();
                }
            }
        });
        return dialogRef;
    }
    closeAll() {
        this._closeDialogs(this.openDialogs);
    }
    getDialogById(id) {
        return this.openDialogs.find((dialog) => dialog.id === id);
    }
    ngOnDestroy() {
        this._closeDialogs(this._openDialogsAtThisLevel);
        this._afterAllClosedAtThisLevel.complete();
        this._afterOpenedAtThisLevel.complete();
    }
    _closeDialogs(dialogs) {
        let i = dialogs.length;
        while (i--) {
            dialogs[i].close();
        }
    }
    _getAfterAllClosed() {
        const parent = this._parentDialog;
        return parent
            ? parent._getAfterAllClosed()
            : this._afterAllClosedAtThisLevel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDialogBase, deps: [{ token: i1.Overlay }, { token: i0.Injector }, { token: String }, { token: String }, { token: i1.OverlayContainer }, { token: String }, { token: i0.Type }, { token: i0.Type }, { token: i0.InjectionToken }, { token: String }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDialogBase }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDialogBase, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.Injector }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }, { type: i1.OverlayContainer }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }, { type: i0.Type }, { type: i0.Type }, { type: i0.InjectionToken }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }] });

class _CubDialogContainerBase extends CubCdkDialogContainer {
    constructor(elementRef, focusTrapFactory, _document, dialogConfig, interactivityChecker, ngZone, overlayRef, focusMonitor) {
        super(elementRef, focusTrapFactory, _document, dialogConfig, interactivityChecker, ngZone, overlayRef, focusMonitor);
        this._animationStateChanged = new EventEmitter();
    }
    _captureInitialFocus() {
        if (!this._config.delayFocusTrap) {
            this._trapFocus();
        }
    }
    _openAnimationDone(totalTime) {
        if (this._config.delayFocusTrap) {
            this._trapFocus();
        }
        this._animationStateChanged.next({ state: 'opened', totalTime });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDialogContainerBase, deps: [{ token: i0.ElementRef }, { token: i1$1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: CubDialogConfig }, { token: i1$1.InteractivityChecker }, { token: i0.NgZone }, { token: i1.OverlayRef }, { token: i1$1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: _CubDialogContainerBase, isStandalone: true, selector: "cub-dialog-container-base", usesInheritance: true, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDialogContainerBase, decorators: [{
            type: Component,
            args: [{
                    selector: 'cub-dialog-container-base',
                    template: '',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: CubDialogConfig }, { type: i1$1.InteractivityChecker }, { type: i0.NgZone }, { type: i1.OverlayRef }, { type: i1$1.FocusMonitor }] });

class CubDialogContainer extends _CubDialogContainerBase {
    constructor(elementRef, focusTrapFactory, document, dialogConfig, checker, ngZone, overlayRef, _changeDetectorRef, focusMonitor) {
        super(elementRef, focusTrapFactory, document, dialogConfig, checker, ngZone, overlayRef, focusMonitor);
        this._changeDetectorRef = _changeDetectorRef;
        this._state = 'enter';
    }
    _onAnimationDone({ toState, totalTime }) {
        if (toState === 'enter') {
            this._openAnimationDone(totalTime);
        }
        else if (toState === 'exit') {
            this._animationStateChanged.next({ state: 'closed', totalTime });
        }
    }
    _onAnimationStart({ toState, totalTime }) {
        if (toState === 'enter') {
            this._animationStateChanged.next({ state: 'opening', totalTime });
        }
        else if (toState === 'exit' || toState === 'void') {
            this._animationStateChanged.next({ state: 'closing', totalTime });
        }
    }
    _startExitAnimation() {
        this._state = 'exit';
        this._changeDetectorRef.markForCheck();
    }
    _getAnimationState() {
        return {
            value: this._state,
            params: {
                enterAnimationDuration: this._config.enterAnimationDuration ||
                    CubDialogDefaultParams.params.enterAnimationDuration,
                exitAnimationDuration: this._config.exitAnimationDuration ||
                    CubDialogDefaultParams.params.exitAnimationDuration,
            },
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogContainer, deps: [{ token: i0.ElementRef }, { token: i1$1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: CubDialogConfig }, { token: i1$1.InteractivityChecker }, { token: i0.NgZone }, { token: i1.OverlayRef }, { token: i0.ChangeDetectorRef }, { token: i1$1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogContainer, isStandalone: true, selector: "cub-dialog-container", host: { attributes: { "tabindex": "-1" }, listeners: { "@dialogContainer.start": "_onAnimationStart($event)", "@dialogContainer.done": "_onAnimationDone($event)" }, properties: { "id": "_config.id", "attr.role": "_config.role", "attr.aria-modal": "_config.ariaModal", "attr.aria-labelledby": "_config.ariaLabel ? null : _ariaLabelledBy", "attr.aria-label": "_config.ariaLabel", "attr.aria-describedby": "_config.ariaDescribedBy || null", "@dialogContainer": "_getAnimationState()" }, classAttribute: "cub-dialog-container" }, exportAs: ["cubDialogContainer"], usesInheritance: true, ngImport: i0, template: "<ng-template cubCdkPortalOutlet></ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkPortalOutlet, selector: "[cubCdkPortalOutlet]", inputs: ["cubCdkPortalOutlet"], outputs: ["attached"], exportAs: ["cubCdkPortalOutlet"] }], animations: [CubDialogAnimations.dialogContainer], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogContainer, decorators: [{
            type: Component,
            args: [{ selector: 'cub-dialog-container', exportAs: 'cubDialogContainer', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Default, animations: [CubDialogAnimations.dialogContainer], host: {
                        class: 'cub-dialog-container',
                        tabindex: '-1',
                        '[id]': '_config.id',
                        '[attr.role]': '_config.role',
                        '[attr.aria-modal]': '_config.ariaModal',
                        '[attr.aria-labelledby]': '_config.ariaLabel ? null : _ariaLabelledBy',
                        '[attr.aria-label]': '_config.ariaLabel',
                        '[attr.aria-describedby]': '_config.ariaDescribedBy || null',
                        '[@dialogContainer]': `_getAnimationState()`,
                        '(@dialogContainer.start)': '_onAnimationStart($event)',
                        '(@dialogContainer.done)': '_onAnimationDone($event)',
                    }, imports: [CubCdkPortalOutlet], template: "<ng-template cubCdkPortalOutlet></ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: CubDialogConfig }, { type: i1$1.InteractivityChecker }, { type: i0.NgZone }, { type: i1.OverlayRef }, { type: i0.ChangeDetectorRef }, { type: i1$1.FocusMonitor }] });

class CubDialog extends _CubDialogBase {
    constructor(overlay, injector, _location, defaultOptions, scrollStrategy, parentDialog, overlayContainer, animationMode) {
        super(overlay, injector, defaultOptions, parentDialog, overlayContainer, scrollStrategy, CubDialogRef, CubDialogContainer, CUB_DIALOG_DATA, animationMode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialog, deps: [{ token: i1.Overlay }, { token: i0.Injector }, { token: i2.Location, optional: true }, { token: CUB_DIALOG_DEFAULT_OPTIONS, optional: true }, { token: CUB_DIALOG_SCROLL_STRATEGY }, { token: CubDialog, optional: true, skipSelf: true }, { token: i1.OverlayContainer }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialog }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialog, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.Injector }, { type: i2.Location, decorators: [{
                    type: Optional
                }] }, { type: CubDialogConfig, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DIALOG_DEFAULT_OPTIONS]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DIALOG_SCROLL_STRATEGY]
                }] }, { type: CubDialog, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.OverlayContainer }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }] });
const CUB_DIALOG_PROVIDER_LIST = [
    ...CUB_CDK_DIALOG_PROVIDER_LIST,
    CubDialog,
    CUB_DIALOG_SCROLL_STRATEGY_PROVIDER,
];

class CubDialogHeader {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogHeader, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogHeader, isStandalone: true, selector: "cub-dialog-header", host: { classAttribute: "cub-dialog-header" }, exportAs: ["cubDialogHeader"], ngImport: i0, template: "<ng-content select=\"cub-dialog-title\"></ng-content>\n<ng-content select=\"cub-dialog-close\"></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-dialog-header', exportAs: 'cubDialogHeader', host: {
                        class: 'cub-dialog-header',
                    }, template: "<ng-content select=\"cub-dialog-title\"></ng-content>\n<ng-content select=\"cub-dialog-close\"></ng-content>\n" }]
        }], ctorParameters: () => [] });

class CubDialogTitle {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogTitle, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogTitle, isStandalone: true, selector: "cub-dialog-title", host: { classAttribute: "cub-dialog-title" }, exportAs: ["cubDialogTitle"], ngImport: i0, template: "<ng-content></ng-content>\n<ng-content select=\"cub-dialog-code\"></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogTitle, decorators: [{
            type: Component,
            args: [{ selector: 'cub-dialog-title', exportAs: 'cubDialogTitle', host: {
                        class: 'cub-dialog-title',
                    }, template: "<ng-content></ng-content>\n<ng-content select=\"cub-dialog-code\"></ng-content>\n" }]
        }], ctorParameters: () => [] });

class CubDefaultDialog {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDefaultDialog, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDefaultDialog, isStandalone: true, selector: "cub-default-dialog", host: { classAttribute: "cub-default-dialog" }, exportAs: ["cubDefaultDialog"], ngImport: i0, template: "<ng-content select=\"cub-dialog-header\"></ng-content>\n\n<div class=\"cub-dialog-content-container\">\n  <ng-content select=\"cub-dialog-content\"></ng-content>\n\n  <ng-content select=\"cub-dialog-actions\"></ng-content>\n</div>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDefaultDialog, decorators: [{
            type: Component,
            args: [{ selector: 'cub-default-dialog', exportAs: 'cubDefaultDialog', host: {
                        class: 'cub-default-dialog',
                    }, template: "<ng-content select=\"cub-dialog-header\"></ng-content>\n\n<div class=\"cub-dialog-content-container\">\n  <ng-content select=\"cub-dialog-content\"></ng-content>\n\n  <ng-content select=\"cub-dialog-actions\"></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [] });

class CubDialogClose {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogClose, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogClose, isStandalone: true, selector: "cub-dialog-close", host: { classAttribute: "cub-dialog-close" }, exportAs: ["cubDialogClose"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogClose, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-dialog-close',
                    exportAs: 'cubDialogClose',
                    host: {
                        class: 'cub-dialog-close',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDialogContent {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogContent, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogContent, isStandalone: true, selector: "cub-dialog-content", host: { classAttribute: "cub-dialog-content" }, exportAs: ["cubDialogContent"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogContent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-dialog-content',
                    exportAs: 'cubDialogContent',
                    host: {
                        class: 'cub-dialog-content',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDialogActions {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogActions, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogActions, isStandalone: true, selector: "cub-dialog-actions", host: { classAttribute: "cub-dialog-actions" }, exportAs: ["cubDialogActions"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogActions, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-dialog-actions',
                    exportAs: 'cubDialogActions',
                    host: {
                        class: 'cub-dialog-actions',
                    },
                }]
        }], ctorParameters: () => [] });

class CubConfirmDialog {
    constructor(dialogRef, dialogData) {
        this.dialogRef = dialogRef;
        this.dialogData = dialogData;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubConfirmDialog, deps: [{ token: CubDialogRef }, { token: CUB_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubConfirmDialog, isStandalone: true, selector: "cub-confirm-dialog", exportAs: ["cubConfirmDialog"], ngImport: i0, template: "<cub-default-dialog>\n  <cub-dialog-header>\n    <cub-dialog-title>\n      {{ dialogData.title }}\n    </cub-dialog-title>\n    <cub-dialog-close>\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"plain\"\n        (click)=\"dialogRef.close()\"\n      >\n        <span class=\"cub-icon-x\"></span>\n      </button>\n    </cub-dialog-close>\n  </cub-dialog-header>\n  <cub-dialog-content>\n    <div\n      *ngIf=\"dialogData.description\"\n      [innerHTML]=\"dialogData.description\"\n    ></div>\n    <!-- \u56E0\u70BA\u9700\u8981\u652F\u63F4 innerHTML \u6240\u4EE5\u6C92\u6709\u4F7F\u7528 <cub-dialog-code> Start -->\n    <div\n      *ngIf=\"dialogData.returnCode\"\n      [innerHTML]=\"dialogData.returnCode\"\n      class=\"cub-dialog-code\"\n    ></div>\n    <!-- End -->\n  </cub-dialog-content>\n  <cub-dialog-actions>\n    <button\n      *ngIf=\"!dialogData.subButton?.hidden\"\n      cub-button\n      type=\"button\"\n      [withMinWidth]=\"true\"\n      [appearance]=\"dialogData.subButton?.appearance || 'filled-outline'\"\n      [color]=\"dialogData.subButton?.color || 'neutral'\"\n      (click)=\"dialogRef.close('cancel')\"\n    >\n      {{ dialogData.subButton?.label }}\n    </button>\n    <button\n      cub-button\n      type=\"button\"\n      [withMinWidth]=\"true\"\n      [appearance]=\"dialogData.mainButton.appearance || 'filled'\"\n      [color]=\"dialogData.mainButton.color || 'brand'\"\n      (click)=\"dialogRef.close('confirm')\"\n    >\n      {{ dialogData.mainButton.label }}\n    </button>\n  </cub-dialog-actions>\n</cub-default-dialog>\n", styles: [""], dependencies: [{ kind: "component", type: CubDefaultDialog, selector: "cub-default-dialog", exportAs: ["cubDefaultDialog"] }, { kind: "component", type: CubDialogHeader, selector: "cub-dialog-header", exportAs: ["cubDialogHeader"] }, { kind: "component", type: CubDialogTitle, selector: "cub-dialog-title", exportAs: ["cubDialogTitle"] }, { kind: "directive", type: CubDialogClose, selector: "cub-dialog-close", exportAs: ["cubDialogClose"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "directive", type: CubDialogContent, selector: "cub-dialog-content", exportAs: ["cubDialogContent"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: CubDialogActions, selector: "cub-dialog-actions", exportAs: ["cubDialogActions"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubConfirmDialog, decorators: [{
            type: Component,
            args: [{ selector: 'cub-confirm-dialog', exportAs: 'cubConfirmDialog', imports: [
                        CubDefaultDialog,
                        CubDialogHeader,
                        CubDialogTitle,
                        CubDialogClose,
                        CubIconButton,
                        CubDialogContent,
                        NgIf,
                        CubDialogActions,
                        CubButton,
                    ], template: "<cub-default-dialog>\n  <cub-dialog-header>\n    <cub-dialog-title>\n      {{ dialogData.title }}\n    </cub-dialog-title>\n    <cub-dialog-close>\n      <button\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"plain\"\n        (click)=\"dialogRef.close()\"\n      >\n        <span class=\"cub-icon-x\"></span>\n      </button>\n    </cub-dialog-close>\n  </cub-dialog-header>\n  <cub-dialog-content>\n    <div\n      *ngIf=\"dialogData.description\"\n      [innerHTML]=\"dialogData.description\"\n    ></div>\n    <!-- \u56E0\u70BA\u9700\u8981\u652F\u63F4 innerHTML \u6240\u4EE5\u6C92\u6709\u4F7F\u7528 <cub-dialog-code> Start -->\n    <div\n      *ngIf=\"dialogData.returnCode\"\n      [innerHTML]=\"dialogData.returnCode\"\n      class=\"cub-dialog-code\"\n    ></div>\n    <!-- End -->\n  </cub-dialog-content>\n  <cub-dialog-actions>\n    <button\n      *ngIf=\"!dialogData.subButton?.hidden\"\n      cub-button\n      type=\"button\"\n      [withMinWidth]=\"true\"\n      [appearance]=\"dialogData.subButton?.appearance || 'filled-outline'\"\n      [color]=\"dialogData.subButton?.color || 'neutral'\"\n      (click)=\"dialogRef.close('cancel')\"\n    >\n      {{ dialogData.subButton?.label }}\n    </button>\n    <button\n      cub-button\n      type=\"button\"\n      [withMinWidth]=\"true\"\n      [appearance]=\"dialogData.mainButton.appearance || 'filled'\"\n      [color]=\"dialogData.mainButton.color || 'brand'\"\n      (click)=\"dialogRef.close('confirm')\"\n    >\n      {{ dialogData.mainButton.label }}\n    </button>\n  </cub-dialog-actions>\n</cub-default-dialog>\n" }]
        }], ctorParameters: () => [{ type: CubDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DIALOG_DATA]
                }] }] });

class CubDialogCode {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogCode, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDialogCode, isStandalone: true, selector: "cub-dialog-code", host: { classAttribute: "cub-dialog-code" }, exportAs: ["cubDialogCode"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogCode, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-dialog-code',
                    exportAs: 'cubDialogCode',
                    host: {
                        class: 'cub-dialog-code',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDialogModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubDialogModule, imports: [CubButtonModule,
            CubDialogContainer,
            CubDialogHeader,
            CubDialogTitle,
            CubDefaultDialog,
            CubConfirmDialog,
            CubDialogCode,
            CubDialogClose,
            CubDialogContent,
            CubDialogActions], exports: [CubButtonModule,
            CubDialogContainer,
            CubDialogHeader,
            CubDialogTitle,
            CubDefaultDialog,
            CubConfirmDialog,
            CubDialogCode,
            CubDialogClose,
            CubDialogContent,
            CubDialogActions] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogModule, providers: [...CUB_CDK_OVERLAY_PROVIDER_LIST, ...CUB_DIALOG_PROVIDER_LIST], imports: [CubButtonModule,
            CubConfirmDialog, CubButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubButtonModule,
                        CubDialogContainer,
                        CubDialogHeader,
                        CubDialogTitle,
                        CubDefaultDialog,
                        CubConfirmDialog,
                        CubDialogCode,
                        CubDialogClose,
                        CubDialogContent,
                        CubDialogActions,
                    ],
                    exports: [
                        CubButtonModule,
                        CubDialogContainer,
                        CubDialogHeader,
                        CubDialogTitle,
                        CubDefaultDialog,
                        CubConfirmDialog,
                        CubDialogCode,
                        CubDialogClose,
                        CubDialogContent,
                        CubDialogActions,
                    ],
                    providers: [...CUB_CDK_OVERLAY_PROVIDER_LIST, ...CUB_DIALOG_PROVIDER_LIST],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/dialog
 */
/* Core */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_DIALOG_DATA, CUB_DIALOG_DEFAULT_OPTIONS, CUB_DIALOG_PROVIDER_LIST, CUB_DIALOG_SCROLL_STRATEGY, CUB_DIALOG_SCROLL_STRATEGY_FACTORY, CUB_DIALOG_SCROLL_STRATEGY_PROVIDER, CUB_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY, CubConfirmDialog, CubDefaultDialog, CubDialog, CubDialogActions, CubDialogAnimations, CubDialogClose, CubDialogCode, CubDialogConfig, CubDialogContainer, CubDialogContent, CubDialogDefaultParams, CubDialogHeader, CubDialogModule, CubDialogRef, CubDialogTitle, _CloseDialogVia, _CubDialogBase, _CubDialogContainerBase, getClosestDialog };
//# sourceMappingURL=cub-lib-view-rootng-component-dialog.mjs.map
