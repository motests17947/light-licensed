import * as i0 from '@angular/core';
import { InjectionToken, Inject, Injectable, EventEmitter, DOCUMENT, Optional, Component, ChangeDetectionStrategy, ViewEncapsulation, SkipSelf, Directive, NgModule } from '@angular/core';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { Dialog, DialogConfig, CubCdkDialogContainer, CUB_CDK_DIALOG_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/dialog';
import { Subject, merge, defer } from 'rxjs';
import { filter, take, startWith } from 'rxjs/operators';
import { ESCAPE, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { trigger, state, transition, style, group, animate, query, animateChild } from '@angular/animations';
import * as i1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { CubCdkPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import * as i1$1 from 'cub-lib-view-rootng/cdk/a11y';
import * as i2 from '@angular/common';
import { CubButtonModule } from 'cub-lib-view-rootng/component/button';

function CUB_DRAWER_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.block();
}
function CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay) {
    return () => overlay.scrollStrategies.block();
}
function getClosestDrawer(element, openDrawers) {
    let parent = element.nativeElement.parentElement;
    while (parent && !parent.classList.contains('cub-drawer-container')) {
        parent = parent.parentElement;
    }
    return parent ? openDrawers.find((drawer) => drawer.id === parent.id) : null;
}
function _CloseDrawerVia(ref, interactionType, result) {
    ref._closeInteractionType = interactionType;
    return ref.close(result);
}

const CUB_DRAWER_DATA = new InjectionToken('CubDrawerData');
const CUB_DRAWER_SCROLL_STRATEGY = new InjectionToken('cub-drawer-scroll-strategy');
const CUB_DRAWER_SCROLL_STRATEGY_PROVIDER = {
    provide: CUB_DRAWER_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY,
};
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
const CubDrawerDefaultParams = {
    params: { enterAnimationDuration: '300ms', exitAnimationDuration: '200ms' },
};
/**
 * Animations used by CubDrawer.
 * @docs-private
 */
const CubDrawerAnimations = {
    /** Animation that is applied on the drawer container by default. */
    drawerContainer: trigger('drawerContainer', [
        // Note: The `enter` animation transitions to `transform: none`, because for some reason
        // specifying the transform explicitly, causes IE both to blur the drawer content and
        // decimate the animation performance. Leaving it as `none` solves both issues.
        state('void, exit', style({ opacity: 0, transform: 'translate3d(100%, 0, 0)' })),
        state('enter', style({ transform: 'none' })),
        transition('* => enter', group([
            animate('{{enterAnimationDuration}} cubic-bezier(0, 0, 0.2, 1)', style({ transform: 'none', opacity: 1 })),
            query('@*', animateChild(), { optional: true }),
        ]), CubDrawerDefaultParams),
        transition('* => void, * => exit', group([
            animate('{{exitAnimationDuration}} cubic-bezier(0.4, 0.0, 0.2, 1)', style({ opacity: 0, transform: 'translate3d(100%, 0, 0)' })),
            query('@*', animateChild(), { optional: true }),
        ]), CubDrawerDefaultParams),
    ]),
};

const CUB_DRAWER_DEFAULT_OPTIONS = new InjectionToken('cub-drawer-default-options');
class CubDrawerConfig {
    constructor() {
        this.role = 'drawer';
        this.panelClass = '';
        this.hasBackdrop = true;
        this.backdropClass = '';
        this.disableClose = false;
        this.width = '';
        this.height = '';
        this.data = null;
        this.ariaDescribedBy = null;
        this.ariaLabelledBy = null;
        this.ariaLabel = null;
        this.ariaModal = true;
        this.autoFocus = 'cub-drawer-title';
        this.restoreFocus = false;
        this.delayFocusTrap = false;
        this.closeOnNavigation = true;
        this.enterAnimationDuration = CubDrawerDefaultParams.params.enterAnimationDuration;
        this.exitAnimationDuration = CubDrawerDefaultParams.params.exitAnimationDuration;
    }
}
class CubDrawerRef {
    constructor(_ref, config, _containerInstance) {
        this._ref = _ref;
        this._containerInstance = _containerInstance;
        this._afterOpened = new Subject();
        this._beforeClosed = new Subject();
        this._state = 0 /* CubDrawerState.OPEN */;
        this.disableClose = config.disableClose;
        this.id = _ref.id;
        _containerInstance._animationStateChanged
            .pipe(filter((event) => event.state === 'opened'), take(1))
            .subscribe(() => {
            this._afterOpened.next();
            this._afterOpened.complete();
        });
        _containerInstance._animationStateChanged
            .pipe(filter((event) => event.state === 'closed'), take(1))
            .subscribe(() => {
            clearTimeout(this._closeFallbackTimeout);
            this._finishDrawerClose();
        });
        _ref.overlayRef.detachments().subscribe(() => {
            this._beforeClosed.next(this._result);
            this._beforeClosed.complete();
            this._finishDrawerClose();
        });
        merge(this.backdropClick(), this.keydownEvents().pipe(filter((event) => event.keyCode === ESCAPE &&
            !this.disableClose &&
            !hasModifierKey(event)))).subscribe((event) => {
            if (!this.disableClose) {
                event.preventDefault();
                _CloseDrawerVia(this, event.type === 'keydown' ? 'keyboard' : 'mouse');
            }
        });
    }
    close(drawerResult) {
        this._result = drawerResult;
        this._containerInstance._animationStateChanged
            .pipe(filter((event) => event.state === 'closing'), take(1))
            .subscribe((event) => {
            this._beforeClosed.next(drawerResult);
            this._beforeClosed.complete();
            this._ref.overlayRef.detachBackdrop();
            this._closeFallbackTimeout = setTimeout(() => this._finishDrawerClose(), event.totalTime + 100);
        });
        this._state = 1 /* CubDrawerState.CLOSING */;
        this._containerInstance._startExitAnimation();
    }
    afterOpened() {
        return this._afterOpened;
    }
    afterClosed() {
        return this._ref.closed;
    }
    beforeClosed() {
        return this._beforeClosed;
    }
    backdropClick() {
        return this._ref.backdropClick;
    }
    keydownEvents() {
        return this._ref.keydownEvents;
    }
    updatePosition(position) {
        let strategy = this._ref.config.positionStrategy;
        if (position && (position.left || position.right)) {
            position.left
                ? strategy.left(position.left)
                : strategy.right(position.right);
        }
        else {
            strategy.centerHorizontally();
        }
        if (position && (position.top || position.bottom)) {
            position.top
                ? strategy.top(position.top)
                : strategy.bottom(position.bottom);
        }
        else {
            strategy.centerVertically();
        }
        this._ref.updatePosition();
        return this;
    }
    updateSize(width = '', height = '') {
        this._ref.updateSize(width, height);
        return this;
    }
    addPanelClass(classes) {
        this._ref.addPanelClass(classes);
        return this;
    }
    removePanelClass(classes) {
        this._ref.removePanelClass(classes);
        return this;
    }
    getState() {
        return this._state;
    }
    _finishDrawerClose() {
        this._state = 2 /* CubDrawerState.CLOSED */;
        this._ref.close(this._result, { focusOrigin: this._closeInteractionType });
        this.componentInstance = null;
    }
}

let uniqueId = 0;
class _CubDrawerBase {
    /** Keeps track of the currently-open drawers. */
    get openDrawers() {
        return this._parentDrawer
            ? this._parentDrawer.openDrawers
            : this._openDrawersAtThisLevel;
    }
    /** Stream that emits when a drawer has been opened. */
    get afterOpened() {
        return this._parentDrawer
            ? this._parentDrawer.afterOpened
            : this._afterOpenedAtThisLevel;
    }
    constructor(_overlay, injector, _defaultOptions, _parentDrawer, _overlayContainer, scrollStrategy, _drawerRefConstructor, _drawerContainerType, _drawerDataToken, _animationMode) {
        this._overlay = _overlay;
        this._defaultOptions = _defaultOptions;
        this._parentDrawer = _parentDrawer;
        this._drawerRefConstructor = _drawerRefConstructor;
        this._drawerContainerType = _drawerContainerType;
        this._drawerDataToken = _drawerDataToken;
        this.afterAllClosed = defer(() => this.openDrawers.length
            ? this._getAfterAllClosed()
            : this._getAfterAllClosed().pipe(startWith(undefined)));
        this._idPrefix = 'cub-drawer-';
        this._openDrawersAtThisLevel = [];
        this._afterAllClosedAtThisLevel = new Subject();
        this._afterOpenedAtThisLevel = new Subject();
        this._scrollStrategy = scrollStrategy;
        this._drawer = injector.get(Dialog);
    }
    open(componentOrTemplateRef, config) {
        let drawerRef;
        config = { ...(this._defaultOptions || new CubDrawerConfig()), ...config };
        config.id = config.id || `${this._idPrefix}${uniqueId++}`;
        config.scrollStrategy = config.scrollStrategy || this._scrollStrategy();
        const cdkRef = this._drawer.open(componentOrTemplateRef, {
            ...config,
            positionStrategy: this._overlay.position().global().end().top(),
            disableClose: true,
            closeOnDestroy: false,
            container: {
                type: this._drawerContainerType,
                providers: () => [
                    { provide: CubDrawerConfig, useValue: config },
                    { provide: DialogConfig, useValue: config },
                ],
            },
            templateContext: () => ({ drawerRef }),
            providers: (ref, cdkConfig, drawerContainer) => {
                drawerRef = new this._drawerRefConstructor(ref, config, drawerContainer);
                return [
                    { provide: this._drawerContainerType, useValue: drawerContainer },
                    { provide: this._drawerDataToken, useValue: cdkConfig.data },
                    { provide: this._drawerRefConstructor, useValue: drawerRef },
                ];
            },
        });
        drawerRef.componentInstance = cdkRef.componentInstance;
        this.openDrawers.push(drawerRef);
        this.afterOpened.next(drawerRef);
        drawerRef.afterClosed().subscribe(() => {
            const index = this.openDrawers.indexOf(drawerRef);
            if (index > -1) {
                this.openDrawers.splice(index, 1);
                if (!this.openDrawers.length) {
                    this._getAfterAllClosed().next();
                }
            }
        });
        return drawerRef;
    }
    closeAll() {
        this._closeDrawers(this.openDrawers);
    }
    getDrawerById(id) {
        return this.openDrawers.find((drawer) => drawer.id === id);
    }
    ngOnDestroy() {
        this._closeDrawers(this._openDrawersAtThisLevel);
        this._afterAllClosedAtThisLevel.complete();
        this._afterOpenedAtThisLevel.complete();
    }
    _closeDrawers(drawers) {
        let i = drawers.length;
        while (i--) {
            drawers[i].close();
        }
    }
    _getAfterAllClosed() {
        const parent = this._parentDrawer;
        return parent
            ? parent._getAfterAllClosed()
            : this._afterAllClosedAtThisLevel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDrawerBase, deps: [{ token: i1.Overlay }, { token: i0.Injector }, { token: String }, { token: String }, { token: i1.OverlayContainer }, { token: String }, { token: i0.Type }, { token: i0.Type }, { token: i0.InjectionToken }, { token: String }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDrawerBase }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDrawerBase, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.Injector }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }, { type: i1.OverlayContainer }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }, { type: i0.Type }, { type: i0.Type }, { type: i0.InjectionToken }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [String]
                }] }] });

class _CubDrawerContainerBase extends CubCdkDialogContainer {
    constructor(elementRef, focusTrapFactory, _document, drawerConfig, interactivityChecker, ngZone, overlayRef, focusMonitor) {
        super(elementRef, focusTrapFactory, _document, drawerConfig, interactivityChecker, ngZone, overlayRef, focusMonitor);
        this._animationStateChanged = new EventEmitter();
    }
    _captureInitialFocus() {
        if (!this._config.delayFocusTrap) {
            this._trapFocus();
        }
    }
    _openAnimationDone(totalTime) {
        if (this._config.delayFocusTrap) {
            this._trapFocus();
        }
        this._animationStateChanged.next({ state: 'opened', totalTime });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDrawerContainerBase, deps: [{ token: i0.ElementRef }, { token: i1$1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: CubDrawerConfig }, { token: i1$1.InteractivityChecker }, { token: i0.NgZone }, { token: i1.OverlayRef }, { token: i1$1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: _CubDrawerContainerBase, isStandalone: true, selector: "cub-drawer-container-base", usesInheritance: true, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDrawerContainerBase, decorators: [{
            type: Component,
            args: [{
                    selector: 'cub-drawer-container-base',
                    template: '',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: CubDrawerConfig }, { type: i1$1.InteractivityChecker }, { type: i0.NgZone }, { type: i1.OverlayRef }, { type: i1$1.FocusMonitor }] });

class CubDrawerContainer extends _CubDrawerContainerBase {
    constructor(elementRef, focusTrapFactory, document, drawerConfig, checker, ngZone, overlayRef, _changeDetectorRef, focusMonitor) {
        super(elementRef, focusTrapFactory, document, drawerConfig, checker, ngZone, overlayRef, focusMonitor);
        this._changeDetectorRef = _changeDetectorRef;
        this._state = 'enter';
    }
    _onAnimationDone({ toState, totalTime }) {
        if (toState === 'enter') {
            this._openAnimationDone(totalTime);
        }
        else if (toState === 'exit') {
            this._animationStateChanged.next({ state: 'closed', totalTime });
        }
    }
    _onAnimationStart({ toState, totalTime }) {
        if (toState === 'enter') {
            this._animationStateChanged.next({ state: 'opening', totalTime });
        }
        else if (toState === 'exit' || toState === 'void') {
            this._animationStateChanged.next({ state: 'closing', totalTime });
        }
    }
    _startExitAnimation() {
        this._state = 'exit';
        this._changeDetectorRef.markForCheck();
    }
    _getAnimationState() {
        return {
            value: this._state,
            params: {
                enterAnimationDuration: this._config.enterAnimationDuration ||
                    CubDrawerDefaultParams.params.enterAnimationDuration,
                exitAnimationDuration: this._config.exitAnimationDuration ||
                    CubDrawerDefaultParams.params.exitAnimationDuration,
            },
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerContainer, deps: [{ token: i0.ElementRef }, { token: i1$1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: CubDrawerConfig }, { token: i1$1.InteractivityChecker }, { token: i0.NgZone }, { token: i1.OverlayRef }, { token: i0.ChangeDetectorRef }, { token: i1$1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerContainer, isStandalone: true, selector: "cub-drawer-container", host: { attributes: { "tabindex": "-1" }, listeners: { "@drawerContainer.start": "_onAnimationStart($event)", "@drawerContainer.done": "_onAnimationDone($event)" }, properties: { "id": "_config.id", "attr.role": "_config.role", "attr.aria-modal": "_config.ariaModal", "attr.aria-labelledby": "_config.ariaLabel ? null : _ariaLabelledBy", "attr.aria-label": "_config.ariaLabel", "attr.aria-describedby": "_config.ariaDescribedBy || null", "@drawerContainer": "_getAnimationState()" }, classAttribute: "cub-drawer-container" }, exportAs: ["cubDrawerContainer"], usesInheritance: true, ngImport: i0, template: "<ng-template cubCdkPortalOutlet></ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkPortalOutlet, selector: "[cubCdkPortalOutlet]", inputs: ["cubCdkPortalOutlet"], outputs: ["attached"], exportAs: ["cubCdkPortalOutlet"] }], animations: [CubDrawerAnimations.drawerContainer], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerContainer, decorators: [{
            type: Component,
            args: [{ selector: 'cub-drawer-container', exportAs: 'cubDrawerContainer', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Default, animations: [CubDrawerAnimations.drawerContainer], host: {
                        class: 'cub-drawer-container',
                        tabindex: '-1',
                        '[id]': '_config.id',
                        '[attr.role]': '_config.role',
                        '[attr.aria-modal]': '_config.ariaModal',
                        '[attr.aria-labelledby]': '_config.ariaLabel ? null : _ariaLabelledBy',
                        '[attr.aria-label]': '_config.ariaLabel',
                        '[attr.aria-describedby]': '_config.ariaDescribedBy || null',
                        '[@drawerContainer]': `_getAnimationState()`,
                        '(@drawerContainer.start)': '_onAnimationStart($event)',
                        '(@drawerContainer.done)': '_onAnimationDone($event)',
                    }, imports: [CubCdkPortalOutlet], template: "<ng-template cubCdkPortalOutlet></ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: CubDrawerConfig }, { type: i1$1.InteractivityChecker }, { type: i0.NgZone }, { type: i1.OverlayRef }, { type: i0.ChangeDetectorRef }, { type: i1$1.FocusMonitor }] });

class CubDrawer extends _CubDrawerBase {
    constructor(overlay, injector, _location, defaultOptions, scrollStrategy, parentDrawer, overlayContainer, animationMode) {
        super(overlay, injector, defaultOptions, parentDrawer, overlayContainer, scrollStrategy, CubDrawerRef, CubDrawerContainer, CUB_DRAWER_DATA, animationMode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawer, deps: [{ token: i1.Overlay }, { token: i0.Injector }, { token: i2.Location, optional: true }, { token: CUB_DRAWER_DEFAULT_OPTIONS, optional: true }, { token: CUB_DRAWER_SCROLL_STRATEGY }, { token: CubDrawer, optional: true, skipSelf: true }, { token: i1.OverlayContainer }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawer }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawer, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.Injector }, { type: i2.Location, decorators: [{
                    type: Optional
                }] }, { type: CubDrawerConfig, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_DRAWER_DEFAULT_OPTIONS]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DRAWER_SCROLL_STRATEGY]
                }] }, { type: CubDrawer, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.OverlayContainer }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }] });
const CUB_DRAWER_PROVIDER_LIST = [
    ...CUB_CDK_DIALOG_PROVIDER_LIST,
    CubDrawer,
    CUB_DRAWER_SCROLL_STRATEGY_PROVIDER,
];

class CubDrawerHeader {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerHeader, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerHeader, isStandalone: true, selector: "cub-drawer-header", host: { classAttribute: "cub-drawer-header" }, exportAs: ["cubDrawerHeader"], ngImport: i0, template: "<ng-content select=\"cub-drawer-title\"></ng-content>\n<ng-content select=\"cub-drawer-close\"></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-drawer-header', exportAs: 'cubDrawerHeader', host: {
                        class: 'cub-drawer-header',
                    }, template: "<ng-content select=\"cub-drawer-title\"></ng-content>\n<ng-content select=\"cub-drawer-close\"></ng-content>\n" }]
        }], ctorParameters: () => [] });

class CubDrawerTitle {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerTitle, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerTitle, isStandalone: true, selector: "cub-drawer-title", host: { classAttribute: "cub-drawer-title" }, exportAs: ["cubDrawerTitle"], ngImport: i0, template: "<ng-content></ng-content>\n<ng-content select=\"cub-drawer-code\"></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerTitle, decorators: [{
            type: Component,
            args: [{ selector: 'cub-drawer-title', exportAs: 'cubDrawerTitle', host: {
                        class: 'cub-drawer-title',
                    }, template: "<ng-content></ng-content>\n<ng-content select=\"cub-drawer-code\"></ng-content>\n" }]
        }], ctorParameters: () => [] });

class CubDefaultDrawer {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDefaultDrawer, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDefaultDrawer, isStandalone: true, selector: "cub-default-drawer", host: { classAttribute: "cub-default-drawer" }, exportAs: ["cubDefaultDrawer"], ngImport: i0, template: "<ng-content select=\"cub-drawer-header\"></ng-content>\n\n<div class=\"cub-drawer-content-container\">\n  <ng-content select=\"cub-drawer-content\"></ng-content>\n\n  <ng-content select=\"cub-drawer-actions\"></ng-content>\n</div>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDefaultDrawer, decorators: [{
            type: Component,
            args: [{ selector: 'cub-default-drawer', exportAs: 'cubDefaultDrawer', host: {
                        class: 'cub-default-drawer',
                    }, template: "<ng-content select=\"cub-drawer-header\"></ng-content>\n\n<div class=\"cub-drawer-content-container\">\n  <ng-content select=\"cub-drawer-content\"></ng-content>\n\n  <ng-content select=\"cub-drawer-actions\"></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [] });

class CubDrawerCode {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerCode, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerCode, isStandalone: true, selector: "cub-drawer-code", host: { classAttribute: "cub-drawer-code" }, exportAs: ["cubDrawerCode"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerCode, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-drawer-code',
                    exportAs: 'cubDrawerCode',
                    host: {
                        class: 'cub-drawer-code',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDrawerClose {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerClose, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerClose, isStandalone: true, selector: "cub-drawer-close", host: { classAttribute: "cub-drawer-close" }, exportAs: ["cubDrawerClose"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerClose, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-drawer-close',
                    exportAs: 'cubDrawerClose',
                    host: {
                        class: 'cub-drawer-close',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDrawerContent {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerContent, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerContent, isStandalone: true, selector: "cub-drawer-content", host: { classAttribute: "cub-drawer-content" }, exportAs: ["cubDrawerContent"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerContent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-drawer-content',
                    exportAs: 'cubDrawerContent',
                    host: {
                        class: 'cub-drawer-content',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDrawerActions {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerActions, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDrawerActions, isStandalone: true, selector: "cub-drawer-actions", host: { classAttribute: "cub-drawer-actions" }, exportAs: ["cubDrawerActions"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerActions, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-drawer-actions',
                    exportAs: 'cubDrawerActions',
                    host: {
                        class: 'cub-drawer-actions',
                    },
                }]
        }], ctorParameters: () => [] });

class CubDrawerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerModule, imports: [CubButtonModule,
            CubDrawerContainer,
            CubDrawerHeader,
            CubDrawerTitle,
            CubDefaultDrawer,
            CubDrawerCode,
            CubDrawerClose,
            CubDrawerContent,
            CubDrawerActions], exports: [CubButtonModule,
            CubDrawerContainer,
            CubDrawerHeader,
            CubDrawerTitle,
            CubDefaultDrawer,
            CubDrawerCode,
            CubDrawerClose,
            CubDrawerContent,
            CubDrawerActions] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerModule, providers: [...CUB_CDK_OVERLAY_PROVIDER_LIST, ...CUB_DRAWER_PROVIDER_LIST], imports: [CubButtonModule, CubButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDrawerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubButtonModule,
                        CubDrawerContainer,
                        CubDrawerHeader,
                        CubDrawerTitle,
                        CubDefaultDrawer,
                        CubDrawerCode,
                        CubDrawerClose,
                        CubDrawerContent,
                        CubDrawerActions,
                    ],
                    exports: [
                        CubButtonModule,
                        CubDrawerContainer,
                        CubDrawerHeader,
                        CubDrawerTitle,
                        CubDefaultDrawer,
                        CubDrawerCode,
                        CubDrawerClose,
                        CubDrawerContent,
                        CubDrawerActions,
                    ],
                    providers: [...CUB_CDK_OVERLAY_PROVIDER_LIST, ...CUB_DRAWER_PROVIDER_LIST],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/drawer
 */
/* Core */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_DRAWER_DATA, CUB_DRAWER_DEFAULT_OPTIONS, CUB_DRAWER_PROVIDER_LIST, CUB_DRAWER_SCROLL_STRATEGY, CUB_DRAWER_SCROLL_STRATEGY_FACTORY, CUB_DRAWER_SCROLL_STRATEGY_PROVIDER, CUB_DRAWER_SCROLL_STRATEGY_PROVIDER_FACTORY, CubDefaultDrawer, CubDrawer, CubDrawerActions, CubDrawerAnimations, CubDrawerClose, CubDrawerCode, CubDrawerConfig, CubDrawerContainer, CubDrawerContent, CubDrawerDefaultParams, CubDrawerHeader, CubDrawerModule, CubDrawerRef, CubDrawerTitle, _CloseDrawerVia, _CubDrawerBase, _CubDrawerContainerBase, getClosestDrawer };
//# sourceMappingURL=cub-lib-view-rootng-component-drawer.mjs.map
