import * as i0 from '@angular/core';
import { InjectionToken, DOCUMENT, Inject, Directive, inject, ChangeDetectorRef, ContentChild, Input, Optional, QueryList, EventEmitter, TemplateRef, booleanAttribute, ContentChildren, ViewChild, Output, ViewEncapsulation, ChangeDetectionStrategy, Component, ElementRef, numberAttribute, Self, NgModule } from '@angular/core';
import { NgClass } from '@angular/common';
import { trigger, state, transition, style, animate } from '@angular/animations';
import { Overlay, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { Subject, merge, Observable, take as take$1, takeUntil, startWith as startWith$1, switchMap as switchMap$1, Subscription, filter, of, delay, asapScheduler } from 'rxjs';
import { startWith, switchMap, take } from 'rxjs/operators';
import { FocusKeyManager } from 'cub-lib-view-rootng/cdk/a11y';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { UP_ARROW, DOWN_ARROW, TAB, RIGHT_ARROW, LEFT_ARROW, ESCAPE, hasModifierKey, ENTER as ENTER$1, SPACE as SPACE$1 } from 'cub-lib-view-rootng/cdk/keycodes';
import * as i1 from 'cub-lib-view-rootng/cdk';
import { TemplatePortal, DomPortalOutlet, ENTER, SPACE, normalizePassiveListenerOptions, isFakeTouchstartFromScreenReader, isFakeMousedownFromScreenReader, RIGHT_ARROW as RIGHT_ARROW$1, LEFT_ARROW as LEFT_ARROW$1, OverlayConfig } from 'cub-lib-view-rootng/cdk';
import { mixinDisableRipple, mixinDisabled, CubPrefix, CubSuffix, CubRipple, CubDivider } from 'cub-lib-view-rootng/component/common';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';

function throwDropDownInvalidPositionX() {
    throw Error(`positionStart value must be either 'above', 'below', 'before' or 'after'.
      Example: <cub-drop-down positionStart="before" #drop-down="cubDropDown"></cub-drop-down>`);
}
function throwDropDownInvalidPositionY() {
    throw Error(`positionEnd value must be either 'above', 'below', 'before' or 'after'.
      Example: <cub-drop-down positionEnd="above" #drop-down="cubDropDown"></cub-drop-down>`);
}
function throwDropDownRecursiveError() {
    throw Error(`cubDropDownTriggerFor: drop-down cannot contain its own trigger. Assign a drop-down that is ` +
        `not a parent of the trigger or move the trigger outside of the drop-down.`);
}
function CUB_DROP_DOWN_DEFAULT_OPTIONS_FACTORY() {
    return {
        overlapTrigger: false,
        positionStart: 'below',
        positionEnd: 'before',
        backdropClass: 'cub-cdk-overlay-transparent-backdrop',
        overlayPanelClass: 'cub-drop-down-overlay',
    };
}
function CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition();
}

const CUB_DROP_DOWN_PANEL = new InjectionToken('CUB_DROP_DOWN_PANEL');
const CUB_DROP_DOWN_DEFAULT_OPTIONS = new InjectionToken('cub-drop-down-default-options', {
    providedIn: 'root',
    factory: CUB_DROP_DOWN_DEFAULT_OPTIONS_FACTORY,
});
const CUB_DROP_DOWN_SCROLL_STRATEGY = new InjectionToken('cub-drop-down-scroll-strategy');
const CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY_PROVIDER = {
    provide: CUB_DROP_DOWN_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY,
};
const cubDropDownAnimations = {
    transformDropDown: trigger('transformDropDown', [
        state('void', style({
            opacity: 0,
            transform: 'scale(0.8)',
        })),
        transition('void => enter', animate('120ms cubic-bezier(0, 0, 0.2, 1)', style({
            opacity: 1,
            transform: 'scale(1)',
        }))),
        transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
    ]),
    fadeInItems: trigger('fadeInItems', [
        state('showing', style({ opacity: 1 })),
        transition('void => *', [
            style({ opacity: 0 }),
            animate('400ms 100ms cubic-bezier(0.55, 0, 0.55, 0.2)'),
        ]),
    ]),
};
const CUB_DROP_DOWN_ITEM_HANDLE = new InjectionToken('CubDropDownItemHandle');

class _CubDropDownContentBase {
    constructor(_templateRef, _componentFactoryResolver, _appRef, _injector, _viewContainerRef, _document, _changeDetectorRef) {
        this._templateRef = _templateRef;
        this._componentFactoryResolver = _componentFactoryResolver;
        this._appRef = _appRef;
        this._injector = _injector;
        this._viewContainerRef = _viewContainerRef;
        this._document = _document;
        this._changeDetectorRef = _changeDetectorRef;
        this._attached = new Subject();
    }
    attach(context = {}) {
        if (!this._portal) {
            this._portal = new TemplatePortal(this._templateRef, this._viewContainerRef);
        }
        this.detach();
        if (!this._outlet) {
            this._outlet = new DomPortalOutlet(this._document.createElement('div'), this._componentFactoryResolver, this._appRef, this._injector);
        }
        const element = this._templateRef.elementRef.nativeElement;
        element.parentNode.insertBefore(this._outlet.outletElement, element);
        this._changeDetectorRef?.markForCheck();
        this._portal.attach(this._outlet, context);
        this._attached.next();
    }
    detach() {
        if (this._portal.isAttached) {
            this._portal.detach();
        }
    }
    ngOnDestroy() {
        if (this._outlet) {
            this._outlet.dispose();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDropDownContentBase, deps: [{ token: i0.TemplateRef }, { token: i0.ComponentFactoryResolver }, { token: i0.ApplicationRef }, { token: i0.Injector }, { token: i0.ViewContainerRef }, { token: DOCUMENT }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubDropDownContentBase, isStandalone: true, selector: "cubDropDownContentBase", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDropDownContentBase, decorators: [{
            type: Directive,
            args: [{ selector: 'cubDropDownContentBase' }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.ComponentFactoryResolver }, { type: i0.ApplicationRef }, { type: i0.Injector }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.ChangeDetectorRef }] });

const CUB_DROP_DOWN_CONTENT = new InjectionToken('CubDropDownContent');
class CubDropDownContent extends _CubDropDownContentBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownContent, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDropDownContent, isStandalone: true, selector: "ng-template[cubDropDownContent]", providers: [
            { provide: CUB_DROP_DOWN_CONTENT, useExisting: CubDropDownContent },
        ], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownContent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[cubDropDownContent]',
                    providers: [
                        { provide: CUB_DROP_DOWN_CONTENT, useExisting: CubDropDownContent },
                    ]
                }]
        }] });

const CUB_DROP_DOWN_ITEM = new InjectionToken('CubDropDownItem');
const _CubDropDownItemBase = mixinDisableRipple(mixinDisabled(class {
}));
class CubDropDownItem extends _CubDropDownItemBase {
    get prefixSpace() {
        return this._parentDropDown.prefixSpace;
    }
    /**
     * 元件數值，預設為 undefined。
     */
    get value() {
        return this._value !== undefined ? this._value : this.label;
    }
    set value(value) {
        this._value = value;
    }
    /**
     * 是否為 loading 的狀態，預設值為 false。
     */
    get loading() {
        return this._loading;
    }
    set loading(value) {
        this._loading = value;
        this._changeDetectorRef.markForCheck();
    }
    constructor(_elementRef, _document, _focusMonitor, _parentDropDown) {
        super();
        this._elementRef = _elementRef;
        this._document = _document;
        this._focusMonitor = _focusMonitor;
        this._parentDropDown = _parentDropDown;
        this._changeDetectorRef = inject(ChangeDetectorRef);
        this._dropDownItemsMultiple = false;
        this._dropDownItemsSelectable = false;
        this._highlighted = false;
        this._triggersSubDropDown = false;
        this._loading = false;
        this.withPrefix = false;
        this.size = 'medium';
        this._hovered = new Subject();
        this._focused = new Subject();
        /*
         * 設立元件的顯示文字。
         */
        this.label = '';
        this.prefixContent = null;
        this.suffixContent = null;
        _parentDropDown?.addItem?.(this);
    }
    ngAfterViewInit() {
        this._textElement = this._elementRef.nativeElement.querySelector('.cub-drop-down-item-content-text');
        if (this._focusMonitor) {
            this._focusMonitor.monitor(this._elementRef, false);
        }
        if (this.prefixContent) {
            this.withPrefix = true;
            this._changeDetectorRef?.markForCheck();
        }
        if (this.suffixContent) {
            this._changeDetectorRef?.markForCheck();
        }
    }
    ngOnDestroy() {
        if (this._focusMonitor) {
            this._focusMonitor.stopMonitoring(this._elementRef);
        }
        if (this._parentDropDown && this._parentDropDown.removeItem) {
            this._parentDropDown.removeItem(this);
        }
        this._hovered.complete();
        this._focused.complete();
    }
    focus(origin, options) {
        if (this._focusMonitor && origin) {
            this._focusMonitor.focusVia(this._getHostElement(), origin, options);
        }
        else {
            this._getHostElement().focus(options);
        }
        this._focused.next(this);
    }
    getLabel() {
        const clone = this._elementRef.nativeElement.cloneNode(true);
        const icons = clone.querySelectorAll('cub-icon');
        for (let i = 0; i < icons.length; i++) {
            icons[i].remove();
        }
        return clone.textContent?.trim() || '';
    }
    _getTabIndex() {
        return this.disabled ? '-1' : '0';
    }
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    _checkDisabled(event) {
        if (this.disabled) {
            event.preventDefault();
            event.stopPropagation();
        }
    }
    _handleMouseEnter() {
        this._hovered.next(this);
    }
    _setHighlighted(isHighlighted) {
        this._highlighted = isHighlighted;
        this._changeDetectorRef?.markForCheck();
    }
    _setTriggersSubdropDown(triggersSubdropDown) {
        this._triggersSubDropDown = triggersSubdropDown;
        this._changeDetectorRef?.markForCheck();
    }
    _hasFocus() {
        return (this._document && this._document.activeElement === this._getHostElement());
    }
    _handlePrimaryActionInteraction(...args) {
        // Empty here, but is overwritten in child classes.
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownItem, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }, { token: i1.FocusMonitor }, { token: CUB_DROP_DOWN_PANEL, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDropDownItem, isStandalone: true, selector: "[cubDropDownItem]", inputs: { disabled: "disabled", disableRipple: "disableRipple", value: "value", label: "label", loading: "loading" }, host: { listeners: { "keydown": "_handleKeydown($event)", "mouseenter": "_handleMouseEnter()" }, properties: { "class.cub-highlighted": "_highlighted", "class.cub-drop-down-item-sub-drop-down-trigger": "_triggersSubDropDown", "attr.role": "role", "attr.tabindex": "_getTabIndex()", "attr.aria-disabled": "disabled", "attr.disabled": "disabled || null" }, classAttribute: "cub-drop-down-item cub-focus-indicator" }, queries: [{ propertyName: "prefixContent", first: true, predicate: CubPrefix, descendants: true }, { propertyName: "suffixContent", first: true, predicate: CubSuffix, descendants: true }], exportAs: ["cubDropDownItem"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubDropDownItem]',
                    exportAs: 'cubDropDownItem',
                    inputs: ['disabled', 'disableRipple'],
                    host: {
                        class: 'cub-drop-down-item cub-focus-indicator',
                        '[class.cub-highlighted]': '_highlighted',
                        '[class.cub-drop-down-item-sub-drop-down-trigger]': '_triggersSubDropDown',
                        '[attr.role]': 'role',
                        '[attr.tabindex]': '_getTabIndex()',
                        '[attr.aria-disabled]': 'disabled',
                        '[attr.disabled]': 'disabled || null',
                        '(keydown)': '_handleKeydown($event)',
                        '(mouseenter)': '_handleMouseEnter()',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.FocusMonitor }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DROP_DOWN_PANEL]
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input
            }], label: [{
                type: Input
            }], loading: [{
                type: Input
            }], prefixContent: [{
                type: ContentChild,
                args: [CubPrefix, { descendants: true }]
            }], suffixContent: [{
                type: ContentChild,
                args: [CubSuffix, { descendants: true }]
            }] } });

let dropDownPanelUid = 0;
class _CubDropDownBase {
    /**
     * 用於設定此drop down 是否允許選項或動作前面有 icon 圖示，預設值為 true。
     */
    get prefixSpace() {
        return this._prefixSpace;
    }
    set prefixSpace(value) {
        this._prefixSpace = value;
    }
    /**
     * 設定 dropDown 在 X 軸的顯示位置，預設值為 'after'。
     */
    get positionStart() {
        return this._positionStart;
    }
    set positionStart(value) {
        if (!['before', 'after', 'above', 'below'].includes(value)) {
            throwDropDownInvalidPositionX();
        }
        this._positionStart = value;
        this.setPositionClasses();
    }
    /**
     * 設定 dropDown 在 Y 軸的顯示位置，預設值為 'below'。
     */
    get positionEnd() {
        return this._positionEnd;
    }
    set positionEnd(value) {
        if (!['before', 'after', 'above', 'below'].includes(value)) {
            throwDropDownInvalidPositionY();
        }
        this._positionEnd = value;
        this.setPositionClasses();
    }
    /**
     * 設定 dropDown 重疊時是否可以觸發，預設值為 false。
     */
    get overlapTrigger() {
        return this._overlapTrigger;
    }
    set overlapTrigger(value) {
        this._overlapTrigger = coerceBooleanProperty(value);
    }
    /**
     * 設定 dropDown 是否要有背景遮罩，預設值為 false。
     */
    get hasBackdrop() {
        return this._hasBackdrop;
    }
    set hasBackdrop(value) {
        this._hasBackdrop = coerceBooleanProperty(value);
    }
    /**
     * 設定 class 的名稱，預設值為 ''。
     */
    set panelClass(classes) {
        const previousPanelClass = this._previousPanelClass;
        if (previousPanelClass && previousPanelClass.length) {
            previousPanelClass.split(' ').forEach((className) => {
                this._classList[className] = false;
            });
        }
        this._previousPanelClass = classes;
        if (classes && classes.length) {
            classes.split(' ').forEach((className) => {
                this._classList[className] = true;
            });
            this._elementRef.nativeElement.className = '';
        }
    }
    constructor(_elementRef, _ngZone, _defaultOptions, _changeDetectorRef) {
        this._elementRef = _elementRef;
        this._ngZone = _ngZone;
        this._defaultOptions = _defaultOptions;
        this._changeDetectorRef = _changeDetectorRef;
        this._directDescendantItems = new QueryList();
        this._classList = {};
        this._panelAnimationState = 'void';
        this._isAnimating = false;
        this.direction = 'ltr';
        this.overlayPanelClass = this._defaultOptions.overlayPanelClass || '';
        this.panelId = `cub-drop-down-panel-${dropDownPanelUid++}`;
        this._animationDone = new Subject();
        this._elevationPrefix = '';
        this._baseElevation = 8;
        this._positionStart = this._defaultOptions.positionStart;
        this._positionEnd = this._defaultOptions.positionEnd;
        this._previousElevation = '';
        this._prefixSpace = true;
        this._overlapTrigger = this._defaultOptions.overlapTrigger;
        this._hasBackdrop = this._defaultOptions.hasBackdrop;
        this._previousPanelClass = '';
        /*
         * 選擇要使用的選單尺寸，預設為 medium。
         */
        this.size = 'medium';
        /**
         * 用於設定 backdrop 的 class 名稱，預設為 'cub-cdk-overlay-transparent-backdrop'。
         */
        this.backdropClass = this._defaultOptions.backdropClass;
        /**
         * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 undefined。
         */
        this.ariaLabel = '';
        /**
         * 添加 aria-labelledby 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 undefined。
         */
        this.ariaLabelledby = '';
        /**
         * 添加 aria-describedby 屬性的值，在標題與欄位型別之後讀的描述內容(螢幕閱讀緝讀取用)，預設值為 undefined。
         */
        this.ariaDescribedby = '';
        /**
         * 當 dropDown 關閉時會送出事件通知。
         */
        this.closed = new EventEmitter();
    }
    ngOnInit() {
        this.setPositionClasses();
    }
    ngAfterContentInit() {
        this._updateDirectDescendants();
        this._keyManager = new FocusKeyManager(this._directDescendantItems)
            .withWrap()
            .withTypeAhead()
            .withHomeAndEnd();
        this._directDescendantItems.changes
            .pipe(startWith(this._directDescendantItems), switchMap((items) => merge(...items.map((item) => item._focused))))
            .subscribe((focusedItem) => this._keyManager.updateActiveItem(focusedItem));
        this._directDescendantItems.changes.subscribe((itemsList) => {
            const manager = this._keyManager;
            if (this._panelAnimationState === 'enter' &&
                manager.activeItem?._hasFocus()) {
                const items = itemsList.toArray();
                const index = Math.max(0, Math.min(items.length - 1, manager.activeItemIndex || 0));
                if (items[index] && !items[index].disabled) {
                    manager.setActiveItem(index);
                }
                else {
                    manager.setNextItemActive();
                }
            }
        });
        this._allItems.forEach((item) => {
            if (this.size)
                item.size = this.size;
        });
    }
    ngOnDestroy() {
        this._keyManager?.destroy();
        this._directDescendantItems.destroy();
        this.closed.complete();
        this._firstItemFocusSubscription?.unsubscribe();
    }
    addItem(_item) { }
    removeItem(_item) { }
    focusFirstItem(origin = 'program') {
        // Wait for `onStable` to ensure iOS VoiceOver screen reader focuses the first item (#24735).
        this._firstItemFocusSubscription?.unsubscribe();
        this._firstItemFocusSubscription = this._ngZone.onStable
            .pipe(take(1))
            .subscribe(() => {
            let dropDownPanel = null;
            if (this._directDescendantItems.length) {
                dropDownPanel = this._directDescendantItems
                    .first._getHostElement()
                    .closest('[role="drop-down"]');
            }
            if (!dropDownPanel || !dropDownPanel.contains(document.activeElement)) {
                const manager = this._keyManager;
                manager.setFocusOrigin(origin).setFirstItemActive();
                if (!manager.activeItem && dropDownPanel) {
                    dropDownPanel.focus();
                }
            }
        });
    }
    resetActiveItem() {
        this._keyManager.setActiveItem(-1);
    }
    setElevation(depth) {
        const elevation = Math.min(this._baseElevation + depth, 24);
        const newElevation = `${this._elevationPrefix}${elevation}`;
        const customElevation = Object.keys(this._classList).find((className) => {
            return className.startsWith(this._elevationPrefix);
        });
        if (!customElevation || customElevation === this._previousElevation) {
            if (this._previousElevation) {
                this._classList[this._previousElevation] = false;
            }
            this._classList[newElevation] = true;
            this._previousElevation = newElevation;
        }
    }
    setPositionClasses(start = this.positionStart, end = this.positionEnd) {
        const classes = this._classList;
        classes['cub-drop-down-before'] = start === 'before';
        classes['cub-drop-down-after'] = start === 'after';
        classes['cub-drop-down-above'] = start === 'above';
        classes['cub-drop-down-below'] = start === 'below';
        this._changeDetectorRef?.markForCheck();
    }
    _hovered() {
        const itemChanges = this._directDescendantItems.changes;
        return itemChanges.pipe(startWith(this._directDescendantItems), switchMap((items) => merge(...items.map((item) => item._hovered))));
    }
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        const manager = this._keyManager;
        switch (keyCode) {
            case ESCAPE:
                if (!hasModifierKey(event)) {
                    event.preventDefault();
                    this.closed.emit('keydown');
                }
                break;
            case LEFT_ARROW:
                if (this.parentDropDown && this.direction === 'ltr') {
                    this.closed.emit('keydown');
                }
                break;
            case RIGHT_ARROW:
                if (this.parentDropDown && this.direction === 'rtl') {
                    this.closed.emit('keydown');
                }
                break;
            case TAB:
                this.closed.emit('tab');
                break;
            default:
                if (keyCode === UP_ARROW || keyCode === DOWN_ARROW) {
                    manager.setFocusOrigin('keyboard');
                }
                manager.onKeydown(event);
                return;
        }
        event.stopPropagation();
    }
    _startAnimation() {
        this._panelAnimationState = 'enter';
    }
    _resetAnimation() {
        this._panelAnimationState = 'void';
    }
    _onAnimationDone(event) {
        this._animationDone.next(event);
        this._isAnimating = false;
    }
    _onAnimationStart(event) {
        this._isAnimating = true;
        if (event.toState === 'enter' && this._keyManager.activeItemIndex === 0) {
            event.element.scrollTop = 0;
        }
    }
    _updateDirectDescendants() {
        this._allItems.changes
            .pipe(startWith(this._allItems))
            .subscribe((items) => {
            this._directDescendantItems.reset(items.filter((item) => item._parentDropDown === this));
            this._directDescendantItems.notifyOnChanges();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDropDownBase, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: CUB_DROP_DOWN_DEFAULT_OPTIONS }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: _CubDropDownBase, isStandalone: true, selector: "cubDropDownBase", inputs: { size: "size", backdropClass: "backdropClass", prefixSpace: ["prefixSpace", "prefixSpace", booleanAttribute], ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], positionStart: "positionStart", positionEnd: "positionEnd", overlapTrigger: "overlapTrigger", hasBackdrop: "hasBackdrop", panelClass: ["class", "panelClass"] }, outputs: { closed: "closed" }, queries: [{ propertyName: "lazyContent", first: true, predicate: CUB_DROP_DOWN_CONTENT, descendants: true }, { propertyName: "items", predicate: CubDropDownItem }, { propertyName: "_allItems", predicate: CubDropDownItem, descendants: true }], viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDropDownBase, decorators: [{
            type: Directive,
            args: [{ selector: 'cubDropDownBase' }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DROP_DOWN_DEFAULT_OPTIONS]
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { size: [{
                type: Input
            }], backdropClass: [{
                type: Input
            }], prefixSpace: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], positionStart: [{
                type: Input
            }], positionEnd: [{
                type: Input
            }], overlapTrigger: [{
                type: Input
            }], hasBackdrop: [{
                type: Input
            }], panelClass: [{
                type: Input,
                args: ['class']
            }], closed: [{
                type: Output
            }], templateRef: [{
                type: ViewChild,
                args: [TemplateRef]
            }], items: [{
                type: ContentChildren,
                args: [CubDropDownItem, { descendants: false }]
            }], lazyContent: [{
                type: ContentChild,
                args: [CUB_DROP_DOWN_CONTENT]
            }], _allItems: [{
                type: ContentChildren,
                args: [CubDropDownItem, { descendants: true }]
            }] } });

class CubDropDown extends _CubDropDownBase {
    constructor(_elementRef, _ngZone, _defaultOptions, changeDetectorRef) {
        super(_elementRef, _ngZone, _defaultOptions, changeDetectorRef);
        this.changeDetectorRef = changeDetectorRef;
    }
    ngOnChanges(changes) {
        if (changes['size']) {
            this.changeDetectorRef.markForCheck();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDown, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: CUB_DROP_DOWN_DEFAULT_OPTIONS }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubDropDown, isStandalone: true, selector: "cub-drop-down", host: { properties: { "attr.aria-label": "null", "attr.aria-labelledby": "null", "attr.aria-describedby": "null" } }, providers: [{ provide: CUB_DROP_DOWN_PANEL, useExisting: CubDropDown }], exportAs: ["cubDropDown"], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<ng-template>\n  <div\n    tabindex=\"-1\"\n    role=\"drop-down\"\n    class=\"cub-drop-down-panel\"\n    [class.cub-drop-down-panel-small]=\"size === 'small'\"\n    [ngClass]=\"_classList\"\n    [id]=\"panelId\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [@transformDropDown]=\"_panelAnimationState\"\n    (@transformDropDown.start)=\"_onAnimationStart($event)\"\n    (@transformDropDown.done)=\"_onAnimationDone($event)\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"closed.emit('click')\"\n  >\n    <div class=\"cub-drop-down-content\">\n      <ng-content select=\"cub-drop-down-group\"></ng-content>\n    </div>\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], animations: [
            cubDropDownAnimations.transformDropDown,
            cubDropDownAnimations.fadeInItems,
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDown, decorators: [{
            type: Component,
            args: [{ selector: 'cub-drop-down', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, exportAs: 'cubDropDown', host: {
                        '[attr.aria-label]': 'null',
                        '[attr.aria-labelledby]': 'null',
                        '[attr.aria-describedby]': 'null',
                    }, animations: [
                        cubDropDownAnimations.transformDropDown,
                        cubDropDownAnimations.fadeInItems,
                    ], providers: [{ provide: CUB_DROP_DOWN_PANEL, useExisting: CubDropDown }], imports: [NgClass], template: "<ng-template>\n  <div\n    tabindex=\"-1\"\n    role=\"drop-down\"\n    class=\"cub-drop-down-panel\"\n    [class.cub-drop-down-panel-small]=\"size === 'small'\"\n    [ngClass]=\"_classList\"\n    [id]=\"panelId\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [@transformDropDown]=\"_panelAnimationState\"\n    (@transformDropDown.start)=\"_onAnimationStart($event)\"\n    (@transformDropDown.done)=\"_onAnimationDone($event)\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"closed.emit('click')\"\n  >\n    <div class=\"cub-drop-down-content\">\n      <ng-content select=\"cub-drop-down-group\"></ng-content>\n    </div>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DROP_DOWN_DEFAULT_OPTIONS]
                }] }, { type: i0.ChangeDetectorRef }] });

class CubDropDownItemHandle {
    /** Whether the action is disabled. */
    get disabled() {
        return this._disabled || this._parentItem?.disabled || false;
    }
    set disabled(value) {
        this._disabled = value;
    }
    constructor() {
        this._elementRef = inject(ElementRef);
        this._parentItem = inject(CUB_DROP_DOWN_ITEM);
        this._disabled = false;
        /** Tab index of the action. */
        this.tabIndex = -1;
        /**
         * Private API to allow focusing this drop-down when it is disabled.
         */
        this.allowFocusWhenDisabled = false;
    }
    focus() {
        this._elementRef.nativeElement.focus();
    }
    _handleClick(event) {
        if (!this.disabled) {
            event.preventDefault();
            this._parentItem._handlePrimaryActionInteraction(event);
        }
    }
    _handleKeydown(event) {
        if ((event.keyCode === ENTER || event.keyCode === SPACE) &&
            !this.disabled) {
            event.preventDefault();
            this._parentItem._handlePrimaryActionInteraction(event);
        }
    }
    /**
     * Determine the value of the disabled attribute for this drop-down action.
     */
    _getDisabledAttribute() {
        // When this drop-down action is disabled and focusing disabled drop-downs is not permitted, return empty
        // string to indicate that disabled attribute should be included.
        return this.disabled && !this.allowFocusWhenDisabled ? '' : null;
    }
    /**
     * Determine the value of the tabindex attribute for this drop-down action.
     */
    _getTabindex() {
        return this.disabled && !this.allowFocusWhenDisabled
            ? null
            : this.tabIndex.toString();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownItemHandle, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubDropDownItemHandle, isStandalone: true, selector: "[cubDropDownItemHandle]", inputs: { disabled: ["disabled", "disabled", booleanAttribute], tabIndex: ["tabIndex", "tabIndex", (value) => value == null ? -1 : numberAttribute(value)], allowFocusWhenDisabled: "allowFocusWhenDisabled" }, host: { listeners: { "click": "_handleClick($event)", "keydown": "_handleKeydown($event)" }, properties: { "attr.tabindex": "_getTabindex()", "attr.disabled": "_getDisabledAttribute()", "attr.aria-disabled": "disabled" }, classAttribute: "dropdown-item-handle" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownItemHandle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubDropDownItemHandle]',
                    host: {
                        class: 'dropdown-item-handle',
                        '[attr.tabindex]': '_getTabindex()',
                        '[attr.disabled]': '_getDisabledAttribute()',
                        '[attr.aria-disabled]': 'disabled',
                        '(click)': '_handleClick($event)',
                        '(keydown)': '_handleKeydown($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], tabIndex: [{
                type: Input,
                args: [{
                        transform: (value) => value == null ? -1 : numberAttribute(value),
                    }]
            }], allowFocusWhenDisabled: [{
                type: Input
            }] } });

class CubDropDownAction extends CubDropDownItem {
    constructor() {
        super(...arguments);
        /**
         * 當非同步請求完成時送出事件。
         */
        this.actionCompleted = new EventEmitter();
        /**
         * 當非同步請求失敗時送出事件。
         */
        this.actionFailed = new EventEmitter();
    }
    _handlePrimaryActionInteraction(event) {
        if (!this.disabled) {
            if (event instanceof KeyboardEvent) {
                this._handleKeydown(event);
            }
            if (event instanceof MouseEvent) {
                this._handleClick(event);
            }
        }
    }
    _handleClick(e) {
        if (this.action && this.action instanceof Observable && !this.loading) {
            this.asyncActionHandler(this.action);
            e.stopPropagation();
            e.preventDefault();
            return;
        }
        else {
            if (this.action && typeof this.action === 'function') {
                this.action();
            }
        }
    }
    _handleKeydown(e) {
        const keyCode = e.keyCode;
        if (keyCode === ENTER || keyCode === SPACE) {
            if (this._triggersSubDropDown) {
                this._handleMouseEnter();
                return;
            }
            else {
                if (this.action && this.action instanceof Observable && !this.loading) {
                    this.asyncActionHandler(this.action);
                }
                else {
                    if (this.action && typeof this.action === 'function') {
                        this.action();
                        this._parentDropDown.closed.emit('click');
                    }
                }
            }
            e.stopPropagation();
            e.preventDefault();
        }
    }
    asyncActionHandler(action) {
        this.loading = true;
        action.pipe(take$1(1)).subscribe({
            next: (result) => {
                this.loading = false;
                this.actionCompleted.emit(result);
            },
            error: (err) => {
                this.loading = false;
                this.actionFailed.emit(err);
            },
            complete: () => {
                this.loading = false;
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownAction, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubDropDownAction, isStandalone: true, selector: "[cub-drop-down-action]", inputs: { action: "action" }, outputs: { actionCompleted: "actionCompleted", actionFailed: "actionFailed" }, host: { listeners: { "mouseenter": "_handleMouseEnter()" }, properties: { "attr.role": "role", "attr.tabindex": "_getTabIndex()", "attr.aria-disabled": "disabled", "attr.disabled": "disabled || null" } }, providers: [
            {
                provide: CubDropDownItem,
                useExisting: CubDropDownAction,
            },
            { provide: CUB_DROP_DOWN_ITEM, useExisting: CubDropDownAction },
        ], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-drop-down-item-content\" cubDropDownItemHandle>\n  @if (prefixSpace) { @if (withPrefix) {\n  <span class=\"cub-drop-down-item-content-prefix\">\n    <ng-content select=\"[cubPrefix]\" #prefixIcon></ng-content>\n  </span>\n  } @else {\n  <span class=\"cub-icon-empty-space\"></span>\n  } }\n  <span class=\"cub-drop-down-item-content-text\">\n    {{ label }}\n  </span>\n  <span class=\"cub-drop-down-item-content-suffix\">\n    @if (loading) {\n    <div class=\"cub-loading-wrapper\">\n      <cub-loading [size]=\"size\"></cub-loading>\n    </div>\n    } @else if(_triggersSubDropDown) {\n    <span cubSuffix class=\"cub-icon-chevron-right\"></span>\n    }\n  </span>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-drop-down-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-drop-down-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "directive", type: CubDropDownItemHandle, selector: "[cubDropDownItemHandle]", inputs: ["disabled", "tabIndex", "allowFocusWhenDisabled"] }, { kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownAction, decorators: [{
            type: Component,
            args: [{ selector: '[cub-drop-down-action]', host: {
                        '[attr.role]': 'role',
                        '[attr.tabindex]': '_getTabIndex()',
                        '[attr.aria-disabled]': 'disabled',
                        '[attr.disabled]': 'disabled || null',
                        '(mouseenter)': '_handleMouseEnter()',
                    }, providers: [
                        {
                            provide: CubDropDownItem,
                            useExisting: CubDropDownAction,
                        },
                        { provide: CUB_DROP_DOWN_ITEM, useExisting: CubDropDownAction },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [CubDropDownItemHandle, CubLoading, CubRipple], template: "<span class=\"cub-drop-down-item-content\" cubDropDownItemHandle>\n  @if (prefixSpace) { @if (withPrefix) {\n  <span class=\"cub-drop-down-item-content-prefix\">\n    <ng-content select=\"[cubPrefix]\" #prefixIcon></ng-content>\n  </span>\n  } @else {\n  <span class=\"cub-icon-empty-space\"></span>\n  } }\n  <span class=\"cub-drop-down-item-content-text\">\n    {{ label }}\n  </span>\n  <span class=\"cub-drop-down-item-content-suffix\">\n    @if (loading) {\n    <div class=\"cub-loading-wrapper\">\n      <cub-loading [size]=\"size\"></cub-loading>\n    </div>\n    } @else if(_triggersSubDropDown) {\n    <span cubSuffix class=\"cub-icon-chevron-right\"></span>\n    }\n  </span>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-drop-down-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-drop-down-persistent-ripple\"></span>\n" }]
        }], propDecorators: { action: [{
                type: Input
            }], actionCompleted: [{
                type: Output
            }], actionFailed: [{
                type: Output
            }] } });

/** Event object emitted by MatDrop DownOption when selected or deselected. */
class CubDropDownOptionSelectionChange {
    constructor(
    /** Reference to the drop down that emitted the event. */
    source, 
    /** Whether the drop down that emitted the event is selected. */
    selected, 
    /** Whether the selection change was a result of a user interaction. */
    isUserInput = false) {
        this.source = source;
        this.selected = selected;
        this.isUserInput = isUserInput;
    }
}
class CubDropDownOption extends CubDropDownItem {
    constructor() {
        super(...arguments);
        this._selected = false;
        /**
         * 當選取狀態改變時，送出事件。
         */
        this.selectedChange = new EventEmitter();
        /**
         * 當元件選取狀態改變時送出事件。
         * */
        this.selectionChange = new EventEmitter();
    }
    /**
     * 元件是否被選取狀態，預設值為 false。
     */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._setSelectedState(value, false, true);
    }
    /** Selects the drop down. */
    select() {
        this._setSelectedState(true, false, true);
    }
    /** Deselects the drop down. */
    deselect() {
        this._setSelectedState(false, false, true);
    }
    /** Selects this drop down and emits userInputSelection event */
    selectViaInteraction() {
        this._setSelectedState(true, true, true);
    }
    /** Toggles the current selected state of this drop down. */
    toggleSelected(isUserInput = false, event) {
        this._setSelectedState(!this.selected, isUserInput, true);
    }
    _setSelectedState(isSelected, isUserInput, emitEvent) {
        // 單選模式下，不允許用戶取消勾選，但允許透過內部控制取消其他選項
        if (!this._dropDownItemsMultiple && isUserInput && this.selected && !isSelected) {
            return;
        }
        if (isSelected !== this.selected) {
            this._selected = isSelected;
            if (emitEvent) {
                this.selectionChange.emit({
                    source: this,
                    isUserInput,
                    selected: this.selected,
                });
            }
            this.selectedChange.emit(this.selected);
            this._changeDetectorRef.markForCheck();
        }
    }
    _handleKeydown(e) {
        const keyCode = e.keyCode;
        if (keyCode === ENTER$1 || keyCode === SPACE$1) {
            this._setSelectedState(!this.selected, true, true);
        }
    }
    _handleClick(e) {
        this._setSelectedState(!this.selected, true, true);
    }
    _handlePrimaryActionInteraction(event) {
        if (!this.disabled) {
            if (event instanceof KeyboardEvent) {
                event.stopPropagation();
                this._handleKeydown(event);
            }
            if (event instanceof MouseEvent) {
                event.stopPropagation();
                this._handleClick(event);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownOption, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubDropDownOption, isStandalone: true, selector: "[cub-drop-down-option]", inputs: { selected: ["selected", "selected", booleanAttribute] }, outputs: { selectedChange: "selectedChange", selectionChange: "selectionChange" }, host: { properties: { "class.cub-selected": "_selected", "attr.role": "role", "attr.tabindex": "_getTabIndex()", "attr.aria-disabled": "disabled", "attr.disabled": "disabled || null" } }, providers: [
            {
                provide: CubDropDownItem,
                useExisting: CubDropDownOption,
            },
            { provide: CUB_DROP_DOWN_ITEM, useExisting: CubDropDownOption },
        ], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-drop-down-item-content\" cubDropDownItemHandle>\n  @if (prefixSpace) { @if (selected) {\n  <span class=\"cub-drop-down-item-content-prefix\">\n    <span class=\"cub-icon-check\"></span>\n  </span>\n  } @else {\n  <span class=\"cub-icon-empty-space\"></span>\n  } }\n  <span class=\"cub-drop-down-item-content-text\">\n    {{ label }}\n  </span>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-drop-down-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-drop-down-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "directive", type: CubDropDownItemHandle, selector: "[cubDropDownItemHandle]", inputs: ["disabled", "tabIndex", "allowFocusWhenDisabled"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownOption, decorators: [{
            type: Component,
            args: [{ selector: '[cub-drop-down-option]', host: {
                        '[class.cub-selected]': '_selected',
                        '[attr.role]': 'role',
                        '[attr.tabindex]': '_getTabIndex()',
                        '[attr.aria-disabled]': 'disabled',
                        '[attr.disabled]': 'disabled || null',
                    }, providers: [
                        {
                            provide: CubDropDownItem,
                            useExisting: CubDropDownOption,
                        },
                        { provide: CUB_DROP_DOWN_ITEM, useExisting: CubDropDownOption },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [CubDropDownItemHandle, CubRipple], template: "<span class=\"cub-drop-down-item-content\" cubDropDownItemHandle>\n  @if (prefixSpace) { @if (selected) {\n  <span class=\"cub-drop-down-item-content-prefix\">\n    <span class=\"cub-icon-check\"></span>\n  </span>\n  } @else {\n  <span class=\"cub-icon-empty-space\"></span>\n  } }\n  <span class=\"cub-drop-down-item-content-text\">\n    {{ label }}\n  </span>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-drop-down-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-drop-down-persistent-ripple\"></span>\n" }]
        }], propDecorators: { selected: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], selectedChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }] } });

/** Change event object that is emitted when the drop down listbox value has changed. */
class CubDropDownOptionGroupChange {
    constructor(
    /** Drop Down listbox that emitted the event. */
    source, 
    /** Value of the drop down listbox when the event was emitted. */
    value) {
        this.source = source;
        this.value = value;
    }
}
const CUB_DROP_DOWN_GROUP = new InjectionToken('CUB_DROP_DOWN_GROUP');
class CubDropDownGroup {
    constructor() {
        this._changeDetectorRef = inject(ChangeDetectorRef);
        this._selectable = true;
        /** Subject that emits when the component has been destroyed. */
        this._destroyed = new Subject();
        this._multiple = false;
        /*
         * 無資料時的顯示文字，預設值為 '無資料'。
         */
        this.emptyMessage = '無資料';
        /*
         * 用於設定 drop down group 的 標題， 預設值為 ''。
         */
        this.label = '';
        /**
         * 件比較選項值和選定值的函式，第一個參數是選項中的值，第二個參數是選定的值，並且需要回傳一個布林值，預設為 (o1: any, o2: any) => o1 === o2。
         */
        this.compareWith = (o1, o2) => o1 === o2;
        /**
         * 當狀態改變時送出事件。
         */
        this.change = new EventEmitter();
    }
    get hasItems() {
        return this.allItems.length > 0;
    }
    /** Combined stream of all of the child drop downs' selection change events. */
    get dropDownOptionSelectionChanges() {
        return this._getDropDownItemStream((item) => item.selectionChange);
    }
    /** The array of selected drop downs inside the drop down listbox. */
    get selected() {
        const selectedOptions = this.optionItems.toArray().filter((item) => item.selected);
        return this.multiple ? selectedOptions : selectedOptions[0];
    }
    /**
     * 是否開放多選，預設值為 false。
     */
    get multiple() {
        return this._multiple;
    }
    set multiple(value) {
        this._multiple = value;
        this._syncOptionProperties();
    }
    /**
     * 元件是否能被選取，預設值為 true。
     */
    get selectable() {
        return this._selectable;
    }
    set selectable(value) {
        this._selectable = value;
        this._syncOptionProperties();
    }
    /**
     * 元件的 value ，主要用於紀錄底下被選取的 option 的值，預設值為 undefined。
     */
    get value() {
        return this._value;
    }
    set value(value) {
        if (this.optionItems && this.optionItems.length) {
            this._setSelectionByValue(value, false);
        }
        this._value = value;
    }
    ngAfterViewInit() {
        // 初始化時同步所有選項的屬性
        this._syncOptionProperties();
        this.dropDownOptionSelectionChanges
            .pipe(takeUntil(this._destroyed))
            .subscribe((event) => {
            if (event === undefined) {
                return;
            }
            if (!this.multiple) {
                this.optionItems.forEach((item) => {
                    if (item !== event.source) {
                        item._setSelectedState(false, false, false);
                    }
                });
            }
            if (event.isUserInput) {
                this._propagateChanges();
            }
        });
        // 監聽選項變化，當選項數量變更時觸發變更檢測
        this.optionItems.changes.pipe(takeUntil(this._destroyed)).subscribe(() => {
            this._syncOptionProperties();
            this._changeDetectorRef.markForCheck();
        });
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    /** Selects all drop downs with value. */
    _setSelectionByValue(value, isUserInput = true) {
        this._clearSelection();
        if (Array.isArray(value)) {
            value.forEach((currentValue) => this._selectValue(currentValue, isUserInput));
        }
        else {
            this._selectValue(value, isUserInput);
        }
    }
    /**
     * Gets a stream of events from all the drop downs within the set.
     * The stream will automatically incorporate any newly-added drop downs.
     */
    _getDropDownItemStream(mappingFunction) {
        return this.optionItems.changes.pipe(startWith$1(null), switchMap$1(() => merge(...this.optionItems.map(mappingFunction))));
    }
    /** Emits change event to set the model value. */
    _propagateChanges() {
        let valueToEmit = null;
        if (Array.isArray(this.selected)) {
            valueToEmit = this.selected.map((item) => item.value);
        }
        else {
            valueToEmit = this.selected ? this.selected.value : undefined;
        }
        this._value = valueToEmit;
        this.change.emit(new CubDropDownOptionGroupChange(this, valueToEmit));
        this._changeDetectorRef.markForCheck();
    }
    /**
     * Finds and selects the drop down based on its value.
     * @returns Drop Down that has the corresponding value.
     */
    _selectValue(value, isUserInput) {
        const correspondingOption = this.optionItems.find((item) => {
            return item.value != null && this.compareWith(item.value, value);
        });
        if (correspondingOption) {
            isUserInput
                ? correspondingOption.selectViaInteraction()
                : correspondingOption.select();
        }
        return correspondingOption;
    }
    /**
     * Deselects every drop down in the listbox.
     * @param skip Drop Down that should not be deselected.
     */
    _clearSelection(skip) {
        this.optionItems.forEach((item) => {
            if (item !== skip) {
                item.deselect();
            }
        });
    }
    _syncOptionProperties() {
        if (this.optionItems) {
            // Defer setting the value in order to avoid the "Expression
            // has changed after it was checked" errors from Angular.
            Promise.resolve().then(() => {
                this.optionItems.forEach((item) => {
                    item._dropDownItemsMultiple = this.multiple;
                    item._dropDownItemsSelectable = this._selectable;
                    item._changeDetectorRef.markForCheck();
                });
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubDropDownGroup, isStandalone: true, selector: "cub-drop-down-group", inputs: { emptyMessage: "emptyMessage", label: "label", multiple: ["multiple", "multiple", booleanAttribute], selectable: ["selectable", "selectable", booleanAttribute], value: "value", compareWith: "compareWith" }, outputs: { change: "change" }, host: { classAttribute: "cub-drop-down-group" }, providers: [
            {
                provide: CUB_DROP_DOWN_GROUP,
                useExisting: CubDropDownGroup,
            },
        ], queries: [{ propertyName: "optionItems", predicate: CubDropDownOption, descendants: true }, { propertyName: "allItems", predicate: CubDropDownItem, descendants: true }], ngImport: i0, template: "<div>\n  @if (label) {\n  <div class=\"cub-drop-down-group-container\">\n    <span class=\"cub-drop-down-group-label\">{{ label }}</span>\n  </div>\n  } @if (hasItems) {\n  <ng-content\n    select=\"[cub-drop-down-option], [cub-drop-down-action]\"\n  ></ng-content>\n  } @else {\n  <div class=\"cub-drop-down-group-container\">\n    <span class=\"cub-drop-down-group-no-data\">{{ emptyMessage }}</span>\n  </div>\n  }\n\n  <cub-divider></cub-divider>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubDivider, selector: "[cubDivider], cub-divider", inputs: ["appearance", "orientation"], exportAs: ["cubDivider"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-drop-down-group', providers: [
                        {
                            provide: CUB_DROP_DOWN_GROUP,
                            useExisting: CubDropDownGroup,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-drop-down-group',
                    }, imports: [CubDivider], template: "<div>\n  @if (label) {\n  <div class=\"cub-drop-down-group-container\">\n    <span class=\"cub-drop-down-group-label\">{{ label }}</span>\n  </div>\n  } @if (hasItems) {\n  <ng-content\n    select=\"[cub-drop-down-option], [cub-drop-down-action]\"\n  ></ng-content>\n  } @else {\n  <div class=\"cub-drop-down-group-container\">\n    <span class=\"cub-drop-down-group-no-data\">{{ emptyMessage }}</span>\n  </div>\n  }\n\n  <cub-divider></cub-divider>\n</div>\n" }]
        }], propDecorators: { emptyMessage: [{
                type: Input
            }], label: [{
                type: Input
            }], multiple: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], selectable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], value: [{
                type: Input
            }], compareWith: [{
                type: Input
            }], change: [{
                type: Output
            }], optionItems: [{
                type: ContentChildren,
                args: [CubDropDownOption, { descendants: true }]
            }], allItems: [{
                type: ContentChildren,
                args: [CubDropDownItem, { descendants: true }]
            }] } });

const passiveEventListenerOptions = normalizePassiveListenerOptions({
    passive: true,
});
class _CubDropDownTriggerBase {
    get dropDownOpen() {
        return this._dropDownOpen;
    }
    get dir() {
        return this._dir && this._dir.value === 'rtl' ? 'rtl' : 'ltr';
    }
    /**
     * 欲於綁定開啟 dropDown 的元件，預設值為 undefined。
     */
    get dropDown() {
        return this._dropDown;
    }
    set dropDown(dropDown) {
        if (dropDown === this._dropDown) {
            return;
        }
        this._dropDown = dropDown;
        this._dropDownCloseSubscription.unsubscribe();
        if (dropDown) {
            if (dropDown === this._parentMaterialDropDown) {
                throwDropDownRecursiveError();
            }
            this._dropDownCloseSubscription = dropDown.closed.subscribe((reason) => {
                this._destroyDropDown(reason);
                if ((reason === 'click' || reason === 'tab') &&
                    this._parentMaterialDropDown) {
                    this._parentMaterialDropDown.closed.emit(reason);
                }
            });
        }
        this._dropDownItemInstance?._setTriggersSubdropDown(this.triggersSubdropDown());
    }
    constructor(_overlay, _element, _viewContainerRef, scrollStrategy, parentDropDown, _dropDownItemInstance, _dir, _focusMonitor, _ngZone) {
        this._overlay = _overlay;
        this._element = _element;
        this._viewContainerRef = _viewContainerRef;
        this._dropDownItemInstance = _dropDownItemInstance;
        this._dir = _dir;
        this._focusMonitor = _focusMonitor;
        this._ngZone = _ngZone;
        this._openedBy = undefined;
        this._overlayRef = null;
        this._dropDownOpen = false;
        this._closingActionsSubscription = Subscription.EMPTY;
        this._hoverSubscription = Subscription.EMPTY;
        this._dropDownCloseSubscription = Subscription.EMPTY;
        this._outsideClickSubscription = null;
        this._onDestroy = new Subject();
        /**
         * dropDown 關閉時是否應恢復焦點，預設值為 true。
         */
        this.restoreFocus = true;
        /**
         * dropDown 打開時送出的事件。
         */
        this.dropDownOpened = new EventEmitter();
        /**
         * dropDown 關閉時送出的事件。
         */
        this.dropDownClosed = new EventEmitter();
        this._handleTouchStart = (event) => {
            if (!isFakeTouchstartFromScreenReader(event)) {
                this._openedBy = 'touch';
            }
        };
        this._scrollStrategy = scrollStrategy;
        this._parentMaterialDropDown =
            parentDropDown instanceof _CubDropDownBase ? parentDropDown : undefined;
        _element.nativeElement.addEventListener('touchstart', this._handleTouchStart, passiveEventListenerOptions);
    }
    ngAfterContentInit() {
        this._handleHover();
    }
    ngOnDestroy() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef = null;
        }
        this._element.nativeElement.removeEventListener('touchstart', this._handleTouchStart, passiveEventListenerOptions);
        this._onDestroy.next();
        this._onDestroy.complete();
        if (this._outsideClickSubscription) {
            this._outsideClickSubscription.unsubscribe();
            this._outsideClickSubscription = null;
        }
        this._dropDownCloseSubscription.unsubscribe();
        this._closingActionsSubscription.unsubscribe();
        this._hoverSubscription.unsubscribe();
    }
    triggersSubdropDown() {
        return !!(this._dropDownItemInstance &&
            this._parentMaterialDropDown &&
            this.dropDown);
    }
    toggleDropDown() {
        return this._dropDownOpen ? this.closeDropDown() : this.openDropDown();
    }
    openDropDown() {
        const dropDown = this.dropDown;
        if (this._dropDownOpen || !dropDown) {
            return;
        }
        const overlayRef = this._createOverlay(dropDown);
        const overlayConfig = overlayRef.getConfig();
        const positionStrategy = overlayConfig.positionStrategy;
        this._setPosition(dropDown, positionStrategy);
        overlayConfig.hasBackdrop =
            dropDown.hasBackdrop == null
                ? !this.triggersSubdropDown()
                : dropDown.hasBackdrop;
        overlayRef.attach(this._getPortal(dropDown));
        if (dropDown.lazyContent) {
            dropDown.lazyContent.attach(this.dropDownData);
        }
        this._closingActionsSubscription = this._dropDownClosingActions().subscribe(() => {
            this.closeDropDown();
        });
        this._initDropDown(dropDown);
        if (dropDown instanceof _CubDropDownBase) {
            dropDown._startAnimation();
            dropDown._directDescendantItems.changes
                .pipe(takeUntil(dropDown.closed))
                .subscribe(() => {
                positionStrategy.withLockedPosition(false).reapplyLastPosition();
                positionStrategy.withLockedPosition(true);
            });
        }
    }
    closeDropDown() {
        this.dropDown?.closed.emit();
    }
    focus(origin, options) {
        if (this._focusMonitor && origin) {
            this._focusMonitor.focusVia(this._element, origin, options);
        }
        else {
            this._element.nativeElement.focus(options);
        }
    }
    updatePosition() {
        this._overlayRef?.updatePosition();
    }
    _handleMousedown(event) {
        if (!isFakeMousedownFromScreenReader(event)) {
            this._openedBy = event.button === 0 ? 'mouse' : undefined;
            if (this.triggersSubdropDown()) {
                event.preventDefault();
            }
        }
    }
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        if (keyCode === ENTER || keyCode === SPACE) {
            this._openedBy = 'keyboard';
        }
        if (this.triggersSubdropDown() &&
            ((keyCode === RIGHT_ARROW$1 && this.dir === 'ltr') ||
                (keyCode === LEFT_ARROW$1 && this.dir === 'rtl'))) {
            this._openedBy = 'keyboard';
            this.openDropDown();
        }
    }
    _handleClick(event) {
        if (this.triggersSubdropDown()) {
            event.stopPropagation();
            this.openDropDown();
        }
        else {
            this.toggleDropDown();
        }
    }
    _destroyDropDown(reason) {
        if (!this._overlayRef || !this.dropDownOpen) {
            return;
        }
        const dropDown = this.dropDown;
        this._closingActionsSubscription.unsubscribe();
        this._overlayRef.detach();
        if (this.restoreFocus &&
            (reason === 'keydown' || !this._openedBy || !this.triggersSubdropDown())) {
            this.focus(this._openedBy);
        }
        this._openedBy = undefined;
        if (dropDown instanceof _CubDropDownBase) {
            dropDown._resetAnimation();
            if (dropDown.lazyContent) {
                dropDown._animationDone
                    .pipe(filter((event) => event.toState === 'void'), take$1(1), 
                // Interrupt if the content got re-attached.
                takeUntil(dropDown.lazyContent._attached))
                    .subscribe({
                    next: () => dropDown.lazyContent.detach(),
                    complete: () => this._setIsDropDownOpen(false),
                });
            }
            else {
                this._setIsDropDownOpen(false);
            }
        }
        else {
            this._setIsDropDownOpen(false);
            dropDown?.lazyContent?.detach();
        }
    }
    _initDropDown(dropDown) {
        dropDown.parentDropDown = this.triggersSubdropDown()
            ? this._parentMaterialDropDown
            : undefined;
        dropDown.direction = this.dir;
        this._setDropDownElevation(dropDown);
        dropDown.size = dropDown.parentDropDown
            ? this._dropDownItemInstance?.size
            : dropDown.size;
        if (dropDown._allItems && dropDown.size) {
            dropDown._allItems.forEach((item) => {
                item.size = dropDown.size;
            });
        }
        dropDown.focusFirstItem(this._openedBy || 'program');
        this._setIsDropDownOpen(true);
    }
    _setDropDownElevation(dropDown) {
        if (dropDown.setElevation) {
            let depth = 0;
            let parentDropDown = dropDown.parentDropDown;
            while (parentDropDown) {
                depth++;
                parentDropDown = parentDropDown.parentDropDown;
            }
            dropDown.setElevation(depth);
        }
    }
    _setIsDropDownOpen(isOpen) {
        this._dropDownOpen = isOpen;
        this._dropDownOpen
            ? this.dropDownOpened.emit()
            : this.dropDownClosed.emit();
        if (this.triggersSubdropDown()) {
            this._dropDownItemInstance._setHighlighted(isOpen);
        }
    }
    _createOverlay(dropDown) {
        if (!this._overlayRef) {
            const config = this._getOverlayConfig(dropDown);
            this._subscribeToPositions(dropDown, config.positionStrategy);
            this._overlayRef = this._overlay.create(config);
            this._overlayRef.keydownEvents().subscribe();
            if (dropDown && !dropDown.hasBackdrop) {
                this._outsideClickSubscription = this._overlayRef
                    .outsidePointerEvents()
                    .pipe(takeUntil(this._onDestroy)) // Ensure unsubscription on component destroy
                    .subscribe((event) => {
                    if (event.target instanceof HTMLElement) {
                        let element = event.target;
                        while (element) {
                            // 排除當前觸發器
                            if (element === this._element.nativeElement) {
                                return;
                            }
                            // 排除帶有 cubDropDownTriggerFor 的 cub-drop-down-item（巢狀子選單）
                            if (element.hasAttribute('cub-drop-down-item') &&
                                element.hasAttribute('cubdropdowntriggerfor')) {
                                return;
                            }
                            if (element.classList.contains('cdk-overlay-container')) {
                                break;
                            }
                            element = element.parentElement;
                        }
                    }
                    this.closeDropDown(); // Call the menu's close method
                });
            }
        }
        return this._overlayRef;
    }
    _getOverlayConfig(dropDown) {
        return new OverlayConfig({
            positionStrategy: this._overlay
                .position()
                .flexibleConnectedTo(this._element)
                .withLockedPosition()
                .withGrowAfterOpen()
                .withTransformOriginOn('.cub-dropDown-panel, .cub-dropDown-panel'),
            backdropClass: dropDown.backdropClass || 'cub-cdk-overlay-transparent-backdrop',
            panelClass: dropDown.overlayPanelClass,
            scrollStrategy: this._scrollStrategy(),
            direction: this._dir,
        });
    }
    _subscribeToPositions(dropDown, position) {
        if (dropDown.setPositionClasses) {
            position.positionChanges.subscribe((change) => {
                const positionStart = change.connectionPair.overlayX === 'start' ? 'after' : 'before';
                const positionEnd = change.connectionPair.overlayY === 'top' ? 'below' : 'above';
                if (this._ngZone) {
                    this._ngZone.run(() => dropDown.setPositionClasses(positionStart, positionEnd));
                }
                else {
                    dropDown.setPositionClasses(positionStart, positionEnd);
                }
            });
        }
    }
    _setPosition(dropDown, positionStrategy) {
        /* 根據 positionStart 設定位置 originX 和 originFallbackX。
         originx 為 原點元素 上的水平連接點 fallback 為備用位置
        'start' 通常指左邊緣（或在 RTL 模式下指右邊緣）。
        'center' 指水平中點。
        'end' 通常指右邊緣（或在 RTL 模式下指左邊緣）。
        originY: 指定 原點元素 上的垂直連接點。
        'top' 指最上邊緣。
        'center' 指垂直中點。
        'bottom' 指最下邊緣。
        overlayX: 指定 彈出層 自身的水平連接點。
        參數與 originX 相同，但應用於彈出層。
        overlayY: 指定 彈出層 自身的垂直連接點。
        參數與 originY 相同，但應用於彈出層。
        */
        let originX = dropDown.positionStart === 'before' || dropDown.positionEnd === 'before'
            ? 'start'
            : dropDown.positionStart === 'after' || dropDown.positionEnd === 'after'
                ? 'end'
                : 'start';
        let originY = dropDown.positionStart === 'above' || dropDown.positionEnd === 'above'
            ? 'top'
            : dropDown.positionStart === 'below' || dropDown.positionEnd === 'below'
                ? 'bottom'
                : 'top';
        let [overlayX, overlayFallbackX] = dropDown.positionStart === 'below' || dropDown.positionStart === 'above'
            ? [originX, originX]
            : dropDown.positionStart === 'before'
                ? ['end', 'start']
                : ['start', 'end'];
        let [overlayY, overlayFallbackY] = dropDown.positionStart === 'before' || dropDown.positionStart === 'after'
            ? [originY, originY]
            : dropDown.positionStart === 'below'
                ? ['top', 'bottom']
                : ['bottom', 'top'];
        let originFallbackX = overlayX;
        let originFallbackY = overlayY;
        let offsetY = 0;
        if (this.triggersSubdropDown()) {
            overlayFallbackX = originX =
                dropDown.positionStart === 'before' ? 'start' : 'end';
            originFallbackX = overlayX = originX === 'end' ? 'start' : 'end';
            originY = overlayY === 'top' ? 'top' : 'bottom';
            originFallbackY = overlayFallbackY === 'top' ? 'top' : 'bottom';
            if (this._parentMaterialDropDown) {
                if (this._parentInnerPadding == null) {
                    const firstItem = this._parentMaterialDropDown.items.first;
                    this._parentInnerPadding = firstItem
                        ? firstItem._getHostElement().offsetTop
                        : 0;
                }
                offsetY =
                    overlayY === 'bottom'
                        ? this._parentInnerPadding
                        : -this._parentInnerPadding;
            }
        }
        else if (!dropDown.overlapTrigger) {
            if (dropDown.positionStart !== 'before' &&
                dropDown.positionStart !== 'after') {
                originY = overlayY === 'top' ? 'bottom' : 'top';
                originFallbackY = overlayFallbackY === 'top' ? 'bottom' : 'top';
            }
            else {
                originY = overlayY;
                originFallbackY = overlayFallbackY;
            }
        }
        positionStrategy.withPositions([
            { originX, originY, overlayX, overlayY, offsetY },
            {
                originX: originFallbackX,
                originY,
                overlayX: overlayFallbackX,
                overlayY,
                offsetY,
            },
            {
                originX,
                originY: originFallbackY,
                overlayX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
            {
                originX: originFallbackX,
                originY: originFallbackY,
                overlayX: overlayFallbackX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
        ]);
    }
    _dropDownClosingActions() {
        const backdrop = this._overlayRef.backdropClick();
        const detachments = this._overlayRef.detachments();
        const parentClose = this._parentMaterialDropDown
            ? this._parentMaterialDropDown.closed
            : of();
        const hover = this._parentMaterialDropDown
            ? this._parentMaterialDropDown._hovered().pipe(filter((active) => active !== this._dropDownItemInstance), filter(() => this._dropDownOpen))
            : of();
        return merge(backdrop, parentClose, hover, detachments);
    }
    _handleHover() {
        if (!this.triggersSubdropDown() || !this._parentMaterialDropDown) {
            return;
        }
        this._hoverSubscription = this._parentMaterialDropDown
            ._hovered()
            .pipe(filter((active) => active === this._dropDownItemInstance && !active.disabled), delay(0, asapScheduler))
            .subscribe(() => {
            this._openedBy = 'mouse';
            if (this.dropDown instanceof _CubDropDownBase &&
                this.dropDown._isAnimating) {
                this.dropDown._animationDone
                    .pipe(take$1(1), delay(0, asapScheduler), takeUntil(this._parentMaterialDropDown._hovered()))
                    .subscribe(() => this.openDropDown());
            }
            else {
                this.openDropDown();
            }
        });
    }
    _getPortal(dropDown) {
        if (!this._portal || this._portal.templateRef !== dropDown.templateRef) {
            this._portal = new TemplatePortal(dropDown.templateRef, this._viewContainerRef);
        }
        return this._portal;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDropDownTriggerBase, deps: [{ token: i1.Overlay }, { token: i0.ElementRef }, { token: i0.ViewContainerRef }, { token: CUB_DROP_DOWN_SCROLL_STRATEGY }, { token: CUB_DROP_DOWN_PANEL, optional: true }, { token: CubDropDownItem, optional: true, self: true }, { token: i1.Directionality, optional: true }, { token: i1.FocusMonitor }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubDropDownTriggerBase, isStandalone: true, inputs: { dropDown: ["cubDropDownTriggerFor", "dropDown"], dropDownData: ["cubDropDownTriggerData", "dropDownData"], restoreFocus: ["cubDropDownTriggerRestoreFocus", "restoreFocus"] }, outputs: { dropDownOpened: "dropDownOpened", dropDownClosed: "dropDownClosed" }, host: { listeners: { "click": "_handleClick($event)", "mousedown": "_handleMousedown($event)", "keydown": "_handleKeydown($event)" }, properties: { "attr.aria-haspopup": "dropDown ? \"dropDown\" : null", "attr.aria-expanded": "dropDownOpen || null", "attr.aria-controls": "dropDownOpen ? dropDown.panelId : null" }, classAttribute: "cub-drop-down-trigger" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubDropDownTriggerBase, decorators: [{
            type: Directive,
            args: [{
                    host: {
                        class: 'cub-drop-down-trigger',
                        '[attr.aria-haspopup]': 'dropDown ? "dropDown" : null',
                        '[attr.aria-expanded]': 'dropDownOpen || null',
                        '[attr.aria-controls]': 'dropDownOpen ? dropDown.panelId : null',
                        '(click)': '_handleClick($event)',
                        '(mousedown)': '_handleMousedown($event)',
                        '(keydown)': '_handleKeydown($event)',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.ElementRef }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DROP_DOWN_SCROLL_STRATEGY]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_DROP_DOWN_PANEL]
                }, {
                    type: Optional
                }] }, { type: CubDropDownItem, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i1.FocusMonitor }, { type: i0.NgZone }], propDecorators: { dropDown: [{
                type: Input,
                args: ['cubDropDownTriggerFor']
            }], dropDownData: [{
                type: Input,
                args: ['cubDropDownTriggerData']
            }], restoreFocus: [{
                type: Input,
                args: ['cubDropDownTriggerRestoreFocus']
            }], dropDownOpened: [{
                type: Output
            }], dropDownClosed: [{
                type: Output
            }] } });

class CubDropDownTrigger extends _CubDropDownTriggerBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownTrigger, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDropDownTrigger, isStandalone: true, selector: "[cubDropDownTriggerFor]", host: { classAttribute: "cub-drop-down-trigger" }, exportAs: ["cubDropDownTrigger"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: `[cubDropDownTriggerFor]`,
                    host: {
                        class: 'cub-drop-down-trigger',
                    },
                    exportAs: 'cubDropDownTrigger'
                }]
        }] });

const DECLAR_COMPONENTS = [
    _CubDropDownBase,
    CubDropDown,
    CubDropDownTrigger,
    _CubDropDownTriggerBase,
    CubDropDownContent,
    _CubDropDownContentBase,
    CubDropDownAction,
    CubDropDownOption,
    CubDropDownItem,
    CubDropDownGroup,
    CubDropDownItemHandle,
];
class CubDropDownModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownModule, imports: [_CubDropDownBase,
            CubDropDown,
            CubDropDownTrigger,
            _CubDropDownTriggerBase,
            CubDropDownContent,
            _CubDropDownContentBase,
            CubDropDownAction,
            CubDropDownOption,
            CubDropDownItem,
            CubDropDownGroup,
            CubDropDownItemHandle], exports: [_CubDropDownBase,
            CubDropDown,
            CubDropDownTrigger,
            _CubDropDownTriggerBase,
            CubDropDownContent,
            _CubDropDownContentBase,
            CubDropDownAction,
            CubDropDownOption,
            CubDropDownItem,
            CubDropDownGroup,
            CubDropDownItemHandle] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubDropDownAction] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDropDownModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [DECLAR_COMPONENTS],
                    exports: [DECLAR_COMPONENTS],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/drop-down
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_DROP_DOWN_CONTENT, CUB_DROP_DOWN_DEFAULT_OPTIONS, CUB_DROP_DOWN_DEFAULT_OPTIONS_FACTORY, CUB_DROP_DOWN_GROUP, CUB_DROP_DOWN_ITEM, CUB_DROP_DOWN_ITEM_HANDLE, CUB_DROP_DOWN_PANEL, CUB_DROP_DOWN_SCROLL_STRATEGY, CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY, CUB_DROP_DOWN_SCROLL_STRATEGY_FACTORY_PROVIDER, CubDropDown, CubDropDownAction, CubDropDownContent, CubDropDownGroup, CubDropDownItem, CubDropDownItemHandle, CubDropDownModule, CubDropDownOption, CubDropDownOptionGroupChange, CubDropDownOptionSelectionChange, CubDropDownTrigger, _CubDropDownBase, _CubDropDownContentBase, _CubDropDownTriggerBase, cubDropDownAnimations, throwDropDownInvalidPositionX, throwDropDownInvalidPositionY, throwDropDownRecursiveError };
//# sourceMappingURL=cub-lib-view-rootng-component-drop-down.mjs.map
