import * as i0 from '@angular/core';
import { Directive, Input, Component, InjectionToken, Attribute, ContentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, NgModule } from '@angular/core';
import { NgSwitch, NgSwitchCase, NgIf } from '@angular/common';
import { Subject } from 'rxjs';
import { startWith, takeUntil } from 'rxjs/operators';
import { CubLabel, CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { trigger, state, transition, style, animate } from '@angular/animations';
import { CubCommonModule } from 'cub-lib-view-rootng/component/common';

class CubFormFieldControl {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormFieldControl, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubFormFieldControl, isStandalone: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormFieldControl, decorators: [{
            type: Directive
        }] });

class CubMessageIcon {
    constructor() {
        /**
         元件狀態，預設為 'neutral'。
         */
        this.status = 'neutral';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMessageIcon, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubMessageIcon, isStandalone: true, selector: "cub-message-icon", inputs: { status: "status" }, host: { classAttribute: "cub-message-icon" }, ngImport: i0, template: "<ng-container [ngSwitch]=\"status\">\n  <ng-container *ngSwitchCase=\"'success'\">\n    <span class=\"cub-icon-check-circle\"></span>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'error'\">\n    <span class=\"cub-icon-x-circle\"></span>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'neutral'\">\n    <span class=\"cub-icon-info-circle\"></span>\n  </ng-container>\n</ng-container>\n", styles: [""], dependencies: [{ kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMessageIcon, decorators: [{
            type: Component,
            args: [{ selector: 'cub-message-icon', host: {
                        class: 'cub-message-icon',
                    }, imports: [NgSwitch, NgSwitchCase], template: "<ng-container [ngSwitch]=\"status\">\n  <ng-container *ngSwitchCase=\"'success'\">\n    <span class=\"cub-icon-check-circle\"></span>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'error'\">\n    <span class=\"cub-icon-x-circle\"></span>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'neutral'\">\n    <span class=\"cub-icon-info-circle\"></span>\n  </ng-container>\n</ng-container>\n" }]
        }], propDecorators: { status: [{
                type: Input
            }] } });

let nextUniqueId$3 = 0;
const CUB_HINT = new InjectionToken('CubHint');
class CubHint {
    /**
     元件狀態，預設為 'neutral'。
     */
    get status() {
        return this._status;
    }
    set status(value) {
        this._status = value;
        setTimeout(() => {
            this._setMessageIcon();
        }, 0);
    }
    constructor(elementRef, renderer, viewContainerRef) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.viewContainerRef = viewContainerRef;
        this._status = 'neutral';
        /**
         元件 id，預設為 'cub-form-field-hint-0'。
         */
        this.id = `cub-form-field-hint-${nextUniqueId$3++}`;
    }
    ngAfterViewInit() {
        setTimeout(() => {
            this._setMessageIcon();
        }, 0);
    }
    // TODO 待優化 Hint、Success、Error 共用部分
    _setMessageIcon() {
        if (!this.parentContainer) {
            // 創建一個父層容器
            this.parentContainer = this.renderer.createElement('div');
            this.renderer.addClass(this.parentContainer, 'cub-hint-container');
            const parentNode = this.elementRef.nativeElement.parentNode;
            this.renderer.insertBefore(parentNode, this.parentContainer, this.elementRef.nativeElement);
        }
        if (this.status === 'custom') {
            if (this.cubMessageIcon) {
                this.renderer.removeChild(this.parentContainer, this.cubMessageIcon.location.nativeElement);
                this.cubMessageIcon = null;
            }
        }
        else {
            if (!this.cubMessageIcon) {
                // 創建 cubMessageIcon component
                this.cubMessageIcon =
                    this.viewContainerRef.createComponent(CubMessageIcon);
                // 初始化 cubMessageIcon 屬性
                this.cubMessageIcon.instance.status = this.status;
                // 將 icon 移到父層容器
                this.renderer.appendChild(this.parentContainer, this.cubMessageIcon.location.nativeElement);
            }
        }
        // 將 hint 移到父層容器
        this.renderer.appendChild(this.parentContainer, this.elementRef.nativeElement);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubHint, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubHint, isStandalone: true, selector: "cub-hint", inputs: { id: "id", status: "status" }, host: { properties: { "attr.id": "id" }, classAttribute: "cub-form-field-hint" }, providers: [{ provide: CUB_HINT, useExisting: CubHint }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubHint, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-hint',
                    host: {
                        class: 'cub-form-field-hint',
                        '[attr.id]': 'id',
                    },
                    providers: [{ provide: CUB_HINT, useExisting: CubHint }],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.ViewContainerRef }], propDecorators: { id: [{
                type: Input
            }], status: [{
                type: Input
            }] } });

let nextUniqueId$2 = 0;
const CUB_ERROR = new InjectionToken('CubError');
class CubError {
    constructor(ariaLive, elementRef, renderer, viewContainerRef) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.viewContainerRef = viewContainerRef;
        this.status = 'error';
        /**
         元件 id，預設為 'cub-form-field-error-0'。
         */
        this.id = `cub-form-field-error-${nextUniqueId$2++}`;
        // If no aria-live value is set add 'polite' as a default. This is preferred over setting
        // role='alert' so that screen readers do not interrupt the current task to read this aloud.
        if (!ariaLive) {
            elementRef.nativeElement.setAttribute('aria-live', 'polite');
        }
    }
    // TODO 待優化 Hint、Success、Error 共用部分
    ngAfterViewInit() {
        setTimeout(() => {
            // 創建 cubMessageIcon component
            this.cubMessageIcon =
                this.viewContainerRef.createComponent(CubMessageIcon);
            // 初始化 cubMessageIcon 屬性
            this.cubMessageIcon.instance.status = this.status;
            // 創建一個父層容器
            const container = this.renderer.createElement('div');
            this.renderer.addClass(container, 'cub-error-container');
            // 將 icon、error 移到父層容器
            const parent = this.elementRef.nativeElement.parentNode;
            this.renderer.insertBefore(parent, container, this.elementRef.nativeElement);
            this.renderer.appendChild(container, this.cubMessageIcon.location.nativeElement);
            this.renderer.appendChild(container, this.elementRef.nativeElement);
        }, 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubError, deps: [{ token: 'aria-live', attribute: true }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubError, isStandalone: true, selector: "cub-error", inputs: { id: "id" }, host: { attributes: { "aria-atomic": "true" }, properties: { "attr.id": "id" }, classAttribute: "cub-form-field-error" }, providers: [{ provide: CUB_ERROR, useExisting: CubError }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubError, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-error',
                    host: {
                        class: 'cub-form-field-error',
                        '[attr.id]': 'id',
                        'aria-atomic': 'true',
                    },
                    providers: [{ provide: CUB_ERROR, useExisting: CubError }],
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['aria-live']
                }] }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.ViewContainerRef }], propDecorators: { id: [{
                type: Input
            }] } });

let nextUniqueId$1 = 0;
const CUB_SUCCESS = new InjectionToken('CubSuccess');
class CubSuccess {
    constructor(ariaLive, elementRef, renderer, viewContainerRef) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.viewContainerRef = viewContainerRef;
        this.status = 'success';
        /**
         元件 id，預設為 'cub-form-field-success-0'。
         */
        this.id = `cub-form-field-success-${nextUniqueId$1++}`;
        // If no aria-live value is set add 'polite' as a default. This is preferred over setting
        // role='alert' so that screen readers do not interrupt the current task to read this aloud.
        if (!ariaLive) {
            elementRef.nativeElement.setAttribute('aria-live', 'polite');
        }
    }
    // TODO 待優化 Hint、Success、Error 共用部分
    ngAfterViewInit() {
        setTimeout(() => {
            // 創建 cubMessageIcon component
            this.cubMessageIcon =
                this.viewContainerRef.createComponent(CubMessageIcon);
            // 初始化 cubMessageIcon 屬性
            this.cubMessageIcon.instance.status = this.status;
            // 創建一個父層容器
            const container = this.renderer.createElement('div');
            this.renderer.addClass(container, 'cub-success-container');
            // 將 icon、success 移到父層容器
            const parent = this.elementRef.nativeElement.parentNode;
            this.renderer.insertBefore(parent, container, this.elementRef.nativeElement);
            this.renderer.appendChild(container, this.cubMessageIcon.location.nativeElement);
            this.renderer.appendChild(container, this.elementRef.nativeElement);
        }, 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSuccess, deps: [{ token: 'aria-live', attribute: true }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSuccess, isStandalone: true, selector: "cub-success", inputs: { id: "id" }, host: { attributes: { "aria-atomic": "true" }, properties: { "attr.id": "id" }, classAttribute: "cub-form-field-success" }, providers: [{ provide: CUB_SUCCESS, useExisting: CubSuccess }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSuccess, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-success',
                    host: {
                        class: 'cub-form-field-success',
                        '[attr.id]': 'id',
                        'aria-atomic': 'true',
                    },
                    providers: [{ provide: CUB_SUCCESS, useExisting: CubSuccess }],
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['aria-live']
                }] }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.ViewContainerRef }], propDecorators: { id: [{
                type: Input
            }] } });

const cubFormFieldAnimations = {
    /** Animation that transitions the form field's error and hint messages. */
    transitionMessages: trigger('transitionMessages', [
        state('enter', style({ opacity: 1, transform: 'translateY(0%)' })),
        transition('void => enter', [
            style({ opacity: 0, transform: 'translateY(-5px)' }),
            animate('300ms cubic-bezier(0.55, 0, 0.55, 0.2)'),
        ]),
    ]),
};

function getCubFormFieldPlaceholderConflictError() {
    return Error('Placeholder attribute and child element were both specified.');
}
function getCubFormFieldDuplicatedHintError(align) {
    return Error(`A hint was already declared for 'align="${align}"'.`);
}
function getCubFormFieldMissingControlError() {
    return Error('cub-form-field must contain a CubFormFieldControl.');
}

let nextUniqueId = 0;
const CUB_FORM_FIELD = new InjectionToken('FormField');
class CubFormField {
    get _control() {
        return (this._explicitFormFieldControl ||
            this._controlNonStatic ||
            this._controlStatic);
    }
    set _control(value) {
        this._explicitFormFieldControl = value;
    }
    get _label() {
        return this._labelChildNonStatic || this._labelChildStatic || '';
    }
    constructor(_elementRef, _changeDetectorRef) {
        this._elementRef = _elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._subscriptAnimationState = '';
        this._hintLabelId = `cub-form-field-hint-${nextUniqueId++}`;
        this._destroyed = new Subject();
        /**
         是否啟用錯誤狀態，預設為否。
         */
        this.invalid = false;
        /**
         元件方向，預設為 'vertical'。
         */
        this.orientation = 'vertical';
        /**
           元件尺寸，預設為 'medium'。
           */
        this.size = 'medium';
    }
    ngAfterContentInit() {
        const control = this._control;
        if (control.controlType) {
            this._elementRef.nativeElement.classList.add(`cub-form-field-type-${control.controlType}`);
        }
        control.stateChanges
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            this._syncDescribedByIds();
            this._changeDetectorRef.markForCheck();
        });
        // 當 Form Field 內 Form 元件值改變時，使用 changeDetector 標記
        if (control.ngControl && control.ngControl.valueChanges) {
            control.ngControl.valueChanges
                .pipe(takeUntil(this._destroyed))
                .subscribe(() => this._changeDetectorRef.markForCheck());
        }
        // 當 Hint 改變時，使用 changeDetector 標記
        this._hintChildren.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            this._processHints();
            this._changeDetectorRef.markForCheck();
        });
        // 當 Success 改變時，使用 changeDetector 標記
        this._successChildren.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            this._syncDescribedByIds();
            this._changeDetectorRef.markForCheck();
        });
        // 當 Error 改變時，使用 changeDetector 標記
        this._errorChildren.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            this._syncDescribedByIds();
            this._changeDetectorRef.markForCheck();
        });
    }
    ngAfterContentChecked() {
        this._validateControlChild();
    }
    ngAfterViewInit() {
        this._subscriptAnimationState = 'enter';
        this._changeDetectorRef.detectChanges();
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    _shouldForward(prop) {
        const control = this._control ? this._control.ngControl : null;
        return control && control[prop];
    }
    _validateControlChild() {
        if (!this._control) {
            throw getCubFormFieldMissingControlError();
        }
    }
    _processHints() {
        this._syncDescribedByIds();
    }
    _syncDescribedByIds() {
        if (this._control) {
            let ids = [];
            if (this._control.ariaDescribedBy &&
                typeof this._control.ariaDescribedBy === 'string') {
                ids.push(...this._control.ariaDescribedBy.split(' '));
            }
            if (this._hintChildren) {
                ids.push(...this._hintChildren.map((hint) => hint.id));
            }
            if (this._successChildren) {
                ids.push(...this._successChildren.map((success) => success.id));
            }
            if (this._errorChildren) {
                ids.push(...this._errorChildren.map((error) => error.id));
            }
            this._control.setDescribedByIds(ids);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormField, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubFormField, isStandalone: true, selector: "cub-form-field", inputs: { invalid: "invalid", orientation: "orientation", size: "size" }, host: { properties: { "class.cub-form-field-invalid": "_control.errorState  || invalid", "class.cub-form-field-valid": "!(_control.errorState  || invalid) && _shouldForward(\"touched\")", "class.cub-form-field-disabled": "_control.disabled", "class.cub-form-field-horizontal": "orientation === \"horizontal\"", "class.cub-form-field-small": "size === \"small\"", "class.cub-focused": "_control.focused", "class.ng-untouched": "_shouldForward(\"untouched\")", "class.ng-touched": "_shouldForward(\"touched\")", "class.ng-pristine": "_shouldForward(\"pristine\")", "class.ng-dirty": "_shouldForward(\"dirty\")", "class.ng-valid": "_shouldForward(\"valid\")", "class.ng-invalid": "_shouldForward(\"invalid\")", "class.ng-pending": "_shouldForward(\"pending\")" }, classAttribute: "cub-form-field" }, providers: [{ provide: CUB_FORM_FIELD, useExisting: CubFormField }], queries: [{ propertyName: "_controlNonStatic", first: true, predicate: CubFormFieldControl, descendants: true }, { propertyName: "_controlStatic", first: true, predicate: CubFormFieldControl, descendants: true, static: true }, { propertyName: "_labelChildNonStatic", first: true, predicate: CubLabel, descendants: true }, { propertyName: "_labelChildStatic", first: true, predicate: CubLabel, descendants: true, static: true }, { propertyName: "_successChildren", predicate: CUB_SUCCESS, descendants: true }, { propertyName: "_errorChildren", predicate: CUB_ERROR, descendants: true }, { propertyName: "_hintChildren", predicate: CUB_HINT, descendants: true }], exportAs: ["cubFormField"], ngImport: i0, template: "<ng-container *ngIf=\"_labelChildStatic\">\n  <ng-content select=\"cub-label\"></ng-content>\n</ng-container>\n\n<div class=\"cub-form-field-container\">\n  <div class=\"cub-form-field-content\" #inputContent>\n    <ng-content></ng-content>\n  </div>\n\n  <div\n    class=\"cub-form-field-subscript-container\"\n    [hidden]=\"\n      !(\n        _hintChildren.length ||\n        (_errorChildren.length && (_control.errorState || invalid)) ||\n        (_successChildren.length &&\n          !(_control.errorState || invalid) &&\n          _shouldForward('touched'))\n      )\n    \"\n  >\n    <div class=\"cub-form-field-hint-container\" *ngIf=\"_hintChildren.length\">\n      <ng-content select=\"cub-hint\"></ng-content>\n    </div>\n\n    <div class=\"cub-form-field-error-container\" *ngIf=\"_errorChildren.length\">\n      <ng-content select=\"cub-error\"></ng-content>\n    </div>\n\n    <div\n      class=\"cub-form-field-success-container\"\n      *ngIf=\"_successChildren.length\"\n    >\n      <ng-content select=\"cub-success\"></ng-content>\n    </div>\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], animations: [cubFormFieldAnimations.transitionMessages], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormField, decorators: [{
            type: Component,
            args: [{ selector: 'cub-form-field', exportAs: 'cubFormField', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, animations: [cubFormFieldAnimations.transitionMessages], host: {
                        class: 'cub-form-field',
                        '[class.cub-form-field-invalid]': '_control.errorState  || invalid',
                        '[class.cub-form-field-valid]': '!(_control.errorState  || invalid) && _shouldForward("touched")',
                        '[class.cub-form-field-disabled]': '_control.disabled',
                        '[class.cub-form-field-horizontal]': 'orientation === "horizontal"',
                        '[class.cub-form-field-small]': 'size === "small"',
                        '[class.cub-focused]': '_control.focused',
                        '[class.ng-untouched]': '_shouldForward("untouched")',
                        '[class.ng-touched]': '_shouldForward("touched")',
                        '[class.ng-pristine]': '_shouldForward("pristine")',
                        '[class.ng-dirty]': '_shouldForward("dirty")',
                        '[class.ng-valid]': '_shouldForward("valid")',
                        '[class.ng-invalid]': '_shouldForward("invalid")',
                        '[class.ng-pending]': '_shouldForward("pending")',
                    }, providers: [{ provide: CUB_FORM_FIELD, useExisting: CubFormField }], imports: [NgIf], template: "<ng-container *ngIf=\"_labelChildStatic\">\n  <ng-content select=\"cub-label\"></ng-content>\n</ng-container>\n\n<div class=\"cub-form-field-container\">\n  <div class=\"cub-form-field-content\" #inputContent>\n    <ng-content></ng-content>\n  </div>\n\n  <div\n    class=\"cub-form-field-subscript-container\"\n    [hidden]=\"\n      !(\n        _hintChildren.length ||\n        (_errorChildren.length && (_control.errorState || invalid)) ||\n        (_successChildren.length &&\n          !(_control.errorState || invalid) &&\n          _shouldForward('touched'))\n      )\n    \"\n  >\n    <div class=\"cub-form-field-hint-container\" *ngIf=\"_hintChildren.length\">\n      <ng-content select=\"cub-hint\"></ng-content>\n    </div>\n\n    <div class=\"cub-form-field-error-container\" *ngIf=\"_errorChildren.length\">\n      <ng-content select=\"cub-error\"></ng-content>\n    </div>\n\n    <div\n      class=\"cub-form-field-success-container\"\n      *ngIf=\"_successChildren.length\"\n    >\n      <ng-content select=\"cub-success\"></ng-content>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { invalid: [{
                type: Input
            }], orientation: [{
                type: Input
            }], size: [{
                type: Input
            }], _controlNonStatic: [{
                type: ContentChild,
                args: [CubFormFieldControl]
            }], _controlStatic: [{
                type: ContentChild,
                args: [CubFormFieldControl, { static: true }]
            }], _labelChildNonStatic: [{
                type: ContentChild,
                args: [CubLabel]
            }], _labelChildStatic: [{
                type: ContentChild,
                args: [CubLabel, { static: true }]
            }], _successChildren: [{
                type: ContentChildren,
                args: [CUB_SUCCESS, { descendants: true }]
            }], _errorChildren: [{
                type: ContentChildren,
                args: [CUB_ERROR, { descendants: true }]
            }], _hintChildren: [{
                type: ContentChildren,
                args: [CUB_HINT, { descendants: true }]
            }] } });

class CubFormFieldModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubFormFieldModule, imports: [CubCommonModule,
            CubLabelModule,
            /** Component */
            CubFormField,
            /** Directive */
            CubHint,
            CubError,
            CubSuccess], exports: [CubCommonModule,
            CubLabelModule,
            /** Component */
            CubFormField,
            /** Directive */
            CubHint,
            CubError,
            CubSuccess] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormFieldModule, imports: [CubCommonModule,
            CubLabelModule, CubCommonModule,
            CubLabelModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFormFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        CubLabelModule,
                        /** Component */
                        CubFormField,
                        /** Directive */
                        CubHint,
                        CubError,
                        CubSuccess,
                    ],
                    exports: [
                        CubCommonModule,
                        CubLabelModule,
                        /** Component */
                        CubFormField,
                        /** Directive */
                        CubHint,
                        CubError,
                        CubSuccess,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/form-field
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_ERROR, CUB_FORM_FIELD, CUB_HINT, CUB_SUCCESS, CubError, CubFormField, CubFormFieldControl, CubFormFieldModule, CubHint, CubSuccess, cubFormFieldAnimations, getCubFormFieldDuplicatedHintError, getCubFormFieldMissingControlError, getCubFormFieldPlaceholderConflictError };
//# sourceMappingURL=cub-lib-view-rootng-component-form-field.mjs.map
