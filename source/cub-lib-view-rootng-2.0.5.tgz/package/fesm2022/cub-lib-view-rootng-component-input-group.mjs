import * as i0 from '@angular/core';
import { InjectionToken, Directive, ViewChild, ContentChildren, ContentChild, Input, Optional, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NgIf } from '@angular/common';
import { CUB_PREFIX, CUB_SUFFIX, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/component/form-field';
import { CubFormFieldControl, CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';

const CUB_FIELD_SUFFIX = new InjectionToken('CubFieldSuffix');
class CubFieldSuffix {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFieldSuffix, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubFieldSuffix, isStandalone: true, selector: "button[appearance=\"filled-outline\"][cubFieldSuffix]", providers: [{ provide: CUB_FIELD_SUFFIX, useExisting: CubFieldSuffix }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFieldSuffix, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[appearance="filled-outline"][cubFieldSuffix]',
                    providers: [{ provide: CUB_FIELD_SUFFIX, useExisting: CubFieldSuffix }],
                }]
        }], ctorParameters: () => [] });

const CUB_INPUT_GROUP = new InjectionToken('InputGroup');
class CubInputGroup {
    get _control() {
        return (this._explicitFormFieldControl ||
            this._controlNonStatic ||
            this._controlStatic);
    }
    set _control(value) {
        this._explicitFormFieldControl = value;
    }
    get _formFieldInvalid() {
        return this._formField && this._formField.invalid;
    }
    constructor(_changeDetectorRef, _formField) {
        this._changeDetectorRef = _changeDetectorRef;
        this._formField = _formField;
        this.infixDisabled = false;
        /**
         元件尺寸，預設為 'medium'。
         */
        this.size = 'medium';
    }
    ngAfterViewInit() {
        this._changeDetectorRef.detectChanges();
    }
    ngOnDestroy() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputGroup, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.CubFormField, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubInputGroup, isStandalone: true, selector: "cub-input-group", inputs: { size: "size" }, host: { properties: { "class.cub-input-group-invalid": "_control.errorState || _formFieldInvalid", "class.cub-input-group-with-field-suffix": "_fieldSuffixChildren.length", "class.cub-input-group-small": "size === \"small\"" }, classAttribute: "cub-input-group" }, queries: [{ propertyName: "_controlNonStatic", first: true, predicate: CubFormFieldControl, descendants: true }, { propertyName: "_controlStatic", first: true, predicate: CubFormFieldControl, descendants: true, static: true }, { propertyName: "_prefixChildren", predicate: CUB_PREFIX, descendants: true }, { propertyName: "_suffixChildren", predicate: CUB_SUFFIX, descendants: true }, { propertyName: "_fieldSuffixChildren", predicate: CUB_FIELD_SUFFIX, descendants: true }], viewQueries: [{ propertyName: "_inputContainerRef", first: true, predicate: ["inputContainer"], descendants: true }], exportAs: ["cubInputGroup"], ngImport: i0, template: "<div\n  class=\"cub-input-group-container\"\n  [class.cub-input-group-with-prefix]=\"_prefixChildren.length\"\n  [class.cub-input-group-with-suffix]=\"_suffixChildren.length\"\n  [class.cub-disabled]=\"_control.disabled\"\n>\n  <div\n    class=\"cub-input-group-prefix\"\n    *ngIf=\"_prefixChildren.length\"\n    #inputPrefix\n  >\n    <ng-content select=\"[cubPrefix]\"></ng-content>\n  </div>\n\n  <div class=\"cub-input-group-infix\" #inputContainer>\n    <ng-content></ng-content>\n  </div>\n\n  <div\n    class=\"cub-input-group-suffix\"\n    *ngIf=\"_suffixChildren.length\"\n    #inputSuffix\n  >\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </div>\n</div>\n<div\n  class=\"cub-input-group-field-suffix\"\n  *ngIf=\"_fieldSuffixChildren.length\"\n  #inputFieldSuffix\n>\n  <ng-content select=\"[cubFieldSuffix]\"></ng-content>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-input-group', exportAs: 'cubInputGroup', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-input-group',
                        '[class.cub-input-group-invalid]': '_control.errorState || _formFieldInvalid',
                        '[class.cub-input-group-with-field-suffix]': '_fieldSuffixChildren.length',
                        '[class.cub-input-group-small]': 'size === "small"',
                    }, imports: [NgIf], template: "<div\n  class=\"cub-input-group-container\"\n  [class.cub-input-group-with-prefix]=\"_prefixChildren.length\"\n  [class.cub-input-group-with-suffix]=\"_suffixChildren.length\"\n  [class.cub-disabled]=\"_control.disabled\"\n>\n  <div\n    class=\"cub-input-group-prefix\"\n    *ngIf=\"_prefixChildren.length\"\n    #inputPrefix\n  >\n    <ng-content select=\"[cubPrefix]\"></ng-content>\n  </div>\n\n  <div class=\"cub-input-group-infix\" #inputContainer>\n    <ng-content></ng-content>\n  </div>\n\n  <div\n    class=\"cub-input-group-suffix\"\n    *ngIf=\"_suffixChildren.length\"\n    #inputSuffix\n  >\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </div>\n</div>\n<div\n  class=\"cub-input-group-field-suffix\"\n  *ngIf=\"_fieldSuffixChildren.length\"\n  #inputFieldSuffix\n>\n  <ng-content select=\"[cubFieldSuffix]\"></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.CubFormField, decorators: [{
                    type: Optional
                }] }], propDecorators: { size: [{
                type: Input
            }], _controlNonStatic: [{
                type: ContentChild,
                args: [CubFormFieldControl]
            }], _controlStatic: [{
                type: ContentChild,
                args: [CubFormFieldControl, { static: true }]
            }], _prefixChildren: [{
                type: ContentChildren,
                args: [CUB_PREFIX, { descendants: true }]
            }], _suffixChildren: [{
                type: ContentChildren,
                args: [CUB_SUFFIX, { descendants: true }]
            }], _fieldSuffixChildren: [{
                type: ContentChildren,
                args: [CUB_FIELD_SUFFIX, { descendants: true }]
            }], _inputContainerRef: [{
                type: ViewChild,
                args: ['inputContainer']
            }] } });

class CubInputGroupModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputGroupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubInputGroupModule, imports: [CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            /** Component */
            CubInputGroup,
            /** Directive */
            CubFieldSuffix], exports: [CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            /** Component */
            CubInputGroup,
            /** Directive */
            CubFieldSuffix] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputGroupModule, imports: [CubCommonModule,
            CubFormFieldModule,
            CubLabelModule, CubCommonModule,
            CubFormFieldModule,
            CubLabelModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputGroupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        /** Component */
                        CubInputGroup,
                        /** Directive */
                        CubFieldSuffix,
                    ],
                    exports: [
                        CubCommonModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        /** Component */
                        CubInputGroup,
                        /** Directive */
                        CubFieldSuffix,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/input-group
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_FIELD_SUFFIX, CUB_INPUT_GROUP, CubFieldSuffix, CubInputGroup, CubInputGroupModule };
//# sourceMappingURL=cub-lib-view-rootng-component-input-group.mjs.map
