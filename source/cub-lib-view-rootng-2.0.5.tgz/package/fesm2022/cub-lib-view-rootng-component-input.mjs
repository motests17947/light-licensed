import * as i0 from '@angular/core';
import { EventEmitter, Component, InjectionToken, Output, Input, Optional, Self, Inject, Directive, forwardRef, NgModule } from '@angular/core';
import * as i2 from '@angular/forms';
import { Validators, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import * as i1 from 'cub-lib-view-rootng/cdk/platform';
import { getSupportedInputTypes } from 'cub-lib-view-rootng/cdk/platform';
import { coerceBooleanProperty, coerceArray } from 'cub-lib-view-rootng/cdk/coercion';
import * as i3 from 'cub-lib-view-rootng/component/common';
import { mixinErrorState, DomHandler, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import * as i5 from 'cub-lib-view-rootng/component/form-field';
import { CUB_FORM_FIELD, CubFormFieldControl, CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubIconButton } from 'cub-lib-view-rootng/component/button';
import * as i4 from 'cub-lib-view-rootng/cdk/text-field';
import { CubCdkTextFieldModule } from 'cub-lib-view-rootng/cdk/text-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputGroupModule } from 'cub-lib-view-rootng/component/input-group';

class CubInputClearButton {
    constructor() {
        this.valueChange = new EventEmitter();
    }
    ngOnInit() { }
    clearValue() {
        this.value = null;
        this.valueChange.emit(this.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputClearButton, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubInputClearButton, isStandalone: true, selector: "cub-input-clear-button", host: { classAttribute: "cub-input-clear-button" }, ngImport: i0, template: "@if (!disabled && showClear && value && value.length > 0) {\n<button\n  cub-icon-button\n  type=\"button\"\n  color=\"neutral\"\n  appearance=\"plain\"\n  [size]=\"size\"\n  (click)=\"clearValue()\"\n>\n  <span class=\"cub-icon-x-small\"></span>\n</button>\n}\n", styles: [""], dependencies: [{ kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputClearButton, decorators: [{
            type: Component,
            args: [{ selector: 'cub-input-clear-button', host: {
                        class: 'cub-input-clear-button',
                    }, imports: [CubIconButton], template: "@if (!disabled && showClear && value && value.length > 0) {\n<button\n  cub-icon-button\n  type=\"button\"\n  color=\"neutral\"\n  appearance=\"plain\"\n  [size]=\"size\"\n  (click)=\"clearValue()\"\n>\n  <span class=\"cub-icon-x-small\"></span>\n</button>\n}\n" }]
        }] });

const CUB_INPUT_VALUE_ACCESSOR = new InjectionToken('CUB_INPUT_VALUE_ACCESSOR');
let nextUniqueId = 0;
const _CubInputBase = mixinErrorState(class {
    constructor(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, 
    /**
     * Form control bound to the component.
     * Implemented as part of `MatFormFieldControl`.
     * @docs-private
     */
    ngControl) {
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
        /**
         * Emits whenever the component state changes and should cause the parent
         * form field to update. Implemented as part of `CubFormFieldControl`.
         * @docs-private
         */
        this.stateChanges = new Subject();
    }
});
class CubInput extends _CubInputBase {
    /**
     * Implemented as part of CubFormFieldControl.
     * @docs-private
     */
    get empty() {
        return (!this._isNeverEmpty() &&
            !this._elementRef.nativeElement.value &&
            !this._isBadInput() &&
            !this.autofilled);
    }
    /** 設定 textarea 的 rows 屬性，預設為 3。 */
    get rows() {
        return this._rows;
    }
    set rows(value) {
        if (value !== this._rows) {
            this._rows = value;
            if (this._isTextarea) {
                this._setTextareaRows();
            }
        }
    }
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        if (this.ngControl && this.ngControl.disabled !== null) {
            return this.ngControl.disabled;
        }
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        // Browsers may not fire the blur event if the input is disabled too quickly.
        // Reset from here to ensure that the element doesn't become stuck.
        if (this.focused) {
            this.focused = false;
            this.stateChanges.next();
        }
    }
    /** 元件唯一識別符，預設為 undefined。 */
    get id() {
        return this._id;
    }
    set id(value) {
        this._id = value || this._uid;
    }
    /** 是否啟用清除功能，預設 false。 */
    get showClear() {
        return this._showClear;
    }
    set showClear(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== this._showClear) {
            this._showClear = newValue;
            if (this._showClear && !this._readonly) {
                this._setupInputClearButton();
            }
            else {
                this._removeInputClearButton();
            }
            this.stateChanges.next();
        }
    }
    /** 元件是否為必填，預設為 false。 */
    get required() {
        return (this._required ??
            this.ngControl?.control?.hasValidator(Validators.required) ??
            false);
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    /** 元件輸入的類型，預設為 'text'。 */
    get type() {
        return this._type;
    }
    set type(value) {
        this._type = value || 'text';
        // When using Angular inputs, developers are no longer able to set the properties on the native
        // input element. To ensure that bindings for `type` work, we need to sync the setter
        // with the native property. Textarea elements don't support the type property or attribute.
        if (!this._isTextarea && getSupportedInputTypes().has(this._type)) {
            this._elementRef.nativeElement.type = this._type;
        }
    }
    /** 元件輸入的當前值，預設為 undefined。 */
    get value() {
        return this._inputValueAccessor.value;
    }
    set value(value) {
        if (value !== this.value) {
            this._inputValueAccessor.value = value;
            this.stateChanges.next();
        }
    }
    /** 元件是否為唯讀狀態，預設為 false。 */
    get readonly() {
        return this._readonly;
    }
    set readonly(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== this._readonly) {
            this._readonly = newValue;
            // 當 readonly 狀態改變時，重新檢查清除按鈕
            if (this._readonly) {
                this._removeInputClearButton();
            }
            else if (this.showClear) {
                this._setupInputClearButton();
            }
            this.stateChanges.next();
        }
    }
    constructor(_elementRef, _platform, ngControl, _parentForm, _parentFormGroup, _defaultErrorStateMatcher, inputValueAccessor, _autofillMonitor, viewContainerRef, renderer, ngZone, _formField) {
        super(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl);
        this._elementRef = _elementRef;
        this._platform = _platform;
        this._autofillMonitor = _autofillMonitor;
        this.viewContainerRef = viewContainerRef;
        this.renderer = renderer;
        this._formField = _formField;
        this.cubInputClearButton = null;
        /**
         * Implemented as part of CubFormFieldControl.
         * @docs-private
         */
        this.focused = false;
        /**
         * Implemented as part of CubFormFieldControl.
         * @docs-private
         */
        this.controlType = 'cub-input';
        /**
         * Implemented as part of CubFormFieldControl.
         * @docs-private
         */
        this.autofilled = false;
        /**
         * Implemented as part of CubFormFieldControl.
         * @docs-private
         */
        this.stateChanges = new Subject();
        this._type = 'text';
        this._disabled = false;
        this._uid = `cub-input-${nextUniqueId++}`;
        this._neverEmptyInputTypes = [
            'date',
            'datetime',
            'datetime-local',
            'month',
            'time',
            'week',
        ].filter((t) => getSupportedInputTypes().has(t));
        this.destroy$ = new Subject();
        this._rows = 3;
        this._showClear = false;
        this._readonly = false;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 外觀樣式，預設為 'outline'。 */
        this.appearance = 'outline';
        /** 輸入框的 title 屬性，預設為 ''。 */
        this.title = '';
        /** 設定輸入框的 autocomplete 屬性，用於禁用瀏覽器的自動填充功能，預設為 'off'。 */
        this.autocomplete = 'off';
        /**
         當清除資料時發出通知。
         */
        this.clear = new EventEmitter();
        this._iOSKeyupListener = (event) => {
            const el = event.target;
            // Note: We specifically check for 0, rather than `!el.selectionStart`, because the two
            // indicate different things. If the value is 0, it means that the caret is at the start
            // of the input, whereas a value of `null` means that the input doesn't support
            // manipulating the selection range. Inputs that don't support setting the selection range
            // will throw an error so we want to avoid calling `setSelectionRange` on them. See:
            // https://html.spec.whatwg.org/multipage/input.html#do-not-apply
            if (!el.value && el.selectionStart === 0 && el.selectionEnd === 0) {
                // Note: Just setting `0, 0` doesn't fix the issue. Setting
                // `1, 1` fixes it for the first time that you type text and
                // then hold delete. Toggling to `1, 1` and then back to
                // `0, 0` seems to completely fix it.
                el.setSelectionRange(1, 1);
                el.setSelectionRange(0, 0);
            }
        };
        const element = this._elementRef.nativeElement;
        const nodeName = element.nodeName.toLowerCase();
        // If no input value accessor was explicitly specified, use the element as the input value
        // accessor.
        this._inputValueAccessor = inputValueAccessor || element;
        this._previousNativeValue = this.value;
        this.id = this.id;
        // On some versions of iOS the caret gets stuck in the wrong place when holding down the delete
        // key. In order to get around this we need to "jiggle" the caret loose. Since this bug only
        // exists on iOS, we only bother to install the listener on iOS.
        if (_platform.IOS) {
            ngZone.runOutsideAngular(() => {
                _elementRef.nativeElement.addEventListener('keyup', this._iOSKeyupListener);
            });
        }
        this._isServer = !this._platform.isBrowser;
        this._isNativeSelect = nodeName === 'select';
        this._isTextarea = nodeName === 'textarea';
        this._isInFormField = !!_formField;
        if (this._isNativeSelect) {
            this.controlType = element.multiple
                ? 'cub-native-select-multiple'
                : 'cub-native-select';
        }
    }
    ngOnChanges() {
        this.stateChanges.next();
    }
    ngOnInit() {
        // 一開始就創建 <div class="cub-input-container">
        this._setupInputContainer();
        if (this.showClear && !this._readonly) {
            this._setupInputClearButton();
        }
        if (this._isTextarea) {
            this._setTextareaRows();
        }
    }
    ngDoCheck() {
        if (this.ngControl) {
            this.updateErrorState();
        }
        this._dirtyCheckNativeValue();
        this._dirtyCheckPlaceholder();
    }
    ngAfterViewInit() {
        if (this._platform.isBrowser) {
            this._autofillMonitor
                .monitor(this._elementRef.nativeElement)
                .subscribe((event) => {
                this.autofilled = event.isAutofilled;
                this.stateChanges.next();
            });
        }
    }
    ngOnDestroy() {
        this.stateChanges.complete();
        if (this._platform.isBrowser) {
            this._autofillMonitor.stopMonitoring(this._elementRef.nativeElement);
        }
        if (this._platform.IOS) {
            this._elementRef.nativeElement.removeEventListener('keyup', this._iOSKeyupListener);
        }
        this.destroy$.next();
        this.destroy$.complete();
        this._removeInputClearButton();
    }
    /** Focuses the input. */
    focus(options) {
        this._elementRef.nativeElement.focus(options);
    }
    /**
     * Implemented as part of CubFormFieldControl.
     * @docs-private
     */
    setDescribedByIds(ids) {
        if (ids.length) {
            this._elementRef.nativeElement.setAttribute('aria-describedby', ids.join(' '));
        }
        else {
            this._elementRef.nativeElement.removeAttribute('aria-describedby');
        }
    }
    /**
     * Implemented as part of CubFormFieldControl.
     * @docs-private
     */
    onContainerClick() {
        // Do not re-focus the input element if the element is already focused.
        if (!this.focused) {
            this.focus();
        }
    }
    /** Whether the form control is a native select that is displayed inline. */
    _isInlineSelect() {
        const element = this._elementRef.nativeElement;
        return this._isNativeSelect && (element.multiple || element.size > 1);
    }
    /** Callback for the cases where the focused state of the input changes. */
    _focusChanged(isFocused) {
        if (isFocused !== this.focused) {
            this.focused = isFocused;
            this.stateChanges.next();
        }
    }
    _onInput() {
        // 在使用者開始輸入時標記為 touched
        if (this.ngControl?.control && !this.ngControl.control.touched) {
            this.ngControl.control.markAsTouched();
        }
    }
    /** Does some manual dirty checking on the native input `value` property. */
    _dirtyCheckNativeValue() {
        const newValue = this._elementRef.nativeElement.value;
        if (this._previousNativeValue !== newValue) {
            const oldValue = this._previousNativeValue;
            this._previousNativeValue = newValue;
            this.stateChanges.next();
            // 同步即時 value 值給 cubInputClearButton
            if (this.cubInputClearButton) {
                this.cubInputClearButton.instance.value = newValue;
            }
        }
    }
    /** Checks whether the input type is one of the types that are never empty. */
    _isNeverEmpty() {
        return this._neverEmptyInputTypes.indexOf(this._type) > -1;
    }
    /** Checks whether the input is invalid based on the native validation. */
    _isBadInput() {
        // The `validity` property won't be present on platform-server.
        let validity = this._elementRef.nativeElement
            .validity;
        return validity && validity.badInput;
    }
    /** Does some manual dirty checking on the native input `placeholder` attribute. */
    _dirtyCheckPlaceholder() {
        const placeholder = this.placeholder;
        if (placeholder !== this._previousPlaceholder) {
            const element = this._elementRef.nativeElement;
            this._previousPlaceholder = placeholder;
            placeholder
                ? element.setAttribute('placeholder', placeholder)
                : element.removeAttribute('placeholder');
        }
    }
    /** 建立 InputClearButton 區域，目前供 Clear 放置。 */
    _setupInputClearButton() {
        // 如果已经存在，先移除以避免重复
        if (this.cubInputClearButton) {
            this._removeInputClearButton();
        }
        this.cubInputClearButton =
            this.viewContainerRef.createComponent(CubInputClearButton);
        // 初始化 cubInputClearButton 的属性
        const props = {
            value: this.value,
            size: this.size,
            disabled: this.disabled,
            showClear: this.showClear,
        };
        Object.assign(this.cubInputClearButton.instance, props);
        // 監聽 cubInputClearButton 的 valueChange 事件
        this.cubInputClearButton.instance.valueChange
            .pipe(takeUntil(this.destroy$))
            .subscribe((newValue) => {
            this.value = newValue || '';
            // 同步更新 ngModel 或 FormControl 的值
            if (this.ngControl && this.ngControl.control) {
                this.ngControl.control.setValue(this.value);
                this.ngControl.control.markAsDirty();
                this.ngControl.control.markAsTouched();
            }
            this.clear.emit();
            this.stateChanges.next();
        });
        // 將 clear 按紐放入已存在的 cub-input-container
        const inputClearButton = this.cubInputClearButton.location.nativeElement;
        const wrapper = this._elementRef.nativeElement.parentNode;
        this.renderer.appendChild(wrapper, inputClearButton);
    }
    /** 移除 InputClearButton 區域 */
    _removeInputClearButton() {
        if (this.cubInputClearButton) {
            this.cubInputClearButton.destroy();
            this.cubInputClearButton = null;
        }
    }
    _setupInputContainer() {
        // 創建 cub-input-container
        this.inputContainer = this.renderer.createElement('div');
        this.renderer.addClass(this.inputContainer, 'cub-input-container');
        const inputElement = this._elementRef.nativeElement;
        const parent = inputElement.parentNode;
        // 複製 style 屬性到 container
        const inputStyle = this.style;
        if (inputStyle) {
            this.renderer.setAttribute(this.inputContainer, 'style', inputStyle);
        }
        // 複製 class 屬性到 container
        const inputClasses = this.class;
        if (inputClasses) {
            const processedClasses = this._processClasses(inputClasses);
            processedClasses.forEach((cssClass) => {
                this.renderer.addClass(this.inputContainer, cssClass);
            });
        }
        // 將 input 插入 cub-input-container
        this.renderer.insertBefore(parent, this.inputContainer, inputElement);
        this.renderer.appendChild(this.inputContainer, inputElement);
    }
    /** 處理當多個 class 傳入 */
    _processClasses(cssClasses) {
        if (!cssClasses)
            return [];
        return coerceArray(cssClasses)
            .flatMap((cssClass) => cssClass?.trim().split(/\s+/) || [])
            .filter((cssClass) => cssClass && cssClass !== '');
    }
    /** 設置 Textarea 的 rows 屬性 */
    _setTextareaRows() {
        this.renderer.setAttribute(this._elementRef.nativeElement, 'rows', this.rows.toString());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInput, deps: [{ token: i0.ElementRef }, { token: i1.Platform }, { token: i2.NgControl, optional: true, self: true }, { token: i2.NgForm, optional: true }, { token: i2.FormGroupDirective, optional: true }, { token: i3.ErrorStateMatcher }, { token: CUB_INPUT_VALUE_ACCESSOR, optional: true, self: true }, { token: i4.AutofillMonitor }, { token: i0.ViewContainerRef }, { token: i0.Renderer2 }, { token: i0.NgZone }, { token: CUB_FORM_FIELD, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubInput, isStandalone: true, selector: "input[cubInput], textarea[cubInput], select[cubNativeControl],\n      input[cubNativeControl], textarea[cubNativeControl]", inputs: { size: "size", appearance: "appearance", rows: "rows", title: "title", autocomplete: "autocomplete", disabled: "disabled", id: "id", placeholder: "placeholder", showClear: "showClear", style: "style", class: "class", name: "name", required: "required", type: "type", errorStateMatcher: "errorStateMatcher", ariaDescribedBy: ["aria-describedby", "ariaDescribedBy"], value: "value", readonly: "readonly" }, outputs: { clear: "clear" }, host: { listeners: { "focus": "_focusChanged(true)", "blur": "_focusChanged(false)", "input": "_onInput()" }, properties: { "class.cub-input-focused": "focused", "class.cub-input-invalid": "errorState", "class.cub-input-with-clear": "!disabled && showClear && !this._readonly", "class.cub-input-outline": "appearance === \"outline\"", "class.cub-input-borderless": "appearance === \"borderless\"", "class.cub-input-small": "size === \"small\"", "disabled": "disabled", "required": "required", "attr.id": "id", "attr.data-placeholder": "placeholder", "attr.name": "name || null", "attr.readonly": "readonly && !_isNativeSelect || null", "attr.aria-invalid": "(empty && required) ? null : errorState", "attr.aria-required": "required", "attr.title": "title", "attr.autocomplete": "autocomplete", "ngClass": "class" }, classAttribute: "cub-input " }, providers: [{ provide: CubFormFieldControl, useExisting: CubInput }], exportAs: ["cubInput"], usesInheritance: true, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInput, decorators: [{
            type: Directive,
            args: [{
                    selector: `input[cubInput], textarea[cubInput], select[cubNativeControl],
      input[cubNativeControl], textarea[cubNativeControl]`,
                    exportAs: 'cubInput',
                    host: {
                        class: 'cub-input ',
                        '[class.cub-input-focused]': 'focused',
                        '[class.cub-input-invalid]': 'errorState',
                        '[class.cub-input-with-clear]': '!disabled && showClear && !this._readonly',
                        '[class.cub-input-outline]': 'appearance === "outline"',
                        '[class.cub-input-borderless]': 'appearance === "borderless"',
                        '[class.cub-input-small]': 'size === "small"',
                        '[disabled]': 'disabled',
                        '[required]': 'required',
                        '[attr.id]': 'id',
                        '[attr.data-placeholder]': 'placeholder',
                        '[attr.name]': 'name || null',
                        '[attr.readonly]': 'readonly && !_isNativeSelect || null',
                        '[attr.aria-invalid]': '(empty && required) ? null : errorState',
                        '[attr.aria-required]': 'required',
                        '[attr.title]': 'title',
                        '[attr.autocomplete]': 'autocomplete',
                        '[ngClass]': 'class',
                        '(focus)': '_focusChanged(true)',
                        '(blur)': '_focusChanged(false)',
                        '(input)': '_onInput()',
                    },
                    providers: [{ provide: CubFormFieldControl, useExisting: CubInput }],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.Platform }, { type: i2.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i2.NgForm, decorators: [{
                    type: Optional
                }] }, { type: i2.FormGroupDirective, decorators: [{
                    type: Optional
                }] }, { type: i3.ErrorStateMatcher }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }, {
                    type: Inject,
                    args: [CUB_INPUT_VALUE_ACCESSOR]
                }] }, { type: i4.AutofillMonitor }, { type: i0.ViewContainerRef }, { type: i0.Renderer2 }, { type: i0.NgZone }, { type: i5.CubFormField, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_FORM_FIELD]
                }] }], propDecorators: { size: [{
                type: Input
            }], appearance: [{
                type: Input
            }], rows: [{
                type: Input
            }], title: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }], disabled: [{
                type: Input
            }], id: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], showClear: [{
                type: Input
            }], style: [{
                type: Input
            }], class: [{
                type: Input
            }], name: [{
                type: Input
            }], required: [{
                type: Input
            }], type: [{
                type: Input
            }], errorStateMatcher: [{
                type: Input
            }], ariaDescribedBy: [{
                type: Input,
                args: ['aria-describedby']
            }], value: [{
                type: Input
            }], readonly: [{
                type: Input
            }], clear: [{
                type: Output
            }] } });

const CUB_INPUT_MASK_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubInputMask),
    multi: true,
};
class CubInputMask {
    /**
     * 輸入遮罩格式，必填，預設值為 undefined。
     */
    get mask() {
        return this._mask;
    }
    set mask(value) {
        this._mask = value;
        this.initMask();
        this.writeValue('');
        this.onChanged(this.value);
    }
    constructor(elementRef, changeDetectorRef) {
        this.elementRef = elementRef;
        this.changeDetectorRef = changeDetectorRef;
        this.regexTests = [];
        this.firstNonMaskPosition = 0;
        this.length = 0;
        this.previousValue = '';
        this.defaultBuffer = '';
        this.focusText = '';
        this.androidChrome = false;
        this.patterns = {};
        this._filled = false;
        this._focused = false;
        /** 是否禁用元件，預設值為 false。 */
        this.disabled = false;
        /** 是否唯讀，預設值為 false。 */
        this.readonly = false;
        /** 遮罩預設字元，預設值為 '_'。 */
        this.slotChar = '_';
        /** 自動清除不合法輸入，預設值為 false。 */
        this.autoClear = false;
        /** 輸出值是否去除遮罩字元，預設值為 false。 */
        this.unmask = false;
        /** 輸入值變更時觸發 */
        this.inputChange = new EventEmitter();
        /** 鍵盤按下時觸發 */
        this.keydownChange = new EventEmitter();
        /** 元件獲得焦點時觸發 */
        this.focused = new EventEmitter();
        /** 元件失去焦點時觸發 */
        this.blurred = new EventEmitter();
        /** 遮罩輸入完成時觸發 */
        this.completed = new EventEmitter();
        this.onChanged = () => { };
        this.onTouched = () => { };
        this.inputElement = this.elementRef.nativeElement;
    }
    ngOnInit() {
        let userAgent = DomHandler.getUserAgent();
        this.androidChrome =
            /chrome/i.test(userAgent) && /android/i.test(userAgent);
        this.initMask();
    }
    initMask() {
        this.regexTests = [];
        this.partialPosition = this.mask.length;
        this.length = this.mask.length;
        this.firstNonMaskPosition = -1;
        this.patterns = {
            '0': '[0-9]',
            A: '[a-zA-Z]',
            L: '[a-z]',
            U: '[A-Z]',
            '*': `[a-zA-Z]|[0-9]`,
        };
        let maskPatterns = this.mask.split('');
        for (let index = 0; index < maskPatterns.length; index++) {
            let pattern = maskPatterns[index];
            if (pattern == '?') {
                this.length--;
                this.partialPosition = index;
            }
            else if (this.patterns[pattern]) {
                this.regexTests.push(new RegExp(this.patterns[pattern]));
                if (this.firstNonMaskPosition === -1) {
                    this.firstNonMaskPosition = this.regexTests.length - 1;
                }
                if (index < this.partialPosition) {
                    this.lastRequiredNonMaskPosition = this.regexTests.length - 1;
                }
            }
            else {
                this.regexTests.push(null);
            }
        }
        this.buffer = [];
        for (let index = 0; index < maskPatterns.length; index++) {
            let pattern = maskPatterns[index];
            if (pattern != '?') {
                if (this.patterns[pattern]) {
                    this.buffer.push(this.getPlaceholder(index));
                }
                else {
                    this.buffer.push(pattern);
                }
            }
        }
        this.defaultBuffer = this.buffer.join('');
    }
    writeValue(value) {
        this.value = value;
        if (this.elementRef && this.inputElement) {
            if (this.value == undefined || this.value == null) {
                this.inputElement.value = '';
            }
            else {
                this.inputElement.value = this.value;
            }
            this.checkValue();
            this.focusText = this.inputElement.value;
            this.updateFilledState();
        }
    }
    registerOnChange(fn) {
        this.onChanged = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(value) {
        this.disabled = value;
        this.changeDetectorRef.markForCheck();
    }
    caret(first, last) {
        let range, start, end;
        if (!this.inputElement.offsetParent ||
            this.inputElement !== this.inputElement.ownerDocument.activeElement) {
            return;
        }
        if (typeof first == 'number') {
            start = first;
            end = typeof last === 'number' ? last : start;
            if (this.inputElement.setSelectionRange) {
                this.inputElement.setSelectionRange(start, end);
            }
            else if (this.inputElement['createTextRange']) {
                range = this.inputElement['createTextRange']();
                range.collapse(true);
                range.moveEnd('character', end);
                range.moveStart('character', start);
                range.select();
            }
        }
        else {
            if (this.inputElement['setSelectionRange']) {
                start = this.inputElement['selectionStart'];
                end = this.inputElement['selectionEnd'];
            }
            else if (document['selection'] &&
                document['selection'].createRange) {
                range = document['selection'].createRange();
                start = 0 - range.duplicate().moveStart('character', -100000);
                end = start + range.text.length;
            }
            return { start, end };
        }
    }
    isCompleted() {
        for (let index = this.firstNonMaskPosition; index <= this.lastRequiredNonMaskPosition; index++) {
            if (this.regexTests[index] &&
                this.buffer[index] === this.getPlaceholder(index)) {
                return false;
            }
        }
        return true;
    }
    getPlaceholder(index) {
        if (index < this.slotChar.length) {
            return this.slotChar.charAt(index);
        }
        return this.slotChar.charAt(0);
    }
    seekNext(position) {
        while (++position < this.length && !this.regexTests[position])
            ;
        return position;
    }
    seekPrev(position) {
        while (--position >= 0 && !this.regexTests[position])
            ;
        return position;
    }
    shiftLeft(start, end) {
        let index, nextIndex;
        if (start < 0) {
            return;
        }
        for (index = start, nextIndex = this.seekNext(end); index < this.length; index++) {
            if (this.regexTests[index]) {
                if (nextIndex < this.length &&
                    this.regexTests[index].test(this.buffer[nextIndex])) {
                    this.buffer[index] = this.buffer[nextIndex];
                    this.buffer[nextIndex] = this.getPlaceholder(nextIndex);
                }
                else {
                    break;
                }
                nextIndex = this.seekNext(nextIndex);
            }
        }
        this.writeBuffer();
        this.caret(Math.max(this.firstNonMaskPosition, start));
    }
    shiftRight(position) {
        let index, nextIndex, placeholder, pattern;
        for (index = position, placeholder = this.getPlaceholder(position); index < this.length; index++) {
            if (this.regexTests[index]) {
                nextIndex = this.seekNext(index);
                pattern = this.buffer[index];
                this.buffer[index] = placeholder;
                if (nextIndex < this.length &&
                    this.regexTests[nextIndex].test(pattern)) {
                    placeholder = pattern;
                }
                else {
                    break;
                }
            }
        }
    }
    handleAndroidInput(event) {
        var currentValue = this.inputElement.value;
        var position = this.caret();
        if (this.previousValue &&
            this.previousValue.length &&
            this.previousValue.length > currentValue.length) {
            // a deletion or backspace happened
            this.checkValue(true);
            while (position.start > 0 && !this.regexTests[position.start - 1])
                position.start--;
            if (position.start === 0) {
                while (position.start < this.firstNonMaskPosition &&
                    !this.regexTests[position.start])
                    position.start++;
            }
            setTimeout(() => {
                this.caret(position.start, position.start);
                this.updateModel(event);
                if (this.isCompleted()) {
                    this.completed.emit();
                }
            }, 0);
        }
        else {
            this.checkValue(true);
            while (position.start < this.length && !this.regexTests[position.start])
                position.start++;
            setTimeout(() => {
                this.caret(position.start, position.start);
                this.updateModel(event);
                if (this.isCompleted()) {
                    this.completed.emit();
                }
            }, 0);
        }
    }
    onInputBlur(event) {
        this._focused = false;
        this.onTouched();
        this.checkValue();
        this.updateFilledState();
        this.blurred.emit(event);
        if (this.inputElement.value != this.focusText ||
            this.inputElement.value != this.value) {
            this.updateModel(event);
            let htmlEvent = document.createEvent('HTMLEvents');
            htmlEvent.initEvent('change', true, false);
            this.inputElement.dispatchEvent(htmlEvent);
        }
    }
    onInputKeydown(event) {
        if (this.readonly) {
            return;
        }
        let keyCode = event.which || event.keyCode, position, start, end;
        let iPhone = /iphone/i.test(DomHandler.getUserAgent());
        this.previousValue = this.inputElement.value;
        this.keydownChange.emit(event);
        //backspace, delete, and escape get special treatment
        if (keyCode === 8 || keyCode === 46 || (iPhone && keyCode === 127)) {
            position = this.caret();
            start = position.start;
            end = position.end;
            if (end - start === 0) {
                start =
                    keyCode !== 46
                        ? this.seekPrev(start)
                        : (end = this.seekNext(start - 1));
                end = keyCode === 46 ? this.seekNext(end) : end;
            }
            this.clearBuffer(start, end);
            this.shiftLeft(start, end - 1);
            this.updateModel(event);
            this.inputChange.emit(event);
            event.preventDefault();
        }
        else if (keyCode === 13) {
            // enter
            this.onInputBlur(event);
            this.updateModel(event);
        }
        else if (keyCode === 27) {
            // escape
            this.inputElement.value = this.focusText;
            this.caret(0, this.checkValue());
            this.updateModel(event);
            event.preventDefault();
        }
    }
    onInputKeypress(event) {
        if (this.readonly) {
            return;
        }
        var keyCode = event.which || event.keyCode, position = this.caret(), property, code, next, completed = false;
        if (event.ctrlKey ||
            event.altKey ||
            event.metaKey ||
            keyCode < 32 ||
            (keyCode > 34 && keyCode < 41)) {
            //Ignore
            return;
        }
        else if (keyCode && keyCode !== 13) {
            if (position.end - position.start !== 0) {
                this.clearBuffer(position.start, position.end);
                this.shiftLeft(position.start, position.end - 1);
            }
            property = this.seekNext(position.start - 1);
            if (property < this.length) {
                code = String.fromCharCode(keyCode);
                if (this.regexTests[property].test(code)) {
                    this.shiftRight(property);
                    this.buffer[property] = code;
                    this.writeBuffer();
                    next = this.seekNext(property);
                    if (/android/i.test(DomHandler.getUserAgent())) {
                        //Path for CSP Violation on FireFox OS 1.1
                        let proxy = () => {
                            this.caret(next);
                        };
                        setTimeout(proxy, 0);
                    }
                    else {
                        this.caret(next);
                    }
                    if (position.start <= this.lastRequiredNonMaskPosition) {
                        completed = this.isCompleted();
                    }
                    this.inputChange.emit(event);
                }
            }
            event.preventDefault();
        }
        this.updateModel(event);
        this.updateFilledState();
        if (completed) {
            this.completed.emit();
        }
    }
    clearBuffer(start, end) {
        let index;
        for (index = start; index < end && index < this.length; index++) {
            if (this.regexTests[index]) {
                this.buffer[index] = this.getPlaceholder(index);
            }
        }
    }
    writeBuffer() {
        this.inputElement.value = this.buffer.join('');
    }
    checkValue(allow) {
        //try to place characters where they belong
        let test = this.inputElement.value, lastMatch = -1, index, character, position;
        for (index = 0, position = 0; index < this.length; index++) {
            if (this.regexTests[index]) {
                this.buffer[index] = this.getPlaceholder(index);
                while (position++ < test.length) {
                    character = test.charAt(position - 1);
                    if (this.regexTests[index].test(character)) {
                        this.buffer[index] = character;
                        lastMatch = index;
                        break;
                    }
                }
                if (position > test.length) {
                    this.clearBuffer(index + 1, this.length);
                    break;
                }
            }
            else {
                if (this.buffer[index] === test.charAt(position)) {
                    position++;
                }
                if (index < this.partialPosition) {
                    lastMatch = index;
                }
            }
        }
        if (allow) {
            this.writeBuffer();
        }
        else if (lastMatch + 1 < this.partialPosition) {
            if (this.autoClear || this.buffer.join('') === this.defaultBuffer) {
                // Invalid value. Remove it and replace it with the
                // mask, which is the default behavior.
                if (this.inputElement.value)
                    this.inputElement.value = '';
                this.clearBuffer(0, this.length);
            }
            else {
                // Invalid value, but we opt to show the value to the
                // user and allow them to correct their mistake.
                this.writeBuffer();
            }
        }
        else {
            this.writeBuffer();
            this.inputElement.value = this.inputElement.value.substring(0, lastMatch + 1);
        }
        return this.partialPosition ? index : this.firstNonMaskPosition;
    }
    onInputFocus(event) {
        if (this.readonly) {
            return;
        }
        this._focused = true;
        clearTimeout(this.caretTimeoutId);
        let position;
        this.focusText = this.inputElement.value;
        position = this.checkValue();
        this.caretTimeoutId = setTimeout(() => {
            if (this.inputElement !== this.inputElement.ownerDocument.activeElement) {
                return;
            }
            this.writeBuffer();
            if (position == this.mask.replace('?', '').length) {
                this.caret(0, position);
            }
            else {
                this.caret(position);
            }
        }, 10);
        this.focused.emit(event);
    }
    onInputChange(event) {
        if (this.androidChrome) {
            this.handleAndroidInput(event);
        }
        else {
            this.onInputPaste(event);
        }
        this.inputChange.emit(event);
    }
    onInputPaste(event) {
        if (this.readonly) {
            return;
        }
        setTimeout(() => {
            var position = this.checkValue(true);
            this.caret(position);
            this.updateModel(event);
            if (this.isCompleted()) {
                this.completed.emit();
            }
        }, 0);
    }
    getUnmaskedValue() {
        let unmaskedBuffer = [];
        for (let index = 0; index < this.buffer.length; index++) {
            let c = this.buffer[index];
            if (this.regexTests[index] && c != this.getPlaceholder(index)) {
                unmaskedBuffer.push(c);
            }
        }
        return unmaskedBuffer.join('');
    }
    updateModel(event) {
        const updatedValue = this.unmask
            ? this.getUnmaskedValue()
            : event.target.value;
        if (updatedValue !== null || updatedValue !== undefined) {
            this.value = updatedValue;
            this.onChanged(this.value);
        }
    }
    updateFilledState() {
        this._filled = this.inputElement && this.inputElement.value != '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputMask, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubInputMask, isStandalone: true, selector: "input[cubInputMask]", inputs: { mask: ["cubInputMask", "mask"], disabled: "disabled", readonly: "readonly", slotChar: "slotChar", autoClear: "autoClear", unmask: "unmask" }, outputs: { inputChange: "inputChange", keydownChange: "keydownChange", focused: "focused", blurred: "blurred", completed: "completed" }, host: { listeners: { "input": "onInputChange($event)", "keydown": "onInputKeydown($event)", "keypress": "onInputKeypress($event)", "paste": "onInputPaste($event)", "focus": "onInputFocus($event)", "blur": "onInputBlur($event)" } }, providers: [CUB_INPUT_MASK_VALUE_ACCESSOR], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputMask, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[cubInputMask]',
                    providers: [CUB_INPUT_MASK_VALUE_ACCESSOR],
                    host: {
                        '(input)': 'onInputChange($event)',
                        '(keydown)': 'onInputKeydown($event)',
                        '(keypress)': 'onInputKeypress($event)',
                        '(paste)': 'onInputPaste($event)',
                        '(focus)': 'onInputFocus($event)',
                        '(blur)': 'onInputBlur($event)',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { mask: [{
                type: Input,
                args: ['cubInputMask']
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], slotChar: [{
                type: Input
            }], autoClear: [{
                type: Input
            }], unmask: [{
                type: Input
            }], inputChange: [{
                type: Output
            }], keydownChange: [{
                type: Output
            }], focused: [{
                type: Output
            }], blurred: [{
                type: Output
            }], completed: [{
                type: Output
            }] } });

const CUB_INPUT_NUMBER_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubInputNumber),
    multi: true,
};
/* JS 浮點數計算最大支援到16位數: https://blog.darkthread.net/blog/js-float-round-function/ */
class CubInputNumber {
    get filled() {
        return this.value !== null && this.value.toString().length > 0;
    }
    /** 控制元件是否禁用，預設值為 false。 */
    get disabled() {
        return this._disabled;
    }
    set disabled(disabled) {
        if (disabled) {
            this._focused = false;
        }
        this._disabled = disabled;
        if (this.timer) {
            this.clearTimer();
        }
    }
    constructor(elementRef, changeDetectorRef) {
        this.elementRef = elementRef;
        this.changeDetectorRef = changeDetectorRef;
        this.value = '';
        this.initialized = false;
        this.groupChar = '';
        this.prefixChar = '';
        this.suffixChar = '';
        this.isSpecialChar = false;
        this.lastValue = '';
        this._disabled = false;
        this._focused = false;
        /** 是否唯讀，預設值為 false。 */
        this.readonly = false;
        /** 每次遞增/遞減的步長，預設值為 1。 */
        this.step = 1;
        /** 輸入模式，預設值為 'decimal'。 */
        this.mode = 'decimal';
        /** 是否格式化顯示，預設值為 true。 */
        this.format = true;
        /** 是否允許空值，預設值為 true。 */
        this.allowEmpty = true;
        /** 顯示於數值前的字串，預設值為 ''。 */
        this.prefix = '';
        /** 顯示於數值後的字串，預設值為 ''。 */
        this.suffix = '';
        /** 是否使用千分位分隔，預設值為 true。 */
        this.useGrouping = true;
        /** 輸入值變更時觸發，回傳 { originalEvent, value, formattedValue } */
        this.inputChange = new EventEmitter();
        /** 鍵盤按下時觸發 */
        this.keydownChange = new EventEmitter();
        /** 元件獲得焦點時觸發 */
        this.focused = new EventEmitter();
        /** 元件失去焦點時觸發 */
        this.blurred = new EventEmitter();
        this.onChanged = () => { };
        this.onTouched = () => { };
        this.inputElement = this.elementRef.nativeElement;
    }
    ngOnInit() {
        this.constructParser();
        this.initialized = true;
    }
    ngOnChanges(simpleChange) {
        const properties = [
            'locale',
            'localeMatcher',
            'mode',
            'currency',
            'currencyDisplay',
            'useGrouping',
            'minFractionDigits',
            'maxFractionDigits',
            'prefix',
            'suffix',
        ];
        if (properties.some((property) => !!simpleChange[property])) {
            this.updateConstructParser();
        }
    }
    writeValue(value) {
        this.value = value;
        this.changeDetectorRef.markForCheck();
    }
    registerOnChange(fn) {
        this.onChanged = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    getOptions() {
        return {
            localeMatcher: this.localeMatcher,
            style: this.mode,
            currency: this.currency,
            currencyDisplay: this.currencyDisplay,
            useGrouping: this.useGrouping,
            minimumFractionDigits: this.minFractionDigits,
            maximumFractionDigits: this.maxFractionDigits,
        };
    }
    constructParser() {
        this.numberFormat = new Intl.NumberFormat(this.locale, this.getOptions());
        const numerals = [
            ...new Intl.NumberFormat(this.locale, { useGrouping: false }).format(9876543210),
        ].reverse();
        const index = new Map(numerals.map((number, index) => [number, index]));
        this._numeral = new RegExp(`[${numerals.join('')}]`, 'g');
        this._group = this.getGroupingExpression();
        this._minusSign = this.getMinusSignExpression();
        this._currency = this.getCurrencyExpression();
        this._decimal = this.getDecimalExpression();
        this._suffix = this.getSuffixExpression();
        this._prefix = this.getPrefixExpression();
        this._index = (key) => index.get(key);
    }
    updateConstructParser() {
        if (this.initialized) {
            this.constructParser();
        }
    }
    escapeRegExp(text) {
        return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
    }
    getDecimalExpression() {
        const formatter = new Intl.NumberFormat(this.locale, {
            ...this.getOptions(),
            useGrouping: false,
        });
        return new RegExp(`[${formatter
            .format(1.1)
            .replace(this._currency, '')
            .trim()
            .replace(this._numeral, '')}]`, 'g');
    }
    getGroupingExpression() {
        const formatter = new Intl.NumberFormat(this.locale, { useGrouping: true });
        this.groupChar = formatter
            .format(1000000)
            .trim()
            .replace(this._numeral, '')
            .charAt(0);
        return new RegExp(`[${this.groupChar}]`, 'g');
    }
    getMinusSignExpression() {
        const formatter = new Intl.NumberFormat(this.locale, {
            useGrouping: false,
        });
        return new RegExp(`[${formatter.format(-1).trim().replace(this._numeral, '')}]`, 'g');
    }
    getCurrencyExpression() {
        if (this.currency) {
            const formatter = new Intl.NumberFormat(this.locale, {
                style: 'currency',
                currency: this.currency,
                currencyDisplay: this.currencyDisplay,
                minimumFractionDigits: 0,
                maximumFractionDigits: 0,
            });
            return new RegExp(`[${formatter
                .format(1)
                .replace(/\s/g, '')
                .replace(this._numeral, '')
                .replace(this._group, '')}]`, 'g');
        }
        return new RegExp(`[]`, 'g');
    }
    getPrefixExpression() {
        if (this.prefix) {
            this.prefixChar = this.prefix;
        }
        else {
            const formatter = new Intl.NumberFormat(this.locale, {
                style: this.mode,
                currency: this.currency,
                currencyDisplay: this.currencyDisplay,
            });
            this.prefixChar = formatter.format(1).split('1')[0];
        }
        return new RegExp(`${this.escapeRegExp(this.prefixChar || '')}`, 'g');
    }
    getSuffixExpression() {
        if (this.suffix) {
            this.suffixChar = this.suffix;
        }
        else {
            const formatter = new Intl.NumberFormat(this.locale, {
                style: this.mode,
                currency: this.currency,
                currencyDisplay: this.currencyDisplay,
                minimumFractionDigits: 0,
                maximumFractionDigits: 0,
            });
            this.suffixChar = formatter.format(1).split('1')[1];
        }
        return new RegExp(`${this.escapeRegExp(this.suffixChar || '')}`, 'g');
    }
    formatValue(value) {
        if (value !== '' && value !== null) {
            if (value === '-') {
                // Minus sign
                return value;
            }
            if (this.format) {
                let formatter = new Intl.NumberFormat(this.locale, this.getOptions());
                let formattedValue = formatter.format(value);
                if (this.prefix) {
                    formattedValue = this.prefix + formattedValue;
                }
                if (this.suffix) {
                    formattedValue = formattedValue + this.suffix;
                }
                return formattedValue;
            }
            return value.toString();
        }
        return '';
    }
    parseValue(text) {
        let filteredText = text
            .replace(this._suffix, '')
            .replace(this._prefix, '')
            .trim()
            .replace(/\s/g, '')
            .replace(this._currency, '')
            .replace(this._group, '')
            .replace(this._minusSign, '-')
            .replace(this._decimal, '.')
            .replace(this._numeral, this._index);
        if (filteredText) {
            if (filteredText === '-') {
                // Minus sign
                return filteredText;
            }
            let parsedValue = +filteredText;
            return isNaN(parsedValue) ? null : parsedValue;
        }
        return null;
    }
    repeat(event, interval, dir) {
        if (this.readonly) {
            return;
        }
        let i = interval || 500;
        this.clearTimer();
        this.timer = setTimeout(() => {
            this.repeat(event, 40, dir);
        }, i);
        this.spin(event, dir);
    }
    spin(event, dir) {
        let step = this.step * dir;
        let currentValue = (this.parseValue(this.inputElement.value) ||
            0);
        let newValue = this.validateValue(currentValue + step);
        if (this.maxLength && this.maxLength < this.formatValue(newValue).length) {
            return;
        }
        this.updateInput(newValue, '', 'spin', '');
        this.updateModel(event, newValue);
        this.handleOnInput(event, currentValue, newValue);
    }
    onInputChange(event) {
        if (this.readonly) {
            return;
        }
        if (this.isSpecialChar) {
            event.target.value = this.lastValue;
        }
        this.isSpecialChar = false;
    }
    onInputKeydown(event) {
        if (this.readonly) {
            return;
        }
        this.lastValue = event.target.value;
        if (event.shiftKey || event.altKey) {
            this.isSpecialChar = true;
            return;
        }
        let selectionStart = event.target.selectionStart;
        let selectionEnd = event.target.selectionEnd;
        let inputValue = event.target.value;
        let newValueString = null;
        if (event.altKey) {
            event.preventDefault();
        }
        switch (event.which) {
            //up
            case 38:
                this.spin(event, 1);
                event.preventDefault();
                break;
            //down
            case 40:
                this.spin(event, -1);
                event.preventDefault();
                break;
            //left
            case 37:
                if (!this.isNumeralChar(inputValue.charAt(selectionStart - 1))) {
                    event.preventDefault();
                }
                break;
            //right
            case 39:
                if (!this.isNumeralChar(inputValue.charAt(selectionStart))) {
                    event.preventDefault();
                }
                break;
            //enter
            case 13:
                newValueString = this.validateValue(this.parseValue(this.inputElement.value));
                this.inputElement.value = this.formatValue(newValueString);
                this.inputElement.setAttribute('aria-valuenow', newValueString);
                this.updateModel(event, newValueString);
                break;
            //backspace
            case 8: {
                event.preventDefault();
                if (selectionStart === selectionEnd) {
                    const deleteChar = inputValue.charAt(selectionStart - 1);
                    const { decimalCharIndex, decimalCharIndexWithoutPrefix } = this.getDecimalCharIndexes(inputValue);
                    if (this.isNumeralChar(deleteChar)) {
                        const decimalLength = this.getDecimalLength(inputValue);
                        if (this._group.test(deleteChar)) {
                            this._group.lastIndex = 0;
                            newValueString =
                                inputValue.slice(0, selectionStart - 2) +
                                    inputValue.slice(selectionStart - 1);
                        }
                        else if (this._decimal.test(deleteChar)) {
                            this._decimal.lastIndex = 0;
                            if (decimalLength) {
                                this.inputElement.setSelectionRange(selectionStart - 1, selectionStart - 1);
                            }
                            else {
                                newValueString =
                                    inputValue.slice(0, selectionStart - 1) +
                                        inputValue.slice(selectionStart);
                            }
                        }
                        else if (decimalCharIndex > 0 &&
                            selectionStart > decimalCharIndex) {
                            const insertedText = this.isDecimalMode() &&
                                (this.minFractionDigits || 0) < decimalLength
                                ? ''
                                : '0';
                            newValueString =
                                inputValue.slice(0, selectionStart - 1) +
                                    insertedText +
                                    inputValue.slice(selectionStart);
                        }
                        else if (decimalCharIndexWithoutPrefix === 1) {
                            newValueString =
                                inputValue.slice(0, selectionStart - 1) +
                                    '0' +
                                    inputValue.slice(selectionStart);
                            newValueString =
                                this.parseValue(newValueString) > 0 ? newValueString : '';
                        }
                        else {
                            newValueString =
                                inputValue.slice(0, selectionStart - 1) +
                                    inputValue.slice(selectionStart);
                        }
                    }
                    this.updateValue(event, newValueString, null, 'delete-single');
                }
                else {
                    newValueString = this.deleteRange(inputValue, selectionStart, selectionEnd);
                    this.updateValue(event, newValueString, null, 'delete-range');
                }
                break;
            }
            // del
            case 46:
                event.preventDefault();
                if (selectionStart === selectionEnd) {
                    const deleteChar = inputValue.charAt(selectionStart);
                    const { decimalCharIndex, decimalCharIndexWithoutPrefix } = this.getDecimalCharIndexes(inputValue);
                    if (this.isNumeralChar(deleteChar)) {
                        const decimalLength = this.getDecimalLength(inputValue);
                        if (this._group.test(deleteChar)) {
                            this._group.lastIndex = 0;
                            newValueString =
                                inputValue.slice(0, selectionStart) +
                                    inputValue.slice(selectionStart + 2);
                        }
                        else if (this._decimal.test(deleteChar)) {
                            this._decimal.lastIndex = 0;
                            if (decimalLength) {
                                this.inputElement.setSelectionRange(selectionStart + 1, selectionStart + 1);
                            }
                            else {
                                newValueString =
                                    inputValue.slice(0, selectionStart) +
                                        inputValue.slice(selectionStart + 1);
                            }
                        }
                        else if (decimalCharIndex > 0 &&
                            selectionStart > decimalCharIndex) {
                            const insertedText = this.isDecimalMode() &&
                                (this.minFractionDigits || 0) < decimalLength
                                ? ''
                                : '0';
                            newValueString =
                                inputValue.slice(0, selectionStart) +
                                    insertedText +
                                    inputValue.slice(selectionStart + 1);
                        }
                        else if (decimalCharIndexWithoutPrefix === 1) {
                            newValueString =
                                inputValue.slice(0, selectionStart) +
                                    '0' +
                                    inputValue.slice(selectionStart + 1);
                            newValueString =
                                this.parseValue(newValueString) > 0 ? newValueString : '';
                        }
                        else {
                            newValueString =
                                inputValue.slice(0, selectionStart) +
                                    inputValue.slice(selectionStart + 1);
                        }
                    }
                    this.updateValue(event, newValueString, null, 'delete-back-single');
                }
                else {
                    newValueString = this.deleteRange(inputValue, selectionStart, selectionEnd);
                    this.updateValue(event, newValueString, null, 'delete-range');
                }
                break;
            default:
                break;
        }
        this.keydownChange.emit(event);
    }
    onInputKeypress(event) {
        if (this.readonly) {
            return;
        }
        let code = event.which || event.keyCode;
        let char = String.fromCharCode(code);
        const isDecimalSign = this.isDecimalSign(char);
        const isMinusSign = this.isMinusSign(char);
        if (code != 13) {
            event.preventDefault();
        }
        if ((48 <= code && code <= 57) || isMinusSign || isDecimalSign) {
            this.insert(event, char, { isDecimalSign, isMinusSign });
        }
    }
    onInputPaste(event) {
        if (!this.disabled && !this.readonly) {
            event.preventDefault();
            let data = (event.clipboardData || window['clipboardData']).getData('Text');
            if (data) {
                let filteredData = this.parseValue(data);
                if (filteredData != null) {
                    this.insert(event, filteredData.toString());
                }
            }
        }
    }
    allowMinusSign() {
        return this.min == null || this.min < 0;
    }
    isMinusSign(char) {
        if (this._minusSign.test(char) || char === '-') {
            this._minusSign.lastIndex = 0;
            return true;
        }
        return false;
    }
    isDecimalSign(char) {
        if (this._decimal.test(char)) {
            this._decimal.lastIndex = 0;
            return true;
        }
        return false;
    }
    isDecimalMode() {
        return this.mode === 'decimal';
    }
    getDecimalCharIndexes(value) {
        let decimalCharIndex = value.search(this._decimal);
        this._decimal.lastIndex = 0;
        const filteredVal = value
            .replace(this._prefix, '')
            .trim()
            .replace(/\s/g, '')
            .replace(this._currency, '');
        const decimalCharIndexWithoutPrefix = filteredVal.search(this._decimal);
        this._decimal.lastIndex = 0;
        return { decimalCharIndex, decimalCharIndexWithoutPrefix };
    }
    getCharIndexes(value) {
        const decimalCharIndex = value.search(this._decimal);
        this._decimal.lastIndex = 0;
        const minusCharIndex = value.search(this._minusSign);
        this._minusSign.lastIndex = 0;
        const suffixCharIndex = value.search(this._suffix);
        this._suffix.lastIndex = 0;
        const currencyCharIndex = value.search(this._currency);
        this._currency.lastIndex = 0;
        return {
            decimalCharIndex,
            minusCharIndex,
            suffixCharIndex,
            currencyCharIndex,
        };
    }
    insert(event, text, sign = { isDecimalSign: false, isMinusSign: false }) {
        const minusCharIndexOnText = text.search(this._minusSign);
        this._minusSign.lastIndex = 0;
        if (!this.allowMinusSign() && minusCharIndexOnText !== -1) {
            return;
        }
        let selectionStart = this.inputElement.selectionStart;
        let selectionEnd = this.inputElement.selectionEnd;
        let inputValue = this.inputElement.value.trim();
        const { decimalCharIndex, minusCharIndex, suffixCharIndex, currencyCharIndex, } = this.getCharIndexes(inputValue);
        let newValueString;
        if (sign.isMinusSign) {
            if (selectionStart === 0) {
                newValueString = inputValue;
                if (minusCharIndex === -1 || selectionEnd !== 0) {
                    newValueString = this.insertText(inputValue, text, 0, selectionEnd);
                }
                this.updateValue(event, newValueString, text, 'insert');
            }
        }
        else if (sign.isDecimalSign) {
            if (decimalCharIndex > 0 && selectionStart === decimalCharIndex) {
                this.updateValue(event, inputValue, text, 'insert');
            }
            else if (decimalCharIndex > selectionStart &&
                decimalCharIndex < selectionEnd) {
                newValueString = this.insertText(inputValue, text, selectionStart, selectionEnd);
                this.updateValue(event, newValueString, text, 'insert');
            }
            else if (decimalCharIndex === -1 && this.maxFractionDigits) {
                newValueString = this.insertText(inputValue, text, selectionStart, selectionEnd);
                this.updateValue(event, newValueString, text, 'insert');
            }
        }
        else {
            const maxFractionDigits = this.numberFormat.resolvedOptions().maximumFractionDigits;
            const operation = selectionStart !== selectionEnd ? 'range-insert' : 'insert';
            if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                if (selectionStart + text.length - (decimalCharIndex + 1) <=
                    maxFractionDigits) {
                    const charIndex = currencyCharIndex >= selectionStart
                        ? currencyCharIndex - 1
                        : suffixCharIndex >= selectionStart
                            ? suffixCharIndex
                            : inputValue.length;
                    newValueString =
                        inputValue.slice(0, selectionStart) +
                            text +
                            inputValue.slice(selectionStart + text.length, charIndex) +
                            inputValue.slice(charIndex);
                    this.updateValue(event, newValueString, text, operation);
                }
            }
            else {
                newValueString = this.insertText(inputValue, text, selectionStart, selectionEnd);
                this.updateValue(event, newValueString, text, operation);
            }
        }
    }
    insertText(value, text, start, end) {
        let textSplit = text === '.' ? text : text.split('.');
        if (textSplit.length === 2) {
            const decimalCharIndex = value.slice(start, end).search(this._decimal);
            this._decimal.lastIndex = 0;
            return decimalCharIndex > 0
                ? value.slice(0, start) + this.formatValue(text) + value.slice(end)
                : value || this.formatValue(text);
        }
        else if (end - start === value.length) {
            return this.formatValue(text);
        }
        else if (start === 0) {
            return text + value.slice(end);
        }
        else if (end === value.length) {
            return value.slice(0, start) + text;
        }
        else {
            return value.slice(0, start) + text + value.slice(end);
        }
    }
    deleteRange(value, start, end) {
        let newValueString;
        if (end - start === value.length)
            newValueString = '';
        else if (start === 0)
            newValueString = value.slice(end);
        else if (end === value.length)
            newValueString = value.slice(0, start);
        else
            newValueString = value.slice(0, start) + value.slice(end);
        return newValueString;
    }
    initCursor() {
        let selectionStart = this.inputElement.selectionStart;
        let inputValue = this.inputElement.value;
        let valueLength = inputValue.length;
        let index = null;
        // remove prefix
        let prefixLength = (this.prefixChar || '').length;
        inputValue = inputValue.replace(this._prefix, '');
        selectionStart = selectionStart - prefixLength;
        let char = inputValue.charAt(selectionStart);
        if (this.isNumeralChar(char)) {
            return selectionStart + prefixLength;
        }
        //left
        let i = selectionStart - 1;
        while (i >= 0) {
            char = inputValue.charAt(i);
            if (this.isNumeralChar(char)) {
                index = i + prefixLength;
                break;
            }
            else {
                i--;
            }
        }
        if (index !== null) {
            this.inputElement.setSelectionRange(index + 1, index + 1);
        }
        else {
            i = selectionStart;
            while (i < valueLength) {
                char = inputValue.charAt(i);
                if (this.isNumeralChar(char)) {
                    index = i + prefixLength;
                    break;
                }
                else {
                    i++;
                }
            }
            if (index !== null) {
                this.inputElement.setSelectionRange(index, index);
            }
        }
        return index || 0;
    }
    onInputClick() {
        const currentValue = this.inputElement.value;
        if (!this.readonly && currentValue !== DomHandler.getSelection()) {
            this.initCursor();
        }
    }
    isNumeralChar(char) {
        if (char.length === 1 &&
            (this._numeral.test(char) ||
                this._decimal.test(char) ||
                this._group.test(char) ||
                this._minusSign.test(char))) {
            this.resetRegex();
            return true;
        }
        return false;
    }
    resetRegex() {
        this._numeral.lastIndex = 0;
        this._decimal.lastIndex = 0;
        this._group.lastIndex = 0;
        this._minusSign.lastIndex = 0;
    }
    updateValue(event, valueString, insertedValueString, operation) {
        let currentValue = this.inputElement.value;
        let newValue = null;
        if (valueString != null) {
            newValue = this.parseValue(valueString);
            newValue = !newValue && !this.allowEmpty ? 0 : newValue;
            this.updateInput(newValue, insertedValueString, operation, valueString);
            this.handleOnInput(event, currentValue, newValue);
        }
    }
    handleOnInput(event, currentValue, newValue) {
        if (this.isValueChanged(currentValue, newValue)) {
            this.inputChange.emit({
                originalEvent: event,
                value: newValue,
                formattedValue: currentValue,
            });
        }
    }
    isValueChanged(currentValue, newValue) {
        if (newValue === null && currentValue !== null) {
            return true;
        }
        if (newValue != null) {
            let parsedCurrentValue = typeof currentValue === 'string'
                ? this.parseValue(currentValue)
                : currentValue;
            return newValue !== parsedCurrentValue;
        }
        return false;
    }
    validateValue(value) {
        if (value === '-' || value === '' || value === null) {
            return null;
        }
        if (this.min != null && value < this.min) {
            return this.min;
        }
        if (this.max != null && value > this.max) {
            return this.max;
        }
        return value;
    }
    updateInput(value, insertedValueString, operation, valueString) {
        insertedValueString = insertedValueString || '';
        let inputValue = this.inputElement.value;
        let newValue = this.formatValue(value);
        let currentLength = inputValue.length;
        if (newValue !== valueString) {
            newValue = this.concatValues(newValue, valueString);
        }
        if (currentLength === 0) {
            this.inputElement.value = newValue;
            this.inputElement.setSelectionRange(0, 0);
            const index = this.initCursor();
            const selectionEnd = index + insertedValueString.length;
            this.inputElement.setSelectionRange(selectionEnd, selectionEnd);
        }
        else {
            let selectionStart = this.inputElement.selectionStart;
            let selectionEnd = this.inputElement.selectionEnd;
            if (this.maxLength && this.maxLength < newValue.length) {
                return;
            }
            this.inputElement.value = newValue;
            let newLength = newValue.length;
            if (operation === 'range-insert') {
                const startValue = this.parseValue((inputValue || '').slice(0, selectionStart));
                const startValueString = startValue !== null ? startValue.toString() : '';
                const startExpr = startValueString
                    .split('')
                    .join(`(${this.groupChar})?`);
                const sRegex = new RegExp(startExpr, 'g');
                sRegex.test(newValue);
                const tExpr = insertedValueString
                    .split('')
                    .join(`(${this.groupChar})?`);
                const tRegex = new RegExp(tExpr, 'g');
                tRegex.test(newValue.slice(sRegex.lastIndex));
                selectionEnd = sRegex.lastIndex + tRegex.lastIndex;
                this.inputElement.setSelectionRange(selectionEnd, selectionEnd);
            }
            else if (newLength === currentLength) {
                if (operation === 'insert' || operation === 'delete-back-single') {
                    this.inputElement.setSelectionRange(selectionEnd + 1, selectionEnd + 1);
                }
                else if (operation === 'delete-single') {
                    this.inputElement.setSelectionRange(selectionEnd - 1, selectionEnd - 1);
                }
                else if (operation === 'delete-range' || operation === 'spin') {
                    this.inputElement.setSelectionRange(selectionEnd, selectionEnd);
                }
            }
            else if (operation === 'delete-back-single') {
                let prevChar = inputValue.charAt(selectionEnd - 1);
                let nextChar = inputValue.charAt(selectionEnd);
                let diff = currentLength - newLength;
                let isGroupChar = this._group.test(nextChar);
                if (isGroupChar && diff === 1) {
                    selectionEnd += 1;
                }
                else if (!isGroupChar && this.isNumeralChar(prevChar)) {
                    selectionEnd += -1 * diff + 1;
                }
                this._group.lastIndex = 0;
                this.inputElement.setSelectionRange(selectionEnd, selectionEnd);
            }
            else if (inputValue === '-' && operation === 'insert') {
                this.inputElement.setSelectionRange(0, 0);
                const index = this.initCursor();
                const selectionEnd = index + insertedValueString.length + 1;
                this.inputElement.setSelectionRange(selectionEnd, selectionEnd);
            }
            else {
                selectionEnd = selectionEnd + (newLength - currentLength);
                this.inputElement.setSelectionRange(selectionEnd, selectionEnd);
            }
        }
        this.inputElement.setAttribute('aria-valuenow', value);
    }
    concatValues(value, nextValue) {
        if (value && nextValue) {
            let decimalCharIndex = nextValue.search(this._decimal);
            this._decimal.lastIndex = 0;
            if (this.suffixChar) {
                return decimalCharIndex !== -1
                    ? value.replace(this.suffixChar, '').split(this._decimal)[0] +
                        nextValue.replace(this.suffixChar, '').slice(decimalCharIndex) +
                        this.suffixChar
                    : value.replace(this.suffixChar, '').split(this._decimal)[0] +
                        this.suffixChar;
            }
            else {
                return decimalCharIndex !== -1
                    ? value.split(this._decimal)[0] + nextValue.slice(decimalCharIndex)
                    : value;
            }
        }
        return value;
    }
    getDecimalLength(value) {
        if (value) {
            const valueSplit = value.split(this._decimal);
            if (valueSplit.length === 2) {
                return valueSplit[1]
                    .replace(this._suffix, '')
                    .trim()
                    .replace(/\s/g, '')
                    .replace(this._currency, '').length;
            }
        }
        return 0;
    }
    onInputFocus(event) {
        this._focused = true;
        this.focused.emit(event);
    }
    onInputBlur(event) {
        this._focused = false;
        let newValue = this.validateValue(this.parseValue(this.inputElement.value));
        this.inputElement.value = this.formatValue(newValue);
        this.inputElement.setAttribute('aria-valuenow', newValue);
        this.updateModel(event, newValue);
        this.blurred.emit(event);
    }
    formattedValue() {
        const value = !this.value && !this.allowEmpty ? 0 : this.value;
        return this.formatValue(value);
    }
    updateModel(event, value) {
        if (this.value !== value) {
            this.value = value;
            this.onChanged(value);
        }
        this.onTouched();
    }
    setDisabledState(disabled) {
        this.disabled = disabled;
        this.changeDetectorRef.markForCheck();
    }
    clearTimer() {
        if (this.timer) {
            clearInterval(this.timer);
        }
    }
    getFormatter() {
        return this.numberFormat;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputNumber, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubInputNumber, isStandalone: true, selector: "input[cubInputNumber]", inputs: { maxLength: "maxLength", min: "min", max: "max", readonly: "readonly", step: "step", mode: "mode", format: "format", allowEmpty: "allowEmpty", prefix: "prefix", suffix: "suffix", locale: "locale", localeMatcher: "localeMatcher", currency: "currency", currencyDisplay: "currencyDisplay", useGrouping: "useGrouping", minFractionDigits: "minFractionDigits", maxFractionDigits: "maxFractionDigits", disabled: "disabled" }, outputs: { inputChange: "inputChange", keydownChange: "keydownChange", focused: "focused", blurred: "blurred" }, host: { attributes: { "inputmode": "decimal" }, listeners: { "input": "onInputChange($event)", "keydown": "onInputKeydown($event)", "keypress": "onInputKeypress($event)", "paste": "onInputPaste($event)", "click": "onInputClick()", "focus": "onInputFocus($event)", "blur": "onInputBlur($event)" }, properties: { "value": "formattedValue()" } }, providers: [CUB_INPUT_NUMBER_VALUE_ACCESSOR], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputNumber, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[cubInputNumber]',
                    providers: [CUB_INPUT_NUMBER_VALUE_ACCESSOR],
                    host: {
                        inputmode: 'decimal',
                        '[value]': 'formattedValue()',
                        '(input)': 'onInputChange($event)',
                        '(keydown)': 'onInputKeydown($event)',
                        '(keypress)': 'onInputKeypress($event)',
                        '(paste)': 'onInputPaste($event)',
                        '(click)': 'onInputClick()',
                        '(focus)': 'onInputFocus($event)',
                        '(blur)': 'onInputBlur($event)',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { maxLength: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], readonly: [{
                type: Input
            }], step: [{
                type: Input
            }], mode: [{
                type: Input
            }], format: [{
                type: Input
            }], allowEmpty: [{
                type: Input
            }], prefix: [{
                type: Input
            }], suffix: [{
                type: Input
            }], locale: [{
                type: Input
            }], localeMatcher: [{
                type: Input
            }], currency: [{
                type: Input
            }], currencyDisplay: [{
                type: Input
            }], useGrouping: [{
                type: Input
            }], minFractionDigits: [{
                type: Input
            }], maxFractionDigits: [{
                type: Input
            }], disabled: [{
                type: Input
            }], inputChange: [{
                type: Output
            }], keydownChange: [{
                type: Output
            }], focused: [{
                type: Output
            }], blurred: [{
                type: Output
            }] } });

class CubInputModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubInputModule, imports: [CubCdkTextFieldModule,
            CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule,
            /** Directives */
            CubInput,
            CubInputMask,
            CubInputNumber], exports: [CubCdkTextFieldModule,
            CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule,
            /** Directives */
            CubInput,
            CubInputMask,
            CubInputNumber] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputModule, imports: [CubCdkTextFieldModule,
            CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule, CubCdkTextFieldModule,
            CubCommonModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInputModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkTextFieldModule,
                        CubCommonModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputGroupModule,
                        /** Directives */
                        CubInput,
                        CubInputMask,
                        CubInputNumber,
                    ],
                    exports: [
                        CubCdkTextFieldModule,
                        CubCommonModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputGroupModule,
                        /** Directives */
                        CubInput,
                        CubInputMask,
                        CubInputNumber,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/input
 */
/* Directive */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_INPUT_MASK_VALUE_ACCESSOR, CUB_INPUT_NUMBER_VALUE_ACCESSOR, CUB_INPUT_VALUE_ACCESSOR, CubInput, CubInputMask, CubInputModule, CubInputNumber };
//# sourceMappingURL=cub-lib-view-rootng-component-input.mjs.map
