import * as i0 from '@angular/core';
import { ElementRef, Input, ViewChild, ContentChildren, Component, NgModule } from '@angular/core';
import { NgIf } from '@angular/common';
import { CubCdkObserveContent } from 'cub-lib-view-rootng/cdk/observers';
import { CUB_SUFFIX, CUB_END, CubCommonModule } from 'cub-lib-view-rootng/component/common';

let nextUniqueId = 0;
class CubLabel {
    /**
     元件寬度設定，預設為 'fill'。
     */
    get widthMode() {
        return this._widthMode;
    }
    set widthMode(value) {
        this._widthMode = value;
        this.setCustomWidth();
    }
    /**
     元件寬度，當 widthMode 設定為 'fixed' 才有效果，預設為 ''。
     */
    get customWidth() {
        return this._customWidth;
    }
    set customWidth(value) {
        this._customWidth = value;
        this.setCustomWidth();
    }
    constructor(renderer, elementRef, _changeDetectorRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this.labelContent = '';
        this._labelId = `cub-label-${nextUniqueId++}`;
        this._widthMode = 'fill';
        this._customWidth = '';
        /**
         是否啟用必填狀態，預設為否。
         */
        this.required = false;
        /**
         元件尺寸，預設為 'medium'。
         */
        this.size = 'medium';
        /**
         元件文字對齊，預設為 'left'。
         */
        this.alignment = 'left';
    }
    ngAfterContentInit() {
        this.trim(this.label.nativeElement);
    }
    observeContent(event) {
        this.trim(event[0].target);
    }
    trim(element) {
        if (element) {
            this.labelContent = element.textContent.trim();
            this._changeDetectorRef.markForCheck();
        }
    }
    setCustomWidth() {
        setTimeout(() => {
            if (this.widthMode === 'fixed' && !!this.customWidth) {
                this.renderer.setStyle(this.elementRef.nativeElement, 'width', this.customWidth);
            }
        }, 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLabel, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubLabel, isStandalone: true, selector: "cub-label", inputs: { required: "required", size: "size", alignment: "alignment", widthMode: "widthMode", customWidth: "customWidth" }, host: { properties: { "class.cub-label-container-small": "size === \"small\"", "class.cub-label-container-left": "alignment === \"left\"", "class.cub-label-container-right": "alignment === \"right\"", "class.cub-label-container-fill": "widthMode === \"fill\"", "class.cub-label-container-auto": "widthMode === \"auto\"", "class.cub-label-container-fixed": "widthMode === \"fixed\"" }, classAttribute: "cub-label-container" }, queries: [{ propertyName: "_labelSuffixChildren", predicate: CUB_SUFFIX, descendants: true }, { propertyName: "_labelEndChildren", predicate: CUB_END, descendants: true }], viewQueries: [{ propertyName: "label", first: true, predicate: ["label"], descendants: true, read: ElementRef, static: true }], ngImport: i0, template: "<div class=\"cub-label-appended\">\n  <label class=\"cub-label\" [id]=\"_labelId\" #label>\n    <!-- \u79FB\u9664\u7A7A\u683C\u5F8C\u7684\u6A19\u984C\u5167\u6587 -->\n    <span [class.cub-label-required]=\"required\">{{ labelContent }}</span>\n    <!-- \u539F\u6A19\u984C\u5167\u6587 -->\n    <span class=\"cub-hidden\" (cubCdkObserveContent)=\"observeContent($event)\">\n      <ng-content></ng-content>\n    </span>\n  </label>\n\n  <span class=\"cub-label-suffix\" *ngIf=\"_labelSuffixChildren.length\">\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </span>\n</div>\n\n<span class=\"cub-label-end\" *ngIf=\"_labelEndChildren.length\">\n  <ng-content select=\"[cubEnd]\"></ng-content>\n</span>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: CubCdkObserveContent, selector: "[cubCdkObserveContent]", inputs: ["cubCdkObserveContentDisabled", "debounce"], outputs: ["cubCdkObserveContent"], exportAs: ["cubCdkObserveContent"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLabel, decorators: [{
            type: Component,
            args: [{ selector: 'cub-label', host: {
                        class: 'cub-label-container',
                        '[class.cub-label-container-small]': 'size === "small"',
                        '[class.cub-label-container-left]': 'alignment === "left"',
                        '[class.cub-label-container-right]': 'alignment === "right"',
                        '[class.cub-label-container-fill]': 'widthMode === "fill"',
                        '[class.cub-label-container-auto]': 'widthMode === "auto"',
                        '[class.cub-label-container-fixed]': 'widthMode === "fixed"',
                    }, imports: [NgIf, CubCdkObserveContent], template: "<div class=\"cub-label-appended\">\n  <label class=\"cub-label\" [id]=\"_labelId\" #label>\n    <!-- \u79FB\u9664\u7A7A\u683C\u5F8C\u7684\u6A19\u984C\u5167\u6587 -->\n    <span [class.cub-label-required]=\"required\">{{ labelContent }}</span>\n    <!-- \u539F\u6A19\u984C\u5167\u6587 -->\n    <span class=\"cub-hidden\" (cubCdkObserveContent)=\"observeContent($event)\">\n      <ng-content></ng-content>\n    </span>\n  </label>\n\n  <span class=\"cub-label-suffix\" *ngIf=\"_labelSuffixChildren.length\">\n    <ng-content select=\"[cubSuffix]\"></ng-content>\n  </span>\n</div>\n\n<span class=\"cub-label-end\" *ngIf=\"_labelEndChildren.length\">\n  <ng-content select=\"[cubEnd]\"></ng-content>\n</span>\n" }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { _labelSuffixChildren: [{
                type: ContentChildren,
                args: [CUB_SUFFIX, { descendants: true }]
            }], _labelEndChildren: [{
                type: ContentChildren,
                args: [CUB_END, { descendants: true }]
            }], label: [{
                type: ViewChild,
                args: ['label', { read: ElementRef, static: true }]
            }], required: [{
                type: Input
            }], size: [{
                type: Input
            }], alignment: [{
                type: Input
            }], widthMode: [{
                type: Input
            }], customWidth: [{
                type: Input
            }] } });

class CubLabelModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubLabelModule, imports: [CubCommonModule,
            /** Component */
            CubLabel], exports: [CubCommonModule,
            /** Component */
            CubLabel] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLabelModule, imports: [CubCommonModule, CubCommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        /** Component */
                        CubLabel,
                    ],
                    exports: [
                        CubCommonModule,
                        /** Component */
                        CubLabel,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/label
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubLabel, CubLabelModule };
//# sourceMappingURL=cub-lib-view-rootng-component-label.mjs.map
