import * as i0 from '@angular/core';
import { InjectionToken, Injectable, EventEmitter, DOCUMENT, ViewChild, Output, Input, Optional, Inject, ViewEncapsulation, ChangeDetectionStrategy, Component, QueryList, ContentChild, ContentChildren, Directive, NgModule } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { BehaviorSubject, Subject, fromEvent, merge } from 'rxjs';
import { filter, map, mapTo, takeUntil, distinctUntilChanged, take, startWith, debounceTime } from 'rxjs/operators';
import * as i5 from 'cub-lib-view-rootng/cdk/scrolling';
import { CubCdkScrollable, CubCdkScrollableModule } from 'cub-lib-view-rootng/cdk/scrolling';
import { coerceBooleanProperty, coerceNumberProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { ESCAPE, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { CubCdkPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import * as i2 from 'cub-lib-view-rootng/cdk/platform';
import * as i4 from 'cub-lib-view-rootng/cdk/bidi';

const CubLayoutAnimations = {
    transformLayout: trigger('transform', [
        state('open, open-instant', style({
            transform: 'none',
            visibility: 'visible',
        })),
        state('void', style({
            'box-shadow': 'none',
            visibility: 'hidden',
        })),
        transition('void => open-instant', animate('0ms')),
        transition('void <=> open, open-instant => void', animate('400ms cubic-bezier(0.25, 0.8, 0.25, 1)')),
    ]),
};

function throwCubDuplicatedLayoutError(position) {
    throw Error(`A layout was already declared for 'position="${position}"'`);
}
function throwCubDuplicatedStickyBarError(position) {
    throw Error(`A sticky action bar was already declared for 'position="${position}"'`);
}
function CUB_LAYOUT_DEFAULT_AUTOSIZE_FACTORY() {
    return false;
}

const CUB_LAYOUT_DEFAULT_AUTOSIZE = new InjectionToken('CUB_LAYOUT_DEFAULT_AUTOSIZE', {
    providedIn: 'root',
    factory: CUB_LAYOUT_DEFAULT_AUTOSIZE_FACTORY,
});
const CUB_LAYOUT_CONTAINER = new InjectionToken('CUB_LAYOUT_CONTAINER');

class CubLayoutService {
    constructor() {
        this.stickyBarSource = new BehaviorSubject([]);
        this.stickyBarSource$ = this.stickyBarSource.asObservable();
        this.contentMarginCheck = new Subject();
        this.contentMarginCheck$ = this.contentMarginCheck.asObservable();
    }
    /* 將固定操作列新增到 Subject 清單中 */
    registerStickyBar(stickyBar) {
        const stickyBars = new Set(this.stickyBarSource.value);
        stickyBars.add(stickyBar);
        this.stickyBarSource.next(Array.from(stickyBars));
    }
    /* 將固定操作列從 Subject 清單中移除 */
    unregisterStickyBar(stickyBar) {
        const stickyBars = new Set(this.stickyBarSource.value);
        stickyBars.delete(stickyBar);
        this.stickyBarSource.next(Array.from(stickyBars));
    }
    /* 當面版尺寸更新時發出事件 */
    onPanelResize(width) {
        this.contentMarginCheck.next(width);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

class CubLayoutPanel {
    /** 元件顯示的位置，有效值為 'start' 與 'end'，預設為 'start'。 */
    get position() {
        return this._position;
    }
    set position(value) {
        value = value === 'end' ? 'end' : 'start';
        if (value !== this._position) {
            if (this._isAttached) {
                this._updatePositionInParent(value);
            }
            this._position = value;
            this.onPositionChanged.emit();
        }
    }
    /** 元件的顯示模式，有效值為 'over'、'push' 與 'side'，預設為 'over'。 */
    /** 'over' 表示懸浮在內容區塊之上，並顯示遮罩覆蓋住內容區塊。 */
    /** 'push' 表示將內容區塊推開，並顯示遮罩覆蓋住內容區塊。 */
    /** 'side' 表示與內容區塊並排顯示，縮小內容區塊顯示寬度。 */
    get mode() {
        return this._mode;
    }
    set mode(value) {
        this._mode = value;
        this._updateFocusTrapState();
        this._modeChanged.next();
    }
    /** 是否禁止使用退出鍵或點擊背景來關閉抽屜，預設為 false。 */
    get disableClose() {
        return this._disableClose;
    }
    set disableClose(value) {
        this._disableClose = coerceBooleanProperty(value);
    }
    /** 元件開啟時，是否自動聚焦於第一個可聚焦元素，預設為 undefined。 */
    get autoFocus() {
        if (this._autoFocus == null) {
            return this.mode === 'side' ? 'dialog' : 'first-tabbable';
        }
        return this._autoFocus;
    }
    set autoFocus(value) {
        if (value === 'true' || value === 'false' || value == null) {
            value = coerceBooleanProperty(value);
        }
        this._autoFocus = value;
    }
    /** 元件是否開啟，預設為 false。 */
    get opened() {
        return this._opened;
    }
    set opened(value) {
        this.toggle(coerceBooleanProperty(value));
    }
    constructor(_elementRef, _focusTrapFactory, _focusMonitor, _platform, _ngZone, _layoutService, _interactivityChecker, _doc, _container) {
        this._elementRef = _elementRef;
        this._focusTrapFactory = _focusTrapFactory;
        this._focusMonitor = _focusMonitor;
        this._platform = _platform;
        this._ngZone = _ngZone;
        this._layoutService = _layoutService;
        this._interactivityChecker = _interactivityChecker;
        this._doc = _doc;
        this._container = _container;
        this._animationState = 'void';
        this._modeChanged = new Subject();
        this._animationStarted = new Subject();
        this._animationEnd = new Subject();
        this._position = 'start';
        this._mode = 'over';
        this._disableClose = false;
        this._opened = false;
        this._openedVia = null;
        this._elementFocusedBeforeLayoutWasOpened = null;
        this._enableAnimations = false;
        this._isAttached = false;
        this._anchor = null;
        this._destroyed = new Subject();
        /** 當開啟狀態改變時調用的通知事件。 */
        this.openedChange = new EventEmitter(/* isAsync */ true);
        /** 當開啟時調用的通知事件。 */
        this._openedStream = this.openedChange.pipe(filter((o) => o), map(() => { }));
        /** 當開始開啟時調用的通知事件。 */
        this.openedStart = this._animationStarted.pipe(filter((e) => e.fromState !== e.toState && e.toState.indexOf('open') === 0), mapTo(undefined));
        /** 當關閉時調用的通知事件。 */
        this._closedStream = this.openedChange.pipe(filter((o) => !o), map(() => { }));
        /** 當開始關閉時調用的通知事件。 */
        this.closedStart = this._animationStarted.pipe(filter((e) => e.fromState !== e.toState && e.toState === 'void'), mapTo(undefined));
        // tslint:disable-next-line:no-output-on-prefix
        this.onPositionChanged = new EventEmitter();
        this.openedChange.subscribe((opened) => {
            if (opened) {
                if (this._doc) {
                    this._elementFocusedBeforeLayoutWasOpened = this._doc
                        .activeElement;
                }
                this._takeFocus();
            }
            else if (this._isFocusWithinLayout()) {
                this._restoreFocus(this._openedVia || 'program');
            }
        });
        this._ngZone.runOutsideAngular(() => {
            fromEvent(this._elementRef.nativeElement, 'keydown')
                .pipe(filter((event) => {
                return (event.keyCode === ESCAPE &&
                    !this.disableClose &&
                    !hasModifierKey(event));
            }), takeUntil(this._destroyed))
                .subscribe((event) => this._ngZone.run(() => {
                this.close();
                event.stopPropagation();
                event.preventDefault();
            }));
        });
        // We need a Subject with distinctUntilChanged, because the `done` event
        // fires twice on some browsers. See https://github.com/angular/angular/issues/24084
        this._animationEnd
            .pipe(distinctUntilChanged((x, y) => {
            return x.fromState === y.fromState && x.toState === y.toState;
        }))
            .subscribe((event) => {
            const { fromState, toState } = event;
            if ((toState.indexOf('open') === 0 && fromState === 'void') ||
                (toState === 'void' && fromState.indexOf('open') === 0)) {
                this.openedChange.emit(this._opened);
            }
        });
    }
    ngAfterViewInit() {
        this._isAttached = true;
        this._focusTrap = this._focusTrapFactory.create(this._elementRef.nativeElement);
        this._updateFocusTrapState();
        if (this._position === 'end') {
            this._updatePositionInParent('end');
        }
        this._registeredObserver();
        if (this.resizeObserver) {
            this.resizeObserver.observe(this._elementRef.nativeElement);
        }
    }
    ngAfterContentChecked() {
        if (this._platform.isBrowser) {
            this._enableAnimations = true;
        }
    }
    ngOnDestroy() {
        if (this._focusTrap) {
            this._focusTrap.destroy();
        }
        this._anchor?.remove();
        this._anchor = null;
        this._animationStarted.complete();
        this._animationEnd.complete();
        this._modeChanged.complete();
        this._destroyed.next();
        this._destroyed.complete();
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this._elementRef.nativeElement);
        }
    }
    open(openedVia) {
        return this.toggle(true, openedVia);
    }
    close() {
        return this.toggle(false);
    }
    toggle(isOpen = !this.opened, openedVia) {
        if (isOpen && openedVia) {
            this._openedVia = openedVia;
        }
        const result = this._setOpen(isOpen, !isOpen && this._isFocusWithinLayout(), this._openedVia || 'program');
        if (!isOpen) {
            this._openedVia = null;
        }
        return result;
    }
    _closeViaBackdropClick() {
        return this._setOpen(/* isOpen */ false, /* restoreFocus */ true, 'mouse');
    }
    _getWidth() {
        return this._elementRef.nativeElement
            ? this._elementRef.nativeElement.offsetWidth || 0
            : 0;
    }
    _registeredObserver() {
        try {
            this.resizeObserver = new ResizeObserver((entries) => {
                const width = entries[0].contentRect.width;
                this._layoutService.onPanelResize(width);
            });
        }
        catch (error) {
            this.resizeObserver = undefined;
        }
    }
    _forceFocus(element, options) {
        if (!this._interactivityChecker.isFocusable(element)) {
            element.tabIndex = -1;
            // The tabindex attribute should be removed to avoid navigating to that element again
            this._ngZone.runOutsideAngular(() => {
                const callback = () => {
                    element.removeEventListener('blur', callback);
                    element.removeEventListener('mousedown', callback);
                    element.removeAttribute('tabindex');
                };
                element.addEventListener('blur', callback);
                element.addEventListener('mousedown', callback);
            });
        }
        element.focus(options);
    }
    _focusByCssSelector(selector, options) {
        let elementToFocus = this._elementRef.nativeElement.querySelector(selector);
        if (elementToFocus) {
            this._forceFocus(elementToFocus, options);
        }
    }
    _takeFocus() {
        if (!this._focusTrap) {
            return;
        }
        const element = this._elementRef.nativeElement;
        switch (this.autoFocus) {
            case false:
            case 'dialog':
                return;
            case true:
            case 'first-tabbable':
                this._focusTrap
                    .focusInitialElementWhenReady()
                    .then((hasMovedFocus) => {
                    if (!hasMovedFocus &&
                        typeof this._elementRef.nativeElement.focus === 'function') {
                        element.focus();
                    }
                });
                break;
            case 'first-heading':
                this._focusByCssSelector('h1, h2, h3, h4, h5, h6, [role="heading"]');
                break;
            default:
                this._focusByCssSelector(this.autoFocus);
                break;
        }
    }
    _restoreFocus(focusOrigin) {
        if (this.autoFocus === 'dialog') {
            return;
        }
        if (this._elementFocusedBeforeLayoutWasOpened) {
            this._focusMonitor.focusVia(this._elementFocusedBeforeLayoutWasOpened, focusOrigin);
        }
        else {
            this._elementRef.nativeElement.blur();
        }
        this._elementFocusedBeforeLayoutWasOpened = null;
    }
    _isFocusWithinLayout() {
        const activeEl = this._doc.activeElement;
        return !!activeEl && this._elementRef.nativeElement.contains(activeEl);
    }
    _setOpen(isOpen, restoreFocus, focusOrigin) {
        this._opened = isOpen;
        if (isOpen) {
            this._animationState = this._enableAnimations ? 'open' : 'open-instant';
        }
        else {
            this._animationState = 'void';
            if (restoreFocus) {
                this._restoreFocus(focusOrigin);
            }
        }
        this._updateFocusTrapState();
        return new Promise((resolve) => {
            this.openedChange
                .pipe(take(1))
                .subscribe((open) => resolve(open ? 'open' : 'close'));
        });
    }
    _updateFocusTrapState() {
        if (this._focusTrap) {
            this._focusTrap.enabled = this.opened && this.mode !== 'side';
        }
    }
    _updatePositionInParent(newPosition) {
        const element = this._elementRef.nativeElement;
        const parent = element.parentNode;
        if (newPosition === 'end') {
            if (!this._anchor) {
                this._anchor = this._doc.createComment('cub-layout-panel-anchor');
                parent.insertBefore(this._anchor, element);
            }
            parent.appendChild(element);
        }
        else if (this._anchor) {
            this._anchor.parentNode.insertBefore(element, this._anchor);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutPanel, deps: [{ token: i0.ElementRef }, { token: i1.FocusTrapFactory }, { token: i1.FocusMonitor }, { token: i2.Platform }, { token: i0.NgZone }, { token: CubLayoutService }, { token: i1.InteractivityChecker }, { token: DOCUMENT, optional: true }, { token: CUB_LAYOUT_CONTAINER, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubLayoutPanel, isStandalone: true, selector: "cub-layout-panel", inputs: { position: "position", mode: "mode", disableClose: "disableClose", autoFocus: "autoFocus", opened: "opened" }, outputs: { openedChange: "openedChange", _openedStream: "opened", openedStart: "openedStart", _closedStream: "closed", closedStart: "closedStart", onPositionChanged: "positionChanged" }, host: { attributes: { "tabIndex": "-1" }, listeners: { "@transform.start": "_animationStarted.next($event)", "@transform.done": "_animationEnd.next($event)" }, properties: { "attr.align": "null", "class.cub-layout-panel-start": "position === \"start\"", "class.cub-layout-panel-end": "position === \"end\"", "class.cub-layout-panel-over": "mode === \"over\"", "class.cub-layout-panel-push": "mode === \"push\"", "class.cub-layout-panel-side": "mode === \"side\"", "class.cub-layout-panel-opened": "opened", "@transform": "_animationState" }, classAttribute: "cub-layout-panel" }, providers: [CubLayoutService], viewQueries: [{ propertyName: "_content", first: true, predicate: ["content"], descendants: true }], exportAs: ["cubLayoutPanel"], ngImport: i0, template: `<div class="cub-layout-panel-container" cubCdkScrollable #content>
    <ng-content></ng-content>
  </div>`, isInline: true, dependencies: [{ kind: "directive", type: CubCdkScrollable, selector: "[cub-cdk-scrollable], [cubCdkScrollable]" }], animations: [CubLayoutAnimations.transformLayout], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutPanel, decorators: [{
            type: Component,
            args: [{
                    selector: 'cub-layout-panel',
                    exportAs: 'cubLayoutPanel',
                    template: `<div class="cub-layout-panel-container" cubCdkScrollable #content>
    <ng-content></ng-content>
  </div>`,
                    animations: [CubLayoutAnimations.transformLayout],
                    host: {
                        class: 'cub-layout-panel',
                        '[attr.align]': 'null',
                        '[class.cub-layout-panel-start]': 'position === "start"',
                        '[class.cub-layout-panel-end]': 'position === "end"',
                        '[class.cub-layout-panel-over]': 'mode === "over"',
                        '[class.cub-layout-panel-push]': 'mode === "push"',
                        '[class.cub-layout-panel-side]': 'mode === "side"',
                        '[class.cub-layout-panel-opened]': 'opened',
                        tabIndex: '-1',
                        '[@transform]': '_animationState',
                        '(@transform.start)': '_animationStarted.next($event)',
                        '(@transform.done)': '_animationEnd.next($event)',
                    },
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [CubLayoutService],
                    imports: [CubCdkScrollable],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusTrapFactory }, { type: i1.FocusMonitor }, { type: i2.Platform }, { type: i0.NgZone }, { type: CubLayoutService }, { type: i1.InteractivityChecker }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: CubLayoutContainer, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_LAYOUT_CONTAINER]
                }] }], propDecorators: { position: [{
                type: Input
            }], mode: [{
                type: Input
            }], disableClose: [{
                type: Input
            }], autoFocus: [{
                type: Input
            }], opened: [{
                type: Input
            }], openedChange: [{
                type: Output
            }], _openedStream: [{
                type: Output,
                args: ['opened']
            }], openedStart: [{
                type: Output
            }], _closedStream: [{
                type: Output,
                args: ['closed']
            }], closedStart: [{
                type: Output
            }], onPositionChanged: [{
                type: Output,
                args: ['positionChanged']
            }], _content: [{
                type: ViewChild,
                args: ['content']
            }] } });
class CubLayoutContent {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutContent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubLayoutContent, isStandalone: true, selector: "cub-layout-content", host: { classAttribute: "cub-layout-content" }, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutContent, decorators: [{
            type: Component,
            args: [{
                    selector: 'cub-layout-content',
                    template: '<ng-content></ng-content>',
                    host: {
                        class: 'cub-layout-content',
                    },
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                }]
        }], ctorParameters: () => [] });
class CubLayoutContainer {
    get start() {
        return this._start;
    }
    get end() {
        return this._end;
    }
    /** 元件尺寸改變時，是否自動調整容器大小，預設為 undefined。 */
    get autosize() {
        return this._autosize;
    }
    set autosize(value) {
        this._autosize = coerceBooleanProperty(value);
    }
    /** 元件打開時，是否顯示遮罩背景，預設為 null。 */
    get hasBackdrop() {
        if (this._backdropOverride == null) {
            return (!this._start ||
                this._start.mode !== 'side' ||
                !this._end ||
                this._end.mode !== 'side');
        }
        return this._backdropOverride;
    }
    set hasBackdrop(value) {
        this._backdropOverride =
            value == null ? null : coerceBooleanProperty(value);
    }
    constructor(layoutService, _dir, _element, _ngZone, _changeDetectorRef, viewportRuler, defaultAutosize = false, _animationMode) {
        this.layoutService = layoutService;
        this._dir = _dir;
        this._element = _element;
        this._ngZone = _ngZone;
        this._changeDetectorRef = _changeDetectorRef;
        this._animationMode = _animationMode;
        this._backdropOverride = null;
        this._contentMargins = {
            left: null,
            right: null,
        };
        this._contentPaddings = {
            top: 0,
            bottom: 0,
        };
        this._stickyBars = [];
        this._stickyTopBar = null;
        this._stickyBottomBar = null;
        this._layoutPanels = new QueryList();
        this._contentMarginChanges = new Subject();
        this._contentPaddingChanges = new Subject();
        this._start = null;
        this._end = null;
        this._left = null;
        this._right = null;
        this._destroyed = new Subject();
        this._doCheckSubject = new Subject();
        /** 當點擊遮罩背景時調用的通知事件。 */
        this.backdropClick = new EventEmitter();
        if (_dir) {
            _dir.change.pipe(takeUntil(this._destroyed)).subscribe(() => {
                this._validateLayouts();
                this.updateContentMargins();
                this.updateContentPaddings();
            });
        }
        viewportRuler
            .change()
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => {
            this.updateContentMargins();
            this.updateContentPaddings();
        });
        this._autosize = defaultAutosize;
    }
    ngAfterContentInit() {
        this._allLayoutPanels.changes
            .pipe(startWith(this._allLayoutPanels), takeUntil(this._destroyed))
            .subscribe((layout) => {
            this._layoutPanels.reset(layout.filter((item) => !item._container || item._container === this));
            this._layoutPanels.notifyOnChanges();
        });
        this._layoutPanels.changes.pipe(startWith(null)).subscribe(() => {
            this._validateLayouts();
            this._layoutPanels.forEach((layout) => {
                this._watchLayoutToggle(layout);
                this._watchLayoutPosition(layout);
                this._watchLayoutMode(layout);
            });
            if (!this._layoutPanels.length ||
                this._isLayoutOpen(this._start) ||
                this._isLayoutOpen(this._end)) {
                this.updateContentMargins();
            }
            this._changeDetectorRef.markForCheck();
        });
        this._ngZone.runOutsideAngular(() => {
            this._doCheckSubject
                .pipe(debounceTime(10), takeUntil(this._destroyed))
                .subscribe((spacing) => {
                if (spacing === 'margin') {
                    this.updateContentMargins();
                }
                else {
                    this.updateContentPaddings();
                }
            });
        });
        this.layoutService.stickyBarSource$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe((stickyBars) => {
            this._stickyBars = stickyBars;
            this._validateStickyBars();
            this.updateContentPaddings();
        });
        this.layoutService.contentMarginCheck$
            .pipe(debounceTime(10), takeUntil(this._destroyed))
            .subscribe(() => {
            this.updateContentMargins();
            this._changeDetectorRef.markForCheck();
        });
    }
    ngDoCheck() {
        if (this._autosize && this._isPushed()) {
            this._ngZone.runOutsideAngular(() => this._doCheckSubject.next('margin'));
        }
        if (this._stickyTopBar || this._stickyBottomBar) {
            this._ngZone.runOutsideAngular(() => this._doCheckSubject.next('padding'));
        }
    }
    ngOnDestroy() {
        this._contentMarginChanges.complete();
        this._contentPaddingChanges.complete();
        this._doCheckSubject.complete();
        this._layoutPanels.destroy();
        this._destroyed.next();
        this._destroyed.complete();
    }
    open() {
        this._layoutPanels.forEach((layout) => layout.open());
    }
    close() {
        this._layoutPanels.forEach((layout) => layout.close());
    }
    updateContentMargins() {
        // 1. For layouts in `over` mode, they don't affect the content.
        // 2. For layouts in `side` mode they should shrink the content. We do this by adding to the
        //    left margin (for left layout) or right margin (for right the layout).
        // 3. For layouts in `push` mode the should shift the content without resizing it. We do this by
        //    adding to the left or right margin and simultaneously subtracting the same amount of
        //    margin from the other side.
        let left = 0;
        let right = 0;
        if (this._left && this._left.opened) {
            if (this._left.mode == 'side') {
                left += this._left._getWidth();
            }
            else if (this._left.mode == 'push') {
                const width = this._left._getWidth();
                left += width;
                right -= width;
            }
        }
        if (this._right && this._right.opened) {
            if (this._right.mode == 'side') {
                right += this._right._getWidth();
            }
            else if (this._right.mode == 'push') {
                const width = this._right._getWidth();
                right += width;
                left -= width;
            }
        }
        left = left || null;
        right = right || null;
        if (left !== this._contentMargins.left ||
            right !== this._contentMargins.right) {
            this._contentMargins = { left, right };
            this._ngZone.run(() => this._contentMarginChanges.next(this._contentMargins));
        }
    }
    updateContentPaddings() {
        let top = 0;
        let bottom = 0;
        if (this._stickyTopBar && this._layoutStickyTopBar) {
            top += this._layoutStickyTopBar.nativeElement.offsetHeight;
        }
        if (this._stickyBottomBar && this._layoutStickyBottomBar) {
            const STICKY_BAR_MARGIN_TOP = 0;
            bottom +=
                this._layoutStickyBottomBar.nativeElement.offsetHeight +
                    STICKY_BAR_MARGIN_TOP;
        }
        top = top || 0;
        bottom = bottom || 0;
        if (top !== this._contentPaddings.top ||
            bottom !== this._contentPaddings.bottom) {
            this._contentPaddings = { top, bottom };
            this._ngZone.run(() => {
                this._contentPaddingChanges.next(this._contentPaddings);
            });
        }
        this._changeDetectorRef.detectChanges();
    }
    _isPushed() {
        return ((this._isLayoutOpen(this._start) && this._start.mode != 'over') ||
            (this._isLayoutOpen(this._end) && this._end.mode != 'over'));
    }
    _onBackdropClicked() {
        this.backdropClick.emit();
        this._closeModalLayoutsViaBackdrop();
    }
    _closeModalLayoutsViaBackdrop() {
        [this._start, this._end]
            .filter((layout) => layout && !layout.disableClose && this._canHaveBackdrop(layout))
            .forEach((layout) => layout._closeViaBackdropClick());
    }
    _isShowingBackdrop() {
        return ((this._isLayoutOpen(this._start) && this._canHaveBackdrop(this._start)) ||
            (this._isLayoutOpen(this._end) && this._canHaveBackdrop(this._end)));
    }
    _watchLayoutToggle(layout) {
        layout._animationStarted
            .pipe(filter((event) => event.fromState !== event.toState), takeUntil(this._layoutPanels.changes))
            .subscribe((event) => {
            if (event.toState !== 'open-instant' &&
                this._animationMode !== 'NoopAnimations') {
                this._element.nativeElement.classList.add('cub-layout-transition');
            }
            this.updateContentMargins();
            this._changeDetectorRef.markForCheck();
        });
        if (layout.mode !== 'side') {
            layout.openedChange
                .pipe(takeUntil(this._layoutPanels.changes))
                .subscribe(() => this._setContainerClass(layout.opened));
        }
    }
    _watchLayoutPosition(layout) {
        if (!layout) {
            return;
        }
        layout.onPositionChanged
            .pipe(takeUntil(this._layoutPanels.changes))
            .subscribe(() => {
            this._ngZone.onMicrotaskEmpty.pipe(take(1)).subscribe(() => {
                this._validateLayouts();
            });
        });
    }
    _watchLayoutMode(layout) {
        if (layout) {
            layout._modeChanged
                .pipe(takeUntil(merge(this._layoutPanels.changes, this._destroyed)))
                .subscribe(() => {
                this.updateContentMargins();
                this._changeDetectorRef.markForCheck();
            });
        }
    }
    _setContainerClass(isAdd) {
        const classList = this._element.nativeElement.classList;
        const className = 'cub-layout-container-has-open';
        if (isAdd) {
            classList.add(className);
        }
        else {
            classList.remove(className);
        }
    }
    _validateStickyBars() {
        this._stickyTopBar = this._stickyBottomBar = null;
        this._stickyBars.forEach((bar) => {
            if (bar.position == 'top') {
                if (this._stickyTopBar != null) {
                    throwCubDuplicatedStickyBarError('top');
                }
                this._stickyTopBar = bar;
            }
            else {
                if (this._stickyBottomBar != null) {
                    throwCubDuplicatedStickyBarError('bottom');
                }
                this._stickyBottomBar = bar;
            }
        });
    }
    _validateLayouts() {
        this._start = this._end = null;
        this._layoutPanels.forEach((layout) => {
            if (layout.position == 'end') {
                if (this._end != null) {
                    throwCubDuplicatedLayoutError('end');
                }
                this._end = layout;
            }
            else {
                if (this._start != null) {
                    throwCubDuplicatedLayoutError('start');
                }
                this._start = layout;
            }
        });
        this._right = this._left = null;
        if (this._dir && this._dir.value === 'rtl') {
            this._left = this._end;
            this._right = this._start;
        }
        else {
            this._left = this._start;
            this._right = this._end;
        }
    }
    _canHaveBackdrop(layout) {
        return layout.mode !== 'side' || !!this._backdropOverride;
    }
    _isLayoutOpen(layout) {
        return layout != null && layout.opened;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutContainer, deps: [{ token: CubLayoutService }, { token: i4.Directionality, optional: true }, { token: i0.ElementRef }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i5.ViewportRuler }, { token: CUB_LAYOUT_DEFAULT_AUTOSIZE }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubLayoutContainer, isStandalone: true, selector: "cub-layout-container", inputs: { autosize: "autosize", hasBackdrop: "hasBackdrop" }, outputs: { backdropClick: "backdropClick" }, host: { properties: { "class.cub-layout-container-explicit-backdrop": "_backdropOverride" }, classAttribute: "cub-layout-container" }, providers: [
            CubLayoutService,
            {
                provide: CUB_LAYOUT_CONTAINER,
                useExisting: CubLayoutContainer,
            },
        ], queries: [{ propertyName: "_content", first: true, predicate: CubLayoutContent, descendants: true }, { propertyName: "_allLayoutPanels", predicate: CubLayoutPanel, descendants: true }], viewQueries: [{ propertyName: "_layoutContent", first: true, predicate: CubLayoutContent, descendants: true }, { propertyName: "portalOutlet", first: true, predicate: CubCdkPortalOutlet, descendants: true }, { propertyName: "_layoutStickyTopBar", first: true, predicate: ["stickyTopBar"], descendants: true }, { propertyName: "_layoutStickyBottomBar", first: true, predicate: ["stickyBottomBar"], descendants: true }], exportAs: ["cubLayoutContainer"], ngImport: i0, template: "@if (hasBackdrop) {\n<div\n  class=\"cub-layout-backdrop\"\n  [class.cub-layout-visible]=\"_isShowingBackdrop()\"\n  (click)=\"_onBackdropClicked()\"\n></div>\n}\n\n<!-- \u9801\u9996 -->\n<ng-content select=\"[cubLayoutHeader]\"></ng-content>\n\n<div class=\"cub-layout-inner-container\">\n  <!-- \u5074\u908A\u6B04 -->\n  <ng-content select=\"[cubLayoutPanel]\"></ng-content>\n\n  <div\n    class=\"cub-layout-sticky-container\"\n    [style.margin-left.px]=\"_contentMargins.left\"\n    [style.margin-right.px]=\"_contentMargins.right\"\n  >\n    <!-- \u4E0A\u65B9\u91D8\u9078\u5340\u584A -->\n    @if (_stickyTopBar) {\n    <div class=\"cub-sticky-action-bar cub-sticky-action-bar-top\" #stickyTopBar>\n      <ng-container *ngTemplateOutlet=\"_stickyTopBar.stickyBar\"></ng-container>\n    </div>\n    }\n\n    <div\n      class=\"cub-layout-content-container\"\n      [style.padding-top.px]=\"_contentPaddings.top\"\n      [style.padding-bottom.px]=\"_contentPaddings.bottom\"\n      cubCdkScrollable\n    >\n      <!-- \u9801\u9762\u5167\u5BB9 -->\n      <ng-content select=\"cub-layout-content\"></ng-content>\n      @if (!_content) {\n      <cub-layout-content>\n        <ng-content></ng-content>\n      </cub-layout-content>\n      }\n\n      <!-- \u9801\u5C3E -->\n      <ng-content select=\"[cubLayoutFooter]\"></ng-content>\n    </div>\n\n    <!-- \u4E0B\u65B9\u91D8\u9078\u5340\u584A -->\n    @if (_stickyBottomBar) {\n    <div\n      class=\"cub-sticky-action-bar cub-sticky-action-bar-bottom\"\n      #stickyBottomBar\n    >\n      <ng-container\n        *ngTemplateOutlet=\"_stickyBottomBar.stickyBar\"\n      ></ng-container>\n    </div>\n    }\n  </div>\n</div>\n\n<div class=\"cub-layout-overlay-container\">\n  <ng-template\n    cubCdkPortalOutlet\n    #portalOutlet=\"cubCdkPortalOutlet\"\n  ></ng-template>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: CubCdkScrollable, selector: "[cub-cdk-scrollable], [cubCdkScrollable]" }, { kind: "component", type: CubLayoutContent, selector: "cub-layout-content" }, { kind: "directive", type: CubCdkPortalOutlet, selector: "[cubCdkPortalOutlet]", inputs: ["cubCdkPortalOutlet"], outputs: ["attached"], exportAs: ["cubCdkPortalOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutContainer, decorators: [{
            type: Component,
            args: [{ selector: 'cub-layout-container', exportAs: 'cubLayoutContainer', host: {
                        class: 'cub-layout-container',
                        '[class.cub-layout-container-explicit-backdrop]': '_backdropOverride',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, providers: [
                        CubLayoutService,
                        {
                            provide: CUB_LAYOUT_CONTAINER,
                            useExisting: CubLayoutContainer,
                        },
                    ], imports: [
                        NgTemplateOutlet,
                        CubCdkScrollable,
                        CubLayoutContent,
                        CubCdkPortalOutlet,
                    ], template: "@if (hasBackdrop) {\n<div\n  class=\"cub-layout-backdrop\"\n  [class.cub-layout-visible]=\"_isShowingBackdrop()\"\n  (click)=\"_onBackdropClicked()\"\n></div>\n}\n\n<!-- \u9801\u9996 -->\n<ng-content select=\"[cubLayoutHeader]\"></ng-content>\n\n<div class=\"cub-layout-inner-container\">\n  <!-- \u5074\u908A\u6B04 -->\n  <ng-content select=\"[cubLayoutPanel]\"></ng-content>\n\n  <div\n    class=\"cub-layout-sticky-container\"\n    [style.margin-left.px]=\"_contentMargins.left\"\n    [style.margin-right.px]=\"_contentMargins.right\"\n  >\n    <!-- \u4E0A\u65B9\u91D8\u9078\u5340\u584A -->\n    @if (_stickyTopBar) {\n    <div class=\"cub-sticky-action-bar cub-sticky-action-bar-top\" #stickyTopBar>\n      <ng-container *ngTemplateOutlet=\"_stickyTopBar.stickyBar\"></ng-container>\n    </div>\n    }\n\n    <div\n      class=\"cub-layout-content-container\"\n      [style.padding-top.px]=\"_contentPaddings.top\"\n      [style.padding-bottom.px]=\"_contentPaddings.bottom\"\n      cubCdkScrollable\n    >\n      <!-- \u9801\u9762\u5167\u5BB9 -->\n      <ng-content select=\"cub-layout-content\"></ng-content>\n      @if (!_content) {\n      <cub-layout-content>\n        <ng-content></ng-content>\n      </cub-layout-content>\n      }\n\n      <!-- \u9801\u5C3E -->\n      <ng-content select=\"[cubLayoutFooter]\"></ng-content>\n    </div>\n\n    <!-- \u4E0B\u65B9\u91D8\u9078\u5340\u584A -->\n    @if (_stickyBottomBar) {\n    <div\n      class=\"cub-sticky-action-bar cub-sticky-action-bar-bottom\"\n      #stickyBottomBar\n    >\n      <ng-container\n        *ngTemplateOutlet=\"_stickyBottomBar.stickyBar\"\n      ></ng-container>\n    </div>\n    }\n  </div>\n</div>\n\n<div class=\"cub-layout-overlay-container\">\n  <ng-template\n    cubCdkPortalOutlet\n    #portalOutlet=\"cubCdkPortalOutlet\"\n  ></ng-template>\n</div>\n" }]
        }], ctorParameters: () => [{ type: CubLayoutService }, { type: i4.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.ElementRef }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i5.ViewportRuler }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_LAYOUT_DEFAULT_AUTOSIZE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { autosize: [{
                type: Input
            }], hasBackdrop: [{
                type: Input
            }], backdropClick: [{
                type: Output
            }], _allLayoutPanels: [{
                type: ContentChildren,
                args: [CubLayoutPanel, {
                        descendants: true,
                    }]
            }], _content: [{
                type: ContentChild,
                args: [CubLayoutContent]
            }], _layoutContent: [{
                type: ViewChild,
                args: [CubLayoutContent]
            }], portalOutlet: [{
                type: ViewChild,
                args: [CubCdkPortalOutlet]
            }], _layoutStickyTopBar: [{
                type: ViewChild,
                args: ['stickyTopBar']
            }], _layoutStickyBottomBar: [{
                type: ViewChild,
                args: ['stickyBottomBar']
            }] } });

class CubHeader {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubHeader, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubHeader, isStandalone: true, selector: "cub-header", host: { classAttribute: "cub-header" }, exportAs: ["cubHeader"], ngImport: i0, template: "<ng-content></ng-content>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-header', exportAs: 'cubHeader', host: {
                        class: 'cub-header',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<ng-content></ng-content>\n" }]
        }], ctorParameters: () => [] });

class CubFooter {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFooter, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubFooter, isStandalone: true, selector: "cub-footer", exportAs: ["cubFooter"], ngImport: i0, template: "<footer class=\"cub-footer\">\n  <div class=\"cub-footer-text\">\n    <ng-content></ng-content>\n  </div>\n</footer>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFooter, decorators: [{
            type: Component,
            args: [{ selector: 'cub-footer', exportAs: 'cubFooter', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<footer class=\"cub-footer\">\n  <div class=\"cub-footer-text\">\n    <ng-content></ng-content>\n  </div>\n</footer>\n" }]
        }], ctorParameters: () => [] });

let nextUniqueId = 0;
class CubStickyActionBar {
    constructor(layoutService) {
        this.layoutService = layoutService;
        /**
         元件 id，預設為 'cub-sticky-action-bar-0'。
         */
        this.id = `cub-sticky-action-bar-${nextUniqueId++}`;
        /** 元件顯示的位置，有效值為 'top' 與 'bottom'，預設為 'top'。 */
        this.position = 'top';
    }
    ngAfterViewInit() {
        this.layoutService.registerStickyBar(this);
    }
    ngOnDestroy() {
        this.layoutService.unregisterStickyBar(this);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStickyActionBar, deps: [{ token: CubLayoutService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubStickyActionBar, isStandalone: true, selector: "cub-sticky-action-bar", inputs: { id: "id", position: "position" }, viewQueries: [{ propertyName: "stickyBar", first: true, predicate: ["stickyBar"], descendants: true }], exportAs: ["cubStickyActionBar"], ngImport: i0, template: "<ng-template #stickyBar>\n  <ng-content></ng-content>\n</ng-template>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStickyActionBar, decorators: [{
            type: Component,
            args: [{ selector: 'cub-sticky-action-bar', exportAs: 'cubStickyActionBar', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<ng-template #stickyBar>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: CubLayoutService }], propDecorators: { stickyBar: [{
                type: ViewChild,
                args: ['stickyBar']
            }], id: [{
                type: Input
            }], position: [{
                type: Input
            }] } });

class CubSidebarContent {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarContent, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSidebarContent, isStandalone: true, selector: "cub-sidebar-content", host: { classAttribute: "cub-sidebar-content cub-sidebar-content-spaced" }, exportAs: ["cubSidebarContent"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarContent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-sidebar-content',
                    exportAs: 'cubSidebarContent',
                    host: {
                        class: 'cub-sidebar-content cub-sidebar-content-spaced',
                    },
                }]
        }], ctorParameters: () => [] });

class CubSidebar extends CubLayoutPanel {
    constructor() {
        super(...arguments);
        this._fixedInViewport = false;
        this._fixedTopGap = 0;
        this._fixedBottomGap = 0;
    }
    /** 元件是否固定在可視區域中，預設為 false。 */
    get fixedInViewport() {
        return this._fixedInViewport;
    }
    set fixedInViewport(value) {
        this._fixedInViewport = coerceBooleanProperty(value);
    }
    /** 元件設定為固定模式時，與可視區域上方的間距，預設為 0。 */
    get fixedTopGap() {
        return this._fixedTopGap;
    }
    set fixedTopGap(value) {
        this._fixedTopGap = coerceNumberProperty(value);
    }
    /** 元件設定為固定模式時，與可視區域下方的間距，預設為 0。 */
    get fixedBottomGap() {
        return this._fixedBottomGap;
    }
    set fixedBottomGap(value) {
        this._fixedBottomGap = coerceNumberProperty(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebar, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubSidebar, isStandalone: true, selector: "cub-sidebar", inputs: { fixedInViewport: "fixedInViewport", fixedTopGap: "fixedTopGap", fixedBottomGap: "fixedBottomGap" }, host: { attributes: { "tabIndex": "-1" }, properties: { "attr.align": "null", "class.cub-layout-panel-start": "position === \"start\"", "class.cub-layout-panel-end": "position === \"end\"", "class.cub-layout-panel-over": "mode === \"over\"", "class.cub-layout-panel-push": "mode === \"push\"", "class.cub-layout-panel-side": "mode === \"side\"", "class.cub-layout-panel-opened": "opened", "class.cub-layout-panel-fixed": "fixedInViewport", "style.top.px": "fixedInViewport ? fixedTopGap : null", "style.bottom.px": "fixedInViewport ? fixedBottomGap : null" }, classAttribute: "cub-layout-panel cub-sidebar" }, providers: [{ provide: CubLayoutPanel, useExisting: CubSidebar }], queries: [{ propertyName: "_contentStatic", first: true, predicate: CubSidebarContent, descendants: true, static: true }], exportAs: ["cubSidebar"], usesInheritance: true, ngImport: i0, template: "<div class=\"cub-layout-panel-container cub-sidebar-container\" #content>\n  <ng-content select=\"cub-sidebar-header\"></ng-content>\n\n  <div class=\"cub-sidebar-content-container\" cubCdkScrollable>\n    @if (_contentStatic) {\n    <ng-content select=\"cub-sidebar-content\"></ng-content>\n    } @else {\n    <div class=\"cub-sidebar-content\">\n      <ng-content></ng-content>\n    </div>\n    }\n\n    <ng-content select=\"cub-sidebar-actions\"></ng-content>\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkScrollable, selector: "[cub-cdk-scrollable], [cubCdkScrollable]" }], animations: [CubLayoutAnimations.transformLayout], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebar, decorators: [{
            type: Component,
            args: [{ selector: 'cub-sidebar', exportAs: 'cubSidebar', animations: [CubLayoutAnimations.transformLayout], host: {
                        class: 'cub-layout-panel cub-sidebar',
                        tabIndex: '-1',
                        '[attr.align]': 'null',
                        '[class.cub-layout-panel-start]': 'position === "start"',
                        '[class.cub-layout-panel-end]': 'position === "end"',
                        '[class.cub-layout-panel-over]': 'mode === "over"',
                        '[class.cub-layout-panel-push]': 'mode === "push"',
                        '[class.cub-layout-panel-side]': 'mode === "side"',
                        '[class.cub-layout-panel-opened]': 'opened',
                        '[class.cub-layout-panel-fixed]': 'fixedInViewport',
                        '[style.top.px]': 'fixedInViewport ? fixedTopGap : null',
                        '[style.bottom.px]': 'fixedInViewport ? fixedBottomGap : null',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, providers: [{ provide: CubLayoutPanel, useExisting: CubSidebar }], imports: [CubCdkScrollable], template: "<div class=\"cub-layout-panel-container cub-sidebar-container\" #content>\n  <ng-content select=\"cub-sidebar-header\"></ng-content>\n\n  <div class=\"cub-sidebar-content-container\" cubCdkScrollable>\n    @if (_contentStatic) {\n    <ng-content select=\"cub-sidebar-content\"></ng-content>\n    } @else {\n    <div class=\"cub-sidebar-content\">\n      <ng-content></ng-content>\n    </div>\n    }\n\n    <ng-content select=\"cub-sidebar-actions\"></ng-content>\n  </div>\n</div>\n" }]
        }], propDecorators: { fixedInViewport: [{
                type: Input
            }], fixedTopGap: [{
                type: Input
            }], fixedBottomGap: [{
                type: Input
            }], _contentStatic: [{
                type: ContentChild,
                args: [CubSidebarContent, { static: true }]
            }] } });

class CubSidebarHeader {
    constructor() { }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarHeader, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubSidebarHeader, isStandalone: true, selector: "cub-sidebar-header", host: { classAttribute: "cub-sidebar-header" }, exportAs: ["cubSidebarHeader"], ngImport: i0, template: "<ng-content></ng-content>\n<ng-content select=\"cub-sidebar-close\"></ng-content>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-sidebar-header', exportAs: 'cubSidebarHeader', host: {
                        class: 'cub-sidebar-header',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<ng-content></ng-content>\n<ng-content select=\"cub-sidebar-close\"></ng-content>\n" }]
        }], ctorParameters: () => [] });

class CubSidebarClose {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarClose, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSidebarClose, isStandalone: true, selector: "cub-sidebar-close", host: { classAttribute: "cub-sidebar-close" }, exportAs: ["cubSidebarClose"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarClose, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-sidebar-close',
                    exportAs: 'cubSidebarClose',
                    host: {
                        class: 'cub-sidebar-close',
                    },
                }]
        }], ctorParameters: () => [] });

class CubSidebarActions {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarActions, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSidebarActions, isStandalone: true, selector: "cub-sidebar-actions", host: { classAttribute: "cub-sidebar-actions" }, exportAs: ["cubSidebarActions"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSidebarActions, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-sidebar-actions',
                    exportAs: 'cubSidebarActions',
                    host: {
                        class: 'cub-sidebar-actions',
                    },
                }]
        }] });

class CubLayoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutModule, imports: [CubCdkScrollableModule,
            CubLayoutPanel,
            CubLayoutContent,
            CubLayoutContainer,
            CubHeader,
            CubFooter,
            CubStickyActionBar,
            CubSidebar,
            CubSidebarHeader,
            CubSidebarClose,
            CubSidebarContent,
            CubSidebarActions], exports: [CubCdkScrollableModule,
            CubLayoutPanel,
            CubLayoutContent,
            CubLayoutContainer,
            CubHeader,
            CubFooter,
            CubStickyActionBar,
            CubSidebar,
            CubSidebarHeader,
            CubSidebarClose,
            CubSidebarContent,
            CubSidebarActions] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutModule, imports: [CubCdkScrollableModule, CubCdkScrollableModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkScrollableModule,
                        CubLayoutPanel,
                        CubLayoutContent,
                        CubLayoutContainer,
                        CubHeader,
                        CubFooter,
                        CubStickyActionBar,
                        CubSidebar,
                        CubSidebarHeader,
                        CubSidebarClose,
                        CubSidebarContent,
                        CubSidebarActions,
                    ],
                    exports: [
                        CubCdkScrollableModule,
                        CubLayoutPanel,
                        CubLayoutContent,
                        CubLayoutContainer,
                        CubHeader,
                        CubFooter,
                        CubStickyActionBar,
                        CubSidebar,
                        CubSidebarHeader,
                        CubSidebarClose,
                        CubSidebarContent,
                        CubSidebarActions,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/layout
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_LAYOUT_CONTAINER, CUB_LAYOUT_DEFAULT_AUTOSIZE, CUB_LAYOUT_DEFAULT_AUTOSIZE_FACTORY, CubFooter, CubHeader, CubLayoutAnimations, CubLayoutContainer, CubLayoutContent, CubLayoutModule, CubLayoutPanel, CubLayoutService, CubSidebar, CubSidebarActions, CubSidebarClose, CubSidebarContent, CubSidebarHeader, CubStickyActionBar, throwCubDuplicatedLayoutError, throwCubDuplicatedStickyBarError };
//# sourceMappingURL=cub-lib-view-rootng-component-layout.mjs.map
