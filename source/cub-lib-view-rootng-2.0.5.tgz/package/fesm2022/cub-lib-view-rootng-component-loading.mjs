import * as i0 from '@angular/core';
import { Input, Component, NgModule } from '@angular/core';
import { NgIf } from '@angular/common';

const CubLoadingBackdropTheme = {
    ['brand']: 'light',
    ['success']: 'light',
    ['warning']: 'light',
    ['error']: 'light',
    ['neutral']: 'light',
    ['neutral-light']: 'light',
    ['brand-contrast']: 'dark',
    ['success-contrast']: 'dark',
    ['warning-contrast']: 'dark',
    ['error-contrast']: 'dark',
    ['neutral-contrast']: 'dark',
    ['neutral-light-contrast']: 'dark',
    white: 'dark',
};

class CubLoading {
    get spinnerSecondHalfId() {
        return 'spinner-second-half-' + this.color;
    }
    get spinnerFirstHalfId() {
        return 'spinner-first-half-' + this.color;
    }
    get backdropTheme() {
        return this.color ? CubLoadingBackdropTheme[this.color] : 'light';
    }
    constructor() {
        /** 元件顏色，預設為 'brand'。 */
        this.color = 'brand';
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 是否螢幕滿版顯示，預設為 false。 */
        this.fullScreen = false;
        /** 是否有遮罩，預設為 false。 */
        this.hasBackdrop = false;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLoading, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubLoading, isStandalone: true, selector: "cub-loading", inputs: { color: "color", size: "size", fullScreen: "fullScreen", hasBackdrop: "hasBackdrop" }, host: { properties: { "class.cub-loading-brand": "color === \"brand\"", "class.cub-loading-success": "color === \"success\"", "class.cub-loading-warning": "color === \"warning\"", "class.cub-loading-error": "color === \"error\"", "class.cub-loading-neutral": "color === \"neutral\"", "class.cub-loading-neutral-light": "color === \"neutral-light\"", "class.cub-loading-brand-contrast": "color === \"brand-contrast\"", "class.cub-loading-success-contrast": "color === \"success-contrast\"", "class.cub-loading-warning-contrast": "color === \"warning-contrast\"", "class.cub-loading-error-contrast": "color === \"error-contrast\"", "class.cub-loading-neutral-contrast": "color === \"neutral-contrast\"", "class.cub-loading-neutral-light-contrast": "color === \"neutral-light-contrast\"", "class.cub-loading-white": "color === \"white\"", "class.cub-loading-small": "size === \"small\"", "class.cub-loading-medium": "size === \"medium\"", "class.cub-loading-large": "size === \"large\"", "class.cub-loading-extra-large": "size === \"extra-large\"", "class.cub-loading-full-screen": "fullScreen", "class.cub-loading-fit-content": "!hasBackdrop && !fullScreen" }, classAttribute: "cub-loading" }, ngImport: i0, template: "<ng-container *ngIf=\"hasBackdrop || fullScreen\">\n  <div\n    class=\"cub-loading-backdrop\"\n    [class.cub-loading-backdrop-dark]=\"backdropTheme === 'dark'\"\n    [class.cub-loading-backdrop-light]=\"backdropTheme === 'light'\"\n  ></div>\n</ng-container>\n\n<div class=\"cub-loading-spinner\">\n  <svg\n    width=\"200\"\n    height=\"200\"\n    viewBox=\"0 0 200 200\"\n    fill=\"none\"\n    class=\"cub-loading-spinner-icon\"\n    xmlns=\"http://www.w3.org/2000/svg\"\n  >\n    <defs>\n      <linearGradient [attr.id]=\"spinnerSecondHalfId\">\n        <stop offset=\"0%\" stop-opacity=\"0\" stop-color=\"currentColor\" />\n        <stop offset=\"100%\" stop-opacity=\"0.5\" stop-color=\"currentColor\" />\n      </linearGradient>\n      <linearGradient [attr.id]=\"spinnerFirstHalfId\">\n        <stop offset=\"0%\" stop-opacity=\"1\" stop-color=\"currentColor\" />\n        <stop offset=\"100%\" stop-opacity=\"0.5\" stop-color=\"currentColor\" />\n      </linearGradient>\n    </defs>\n\n    <g stroke-width=\"20\">\n      <path\n        [attr.stroke]=\"'url(#' + spinnerSecondHalfId + ')'\"\n        d=\"M 20 100 A 80 80 0 0 1 180 100\"\n      />\n      <path\n        [attr.stroke]=\"'url(#' + spinnerFirstHalfId + ')'\"\n        d=\"M 180 100 A 80 80 0 0 1 20 100\"\n      />\n    </g>\n  </svg>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLoading, decorators: [{
            type: Component,
            args: [{ selector: 'cub-loading', host: {
                        class: 'cub-loading',
                        '[class.cub-loading-brand]': 'color === "brand"',
                        '[class.cub-loading-success]': 'color === "success"',
                        '[class.cub-loading-warning]': 'color === "warning"',
                        '[class.cub-loading-error]': 'color === "error"',
                        '[class.cub-loading-neutral]': 'color === "neutral"',
                        '[class.cub-loading-neutral-light]': 'color === "neutral-light"',
                        '[class.cub-loading-brand-contrast]': 'color === "brand-contrast"',
                        '[class.cub-loading-success-contrast]': 'color === "success-contrast"',
                        '[class.cub-loading-warning-contrast]': 'color === "warning-contrast"',
                        '[class.cub-loading-error-contrast]': 'color === "error-contrast"',
                        '[class.cub-loading-neutral-contrast]': 'color === "neutral-contrast"',
                        '[class.cub-loading-neutral-light-contrast]': 'color === "neutral-light-contrast"',
                        '[class.cub-loading-white]': 'color === "white"',
                        '[class.cub-loading-small]': 'size === "small"',
                        '[class.cub-loading-medium]': 'size === "medium"',
                        '[class.cub-loading-large]': 'size === "large"',
                        '[class.cub-loading-extra-large]': 'size === "extra-large"',
                        '[class.cub-loading-full-screen]': 'fullScreen',
                        '[class.cub-loading-fit-content]': '!hasBackdrop && !fullScreen',
                    }, imports: [NgIf], template: "<ng-container *ngIf=\"hasBackdrop || fullScreen\">\n  <div\n    class=\"cub-loading-backdrop\"\n    [class.cub-loading-backdrop-dark]=\"backdropTheme === 'dark'\"\n    [class.cub-loading-backdrop-light]=\"backdropTheme === 'light'\"\n  ></div>\n</ng-container>\n\n<div class=\"cub-loading-spinner\">\n  <svg\n    width=\"200\"\n    height=\"200\"\n    viewBox=\"0 0 200 200\"\n    fill=\"none\"\n    class=\"cub-loading-spinner-icon\"\n    xmlns=\"http://www.w3.org/2000/svg\"\n  >\n    <defs>\n      <linearGradient [attr.id]=\"spinnerSecondHalfId\">\n        <stop offset=\"0%\" stop-opacity=\"0\" stop-color=\"currentColor\" />\n        <stop offset=\"100%\" stop-opacity=\"0.5\" stop-color=\"currentColor\" />\n      </linearGradient>\n      <linearGradient [attr.id]=\"spinnerFirstHalfId\">\n        <stop offset=\"0%\" stop-opacity=\"1\" stop-color=\"currentColor\" />\n        <stop offset=\"100%\" stop-opacity=\"0.5\" stop-color=\"currentColor\" />\n      </linearGradient>\n    </defs>\n\n    <g stroke-width=\"20\">\n      <path\n        [attr.stroke]=\"'url(#' + spinnerSecondHalfId + ')'\"\n        d=\"M 20 100 A 80 80 0 0 1 180 100\"\n      />\n      <path\n        [attr.stroke]=\"'url(#' + spinnerFirstHalfId + ')'\"\n        d=\"M 180 100 A 80 80 0 0 1 20 100\"\n      />\n    </g>\n  </svg>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { color: [{
                type: Input
            }], size: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], hasBackdrop: [{
                type: Input
            }] } });

class CubLoadingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLoadingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubLoadingModule, imports: [CubLoading], exports: [CubLoading] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLoadingModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubLoadingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubLoading],
                    exports: [CubLoading],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/loading
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubLoading, CubLoadingBackdropTheme, CubLoadingModule };
//# sourceMappingURL=cub-lib-view-rootng-component-loading.mjs.map
