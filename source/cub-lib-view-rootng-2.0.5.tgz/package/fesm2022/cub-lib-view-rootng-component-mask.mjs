import * as i0 from '@angular/core';
import { EventEmitter, HostListener, Output, Input, Component, NgModule } from '@angular/core';
import { NgIf } from '@angular/common';
import { GRID_BREAKPOINT } from 'cub-lib-view-rootng/component/common';
import { CubButton } from 'cub-lib-view-rootng/component/button';

const CUB_MASK_LANGUAGE_CONFIG = {
    'zh-TW': {
        title: '本系統不支援目前偵測到的瀏覽器尺寸',
        description: `1. 建議使用系統支援之裝置（桌機、筆電、平板-橫式、平版-直式、手機）並將瀏覽器縮放設為 100%。<br />
    2. 為避免畫面顯示異常，系統已自動遮蔽畫面。`,
        button: {
            label: '繼續使用',
            command: () => { },
        },
        device: {
            desktop: '桌機',
            laptop: '筆電',
            tabletLandscape: '平板-橫式',
            tabletPortrait: '平版-直式',
            mobile: '手機',
        },
    },
    'en-US': {
        title: 'This browser size is not supported.',
        description: `1. Please use a supported device (desktop, laptop, tablet-Landscape mode, tablet-Portrait mode, mobile) with browser zoom set to 100%.<br />
    2. The screen has been masked to avoid display issues.`,
        button: {
            label: 'Continue',
            command: () => { },
        },
        device: {
            desktop: 'desktop',
            laptop: 'laptop',
            tabletLandscape: 'tablet-Landscape mode',
            tabletPortrait: 'tablet-Portrait mode',
            mobile: 'mobile',
        },
    },
};

class CubMask {
    onResize(event) {
        this.toggleMask();
    }
    constructor() {
        this.isShowMask = false;
        this.supportedDeviceList = [
            'desktop',
            'laptop',
            'tabletLandscape',
            'tabletPortrait',
            'mobile',
        ];
        /* 顯示尺寸設定 Start */
        /** 是否顯示遮罩，預設為 true。 */
        this.visible = true;
        /** 遮罩顯式的最大斷點，預設為 null。可取下列值之一：
         * xxl：螢幕尺寸 > 1920px 時顯示。
         * null：不限制螢幕尺寸。
         */
        this.maxBreakPoint = null;
        /** 遮罩顯式的最小斷點，預設為 'lg'。可取下列值之一：
         * xl：螢幕尺寸 < 1440px 時顯示。
         * lg：螢幕尺寸 < 1024px 時顯示。
         * md：螢幕尺寸 < 768px 時顯示。
         * sm：螢幕尺寸 < 576px 時顯示。
         */
        this.minBreakPoint = 'lg';
        /** 是否顯示關閉按鈕，預設為 false。 */
        this.showCloseButton = false;
        /** End */
        /* 顯示資訊設定 Start */
        /** 提示訊息所支援的顯示語言，預設為 'zh-TW'。可取下列值之一：
         * zh-TW：繁體中文。
         * en-US：英文。
         */
        this.language = 'zh-TW';
        /** 在提示訊息中所支援的裝置類型，預設為 ['desktop','laptop','tabletLandscape','tabletPortrait','mobile']。可取下列值使用：
         * desktop：桌機。
         * laptop：筆電。
         * tabletLandscape：橫式平板。
         * tabletPortrait：直式平板。
         * mobile：手機。
         */
        this.supportedDevice = [
            'desktop',
            'laptop',
            'tabletLandscape',
            'tabletPortrait',
            'mobile',
        ];
        /** End */
        /** 自行關閉遮罩時發出通知。 */
        this.closed = new EventEmitter();
    }
    ngOnInit() {
        this.hintText = this.getHintText();
        this.toggleMask();
    }
    ngOnChanges(changes) {
        this.hintText = this.getHintText();
        this.toggleMask();
    }
    ngOnDestroy() {
        this.hideMask();
    }
    closeMask() {
        this.visible = false;
        this.hideMask();
        this.closed.emit();
    }
    showMask() {
        this.isShowMask = true;
    }
    hideMask() {
        this.isShowMask = false;
    }
    toggleMask() {
        if (this.visible) {
            const innerWidth = window.innerWidth;
            const minBreakPoint = this.minBreakPoint
                ? this.getBreakPoint(this.minBreakPoint)
                : null;
            const maxBreakPoint = this.maxBreakPoint
                ? this.getBreakPoint(this.maxBreakPoint)
                : null;
            if ((maxBreakPoint && innerWidth > maxBreakPoint) ||
                (minBreakPoint && innerWidth < minBreakPoint)) {
                this.showMask();
            }
            else {
                this.hideMask();
            }
        }
        else {
            this.hideMask();
        }
    }
    getBreakPoint(breakPoint) {
        switch (breakPoint) {
            case 'xxl':
                return GRID_BREAKPOINT.XXL;
            case 'xl':
                return GRID_BREAKPOINT.XL;
            case 'lg':
                return GRID_BREAKPOINT.LG;
            case 'md':
                return GRID_BREAKPOINT.MD;
            case 'sm':
                return GRID_BREAKPOINT.SM;
            default:
                return GRID_BREAKPOINT.LG;
        }
    }
    getHintText() {
        let hintText;
        switch (this.language) {
            case 'zh-TW':
                hintText = { ...CUB_MASK_LANGUAGE_CONFIG['zh-TW'] };
                break;
            case 'en-US':
                hintText = { ...CUB_MASK_LANGUAGE_CONFIG['en-US'] };
                break;
            default:
                hintText = { ...CUB_MASK_LANGUAGE_CONFIG['zh-TW'] };
                break;
        }
        return this.updateDeviceList(hintText);
    }
    updateDeviceList(hintText) {
        const supportedDeviceList = this.supportedDeviceList.map((device) => hintText.device[device]);
        const deviceList = this.supportedDevice.map((device) => hintText.device[device]);
        let supportedDevice = '';
        let device = '';
        switch (this.language) {
            case 'zh-TW':
                supportedDevice = supportedDeviceList.join('、');
                device = deviceList.join('、');
                break;
            case 'en-US':
                supportedDevice = supportedDeviceList.join(', ');
                device = deviceList.join(', ');
                break;
            default:
                supportedDevice = supportedDeviceList.join('、');
                device = deviceList.join('、');
                break;
        }
        hintText.description = hintText.description.replace(supportedDevice, device);
        return hintText;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMask, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubMask, isStandalone: true, selector: "cub-mask", inputs: { visible: "visible", maxBreakPoint: "maxBreakPoint", minBreakPoint: "minBreakPoint", showCloseButton: "showCloseButton", language: "language", supportedDevice: "supportedDevice" }, outputs: { closed: "closed" }, host: { listeners: { "window:resize": "onResize($event)" }, classAttribute: "cub-mask" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"isShowMask\">\n  <div class=\"cub-mask-backdrop\"></div>\n\n  <div class=\"cub-mask-panel\">\n    <div class=\"cub-mask-container\">\n      <div class=\"cub-mask-image\">\n        <div class=\"cub-img-notice-horizontal\"></div>\n      </div>\n\n      <div class=\"cub-mask-content\">\n        <div class=\"cub-mask-title\">\n          {{ hintText.title }}\n        </div>\n\n        <div\n          class=\"cub-mask-description\"\n          [innerHTML]=\"hintText.description\"\n        ></div>\n\n        <ng-container *ngIf=\"showCloseButton\">\n          <div class=\"cub-mask-button\">\n            <button\n              cub-button\n              type=\"button\"\n              color=\"brand\"\n              appearance=\"filled\"\n              [withMinWidth]=\"true\"\n              (click)=\"closeMask()\"\n            >\n              {{ hintText.button.label }}\n            </button>\n          </div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n</ng-container>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMask, decorators: [{
            type: Component,
            args: [{ selector: 'cub-mask', host: {
                        class: 'cub-mask',
                    }, imports: [NgIf, CubButton], template: "<ng-container *ngIf=\"isShowMask\">\n  <div class=\"cub-mask-backdrop\"></div>\n\n  <div class=\"cub-mask-panel\">\n    <div class=\"cub-mask-container\">\n      <div class=\"cub-mask-image\">\n        <div class=\"cub-img-notice-horizontal\"></div>\n      </div>\n\n      <div class=\"cub-mask-content\">\n        <div class=\"cub-mask-title\">\n          {{ hintText.title }}\n        </div>\n\n        <div\n          class=\"cub-mask-description\"\n          [innerHTML]=\"hintText.description\"\n        ></div>\n\n        <ng-container *ngIf=\"showCloseButton\">\n          <div class=\"cub-mask-button\">\n            <button\n              cub-button\n              type=\"button\"\n              color=\"brand\"\n              appearance=\"filled\"\n              [withMinWidth]=\"true\"\n              (click)=\"closeMask()\"\n            >\n              {{ hintText.button.label }}\n            </button>\n          </div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [], propDecorators: { visible: [{
                type: Input
            }], maxBreakPoint: [{
                type: Input
            }], minBreakPoint: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], language: [{
                type: Input
            }], supportedDevice: [{
                type: Input
            }], closed: [{
                type: Output
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }] } });

class CubMaskModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMaskModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubMaskModule, imports: [CubMask], exports: [CubMask] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMaskModule, imports: [CubMask] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMaskModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubMask],
                    exports: [CubMask],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/mask
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_MASK_LANGUAGE_CONFIG, CubMask, CubMaskModule };
//# sourceMappingURL=cub-lib-view-rootng-component-mask.mjs.map
