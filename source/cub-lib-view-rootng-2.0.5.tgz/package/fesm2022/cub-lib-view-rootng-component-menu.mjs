import * as i0 from '@angular/core';
import { InjectionToken, EventEmitter, DOCUMENT, ContentChild, Input, Output, Inject, Optional, ViewEncapsulation, ChangeDetectionStrategy, Component, Directive, QueryList, TemplateRef, ContentChildren, ViewChild, Self, NgModule } from '@angular/core';
import { NgClass } from '@angular/common';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i1$1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, OverlayConfig, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { Subject, Observable, take, merge, Subscription, of, asapScheduler } from 'rxjs';
import { startWith, switchMap, take as take$1, takeUntil, filter, delay } from 'rxjs/operators';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import { FocusKeyManager, isFakeTouchstartFromScreenReader, isFakeMousedownFromScreenReader } from 'cub-lib-view-rootng/cdk/a11y';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { ENTER, SPACE, UP_ARROW, DOWN_ARROW, RIGHT_ARROW, LEFT_ARROW, ESCAPE, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { mixinDisableRipple, mixinDisabled, CubRipple, CubPrefix, CubSuffix, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';
import { TemplatePortal, DomPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import { normalizePassiveListenerOptions } from 'cub-lib-view-rootng/cdk/platform';
import * as i3 from 'cub-lib-view-rootng/cdk/bidi';
import { CubCdkScrollableModule } from 'cub-lib-view-rootng/cdk/scrolling';

function throwMenuInvalidPositionStart() {
    throw Error(`positionStart value must be either 'above', 'below', 'before' or 'after'.
      Example: <cub-menu positionStart="before" #menu="cubMenu"></cub-menu>`);
}
function throwMenuInvalidPositionEnd() {
    throw Error(`positionEnd value must be either 'above', 'below', 'before' or 'after'.
      Example: <cub-menu positionEnd="above" #menu="cubMenu"></cub-menu>`);
}
function throwMenuRecursiveError() {
    throw Error(`cubMenuTriggerFor: menu cannot contain its own trigger. Assign a menu that is ` +
        `not a parent of the trigger or move the trigger outside of the menu.`);
}
function CUB_MENU_DEFAULT_OPTIONS_FACTORY() {
    return {
        hasBackdrop: false,
        overlapTrigger: false,
        positionStart: 'below',
        positionEnd: 'before',
        backdropClass: 'cub-cdk-overlay-transparent-backdrop',
        overlayPanelClass: 'cub-menu-overlay',
    };
}
function CUB_MENU_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition();
}

const CUB_MENU_PANEL = new InjectionToken('MAT_MENU_PANEL');
const CUB_MENU_DEFAULT_OPTIONS = new InjectionToken('cub-menu-default-options', {
    providedIn: 'root',
    factory: CUB_MENU_DEFAULT_OPTIONS_FACTORY,
});
const CUB_MENU_SCROLL_STRATEGY = new InjectionToken('cub-menu-scroll-strategy');
const CUB_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER = {
    provide: CUB_MENU_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_MENU_SCROLL_STRATEGY_FACTORY,
};
const cubMenuAnimations = {
    transformMenu: trigger('transformMenu', [
        state('void', style({
            opacity: 0,
            transform: 'scale(0.8)',
        })),
        transition('void => enter', animate('120ms cubic-bezier(0, 0, 0.2, 1)', style({
            opacity: 1,
            transform: 'scale(1)',
        }))),
        transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
    ]),
    fadeInItems: trigger('fadeInItems', [
        state('showing', style({ opacity: 1 })),
        transition('void => *', [
            style({ opacity: 0 }),
            animate('400ms 100ms cubic-bezier(0.55, 0, 0.55, 0.2)'),
        ]),
    ]),
};

const _CubMenuItemBase = mixinDisableRipple(mixinDisabled(class {
}));
class CubMenuItem extends _CubMenuItemBase {
    /**
     * 是否為 loading 的狀態，預設值為 false。
     */
    get loading() {
        return this._loading;
    }
    set loading(value) {
        this._loading = value;
        this._changeDetectorRef.markForCheck();
    }
    constructor(_elementRef, _document, _focusMonitor, _parentMenu, _changeDetectorRef) {
        super();
        this._elementRef = _elementRef;
        this._document = _document;
        this._focusMonitor = _focusMonitor;
        this._parentMenu = _parentMenu;
        this._changeDetectorRef = _changeDetectorRef;
        this.withPrefix = false;
        this._loading = false;
        this._highlighted = false;
        this._triggersSubmenu = false;
        this.size = 'medium';
        this._hovered = new Subject();
        this._focused = new Subject();
        /**
         * 當非同步請求完成時送出事件。
         */
        this.actionCompleted = new EventEmitter();
        /**
         * 當非同步請求失敗時送出事件。
         */
        this.actionFailed = new EventEmitter();
        this.prefixContent = null;
        this.suffixContent = null;
        _parentMenu?.addItem?.(this);
    }
    ngAfterViewInit() {
        if (this._focusMonitor) {
            this._focusMonitor.monitor(this._elementRef, false);
        }
        if (this.prefixContent) {
            this.withPrefix = true;
            this._changeDetectorRef?.markForCheck();
        }
        if (this.suffixContent) {
            this._changeDetectorRef?.markForCheck();
        }
    }
    ngOnDestroy() {
        if (this._focusMonitor) {
            this._focusMonitor.stopMonitoring(this._elementRef);
        }
        if (this._parentMenu && this._parentMenu.removeItem) {
            this._parentMenu.removeItem(this);
        }
        this._hovered.complete();
        this._focused.complete();
    }
    focus(origin, options) {
        if (this._focusMonitor && origin) {
            this._focusMonitor.focusVia(this._getHostElement(), origin, options);
        }
        else {
            this._getHostElement().focus(options);
        }
        this._focused.next(this);
    }
    _getTabIndex() {
        return this.disabled ? '-1' : '0';
    }
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    _checkDisabled(event) {
        if (this.disabled) {
            event.preventDefault();
            event.stopPropagation();
        }
    }
    _handleMouseEnter() {
        this._hovered.next(this);
    }
    getLabel() {
        const clone = this._elementRef.nativeElement.cloneNode(true);
        const icons = clone.querySelectorAll('cub-icon');
        for (let i = 0; i < icons.length; i++) {
            icons[i].remove();
        }
        return clone.textContent?.trim() || '';
    }
    _setHighlighted(isHighlighted) {
        this._highlighted = isHighlighted;
        this._changeDetectorRef?.markForCheck();
    }
    _setTriggersSubmenu(triggersSubmenu) {
        this._triggersSubmenu = triggersSubmenu;
        this._changeDetectorRef?.markForCheck();
    }
    _hasFocus() {
        return (this._document && this._document.activeElement === this._getHostElement());
    }
    _handleClick(e) {
        if (this.action && this.action instanceof Observable && !this.loading) {
            this.asyncActionHandler(this.action);
            e.stopPropagation();
            e.preventDefault();
            return;
        }
        else {
            if (this.action && typeof this.action === 'function') {
                this.action();
            }
        }
    }
    _handleKeydown(e) {
        const keyCode = e.keyCode;
        if (keyCode === ENTER || keyCode === SPACE) {
            if (this._triggersSubmenu) {
                this._handleMouseEnter();
                return;
            }
            else {
                if (this.action && this.action instanceof Observable && !this.loading) {
                    this.asyncActionHandler(this.action);
                }
                else {
                    if (this.action && typeof this.action === 'function') {
                        this.action();
                        this._parentMenu.closed.emit('click');
                    }
                }
            }
            e.stopPropagation();
            e.preventDefault();
        }
    }
    asyncActionHandler(action) {
        this.loading = true;
        action.pipe(take(1)).subscribe({
            next: (result) => {
                this.loading = false;
                this.actionCompleted.emit(result);
            },
            error: (err) => {
                this.loading = false;
                this.actionFailed.emit(err);
            },
            complete: () => {
                this.loading = false;
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuItem, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }, { token: i1.FocusMonitor }, { token: CUB_MENU_PANEL, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubMenuItem, isStandalone: true, selector: "[cub-menu-item]", inputs: { disabled: "disabled", disableRipple: "disableRipple", action: "action", loading: "loading" }, outputs: { actionCompleted: "actionCompleted", actionFailed: "actionFailed" }, host: { listeners: { "click": "_handleClick($event)", "keydown": "_handleKeydown($event)", "mouseenter": "_handleMouseEnter()" }, properties: { "attr.role": "role", "class.cub-menu-item-highlighted": "_highlighted", "class.cub-menu-item-submenu-trigger": "_triggersSubmenu", "attr.tabindex": "_getTabIndex()", "attr.aria-disabled": "disabled", "attr.disabled": "disabled || null" }, classAttribute: "cub-menu-item cub-focus-indicator" }, queries: [{ propertyName: "prefixContent", first: true, predicate: CubPrefix, descendants: true }, { propertyName: "suffixContent", first: true, predicate: CubSuffix, descendants: true }], exportAs: ["cubMenuItem"], usesInheritance: true, ngImport: i0, template: "<span class=\"cub-menu-item-content\">\n  <span class=\"cub-menu-item-content-prefix\" [class.with-prefix]=\"withPrefix\">\n    <ng-content select=\"[cubPrefix]\" #prefixIcon></ng-content>\n  </span>\n  <span class=\"cub-menu-item-content-text\">\n    <ng-content></ng-content>\n  </span>\n  <span class=\"cub-menu-item-content-suffix\">\n    @if (loading) {\n    <div class=\"cub-loading-wrapper\">\n      <cub-loading [size]=\"size\"></cub-loading>\n    </div>\n    } @else if(_triggersSubmenu) {\n    <span cubSuffix class=\"cub-icon-chevron-right\"></span>\n    }\n  </span>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-menu-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-menu-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuItem, decorators: [{
            type: Component,
            args: [{ selector: '[cub-menu-item]', exportAs: 'cubMenuItem', inputs: ['disabled', 'disableRipple'], host: {
                        '[attr.role]': 'role',
                        class: 'cub-menu-item cub-focus-indicator',
                        '[class.cub-menu-item-highlighted]': '_highlighted',
                        '[class.cub-menu-item-submenu-trigger]': '_triggersSubmenu',
                        '[attr.tabindex]': '_getTabIndex()',
                        '[attr.aria-disabled]': 'disabled',
                        '[attr.disabled]': 'disabled || null',
                        '(click)': '_handleClick($event)',
                        '(keydown)': '_handleKeydown($event)',
                        '(mouseenter)': '_handleMouseEnter()',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [CubLoading, CubRipple], template: "<span class=\"cub-menu-item-content\">\n  <span class=\"cub-menu-item-content-prefix\" [class.with-prefix]=\"withPrefix\">\n    <ng-content select=\"[cubPrefix]\" #prefixIcon></ng-content>\n  </span>\n  <span class=\"cub-menu-item-content-text\">\n    <ng-content></ng-content>\n  </span>\n  <span class=\"cub-menu-item-content-suffix\">\n    @if (loading) {\n    <div class=\"cub-loading-wrapper\">\n      <cub-loading [size]=\"size\"></cub-loading>\n    </div>\n    } @else if(_triggersSubmenu) {\n    <span cubSuffix class=\"cub-icon-chevron-right\"></span>\n    }\n  </span>\n</span>\n<span\n  cubRipple\n  cubRippleClass=\"cub-menu-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-menu-persistent-ripple\"></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.FocusMonitor }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_MENU_PANEL]
                }, {
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { action: [{
                type: Input
            }], actionCompleted: [{
                type: Output
            }], actionFailed: [{
                type: Output
            }], loading: [{
                type: Input
            }], prefixContent: [{
                type: ContentChild,
                args: [CubPrefix, { descendants: true }]
            }], suffixContent: [{
                type: ContentChild,
                args: [CubSuffix, { descendants: true }]
            }] } });

const CUB_MENU_CONTENT = new InjectionToken('CubMenuContent');
class _CubMenuContentBase {
    constructor(_templateRef, _componentFactoryResolver, _appRef, _injector, _viewContainerRef, _document, _changeDetectorRef) {
        this._templateRef = _templateRef;
        this._componentFactoryResolver = _componentFactoryResolver;
        this._appRef = _appRef;
        this._injector = _injector;
        this._viewContainerRef = _viewContainerRef;
        this._document = _document;
        this._changeDetectorRef = _changeDetectorRef;
        this._attached = new Subject();
    }
    attach(context = {}) {
        if (!this._portal) {
            this._portal = new TemplatePortal(this._templateRef, this._viewContainerRef);
        }
        this.detach();
        if (!this._outlet) {
            this._outlet = new DomPortalOutlet(this._document.createElement('div'), this._componentFactoryResolver, this._appRef, this._injector);
        }
        const element = this._templateRef.elementRef.nativeElement;
        element.parentNode.insertBefore(this._outlet.outletElement, element);
        this._changeDetectorRef?.markForCheck();
        this._portal.attach(this._outlet, context);
        this._attached.next();
    }
    detach() {
        if (this._portal.isAttached) {
            this._portal.detach();
        }
    }
    ngOnDestroy() {
        if (this._outlet) {
            this._outlet.dispose();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubMenuContentBase, deps: [{ token: i0.TemplateRef }, { token: i0.ComponentFactoryResolver }, { token: i0.ApplicationRef }, { token: i0.Injector }, { token: i0.ViewContainerRef }, { token: DOCUMENT }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubMenuContentBase, isStandalone: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubMenuContentBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.ComponentFactoryResolver }, { type: i0.ApplicationRef }, { type: i0.Injector }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.ChangeDetectorRef }] });
class CubMenuContent extends _CubMenuContentBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuContent, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubMenuContent, isStandalone: true, selector: "ng-template[cubMenuContent]", providers: [{ provide: CUB_MENU_CONTENT, useExisting: CubMenuContent }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuContent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[cubMenuContent]',
                    providers: [{ provide: CUB_MENU_CONTENT, useExisting: CubMenuContent }],
                }]
        }] });

let menuPanelUid = 0;
class _CubMenuBase {
    /**
     * 設定 menu 在 X 軸的顯示位置，預設值為 'after'。
     */
    get positionStart() {
        return this._positionStart;
    }
    set positionStart(value) {
        if (!['before', 'after', 'above', 'below'].includes(value)) {
            throwMenuInvalidPositionStart();
        }
        this._positionStart = value;
        this.setPositionClasses();
    }
    /**
     * 設定 menu 在 Y 軸的顯示位置，預設值為 'below'。
     */
    get positionEnd() {
        return this._positionEnd;
    }
    set positionEnd(value) {
        if (!['before', 'after', 'above', 'below'].includes(value)) {
            throwMenuInvalidPositionEnd();
        }
        this._positionEnd = value;
        this.setPositionClasses();
    }
    /**
     * 設定 menu 重疊時是否可以觸發，預設值為 false。
     */
    get overlapTrigger() {
        return this._overlapTrigger;
    }
    set overlapTrigger(value) {
        this._overlapTrigger = coerceBooleanProperty(value);
    }
    /**
     * 設定 menu 是否要有背景遮罩，預設值為 false。
     */
    get hasBackdrop() {
        return this._hasBackdrop;
    }
    set hasBackdrop(value) {
        this._hasBackdrop = coerceBooleanProperty(value);
    }
    /**
     * 設定 class 的名稱，預設值為 ''。
     */
    set panelClass(classes) {
        const previousPanelClass = this._previousPanelClass;
        if (previousPanelClass && previousPanelClass.length) {
            previousPanelClass.split(' ').forEach((className) => {
                this._classList[className] = false;
            });
        }
        this._previousPanelClass = classes;
        if (classes && classes.length) {
            classes.split(' ').forEach((className) => {
                this._classList[className] = true;
            });
            this._elementRef.nativeElement.className = '';
        }
    }
    constructor(_elementRef, _ngZone, _defaultOptions, _changeDetectorRef) {
        this._elementRef = _elementRef;
        this._ngZone = _ngZone;
        this._defaultOptions = _defaultOptions;
        this._changeDetectorRef = _changeDetectorRef;
        this.direction = 'ltr';
        this.overlayPanelClass = this._defaultOptions.overlayPanelClass || '';
        this._directDescendantItems = new QueryList();
        this._classList = {};
        this._panelAnimationState = 'void';
        this._isAnimating = false;
        this.panelId = `cub-menu-panel-${menuPanelUid++}`;
        this._animationDone = new Subject();
        this._elevationPrefix = '';
        this._baseElevation = 8;
        this._positionStart = this._defaultOptions.positionStart;
        this._positionEnd = this._defaultOptions.positionEnd;
        this._previousElevation = '';
        this._overlapTrigger = this._defaultOptions.overlapTrigger;
        this._hasBackdrop = this._defaultOptions.hasBackdrop;
        this._previousPanelClass = '';
        /*
         * 選擇要使用的選單尺寸，預設為 medium。
         */
        this.size = 'medium';
        /**
         * 用於設定 backdrop 的 class 名稱，預設為 'cub-cdk-overlay-transparent-backdrop'。
         */
        this.backdropClass = this._defaultOptions.backdropClass;
        /**
         * 添加 aria-label 屬性的值，檢查框的標題(螢幕閱讀緝讀取用)，預設值為 undefined。
         */
        this.ariaLabel = '';
        /**
         * 添加 aria-labelledby 屬性的值，優先於標題讀取的替代文字(螢幕閱讀緝讀取用)，預設值為 undefined。
         */
        this.ariaLabelledby = '';
        /**
         * 添加 aria-describedby 屬性的值，在標題與欄位型別之後讀的描述內容(螢幕閱讀緝讀取用)，預設值為 undefined。
         */
        this.ariaDescribedby = '';
        /**
         * 當 menu 關閉時會送出事件通知。
         */
        this.closed = new EventEmitter();
    }
    ngOnInit() {
        this.setPositionClasses();
    }
    ngAfterContentInit() {
        this._updateDirectDescendants();
        this._keyManager = new FocusKeyManager(this._directDescendantItems)
            .withWrap()
            .withTypeAhead()
            .withHomeAndEnd();
        this._directDescendantItems.changes
            .pipe(startWith(this._directDescendantItems), switchMap((items) => merge(...items.map((item) => item._focused))))
            .subscribe((focusedItem) => this._keyManager.updateActiveItem(focusedItem));
        this._directDescendantItems.changes.subscribe((itemsList) => {
            const manager = this._keyManager;
            if (this._panelAnimationState === 'enter' &&
                manager.activeItem?._hasFocus()) {
                const items = itemsList.toArray();
                const index = Math.max(0, Math.min(items.length - 1, manager.activeItemIndex || 0));
                if (items[index] && !items[index].disabled) {
                    manager.setActiveItem(index);
                }
                else {
                    manager.setNextItemActive();
                }
            }
        });
        this._allItems.forEach((item) => {
            if (this.size) {
                item.size = this.size;
            }
        });
    }
    ngOnDestroy() {
        // this._keyManager?.destroy();
        this._directDescendantItems.destroy();
        this.closed.complete();
        this._firstItemFocusSubscription?.unsubscribe();
    }
    addItem(_item) { }
    removeItem(_item) { }
    focusFirstItem(origin = 'program') {
        // Wait for `onStable` to ensure iOS VoiceOver screen reader focuses the first item (#24735).
        this._firstItemFocusSubscription?.unsubscribe();
        this._firstItemFocusSubscription = this._ngZone.onStable
            .pipe(take$1(1))
            .subscribe(() => {
            let menuPanel = null;
            if (this._directDescendantItems.length) {
                menuPanel = this._directDescendantItems
                    .first._getHostElement()
                    .closest('[role="menu"]');
            }
            if (!menuPanel || !menuPanel.contains(document.activeElement)) {
                const manager = this._keyManager;
                manager.setFocusOrigin(origin).setFirstItemActive();
                if (!manager.activeItem && menuPanel) {
                    menuPanel.focus();
                }
            }
        });
    }
    resetActiveItem() {
        this._keyManager.setActiveItem(-1);
    }
    setElevation(depth) {
        const elevation = Math.min(this._baseElevation + depth, 24);
        const newElevation = `${this._elevationPrefix}${elevation}`;
        const customElevation = Object.keys(this._classList).find((className) => {
            return className.startsWith(this._elevationPrefix);
        });
        if (!customElevation || customElevation === this._previousElevation) {
            if (this._previousElevation) {
                this._classList[this._previousElevation] = false;
            }
            this._classList[newElevation] = true;
            this._previousElevation = newElevation;
        }
    }
    setPositionClasses(start = this.positionStart, end = this.positionEnd) {
        const classes = this._classList;
        classes['cub-menu-before'] = start === 'before';
        classes['cub-menu-after'] = start === 'after';
        classes['cub-menu-above'] = start === 'above';
        classes['cub-menu-below'] = start === 'below';
        this._changeDetectorRef?.markForCheck();
    }
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    _hovered() {
        const itemChanges = this._directDescendantItems.changes;
        return itemChanges.pipe(startWith(this._directDescendantItems), switchMap((items) => merge(...items.map((item) => item._hovered))));
    }
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        const manager = this._keyManager;
        switch (keyCode) {
            case ESCAPE:
                if (!hasModifierKey(event)) {
                    event.preventDefault();
                    this.closed.emit('keydown');
                }
                break;
            case LEFT_ARROW:
                if (this.parentMenu && this.direction === 'ltr') {
                    this.closed.emit('keydown');
                }
                break;
            case RIGHT_ARROW:
                if (this.parentMenu && this.direction === 'rtl') {
                    this.closed.emit('keydown');
                }
                break;
            default:
                if (keyCode === UP_ARROW || keyCode === DOWN_ARROW) {
                    manager.setFocusOrigin('keyboard');
                }
                manager.onKeydown(event);
                return;
        }
        event.stopPropagation();
    }
    _startAnimation() {
        this._panelAnimationState = 'enter';
    }
    _resetAnimation() {
        this._panelAnimationState = 'void';
    }
    _onAnimationDone(event) {
        this._animationDone.next(event);
        this._isAnimating = false;
    }
    _onAnimationStart(event) {
        this._isAnimating = true;
        if (event.toState === 'enter' && this._keyManager.activeItemIndex === 0) {
            event.element.scrollTop = 0;
        }
    }
    _updateDirectDescendants() {
        this._allItems.changes
            .pipe(startWith(this._allItems))
            .subscribe((items) => {
            this._directDescendantItems.reset(items.filter((item) => item._parentMenu === this));
            this._directDescendantItems.notifyOnChanges();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubMenuBase, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: CUB_MENU_DEFAULT_OPTIONS }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubMenuBase, isStandalone: true, inputs: { size: "size", backdropClass: "backdropClass", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], positionStart: "positionStart", positionEnd: "positionEnd", overlapTrigger: "overlapTrigger", hasBackdrop: "hasBackdrop", panelClass: ["class", "panelClass"] }, outputs: { closed: "closed" }, queries: [{ propertyName: "lazyContent", first: true, predicate: CUB_MENU_CONTENT, descendants: true }, { propertyName: "items", predicate: CubMenuItem }, { propertyName: "_allItems", predicate: CubMenuItem, descendants: true }], viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubMenuBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_MENU_DEFAULT_OPTIONS]
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { size: [{
                type: Input
            }], backdropClass: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], positionStart: [{
                type: Input
            }], positionEnd: [{
                type: Input
            }], overlapTrigger: [{
                type: Input
            }], hasBackdrop: [{
                type: Input
            }], panelClass: [{
                type: Input,
                args: ['class']
            }], closed: [{
                type: Output
            }], templateRef: [{
                type: ViewChild,
                args: [TemplateRef]
            }], items: [{
                type: ContentChildren,
                args: [CubMenuItem, { descendants: false }]
            }], lazyContent: [{
                type: ContentChild,
                args: [CUB_MENU_CONTENT]
            }], _allItems: [{
                type: ContentChildren,
                args: [CubMenuItem, { descendants: true }]
            }] } });

class CubMenu extends _CubMenuBase {
    constructor(_elementRef, _ngZone, _defaultOptions, changeDetectorRef) {
        super(_elementRef, _ngZone, _defaultOptions, changeDetectorRef);
        this.changeDetectorRef = changeDetectorRef;
    }
    ngOnChanges(changes) {
        if (changes['size']) {
            this.changeDetectorRef.markForCheck();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenu, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: CUB_MENU_DEFAULT_OPTIONS }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubMenu, isStandalone: true, selector: "cub-menu", host: { properties: { "attr.aria-label": "null", "attr.aria-labelledby": "null", "attr.aria-describedby": "null" } }, providers: [{ provide: CUB_MENU_PANEL, useExisting: CubMenu }], exportAs: ["cubMenu"], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<ng-template>\n  <div\n    class=\"cub-menu-panel\"\n    [id]=\"panelId\"\n    [ngClass]=\"_classList\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"closed.emit('click')\"\n    [@transformMenu]=\"_panelAnimationState\"\n    (@transformMenu.start)=\"_onAnimationStart($event)\"\n    (@transformMenu.done)=\"_onAnimationDone($event)\"\n    tabindex=\"-1\"\n    role=\"menu\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [class.cub-menu-small]=\"size === 'small'\"\n  >\n    <div class=\"cub-menu-content\">\n      <ng-content></ng-content>\n    </div>\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], animations: [cubMenuAnimations.transformMenu, cubMenuAnimations.fadeInItems], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenu, decorators: [{
            type: Component,
            args: [{ selector: 'cub-menu', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, exportAs: 'cubMenu', host: {
                        '[attr.aria-label]': 'null',
                        '[attr.aria-labelledby]': 'null',
                        '[attr.aria-describedby]': 'null',
                    }, animations: [cubMenuAnimations.transformMenu, cubMenuAnimations.fadeInItems], providers: [{ provide: CUB_MENU_PANEL, useExisting: CubMenu }], imports: [NgClass], template: "<ng-template>\n  <div\n    class=\"cub-menu-panel\"\n    [id]=\"panelId\"\n    [ngClass]=\"_classList\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"closed.emit('click')\"\n    [@transformMenu]=\"_panelAnimationState\"\n    (@transformMenu.start)=\"_onAnimationStart($event)\"\n    (@transformMenu.done)=\"_onAnimationDone($event)\"\n    tabindex=\"-1\"\n    role=\"menu\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [class.cub-menu-small]=\"size === 'small'\"\n  >\n    <div class=\"cub-menu-content\">\n      <ng-content></ng-content>\n    </div>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_MENU_DEFAULT_OPTIONS]
                }] }, { type: i0.ChangeDetectorRef }] });

class CubMenuGroup {
    constructor() {
        /*
         * 用於設定 menu group 的 標題， 預設值為 ''。
         */
        this.label = '';
    }
    handleClick(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubMenuGroup, isStandalone: true, selector: "cub-menu-item-group", inputs: { label: "label" }, ngImport: i0, template: "<div class=\"cub-menu-item-group\">\n  <div\n    tabindex=\"-1\"\n    class=\"cub-menu-item-group-layout\"\n    (click)=\"handleClick($event)\"\n  >\n    <span class=\"cub-menu-item-group-label\">{{ label }}</span>\n  </div>\n  <ng-content></ng-content>\n</div>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-menu-item-group', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div class=\"cub-menu-item-group\">\n  <div\n    tabindex=\"-1\"\n    class=\"cub-menu-item-group-layout\"\n    (click)=\"handleClick($event)\"\n  >\n    <span class=\"cub-menu-item-group-label\">{{ label }}</span>\n  </div>\n  <ng-content></ng-content>\n</div>\n" }]
        }], propDecorators: { label: [{
                type: Input
            }] } });

const passiveEventListenerOptions = normalizePassiveListenerOptions({
    passive: true,
});
class _CubMenuTriggerBase {
    get menuOpen() {
        return this._menuOpen;
    }
    get dir() {
        return this._dir && this._dir.value === 'rtl' ? 'rtl' : 'ltr';
    }
    /**
     * 欲於綁定開啟 menu 的元件，預設值為 undefined。
     */
    get menu() {
        return this._menu;
    }
    set menu(menu) {
        if (menu === this._menu) {
            return;
        }
        this._menu = menu;
        this._menuCloseSubscription.unsubscribe();
        if (menu) {
            if (menu === this._parentMaterialMenu) {
                throwMenuRecursiveError();
            }
            this._menuCloseSubscription = menu.closed.subscribe((reason) => {
                this._destroyMenu(reason);
                if ((reason === 'click' || reason === 'tab') &&
                    this._parentMaterialMenu) {
                    this._parentMaterialMenu.closed.emit(reason);
                }
            });
        }
        this._menuItemInstance?._setTriggersSubmenu(this.triggersSubmenu());
    }
    constructor(_overlay, _element, _viewContainerRef, scrollStrategy, parentMenu, _menuItemInstance, _dir, _focusMonitor, _ngZone) {
        this._overlay = _overlay;
        this._element = _element;
        this._viewContainerRef = _viewContainerRef;
        this._menuItemInstance = _menuItemInstance;
        this._dir = _dir;
        this._focusMonitor = _focusMonitor;
        this._ngZone = _ngZone;
        this._openedBy = undefined;
        this._overlayRef = null;
        this._menuOpen = false;
        this._closingActionsSubscription = Subscription.EMPTY;
        this._hoverSubscription = Subscription.EMPTY;
        this._menuCloseSubscription = Subscription.EMPTY;
        this._outsideClickSubscription = null;
        this._onDestroy = new Subject();
        /**
         * menu 關閉時是否應恢復焦點，預設值為 true。
         */
        this.restoreFocus = true;
        /**
         * menu 打開時送出的事件。
         */
        this.menuOpened = new EventEmitter();
        /**
         * menu 關閉時送出的事件。
         */
        this.menuClosed = new EventEmitter();
        this._handleTouchStart = (event) => {
            if (!isFakeTouchstartFromScreenReader(event)) {
                this._openedBy = 'touch';
            }
        };
        this._scrollStrategy = scrollStrategy;
        this._parentMaterialMenu =
            parentMenu instanceof _CubMenuBase ? parentMenu : undefined;
        _element.nativeElement.addEventListener('touchstart', this._handleTouchStart, passiveEventListenerOptions);
    }
    ngAfterContentInit() {
        this._handleHover();
    }
    ngOnDestroy() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef = null;
        }
        this._element.nativeElement.removeEventListener('touchstart', this._handleTouchStart, passiveEventListenerOptions);
        this._onDestroy.next();
        this._onDestroy.complete();
        if (this._outsideClickSubscription) {
            this._outsideClickSubscription.unsubscribe();
            this._outsideClickSubscription = null;
        }
        this._menuCloseSubscription.unsubscribe();
        this._closingActionsSubscription.unsubscribe();
        this._hoverSubscription.unsubscribe();
    }
    triggersSubmenu() {
        return !!(this._menuItemInstance && this._parentMaterialMenu && this.menu);
    }
    toggleMenu() {
        return this._menuOpen ? this.closeMenu() : this.openMenu();
    }
    openMenu() {
        const menu = this.menu;
        if (this._menuOpen || !menu) {
            return;
        }
        const overlayRef = this._createOverlay(menu);
        const overlayConfig = overlayRef.getConfig();
        const positionStrategy = overlayConfig.positionStrategy;
        this._setPosition(menu, positionStrategy);
        overlayConfig.hasBackdrop =
            menu.hasBackdrop == null ? !this.triggersSubmenu() : menu.hasBackdrop;
        overlayRef.attach(this._getPortal(menu));
        if (menu.lazyContent) {
            menu.lazyContent.attach(this.menuData);
        }
        this._closingActionsSubscription = this._menuClosingActions().subscribe(() => {
            this.closeMenu();
        });
        this._initMenu(menu);
        if (menu instanceof _CubMenuBase) {
            menu._startAnimation();
            menu._directDescendantItems.changes
                .pipe(takeUntil(menu.closed))
                .subscribe(() => {
                positionStrategy.withLockedPosition(false).reapplyLastPosition();
                positionStrategy.withLockedPosition(true);
            });
        }
    }
    closeMenu() {
        this.menu?.closed.emit();
    }
    focus(origin, options) {
        if (this._focusMonitor && origin) {
            this._focusMonitor.focusVia(this._element, origin, options);
        }
        else {
            this._element.nativeElement.focus(options);
        }
    }
    updatePosition() {
        this._overlayRef?.updatePosition();
    }
    _handleMousedown(event) {
        if (!isFakeMousedownFromScreenReader(event)) {
            this._openedBy = event.button === 0 ? 'mouse' : undefined;
            if (this.triggersSubmenu()) {
                event.preventDefault();
            }
        }
    }
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        if (keyCode === ENTER || keyCode === SPACE) {
            this._openedBy = 'keyboard';
        }
        if (this.triggersSubmenu() &&
            ((keyCode === RIGHT_ARROW && this.dir === 'ltr') ||
                (keyCode === LEFT_ARROW && this.dir === 'rtl'))) {
            this._openedBy = 'keyboard';
            this.openMenu();
        }
    }
    _handleClick(event) {
        if (this.triggersSubmenu()) {
            event.stopPropagation();
            this.openMenu();
        }
        else {
            this.toggleMenu();
        }
    }
    _destroyMenu(reason) {
        if (!this._overlayRef || !this.menuOpen) {
            return;
        }
        const menu = this.menu;
        this._closingActionsSubscription.unsubscribe();
        this._overlayRef.detach();
        if (this.restoreFocus &&
            (reason === 'keydown' || !this._openedBy || !this.triggersSubmenu())) {
            this.focus(this._openedBy);
        }
        this._openedBy = undefined;
        if (menu instanceof _CubMenuBase) {
            menu._resetAnimation();
            if (menu.lazyContent) {
                menu._animationDone
                    .pipe(filter((event) => event.toState === 'void'), take$1(1), 
                // Interrupt if the content got re-attached.
                takeUntil(menu.lazyContent._attached))
                    .subscribe({
                    next: () => menu.lazyContent.detach(),
                    complete: () => this._setIsMenuOpen(false),
                });
            }
            else {
                this._setIsMenuOpen(false);
            }
        }
        else {
            this._setIsMenuOpen(false);
            menu?.lazyContent?.detach();
        }
    }
    _initMenu(menu) {
        menu.parentMenu = this.triggersSubmenu()
            ? this._parentMaterialMenu
            : undefined;
        menu.direction = this.dir;
        this._setMenuElevation(menu);
        menu.size = menu.parentMenu ? this._menuItemInstance.size : menu.size;
        if (menu._allItems && menu.size) {
            menu._allItems.forEach((item) => {
                item.size = menu.size;
            });
        }
        menu.focusFirstItem(this._openedBy || 'program');
        this._setIsMenuOpen(true);
    }
    _setMenuElevation(menu) {
        if (menu.setElevation) {
            let depth = 0;
            let parentMenu = menu.parentMenu;
            while (parentMenu) {
                depth++;
                parentMenu = parentMenu.parentMenu;
            }
            menu.setElevation(depth);
        }
    }
    _setIsMenuOpen(isOpen) {
        this._menuOpen = isOpen;
        this._menuOpen ? this.menuOpened.emit() : this.menuClosed.emit();
        if (this.triggersSubmenu()) {
            this._menuItemInstance._setHighlighted(isOpen);
        }
    }
    _createOverlay(menu) {
        if (!this._overlayRef) {
            const config = this._getOverlayConfig(menu);
            this._subscribeToPositions(menu, config.positionStrategy);
            this._overlayRef = this._overlay.create(config);
            this._overlayRef.keydownEvents().subscribe();
            if (menu && !menu.hasBackdrop) {
                this._outsideClickSubscription = this._overlayRef
                    .outsidePointerEvents()
                    .pipe(takeUntil(this._onDestroy)) // Ensure unsubscription on component destroy
                    .subscribe((event) => {
                    if (event.target instanceof HTMLElement) {
                        let element = event.target;
                        while (element) {
                            // 排除當前觸發器
                            if (element === this._element.nativeElement) {
                                return;
                            }
                            // 排除帶有 cubMenuTriggerFor 的 cub-menu-item（巢狀子選單）
                            if (element.hasAttribute('cub-menu-item') &&
                                element.hasAttribute('cubmenutriggerfor')) {
                                return;
                            }
                            if (element.classList.contains('cdk-overlay-container')) {
                                break;
                            }
                            element = element.parentElement;
                        }
                    }
                    this.closeMenu(); // Call the menu's close method
                });
            }
        }
        return this._overlayRef;
    }
    _getOverlayConfig(menu) {
        return new OverlayConfig({
            positionStrategy: this._overlay
                .position()
                .flexibleConnectedTo(this._element)
                .withLockedPosition()
                .withGrowAfterOpen()
                .withTransformOriginOn('.cub-menu-panel, .cub-menu-panel'),
            backdropClass: menu.backdropClass || 'cub-cdk-overlay-transparent-backdrop',
            panelClass: menu.overlayPanelClass,
            scrollStrategy: this._scrollStrategy(),
            direction: this._dir,
        });
    }
    _subscribeToPositions(menu, position) {
        if (menu.setPositionClasses) {
            position.positionChanges.subscribe((change) => {
                const positionStart = change.connectionPair.overlayX === 'start' ? 'after' : 'before';
                const positionEnd = change.connectionPair.overlayY === 'top' ? 'below' : 'above';
                if (this._ngZone) {
                    this._ngZone.run(() => menu.setPositionClasses(positionStart, positionEnd));
                }
                else {
                    menu.setPositionClasses(positionStart, positionEnd);
                }
            });
        }
    }
    _setPosition(menu, positionStrategy) {
        /* 根據 positionStart 設定位置 originX 和 originFallbackX。
         originx 為 原點元素 上的水平連接點 fallback 為備用位置
        'start' 通常指左邊緣（或在 RTL 模式下指右邊緣）。
        'center' 指水平中點。
        'end' 通常指右邊緣（或在 RTL 模式下指左邊緣）。
        originY: 指定 原點元素 上的垂直連接點。
        'top' 指最上邊緣。
        'center' 指垂直中點。
        'bottom' 指最下邊緣。
        overlayX: 指定 彈出層 自身的水平連接點。
        參數與 originX 相同，但應用於彈出層。
        overlayY: 指定 彈出層 自身的垂直連接點。
        參數與 originY 相同，但應用於彈出層。
        */
        let originX = menu.positionStart === 'before' || menu.positionEnd === 'before'
            ? 'start'
            : menu.positionStart === 'after' || menu.positionEnd === 'after'
                ? 'end'
                : 'start';
        let originY = menu.positionStart === 'above' || menu.positionEnd === 'above'
            ? 'top'
            : menu.positionStart === 'below' || menu.positionEnd === 'below'
                ? 'bottom'
                : 'top';
        let [overlayX, overlayFallbackX] = menu.positionStart === 'below' || menu.positionStart === 'above'
            ? [originX, originX]
            : menu.positionStart === 'before'
                ? ['end', 'start']
                : ['start', 'end'];
        let [overlayY, overlayFallbackY] = menu.positionStart === 'before' || menu.positionStart === 'after'
            ? [originY, originY]
            : menu.positionStart === 'below'
                ? ['top', 'bottom']
                : ['bottom', 'top'];
        let originFallbackX = overlayX;
        let originFallbackY = overlayY;
        let offsetY = 0;
        if (this.triggersSubmenu()) {
            overlayFallbackX = originX =
                menu.positionStart === 'before' ? 'start' : 'end';
            originFallbackX = overlayX = originX === 'end' ? 'start' : 'end';
            originY = overlayY === 'top' ? 'top' : 'bottom';
            originFallbackY = overlayFallbackY === 'top' ? 'top' : 'bottom';
            if (this._parentMaterialMenu) {
                if (this._parentInnerPadding == null) {
                    const firstItem = this._parentMaterialMenu.items.first;
                    this._parentInnerPadding = firstItem
                        ? firstItem._getHostElement().offsetTop
                        : 0;
                }
                offsetY =
                    overlayY === 'bottom'
                        ? this._parentInnerPadding
                        : -this._parentInnerPadding;
            }
        }
        else if (!menu.overlapTrigger) {
            if (menu.positionStart !== 'before' && menu.positionStart !== 'after') {
                originY = overlayY === 'top' ? 'bottom' : 'top';
                originFallbackY = overlayFallbackY === 'top' ? 'bottom' : 'top';
            }
            else {
                originY = overlayY;
                originFallbackY = overlayFallbackY;
            }
        }
        positionStrategy.withPositions([
            { originX, originY, overlayX, overlayY, offsetY },
            {
                originX: originFallbackX,
                originY,
                overlayX: overlayFallbackX,
                overlayY,
                offsetY,
            },
            {
                originX,
                originY: originFallbackY,
                overlayX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
            {
                originX: originFallbackX,
                originY: originFallbackY,
                overlayX: overlayFallbackX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
        ]);
    }
    _menuClosingActions() {
        const backdrop = this._overlayRef.backdropClick();
        const detachments = this._overlayRef.detachments();
        const parentClose = this._parentMaterialMenu
            ? this._parentMaterialMenu.closed
            : of();
        const hover = this._parentMaterialMenu
            ? this._parentMaterialMenu._hovered().pipe(filter((active) => active !== this._menuItemInstance), filter(() => this._menuOpen))
            : of();
        return merge(backdrop, parentClose, hover, detachments);
    }
    _handleHover() {
        if (!this.triggersSubmenu() || !this._parentMaterialMenu) {
            return;
        }
        this._hoverSubscription = this._parentMaterialMenu
            ._hovered()
            .pipe(filter((active) => active === this._menuItemInstance && !active.disabled), delay(0, asapScheduler))
            .subscribe(() => {
            this._openedBy = 'mouse';
            if (this.menu instanceof _CubMenuBase && this.menu._isAnimating) {
                this.menu._animationDone
                    .pipe(take$1(1), delay(0, asapScheduler), takeUntil(this._parentMaterialMenu._hovered()))
                    .subscribe(() => this.openMenu());
            }
            else {
                this.openMenu();
            }
        });
    }
    _getPortal(menu) {
        if (!this._portal || this._portal.templateRef !== menu.templateRef) {
            this._portal = new TemplatePortal(menu.templateRef, this._viewContainerRef);
        }
        return this._portal;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubMenuTriggerBase, deps: [{ token: i1$1.Overlay }, { token: i0.ElementRef }, { token: i0.ViewContainerRef }, { token: CUB_MENU_SCROLL_STRATEGY }, { token: CUB_MENU_PANEL, optional: true }, { token: CubMenuItem, optional: true, self: true }, { token: i3.Directionality, optional: true }, { token: i1.FocusMonitor }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubMenuTriggerBase, isStandalone: true, inputs: { menu: ["cubMenuTriggerFor", "menu"], menuData: ["cubMenuTriggerData", "menuData"], restoreFocus: ["cubMenuTriggerRestoreFocus", "restoreFocus"] }, outputs: { menuOpened: "menuOpened", menuClosed: "menuClosed" }, host: { listeners: { "click": "_handleClick($event)", "mousedown": "_handleMousedown($event)", "keydown": "_handleKeydown($event)" }, properties: { "attr.aria-haspopup": "menu ? \"menu\" : null", "attr.aria-expanded": "menuOpen || null", "attr.aria-controls": "menuOpen ? menu.panelId : null" }, classAttribute: "cub-menu-trigger" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubMenuTriggerBase, decorators: [{
            type: Directive,
            args: [{
                    host: {
                        class: 'cub-menu-trigger',
                        '[attr.aria-haspopup]': 'menu ? "menu" : null',
                        '[attr.aria-expanded]': 'menuOpen || null',
                        '[attr.aria-controls]': 'menuOpen ? menu.panelId : null',
                        '(click)': '_handleClick($event)',
                        '(mousedown)': '_handleMousedown($event)',
                        '(keydown)': '_handleKeydown($event)',
                    },
                }]
        }], ctorParameters: () => [{ type: i1$1.Overlay }, { type: i0.ElementRef }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_MENU_SCROLL_STRATEGY]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_MENU_PANEL]
                }, {
                    type: Optional
                }] }, { type: CubMenuItem, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i3.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i1.FocusMonitor }, { type: i0.NgZone }], propDecorators: { menu: [{
                type: Input,
                args: ['cubMenuTriggerFor']
            }], menuData: [{
                type: Input,
                args: ['cubMenuTriggerData']
            }], restoreFocus: [{
                type: Input,
                args: ['cubMenuTriggerRestoreFocus']
            }], menuOpened: [{
                type: Output
            }], menuClosed: [{
                type: Output
            }] } });
class CubMenuTrigger extends _CubMenuTriggerBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuTrigger, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubMenuTrigger, isStandalone: true, selector: "[cubMenuTriggerFor]", host: { classAttribute: "cub-menu-trigger" }, exportAs: ["cubMenuTrigger"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: `[cubMenuTriggerFor]`,
                    host: {
                        class: 'cub-menu-trigger',
                    },
                    exportAs: 'cubMenuTrigger',
                }]
        }] });

class CubMenuModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubMenuModule, imports: [CubCdkScrollableModule,
            CubCommonModule,
            CubMenu,
            CubMenuItem,
            CubMenuGroup,
            CubMenuContent,
            CubMenuTrigger], exports: [CubCdkScrollableModule,
            CubCommonModule,
            CubMenu,
            CubMenuItem,
            CubMenuContent,
            CubMenuTrigger,
            CubMenuGroup] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubCdkScrollableModule,
            CubCommonModule,
            CubMenuItem, CubCdkScrollableModule,
            CubCommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkScrollableModule,
                        CubCommonModule,
                        CubMenu,
                        CubMenuItem,
                        CubMenuGroup,
                        CubMenuContent,
                        CubMenuTrigger,
                    ],
                    exports: [
                        CubCdkScrollableModule,
                        CubCommonModule,
                        CubMenu,
                        CubMenuItem,
                        CubMenuContent,
                        CubMenuTrigger,
                        CubMenuGroup,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/menu
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_MENU_CONTENT, CUB_MENU_DEFAULT_OPTIONS, CUB_MENU_DEFAULT_OPTIONS_FACTORY, CUB_MENU_PANEL, CUB_MENU_SCROLL_STRATEGY, CUB_MENU_SCROLL_STRATEGY_FACTORY, CUB_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER, CubMenu, CubMenuContent, CubMenuGroup, CubMenuItem, CubMenuModule, CubMenuTrigger, _CubMenuContentBase, _CubMenuTriggerBase, cubMenuAnimations, throwMenuInvalidPositionEnd, throwMenuInvalidPositionStart, throwMenuRecursiveError };
//# sourceMappingURL=cub-lib-view-rootng-component-menu.mjs.map
