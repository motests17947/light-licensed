import * as i0 from '@angular/core';
import { EventEmitter, ViewChild, Output, Input, ChangeDetectionStrategy, ViewEncapsulation, Component, Injectable, ContentChildren, NgModule } from '@angular/core';
import { NgClass, NgIf, NgTemplateOutlet, NgStyle, NgFor } from '@angular/common';
import { trigger, state, transition, style, animate, query, animateChild } from '@angular/animations';
import { Subject, takeUntil, take, Subscription } from 'rxjs';
import { CubTemplate } from 'cub-lib-view-rootng/component/common';
import { CubIconButton, CubButton } from 'cub-lib-view-rootng/component/button';

class CubNotificationItem {
    constructor() {
        this.destroy$ = new Subject();
        /**
         * 當關閉元件時發出通知。
         */
        this.closed = new EventEmitter();
    }
    ngOnInit() { }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    /**
     * 點擊關閉按鈕
     */
    onCloseIconClick(event) {
        this.closed.emit({
            index: this.index,
            notification: this.notification,
        });
        event.preventDefault();
    }
    /**
     * 點擊主要動作按鈕
     */
    onMainButtonClick(event) {
        this.notification?.mainButton?.command$
            ?.pipe(takeUntil(this.destroy$), take(1))
            .subscribe();
        if (this.notification?.mainButton?.isCloseButton) {
            this.onCloseIconClick(event);
        }
        event.preventDefault();
    }
    /**
     * 點擊次要動作按鈕
     */
    onSubButtonClick(event) {
        this.notification?.subButton?.command$
            ?.pipe(takeUntil(this.destroy$), take(1))
            .subscribe();
        if (this.notification?.subButton?.isCloseButton) {
            this.onCloseIconClick(event);
        }
        event.preventDefault();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationItem, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubNotificationItem, isStandalone: true, selector: "cub-notification-item", inputs: { notification: "notification", index: "index", templateRef: "templateRef", showTransformOptions: "showTransformOptions", hideTransformOptions: "hideTransformOptions", showTransitionOptions: "showTransitionOptions", hideTransitionOptions: "hideTransitionOptions" }, outputs: { closed: "closed" }, viewQueries: [{ propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true }], ngImport: i0, template: "<div\n  #container\n  [attr.id]=\"notification.id\"\n  [class]=\"notification.styleClass!\"\n  [ngClass]=\"[\n    'cub-notification-item-' + notification.status || 'neutral',\n    'cub-notification-item'\n  ]\"\n  [@notificationState]=\"{\n    value: 'visible',\n    params: {\n      showTransformParams: showTransformOptions,\n      hideTransformParams: hideTransformOptions,\n      showTransitionParams: showTransitionOptions,\n      hideTransitionParams: hideTransitionOptions\n    }\n  }\"\n>\n  <div\n    class=\"cub-notification-item-content\"\n    role=\"alert\"\n    aria-live=\"assertive\"\n    aria-atomic=\"true\"\n    [ngClass]=\"notification.contentStyleClass\"\n  >\n    <div class=\"cub-notification-item-icon\">\n      <span [class]=\"notification.icon || 'cub-icon-bell-filled'\"></span>\n    </div>\n    <ng-container *ngIf=\"!templateRef\">\n      <div class=\"cub-notification-item-text\">\n        <div class=\"cub-notification-item-title\">{{ notification.title }}</div>\n        <div\n          *ngIf=\"notification.message && notification.message.length > 0\"\n          class=\"cub-notification-item-message\"\n        >\n          {{ notification.message }}\n        </div>\n      </div>\n    </ng-container>\n    <ng-container\n      *ngTemplateOutlet=\"templateRef; context: { $implicit: notification }\"\n    ></ng-container>\n    <div class=\"cub-notification-item-close\">\n      <button\n        *ngIf=\"notification.closable !== false\"\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"plain\"\n        (click)=\"onCloseIconClick($event)\"\n      >\n        <span class=\"cub-icon-x-small\"></span>\n      </button>\n    </div>\n  </div>\n  @if(notification.mainButton || notification.subButton) {\n  <div class=\"cub-notification-item-actions\">\n    @if(notification.subButton) {\n    <button\n      class=\"cub-notification-item-sub-button\"\n      cub-button\n      type=\"button\"\n      [color]=\"'neutral-light'\"\n      (click)=\"onSubButtonClick($event)\"\n    >\n      {{ notification.subButton.label }}\n    </button>\n    } @if(notification.mainButton) {\n    <button\n      class=\"cub-notification-item-main-button\"\n      cub-button\n      type=\"button\"\n      [color]=\"notification.mainButton.color || 'neutral'\"\n      (click)=\"onMainButtonClick($event)\"\n    >\n      {{ notification.mainButton.label }}\n    </button>\n    }\n  </div>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }], animations: [
            trigger('notificationState', [
                state('visible', style({
                    transform: 'translateY(0)',
                    opacity: 1,
                })),
                transition('void => *', [
                    style({ transform: '{{showTransformParams}}', opacity: 0 }),
                    animate('{{showTransitionParams}}'),
                ]),
                transition('* => void', [
                    animate('{{hideTransitionParams}}', style({
                        opacity: 0,
                        transform: '{{hideTransformParams}}',
                    })),
                ]),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationItem, decorators: [{
            type: Component,
            args: [{ selector: 'cub-notification-item', animations: [
                        trigger('notificationState', [
                            state('visible', style({
                                transform: 'translateY(0)',
                                opacity: 1,
                            })),
                            transition('void => *', [
                                style({ transform: '{{showTransformParams}}', opacity: 0 }),
                                animate('{{showTransitionParams}}'),
                            ]),
                            transition('* => void', [
                                animate('{{hideTransitionParams}}', style({
                                    opacity: 0,
                                    transform: '{{hideTransformParams}}',
                                })),
                            ]),
                        ]),
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgClass, NgIf, NgTemplateOutlet, CubIconButton, CubButton], template: "<div\n  #container\n  [attr.id]=\"notification.id\"\n  [class]=\"notification.styleClass!\"\n  [ngClass]=\"[\n    'cub-notification-item-' + notification.status || 'neutral',\n    'cub-notification-item'\n  ]\"\n  [@notificationState]=\"{\n    value: 'visible',\n    params: {\n      showTransformParams: showTransformOptions,\n      hideTransformParams: hideTransformOptions,\n      showTransitionParams: showTransitionOptions,\n      hideTransitionParams: hideTransitionOptions\n    }\n  }\"\n>\n  <div\n    class=\"cub-notification-item-content\"\n    role=\"alert\"\n    aria-live=\"assertive\"\n    aria-atomic=\"true\"\n    [ngClass]=\"notification.contentStyleClass\"\n  >\n    <div class=\"cub-notification-item-icon\">\n      <span [class]=\"notification.icon || 'cub-icon-bell-filled'\"></span>\n    </div>\n    <ng-container *ngIf=\"!templateRef\">\n      <div class=\"cub-notification-item-text\">\n        <div class=\"cub-notification-item-title\">{{ notification.title }}</div>\n        <div\n          *ngIf=\"notification.message && notification.message.length > 0\"\n          class=\"cub-notification-item-message\"\n        >\n          {{ notification.message }}\n        </div>\n      </div>\n    </ng-container>\n    <ng-container\n      *ngTemplateOutlet=\"templateRef; context: { $implicit: notification }\"\n    ></ng-container>\n    <div class=\"cub-notification-item-close\">\n      <button\n        *ngIf=\"notification.closable !== false\"\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"plain\"\n        (click)=\"onCloseIconClick($event)\"\n      >\n        <span class=\"cub-icon-x-small\"></span>\n      </button>\n    </div>\n  </div>\n  @if(notification.mainButton || notification.subButton) {\n  <div class=\"cub-notification-item-actions\">\n    @if(notification.subButton) {\n    <button\n      class=\"cub-notification-item-sub-button\"\n      cub-button\n      type=\"button\"\n      [color]=\"'neutral-light'\"\n      (click)=\"onSubButtonClick($event)\"\n    >\n      {{ notification.subButton.label }}\n    </button>\n    } @if(notification.mainButton) {\n    <button\n      class=\"cub-notification-item-main-button\"\n      cub-button\n      type=\"button\"\n      [color]=\"notification.mainButton.color || 'neutral'\"\n      (click)=\"onMainButtonClick($event)\"\n    >\n      {{ notification.mainButton.label }}\n    </button>\n    }\n  </div>\n  }\n</div>\n" }]
        }], propDecorators: { notification: [{
                type: Input
            }], index: [{
                type: Input
            }], templateRef: [{
                type: Input
            }], showTransformOptions: [{
                type: Input
            }], hideTransformOptions: [{
                type: Input
            }], showTransitionOptions: [{
                type: Input
            }], hideTransitionOptions: [{
                type: Input
            }], closed: [{
                type: Output
            }], containerViewChild: [{
                type: ViewChild,
                args: ['container']
            }] } });

class CubNotificationService {
    constructor() {
        this.notificationSource = new Subject();
        this.clearSource = new Subject();
        this.clearItemSource = new Subject();
        this.notificationObserver = this.notificationSource.asObservable();
        this.clearObserver = this.clearSource.asObservable();
        this.clearItemObserver = this.clearItemSource.asObservable();
    }
    add(notification) {
        const uuid = this.generateInsecureUuid();
        if (!notification.id) {
            notification = { ...notification, id: uuid };
        }
        this.notificationSource.next(notification);
        return uuid;
    }
    addAll(notifications) {
        if (notifications?.length) {
            notifications = notifications.map((notification) => {
                const uuid = this.generateInsecureUuid();
                if (!notification.id) {
                    notification = { ...notification, id: uuid };
                }
                return notification;
            });
            this.notificationSource.next(notifications);
            return notifications.map((notification) => notification.id);
        }
        return [];
    }
    clear(key) {
        this.clearSource.next(key);
    }
    clearItem(id, key) {
        if (id) {
            this.clearItemSource.next({ key, id });
        }
    }
    destroy() {
        this.notificationSource.complete();
        this.clearSource.complete();
        this.clearItemSource.complete();
    }
    generateInsecureUuid() {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) {
            return crypto.randomUUID();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = (Math.random() * 16) | 0, v = c == 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class CubNotification {
    constructor(notificationService, changeDetectorRef) {
        this.notificationService = notificationService;
        this.changeDetectorRef = changeDetectorRef;
        this.notifications = [];
        this.notificationsArchive = [];
        // 配置選項
        this.preventOpenDuplicates = false;
        this.preventDuplicates = false;
        this.showTransformOptions = 'translateY(-100%)';
        this.hideTransformOptions = 'translateY(-100%)';
        this.showTransitionOptions = '300ms ease-out';
        this.hideTransitionOptions = '250ms ease-in';
        this.subscriptions = new Subscription();
        /**
         * 當關閉元件時發出通知。
         */
        this.closed = new EventEmitter();
    }
    ngOnInit() {
        this.initializeSubscriptions();
    }
    ngAfterContentInit() {
        this.setupTemplates();
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    onNotificationClose(event) {
        if (!this.notifications)
            return;
        this.notifications.splice(event.index, 1);
        this.closed.emit({ notification: event.notification });
        this.changeDetectorRef.detectChanges();
    }
    initializeSubscriptions() {
        // 通知訂閱
        this.subscriptions.add(this.notificationService.notificationObserver.subscribe((notifications) => {
            this.handleNewNotifications(notifications);
        }));
        // 清空訂閱
        this.subscriptions.add(this.notificationService.clearObserver.subscribe((key) => {
            this.handleClearNotifications(key);
        }));
        // 清除單項訂閱
        this.subscriptions.add(this.notificationService.clearItemObserver.subscribe(({ key, id }) => {
            this.handleClearItem(id, key);
        }));
    }
    setupTemplates() {
        this.templates.forEach((item) => {
            switch (item.getType()) {
                case 'notification':
                default:
                    this.templateRef = item.template;
                    break;
            }
        });
    }
    handleNewNotifications(notifications) {
        if (!notifications)
            return;
        const notificationsArray = Array.isArray(notifications)
            ? notifications
            : [notifications];
        const filteredNotifications = notificationsArray.filter((notification) => this.canAddNotification(notification));
        if (filteredNotifications.length > 0) {
            this.addNotifications(filteredNotifications);
        }
    }
    handleClearNotifications(key) {
        this.notifications = this.notifications.filter((notification) => notification.key !== key);
        this.changeDetectorRef.markForCheck();
    }
    handleClearItem(id, key) {
        if (this.key !== key)
            return;
        if (this.notifications && id) {
            const removedNotification = this.notifications.filter((notification) => notification.id === id)?.[0];
            this.notifications = this.notifications.filter((notification) => notification.id !== id);
            this.closed.emit({ notification: removedNotification });
            this.changeDetectorRef.markForCheck();
        }
    }
    addNotifications(notifications) {
        this.notifications = this.notifications
            ? [...this.notifications, ...notifications]
            : [...notifications];
        if (this.preventDuplicates) {
            this.notificationsArchive = [
                ...this.notificationsArchive,
                ...notifications,
            ];
        }
        this.changeDetectorRef.markForCheck();
    }
    canAddNotification(notification) {
        const isKeyMatch = this.key === notification.key;
        if (!isKeyMatch)
            return false;
        if (this.preventOpenDuplicates &&
            this.containsNotification(this.notifications, notification)) {
            return false;
        }
        if (this.preventDuplicates &&
            this.containsNotification(this.notificationsArchive, notification)) {
            return false;
        }
        return true;
    }
    containsNotification(collection, notification) {
        if (!collection?.length)
            return false;
        return collection.some((item) => item.title === notification.title &&
            item.message === notification.message &&
            item.status === notification.status);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotification, deps: [{ token: CubNotificationService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubNotification, isStandalone: true, selector: "cub-notification", inputs: { key: "key", style: "style", styleClass: "styleClass" }, outputs: { closed: "closed" }, queries: [{ propertyName: "templates", predicate: CubTemplate }], viewQueries: [{ propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true }], ngImport: i0, template: "<div\n  #container\n  [ngClass]=\"'cub-notification cub-notification-top-right'\"\n  [ngStyle]=\"style\"\n  [class]=\"styleClass\"\n>\n  <cub-notification-item\n    *ngFor=\"let notification of notifications; let index = index\"\n    [notification]=\"notification\"\n    [index]=\"index\"\n    (closed)=\"onNotificationClose($event)\"\n    [templateRef]=\"templateRef\"\n    @notificationAnimation\n    [showTransformOptions]=\"showTransformOptions\"\n    [hideTransformOptions]=\"hideTransformOptions\"\n    [showTransitionOptions]=\"showTransitionOptions\"\n    [hideTransitionOptions]=\"hideTransitionOptions\"\n  ></cub-notification-item>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CubNotificationItem, selector: "cub-notification-item", inputs: ["notification", "index", "templateRef", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions"], outputs: ["closed"] }], animations: [
            trigger('notificationAnimation', [
                transition(':enter, :leave', [query('@*', animateChild())]),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotification, decorators: [{
            type: Component,
            args: [{ selector: 'cub-notification', animations: [
                        trigger('notificationAnimation', [
                            transition(':enter, :leave', [query('@*', animateChild())]),
                        ]),
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [NgClass, NgStyle, NgFor, CubNotificationItem], template: "<div\n  #container\n  [ngClass]=\"'cub-notification cub-notification-top-right'\"\n  [ngStyle]=\"style\"\n  [class]=\"styleClass\"\n>\n  <cub-notification-item\n    *ngFor=\"let notification of notifications; let index = index\"\n    [notification]=\"notification\"\n    [index]=\"index\"\n    (closed)=\"onNotificationClose($event)\"\n    [templateRef]=\"templateRef\"\n    @notificationAnimation\n    [showTransformOptions]=\"showTransformOptions\"\n    [hideTransformOptions]=\"hideTransformOptions\"\n    [showTransitionOptions]=\"showTransitionOptions\"\n    [hideTransitionOptions]=\"hideTransitionOptions\"\n  ></cub-notification-item>\n</div>\n" }]
        }], ctorParameters: () => [{ type: CubNotificationService }, { type: i0.ChangeDetectorRef }], propDecorators: { key: [{
                type: Input
            }], style: [{
                type: Input
            }], styleClass: [{
                type: Input
            }], closed: [{
                type: Output
            }], containerViewChild: [{
                type: ViewChild,
                args: ['container']
            }], templates: [{
                type: ContentChildren,
                args: [CubTemplate]
            }] } });

class CubNotificationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationModule, imports: [CubNotification, CubNotificationItem], exports: [CubNotification, CubNotificationItem] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationModule, imports: [CubNotification, CubNotificationItem] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNotificationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubNotification, CubNotificationItem],
                    exports: [CubNotification, CubNotificationItem],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/notification
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubNotification, CubNotificationItem, CubNotificationModule, CubNotificationService };
//# sourceMappingURL=cub-lib-view-rootng-component-notification.mjs.map
