import * as i0 from '@angular/core';
import { InjectionToken, Input, Inject, Optional, Directive, EventEmitter, Output, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { NgIf } from '@angular/common';
import { mixinDisabled, CubDivider, CubRipple } from 'cub-lib-view-rootng/component/common';
import { CubCheckbox } from 'cub-lib-view-rootng/component/checkbox';
import { Subject } from 'rxjs';
import { ENTER, SPACE, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';

// Notes on the accessibility pattern used for `cub-option-group`.
// The option group has two different "modes": regular and inert. The regular mode uses the
// recommended a11y pattern which has `role="group"` on the group element with `aria-labelledby`
// pointing to the label. This works for `cub-select`, but it seems to hit a bug for autocomplete
// under VoiceOver where the group doesn't get read out at all. The bug appears to be that if
// there's __any__ a11y-related attribute on the group (e.g. `role` or `aria-labelledby`),
// VoiceOver on Safari won't read it out.
// We've introduced the `inert` mode as a workaround. Under this mode, all a11y attributes are
// removed from the group, and we get the screen reader to read out the group label by mirroring it
// inside an invisible element in the option. This is sub-optimal, because the screen reader will
// repeat the group label on each navigation, whereas the default pattern only reads the group when
// the user enters a new group. The following alternate approaches were considered:
// 1. Reading out the group label using the `LiveAnnouncer` solves the problem, but we can't control
//    when the text will be read out so sometimes it comes in too late or never if the user
//    navigates quickly.
// 2. `<cub-option aria-describedby="groupLabel"` - This works on Safari, but VoiceOver in Chrome
//    won't read out the description at all.
// 3. `<cub-option aria-labelledby="optionLabel groupLabel"` - This works on Chrome, but Safari
//     doesn't read out the text at all. Furthermore, on
// Boilerplate for applying mixins to CubOptionGroup.
/** @docs-private */
const _CubOptionGroupMixinBase = mixinDisabled(class {
});
/**
 * Injection token used to provide the parent component to options.
 */
const CUB_OPTION_PARENT = new InjectionToken('CUB_OPTION_PARENT');

/** Event object emitted by CubOption when selected or deselected. */
class CubOptionSelectionChange {
    constructor(
    /** Reference to the option that emitted the event. */
    source, 
    /** Whether the change in the option's value was a result of a user action. */
    isUserInput = false) {
        this.source = source;
        this.isUserInput = isUserInput;
    }
}

// Counter for unique group ids.
let _uniqueOptionGroupIdCounter = 0;
class _CubOptionGroupBase extends _CubOptionGroupMixinBase {
    constructor(parent) {
        super();
        /** Unique id for the underlying label. */
        this._labelId = `cub-option-group-label-${_uniqueOptionGroupIdCounter++}`;
        /** 元件標題，預設為 ''。 */
        this.label = '';
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        this._inert = parent?.inertGroups ?? false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubOptionGroupBase, deps: [{ token: CUB_OPTION_PARENT, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubOptionGroupBase, isStandalone: true, inputs: { label: "label", size: "size" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubOptionGroupBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_OPTION_PARENT]
                }, {
                    type: Optional
                }] }], propDecorators: { label: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

/**
 * Option IDs need to be unique across components, so this counter exists outside of
 * the component definition.
 */
let _uniqueIdCounter = 0;
class _CubOptionBase {
    /** Whether the wrapping component is in multiple selection mode. */
    get multiple() {
        return this._parent && this._parent.multiple;
    }
    /** Whether or not the option is currently selected. */
    get selected() {
        return this._selected;
    }
    /**
     * Whether or not the option is currently active and ready to be selected.
     * An active option displays styles as if it is focused, but the
     * focus is actually retained somewhere else. This comes in handy
     * for components like autocomplete where focus must remain on the input.
     */
    get active() {
        return this._active;
    }
    /**
     * The displayed value of the option. It is necessary to show the selected option in the
     * select's trigger.
     */
    get viewValue() {
        // TODO(kara): Add input property alternative for node envs.
        return (this._getHostElement().textContent || '').trim();
    }
    /** Whether ripples for the option are disabled. */
    get disableRipple() {
        return !!(this._parent && this._parent.disableRipple);
    }
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        return (this.group && this.group.disabled) || this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    constructor(_element, _changeDetectorRef, _parent, group) {
        this._element = _element;
        this._changeDetectorRef = _changeDetectorRef;
        this._parent = _parent;
        this.group = group;
        this.isKeydownActive = false;
        /** Emits when the state of the option changes and any parents have to be notified. */
        this._stateChanges = new Subject();
        this._selected = false;
        this._active = false;
        this._disabled = false;
        this._mostRecentViewValue = '';
        /** 元件 id，預設為 'cub-option-0'。 */
        this.id = `cub-option-${_uniqueIdCounter++}`;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 當更改了選定值時發出通知。 */
        this.selectionChange = new EventEmitter();
    }
    ngAfterViewChecked() {
        // Since parent components could be using the option's label to display the selected values
        // (e.g. `cub-select`) and they don't have a way of knowing if the option's label has changed
        // we have to check for changes in the DOM ourselves and dispatch an event. These checks are
        // relatively cheap, however we still limit them only to selected options in order to avoid
        // hitting the DOM too often.
        if (this._selected) {
            const viewValue = this.viewValue;
            if (viewValue !== this._mostRecentViewValue) {
                this._mostRecentViewValue = viewValue;
                this._stateChanges.next();
            }
        }
    }
    ngOnDestroy() {
        this._stateChanges.complete();
    }
    /** Selects the option. */
    select() {
        if (!this._selected) {
            this._selected = true;
            this._changeDetectorRef.markForCheck();
            this._emitSelectionChangeEvent();
        }
    }
    /** Deselects the option. */
    deselect() {
        if (this._selected) {
            this._selected = false;
            this._changeDetectorRef.markForCheck();
            this._emitSelectionChangeEvent();
        }
    }
    /** Sets focus onto this option. */
    focus(_origin, options) {
        // Note that we aren't using `_origin`, but we need to keep it because some internal consumers
        // use `CubOption` in a `FocusKeyManager` and we need it to match `FocusableOption`.
        const element = this._getHostElement();
        if (typeof element.focus === 'function') {
            element.focus(options);
        }
    }
    /**
     * This method sets display styles on the option to make it appear
     * active. This is used by the ActiveDescendantKeyManager so key
     * events will display the proper options as active on arrow key events.
     */
    setActiveStyles() {
        if (!this._active) {
            this._active = true;
            this._changeDetectorRef.markForCheck();
        }
    }
    /**
     * This method removes display styles on the option that made it appear
     * active. This is used by the ActiveDescendantKeyManager so key
     * events will display the proper options as active on arrow key events.
     */
    setInactiveStyles() {
        if (this._active) {
            this._active = false;
            this._changeDetectorRef.markForCheck();
        }
    }
    /** Gets the label to be used when determining whether the option should be focused. */
    getLabel() {
        return this.viewValue;
    }
    /** Ensures the option is selected when activated from the keyboard. */
    _handleKeydown(event) {
        this.isKeydownActive = true;
        if ((event.keyCode === ENTER || event.keyCode === SPACE) &&
            !hasModifierKey(event)) {
            this._selectViaInteraction();
            // Prevent the page from scrolling down and form submits.
            event.preventDefault();
        }
    }
    _handleClick(event) {
        this.isKeydownActive = false;
        this._selectViaInteraction();
        // 阻止點擊到 checkbox
        event.preventDefault();
    }
    /**
     * `Selects the option while indicating the selection came from the user. Used to
     * determine if the select's view -> model callback should be invoked.`
     */
    _selectViaInteraction() {
        if (!this.disabled) {
            this._selected = this.multiple ? !this._selected : true;
            this._changeDetectorRef.markForCheck();
            this._emitSelectionChangeEvent(true);
        }
    }
    /**
     * Gets the `aria-selected` value for the option. We explicitly omit the `aria-selected`
     * attribute from single-selection, unselected options. Including the `aria-selected="false"`
     * attributes adds a significant amount of noise to screen-reader users without providing useful
     * information.
     */
    _getAriaSelected() {
        return this.selected || (this.multiple ? false : null);
    }
    /** Returns the correct tabindex for the option depending on disabled state. */
    _getTabIndex() {
        return this.disabled ? '-1' : '0';
    }
    /** Gets the host DOM element. */
    _getHostElement() {
        return this._element.nativeElement;
    }
    /** Emits the selection change event. */
    _emitSelectionChangeEvent(isUserInput = false) {
        this.selectionChange.emit(new CubOptionSelectionChange(this, isUserInput));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubOptionBase, deps: "invalid", target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubOptionBase, isStandalone: true, inputs: { value: "value", id: "id", size: "size", disabled: "disabled" }, outputs: { selectionChange: "selectionChange" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubOptionBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: undefined }, { type: _CubOptionGroupBase }], propDecorators: { value: [{
                type: Input
            }], id: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }] } });

/**
 * Injection token that can be used to reference instances of `CubOptionGroup`. It serves as
 * alternative token to the actual `CubOptionGroup` class which could cause unnecessary
 * retention of the class and its component metadata.
 */
const CUB_OPTION_GROUP = new InjectionToken('CubOptionGroup');
/**
 * Component that is used to group instances of `cub-option`.
 */
class CubOptionGroup extends _CubOptionGroupBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOptionGroup, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubOptionGroup, isStandalone: true, selector: "cub-option-group", inputs: { disabled: "disabled" }, host: { properties: { "class.cub-option-group-small": "size === \"small\"", "class.cub-disabled": "disabled", "attr.role": "_inert ? null : \"group\"", "attr.aria-disabled": "_inert ? null : disabled.toString()", "attr.aria-labelledby": "_inert ? null : _labelId" }, classAttribute: "cub-option-group" }, providers: [{ provide: CUB_OPTION_GROUP, useExisting: CubOptionGroup }], exportAs: ["cubOptionGroup"], usesInheritance: true, ngImport: i0, template: "<div class=\"cub-option-group-divider\">\n  <cub-divider></cub-divider>\n</div>\n\n<span class=\"cub-option-group-label\" aria-hidden=\"true\" [id]=\"_labelId\">\n  {{ label }}\n  <ng-content></ng-content>\n</span>\n\n<ng-content select=\"cub-option, ng-container\"></ng-content>\n", styles: [""], dependencies: [{ kind: "directive", type: CubDivider, selector: "[cubDivider], cub-divider", inputs: ["appearance", "orientation"], exportAs: ["cubDivider"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOptionGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-option-group', exportAs: 'cubOptionGroup', inputs: ['disabled'], host: {
                        class: 'cub-option-group',
                        '[class.cub-option-group-small]': 'size === "small"',
                        '[class.cub-disabled]': 'disabled',
                        '[attr.role]': '_inert ? null : "group"',
                        '[attr.aria-disabled]': '_inert ? null : disabled.toString()',
                        '[attr.aria-labelledby]': '_inert ? null : _labelId',
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: CUB_OPTION_GROUP, useExisting: CubOptionGroup }], imports: [CubDivider], template: "<div class=\"cub-option-group-divider\">\n  <cub-divider></cub-divider>\n</div>\n\n<span class=\"cub-option-group-label\" aria-hidden=\"true\" [id]=\"_labelId\">\n  {{ label }}\n  <ng-content></ng-content>\n</span>\n\n<ng-content select=\"cub-option, ng-container\"></ng-content>\n" }]
        }] });

/**
 * Single option inside of a `<cub-select>` element.
 */
class CubOption extends _CubOptionBase {
    constructor(element, changeDetectorRef, parent, group) {
        super(element, changeDetectorRef, parent, group);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOption, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: CUB_OPTION_PARENT, optional: true }, { token: CUB_OPTION_GROUP, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubOption, isStandalone: true, selector: "cub-option", host: { attributes: { "role": "option" }, listeners: { "click": "_handleClick($event)", "keydown": "_handleKeydown($event)" }, properties: { "class.cub-option-multiple": "multiple", "class.cub-option-small": "size === \"small\"", "class.cub-active": "active && isKeydownActive", "class.cub-selected": "selected", "class.cub-disabled": "disabled", "id": "id", "attr.tabindex": "_getTabIndex()", "attr.aria-selected": "_getAriaSelected()", "attr.aria-disabled": "disabled.toString()" }, classAttribute: "cub-option cub-focus-indicator" }, exportAs: ["cubOption"], usesInheritance: true, ngImport: i0, template: "<cub-checkbox\n  *ngIf=\"multiple\"\n  [tabIndex]=\"-1\"\n  [size]=\"size\"\n  [checked]=\"selected\"\n  [disabled]=\"disabled\"\n></cub-checkbox>\n\n<span class=\"cub-option-text\">\n  <ng-content></ng-content>\n</span>\n\n<!-- See a11y notes inside option-group.ts for context behind this element. -->\n<span class=\"cub-cdk-visually-hidden\" *ngIf=\"group && group._inert\">\n  ({{ group.label }})\n</span>\n\n<div\n  cubRipple\n  cubRippleClass=\"cub-option-ripple\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n  [cubRippleDisabled]=\"disabled || disableRipple\"\n></div>\n\n<span class=\"cub-persistent-ripple cub-option-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CubCheckbox, selector: "cub-checkbox", inputs: ["disableRipple", "tabIndex", "size"], exportAs: ["cubCheckbox"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOption, decorators: [{
            type: Component,
            args: [{ selector: 'cub-option', exportAs: 'cubOption', host: {
                        role: 'option',
                        class: 'cub-option cub-focus-indicator',
                        '[class.cub-option-multiple]': 'multiple',
                        '[class.cub-option-small]': 'size === "small"',
                        '[class.cub-active]': 'active && isKeydownActive',
                        '[class.cub-selected]': 'selected',
                        '[class.cub-disabled]': 'disabled',
                        '[id]': 'id',
                        '[attr.tabindex]': '_getTabIndex()',
                        '[attr.aria-selected]': '_getAriaSelected()',
                        '[attr.aria-disabled]': 'disabled.toString()',
                        '(click)': '_handleClick($event)',
                        '(keydown)': '_handleKeydown($event)',
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, CubCheckbox, CubRipple], template: "<cub-checkbox\n  *ngIf=\"multiple\"\n  [tabIndex]=\"-1\"\n  [size]=\"size\"\n  [checked]=\"selected\"\n  [disabled]=\"disabled\"\n></cub-checkbox>\n\n<span class=\"cub-option-text\">\n  <ng-content></ng-content>\n</span>\n\n<!-- See a11y notes inside option-group.ts for context behind this element. -->\n<span class=\"cub-cdk-visually-hidden\" *ngIf=\"group && group._inert\">\n  ({{ group.label }})\n</span>\n\n<div\n  cubRipple\n  cubRippleClass=\"cub-option-ripple\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n  [cubRippleDisabled]=\"disabled || disableRipple\"\n></div>\n\n<span class=\"cub-persistent-ripple cub-option-persistent-ripple\"></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_OPTION_PARENT]
                }] }, { type: CubOptionGroup, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_OPTION_GROUP]
                }] }] });

/**
 * Counts the amount of option group labels that precede the specified option.
 * @param optionIndex Index of the option at which to start counting.
 * @param options Flat list of all of the options.
 * @param optionGroups Flat list of all of the option groups.
 * @docs-private
 */
function _countGroupLabelsBeforeOption(optionIndex, options, optionGroups) {
    if (optionGroups.length) {
        let optionsArray = options.toArray();
        let groups = optionGroups.toArray();
        let groupCounter = 0;
        for (let i = 0; i < optionIndex + 1; i++) {
            if (optionsArray[i].group &&
                optionsArray[i].group === groups[groupCounter]) {
                groupCounter++;
            }
        }
        return groupCounter;
    }
    return 0;
}
/**
 * Determines the position to which to scroll a panel in order for an option to be into view.
 * @param optionOffset Offset of the option from the top of the panel.
 * @param optionHeight Height of the options.
 * @param currentScrollPosition Current scroll position of the panel.
 * @param panelHeight Height of the panel.
 * @docs-private
 */
function _getOptionScrollPosition(optionOffset, optionHeight, currentScrollPosition, panelHeight) {
    if (optionOffset < currentScrollPosition) {
        return optionOffset;
    }
    if (optionOffset + optionHeight > currentScrollPosition + panelHeight) {
        return Math.max(0, optionOffset - panelHeight + optionHeight);
    }
    return currentScrollPosition;
}

class CubOptionModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOptionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubOptionModule, imports: [CubOption, CubOptionGroup], exports: [CubOption, CubOptionGroup] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOptionModule, imports: [CubOption] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubOptionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubOption, CubOptionGroup],
                    exports: [CubOption, CubOptionGroup],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/option
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_OPTION_GROUP, CUB_OPTION_PARENT, CubOption, CubOptionGroup, CubOptionModule, CubOptionSelectionChange, _CubOptionBase, _CubOptionGroupBase, _CubOptionGroupMixinBase, _countGroupLabelsBeforeOption, _getOptionScrollPosition };
//# sourceMappingURL=cub-lib-view-rootng-component-option.mjs.map
