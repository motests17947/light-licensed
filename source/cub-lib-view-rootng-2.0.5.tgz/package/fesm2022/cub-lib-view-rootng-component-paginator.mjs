import * as i0 from '@angular/core';
import { EventEmitter, HostListener, ViewChild, Output, Input, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NgIf, NgStyle, NgClass, NgFor, NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Subject, debounceTime, startWith, pairwise, takeUntil, fromEvent } from 'rxjs';
import { mixinDisabled, mixinDisableRipple, DEVICE_BREAKPOINT, CubRipple } from 'cub-lib-view-rootng/component/common';
import { CubFormField } from 'cub-lib-view-rootng/component/form-field';
import { CubSelect, CUB_SELECT_SCROLL_STRATEGY_PROVIDER } from 'cub-lib-view-rootng/component/select';
import { CubOption } from 'cub-lib-view-rootng/component/option';
import { CubInput } from 'cub-lib-view-rootng/component/input';
import { CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';

const _CubPaginatorMixinBase = mixinDisabled(mixinDisableRipple(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}));
class CubPaginator extends _CubPaginatorMixinBase {
    get pageRange() {
        const first = this.totalRecords > 0 ? this.getFirst() + 1 : 0;
        const last = Math.min(this.getFirst() + this.pageSize, this.totalRecords);
        return this.pageRangeTemplate
            .replace('{currentPage}', String(this.getCurrentPage()))
            .replace('{totalPages}', String(this.getPageCount()))
            .replace('{first}', String(first))
            .replace('{last}', String(last))
            .replace('{pageSize}', String(this.pageSize))
            .replace('{totalRecords}', String(this.totalRecords));
    }
    /** 頁數連結的顯示個數，預設為 5。 */
    get pageLinkSize() {
        return this.pageLinkAutoSize
            ? this._pageLinkSizeByContainerWidth
            : this._pageLinkSize;
    }
    set pageLinkSize(value) {
        this._pageLinkSize = value;
    }
    /** 當前頁數的索引值，預設為 0。 */
    get pageIndex() {
        return this._pageIndex;
    }
    set pageIndex(value) {
        this._pageIndex = value;
    }
    /* 調整瀏覽器視窗，判斷是否顯示精簡版樣式 */
    onResize(event) {
        const windowWidth = event.target.innerWidth;
        this.isStreamlined = this.isMobileWidth(windowWidth);
    }
    constructor(elementRef, _changeDetectorRef) {
        super(elementRef);
        this.elementRef = elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this.currentPageCtrl = new FormControl();
        /* 是否精簡顯示版本，隱藏左右兩側資訊，僅保留中間的跳頁按鈕 */
        this.isStreamlined = false;
        this._pageLinkSize = 5;
        this._pageLinkSizeByContainerWidth = 5;
        this._pageIndex = 0;
        this._destroyed = new Subject();
        this._doCheckSubject = new Subject();
        /** 當總頁數為一頁時是否顯示分頁器，預設為 true。 */
        this.alwaysShow = true;
        /** 頁數資訊的模板，預設為 '{first} - {last} / {totalRecords}'。 */
        this.pageRangeTemplate = '{first} - {last} / {totalRecords}';
        /** 跳至指定頁數的模板，預設為 '跳至' */
        this.jumpToTemplate = '跳至';
        // @Input() jumpToTemplate: string = '跳至 {currentPage} / {pageCount}';
        /** 是否顯示頁數資訊，預設為 true。 */
        this.showPageRange = true;
        /** 是否顯示往第一頁與往最後一頁的按鈕，預設為 true。 */
        this.showFirstLastButton = true;
        /** 是否自動計算頁數連結的顯示個數，預設為 true。 */
        this.pageLinkAutoSize = true;
        /** 總筆數，預設為 0。 */
        this.totalRecords = 0;
        /** 每頁顯示筆數，預設為 10。 */
        this.pageSize = 10;
        /** 每頁顯示筆數選項，預設為 [10, 20, 30, 50, 100] */
        this.pageSizeOptions = [10, 20, 30, 50, 100];
        /** 是否隱藏每頁筆數的下拉選單，預設為 false。 */
        this.hidePageSize = false;
        /** 當頁面切換、顯示筆數變更或是排序更動時發出通知。 */
        this.pageChange = new EventEmitter();
    }
    ngOnInit() {
        /* 初始化判斷是否顯示精簡版樣式 */
        const windowWidth = window.innerWidth;
        this.isStreamlined = this.isMobileWidth(windowWidth);
        /* 初始化更新顯示頁數 */
        this.updatePaginatorState();
        this.updatePageSizeOptions();
        this._doCheckSubject
            .pipe(debounceTime(50), startWith(this.paginatorState), pairwise(), takeUntil(this._destroyed))
            .subscribe(([prevPaginatorState, nextPaginatorState]) => {
            if (prevPaginatorState.pageIndex !== nextPaginatorState.pageIndex ||
                prevPaginatorState.pageSize !== nextPaginatorState.pageSize) {
                this.pageChange.emit(nextPaginatorState);
            }
        });
    }
    ngAfterViewInit() {
        // 處理 @if 延遲渲染導致的尺寸計算時間差
        // 使用 requestAnimationFrame 確保 DOM 完全渲染（比 setTimeout 更高效能）
        requestAnimationFrame(() => {
            this._pageLinkSizeByContainerWidth =
                this.calculatePageLinkSizeByContainerWidth();
            this.updatePageLinks();
            // 手動觸發變更檢測，確保頁碼顯示
            this._changeDetectorRef.detectChanges();
        });
        /* 監聽 window:resize 事件更新顯示的頁數 */
        fromEvent(window, 'resize')
            .pipe(debounceTime(100), takeUntil(this._destroyed))
            .subscribe(() => {
            if (!this.isMobileWidth(window.innerWidth)) {
                const previousSize = this.pageLinkSize;
                let nextSize;
                this._pageLinkSizeByContainerWidth =
                    this.calculatePageLinkSizeByContainerWidth();
                nextSize = this.pageLinkSize;
                if (previousSize !== nextSize) {
                    this.updatePageLinks();
                }
            }
        });
    }
    ngOnChanges(simpleChange) {
        // 更新總筆數（不用發出變更通知）
        if (simpleChange['totalRecords']) {
            this.updatePageLinks();
            this.updatePaginatorState();
            this.updatePage();
            this.updatePageSizeOptions();
        }
        // 更新當前頁數（"要"發出變更通知）
        if (simpleChange['pageIndex']) {
            this._pageIndex = simpleChange['pageIndex'].currentValue;
            this.updatePageLinks();
            this.updatePaginatorState();
            this.updatePage();
            this._doCheckSubject.next(this.paginatorState);
        }
        // 更新每頁筆數（"要"發出變更通知）
        if (simpleChange['pageSize']) {
            this.updatePageLinks();
            this.updatePaginatorState();
            this._doCheckSubject.next(this.paginatorState);
        }
        // 更新每頁筆數的下拉選單項目（不用發出變更通知）
        if (simpleChange['pageSizeOptions']) {
            this.updatePageSizeOptions();
        }
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    isFirstPage() {
        return this.pageIndex === 0;
    }
    isLastPage() {
        return this.pageIndex === this.getPageCount() - 1;
    }
    changePage(pageIndex) {
        const pageCount = this.getPageCount();
        if (pageIndex >= 0 && pageIndex < pageCount) {
            this._pageIndex = pageIndex;
            const first = this.pageSize * pageIndex;
            const state = {
                pageIndex: this.pageIndex,
                pageCount: pageCount,
                pageSize: this.pageSize,
                first,
                totalRecords: this.totalRecords,
            };
            this.updatePageLinks();
            this._doCheckSubject.next(state);
            this.updatePaginatorState();
        }
    }
    changePageToFirst(event) {
        if (!this.isFirstPage()) {
            this.changePage(0);
        }
        event.preventDefault();
    }
    changePageToPrev(event) {
        this.changePage(this.pageIndex - 1);
        event.preventDefault();
    }
    changePageToNext(event) {
        this.changePage(this.pageIndex + 1);
        event.preventDefault();
    }
    changePageToLast(event) {
        if (!this.isLastPage()) {
            this.changePage(this.getPageCount() - 1);
        }
        event.preventDefault();
    }
    onPageLinkClick(event, pageIndex) {
        this.changePage(pageIndex);
        event.preventDefault();
    }
    onPerPageChange(event) {
        this.updatePageLinks();
        this.updatePaginatorState();
        this.updatePage();
        this.changePage(this.pageIndex);
    }
    onPageBlur(control) {
        if (this.verifyControl(control)) {
            this.onPageKeydown(control);
        }
    }
    onPageKeydown(control) {
        if (this.verifyControl(control)) {
            const currentPage = parseInt(control.value.toString(), 10);
            const pageCount = this.getPageCount();
            if (currentPage > pageCount) {
                this.changePage(pageCount - 1);
                control.setValue(this.getCurrentPage());
            }
            else {
                this.changePage(currentPage - 1);
            }
        }
    }
    empty() {
        return this.getPageCount() === 1 && this.totalRecords === 0;
    }
    verifyControl(control) {
        if (!control.value) {
            control.setValue(this.getCurrentPage());
            return false;
        }
        const currentPage = parseInt(control.value.toString(), 10);
        if (isNaN(currentPage) || currentPage <= 0) {
            control.setValue(this.getCurrentPage());
            return false;
        }
        if (this.getCurrentPage() === currentPage) {
            return false;
        }
        return true;
    }
    getFirst() {
        return this.pageSize * this.pageIndex;
    }
    getPageCount() {
        const pageCount = Math.ceil(this.totalRecords / this.pageSize);
        return this.totalRecords > 0 ? pageCount : 1;
    }
    getCurrentPage() {
        return this.getPageCount() > 0 ? this.pageIndex + 1 : 0;
    }
    calculatePageLinkBoundaries() {
        let numberOfPages = this.getPageCount(), visiblePages = Math.min(this.pageLinkSize, numberOfPages);
        /* 計算頁數的顯示範圍，將頁數保持顯示再中間 */
        let start = Math.max(0, Math.ceil(this.pageIndex - visiblePages / 2)), end = Math.min(numberOfPages - 1, start + visiblePages - 1);
        /* 當接近最後一頁時，重新設定起始頁數 */
        const delta = this.pageLinkSize - (end - start + 1);
        start = Math.max(0, start - delta);
        return [start, end];
    }
    calculatePageLinkSizeByContainerWidth() {
        if (!this._pagesContainer) {
            return this._pageLinkSize;
        }
        const container = this._pagesContainer.nativeElement, ulElement = container.children[0], liCount = ulElement.children.length, liWidth = ulElement.firstChild.clientWidth, gap = (ulElement.clientWidth - liCount * liWidth) / (liCount - 1);
        let pageLinkSize = Math.floor(container.clientWidth / (liWidth + gap)), pageLinkWidth = pageLinkSize * (liWidth + gap);
        /* 容器有多餘的空間多放一個 <li> 時再加一 */
        if (pageLinkWidth + liWidth <= container.clientWidth) {
            pageLinkSize += 1;
        }
        /* 計算上要扣掉前後頁的控制按鈕數量 */
        if (this.showFirstLastButton) {
            pageLinkSize -= 4;
        }
        else {
            pageLinkSize -= 2;
        }
        return pageLinkSize;
    }
    updatePageSizeOptions() {
        if (this.pageSizeOptions) {
            this.pageSizeItems = [];
            for (let option of this.pageSizeOptions) {
                if (typeof option == 'object' && option['showAll']) {
                    this.pageSizeItems.unshift({
                        label: option['showAll'],
                        value: this.totalRecords,
                    });
                }
                else {
                    this.pageSizeItems.push({ label: String(option), value: option });
                }
            }
        }
    }
    updatePageLinks() {
        this.pageLinks = [];
        let boundaries = this.calculatePageLinkBoundaries(), start = boundaries[0], end = boundaries[1];
        for (let index = start; index <= end; index++) {
            this.pageLinks.push(index + 1);
        }
        this._changeDetectorRef.markForCheck();
    }
    updatePage() {
        const first = this.getFirst();
        /* 當頁數不存在，跳至最後一頁 */
        if (this.pageIndex > 0 && this.totalRecords && first >= this.totalRecords) {
            Promise.resolve(null).then(() => this.changePage(this.getPageCount() - 1));
        }
    }
    updatePaginatorState() {
        const pageCount = this.getPageCount();
        const first = this.pageIndex * this.pageSize;
        const last = Math.min(first + this.pageSize, this.totalRecords);
        this.paginatorState = {
            pageIndex: this.pageIndex,
            pageCount,
            pageSize: this.pageSize,
            first,
            last,
            totalRecords: this.totalRecords,
        };
        /* 更新當前頁數輸入框 */
        if (this.pageIndex + 1 !== this.currentPageCtrl.value) {
            this.currentPageCtrl.setValue(this.pageIndex + 1);
        }
        /* 當頁數等於 1 禁用輸入框 */
        if (pageCount <= 1) {
            this.currentPageCtrl.disable();
        }
        else {
            this.currentPageCtrl.enable();
        }
    }
    /* 判斷螢幕尺寸是否小於 768px */
    isMobileWidth(windowWidth) {
        return windowWidth < DEVICE_BREAKPOINT.TABLET_PORTRAIT;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPaginator, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubPaginator, isStandalone: true, selector: "cub-paginator", inputs: { disabled: "disabled", disableRipple: "disableRipple", style: "style", styleClass: "styleClass", alwaysShow: "alwaysShow", pageRangeTemplate: "pageRangeTemplate", jumpToTemplate: "jumpToTemplate", showPageRange: "showPageRange", showFirstLastButton: "showFirstLastButton", pageLinkAutoSize: "pageLinkAutoSize", pageLinkSize: "pageLinkSize", totalRecords: "totalRecords", pageSize: "pageSize", pageSizeOptions: "pageSizeOptions", hidePageSize: "hidePageSize", pageIndex: "pageIndex" }, outputs: { pageChange: "pageChange" }, host: { listeners: { "window:resize": "onResize($event)" } }, viewQueries: [{ propertyName: "_pagesContainer", first: true, predicate: ["pagesContainer"], descendants: true }], exportAs: ["cubPaginator"], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div\n  [class]=\"styleClass\"\n  [ngStyle]=\"style\"\n  [ngClass]=\"'cub-paginator'\"\n  *ngIf=\"alwaysShow ? true : pageLinks && pageLinks.length > 1\"\n>\n  <div class=\"cub-paginator-left-container\" *ngIf=\"!isStreamlined\">\n    <!-- \u55AE\u9801\u7B46\u6578\u4E0B\u62C9\u9078\u55AE -->\n    <ng-container *ngIf=\"!hidePageSize\">\n      <cub-form-field class=\"cub-paginator-select\">\n        <cub-select\n          placeholder=\"\u8ACB\u9078\u64C7\"\n          size=\"small\"\n          [(ngModel)]=\"pageSize\"\n          [showOptionPlaceholder]=\"false\"\n          [disabled]=\"empty()\"\n          (selectionChange)=\"onPerPageChange($event)\"\n          panelClass=\"cub-paginator-select-panel\"\n        >\n          <cub-option\n            *ngFor=\"let option of pageSizeItems\"\n            [value]=\"option.value\"\n            [disabled]=\"option.disabled\"\n          >\n            {{ option.label }}\n          </cub-option>\n        </cub-select>\n      </cub-form-field>\n    </ng-container>\n\n    <!--\u7B46\u6578\u8CC7\u8A0A-->\n    <span class=\"cub-paginator-range\" *ngIf=\"showPageRange\">{{\n      pageRange\n    }}</span>\n  </div>\n\n  <!-- \u8DF3\u9801\u9023\u7D50\u8207\u6309\u9215 -->\n  <div class=\"cub-paginator-pages-container\" #pagesContainer>\n    <ul class=\"cub-paginator-pages\">\n      <li class=\"cub-paginator-link\">\n        <!-- \u7B2C\u4E00\u9801\u6309\u7D10 -->\n        <button\n          *ngIf=\"showFirstLastButton\"\n          type=\"button\"\n          [class.disabled]=\"isFirstPage() || empty()\"\n          [disabled]=\"isFirstPage() || empty()\"\n          (click)=\"changePageToFirst($event)\"\n        >\n          <span class=\"cub-icon-caret-left-to-line-filled\"></span>\n        </button>\n      </li>\n      <li class=\"cub-paginator-link\">\n        <!-- \u4E0A\u4E00\u9801\u6309\u7D10 -->\n        <button\n          type=\"button\"\n          [class.disabled]=\"isFirstPage() || empty()\"\n          [disabled]=\"isFirstPage() || empty()\"\n          (click)=\"changePageToPrev($event)\"\n        >\n          <span class=\"cub-icon-caret-left-filled\"></span>\n        </button>\n      </li>\n      <!-- \u9801\u6578\u8F38\u5165\u6846 -->\n      <ng-container *ngIf=\"isStreamlined; else pageLinkTemplate\">\n        <li class=\"cub-paginator-quick-jumper\">\n          <ng-container *ngTemplateOutlet=\"currentPageTemplate\"></ng-container>\n        </li>\n      </ng-container>\n      <!-- \u9801\u6578\u6309\u9215 -->\n      <ng-template #pageLinkTemplate>\n        <li\n          *ngFor=\"let pageLink of pageLinks\"\n          class=\"cub-paginator-page\"\n          [class.cub-selected]=\"pageLink - 1 === pageIndex\"\n          (keydown.space)=\"onPageLinkClick($event, pageLink - 1)\"\n          (keydown.enter)=\"onPageLinkClick($event, pageLink - 1)\"\n          (click)=\"onPageLinkClick($event, pageLink - 1)\"\n        >\n          <a\n            tabIndex=\"0\"\n            cubRipple\n            cubRippleClass=\"cub-paginator-page-ripple\"\n            [cubRippleDisabled]=\"this.disableRipple || this.disabled\"\n            [cubRippleCentered]=\"true\"\n            >{{ pageLink }}</a\n          >\n          <span\n            class=\"cub-persistent-ripple cub-paginator-page-persistent-ripple\"\n          ></span>\n        </li>\n      </ng-template>\n      <li class=\"cub-paginator-link\">\n        <!-- \u4E0B\u4E00\u9801\u6309\u7D10 -->\n        <button\n          type=\"button\"\n          [class.disabled]=\"isLastPage() || empty()\"\n          [disabled]=\"isLastPage() || empty()\"\n          (click)=\"changePageToNext($event)\"\n        >\n          <span class=\"cub-icon-caret-right-filled\"></span>\n        </button>\n      </li>\n      <li class=\"cub-paginator-link\">\n        <!-- \u6700\u5F8C\u4E00\u9801\u6309\u7D10 -->\n        <button\n          *ngIf=\"showFirstLastButton\"\n          type=\"button\"\n          class=\"cub-paginator-previous-next\"\n          [class.disabled]=\"isLastPage() || empty()\"\n          [disabled]=\"isLastPage() || empty()\"\n          (click)=\"changePageToLast($event)\"\n        >\n          <span class=\"cub-icon-caret-right-to-line-filled\"></span>\n        </button>\n      </li>\n    </ul>\n  </div>\n\n  <!-- \u9801\u6578\u8F38\u5165\u6846 -->\n  <div class=\"cub-paginator-right-container\" *ngIf=\"!isStreamlined\">\n    <div class=\"cub-paginator-quick-jumper\">\n      <ng-container *ngTemplateOutlet=\"currentPageTemplate\"></ng-container>\n    </div>\n  </div>\n</div>\n\n<ng-template #currentPageTemplate>\n  <span class=\"cub-paginator-range\" *ngIf=\"!isStreamlined\">\n    {{ jumpToTemplate }}\n  </span>\n  <cub-form-field class=\"cub-paginator-input\">\n    <input\n      cubInput\n      size=\"small\"\n      [formControl]=\"currentPageCtrl\"\n      (keydown.enter)=\"onPageKeydown(currentPageCtrl)\"\n      (keydown.metaKey)=\"onPageKeydown(currentPageCtrl)\"\n      (blur)=\"onPageBlur(currentPageCtrl)\"\n    />\n  </cub-form-field>\n  <span class=\"cub-paginator-range\">\n    {{ \" / \" + paginatorState.pageCount }}\n  </span>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: CubFormField, selector: "cub-form-field", inputs: ["invalid", "orientation", "size"], exportAs: ["cubFormField"] }, { kind: "component", type: CubSelect, selector: "cub-select", inputs: ["disabled", "disableRipple", "tabIndex", "value", "size", "appearance", "filter", "resetFilterOnHide", "selectAllLabel", "showOptionPlaceholder", "optionPlaceholder", "filterPlaceholder", "emptyFilterMessage", "maxSelectedLabels", "selectedItemsLabel", "selectedAllItemsLabel"], outputs: ["filter"], exportAs: ["cubSelect"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CubOption, selector: "cub-option", exportAs: ["cubOption"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: CubInput, selector: "input[cubInput], textarea[cubInput], select[cubNativeControl],      input[cubNativeControl], textarea[cubNativeControl]", inputs: ["size", "appearance", "rows", "title", "autocomplete", "disabled", "id", "placeholder", "showClear", "style", "class", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], outputs: ["clear"], exportAs: ["cubInput"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPaginator, decorators: [{
            type: Component,
            args: [{ selector: 'cub-paginator', exportAs: 'cubPaginator', inputs: ['disabled', 'disableRipple'], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        NgIf,
                        NgStyle,
                        NgClass,
                        CubFormField,
                        CubSelect,
                        NgFor,
                        CubOption,
                        NgTemplateOutlet,
                        CubRipple,
                        CubInput,
                    ], template: "<div\n  [class]=\"styleClass\"\n  [ngStyle]=\"style\"\n  [ngClass]=\"'cub-paginator'\"\n  *ngIf=\"alwaysShow ? true : pageLinks && pageLinks.length > 1\"\n>\n  <div class=\"cub-paginator-left-container\" *ngIf=\"!isStreamlined\">\n    <!-- \u55AE\u9801\u7B46\u6578\u4E0B\u62C9\u9078\u55AE -->\n    <ng-container *ngIf=\"!hidePageSize\">\n      <cub-form-field class=\"cub-paginator-select\">\n        <cub-select\n          placeholder=\"\u8ACB\u9078\u64C7\"\n          size=\"small\"\n          [(ngModel)]=\"pageSize\"\n          [showOptionPlaceholder]=\"false\"\n          [disabled]=\"empty()\"\n          (selectionChange)=\"onPerPageChange($event)\"\n          panelClass=\"cub-paginator-select-panel\"\n        >\n          <cub-option\n            *ngFor=\"let option of pageSizeItems\"\n            [value]=\"option.value\"\n            [disabled]=\"option.disabled\"\n          >\n            {{ option.label }}\n          </cub-option>\n        </cub-select>\n      </cub-form-field>\n    </ng-container>\n\n    <!--\u7B46\u6578\u8CC7\u8A0A-->\n    <span class=\"cub-paginator-range\" *ngIf=\"showPageRange\">{{\n      pageRange\n    }}</span>\n  </div>\n\n  <!-- \u8DF3\u9801\u9023\u7D50\u8207\u6309\u9215 -->\n  <div class=\"cub-paginator-pages-container\" #pagesContainer>\n    <ul class=\"cub-paginator-pages\">\n      <li class=\"cub-paginator-link\">\n        <!-- \u7B2C\u4E00\u9801\u6309\u7D10 -->\n        <button\n          *ngIf=\"showFirstLastButton\"\n          type=\"button\"\n          [class.disabled]=\"isFirstPage() || empty()\"\n          [disabled]=\"isFirstPage() || empty()\"\n          (click)=\"changePageToFirst($event)\"\n        >\n          <span class=\"cub-icon-caret-left-to-line-filled\"></span>\n        </button>\n      </li>\n      <li class=\"cub-paginator-link\">\n        <!-- \u4E0A\u4E00\u9801\u6309\u7D10 -->\n        <button\n          type=\"button\"\n          [class.disabled]=\"isFirstPage() || empty()\"\n          [disabled]=\"isFirstPage() || empty()\"\n          (click)=\"changePageToPrev($event)\"\n        >\n          <span class=\"cub-icon-caret-left-filled\"></span>\n        </button>\n      </li>\n      <!-- \u9801\u6578\u8F38\u5165\u6846 -->\n      <ng-container *ngIf=\"isStreamlined; else pageLinkTemplate\">\n        <li class=\"cub-paginator-quick-jumper\">\n          <ng-container *ngTemplateOutlet=\"currentPageTemplate\"></ng-container>\n        </li>\n      </ng-container>\n      <!-- \u9801\u6578\u6309\u9215 -->\n      <ng-template #pageLinkTemplate>\n        <li\n          *ngFor=\"let pageLink of pageLinks\"\n          class=\"cub-paginator-page\"\n          [class.cub-selected]=\"pageLink - 1 === pageIndex\"\n          (keydown.space)=\"onPageLinkClick($event, pageLink - 1)\"\n          (keydown.enter)=\"onPageLinkClick($event, pageLink - 1)\"\n          (click)=\"onPageLinkClick($event, pageLink - 1)\"\n        >\n          <a\n            tabIndex=\"0\"\n            cubRipple\n            cubRippleClass=\"cub-paginator-page-ripple\"\n            [cubRippleDisabled]=\"this.disableRipple || this.disabled\"\n            [cubRippleCentered]=\"true\"\n            >{{ pageLink }}</a\n          >\n          <span\n            class=\"cub-persistent-ripple cub-paginator-page-persistent-ripple\"\n          ></span>\n        </li>\n      </ng-template>\n      <li class=\"cub-paginator-link\">\n        <!-- \u4E0B\u4E00\u9801\u6309\u7D10 -->\n        <button\n          type=\"button\"\n          [class.disabled]=\"isLastPage() || empty()\"\n          [disabled]=\"isLastPage() || empty()\"\n          (click)=\"changePageToNext($event)\"\n        >\n          <span class=\"cub-icon-caret-right-filled\"></span>\n        </button>\n      </li>\n      <li class=\"cub-paginator-link\">\n        <!-- \u6700\u5F8C\u4E00\u9801\u6309\u7D10 -->\n        <button\n          *ngIf=\"showFirstLastButton\"\n          type=\"button\"\n          class=\"cub-paginator-previous-next\"\n          [class.disabled]=\"isLastPage() || empty()\"\n          [disabled]=\"isLastPage() || empty()\"\n          (click)=\"changePageToLast($event)\"\n        >\n          <span class=\"cub-icon-caret-right-to-line-filled\"></span>\n        </button>\n      </li>\n    </ul>\n  </div>\n\n  <!-- \u9801\u6578\u8F38\u5165\u6846 -->\n  <div class=\"cub-paginator-right-container\" *ngIf=\"!isStreamlined\">\n    <div class=\"cub-paginator-quick-jumper\">\n      <ng-container *ngTemplateOutlet=\"currentPageTemplate\"></ng-container>\n    </div>\n  </div>\n</div>\n\n<ng-template #currentPageTemplate>\n  <span class=\"cub-paginator-range\" *ngIf=\"!isStreamlined\">\n    {{ jumpToTemplate }}\n  </span>\n  <cub-form-field class=\"cub-paginator-input\">\n    <input\n      cubInput\n      size=\"small\"\n      [formControl]=\"currentPageCtrl\"\n      (keydown.enter)=\"onPageKeydown(currentPageCtrl)\"\n      (keydown.metaKey)=\"onPageKeydown(currentPageCtrl)\"\n      (blur)=\"onPageBlur(currentPageCtrl)\"\n    />\n  </cub-form-field>\n  <span class=\"cub-paginator-range\">\n    {{ \" / \" + paginatorState.pageCount }}\n  </span>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { style: [{
                type: Input
            }], styleClass: [{
                type: Input
            }], alwaysShow: [{
                type: Input
            }], pageRangeTemplate: [{
                type: Input
            }], jumpToTemplate: [{
                type: Input
            }], showPageRange: [{
                type: Input
            }], showFirstLastButton: [{
                type: Input
            }], pageLinkAutoSize: [{
                type: Input
            }], pageLinkSize: [{
                type: Input
            }], totalRecords: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageSizeOptions: [{
                type: Input
            }], hidePageSize: [{
                type: Input
            }], pageIndex: [{
                type: Input
            }], pageChange: [{
                type: Output
            }], _pagesContainer: [{
                type: ViewChild,
                args: ['pagesContainer']
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }] } });

class CubPaginatorModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPaginatorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubPaginatorModule, imports: [CubPaginator], exports: [CubPaginator] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPaginatorModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_SELECT_SCROLL_STRATEGY_PROVIDER,
        ], imports: [CubPaginator] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPaginatorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubPaginator],
                    exports: [CubPaginator],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_SELECT_SCROLL_STRATEGY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/paginator
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubPaginator, CubPaginatorModule };
//# sourceMappingURL=cub-lib-view-rootng-component-paginator.mjs.map
