import * as i0 from '@angular/core';
import { EventEmitter, ContentChildren, ViewChildren, ViewChild, Output, Input, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NgClass, NgStyle, NgIf, NgTemplateOutlet, NgFor } from '@angular/common';
import { transferArrayItem, moveItemInArray, CubCdkDropListGroup, CubCdkDropList, CubCdkDrag } from 'cub-lib-view-rootng/cdk/drag-drop';
import * as i1 from 'cub-lib-view-rootng/component/common';
import { DomHandler, ObjectUtils, CubTemplate, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import { CubFormField } from 'cub-lib-view-rootng/component/form-field';
import { CubInput } from 'cub-lib-view-rootng/component/input';
import { CubIconButton } from 'cub-lib-view-rootng/component/button';
import { CubOption, CUB_OPTION_PARENT } from 'cub-lib-view-rootng/component/option';
import { CubCheckbox } from 'cub-lib-view-rootng/component/checkbox';

class CubPicklist {
    get isSelectSourceAll() {
        let sourceLength = this.source.filter((item) => {
            return !item.disabled && this.isItemVisible(item, this.SOURCE_LIST);
        }).length;
        return sourceLength > 0 && sourceLength === this.selectedItemsSource.length;
    }
    get isSelectTargetAll() {
        let targetLength = this.target.filter((item) => {
            return !item.disabled && this.isItemVisible(item, this.TARGET_LIST);
        }).length;
        return targetLength > 0 && targetLength === this.selectedItemsTarget.length;
    }
    constructor(cd, filterService) {
        this.cd = cd;
        this.filterService = filterService;
        this.selectedItemsSource = [];
        this.selectedItemsTarget = [];
        this.multiple = true;
        this.SOURCE_LIST = -1;
        this.TARGET_LIST = 1;
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 元件全選文字，預設為 '全選'。 */
        this.selectAllLabel = '全選';
        /**
         篩選清單的比對方式，預設為 'contains'。可取下列值之一：
         'contains'：篩選內容包含輸入值。
         'startsWith'：篩選內容以輸入值開頭。
         'endsWith'：篩選內容以輸入值結尾。
         'equals'：篩選內容與輸入值完全一致。
         'notEquals'：篩選內容與輸入值完全不一致。
         'lt'：篩選內容小於輸入值。
         'lte'：篩選內容小於等於輸入值。
         'gt'：篩選內容大於輸入值。
         'gte'：篩選內容大於等於輸入值。
         */
        this.filterMatchMode = 'contains';
        /** 當啟用 filterBy 時，是否顯示來源列表的篩選器，預設為 true。 */
        this.showSourceFilter = true;
        /** 當啟用 filterBy 時，是否顯示目標列表的篩選器，預設為 true。 */
        this.showTargetFilter = true;
        /** 來源列表篩選器的 Placeholder，預設為 '請輸入關鍵字查詢'。 */
        this.sourceFilterPlaceholder = '請輸入關鍵字查詢';
        /** 目標列表篩選器的 Placeholder，預設為 '請輸入關鍵字查詢'。 */
        this.targetFilterPlaceholder = '請輸入關鍵字查詢';
        /** 來源列表無資料時顯示的文字，預設為 '無資料'。 */
        this.emptyMessageSource = '無資料';
        /** 來源列表篩選清單無資料時顯示的文字，預設為 '無資料'。 */
        this.emptyFilterMessageSource = '無資料';
        /** 目標列表無資料時顯示的文字，預設為 '無資料'。 */
        this.emptyMessageTarget = '無資料';
        /** 目標列表篩選清單無資料時顯示的文字，預設為 '無資料'。 */
        this.emptyFilterMessageTarget = '無資料';
        /** 透過 ngForTrackBy 來優化操作 dom 的函數，預設算法檢查物件標識（object identity），如果每個列表需要不同的算法，請使用 sourceTrackBy 或 targetTrackBy，預設為 (index: number, item: any) => item。 */
        this.trackBy = (index, item) => item;
        /** 將選擇狀態保留在傳輸至的列表中，預設為 false。 */
        this.keepSelection = false;
        /** 是否啟用拖放功能，預設為 true。 */
        this.dragdrop = true;
        /** 是否為禁用狀態，預設為 false。 */
        this.disabled = false;
        /** 當項目從目標列表移動到來源列表時發出通知。 */
        this.moveToSource = new EventEmitter();
        /** 當項目從來源列表移動到目標列表時發出通知。 */
        this.moveToTarget = new EventEmitter();
        /** 當項目在來源列表中重新排序時發出通知。 */
        this.sourceReorder = new EventEmitter();
        /** 當項目在目標列表中重新排序時發出通知。 */
        this.targetReorder = new EventEmitter();
        /** 在來源列表中選擇項目時發出通知。 */
        this.sourceSelect = new EventEmitter();
        /** 在目標列表中選擇項目時發出通知。 */
        this.targetSelect = new EventEmitter();
        /** 篩選來源列表時發出通知。 */
        this.sourceFilter = new EventEmitter();
        /** 篩選目標列表時發出通知。 */
        this.targetFilter = new EventEmitter();
    }
    ngOnInit() {
        if (this.filterBy) {
            this.sourceFilterOptions = {
                filter: (value) => this.filterSource(value),
                reset: () => this.resetSourceFilter(),
            };
            this.targetFilterOptions = {
                filter: (value) => this.filterTarget(value),
                reset: () => this.resetTargetFilter(),
            };
        }
    }
    ngAfterContentInit() {
        this.templates.forEach((item) => {
            switch (item.getType()) {
                case 'item':
                    this.itemTemplateRef = item.template;
                    break;
                case 'sourceTitle':
                    this.sourceTitleTemplateRef = item.template;
                    break;
                case 'targetTilte':
                    this.targetTilteTemplateRef = item.template;
                    break;
                case 'sourceFilter':
                    this.sourceFilterTemplateRef = item.template;
                    break;
                case 'targetFilter':
                    this.targetFilterTemplateRef = item.template;
                    break;
                case 'emptyMessageSource':
                    this.emptyMessageSourceTemplateRef = item.template;
                    break;
                case 'emptyFilterMessageSource':
                    this.emptyFilterMessageSourceTemplateRef = item.template;
                    break;
                case 'emptyMessageTarget':
                    this.emptyMessageTargetTemplateRef = item.template;
                    break;
                case 'emptyFilterMessageTarget':
                    this.emptyFilterMessageTargetTemplateRef = item.template;
                    break;
                default:
                    this.itemTemplateRef = item.template;
                    break;
            }
        });
    }
    ngAfterViewChecked() {
        if (this.movedUp || this.movedDown) {
            let listItems = DomHandler.find(this.reorderedListElement, '.cub-option.cub-selected');
            let listItem;
            if (this.movedUp)
                listItem = listItems[0];
            else
                listItem = listItems[listItems.length - 1];
            DomHandler.scrollInView(this.reorderedListElement, listItem);
            this.movedUp = false;
            this.movedDown = false;
            this.reorderedListElement = null;
        }
    }
    selectSourceAll(event) {
        this.sourceOption.toArray().forEach((item) => {
            if (!item.disabled) {
                if (event.checked) {
                    item.select();
                }
                else {
                    item.deselect();
                }
            }
        });
    }
    selectTargetAll(event) {
        this.targetOption.toArray().forEach((item) => {
            if (!item.disabled) {
                if (event.checked) {
                    item.select();
                }
                else {
                    item.deselect();
                }
            }
        });
    }
    isSelectSourcePart() {
        if (this.selectedItemsSource.length === 0) {
            return false;
        }
        else {
            return (this.source.filter((item) => {
                return !item.disabled && this.isItemVisible(item, this.SOURCE_LIST);
            }).length > this.selectedItemsSource.length);
        }
    }
    isSelectTargetPart() {
        if (this.selectedItemsTarget.length === 0) {
            return false;
        }
        else {
            return (this.target.filter((item) => {
                return !item.disabled && this.isItemVisible(item, this.TARGET_LIST);
            }).length > this.selectedItemsTarget.length);
        }
    }
    onSourceSelectionChange(item) {
        let index = this.findIndexInSelection(item, this.selectedItemsSource);
        let selected = index != -1;
        if (selected)
            this.selectedItemsSource.splice(index, 1);
        else
            this.selectedItemsSource.push(item);
        this.sourceSelect.emit({ items: this.selectedItemsSource });
    }
    onTargetSelectionChange(item) {
        let index = this.findIndexInSelection(item, this.selectedItemsTarget);
        let selected = index != -1;
        if (selected)
            this.selectedItemsTarget.splice(index, 1);
        else
            this.selectedItemsTarget.push(item);
        this.targetSelect.emit({ items: this.selectedItemsTarget });
    }
    onFilter(event, listType) {
        let query = event.target.value;
        if (listType === this.SOURCE_LIST)
            this.filterSource(query);
        else if (listType === this.TARGET_LIST)
            this.filterTarget(query);
    }
    onClear(input, listType) {
        let query = input.value;
        if (listType === this.SOURCE_LIST)
            this.filterSource(query);
        else if (listType === this.TARGET_LIST)
            this.filterTarget(query);
    }
    filterSource(value = '') {
        this.filterValueSource = value.trim().toLocaleLowerCase(this.filterLocale);
        this.filter(this.source, this.SOURCE_LIST);
    }
    filterTarget(value = '') {
        this.filterValueTarget = value.trim().toLocaleLowerCase(this.filterLocale);
        this.filter(this.target, this.TARGET_LIST);
    }
    filter(data, listType) {
        let searchFields = this.filterBy.split(',');
        if (listType === this.SOURCE_LIST) {
            this.visibleOptionsSource = this.filterService.filter(data, searchFields, this.filterValueSource, this.filterMatchMode, this.filterLocale);
            this.sourceFilter.emit({
                query: this.filterValueSource,
                value: this.visibleOptionsSource,
            });
        }
        else if (listType === this.TARGET_LIST) {
            this.visibleOptionsTarget = this.filterService.filter(data, searchFields, this.filterValueTarget, this.filterMatchMode, this.filterLocale);
            this.targetFilter.emit({
                query: this.filterValueTarget,
                value: this.visibleOptionsTarget,
            });
        }
        this.sourceOption.toArray().forEach((item) => {
            if (!item.disabled) {
                item.deselect();
            }
        });
    }
    isItemVisible(item, listType) {
        if (listType == this.SOURCE_LIST)
            return this.isVisibleInList(this.visibleOptionsSource, item, this.filterValueSource);
        else
            return this.isVisibleInList(this.visibleOptionsTarget, item, this.filterValueTarget);
    }
    isEmpty(listType) {
        if (listType == this.SOURCE_LIST)
            return this.filterValueSource
                ? !this.visibleOptionsSource || this.visibleOptionsSource.length === 0
                : !this.source || this.source.length === 0;
        else
            return this.filterValueTarget
                ? !this.visibleOptionsTarget || this.visibleOptionsTarget.length === 0
                : !this.target || this.target.length === 0;
    }
    isVisibleInList(data, item, filterValue) {
        if (filterValue && filterValue.trim().length) {
            for (let i = 0; i < data.length; i++) {
                if (item == data[i]) {
                    return true;
                }
            }
        }
        else {
            return true;
        }
        return false;
    }
    moveRight() {
        if (this.selectedItemsSource && this.selectedItemsSource.length) {
            for (let i = 0; i < this.selectedItemsSource.length; i++) {
                let selectedItem = this.selectedItemsSource[i];
                if (ObjectUtils.findIndexInList(selectedItem, this.target) == -1) {
                    this.target.push(this.source.splice(ObjectUtils.findIndexInList(selectedItem, this.source), 1)[0]);
                    if (this.visibleOptionsSource)
                        this.visibleOptionsSource.splice(ObjectUtils.findIndexInList(selectedItem, this.visibleOptionsSource), 1);
                }
            }
            this.moveToTarget.emit({
                items: this.selectedItemsSource,
            });
            if (this.keepSelection) {
                this.selectedItemsTarget = [
                    ...this.selectedItemsTarget,
                    ...this.selectedItemsSource,
                ];
            }
            this.selectedItemsSource = [];
            if (this.filterValueTarget) {
                this.filter(this.target, this.TARGET_LIST);
            }
        }
    }
    moveLeft() {
        if (this.selectedItemsTarget && this.selectedItemsTarget.length) {
            for (let i = 0; i < this.selectedItemsTarget.length; i++) {
                let selectedItem = this.selectedItemsTarget[i];
                if (ObjectUtils.findIndexInList(selectedItem, this.source) == -1) {
                    this.source.push(this.target.splice(ObjectUtils.findIndexInList(selectedItem, this.target), 1)[0]);
                    if (this.visibleOptionsTarget)
                        this.visibleOptionsTarget.splice(ObjectUtils.findIndexInList(selectedItem, this.visibleOptionsTarget), 1)[0];
                }
            }
            this.moveToSource.emit({
                items: this.selectedItemsTarget,
            });
            if (this.keepSelection) {
                this.selectedItemsSource = [
                    ...this.selectedItemsSource,
                    ...this.selectedItemsTarget,
                ];
            }
            this.selectedItemsTarget = [];
            if (this.filterValueSource) {
                this.filter(this.source, this.SOURCE_LIST);
            }
        }
    }
    findIndexInSelection(item, selectedItems) {
        return ObjectUtils.findIndexInList(item, selectedItems);
    }
    onDrop(event, listType) {
        let isTransfer = event.previousContainer !== event.container;
        let dropIndexes = this.getDropIndexes(event.previousIndex, event.currentIndex, listType, isTransfer, event.item.data);
        if (listType === this.SOURCE_LIST) {
            if (isTransfer) {
                transferArrayItem(event.previousContainer.data, event.container.data, dropIndexes.previousIndex, dropIndexes.currentIndex);
                let selectedItemIndex = ObjectUtils.findIndexInList(event.item.data, this.selectedItemsTarget);
                if (selectedItemIndex != -1) {
                    this.selectedItemsTarget.splice(selectedItemIndex, 1);
                    if (this.keepSelection) {
                        this.selectedItemsTarget.push(event.item.data);
                    }
                }
                if (this.visibleOptionsTarget)
                    this.visibleOptionsTarget.splice(event.previousIndex, 1);
                this.moveToSource.emit({ items: [event.item.data] });
            }
            else {
                moveItemInArray(event.container.data, dropIndexes.previousIndex, dropIndexes.currentIndex);
                this.sourceReorder.emit({ items: [event.item.data] });
            }
            if (this.filterValueSource) {
                this.filter(this.source, this.SOURCE_LIST);
            }
        }
        else {
            if (isTransfer) {
                transferArrayItem(event.previousContainer.data, event.container.data, dropIndexes.previousIndex, dropIndexes.currentIndex);
                let selectedItemIndex = ObjectUtils.findIndexInList(event.item.data, this.selectedItemsSource);
                if (selectedItemIndex != -1) {
                    this.selectedItemsSource.splice(selectedItemIndex, 1);
                    if (this.keepSelection) {
                        this.selectedItemsTarget.push(event.item.data);
                    }
                }
                if (this.visibleOptionsSource)
                    this.visibleOptionsSource.splice(event.previousIndex, 1);
                this.moveToTarget.emit({ items: [event.item.data] });
            }
            else {
                moveItemInArray(event.container.data, dropIndexes.previousIndex, dropIndexes.currentIndex);
                this.targetReorder.emit({ items: [event.item.data] });
            }
            if (this.filterValueTarget) {
                this.filter(this.target, this.TARGET_LIST);
            }
        }
    }
    getDropIndexes(fromIndex, toIndex, droppedList, isTransfer, data) {
        let previousIndex, currentIndex;
        if (droppedList === this.SOURCE_LIST) {
            previousIndex = isTransfer
                ? this.filterValueTarget
                    ? ObjectUtils.findIndexInList(data, this.target)
                    : fromIndex
                : this.filterValueSource
                    ? ObjectUtils.findIndexInList(data, this.source)
                    : fromIndex;
            currentIndex = this.filterValueSource
                ? this.findFilteredCurrentIndex(this.visibleOptionsSource, toIndex, this.source)
                : toIndex;
        }
        else {
            previousIndex = isTransfer
                ? this.filterValueSource
                    ? ObjectUtils.findIndexInList(data, this.source)
                    : fromIndex
                : this.filterValueTarget
                    ? ObjectUtils.findIndexInList(data, this.target)
                    : fromIndex;
            currentIndex = this.filterValueTarget
                ? this.findFilteredCurrentIndex(this.visibleOptionsTarget, toIndex, this.target)
                : toIndex;
        }
        return { previousIndex, currentIndex };
    }
    findFilteredCurrentIndex(visibleOptions, index, options) {
        if (visibleOptions.length === index) {
            let toIndex = ObjectUtils.findIndexInList(visibleOptions[index - 1], options);
            return toIndex + 1;
        }
        else {
            return ObjectUtils.findIndexInList(visibleOptions[index], options);
        }
    }
    resetSourceFilter() {
        this.visibleOptionsSource = [];
        this.filterValueSource = '';
        this.sourceFilterViewChild &&
            (this.sourceFilterViewChild.nativeElement.value = '');
    }
    resetTargetFilter() {
        this.visibleOptionsTarget = [];
        this.filterValueTarget = '';
        this.targetFilterViewChild &&
            (this.targetFilterViewChild.nativeElement.value = '');
    }
    resetFilter() {
        this.resetSourceFilter();
        this.resetTargetFilter();
    }
    onSelectionKeydown(event) {
        let listItem = event.currentTarget;
        switch (event.which) {
            // down
            case 40:
                let nextItem = this.findNextItem(listItem);
                if (nextItem) {
                    nextItem.focus();
                }
                event.preventDefault();
                break;
            // up
            case 38:
                let prevItem = this.findPrevItem(listItem);
                if (prevItem) {
                    prevItem.focus();
                }
                event.preventDefault();
                break;
            // enter
            case 13:
                event.preventDefault();
                break;
        }
    }
    findNextItem(item) {
        let nextItem = item.nextElementSibling;
        if (nextItem)
            return !DomHandler.hasClass(nextItem, 'cub-option') ||
                DomHandler.isHidden(nextItem) ||
                DomHandler.hasClass(nextItem, 'cub-disabled')
                ? this.findNextItem(nextItem)
                : nextItem;
        else
            return null;
    }
    findPrevItem(item) {
        let prevItem = item.previousElementSibling;
        if (prevItem)
            return !DomHandler.hasClass(prevItem, 'cub-option') ||
                DomHandler.isHidden(prevItem) ||
                DomHandler.hasClass(prevItem, 'cub-disabled')
                ? this.findPrevItem(prevItem)
                : prevItem;
        else
            return null;
    }
    moveRightDisabled() {
        return this.disabled || ObjectUtils.isEmpty(this.selectedItemsSource);
    }
    moveLeftDisabled() {
        return this.disabled || ObjectUtils.isEmpty(this.selectedItemsTarget);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPicklist, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.CubFilterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubPicklist, isStandalone: true, selector: "cub-picklist", inputs: { size: "size", selectAllLabel: "selectAllLabel", source: "source", target: "target", sourceTitle: "sourceTitle", targetTilte: "targetTilte", rightButtonAriaLabel: "rightButtonAriaLabel", leftButtonAriaLabel: "leftButtonAriaLabel", filterBy: "filterBy", filterLocale: "filterLocale", filterMatchMode: "filterMatchMode", showSourceFilter: "showSourceFilter", showTargetFilter: "showTargetFilter", sourceFilterPlaceholder: "sourceFilterPlaceholder", targetFilterPlaceholder: "targetFilterPlaceholder", ariaSourceFilterLabel: "ariaSourceFilterLabel", ariaTargetFilterLabel: "ariaTargetFilterLabel", emptyMessageSource: "emptyMessageSource", emptyFilterMessageSource: "emptyFilterMessageSource", emptyMessageTarget: "emptyMessageTarget", emptyFilterMessageTarget: "emptyFilterMessageTarget", trackBy: "trackBy", keepSelection: "keepSelection", dragdrop: "dragdrop", style: "style", styleClass: "styleClass", sourceStyle: "sourceStyle", targetStyle: "targetStyle", disabled: "disabled", sourceTrackBy: "sourceTrackBy", targetTrackBy: "targetTrackBy" }, outputs: { moveToSource: "moveToSource", moveToTarget: "moveToTarget", sourceReorder: "sourceReorder", targetReorder: "targetReorder", sourceSelect: "sourceSelect", targetSelect: "targetSelect", sourceFilter: "sourceFilter", targetFilter: "targetFilter" }, providers: [
            {
                provide: CUB_OPTION_PARENT,
                useExisting: CubPicklist,
            },
        ], queries: [{ propertyName: "templates", predicate: CubTemplate }], viewQueries: [{ propertyName: "listViewSourceChild", first: true, predicate: ["sourcelist"], descendants: true }, { propertyName: "listViewTargetChild", first: true, predicate: ["targetlist"], descendants: true }, { propertyName: "sourceFilterViewChild", first: true, predicate: ["sourceFilter"], descendants: true }, { propertyName: "targetFilterViewChild", first: true, predicate: ["targetFilter"], descendants: true }, { propertyName: "sourceOption", predicate: ["sourceOption"], descendants: true }, { propertyName: "targetOption", predicate: ["targetOption"], descendants: true }], ngImport: i0, template: "<div\n  cubCdkDropListGroup\n  [class]=\"styleClass\"\n  [ngClass]=\"{\n    'cub-picklist': true,\n    'cub-picklist-small': size === 'small',\n    'cub-picklist-has-filter':\n      filterBy && (showSourceFilter || showTargetFilter)\n  }\"\n  [ngStyle]=\"style\"\n>\n  <div class=\"cub-picklist-source-scope\">\n    <div class=\"cub-picklist-list-wrapper cub-picklist-source-wrapper\">\n      <div\n        *ngIf=\"sourceTitle || sourceTitleTemplateRef\"\n        class=\"cub-picklist-header\"\n      >\n        <div *ngIf=\"!sourceTitleTemplateRef\" class=\"cub-picklist-title\">\n          {{ sourceTitle }}\n        </div>\n        <ng-container *ngTemplateOutlet=\"sourceTitleTemplateRef\"></ng-container>\n      </div>\n      <div\n        class=\"cub-picklist-operate-area\"\n        [ngClass]=\"{\n          'cub-disabled': disabled\n        }\"\n      >\n        <div class=\"cub-picklist-select-all\">\n          <cub-checkbox\n            #selectSourceAllCheckbox\n            [size]=\"size\"\n            [checked]=\"isSelectSourceAll\"\n            [indeterminate]=\"isSelectSourcePart()\"\n            [disabled]=\"disabled || isEmpty(SOURCE_LIST)\"\n            (change)=\"selectSourceAll($event)\"\n            (keydown.enter)=\"selectSourceAllCheckbox._onInputClick($event)\"\n          >\n            {{ selectAllLabel }}\n          </cub-checkbox>\n        </div>\n        <div\n          *ngIf=\"filterBy && showSourceFilter !== false\"\n          class=\"cub-picklist-filter\"\n        >\n          <ng-container\n            *ngIf=\"sourceFilterTemplateRef; else builtInSourceElement\"\n          >\n            <ng-container\n              *ngTemplateOutlet=\"\n                sourceFilterTemplateRef;\n                context: { options: sourceFilterOptions }\n              \"\n            ></ng-container>\n          </ng-container>\n          <ng-template #builtInSourceElement>\n            <cub-form-field>\n              <input\n                #sourceFilter\n                cubInput\n                type=\"text\"\n                role=\"textbox\"\n                [showClear]=\"true\"\n                [size]=\"size\"\n                [disabled]=\"disabled\"\n                [placeholder]=\"sourceFilterPlaceholder\"\n                [attr.aria-label]=\"ariaSourceFilterLabel\"\n                (keyup)=\"onFilter($event, SOURCE_LIST)\"\n                (clear)=\"onClear(sourceFilter, SOURCE_LIST)\"\n              />\n            </cub-form-field>\n          </ng-template>\n        </div>\n        <div\n          #sourcelist\n          cubCdkDropList\n          class=\"cub-picklist-list cub-picklist-source\"\n          role=\"listbox\"\n          aria-multiselectable=\"multiple\"\n          [ngStyle]=\"sourceStyle\"\n          [cubCdkDropListData]=\"source\"\n          (cubCdkDropListDropped)=\"onDrop($event, SOURCE_LIST)\"\n        >\n          <ng-template\n            ngFor\n            let-item\n            let-index=\"index\"\n            let-last=\"last\"\n            [ngForOf]=\"source\"\n            [ngForTrackBy]=\"sourceTrackBy || trackBy\"\n          >\n            <cub-option\n              *ngIf=\"isItemVisible(item, SOURCE_LIST)\"\n              #sourceOption\n              cubCdkDrag\n              class=\"cub-picklist-item\"\n              [attr.tabindex]=\"disabled || item.disabled === true ? -1 : 0\"\n              [size]=\"size\"\n              [value]=\"item\"\n              [disabled]=\"disabled || item.disabled === true\"\n              [cubCdkDragData]=\"item\"\n              [cubCdkDragDisabled]=\"!dragdrop\"\n              (selectionChange)=\"onSourceSelectionChange(item)\"\n              (keydown)=\"onSelectionKeydown($event)\"\n            >\n              <ng-container\n                *ngTemplateOutlet=\"\n                  itemTemplateRef;\n                  context: { $implicit: item, index: index }\n                \"\n              ></ng-container>\n            </cub-option>\n          </ng-template>\n          <ng-container *ngIf=\"isEmpty(SOURCE_LIST)\">\n            <div\n              *ngIf=\"!filterValueSource\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyMessageSourceTemplateRef;\n                  else emptyMessageSourceElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyMessageSourceTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyMessageSourceElement>\n                {{ emptyMessageSource }}\n              </ng-template>\n            </div>\n            <div\n              *ngIf=\"filterValueSource\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyFilterMessageSourceTemplateRef;\n                  else emptyFilterMessageSourceElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyFilterMessageSourceTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyFilterMessageSourceElement>\n                {{ emptyFilterMessageSource }}\n              </ng-template>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"cub-picklist-buttons cub-picklist-transfer-buttons\">\n    <button\n      cub-icon-button\n      type=\"button\"\n      color=\"neutral-light\"\n      appearance=\"filled-outline\"\n      [size]=\"size\"\n      [attr.aria-label]=\"rightButtonAriaLabel\"\n      [disabled]=\"moveRightDisabled()\"\n      (click)=\"moveRight()\"\n    >\n      <span class=\"cub-icon-chevron-right\"></span>\n    </button>\n    <button\n      cub-icon-button\n      type=\"button\"\n      color=\"neutral-light\"\n      appearance=\"filled-outline\"\n      [size]=\"size\"\n      [attr.aria-label]=\"leftButtonAriaLabel\"\n      [disabled]=\"moveLeftDisabled()\"\n      (click)=\"moveLeft()\"\n    >\n      <span class=\"cub-icon-chevron-left\"></span>\n    </button>\n  </div>\n  <div class=\"cub-picklist-target-scope\">\n    <div class=\"cub-picklist-list-wrapper cub-picklist-target-wrapper\">\n      <div\n        *ngIf=\"targetTilte || targetTilteTemplateRef\"\n        class=\"cub-picklist-header\"\n      >\n        <div *ngIf=\"!targetTilteTemplateRef\" class=\"cub-picklist-title\">\n          {{ targetTilte }}\n        </div>\n        <ng-container *ngTemplateOutlet=\"targetTilteTemplateRef\"></ng-container>\n      </div>\n      <div\n        class=\"cub-picklist-operate-area\"\n        [ngClass]=\"{\n          'cub-disabled': disabled\n        }\"\n      >\n        <div class=\"cub-picklist-select-all\">\n          <cub-checkbox\n            #selectTargetAllCheckbox\n            [size]=\"size\"\n            [checked]=\"isSelectTargetAll\"\n            [indeterminate]=\"isSelectTargetPart()\"\n            [disabled]=\"disabled || isEmpty(TARGET_LIST)\"\n            (change)=\"selectTargetAll($event)\"\n            (keydown.enter)=\"selectTargetAllCheckbox._onInputClick($event)\"\n          >\n            {{ selectAllLabel }}\n          </cub-checkbox>\n        </div>\n        <div\n          *ngIf=\"filterBy && showTargetFilter !== false\"\n          class=\"cub-picklist-filter\"\n        >\n          <ng-container\n            *ngIf=\"targetFilterTemplateRef; else builtInTargetElement\"\n          >\n            <ng-container\n              *ngTemplateOutlet=\"\n                targetFilterTemplateRef;\n                context: { options: targetFilterOptions }\n              \"\n            ></ng-container>\n          </ng-container>\n          <ng-template #builtInTargetElement>\n            <cub-form-field>\n              <input\n                #targetFilter\n                cubInput\n                type=\"text\"\n                role=\"textbox\"\n                [showClear]=\"true\"\n                [size]=\"size\"\n                [disabled]=\"disabled\"\n                [placeholder]=\"targetFilterPlaceholder\"\n                [attr.aria-label]=\"ariaTargetFilterLabel\"\n                (keyup)=\"onFilter($event, TARGET_LIST)\"\n                (clear)=\"onClear(targetFilter, TARGET_LIST)\"\n              />\n            </cub-form-field>\n          </ng-template>\n        </div>\n        <div\n          #targetlist\n          cubCdkDropList\n          class=\"cub-picklist-list cub-picklist-target\"\n          role=\"listbox\"\n          aria-multiselectable=\"multiple\"\n          [ngStyle]=\"targetStyle\"\n          [cubCdkDropListData]=\"target\"\n          (cubCdkDropListDropped)=\"onDrop($event, TARGET_LIST)\"\n        >\n          <ng-template\n            ngFor\n            let-item\n            let-index=\"index\"\n            let-last=\"last\"\n            [ngForOf]=\"target\"\n            [ngForTrackBy]=\"targetTrackBy || trackBy\"\n          >\n            <cub-option\n              *ngIf=\"isItemVisible(item, TARGET_LIST)\"\n              #targetOption\n              cubCdkDrag\n              class=\"cub-picklist-item\"\n              [attr.tabindex]=\"disabled || item.disabled === true ? -1 : 0\"\n              [size]=\"size\"\n              [value]=\"item\"\n              [disabled]=\"disabled || item.disabled === true\"\n              [cubCdkDragData]=\"item\"\n              [cubCdkDragDisabled]=\"!dragdrop\"\n              (selectionChange)=\"onTargetSelectionChange(item)\"\n              (keydown)=\"onSelectionKeydown($event)\"\n            >\n              <ng-container\n                *ngTemplateOutlet=\"\n                  itemTemplateRef;\n                  context: { $implicit: item, index: index }\n                \"\n              ></ng-container>\n            </cub-option>\n          </ng-template>\n          <ng-container *ngIf=\"isEmpty(TARGET_LIST)\">\n            <div\n              *ngIf=\"!filterValueTarget\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyMessageTargetTemplateRef;\n                  else emptyMessageTargetElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyMessageTargetTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyMessageTargetElement>\n                {{ emptyMessageTarget }}\n              </ng-template>\n            </div>\n            <div\n              *ngIf=\"filterValueTarget\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyFilterMessageTargetTemplateRef;\n                  else emptyFilterMessageTargetElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyFilterMessageTargetTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyFilterMessageTargetElement>\n                {{ emptyFilterMessageTarget }}\n              </ng-template>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkDropListGroup, selector: "[cubCdkDropListGroup]", inputs: ["cubCdkDropListGroupDisabled"], exportAs: ["cubCdkDropListGroup"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubCheckbox, selector: "cub-checkbox", inputs: ["disableRipple", "tabIndex", "size"], exportAs: ["cubCheckbox"] }, { kind: "component", type: CubFormField, selector: "cub-form-field", inputs: ["invalid", "orientation", "size"], exportAs: ["cubFormField"] }, { kind: "directive", type: CubInput, selector: "input[cubInput], textarea[cubInput], select[cubNativeControl],      input[cubNativeControl], textarea[cubNativeControl]", inputs: ["size", "appearance", "rows", "title", "autocomplete", "disabled", "id", "placeholder", "showClear", "style", "class", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], outputs: ["clear"], exportAs: ["cubInput"] }, { kind: "directive", type: CubCdkDropList, selector: "[cubCdkDropList], cub-cdk-drop-list", inputs: ["cubCdkDropListConnectedTo", "cubCdkDropListData", "cubCdkDropListOrientation", "id", "cubCdkDropListLockAxis", "cubCdkDropListDisabled", "cubCdkDropListSortingDisabled", "cubCdkDropListEnterPredicate", "cubCdkDropListSortPredicate", "cubCdkDropListAutoScrollDisabled", "cubCdkDropListAutoScrollStep"], outputs: ["cubCdkDropListDropped", "cubCdkDropListEntered", "cubCdkDropListExited", "cubCdkDropListSorted"], exportAs: ["cubCdkDropList"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CubOption, selector: "cub-option", exportAs: ["cubOption"] }, { kind: "directive", type: CubCdkDrag, selector: "[cubCdkDrag]", inputs: ["cubCdkDragData", "cubCdkDragLockAxis", "cubCdkDragRootElement", "cubCdkDragBoundary", "cubCdkDragStartDelay", "cubCdkDragFreeDragPosition", "cubCdkDragDisabled", "cubCdkDragConstrainPosition", "cubCdkDragPreviewClass", "cubCdkDragPreviewContainer"], outputs: ["cubCdkDragStarted", "cubCdkDragReleased", "cubCdkDragEnded", "cubCdkDragEntered", "cubCdkDragExited", "cubCdkDragDropped", "cubCdkDragMoved"], exportAs: ["cubCdkDrag"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPicklist, decorators: [{
            type: Component,
            args: [{ selector: 'cub-picklist', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, providers: [
                        {
                            provide: CUB_OPTION_PARENT,
                            useExisting: CubPicklist,
                        },
                    ], imports: [
                        CubCdkDropListGroup,
                        NgClass,
                        NgStyle,
                        NgIf,
                        NgTemplateOutlet,
                        CubCheckbox,
                        CubFormField,
                        CubInput,
                        CubCdkDropList,
                        NgFor,
                        CubOption,
                        CubCdkDrag,
                        CubIconButton,
                    ], template: "<div\n  cubCdkDropListGroup\n  [class]=\"styleClass\"\n  [ngClass]=\"{\n    'cub-picklist': true,\n    'cub-picklist-small': size === 'small',\n    'cub-picklist-has-filter':\n      filterBy && (showSourceFilter || showTargetFilter)\n  }\"\n  [ngStyle]=\"style\"\n>\n  <div class=\"cub-picklist-source-scope\">\n    <div class=\"cub-picklist-list-wrapper cub-picklist-source-wrapper\">\n      <div\n        *ngIf=\"sourceTitle || sourceTitleTemplateRef\"\n        class=\"cub-picklist-header\"\n      >\n        <div *ngIf=\"!sourceTitleTemplateRef\" class=\"cub-picklist-title\">\n          {{ sourceTitle }}\n        </div>\n        <ng-container *ngTemplateOutlet=\"sourceTitleTemplateRef\"></ng-container>\n      </div>\n      <div\n        class=\"cub-picklist-operate-area\"\n        [ngClass]=\"{\n          'cub-disabled': disabled\n        }\"\n      >\n        <div class=\"cub-picklist-select-all\">\n          <cub-checkbox\n            #selectSourceAllCheckbox\n            [size]=\"size\"\n            [checked]=\"isSelectSourceAll\"\n            [indeterminate]=\"isSelectSourcePart()\"\n            [disabled]=\"disabled || isEmpty(SOURCE_LIST)\"\n            (change)=\"selectSourceAll($event)\"\n            (keydown.enter)=\"selectSourceAllCheckbox._onInputClick($event)\"\n          >\n            {{ selectAllLabel }}\n          </cub-checkbox>\n        </div>\n        <div\n          *ngIf=\"filterBy && showSourceFilter !== false\"\n          class=\"cub-picklist-filter\"\n        >\n          <ng-container\n            *ngIf=\"sourceFilterTemplateRef; else builtInSourceElement\"\n          >\n            <ng-container\n              *ngTemplateOutlet=\"\n                sourceFilterTemplateRef;\n                context: { options: sourceFilterOptions }\n              \"\n            ></ng-container>\n          </ng-container>\n          <ng-template #builtInSourceElement>\n            <cub-form-field>\n              <input\n                #sourceFilter\n                cubInput\n                type=\"text\"\n                role=\"textbox\"\n                [showClear]=\"true\"\n                [size]=\"size\"\n                [disabled]=\"disabled\"\n                [placeholder]=\"sourceFilterPlaceholder\"\n                [attr.aria-label]=\"ariaSourceFilterLabel\"\n                (keyup)=\"onFilter($event, SOURCE_LIST)\"\n                (clear)=\"onClear(sourceFilter, SOURCE_LIST)\"\n              />\n            </cub-form-field>\n          </ng-template>\n        </div>\n        <div\n          #sourcelist\n          cubCdkDropList\n          class=\"cub-picklist-list cub-picklist-source\"\n          role=\"listbox\"\n          aria-multiselectable=\"multiple\"\n          [ngStyle]=\"sourceStyle\"\n          [cubCdkDropListData]=\"source\"\n          (cubCdkDropListDropped)=\"onDrop($event, SOURCE_LIST)\"\n        >\n          <ng-template\n            ngFor\n            let-item\n            let-index=\"index\"\n            let-last=\"last\"\n            [ngForOf]=\"source\"\n            [ngForTrackBy]=\"sourceTrackBy || trackBy\"\n          >\n            <cub-option\n              *ngIf=\"isItemVisible(item, SOURCE_LIST)\"\n              #sourceOption\n              cubCdkDrag\n              class=\"cub-picklist-item\"\n              [attr.tabindex]=\"disabled || item.disabled === true ? -1 : 0\"\n              [size]=\"size\"\n              [value]=\"item\"\n              [disabled]=\"disabled || item.disabled === true\"\n              [cubCdkDragData]=\"item\"\n              [cubCdkDragDisabled]=\"!dragdrop\"\n              (selectionChange)=\"onSourceSelectionChange(item)\"\n              (keydown)=\"onSelectionKeydown($event)\"\n            >\n              <ng-container\n                *ngTemplateOutlet=\"\n                  itemTemplateRef;\n                  context: { $implicit: item, index: index }\n                \"\n              ></ng-container>\n            </cub-option>\n          </ng-template>\n          <ng-container *ngIf=\"isEmpty(SOURCE_LIST)\">\n            <div\n              *ngIf=\"!filterValueSource\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyMessageSourceTemplateRef;\n                  else emptyMessageSourceElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyMessageSourceTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyMessageSourceElement>\n                {{ emptyMessageSource }}\n              </ng-template>\n            </div>\n            <div\n              *ngIf=\"filterValueSource\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyFilterMessageSourceTemplateRef;\n                  else emptyFilterMessageSourceElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyFilterMessageSourceTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyFilterMessageSourceElement>\n                {{ emptyFilterMessageSource }}\n              </ng-template>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"cub-picklist-buttons cub-picklist-transfer-buttons\">\n    <button\n      cub-icon-button\n      type=\"button\"\n      color=\"neutral-light\"\n      appearance=\"filled-outline\"\n      [size]=\"size\"\n      [attr.aria-label]=\"rightButtonAriaLabel\"\n      [disabled]=\"moveRightDisabled()\"\n      (click)=\"moveRight()\"\n    >\n      <span class=\"cub-icon-chevron-right\"></span>\n    </button>\n    <button\n      cub-icon-button\n      type=\"button\"\n      color=\"neutral-light\"\n      appearance=\"filled-outline\"\n      [size]=\"size\"\n      [attr.aria-label]=\"leftButtonAriaLabel\"\n      [disabled]=\"moveLeftDisabled()\"\n      (click)=\"moveLeft()\"\n    >\n      <span class=\"cub-icon-chevron-left\"></span>\n    </button>\n  </div>\n  <div class=\"cub-picklist-target-scope\">\n    <div class=\"cub-picklist-list-wrapper cub-picklist-target-wrapper\">\n      <div\n        *ngIf=\"targetTilte || targetTilteTemplateRef\"\n        class=\"cub-picklist-header\"\n      >\n        <div *ngIf=\"!targetTilteTemplateRef\" class=\"cub-picklist-title\">\n          {{ targetTilte }}\n        </div>\n        <ng-container *ngTemplateOutlet=\"targetTilteTemplateRef\"></ng-container>\n      </div>\n      <div\n        class=\"cub-picklist-operate-area\"\n        [ngClass]=\"{\n          'cub-disabled': disabled\n        }\"\n      >\n        <div class=\"cub-picklist-select-all\">\n          <cub-checkbox\n            #selectTargetAllCheckbox\n            [size]=\"size\"\n            [checked]=\"isSelectTargetAll\"\n            [indeterminate]=\"isSelectTargetPart()\"\n            [disabled]=\"disabled || isEmpty(TARGET_LIST)\"\n            (change)=\"selectTargetAll($event)\"\n            (keydown.enter)=\"selectTargetAllCheckbox._onInputClick($event)\"\n          >\n            {{ selectAllLabel }}\n          </cub-checkbox>\n        </div>\n        <div\n          *ngIf=\"filterBy && showTargetFilter !== false\"\n          class=\"cub-picklist-filter\"\n        >\n          <ng-container\n            *ngIf=\"targetFilterTemplateRef; else builtInTargetElement\"\n          >\n            <ng-container\n              *ngTemplateOutlet=\"\n                targetFilterTemplateRef;\n                context: { options: targetFilterOptions }\n              \"\n            ></ng-container>\n          </ng-container>\n          <ng-template #builtInTargetElement>\n            <cub-form-field>\n              <input\n                #targetFilter\n                cubInput\n                type=\"text\"\n                role=\"textbox\"\n                [showClear]=\"true\"\n                [size]=\"size\"\n                [disabled]=\"disabled\"\n                [placeholder]=\"targetFilterPlaceholder\"\n                [attr.aria-label]=\"ariaTargetFilterLabel\"\n                (keyup)=\"onFilter($event, TARGET_LIST)\"\n                (clear)=\"onClear(targetFilter, TARGET_LIST)\"\n              />\n            </cub-form-field>\n          </ng-template>\n        </div>\n        <div\n          #targetlist\n          cubCdkDropList\n          class=\"cub-picklist-list cub-picklist-target\"\n          role=\"listbox\"\n          aria-multiselectable=\"multiple\"\n          [ngStyle]=\"targetStyle\"\n          [cubCdkDropListData]=\"target\"\n          (cubCdkDropListDropped)=\"onDrop($event, TARGET_LIST)\"\n        >\n          <ng-template\n            ngFor\n            let-item\n            let-index=\"index\"\n            let-last=\"last\"\n            [ngForOf]=\"target\"\n            [ngForTrackBy]=\"targetTrackBy || trackBy\"\n          >\n            <cub-option\n              *ngIf=\"isItemVisible(item, TARGET_LIST)\"\n              #targetOption\n              cubCdkDrag\n              class=\"cub-picklist-item\"\n              [attr.tabindex]=\"disabled || item.disabled === true ? -1 : 0\"\n              [size]=\"size\"\n              [value]=\"item\"\n              [disabled]=\"disabled || item.disabled === true\"\n              [cubCdkDragData]=\"item\"\n              [cubCdkDragDisabled]=\"!dragdrop\"\n              (selectionChange)=\"onTargetSelectionChange(item)\"\n              (keydown)=\"onSelectionKeydown($event)\"\n            >\n              <ng-container\n                *ngTemplateOutlet=\"\n                  itemTemplateRef;\n                  context: { $implicit: item, index: index }\n                \"\n              ></ng-container>\n            </cub-option>\n          </ng-template>\n          <ng-container *ngIf=\"isEmpty(TARGET_LIST)\">\n            <div\n              *ngIf=\"!filterValueTarget\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyMessageTargetTemplateRef;\n                  else emptyMessageTargetElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyMessageTargetTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyMessageTargetElement>\n                {{ emptyMessageTarget }}\n              </ng-template>\n            </div>\n            <div\n              *ngIf=\"filterValueTarget\"\n              class=\"cub-picklist-empty-message\"\n              [ngClass]=\"{\n                'cub-disabled': disabled\n              }\"\n            >\n              <ng-container\n                *ngIf=\"\n                  emptyFilterMessageTargetTemplateRef;\n                  else emptyFilterMessageTargetElement\n                \"\n              >\n                <ng-container\n                  *ngTemplateOutlet=\"emptyFilterMessageTargetTemplateRef\"\n                ></ng-container>\n              </ng-container>\n              <ng-template #emptyFilterMessageTargetElement>\n                {{ emptyFilterMessageTarget }}\n              </ng-template>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.CubFilterService }], propDecorators: { size: [{
                type: Input
            }], selectAllLabel: [{
                type: Input
            }], source: [{
                type: Input
            }], target: [{
                type: Input
            }], sourceTitle: [{
                type: Input
            }], targetTilte: [{
                type: Input
            }], rightButtonAriaLabel: [{
                type: Input
            }], leftButtonAriaLabel: [{
                type: Input
            }], filterBy: [{
                type: Input
            }], filterLocale: [{
                type: Input
            }], filterMatchMode: [{
                type: Input
            }], showSourceFilter: [{
                type: Input
            }], showTargetFilter: [{
                type: Input
            }], sourceFilterPlaceholder: [{
                type: Input
            }], targetFilterPlaceholder: [{
                type: Input
            }], ariaSourceFilterLabel: [{
                type: Input
            }], ariaTargetFilterLabel: [{
                type: Input
            }], emptyMessageSource: [{
                type: Input
            }], emptyFilterMessageSource: [{
                type: Input
            }], emptyMessageTarget: [{
                type: Input
            }], emptyFilterMessageTarget: [{
                type: Input
            }], trackBy: [{
                type: Input
            }], keepSelection: [{
                type: Input
            }], dragdrop: [{
                type: Input
            }], style: [{
                type: Input
            }], styleClass: [{
                type: Input
            }], sourceStyle: [{
                type: Input
            }], targetStyle: [{
                type: Input
            }], disabled: [{
                type: Input
            }], sourceTrackBy: [{
                type: Input
            }], targetTrackBy: [{
                type: Input
            }], moveToSource: [{
                type: Output
            }], moveToTarget: [{
                type: Output
            }], sourceReorder: [{
                type: Output
            }], targetReorder: [{
                type: Output
            }], sourceSelect: [{
                type: Output
            }], targetSelect: [{
                type: Output
            }], sourceFilter: [{
                type: Output
            }], targetFilter: [{
                type: Output
            }], listViewSourceChild: [{
                type: ViewChild,
                args: ['sourcelist']
            }], listViewTargetChild: [{
                type: ViewChild,
                args: ['targetlist']
            }], sourceFilterViewChild: [{
                type: ViewChild,
                args: ['sourceFilter']
            }], targetFilterViewChild: [{
                type: ViewChild,
                args: ['targetFilter']
            }], sourceOption: [{
                type: ViewChildren,
                args: ['sourceOption']
            }], targetOption: [{
                type: ViewChildren,
                args: ['targetOption']
            }], templates: [{
                type: ContentChildren,
                args: [CubTemplate]
            }] } });

class CubPicklistModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPicklistModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubPicklistModule, imports: [CubCommonModule, CubPicklist], exports: [CubCommonModule, CubPicklist] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPicklistModule, imports: [CubCommonModule, CubPicklist, CubCommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPicklistModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubCommonModule, CubPicklist],
                    exports: [CubCommonModule, CubPicklist],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/picklist
 */
/* 該元件由 PrimeNG v14.2.3 參考而來 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubPicklist, CubPicklistModule };
//# sourceMappingURL=cub-lib-view-rootng-component-picklist.mjs.map
