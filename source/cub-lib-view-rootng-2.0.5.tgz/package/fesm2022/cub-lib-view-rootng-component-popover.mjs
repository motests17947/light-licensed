import * as i0 from '@angular/core';
import { InjectionToken, DOCUMENT, Inject, Directive, EventEmitter, TemplateRef, ContentChild, ViewChild, Output, Input, ViewEncapsulation, ChangeDetectionStrategy, Component, Optional, NgModule } from '@angular/core';
import { NgClass, NgStyle } from '@angular/common';
import { Subject, Subscription, of, merge } from 'rxjs';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { ESCAPE, hasModifierKey, ENTER, SPACE } from 'cub-lib-view-rootng/cdk/keycodes';
import * as i3 from 'cub-lib-view-rootng/cdk/a11y';
import { CubCdkTrapFocus, isFakeMousedownFromScreenReader } from 'cub-lib-view-rootng/cdk/a11y';
import { TemplatePortal, DomPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import { trigger, state, transition, style, animate } from '@angular/animations';
import { CubButton } from 'cub-lib-view-rootng/component/button';
import { filter, take, takeUntil } from 'rxjs/operators';
import * as i1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, OverlayConfig, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import * as i2 from 'cub-lib-view-rootng/cdk/bidi';

/**
 * Injection token that can be used to reference instances of `CubPopoverContent`. It serves
 * as alternative token to the actual `CubPopoverContent` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
const CUB_POPOVER_CONTENT = new InjectionToken('CubPopoverContent');
class _CubPopoverContentBase {
    constructor(_templateRef, _componentFactoryResolver, _appRef, _injector, _viewContainerRef, _document, _changeDetectorRef) {
        this._templateRef = _templateRef;
        this._componentFactoryResolver = _componentFactoryResolver;
        this._appRef = _appRef;
        this._injector = _injector;
        this._viewContainerRef = _viewContainerRef;
        this._document = _document;
        this._changeDetectorRef = _changeDetectorRef;
        /** Emits when the popover content has been attached. */
        this._attached = new Subject();
    }
    /**
     * Attaches the content with a particular context.
     * @docs-private
     */
    attach(context = {}) {
        if (!this._portal) {
            this._portal = new TemplatePortal(this._templateRef, this._viewContainerRef);
        }
        this.detach();
        if (!this._outlet) {
            this._outlet = new DomPortalOutlet(this._document.createElement('div'), this._componentFactoryResolver, this._appRef, this._injector);
        }
        const element = this._templateRef.elementRef.nativeElement;
        // Because we support opening the same popover from different triggers (which in turn have their
        // own `OverlayRef` panel), we have to re-insert the host element every time, otherwise we
        // risk it staying attached to a pane that's no longer in the DOM.
        element.parentNode.insertBefore(this._outlet.outletElement, element);
        // When `CubPopoverContent` is used in an `OnPush` component, the insertion of the popover
        // content via `createEmbeddedView` does not cause the content to be seen as "dirty"
        // by Angular. This causes the `@ContentChildren` for popover items within the popover to
        // not be updated by Angular. By explicitly marking for check here, we tell Angular that
        // it needs to check for new popover items and update the `@ContentChild` in `CubPopover`.
        // @breaking-change 9.0.0 Make change detector ref required
        if (this._changeDetectorRef) {
            this._changeDetectorRef.markForCheck();
        }
        this._portal.attach(this._outlet, context);
        this._attached.next();
    }
    /**
     * Detaches the content.
     * @docs-private
     */
    detach() {
        if (this._portal.isAttached) {
            this._portal.detach();
        }
    }
    ngOnDestroy() {
        if (this._outlet) {
            this._outlet.dispose();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubPopoverContentBase, deps: [{ token: i0.TemplateRef }, { token: i0.ComponentFactoryResolver }, { token: i0.ApplicationRef }, { token: i0.Injector }, { token: i0.ViewContainerRef }, { token: DOCUMENT }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubPopoverContentBase, isStandalone: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubPopoverContentBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.ComponentFactoryResolver }, { type: i0.ApplicationRef }, { type: i0.Injector }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.ChangeDetectorRef }] });
/**
 * Popover content that will be rendered lazily once the popover is opened.
 */
class CubPopoverContent extends _CubPopoverContentBase {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverContent, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubPopoverContent, isStandalone: true, selector: "ng-template[cubPopoverContent]", providers: [{ provide: CUB_POPOVER_CONTENT, useExisting: CubPopoverContent }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverContent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[cubPopoverContent]',
                    providers: [{ provide: CUB_POPOVER_CONTENT, useExisting: CubPopoverContent }],
                }]
        }] });

/**
 * Throws an exception for the case when popover trigger doesn't have a valid cub-popover instance
 */
function throwCubPopoverMissingError() {
    throw Error(`cub-popover-trigger: must pass in an cub-popover instance.

    Example:
      <cub-popover #popover="cubPopover"></cub-popover>
      <button [cubPopoverTriggerFor]="popover"></button>`);
}
/**
 * Throws an exception for the case when popover's positionStart value isn't valid.
 * In other words, it doesn't match 'above', 'below', 'before' or 'after'.
 */
function throwCubPopoverInvalidPositionStart() {
    throw Error(`positionStart value must be either 'above', 'below', 'before' or 'after'.
    Example: <cub-popover positionStart="below'" #popover="cubPopover"></cub-popover>`);
}
/**
 * Throws an exception for the case when popover's positionEnd value isn't valid.
 * In other words, it doesn't match 'above', 'below', 'before', 'after' or 'center'.
 */
function throwCubPopoverInvalidPositionEnd() {
    throw Error(`positionEnd value must be either 'above', 'below', 'before', 'after' or 'center'.
    Example: <cub-popover positionEnd="after" #popover="cubPopover"></cub-popover>`);
}
/** @docs-private */
function CUB_POPOVER_DEFAULT_OPTIONS_FACTORY() {
    return {
        backdropClass: 'cub-cdk-overlay-transparent-backdrop',
        overlayPanelClass: 'cub-popover-overlay',
    };
}
/** @docs-private */
function CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS_FACTORY() {
    return {
        backdropClass: 'cub-cdk-overlay-transparent-backdrop',
        overlayPanelClass: 'cub-confirm-popover-overlay',
        closeOnBackdropClick: true,
    };
}

/**
 * Below are all the animations for the cub-popover component.
 * Animation duration and timing values are based on AngularJS Material.
 */
/**
 * This animation controls the popover panel's entry and exit from the page.
 *
 * When the popover panel is added to the DOM, it scales in and fades in its border.
 *
 * When the popover panel is removed from the DOM, it simply fades out after a brief
 * delay to display the ripple.
 */
const transformPopover = trigger('transformPopover', [
    state('void', style({
        opacity: 0,
        transform: 'scale(0.8)',
    })),
    transition('void => enter', animate('120ms cubic-bezier(0, 0, 0.2, 1)', style({
        opacity: 1,
        transform: 'scale(1)',
    }))),
    transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
]);
/** Injection token to be used to override the default options for `cub-popover`. */
const CUB_POPOVER_DEFAULT_OPTIONS = new InjectionToken('cub-popover-default-options', {
    providedIn: 'root',
    factory: CUB_POPOVER_DEFAULT_OPTIONS_FACTORY,
});
/** Injection token to be used to override the default options for `cub-confirm-popover`. */
const CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS = new InjectionToken('cub-confirm-popover-default-options', {
    providedIn: 'root',
    factory: CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS_FACTORY,
});
const CUB_POPOVER_DEFAULT_DELAY_TIME = 100;

let popoverPanelUid$1 = 0;
class CubPopover {
    /**
     * 設定延遲開啟的時間(毫秒)，預設值為 100 毫秒。
     */
    get enterDelay() {
        return this._enterDelay;
    }
    set enterDelay(value) {
        this._enterDelay = value;
    }
    /**
     * 設定延遲關閉的時間(毫秒)，預設值為 100 毫秒。
     */
    get leaveDelay() {
        return this._leaveDelay;
    }
    set leaveDelay(value) {
        this._leaveDelay = value;
    }
    /**
     * 設定開啟得顯示位置, 預設為 'above'。
     */
    get positionStart() {
        return this._positionStart;
    }
    set positionStart(value) {
        if (!['before', 'after', 'above', 'below'].includes(value)) {
            throwCubPopoverInvalidPositionStart();
        }
        this._positionStart = value;
        this.setPositionClasses();
    }
    /**
     * 設定開啟得對齊位置, 預設為 'center'。
     */
    get positionEnd() {
        return this._positionEnd;
    }
    set positionEnd(value) {
        if (!['before', 'after', 'above', 'below', 'center'].includes(value)) {
            throwCubPopoverInvalidPositionEnd();
        }
        this._positionEnd = value;
        this.setPositionClasses();
    }
    /**
     * 開啟位置X軸偏移，正數離定位點越近負數則越遠，預設值為 0。
     */
    get xOffset() {
        return this._panelOffsetX;
    }
    set xOffset(value) {
        this._panelOffsetX = value;
    }
    /**
     * 開啟位置Y軸偏移，正數離定位點越近負數則越遠，預設值為 0。
     */
    get yOffset() {
        return this._panelOffsetY;
    }
    set yOffset(value) {
        this._panelOffsetY = value;
    }
    /**
     * 是否在開啟時自動聚焦於第一個可聚焦元素。
     * */
    get autoFocus() {
        return this._autoFocus;
    }
    set autoFocus(value) {
        this._autoFocus = coerceBooleanProperty(value);
    }
    /** 是否要有背景遮罩預設為 false 。*/
    get hasBackdrop() {
        return this._hasBackdrop;
    }
    set hasBackdrop(value) {
        this._hasBackdrop = coerceBooleanProperty(value);
    }
    /** 是否要顯示箭頭，預設為 false 。*/
    get hasArrow() {
        return this._hasArrow;
    }
    set hasArrow(value) {
        this._hasArrow = coerceBooleanProperty(value);
        this.setCurrentStyles();
    }
    /** popover 開啟的驅動方式，有效值為 'click'、'hover'，預設值為 'click'。 */
    get triggerEvent() {
        return this._triggerEvent;
    }
    set triggerEvent(value) {
        this._triggerEvent = value;
    }
    /** 是否可以點擊彈窗面板來關閉彈窗，預設為 false。 */
    get closeOnPanelClick() {
        return this._closeOnPanelClick;
    }
    set closeOnPanelClick(value) {
        this._closeOnPanelClick = coerceBooleanProperty(value);
    }
    /** 是否可以點擊背景來關閉彈窗，預設為 true。 */
    get closeOnBackdropClick() {
        return this._closeOnBackdropClick;
    }
    set closeOnBackdropClick(value) {
        this._closeOnBackdropClick = coerceBooleanProperty(value);
    }
    constructor(_elementRef, _defaultOptions) {
        this._elementRef = _elementRef;
        this._defaultOptions = _defaultOptions;
        /** Closing disabled on popover */
        this.closeDisabled = false;
        /** Class or list of classes to be added to the overlay panel. */
        this.overlayPanelClass = this._defaultOptions.overlayPanelClass || '';
        this.arrowStyles = {};
        this.arrowWidth = this._defaultOptions.arrowWidth ?? 10;
        this.arrowHeight = this._defaultOptions.arrowHeight ?? 10;
        this.arrowOffsetX = this._defaultOptions.arrowOffsetX ?? 12;
        this.arrowOffsetY = this._defaultOptions.arrowOffsetY ?? 12;
        /** Config object to be passed into the popover's ngClass. */
        this._classList = {};
        /** Current state of the panel animation. */
        this._panelAnimationState = 'void';
        /** Whether the popover is animating. */
        this._isAnimating = false;
        /** Emits whenever an animation on the popover completes. */
        this._animationDone = new Subject();
        this.panelId = `cub-popover-panel-${popoverPanelUid$1++}`;
        this._enterDelay = this._defaultOptions.enterDelay ?? CUB_POPOVER_DEFAULT_DELAY_TIME;
        this._leaveDelay = this._defaultOptions.leaveDelay ?? CUB_POPOVER_DEFAULT_DELAY_TIME;
        this._positionStart = this._defaultOptions.positionStart ?? 'below';
        this._positionEnd = this._defaultOptions.positionEnd ?? 'before';
        this._panelOffsetX = this._defaultOptions.xOffset ?? 0;
        this._panelOffsetY = this._defaultOptions.yOffset ?? 0;
        this._autoFocus = this._defaultOptions.autoFocus ?? true;
        this._hasBackdrop = this._defaultOptions.hasBackdrop;
        this._hasArrow = this._defaultOptions.hasArrow;
        this._triggerEvent = this._defaultOptions.triggerEvent ?? 'click';
        this._closeOnPanelClick = this._defaultOptions.closeOnPanelClick ?? false;
        this._closeOnBackdropClick = this._defaultOptions.closeOnBackdropClick ?? true;
        /**
         * 添加背景遮罩的Class名稱，預設值為 'cub-cdk-overlay-transparent-backdrop'。
         */
        this.backdropClass = this._defaultOptions.backdropClass;
        /**
         * 關閉 popover 時送出關閉的事件。
         */
        this.closed = new EventEmitter();
    }
    ngOnInit() {
        this.setPositionClasses();
    }
    ngOnDestroy() {
        this.closed.complete();
    }
    /** Starts the enter animation. */
    _startAnimation() {
        // @breaking-change 8.0.0 Combine with _resetAnimation.
        this._panelAnimationState = 'enter';
    }
    /** Resets the panel animation to its initial state. */
    _resetAnimation() {
        // @breaking-change 8.0.0 Combine with _startAnimation.
        this._panelAnimationState = 'void';
    }
    /** Callback that is invoked when the panel animation completes. */
    _onAnimationDone(event) {
        this._animationDone.next(event);
        this._isAnimating = false;
    }
    _onAnimationStart(event) {
        this._isAnimating = true;
    }
    /** Handle a keyboard event from the popover, delegating to the appropriate action. */
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        switch (keyCode) {
            case ESCAPE:
                if (!hasModifierKey(event)) {
                    event.preventDefault();
                    this.closed.emit('keydown');
                }
                break;
        }
    }
    /** Close popover on click if `closeOnPanelClick` is true. */
    _handleClick() {
        if (this.closeOnPanelClick) {
            this.closed.emit('click');
        }
    }
    /** Disables close of popover when leaving trigger element and mouse over the popover. */
    _handleMouseOver() {
        if (this.triggerEvent === 'hover') {
            this.closeDisabled = true;
        }
    }
    /** Enables close of popover when mouse leaving popover element. */
    _handleMouseLeave() {
        if (this.triggerEvent === 'hover') {
            setTimeout(() => {
                this.closeDisabled = false;
                this.closed.emit();
            }, this.leaveDelay);
        }
    }
    /** Sets the current styles for the popover to allow for dynamically changing settings. */
    setCurrentStyles(positionStart = this.positionStart, triggerRef, overlayRef) {
        let left;
        let top;
        let arrowOffsetX = this.arrowOffsetX, arrowWidth = this.arrowWidth;
        if (!this._hasArrow) {
            arrowOffsetX = 0;
            arrowWidth = 0;
        }
        if (triggerRef && overlayRef) {
            const overlayRect = overlayRef.overlayElement.getBoundingClientRect();
            const triggerRect = triggerRef.nativeElement.getBoundingClientRect();
            left =
                triggerRect.x + triggerRect.width / 2 - overlayRect.x - arrowWidth / 2;
            if (left >= overlayRect.width - arrowWidth - arrowOffsetX * 2) {
                left = overlayRect.width - arrowWidth / 2 - arrowOffsetX;
            }
            top =
                triggerRect.y + triggerRect.height / 2 - overlayRect.y - arrowWidth / 2;
            if (top >= overlayRect.height - arrowOffsetX * 2) {
                top = overlayRect.height - arrowOffsetX;
            }
            top = Math.max(top, arrowOffsetX);
        }
        if (positionStart === 'above') {
            this.arrowStyles = {
                left: `${left}px`,
                bottom: `0px`,
            };
        }
        if (positionStart === 'below') {
            this.arrowStyles = { left: `${left}px`, top: `$0px` };
        }
        if (positionStart === 'before') {
            this.arrowStyles = {
                right: `0px`,
                top: `${top}px`,
            };
        }
        if (positionStart === 'after') {
            this.arrowStyles = {
                left: `0px`,
                top: `${top}px`,
            };
        }
    }
    /**
     * It's necessary to set position-based classes to ensure the popover panel animation
     * folds out from the correct direction.
     */
    setPositionClasses(positionStart = this._positionStart, positionEnd = this._positionEnd) {
        this._classList['cub-popover-before-above'] =
            positionStart === 'before' && positionEnd === 'above';
        this._classList['cub-popover-before-center'] =
            positionStart === 'before' && positionEnd === 'center';
        this._classList['cub-popover-before-below'] =
            positionStart === 'before' && positionEnd === 'below';
        this._classList['cub-popover-after-above'] =
            positionStart === 'after' && positionEnd === 'above';
        this._classList['cub-popover-after-center'] =
            positionStart === 'after' && positionEnd === 'center';
        this._classList['cub-popover-after-below'] =
            positionStart === 'after' && positionEnd === 'below';
        this._classList['cub-popover-above-before'] =
            positionStart === 'above' && positionEnd === 'before';
        this._classList['cub-popover-above-center'] =
            positionStart === 'above' && positionEnd === 'center';
        this._classList['cub-popover-above-after'] =
            positionStart === 'above' && positionEnd === 'after';
        this._classList['cub-popover-below-before'] =
            positionStart === 'below' && positionEnd === 'before';
        this._classList['cub-popover-below-center'] =
            positionStart === 'below' && positionEnd === 'center';
        this._classList['cub-popover-below-after'] =
            positionStart === 'below' && positionEnd === 'after';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopover, deps: [{ token: i0.ElementRef }, { token: CUB_POPOVER_DEFAULT_OPTIONS }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubPopover, isStandalone: true, selector: "cub-popover", inputs: { backdropClass: "backdropClass", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], enterDelay: "enterDelay", leaveDelay: "leaveDelay", positionStart: "positionStart", positionEnd: "positionEnd", xOffset: "xOffset", yOffset: "yOffset", autoFocus: "autoFocus", hasBackdrop: "hasBackdrop", hasArrow: "hasArrow", triggerEvent: "triggerEvent", closeOnPanelClick: "closeOnPanelClick", closeOnBackdropClick: "closeOnBackdropClick" }, outputs: { closed: "closed" }, queries: [{ propertyName: "lazyContent", first: true, predicate: CUB_POPOVER_CONTENT, descendants: true }], viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true }], exportAs: ["cubPopover"], ngImport: i0, template: "<ng-template>\n  <div\n    class=\"cub-popover-panel\"\n    tabindex=\"-1\"\n    role=\"dialog\"\n    aria-modal=\"true\"\n    [id]=\"panelId\"\n    [ngClass]=\"_classList\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [class.cub-popover-panel-has-arrow]=\"hasArrow\"\n    [cubCdkTrapFocus]=\"true\"\n    [cubCdkTrapFocusAutoCapture]=\"autoFocus\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"_handleClick()\"\n    (mouseover)=\"_handleMouseOver()\"\n    (mouseleave)=\"_handleMouseLeave()\"\n    [@transformPopover]=\"_panelAnimationState\"\n    (@transformPopover.start)=\"_onAnimationStart($event)\"\n    (@transformPopover.done)=\"_onAnimationDone($event)\"\n  >\n    <div class=\"cub-popover-content\">\n      <ng-content></ng-content>\n    </div>\n    @if (hasArrow) {\n    <div class=\"cub-popover-direction-arrow\" [ngStyle]=\"arrowStyles\"></div>\n    }\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: CubCdkTrapFocus, selector: "[cubCdkTrapFocus]", inputs: ["cubCdkTrapFocus", "cubCdkTrapFocusAutoCapture"], exportAs: ["cubCdkTrapFocus"] }], animations: [transformPopover], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopover, decorators: [{
            type: Component,
            args: [{ selector: 'cub-popover', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, animations: [transformPopover], exportAs: 'cubPopover', imports: [NgClass, NgStyle, CubCdkTrapFocus], template: "<ng-template>\n  <div\n    class=\"cub-popover-panel\"\n    tabindex=\"-1\"\n    role=\"dialog\"\n    aria-modal=\"true\"\n    [id]=\"panelId\"\n    [ngClass]=\"_classList\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [class.cub-popover-panel-has-arrow]=\"hasArrow\"\n    [cubCdkTrapFocus]=\"true\"\n    [cubCdkTrapFocusAutoCapture]=\"autoFocus\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"_handleClick()\"\n    (mouseover)=\"_handleMouseOver()\"\n    (mouseleave)=\"_handleMouseLeave()\"\n    [@transformPopover]=\"_panelAnimationState\"\n    (@transformPopover.start)=\"_onAnimationStart($event)\"\n    (@transformPopover.done)=\"_onAnimationDone($event)\"\n  >\n    <div class=\"cub-popover-content\">\n      <ng-content></ng-content>\n    </div>\n    @if (hasArrow) {\n    <div class=\"cub-popover-direction-arrow\" [ngStyle]=\"arrowStyles\"></div>\n    }\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_POPOVER_DEFAULT_OPTIONS]
                }] }], propDecorators: { backdropClass: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], enterDelay: [{
                type: Input
            }], leaveDelay: [{
                type: Input
            }], positionStart: [{
                type: Input
            }], positionEnd: [{
                type: Input
            }], xOffset: [{
                type: Input
            }], yOffset: [{
                type: Input
            }], autoFocus: [{
                type: Input
            }], hasBackdrop: [{
                type: Input
            }], hasArrow: [{
                type: Input
            }], triggerEvent: [{
                type: Input
            }], closeOnPanelClick: [{
                type: Input
            }], closeOnBackdropClick: [{
                type: Input
            }], closed: [{
                type: Output
            }], templateRef: [{
                type: ViewChild,
                args: [TemplateRef]
            }], lazyContent: [{
                type: ContentChild,
                args: [CUB_POPOVER_CONTENT]
            }] } });

var CUB_POPOVER_CLOSE_REASON;
(function (CUB_POPOVER_CLOSE_REASON) {
    CUB_POPOVER_CLOSE_REASON["CLICK"] = "click";
    CUB_POPOVER_CLOSE_REASON["KEYDOWN"] = "keydown";
    CUB_POPOVER_CLOSE_REASON["TAB"] = "tab";
    CUB_POPOVER_CLOSE_REASON["ACTION_CLICK"] = "actionClick";
    CUB_POPOVER_CLOSE_REASON["CANCEL_CLICK"] = "cancelClick";
})(CUB_POPOVER_CLOSE_REASON || (CUB_POPOVER_CLOSE_REASON = {}));

let popoverPanelUid = 0;
class CubConfirmPopover extends CubPopover {
    get triggerEvent() {
        return this._triggerEvent;
    }
    set triggerEvent(value) {
        this._triggerEvent = value;
    }
    get closeOnPanelClick() {
        return this._closeOnPanelClick;
    }
    get closeOnBackdropClick() {
        return this._closeOnBackdropClick;
    }
    /**
     * 用於設定 cub-popover 元素的 class 預設值為 'cub-popover-above-center。'
     */
    set panelClass(classes) {
        if (classes && classes.length) {
            this._classList = classes
                .split(' ')
                .reduce((obj, className) => {
                obj[className] = true;
                return obj;
            }, {});
            this._elementRef.nativeElement.className = '';
            this.setPositionClasses();
        }
    }
    /**
     * 用於設定動作按鈕的顯示文字，預設值為 '確認'。
     */
    get actionButtonText() {
        return this._actionButtonText;
    }
    set actionButtonText(text) {
        this._actionButtonText = text;
    }
    /**
     * 用於設定動作按鈕的顯示樣式，預設值為 'error'。
     */
    get actionButtonColor() {
        return this._actionButtonColor;
    }
    set actionButtonColor(type) {
        this._actionButtonColor = type;
    }
    /**
     * 用於設定取消按鈕的顯示文字，預設值為 '取消'。
     */
    get cancelButtonText() {
        return this._cancelButtonText;
    }
    set cancelButtonText(text) {
        this._cancelButtonText = text;
    }
    constructor(elementRef, defaultOptions) {
        super(elementRef, defaultOptions);
        this.elementRef = elementRef;
        this.defaultOptions = defaultOptions;
        this.cancelButtonStyle = 'neutral-light';
        this._actionButtonText = '確認';
        this._actionButtonColor = 'error';
        this._cancelButtonText = '取消';
        this.panelId = `cub-confirm-popover-panel-${popoverPanelUid++}`;
        this._positionStart = this._defaultOptions.positionStart ?? 'above';
        this._positionEnd = this._defaultOptions.positionEnd ?? 'center';
        this._closeOnBackdropClick = this._defaultOptions.closeOnBackdropClick ?? false;
        this._closeOnPanelClick = this._defaultOptions.closeOnPanelClick ?? false;
    }
    onActionClick(event) {
        event?.stopPropagation();
        this.closed.emit(CUB_POPOVER_CLOSE_REASON.ACTION_CLICK);
    }
    onCancelClick(event) {
        event?.stopPropagation();
        this.closed.emit(CUB_POPOVER_CLOSE_REASON.CANCEL_CLICK);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubConfirmPopover, deps: [{ token: i0.ElementRef }, { token: CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubConfirmPopover, isStandalone: true, selector: "cub-confirm-popover", inputs: { panelClass: ["class", "panelClass"], actionButtonText: "actionButtonText", actionButtonColor: "actionButtonColor", cancelButtonText: "cancelButtonText" }, viewQueries: [{ propertyName: "panelElement", first: true, predicate: ["panel"], descendants: true }], exportAs: ["cubConfirmPopover"], usesInheritance: true, ngImport: i0, template: "<ng-template>\n  <div\n    class=\"cub-popover-panel\"\n    [id]=\"panelId\"\n    [ngClass]=\"_classList\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"_handleClick()\"\n    (mouseover)=\"_handleMouseOver()\"\n    (mouseleave)=\"_handleMouseLeave()\"\n    [@transformPopover]=\"_panelAnimationState\"\n    (@transformPopover.start)=\"_onAnimationStart($event)\"\n    (@transformPopover.done)=\"_onAnimationDone($event)\"\n    tabindex=\"-1\"\n    role=\"dialog\"\n    aria-modal=\"true\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [class.cub-popover-panel-has-arrow]=\"hasArrow\"\n    [cubCdkTrapFocus]=\"true\"\n    [cubCdkTrapFocusAutoCapture]=\"autoFocus\"\n  >\n    <div class=\"cub-popover-content\">\n      <ng-content></ng-content>\n\n      <div class=\"cub-popover-footer\">\n        <button class=\"cub-confirm-popover-fake-focus\"></button>\n        <button\n          (click)=\"onCancelClick($event)\"\n          cub-button\n          type=\"button\"\n          [color]=\"cancelButtonStyle\"\n          appearance=\"text\"\n        >\n          {{ cancelButtonText }}\n        </button>\n        <button\n          (click)=\"onActionClick($event)\"\n          cub-button\n          type=\"button\"\n          [color]=\"actionButtonColor\"\n          appearance=\"text\"\n        >\n          {{ actionButtonText }}\n        </button>\n      </div>\n    </div>\n    @if (hasArrow) {\n    <div class=\"cub-popover-direction-arrow\" [ngStyle]=\"arrowStyles\"></div>\n    }\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: CubCdkTrapFocus, selector: "[cubCdkTrapFocus]", inputs: ["cubCdkTrapFocus", "cubCdkTrapFocusAutoCapture"], exportAs: ["cubCdkTrapFocus"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], animations: [transformPopover], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubConfirmPopover, decorators: [{
            type: Component,
            args: [{ selector: 'cub-confirm-popover', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, animations: [transformPopover], exportAs: 'cubConfirmPopover', imports: [NgClass, CubCdkTrapFocus, CubButton, NgStyle], template: "<ng-template>\n  <div\n    class=\"cub-popover-panel\"\n    [id]=\"panelId\"\n    [ngClass]=\"_classList\"\n    (keydown)=\"_handleKeydown($event)\"\n    (click)=\"_handleClick()\"\n    (mouseover)=\"_handleMouseOver()\"\n    (mouseleave)=\"_handleMouseLeave()\"\n    [@transformPopover]=\"_panelAnimationState\"\n    (@transformPopover.start)=\"_onAnimationStart($event)\"\n    (@transformPopover.done)=\"_onAnimationDone($event)\"\n    tabindex=\"-1\"\n    role=\"dialog\"\n    aria-modal=\"true\"\n    [attr.aria-label]=\"ariaLabel || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby || null\"\n    [attr.aria-describedby]=\"ariaDescribedby || null\"\n    [class.cub-popover-panel-has-arrow]=\"hasArrow\"\n    [cubCdkTrapFocus]=\"true\"\n    [cubCdkTrapFocusAutoCapture]=\"autoFocus\"\n  >\n    <div class=\"cub-popover-content\">\n      <ng-content></ng-content>\n\n      <div class=\"cub-popover-footer\">\n        <button class=\"cub-confirm-popover-fake-focus\"></button>\n        <button\n          (click)=\"onCancelClick($event)\"\n          cub-button\n          type=\"button\"\n          [color]=\"cancelButtonStyle\"\n          appearance=\"text\"\n        >\n          {{ cancelButtonText }}\n        </button>\n        <button\n          (click)=\"onActionClick($event)\"\n          cub-button\n          type=\"button\"\n          [color]=\"actionButtonColor\"\n          appearance=\"text\"\n        >\n          {{ actionButtonText }}\n        </button>\n      </div>\n    </div>\n    @if (hasArrow) {\n    <div class=\"cub-popover-direction-arrow\" [ngStyle]=\"arrowStyles\"></div>\n    }\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS]
                }] }], propDecorators: { panelClass: [{
                type: Input,
                args: ['class']
            }], actionButtonText: [{
                type: Input
            }], actionButtonColor: [{
                type: Input
            }], cancelButtonText: [{
                type: Input
            }], panelElement: [{
                type: ViewChild,
                args: ['panel']
            }] } });

/** Injection token that determines the scroll handling while the popover is open. */
const CUB_POPOVER_SCROLL_STRATEGY = new InjectionToken('cub-popover-scroll-strategy');
/** @docs-private */
function CUB_POPOVER_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition();
}
/** @docs-private */
const CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER = {
    provide: CUB_POPOVER_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_POPOVER_SCROLL_STRATEGY_FACTORY,
};
/**
 * This directive is intended to be used in conjunction with an `cub-popover` tag. It is
 * responsible for toggling the display of the provided popover instance.
 */
class CubPopoverTrigger {
    /** Whether the popover is open. */
    get popoverOpen() {
        return this._popoverOpen;
    }
    /** The text direction of the containing app. */
    get dir() {
        return this._dir && this._dir.value === 'rtl' ? 'rtl' : 'ltr';
    }
    /**
     * 綁定要顯示的 <cub-popover> 元件 預設為 undefined。
     */
    get popover() {
        return this._popover;
    }
    set popover(popover) {
        if (popover === this._popover) {
            return;
        }
        this._popover = popover;
        this._popoverCloseSubscription.unsubscribe();
        if (popover) {
            this._popoverCloseSubscription = popover.closed.subscribe((reason) => {
                this._destroyPopover(reason);
            });
        }
    }
    /**
     * 是否禁用 popover，預設為 false。
     */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    constructor(_overlay, _elementRef, _viewContainerRef, scrollStrategy, _dir, _changeDetectorRef, _focusMonitor) {
        this._overlay = _overlay;
        this._elementRef = _elementRef;
        this._viewContainerRef = _viewContainerRef;
        this._dir = _dir;
        this._changeDetectorRef = _changeDetectorRef;
        this._focusMonitor = _focusMonitor;
        /**
         * 綁定要啟用 popover 的事件，預設為 'click'。
         */
        this.triggerEvent = 'click';
        // Tracking input type is necessary so it's possible to only auto-focus
        // the first item of the list when the popover is opened via the keyboard
        this._openedBy = undefined;
        this._overlayRef = null;
        this._popoverOpen = false;
        this._halt = false;
        this._positionSubscription = Subscription.EMPTY;
        this._popoverCloseSubscription = Subscription.EMPTY;
        this._closingActionsSubscription = Subscription.EMPTY;
        this._disabled = false;
        /**
         * 設定 popover 箭頭樣式，預設值為 true
         */
        this.hasArrow = true;
        /**
         * 開啟 popover 時會回傳的事件。
         */
        this.opened = new EventEmitter();
        /**
         * 關閉 popover 時會回傳的事件。
         */
        this.closed = new EventEmitter();
        this._scrollStrategy = scrollStrategy;
    }
    ngAfterContentInit() {
        this._checkPopover();
        this._setCurrentConfig();
    }
    ngOnDestroy() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef = null;
        }
        this._positionSubscription.unsubscribe();
        this._popoverCloseSubscription.unsubscribe();
        this._closingActionsSubscription.unsubscribe();
    }
    /** Handles mouse click on the trigger. */
    _handleClick(event) {
        if (this.popover.triggerEvent === 'click') {
            this.togglePopover();
        }
    }
    /** Handles mouse enter on the trigger. */
    _handleMouseEnter(event) {
        this._halt = false;
        if (this.popover.triggerEvent === 'hover') {
            this._mouseoverTimer = setTimeout(() => {
                this.openPopover();
            }, this.popover.enterDelay);
        }
    }
    /** Handles mouse leave on the trigger. */
    _handleMouseLeave(event) {
        if (this.popover.triggerEvent === 'hover') {
            if (this._mouseoverTimer) {
                clearTimeout(this._mouseoverTimer);
                this._mouseoverTimer = null;
            }
            if (this._popoverOpen) {
                setTimeout(() => {
                    if (!this.popover.closeDisabled) {
                        this.closePopover();
                    }
                }, this.popover.leaveDelay);
            }
            else {
                this._halt = true;
            }
        }
    }
    /** Handles mouse presses on the trigger. */
    _handleMousedown(event) {
        if (!isFakeMousedownFromScreenReader(event)) {
            // Since right or middle button clicks won't trigger the `click` event,
            // we shouldn't consider the popover as opened by mouse in those cases.
            this._openedBy = event.button === 0 ? 'mouse' : undefined;
        }
    }
    /** Handles key presses on the trigger. */
    _handleKeydown(event) {
        const keyCode = event.keyCode;
        // Pressing enter on the trigger will trigger the click handler later.
        if (keyCode === ENTER || keyCode === SPACE) {
            this._openedBy = 'keyboard';
        }
    }
    /** Toggles the popover between the open and closed states. */
    togglePopover() {
        return this._popoverOpen ? this.closePopover() : this.openPopover();
    }
    /** Opens the popover. */
    openPopover() {
        if (this._disabled || this._popoverOpen || this._halt) {
            return;
        }
        this._checkPopover();
        const overlayRef = this._createOverlay();
        const overlayConfig = overlayRef.getConfig();
        this._setPosition(overlayConfig.positionStrategy);
        if (this.popover.triggerEvent === 'click') {
            overlayConfig.hasBackdrop = this.popover.hasBackdrop ?? true;
        }
        overlayRef.attach(this._getPortal());
        if (this.popover.lazyContent) {
            this.popover.lazyContent.attach(this.data);
        }
        this._closingActionsSubscription = this._popoverClosingActions().subscribe(() => this.closePopover());
        this._initPopover();
        if (this.popover instanceof CubPopover) {
            this.popover._startAnimation();
        }
    }
    /** Closes the popover. */
    closePopover() {
        this.popover.closed.emit();
    }
    /**
     * Focuses the popover trigger.
     * @param origin Source of the popover trigger's focus.
     */
    focus(origin, options) {
        if (this._focusMonitor && origin) {
            this._focusMonitor.focusVia(this._elementRef, origin, options);
        }
        else {
            this._elementRef.nativeElement.focus(options);
        }
    }
    _setCurrentConfig() {
        if (!this.triggerEvent) {
            this.triggerEvent = this.popover.triggerEvent;
        }
        this.popover.setCurrentStyles();
    }
    /** Removes the popover from the DOM. */
    _destroyPopover(reason) {
        if (!this._overlayRef || !this.popoverOpen) {
            return;
        }
        // Clear the timeout for hover event.
        if (this._mouseoverTimer) {
            clearTimeout(this._mouseoverTimer);
            this._mouseoverTimer = null;
        }
        const popover = this.popover;
        this._closingActionsSubscription.unsubscribe();
        this._overlayRef.detach();
        this._openedBy = undefined;
        if (popover instanceof CubPopover) {
            popover._resetAnimation();
            if (popover.lazyContent) {
                // Wait for the exit animation to finish before detaching the content.
                popover._animationDone
                    .pipe(filter((event) => event.toState === 'void'), take(1), 
                // Interrupt if the content got re-attached.
                takeUntil(popover.lazyContent._attached))
                    .subscribe({
                    next: () => popover.lazyContent.detach(),
                    // No matter whether the content got re-attached, reset the popover.
                    complete: () => this._setIsPopoverOpen(false),
                });
            }
            else {
                this._setIsPopoverOpen(false, reason);
            }
        }
        else {
            this._setIsPopoverOpen(false);
            if (popover.lazyContent) {
                popover.lazyContent.detach();
            }
        }
    }
    /**
     * This method sets the popover state to open.
     */
    _initPopover() {
        this.popover.direction = this.dir;
        this.popover.hasArrow = this.hasArrow;
        this._setIsPopoverOpen(true);
    }
    // set state rather than toggle to support triggers sharing a popover
    _setIsPopoverOpen(isOpen, result) {
        this._popoverOpen = isOpen;
        if (this._popoverOpen) {
            this.opened.emit();
        }
        else {
            coerceBooleanProperty(result)
                ? this.closed.emit(result)
                : this.closed.emit();
        }
    }
    /**
     * This method checks that a valid instance of MdPopover has been passed into
     * `cubPopoverTriggerFor`. If not, an exception is thrown.
     */
    _checkPopover() {
        if (!this.popover) {
            throwCubPopoverMissingError();
        }
    }
    /**
     * This method creates the overlay from the provided popover's template and saves its
     * OverlayRef so that it can be attached to the DOM when openPopover is called.
     */
    _createOverlay() {
        if (!this._overlayRef) {
            const config = this._getOverlayConfig();
            this._subscribeToPositions(config.positionStrategy);
            this._overlayRef = this._overlay.create(config);
        }
        else {
            const overlayConfig = this._overlayRef.getConfig();
            const positionStrategy = overlayConfig.positionStrategy;
            positionStrategy.setOrigin(this._getTargetElement());
        }
        return this._overlayRef;
    }
    /**
     * This method builds the configuration object needed to create the overlay, the OverlayConfig.
     * @returns OverlayConfig
     */
    _getOverlayConfig() {
        return new OverlayConfig({
            positionStrategy: this._overlay
                .position()
                .flexibleConnectedTo(this._getTargetElement())
                .withLockedPosition()
                .withGrowAfterOpen()
                .withTransformOriginOn('.cub-popover-panel'),
            backdropClass: this.popover.backdropClass || 'cub-cdk-overlay-transparent-backdrop',
            panelClass: this.popover.overlayPanelClass,
            scrollStrategy: this._scrollStrategy(),
            direction: this._dir,
        });
    }
    _getTargetElement() {
        if (this.connectedTo) {
            return this.connectedTo.elementRef;
        }
        return this._elementRef;
    }
    /**
     * Listens to changes in the position of the overlay and sets the correct classes
     * on the popover based on the new position. This ensures the animation origin is always
     * correct, even if a fallback position is used for the overlay.
     */
    _subscribeToPositions(position) {
        this._positionSubscription = position.positionChanges.subscribe((change) => {
            const positionStart = change.connectionPair.overlayX === 'start'
                ? 'after'
                : change.connectionPair.overlayX === 'end'
                    ? 'before'
                    : 'center';
            const positionEnd = change.connectionPair.overlayY === 'top'
                ? 'below'
                : change.connectionPair.overlayY === 'bottom'
                    ? 'above'
                    : 'center';
            const position = this.popover.positionStart === 'above' ||
                this.popover.positionStart === 'below'
                ? [
                    positionEnd,
                    positionStart,
                ]
                : [
                    positionStart,
                    positionEnd,
                ];
            // required for ChangeDetectionStrategy.OnPush
            this._changeDetectorRef.markForCheck();
            this.popover.setCurrentStyles(position[0], this._elementRef, this._overlayRef);
            this.popover.setPositionClasses(...position);
        });
    }
    /**
     * Sets the appropriate positions on a position strategy
     * so the overlay connects with the trigger correctly.
     * @param positionStrategy Strategy whose position to update.
     */
    _setPosition(positionStrategy) {
        /* 根據 positionStart 設定位置 originX 和 originFallbackX。
         originx 為 原點元素 上的水平連接點 fallback 為備用位置
        'start' 通常指左邊緣（或在 RTL 模式下指右邊緣）。
        'center' 指水平中點。
        'end' 通常指右邊緣（或在 RTL 模式下指左邊緣）。
        originY: 指定 原點元素 上的垂直連接點。
        'top' 指最上邊緣。
        'center' 指垂直中點。
        'bottom' 指最下邊緣。
        overlayX: 指定 彈出層 自身的水平連接點。
        參數與 originX 相同，但應用於彈出層。
        overlayY: 指定 彈出層 自身的垂直連接點。
        參數與 originY 相同，但應用於彈出層。
        */
        const [originX, origin2ndX, origin3rdX] = this.popover.positionStart === 'before' ||
            this.popover.positionEnd === 'before'
            ? ['start', 'center', 'end']
            : this.popover.positionStart === 'after' ||
                this.popover.positionEnd === 'after'
                ? ['end', 'center', 'start']
                : ['center', 'start', 'end'];
        const [originY, origin2ndY, origin3rdY] = this.popover.positionStart === 'above' ||
            this.popover.positionEnd === 'above'
            ? ['top', 'center', 'bottom']
            : this.popover.positionStart === 'below' ||
                this.popover.positionEnd === 'below'
                ? ['bottom', 'center', 'top']
                : ['center', 'top', 'bottom'];
        const [overlayX, overlayFallbackX] = this.popover.positionStart === 'below' ||
            this.popover.positionStart === 'above'
            ? [originX, originX]
            : this.popover.positionStart === 'before'
                ? ['end', 'start']
                : ['start', 'end'];
        const [overlayY, overlayFallbackY] = this.popover.positionStart === 'before' ||
            this.popover.positionStart === 'after'
            ? [originY, originY]
            : this.popover.positionStart === 'below'
                ? ['top', 'bottom']
                : ['bottom', 'top'];
        const originFallbackX = overlayX;
        const originFallbackY = overlayY;
        const offsetX = this.popover.xOffset && !isNaN(Number(this.popover.xOffset))
            ? Number(this.dir === 'ltr' ? this.popover.xOffset : -this.popover.xOffset)
            : 0;
        const offsetY = this.popover.yOffset && !isNaN(Number(this.popover.yOffset))
            ? Number(this.popover.yOffset)
            : 0;
        let positions = [
            { originX, originY, overlayX, overlayY },
        ];
        if (this.popover.positionStart === 'above' ||
            this.popover.positionStart === 'below') {
            positions = [
                { originX, originY, overlayX, overlayY, offsetY },
                {
                    originX: origin2ndX,
                    originY,
                    overlayX: origin2ndX,
                    overlayY,
                    offsetY,
                },
                {
                    originX: origin3rdX,
                    originY,
                    overlayX: origin3rdX,
                    overlayY,
                    offsetY,
                },
                {
                    originX,
                    originY: originFallbackY,
                    overlayX,
                    overlayY: overlayFallbackY,
                    offsetY: -offsetY,
                },
                {
                    originX: origin2ndX,
                    originY: originFallbackY,
                    overlayX: origin2ndX,
                    overlayY: overlayFallbackY,
                    offsetY: -offsetY,
                },
                {
                    originX: origin3rdX,
                    originY: originFallbackY,
                    overlayX: origin3rdX,
                    overlayY: overlayFallbackY,
                    offsetY: -offsetY,
                },
            ];
        }
        if (this.popover.positionStart === 'before' ||
            this.popover.positionStart === 'after') {
            positions = [
                { originX, originY, overlayX, overlayY, offsetX },
                {
                    originX,
                    originY: origin2ndY,
                    overlayX,
                    overlayY: origin2ndY,
                    offsetX,
                },
                {
                    originX,
                    originY: origin3rdY,
                    overlayX,
                    overlayY: origin3rdY,
                    offsetX,
                },
                {
                    originX: originFallbackX,
                    originY,
                    overlayX: overlayFallbackX,
                    overlayY,
                    offsetX: -offsetX,
                },
                {
                    originX: originFallbackX,
                    originY: origin2ndY,
                    overlayX: overlayFallbackX,
                    overlayY: origin2ndY,
                    offsetX: -offsetX,
                },
                {
                    originX: originFallbackX,
                    originY: origin3rdY,
                    overlayX: overlayFallbackX,
                    overlayY: origin3rdY,
                    offsetX: -offsetX,
                },
            ];
        }
        positionStrategy
            .withPositions(positions)
            .withDefaultOffsetX(offsetX)
            .withDefaultOffsetY(offsetY);
    }
    /** Returns a stream that emits whenever an action that should close the popover occurs. */
    _popoverClosingActions() {
        const backdrop = this.popover.triggerEvent === 'click' &&
            this.popover.closeOnBackdropClick === true
            ? this._overlayRef.backdropClick()
            : of();
        // const backdrop = observableOf();
        const detachments = this._overlayRef.detachments();
        return merge(backdrop, detachments);
    }
    /** Gets the portal that should be attached to the overlay. */
    _getPortal() {
        // Note that we can avoid this check by keeping the portal on the popover panel.
        // While it would be cleaner, we'd have to introduce another required method on
        // `CubPopoverPanel`, making it harder to consume.
        if (!this._portal ||
            this._portal.templateRef !== this.popover.templateRef) {
            this._portal = new TemplatePortal(this.popover.templateRef, this._viewContainerRef);
        }
        return this._portal;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverTrigger, deps: [{ token: i1.Overlay }, { token: i0.ElementRef }, { token: i0.ViewContainerRef }, { token: CUB_POPOVER_SCROLL_STRATEGY }, { token: i2.Directionality, optional: true }, { token: i0.ChangeDetectorRef }, { token: i3.FocusMonitor }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubPopoverTrigger, isStandalone: true, selector: "[cub-popover-trigger-for], [cubPopoverTriggerFor]", inputs: { popover: ["cubPopoverTriggerFor", "popover"], disabled: ["cubPopoverDisabled", "disabled"], data: ["cubPopoverData", "data"], connectedTo: ["cubPopoverConnectedTo", "connectedTo"], hasArrow: ["cubPopoverHasArrow", "hasArrow"] }, outputs: { opened: "cubPopoverOpened", closed: "cubPopoverClosed" }, host: { attributes: { "aria-haspopup": "true" }, listeners: { "click": "_handleClick($event)", "mouseenter": "_handleMouseEnter($event)", "mouseleave": "_handleMouseLeave($event)", "mousedown": "_handleMousedown($event)", "keydown": "_handleKeydown($event)" }, properties: { "attr.aria-expanded": "popoverOpen || null", "attr.aria-controls": "popoverOpen ? popover.panelId : null" } }, exportAs: ["cubPopoverTrigger"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cub-popover-trigger-for], [cubPopoverTriggerFor]',
                    exportAs: 'cubPopoverTrigger',
                    host: {
                        'aria-haspopup': 'true',
                        '[attr.aria-expanded]': 'popoverOpen || null',
                        '[attr.aria-controls]': 'popoverOpen ? popover.panelId : null',
                        '(click)': '_handleClick($event)',
                        '(mouseenter)': '_handleMouseEnter($event)',
                        '(mouseleave)': '_handleMouseLeave($event)',
                        '(mousedown)': '_handleMousedown($event)',
                        '(keydown)': '_handleKeydown($event)',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.ElementRef }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_POPOVER_SCROLL_STRATEGY]
                }] }, { type: i2.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }, { type: i3.FocusMonitor }], propDecorators: { popover: [{
                type: Input,
                args: ['cubPopoverTriggerFor']
            }], disabled: [{
                type: Input,
                args: ['cubPopoverDisabled']
            }], data: [{
                type: Input,
                args: ['cubPopoverData']
            }], connectedTo: [{
                type: Input,
                args: ['cubPopoverConnectedTo']
            }], hasArrow: [{
                type: Input,
                args: ['cubPopoverHasArrow']
            }], opened: [{
                type: Output,
                args: ['cubPopoverOpened']
            }], closed: [{
                type: Output,
                args: ['cubPopoverClosed']
            }] } });

class CubPopoverConnectedTo {
    constructor(elementRef) {
        this.elementRef = elementRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverConnectedTo, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubPopoverConnectedTo, isStandalone: true, selector: "cub-popover-target, [cubPopoverConnectedTo]", exportAs: ["cubPopoverConnectedTo"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverConnectedTo, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-popover-target, [cubPopoverConnectedTo]',
                    exportAs: 'cubPopoverConnectedTo',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

class CubPopoverModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverModule, imports: [CubPopover,
            CubConfirmPopover,
            CubPopoverTrigger,
            CubPopoverConnectedTo,
            CubPopoverContent], exports: [CubPopover,
            CubConfirmPopover,
            CubPopoverTrigger,
            CubPopoverConnectedTo,
            CubPopoverContent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubConfirmPopover] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubPopoverModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubPopover,
                        CubConfirmPopover,
                        CubPopoverTrigger,
                        CubPopoverConnectedTo,
                        CubPopoverContent,
                    ],
                    exports: [
                        CubPopover,
                        CubConfirmPopover,
                        CubPopoverTrigger,
                        CubPopoverConnectedTo,
                        CubPopoverContent,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

// component

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS, CUB_CONFIRM_POPOVER_DEFAULT_OPTIONS_FACTORY, CUB_POPOVER_CLOSE_REASON, CUB_POPOVER_CONTENT, CUB_POPOVER_DEFAULT_DELAY_TIME, CUB_POPOVER_DEFAULT_OPTIONS, CUB_POPOVER_DEFAULT_OPTIONS_FACTORY, CUB_POPOVER_SCROLL_STRATEGY, CUB_POPOVER_SCROLL_STRATEGY_FACTORY, CUB_POPOVER_SCROLL_STRATEGY_FACTORY_PROVIDER, CubConfirmPopover, CubPopover, CubPopoverConnectedTo, CubPopoverContent, CubPopoverModule, CubPopoverTrigger, _CubPopoverContentBase, throwCubPopoverInvalidPositionEnd, throwCubPopoverInvalidPositionStart, throwCubPopoverMissingError, transformPopover };
//# sourceMappingURL=cub-lib-view-rootng-component-popover.mjs.map
