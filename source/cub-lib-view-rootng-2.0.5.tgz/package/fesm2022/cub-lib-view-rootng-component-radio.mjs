import * as i0 from '@angular/core';
import { InjectionToken, forwardRef, EventEmitter, Output, Input, Directive, ViewChild, ContentChildren, Optional, Inject, Attribute, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty, coerceNumberProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { mixinDisableRipple, mixinTabIndex, CubRipple } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import * as i2 from 'cub-lib-view-rootng/cdk/collections';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';

let nextUniqueId = 0;
class CubRadioChange {
    constructor(source, value) {
        this.source = source;
        this.value = value;
    }
}
const CUB_RADIO = new InjectionToken('CubRadio');
const CUB_RADIO_GROUP = new InjectionToken('CubRadioGroup');
const CUB_RADIO_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubRadio),
    multi: true,
};
const CUB_RADIO_GROUP_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubRadioGroup),
    multi: true,
};
class _CubRadioGroupBase {
    /** 元件名稱，用於表單提交，預設為 undefined。 */
    get name() {
        return this._name;
    }
    set name(value) {
        this._name = value;
        this._updateRadioNames();
    }
    /** 元件標籤位置，預設值為 'after'。 */
    get labelPosition() {
        return this._labelPosition;
    }
    set labelPosition(v) {
        this._labelPosition = v === 'before' ? 'before' : 'after';
        this.markRadiosForCheck();
    }
    /** 元件輸入的的當前值，預設為 undefined。 */
    get value() {
        return this._value;
    }
    set value(newValue) {
        if (this._value !== newValue) {
            this._value = newValue;
            this._updateSelectedRadioFromValue();
            this._checkSelectedRadio();
        }
    }
    /**
     * 元件的選中項目。
     * 此屬性用於設定或取得目前被選中的項目列表。
     * 預設值為 []。
     */
    get selected() {
        return this._selected;
    }
    set selected(selected) {
        this._selected = selected;
        this.value = selected ? selected.value : null;
        this._checkSelectedRadio();
    }
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        this.markRadiosForCheck();
    }
    /** 元件是否為必填，預設為 false。 */
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
        this.markRadiosForCheck();
    }
    constructor(_changeDetector) {
        this._changeDetector = _changeDetector;
        this._isInitialized = false;
        this._name = `cub-radio-group-${nextUniqueId++}`;
        this._labelPosition = 'after';
        this._value = null;
        this._selected = null;
        this._disabled = false;
        this._required = false;
        /** 當元件值發生變化時觸發的事件。傳遞一個 `CubCheckboxChange` 物件，包含元件的來源和選中狀態。 */
        this.change = new EventEmitter();
        this.onTouched = () => { };
        this._controlValueAccessorChangeFn = () => { };
    }
    ngAfterContentInit() {
        this._isInitialized = true;
    }
    writeValue(value) {
        this.value = value;
        this._changeDetector.markForCheck();
    }
    registerOnChange(fn) {
        this._controlValueAccessorChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._changeDetector.markForCheck();
    }
    markRadiosTouched() {
        if (this.onTouched) {
            this.onTouched();
        }
    }
    markRadiosForCheck() {
        if (this._radios) {
            this._radios.forEach((radio) => radio.markForCheck());
        }
    }
    /** Dispatch change event with current selection and group value. */
    _emitChangeEvent() {
        if (this._isInitialized) {
            this.change.emit(new CubRadioChange(this._selected, this._value));
        }
    }
    _checkSelectedRadio() {
        if (this._selected && !this._selected.checked) {
            this._selected.checked = true;
        }
    }
    _updateRadioNames() {
        if (this._radios) {
            this._radios.forEach((radio) => {
                radio.name = this.name;
                radio.markForCheck();
            });
        }
    }
    _updateSelectedRadioFromValue() {
        const isAlreadySelected = this._selected !== null && this._selected.value === this._value;
        if (this._radios && !isAlreadySelected) {
            this._selected = null;
            this._radios.forEach((radio) => {
                radio.checked = this.value === radio.value;
                if (radio.checked) {
                    this._selected = radio;
                }
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubRadioGroupBase, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubRadioGroupBase, isStandalone: true, inputs: { name: "name", labelPosition: "labelPosition", value: "value", selected: "selected", disabled: "disabled", required: "required" }, outputs: { change: "change" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubRadioGroupBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { name: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], value: [{
                type: Input
            }], selected: [{
                type: Input
            }], disabled: [{
                type: Input
            }], required: [{
                type: Input
            }], change: [{
                type: Output
            }] } });
class CubRadioBase {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}
const _CubRadioMixinBase = mixinDisableRipple(mixinTabIndex(CubRadioBase));
class _CubRadioBase extends _CubRadioMixinBase {
    get inputId() {
        return `${this.id || this._uniqueId}-input`;
    }
    /** 元件是否被選中，預設為 false。 */
    get checked() {
        return this._checked;
    }
    set checked(value) {
        const newCheckedState = coerceBooleanProperty(value);
        if (this._checked !== newCheckedState) {
            this._checked = newCheckedState;
            if (newCheckedState &&
                this.radioGroup &&
                this.radioGroup.value !== this.value) {
                this.radioGroup.selected = this;
            }
            else if (!newCheckedState &&
                this.radioGroup &&
                this.radioGroup.value === this.value) {
                this.radioGroup.selected = null;
            }
            if (newCheckedState) {
                this._radioDispatcher.notify(this.id, this.name);
            }
            this._changeDetector.markForCheck();
        }
    }
    /** 元件輸入的當前值，預設為 undefined。 */
    get value() {
        return this._value;
    }
    set value(value) {
        if (this._value !== value) {
            this._value = value;
            if (this.radioGroup !== null) {
                if (!this.checked) {
                    this.checked = this.radioGroup.value === value;
                }
                if (this.checked) {
                    this.radioGroup.selected = this;
                }
            }
        }
    }
    /** 元件標籤位置，預設值為 'after'。 */
    get labelPosition() {
        return (this._labelPosition ||
            (this.radioGroup && this.radioGroup.labelPosition) ||
            'after');
    }
    set labelPosition(value) {
        this._labelPosition = value;
    }
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        return (this._disabled || (this.radioGroup !== null && this.radioGroup.disabled));
    }
    set disabled(value) {
        this._setDisabled(coerceBooleanProperty(value));
    }
    /** 元件是否為必填，預設為 false。 */
    get required() {
        return this._required || (this.radioGroup && this.radioGroup.required);
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    constructor(radioGroup, elementRef, _changeDetector, _focusMonitor, _radioDispatcher, tabIndex) {
        super(elementRef);
        this._changeDetector = _changeDetector;
        this._focusMonitor = _focusMonitor;
        this._radioDispatcher = _radioDispatcher;
        this._uniqueId = `cub-radio-${++nextUniqueId}`;
        this._checked = false;
        this._value = null;
        this._labelPosition = 'after';
        this._disabled = false;
        this._required = false;
        /** 元件唯一識別符，預設為 undefined。 */
        this.id = this._uniqueId;
        /** 元件名稱，用於表單提交，預設為 ''。 */
        this.name = '';
        /** 元件標題（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaLabel = '';
        /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
        this.ariaLabelledby = '';
        /** 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaDescribedby = '';
        /** 當元件值發生變化時觸發的事件。傳遞一個 `CubRadioChange` 物件，包含元件的來源和選中狀態。 */
        this.change = new EventEmitter();
        this.onChanged = () => { };
        this.onTouched = () => { };
        this._removeUniqueSelectionListener = () => { };
        this.radioGroup = radioGroup;
        if (tabIndex) {
            this.tabIndex = coerceNumberProperty(tabIndex, 0);
        }
        this._removeUniqueSelectionListener = _radioDispatcher.listen((id, name) => {
            if (id !== this.id && name === this.name) {
                this.checked = false;
            }
        });
    }
    ngOnInit() {
        if (this.radioGroup) {
            this.checked = this.radioGroup.value === this._value;
            if (this.checked) {
                this.radioGroup.selected = this;
            }
            this.name = this.radioGroup.name;
        }
    }
    ngDoCheck() {
        this._updateTabIndex();
    }
    ngAfterViewInit() {
        this._updateTabIndex();
        this._focusMonitor
            .monitor(this._elementRef, true)
            .subscribe((focusOrigin) => {
            if (!focusOrigin && this.radioGroup) {
                this.radioGroup.markRadiosTouched();
            }
        });
    }
    ngOnDestroy() {
        this._focusMonitor.stopMonitoring(this._elementRef);
        this._removeUniqueSelectionListener();
    }
    _isRippleDisabled() {
        return this.disableRipple || this.disabled;
    }
    writeValue(value) {
        this.value = value;
        this._changeDetector.markForCheck();
    }
    registerOnChange(fn) {
        this.onChanged = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._changeDetector.markForCheck();
    }
    focus(options, origin) {
        if (origin) {
            this._focusMonitor.focusVia(this._inputElement, origin, options);
        }
        else {
            this._inputElement.nativeElement.focus(options);
        }
    }
    markForCheck() {
        this._changeDetector.markForCheck();
    }
    onInputClick(event) {
        event.stopPropagation();
    }
    onInputInteraction(event) {
        event.stopPropagation();
        if (!this.checked && !this.disabled) {
            const groupValueChanged = this.radioGroup && this.value !== this.radioGroup.value;
            this.checked = true;
            this._emitChangeEvent();
            if (this.radioGroup) {
                this.radioGroup._controlValueAccessorChangeFn(this.value);
                if (groupValueChanged) {
                    this.radioGroup._emitChangeEvent();
                }
            }
        }
    }
    _setDisabled(value) {
        if (this._disabled !== value) {
            this._disabled = value;
            this._changeDetector.markForCheck();
        }
    }
    /** Dispatch change event with current value. */
    _emitChangeEvent() {
        this.change.emit(new CubRadioChange(this, this._value));
    }
    _updateTabIndex() {
        const group = this.radioGroup;
        let value;
        if (!group || !group.selected || this.disabled) {
            value = this.tabIndex;
        }
        else {
            value = group.selected === this ? this.tabIndex : -1;
        }
        if (value !== this._previousTabIndex) {
            const input = this._inputElement?.nativeElement;
            if (input) {
                input.setAttribute('tabindex', value + '');
                this._previousTabIndex = value;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubRadioBase, deps: "invalid", target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubRadioBase, isStandalone: true, inputs: { id: "id", name: "name", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], checked: "checked", value: "value", labelPosition: "labelPosition", disabled: "disabled", required: "required" }, outputs: { change: "change" }, viewQueries: [{ propertyName: "_inputElement", first: true, predicate: ["input"], descendants: true }, { propertyName: "_labelElement", first: true, predicate: ["label"], descendants: true }, { propertyName: "ripple", first: true, predicate: CubRipple, descendants: true }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubRadioBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: _CubRadioGroupBase }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.FocusMonitor }, { type: i2.UniqueSelectionDispatcher }, { type: undefined }], propDecorators: { id: [{
                type: Input
            }], name: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], checked: [{
                type: Input
            }], value: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], disabled: [{
                type: Input
            }], required: [{
                type: Input
            }], change: [{
                type: Output
            }], _inputElement: [{
                type: ViewChild,
                args: ['input']
            }], _labelElement: [{
                type: ViewChild,
                args: ['label']
            }], ripple: [{
                type: ViewChild,
                args: [CubRipple]
            }] } });
class CubRadioGroup extends _CubRadioGroupBase {
    constructor() {
        super(...arguments);
        /** 群組排列方向，預設為 'horizontal'。 */
        this.orientation = 'horizontal';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadioGroup, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubRadioGroup, isStandalone: true, selector: "cub-radio-group", inputs: { orientation: "orientation" }, host: { attributes: { "role": "radiogroup" }, properties: { "class.cub-radio-group-horizontal": "orientation === \"horizontal\"", "class.cub-radio-group-vertical": "orientation === \"vertical\"" } }, providers: [
            CUB_RADIO_GROUP_CONTROL_VALUE_ACCESSOR,
            { provide: CUB_RADIO_GROUP, useExisting: CubRadioGroup },
        ], queries: [{ propertyName: "_radios", predicate: i0.forwardRef(() => CubRadio), descendants: true }], exportAs: ["cubRadioGroup"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadioGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-radio-group',
                    exportAs: 'cubRadioGroup',
                    providers: [
                        CUB_RADIO_GROUP_CONTROL_VALUE_ACCESSOR,
                        { provide: CUB_RADIO_GROUP, useExisting: CubRadioGroup },
                    ],
                    host: {
                        role: 'radiogroup',
                        '[class.cub-radio-group-horizontal]': 'orientation === "horizontal"',
                        '[class.cub-radio-group-vertical]': 'orientation === "vertical"',
                    },
                }]
        }], propDecorators: { orientation: [{
                type: Input
            }], _radios: [{
                type: ContentChildren,
                args: [forwardRef(() => CubRadio), {
                        descendants: true,
                    }]
            }] } });
class CubRadio extends _CubRadioBase {
    constructor(radioGroup, elementRef, changeDetector, focusMonitor, radioDispatcher, _animationMode, tabIndex) {
        super(radioGroup, elementRef, changeDetector, focusMonitor, radioDispatcher, tabIndex);
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        this._noopAnimations = _animationMode === 'NoopAnimations';
    }
    /**
     * 處理標籤上的鍵盤事件。
     * 當使用者按下空白鍵時，會切換選取狀態，與顯示 Ripple 漣漪。
     */
    _onLabelKeydown(event, rippleRef) {
        if (event instanceof KeyboardEvent) {
            /* 空白鍵以外操作不顯示 Ripple */
            rippleRef.disabled = event.code !== 'Space';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadio, deps: [{ token: CUB_RADIO_GROUP, optional: true }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.FocusMonitor }, { token: i2.UniqueSelectionDispatcher }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: 'tabindex', attribute: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubRadio, isStandalone: true, selector: "cub-radio", inputs: { disableRipple: "disableRipple", tabIndex: "tabIndex", size: "size" }, host: { listeners: { "focus": "_inputElement.nativeElement.focus()" }, properties: { "attr.id": "id", "class.cub-radio-checked": "checked", "class.cub-radio-disabled": "disabled", "class.cub-radio-invalid": "errorState", "class.cub-radio-small": "size === \"small\"", "attr.tabindex": "null", "attr.aria-label": "null", "attr.aria-labelledby": "null", "attr.aria-describedby": "null", "attr.aria-invalid": "(empty && required) ? null : errorState" }, classAttribute: "cub-radio" }, providers: [
            CUB_RADIO_CONTROL_VALUE_ACCESSOR,
            { provide: CUB_RADIO, useExisting: CubRadio },
        ], exportAs: ["cubRadio"], usesInheritance: true, ngImport: i0, template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  class=\"cub-radio-label\"\n  [class.cub-radio-label-before]=\"labelPosition == 'before'\"\n  [class.cub-radio-label-empty]=\"\n    !radioLabel.textContent || !radioLabel.textContent.trim()\n  \"\n  (keydown)=\"_onLabelKeydown($event, rippleRef)\"\n>\n  <span class=\"cub-radio-container\">\n    <input\n      #input\n      class=\"cub-radio-input\"\n      type=\"radio\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [disabled]=\"disabled\"\n      [attr.name]=\"name\"\n      [attr.value]=\"value\"\n      [attr.aria-label]=\"ariaLabel\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"onInputInteraction($event)\"\n      (click)=\"onInputClick($event)\"\n    />\n    <span class=\"cub-radio-circle-background\">\n      @if (checked) {\n      <span class=\"cub-radio-circle-checked\"> </span>\n      }\n    </span>\n    <span\n      #rippleRef=\"cubRipple\"\n      class=\"cub-focus-indicator\"\n      cubRipple\n      cubRippleClass=\"cub-radio-ripple\"\n      [cubRippleTrigger]=\"label\"\n      [cubRippleDisabled]=\"_isRippleDisabled()\"\n      [cubRippleCentered]=\"true\"\n      [cubRippleAnimation]=\"{\n        enterDuration: _noopAnimations ? 0 : 150\n      }\"\n    >\n    </span>\n    <span class=\"cub-persistent-ripple cub-radio-persistent-ripple\"></span>\n  </span>\n  <span class=\"cub-radio-label-content\" #radioLabel>\n    <span style=\"display: none\">&nbsp;</span>\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadio, decorators: [{
            type: Component,
            args: [{ selector: 'cub-radio', providers: [
                        CUB_RADIO_CONTROL_VALUE_ACCESSOR,
                        { provide: CUB_RADIO, useExisting: CubRadio },
                    ], host: {
                        class: 'cub-radio',
                        '[attr.id]': 'id',
                        '[class.cub-radio-checked]': 'checked',
                        '[class.cub-radio-disabled]': 'disabled',
                        '[class.cub-radio-invalid]': 'errorState',
                        '[class.cub-radio-small]': 'size === "small"',
                        '[attr.tabindex]': 'null',
                        '[attr.aria-label]': 'null',
                        '[attr.aria-labelledby]': 'null',
                        '[attr.aria-describedby]': 'null',
                        '[attr.aria-invalid]': '(empty && required) ? null : errorState',
                        '(focus)': '_inputElement.nativeElement.focus()',
                    }, inputs: ['disableRipple', 'tabIndex'], exportAs: 'cubRadio', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubRipple], template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  class=\"cub-radio-label\"\n  [class.cub-radio-label-before]=\"labelPosition == 'before'\"\n  [class.cub-radio-label-empty]=\"\n    !radioLabel.textContent || !radioLabel.textContent.trim()\n  \"\n  (keydown)=\"_onLabelKeydown($event, rippleRef)\"\n>\n  <span class=\"cub-radio-container\">\n    <input\n      #input\n      class=\"cub-radio-input\"\n      type=\"radio\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [disabled]=\"disabled\"\n      [attr.name]=\"name\"\n      [attr.value]=\"value\"\n      [attr.aria-label]=\"ariaLabel\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"onInputInteraction($event)\"\n      (click)=\"onInputClick($event)\"\n    />\n    <span class=\"cub-radio-circle-background\">\n      @if (checked) {\n      <span class=\"cub-radio-circle-checked\"> </span>\n      }\n    </span>\n    <span\n      #rippleRef=\"cubRipple\"\n      class=\"cub-focus-indicator\"\n      cubRipple\n      cubRippleClass=\"cub-radio-ripple\"\n      [cubRippleTrigger]=\"label\"\n      [cubRippleDisabled]=\"_isRippleDisabled()\"\n      [cubRippleCentered]=\"true\"\n      [cubRippleAnimation]=\"{\n        enterDuration: _noopAnimations ? 0 : 150\n      }\"\n    >\n    </span>\n    <span class=\"cub-persistent-ripple cub-radio-persistent-ripple\"></span>\n  </span>\n  <span class=\"cub-radio-label-content\" #radioLabel>\n    <span style=\"display: none\">&nbsp;</span>\n    <ng-content></ng-content>\n  </span>\n</label>\n" }]
        }], ctorParameters: () => [{ type: CubRadioGroup, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_RADIO_GROUP]
                }] }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.FocusMonitor }, { type: i2.UniqueSelectionDispatcher }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }], propDecorators: { size: [{
                type: Input
            }] } });

class CubRadioModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadioModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubRadioModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubRadio,
            CubRadioGroup], exports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubRadio,
            CubRadioGroup] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadioModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule, CubFormFieldModule,
            CubLabelModule,
            CubInputModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRadioModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubRadio,
                        CubRadioGroup,
                    ],
                    exports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubRadio,
                        CubRadioGroup,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/radio
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_RADIO, CUB_RADIO_CONTROL_VALUE_ACCESSOR, CUB_RADIO_GROUP, CUB_RADIO_GROUP_CONTROL_VALUE_ACCESSOR, CubRadio, CubRadioChange, CubRadioGroup, CubRadioModule, _CubRadioBase, _CubRadioGroupBase };
//# sourceMappingURL=cub-lib-view-rootng-component-radio.mjs.map
