import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ContentChildren, Component, NgModule } from '@angular/core';
import { CubIconButton, CubHyperlink, CubButtonModule } from 'cub-lib-view-rootng/component/button';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';

class CubResourceItem {
    constructor(host) {
        this.host = host;
        /**
         * 元件 size 屬性，預設為 medium。
         */
        this.size = 'medium';
        /**
         * 元件 error 狀態，預設為 false。
         */
        this.hasError = false;
        /**
         * 元件是否禁用，預設為 false。
         */
        this.disabled = false;
        /**
         * 元件 loading 狀態，預設為 false。
         */
        this.loading = false;
        /**
         * 元件 extraInfo 字串顯示，預設為 null。
         */
        this.extraInfo = null;
        /**
         * 超連結預設字串，預設為 '連結'。
         */
        this.hyperlinkText = '連結';
        /**
         是否隱藏關閉按鈕，預設為 false。
         */
        this.hideClose = false;
        /**
         * 當關閉元件時發出通知。
         */
        this.closed = new EventEmitter();
    }
    ngAfterContentChecked() {
        if (this._hyperlinkChildren.length === 0) {
            this.host.nativeElement.remove();
            return;
        }
        this._hyperlinkChildren.forEach((hyperlink) => {
            const hyperlinkTextElement = hyperlink._elementRef.nativeElement.querySelector('.cub-hyperlink-content');
            const hyperlinkText = hyperlinkTextElement.innerText;
            if (!hyperlinkText.trim()) {
                hyperlinkTextElement.innerText = this.hyperlinkText;
            }
        });
    }
    close() {
        this.host.nativeElement.remove();
        this.closed.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResourceItem, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubResourceItem, isStandalone: true, selector: "cub-resource-item", inputs: { size: "size", hasError: "hasError", disabled: "disabled", loading: "loading", extraInfo: "extraInfo", hyperlinkText: "hyperlinkText", hideClose: "hideClose" }, outputs: { closed: "closed" }, host: { properties: { "class.cub-resource-item-medium": "size === \"medium\"", "class.cub-resource-item-small": "size === \"small\"", "class.cub-resource-item-hide-close": "hideClose", "class.cub-resource-item-error": "!!hasError", "class.cub-disabled": "!!disabled" }, classAttribute: "cub-resource-item" }, queries: [{ propertyName: "_hyperlinkChildren", predicate: CubHyperlink, descendants: true }], ngImport: i0, template: "<div class=\"cub-resource-item-content\">\n  <div class=\"cub-resource-item-content-left\">\n    <ng-content select=\"a[cub-hyperlink]\"></ng-content>\n  </div>\n  @if (extraInfo) {\n  <div class=\"cub-resource-item-content-right\">\n    <div class=\"cub-resource-item-extra-info\">{{ extraInfo }}</div>\n  </div>\n  }\n</div>\n@if (!loading && !hideClose) {\n<div class=\"cub-resource-item-close\">\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral-light\"\n    appearance=\"plain\"\n    [size]=\"size\"\n    [disabled]=\"disabled\"\n    (click)=\"close()\"\n  >\n    <span class=\"cub-icon-x-small\"></span>\n  </button>\n</div>\n} @if (loading) {\n<cub-loading [size]=\"'small'\"></cub-loading>\n}\n", styles: [""], dependencies: [{ kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResourceItem, decorators: [{
            type: Component,
            args: [{ selector: 'cub-resource-item', host: {
                        class: 'cub-resource-item',
                        '[class.cub-resource-item-medium]': 'size === "medium"',
                        '[class.cub-resource-item-small]': 'size === "small"',
                        '[class.cub-resource-item-hide-close]': 'hideClose',
                        '[class.cub-resource-item-error]': '!!hasError',
                        '[class.cub-disabled]': '!!disabled',
                    }, imports: [CubIconButton, CubLoading], template: "<div class=\"cub-resource-item-content\">\n  <div class=\"cub-resource-item-content-left\">\n    <ng-content select=\"a[cub-hyperlink]\"></ng-content>\n  </div>\n  @if (extraInfo) {\n  <div class=\"cub-resource-item-content-right\">\n    <div class=\"cub-resource-item-extra-info\">{{ extraInfo }}</div>\n  </div>\n  }\n</div>\n@if (!loading && !hideClose) {\n<div class=\"cub-resource-item-close\">\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral-light\"\n    appearance=\"plain\"\n    [size]=\"size\"\n    [disabled]=\"disabled\"\n    (click)=\"close()\"\n  >\n    <span class=\"cub-icon-x-small\"></span>\n  </button>\n</div>\n} @if (loading) {\n<cub-loading [size]=\"'small'\"></cub-loading>\n}\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { _hyperlinkChildren: [{
                type: ContentChildren,
                args: [CubHyperlink, { descendants: true }]
            }], size: [{
                type: Input
            }], hasError: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loading: [{
                type: Input
            }], extraInfo: [{
                type: Input
            }], hyperlinkText: [{
                type: Input
            }], hideClose: [{
                type: Input
            }], closed: [{
                type: Output
            }] } });

class CubResourceItemModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResourceItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubResourceItemModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule,
            /** Component */
            CubResourceItem], exports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule,
            /** Component */
            CubResourceItem] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResourceItemModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule,
            /** Component */
            CubResourceItem, CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResourceItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubButtonModule,
                        /** Component */
                        CubResourceItem,
                    ],
                    exports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubButtonModule,
                        /** Component */
                        CubResourceItem,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/resource-item
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubResourceItem, CubResourceItemModule };
//# sourceMappingURL=cub-lib-view-rootng-component-resource-item.mjs.map
