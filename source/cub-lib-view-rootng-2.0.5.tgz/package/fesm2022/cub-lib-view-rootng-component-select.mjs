import * as i0 from '@angular/core';
import { InjectionToken, Directive, EventEmitter, ViewChild, Output, Input, Optional, Inject, Self, Attribute, ContentChild, ContentChildren, ElementRef, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { NgSwitch, NgSwitchCase, NgSwitchDefault, NgIf, NgClass } from '@angular/common';
import * as i1$1 from '@angular/forms';
import { Validators, ReactiveFormsModule } from '@angular/forms';
import { Subject, defer, merge } from 'rxjs';
import { startWith, switchMap, take, filter, map, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { Overlay, CubCdkConnectedOverlay, CubCdkOverlayOrigin, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { DOWN_ARROW, UP_ARROW, LEFT_ARROW, RIGHT_ARROW, ENTER, SPACE, hasModifierKey, A, TAB, Z, ZERO, NINE } from 'cub-lib-view-rootng/cdk/keycodes';
import * as i2 from 'cub-lib-view-rootng/component/common';
import { mixinDisableRipple, mixinTabIndex, mixinDisabled, mixinErrorState, CubRipple, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import { _countGroupLabelsBeforeOption, _getOptionScrollPosition, CubOption, CUB_OPTION_GROUP, CubOptionGroup, CUB_OPTION_PARENT, CubOptionModule } from 'cub-lib-view-rootng/component/option';
import * as i6 from 'cub-lib-view-rootng/component/form-field';
import { CUB_FORM_FIELD, CubFormField, CubFormFieldControl, CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubCheckbox } from 'cub-lib-view-rootng/component/checkbox';
import { CubInput } from 'cub-lib-view-rootng/component/input';
import { trigger, state, transition, style, animate, query, animateChild } from '@angular/animations';
import * as i5 from 'cub-lib-view-rootng/cdk/a11y';
import { ActiveDescendantKeyManager } from 'cub-lib-view-rootng/cdk/a11y';
import { coerceBooleanProperty, coerceNumberProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { SelectionModel } from 'cub-lib-view-rootng/cdk/collections';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';
import { CubCdkScrollableModule } from 'cub-lib-view-rootng/cdk/scrolling';
import * as i3 from 'cub-lib-view-rootng/cdk/bidi';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputGroupModule } from 'cub-lib-view-rootng/component/input-group';

/**
 * Injection token that can be used to reference instances of `CubSelectTrigger`. It serves as
 * alternative token to the actual `CubSelectTrigger` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
const CUB_SELECT_TRIGGER = new InjectionToken('CubSelectTrigger');
/**
 * Allows the user to customize the trigger that is displayed when the select has a value.
 */
class CubSelectTrigger {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSelectTrigger, isStandalone: true, selector: "cub-select-trigger", providers: [{ provide: CUB_SELECT_TRIGGER, useExisting: CubSelectTrigger }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-select-trigger',
                    providers: [{ provide: CUB_SELECT_TRIGGER, useExisting: CubSelectTrigger }],
                }]
        }], ctorParameters: () => [] });

/** @docs-private */
function CUB_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition();
}
/**
 * Returns an exception to be thrown when attempting to change a select's `multiple` option
 * after initialization.
 * @docs-private
 */
function getCubSelectDynamicMultipleError() {
    return Error('Cannot change `multiple` mode of select after initialization.');
}
/**
 * Returns an exception to be thrown when attempting to assign a non-array value to a select
 * in `multiple` mode. Note that `undefined` and `null` are still valid values to allow for
 * resetting the value.
 * @docs-private
 */
function getCubSelectNonArrayValueError() {
    return Error('Value must be an array in multiple-selection mode.');
}
/**
 * Returns an exception to be thrown when assigning a non-function value to the comparator
 * used to determine if a value corresponds to an option. Note that whether the function
 * actually takes two values and returns a boolean is not checked.
 */
function getCubSelectNonFunctionValueError() {
    return Error('`compareWith` must be a function.');
}

/**
 * The following style constants are necessary to save here in order
 * to properly calculate the alignment of the selected option over
 * the trigger element.
 */
/** The max height of the select's overlay panel. */
const SELECT_PANEL_MAX_HEIGHT = 256;
/** The panel's padding on the x-axis. */
const SELECT_PANEL_PADDING_X = 16;
/** The panel's x axis padding if it is indented (e.g. there is an option group). */
const SELECT_PANEL_INDENT_PADDING_X = SELECT_PANEL_PADDING_X * 2;
/** The height of the select items in `em` units. */
const SELECT_ITEM_HEIGHT_EM = 3;
// TODO(josephperrott): Revert to a constant after 2018 spec updates are fully merged.
/**
 * Distance between the panel edge and the option text in
 * multi-selection mode.
 *
 * Calculated as:
 * (SELECT_PANEL_PADDING_X * 1.5) + 16 = 40
 * The padding is multiplied by 1.5 because the checkbox's margin is half the padding.
 * The checkbox width is 16px.
 */
const SELECT_MULTIPLE_PANEL_PADDING_X = SELECT_PANEL_PADDING_X * 1.5 + 16;
/**
 * The select panel will only "fit" inside the viewport if it is positioned at
 * this value or more away from the viewport boundary.
 */
const SELECT_PANEL_VIEWPORT_PADDING = 8;
/** Injection token that determines the scroll handling while a select is open. */
const CUB_SELECT_SCROLL_STRATEGY = new InjectionToken('cub-select-scroll-strategy');
/** Injection token that can be used to provide the default options the select module. */
const CUB_SELECT_CONFIG = new InjectionToken('CUB_SELECT_CONFIG');
/** @docs-private */
const CUB_SELECT_SCROLL_STRATEGY_PROVIDER = {
    provide: CUB_SELECT_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
};
// Boilerplate for applying mixins to CubSelect.
/** @docs-private */
const _CubSelectMixinBase = mixinDisableRipple(mixinTabIndex(mixinDisabled(mixinErrorState(class {
    constructor(_elementRef, _defaultErrorStateMatcher, _parentForm, _parentFormGroup, 
    /**
     * Form control bound to the component.
     * Implemented as part of `CubFormFieldControl`.
     * @docs-private
     */
    ngControl) {
        this._elementRef = _elementRef;
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
        /**
         * Emits whenever the component state changes and should cause the parent
         * form-field to update. Implemented as part of `CubFormFieldControl`.
         * @docs-private
         */
        this.stateChanges = new Subject();
    }
}))));
/**
 * The following are all the animations for the cub-select component, with each
 * const containing the metadata for one animation.
 *
 * The values below match the implementation of the AngularJS CUB cub-select animation.
 * @docs-private
 */
const cubSelectAnimations = {
    /**
     * This animation ensures the select's overlay panel animation (transformPanel) is called when
     * closing the select.
     * This is needed due to https://github.com/angular/angular/issues/23302
     */
    transformPanelWrap: trigger('transformPanelWrap', [
        transition('* => void', query('@transformPanel', [animateChild()], { optional: true })),
    ]),
    /**
     * This animation transforms the select's overlay panel on and off the page.
     *
     * When the panel is attached to the DOM, it expands its width by the amount of padding, scales it
     * up to 100% on the Y axis, fades in its border, and translates slightly up and to the
     * side to ensure the option text correctly overlaps the trigger text.
     *
     * When the panel is removed from the DOM, it simply fades out linearly.
     */
    transformPanel: trigger('transformPanel', [
        state('void', style({
            transform: 'scaleY(0.8)',
            minWidth: '100%',
            opacity: 0,
        })),
        state('showing', style({
            opacity: 1,
            minWidth: 'calc(100% + 32px)', // 32px = 2 * 16px padding
            transform: 'scaleY(1)',
        })),
        state('showing-multiple', style({
            opacity: 1,
            minWidth: 'calc(100% + 64px)', // 64px = 48px padding on the left + 16px padding on the right
            transform: 'scaleY(1)',
        })),
        transition('void => *', animate('120ms cubic-bezier(0, 0, 0.2, 1)')),
        transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
    ]),
};

let nextUniqueId = 0;
/** Base class with all of the `CubSelect` functionality. */
class _CubSelectBase extends _CubSelectMixinBase {
    /**
     * Implemented as part of CubFormFieldControl.
     * @docs-private
     */
    get shouldLabelFloat() {
        return (this._panelOpen || !this.empty || (this._focused && !!this._placeholder));
    }
    /** Whether the select has a value. */
    get empty() {
        return !this._selectionModel || this._selectionModel.isEmpty();
    }
    /** Whether or not the overlay panel is open. */
    get panelOpen() {
        return this._panelOpen;
    }
    /** The currently selected option. */
    get selected() {
        return this.multiple
            ? this._selectionModel?.selected || []
            : this._selectionModel?.selected[0];
    }
    /** The value displayed in the trigger. */
    get triggerValue() {
        if (this.empty) {
            return '';
        }
        if (this._multiple) {
            const selectedOptions = this._selectionModel.selected.map((option) => option.viewValue);
            if (this._isRtl()) {
                selectedOptions.reverse();
            }
            // TODO(crisbeto): delimiter should be configurable for proper localization.
            return selectedOptions.join(', ');
        }
        return this._selectionModel.selected[0].viewValue;
    }
    /** Whether the select is focused. */
    get focused() {
        return this._focused || this._panelOpen;
    }
    /** 元件的佔位符，預設為 undefined。 */
    get placeholder() {
        return this._placeholder;
    }
    set placeholder(value) {
        this._placeholder = value;
        this.stateChanges.next();
    }
    /** 元件是否為必填，預設為否。 */
    get required() {
        return (this._required ??
            this.ngControl?.control?.hasValidator(Validators.required) ??
            false);
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
        this.stateChanges.next();
    }
    /** 元件是否啟用選擇功能，預設為不啟用。 */
    get multiple() {
        return this._multiple;
    }
    set multiple(value) {
        if (this._selectionModel) {
            throw getCubSelectDynamicMultipleError();
        }
        this._multiple = coerceBooleanProperty(value);
    }
    /** 元件比較選項值和選定值的函式，第一個參數是選項中的值，第二個參數是選定的值，並且需要回傳一個布林值，預設為 (o1: any, o2: any) => o1 === o2。 */
    get compareWith() {
        return this._compareWith;
    }
    set compareWith(fn) {
        if (typeof fn !== 'function') {
            throw getCubSelectNonFunctionValueError();
        }
        this._compareWith = fn;
        if (this._selectionModel) {
            // A different comparator means the selection could change.
            this._initializeSelection();
        }
    }
    /** 元件的數值，預設為 undefined。 */
    get value() {
        return this._value;
    }
    set value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    /** 元件在將焦點移至某個項目之前，最後一次按鍵後等待的時間（以毫秒為單位），預設為 undefined。 */
    get typeaheadDebounceInterval() {
        return this._typeaheadDebounceInterval;
    }
    set typeaheadDebounceInterval(value) {
        this._typeaheadDebounceInterval = coerceNumberProperty(value);
    }
    /** 元件 id，預設為 undefined。 */
    get id() {
        return this._id;
    }
    set id(value) {
        this._id = value || this._uid;
        this.stateChanges.next();
    }
    constructor(_viewportRuler, _changeDetectorRef, _ngZone, _defaultErrorStateMatcher, elementRef, _dir, _parentForm, _parentFormGroup, _parentFormField, ngControl, tabIndex, scrollStrategyFactory, _liveAnnouncer, _defaultOptions) {
        super(elementRef, _defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl);
        this._viewportRuler = _viewportRuler;
        this._changeDetectorRef = _changeDetectorRef;
        this._ngZone = _ngZone;
        this._dir = _dir;
        this._parentFormField = _parentFormField;
        this._liveAnnouncer = _liveAnnouncer;
        this._defaultOptions = _defaultOptions;
        /** 元件是使否將以選中的選項置中於選擇框中，預設為否。 */
        // @Input()
        // get disableOptionCentering(): boolean {
        //   return this._disableOptionCentering;
        // }
        // set disableOptionCentering(value: BooleanInput) {
        //   this._disableOptionCentering = coerceBooleanProperty(value);
        // }
        // private _disableOptionCentering =
        //   this._defaultOptions?.disableOptionCentering ?? false;
        this.disableOptionCentering = false;
        /** A name for this control that can be used by `cub-form-field`. */
        this.controlType = 'cub-select';
        /** ID for the DOM node containing the select's value. */
        this._valueId = `cub-select-value-${nextUniqueId++}`;
        this._overlayPanelClass = this._defaultOptions?.overlayPanelClass || '';
        /** Combined stream of all of the child options' change events. */
        this.optionSelectionChanges = defer(() => {
            const options = this.options;
            if (options) {
                return options.changes.pipe(startWith(options), switchMap(() => merge(...options.map((option) => option.selectionChange))));
            }
            return this._ngZone.onStable.pipe(take(1), switchMap(() => this.optionSelectionChanges));
        });
        /** Emits when the panel element is finished transforming in. */
        this._panelDoneAnimatingStream = new Subject();
        /** Emits whenever the component is destroyed. */
        this._destroy = new Subject();
        /** Whether or not the overlay panel is open. */
        this._panelOpen = false;
        /** Unique id for this input. */
        this._uid = `cub-select-${nextUniqueId++}`;
        /** Current `aria-labelledby` value for the select trigger. */
        this._triggerAriaLabelledBy = null;
        this._focused = false;
        this._multiple = false;
        /** 元件的標題（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaLabel = '';
        /** 當開關下拉選單 Panel 時發出通知。 */
        this.openedChange = new EventEmitter();
        /** 當更改了選定值時發出通知。 */
        this.selectionChange = new EventEmitter();
        /** 當更改了元件數值時發出通知。 */
        this.valueChange = new EventEmitter();
        /** 當開啟下拉選單 Panel 時發出通知。 */
        this._openedStream = this.openedChange.pipe(filter((o) => o), map(() => { }));
        /** 當關閉下拉選單 Panel 時發出通知。 */
        this._closedStream = this.openedChange.pipe(filter((o) => !o), map(() => { }));
        /** `View -> model callback called when value changes` */
        this._onChange = () => { };
        /** `View -> model callback called when select has been touched` */
        this._onTouched = () => { };
        /** Comparison function to specify which option is displayed. Defaults to object equality. */
        this._compareWith = (o1, o2) => o1 === o2;
        if (this.ngControl) {
            // Note: we provide the value accessor through here, instead of
            // the `providers` to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        // Note that we only want to set this when the defaults pass it in, otherwise it should
        // stay as `undefined` so that it falls back to the default in the key manager.
        if (_defaultOptions?.typeaheadDebounceInterval != null) {
            this._typeaheadDebounceInterval =
                _defaultOptions.typeaheadDebounceInterval;
        }
        this._scrollStrategyFactory = scrollStrategyFactory;
        this._scrollStrategy = this._scrollStrategyFactory();
        this.tabIndex = parseInt(tabIndex) || 0;
        // Force setter to be called in case id was not specified.
        this.id = this.id;
    }
    ngOnInit() {
        this._selectionModel = new SelectionModel(this.multiple);
        this.stateChanges.next();
        // We need `distinctUntilChanged` here, because some browsers will
        // fire the animation end event twice for the same animation. See:
        // https://github.com/angular/angular/issues/24084
        this._panelDoneAnimatingStream
            .pipe(distinctUntilChanged(), takeUntil(this._destroy))
            .subscribe(() => this._panelDoneAnimating(this.panelOpen));
    }
    ngAfterContentInit() {
        this._initKeyManager();
        this._selectionModel.changed
            .pipe(takeUntil(this._destroy))
            .subscribe((event) => {
            event.added.forEach((option) => option.select());
            event.removed.forEach((option) => option.deselect());
        });
        this.options.changes
            .pipe(startWith(null), takeUntil(this._destroy))
            .subscribe(() => {
            this._resetOptions();
            this._initializeSelection();
        });
    }
    ngDoCheck() {
        const newAriaLabelledby = this._getTriggerAriaLabelledby();
        const ngControl = this.ngControl;
        // We have to manage setting the `aria-labelledby` ourselves, because part of its value
        // is computed as a result of a content query which can cause this binding to trigger a
        // "changed after checked" error.
        if (newAriaLabelledby !== this._triggerAriaLabelledBy) {
            const element = this._elementRef.nativeElement;
            this._triggerAriaLabelledBy = newAriaLabelledby;
            if (newAriaLabelledby) {
                element.setAttribute('aria-labelledby', newAriaLabelledby);
            }
            else {
                element.removeAttribute('aria-labelledby');
            }
        }
        if (ngControl) {
            // The disabled state might go out of sync if the form group is swapped out. See #17860.
            if (this._previousControl !== ngControl.control) {
                if (this._previousControl !== undefined &&
                    ngControl.disabled !== null &&
                    ngControl.disabled !== this.disabled) {
                    this.disabled = ngControl.disabled;
                }
                this._previousControl = ngControl.control;
            }
            this.updateErrorState();
        }
    }
    ngOnChanges(changes) {
        // Updating the disabled state is handled by `mixinDisabled`, but we need to additionally let
        // the parent form field know to run change detection when the disabled state changes.
        if (changes['disabled'] || changes['ariaDescribedBy']) {
            this.stateChanges.next();
        }
        if (changes['typeaheadDebounceInterval'] && this._keyManager) {
            this._keyManager.withTypeAhead(this._typeaheadDebounceInterval);
        }
    }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
        this.stateChanges.complete();
    }
    /** Toggles the overlay panel open or closed. */
    toggle() {
        this.panelOpen ? this.close() : this.open();
    }
    /** Opens the overlay panel. */
    open() {
        if (this._canOpen()) {
            this._panelOpen = true;
            this._keyManager.withHorizontalOrientation(null);
            this._highlightCorrectOption();
            this._changeDetectorRef.markForCheck();
        }
    }
    /** Closes the overlay panel and focuses the host element. */
    close() {
        if (this._panelOpen) {
            this._panelOpen = false;
            this._keyManager.withHorizontalOrientation(this._isRtl() ? 'rtl' : 'ltr');
            this._changeDetectorRef.markForCheck();
            this._onTouched();
        }
    }
    /**
     * Sets the select's value. Part of the ControlValueAccessor interface
     * required to integrate with Angular's core forms API.
     *
     * @param value New value to be written to the model.
     */
    writeValue(value) {
        this._assignValue(value);
    }
    /**
     * Saves a callback function to be invoked when the select's value
     * changes from user input. Part of the ControlValueAccessor interface
     * required to integrate with Angular's core forms API.
     *
     * @param fn Callback to be triggered when the value changes.
     */
    registerOnChange(fn) {
        this._onChange = fn;
    }
    /**
     * Saves a callback function to be invoked when the select is blurred
     * by the user. Part of the ControlValueAccessor interface required
     * to integrate with Angular's core forms API.
     *
     * @param fn Callback to be triggered when the component has been touched.
     */
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    /**
     * Disables the select. Part of the ControlValueAccessor interface required
     * to integrate with Angular's core forms API.
     *
     * @param isDisabled Sets whether the component is disabled.
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._changeDetectorRef.markForCheck();
        this.stateChanges.next();
    }
    /**
     * Implemented as part of CubFormFieldControl.
     * @docs-private
     */
    setDescribedByIds(ids) {
        if (ids.length) {
            this._elementRef.nativeElement.setAttribute('aria-describedby', ids.join(' '));
        }
        else {
            this._elementRef.nativeElement.removeAttribute('aria-describedby');
        }
    }
    /**
     * Implemented as part of CubFormFieldControl.
     * @docs-private
     */
    onContainerClick() {
        this.focus();
        this.open();
    }
    /** Focuses the select element. */
    focus(options) {
        this._elementRef.nativeElement.focus(options);
    }
    _onFocus() {
        if (!this.disabled) {
            this._focused = true;
            this.stateChanges.next();
        }
    }
    /**
     * Calls the touched callback only if the panel is closed. Otherwise, the trigger will
     * "blur" to the panel when it opens, causing a false positive.
     */
    _onBlur() {
        this._focused = false;
        if (!this.disabled && !this.panelOpen) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
            this.stateChanges.next();
        }
    }
    /**
     * Callback that is invoked when the overlay panel has been attached.
     */
    _onAttached() {
        this._overlayDir.positionChange.pipe(take(1)).subscribe(() => {
            this._changeDetectorRef.detectChanges();
            this._positioningSettled();
        });
    }
    /** Whether the element is in RTL mode. */
    _isRtl() {
        return this._dir ? this._dir.value === 'rtl' : false;
    }
    /** Handles all keydown events on the select. */
    _handleKeydown(event) {
        if (!this.disabled) {
            this.panelOpen
                ? this._handleOpenKeydown(event)
                : this._handleClosedKeydown(event);
        }
    }
    /** Gets the aria-labelledby for the select panel. */
    _getPanelAriaLabelledby() {
        if (this.ariaLabel) {
            return null;
        }
        const labelId = this._parentFormField?._label._labelId;
        const labelExpression = labelId ? labelId + ' ' : '';
        return this.ariaLabelledby
            ? labelExpression + this.ariaLabelledby
            : labelId;
    }
    /** Determines the `aria-activedescendant` to be set on the host. */
    _getAriaActiveDescendant() {
        if (this.panelOpen && this._keyManager && this._keyManager.activeItem) {
            return this._keyManager.activeItem.id;
        }
        return null;
    }
    /** Whether the panel is allowed to open. */
    _canOpen() {
        return !this._panelOpen && !this.disabled && this.options?.length > 0;
    }
    /** Called when the overlay panel is done animating. */
    _panelDoneAnimating(isOpen) {
        this.openedChange.emit(isOpen);
    }
    /** Handles keyboard events while the select is closed. */
    _handleClosedKeydown(event) {
        const keyCode = event.keyCode;
        const isArrowKey = keyCode === DOWN_ARROW ||
            keyCode === UP_ARROW ||
            keyCode === LEFT_ARROW ||
            keyCode === RIGHT_ARROW;
        const isOpenKey = keyCode === ENTER || keyCode === SPACE;
        const manager = this._keyManager;
        // Open the select on ALT + arrow key to match the native <select>
        if ((!manager.isTyping() && isOpenKey && !hasModifierKey(event)) ||
            ((this.multiple || event.altKey) && isArrowKey)) {
            event.preventDefault(); // prevents the page from scrolling down when pressing space
            this.open();
        }
        else if (!this.multiple) {
            const previouslySelectedOption = this.selected;
            manager.onKeydown(event);
            const selectedOption = this.selected;
            // Since the value has changed, we need to announce it ourselves.
            if (selectedOption && previouslySelectedOption !== selectedOption) {
                // We set a duration on the live announcement, because we want the live element to be
                // cleared after a while so that users can't navigate to it using the arrow keys.
                this._liveAnnouncer.announce(selectedOption.viewValue, 10000);
            }
        }
    }
    /** Handles keyboard events when the selected is open. */
    _handleOpenKeydown(event) {
        const manager = this._keyManager;
        const keyCode = event.keyCode;
        const isArrowKey = keyCode === DOWN_ARROW || keyCode === UP_ARROW;
        const isTyping = manager.isTyping();
        if (isArrowKey && event.altKey) {
            // Close the select on ALT + arrow key to match the native <select>
            event.preventDefault();
            this.close();
            // Don't do anything in this case if the user is typing,
            // because the typing sequence can include the space key.
        }
        else if (!isTyping &&
            (keyCode === ENTER || keyCode === SPACE) &&
            manager.activeItem &&
            !hasModifierKey(event)) {
            event.preventDefault();
            manager.activeItem._selectViaInteraction();
        }
        else if (!isTyping && this._multiple && keyCode === A && event.ctrlKey) {
            event.preventDefault();
            const hasDeselectedOptions = this.options.some((opt) => !opt.disabled && !opt.selected);
            this.options.forEach((option) => {
                if (!option.disabled) {
                    hasDeselectedOptions ? option.select() : option.deselect();
                }
            });
        }
        else {
            const previouslyFocusedIndex = manager.activeItemIndex;
            manager.onKeydown(event);
            if (this._multiple &&
                isArrowKey &&
                event.shiftKey &&
                manager.activeItem &&
                manager.activeItemIndex !== previouslyFocusedIndex) {
                manager.activeItem._selectViaInteraction();
            }
        }
    }
    _initializeSelection() {
        // Defer setting the value in order to avoid the "Expression
        // has changed after it was checked" errors from Angular.
        Promise.resolve().then(() => {
            if (this.ngControl) {
                this._value = this.ngControl.value;
            }
            this._setSelectionByValue(this._value);
            this.stateChanges.next();
        });
    }
    /**
     * Sets the selected option based on a value. If no option can be
     * found with the designated value, the select trigger is cleared.
     */
    _setSelectionByValue(value) {
        this._selectionModel.selected.forEach((option) => option.setInactiveStyles());
        this._selectionModel.clear();
        if (this.multiple && value) {
            if (!Array.isArray(value)) {
                throw getCubSelectNonArrayValueError();
            }
            value.forEach((currentValue) => this._selectOptionByValue(currentValue));
            this._sortValues();
        }
        else {
            const correspondingOption = this._selectOptionByValue(value);
            // Shift focus to the active item. Note that we shouldn't do this in multiple
            // mode, because we don't know what option the user interacted with last.
            if (correspondingOption) {
                this._keyManager.updateActiveItem(correspondingOption);
            }
            else if (!this.panelOpen) {
                // Otherwise reset the highlighted option. Note that we only want to do this while
                // closed, because doing it while open can shift the user's focus unnecessarily.
                this._keyManager.updateActiveItem(-1);
            }
        }
        this._changeDetectorRef.markForCheck();
    }
    /**
     * Finds and selects and option based on its value.
     * @returns Option that has the corresponding value.
     */
    _selectOptionByValue(value) {
        const correspondingOption = this.options.find((option) => {
            // Skip options that are already in the model. This allows us to handle cases
            // where the same primitive value is selected multiple times.
            if (this._selectionModel.isSelected(option)) {
                return false;
            }
            try {
                // Treat null as a special reset value.
                return option.value != null && this._compareWith(option.value, value);
            }
            catch (error) {
                return false;
            }
        });
        if (correspondingOption) {
            this._selectionModel.select(correspondingOption);
        }
        return correspondingOption;
    }
    /** Assigns a specific value to the select. Returns whether the value has changed. */
    _assignValue(newValue) {
        // Always re-assign an array, because it might have been mutated.
        if (newValue !== this._value ||
            (this._multiple && Array.isArray(newValue))) {
            if (this.options) {
                this._setSelectionByValue(newValue);
            }
            this._value = newValue;
            return true;
        }
        return false;
    }
    /** Sets up a key manager to listen to keyboard events on the overlay panel. */
    _initKeyManager() {
        this._keyManager = new ActiveDescendantKeyManager(this.options)
            .withTypeAhead(this._typeaheadDebounceInterval)
            .withVerticalOrientation()
            .withHorizontalOrientation(this._isRtl() ? 'rtl' : 'ltr')
            .withHomeAndEnd()
            .withAllowedModifierKeys(['shiftKey']);
        this._keyManager.tabOut.pipe(takeUntil(this._destroy)).subscribe(() => {
            if (this.panelOpen) {
                // Select the active item when tabbing away. This is consistent with how the native
                // select behaves. Note that we only want to do this in single selection mode.
                if (!this.multiple && this._keyManager.activeItem) {
                    this._keyManager.activeItem._selectViaInteraction();
                }
                // Restore focus to the trigger before closing. Ensures that the focus
                // position won't be lost if the user got focus into the overlay.
                this.focus();
                this.close();
            }
        });
        this._keyManager.change.pipe(takeUntil(this._destroy)).subscribe(() => {
            if (this._panelOpen && this.panel) {
                this._scrollOptionIntoView(this._keyManager.activeItemIndex || 0);
            }
            else if (!this._panelOpen &&
                !this.multiple &&
                this._keyManager.activeItem) {
                this._keyManager.activeItem._selectViaInteraction();
            }
        });
    }
    /** Drops current option subscriptions and IDs and resets from scratch. */
    _resetOptions() {
        const changedOrDestroyed = merge(this.options.changes, this._destroy);
        this.optionSelectionChanges
            .pipe(takeUntil(changedOrDestroyed))
            .subscribe((event) => {
            this._onSelect(event.source, event.isUserInput);
            if (event.isUserInput && !this.multiple && this._panelOpen) {
                this.close();
                this.focus();
            }
        });
        // Listen to changes in the internal state of the options and react accordingly.
        // Handles cases like the labels of the selected options changing.
        merge(...this.options.map((option) => option._stateChanges))
            .pipe(takeUntil(changedOrDestroyed))
            .subscribe(() => {
            this._changeDetectorRef.markForCheck();
            this.stateChanges.next();
        });
    }
    /** Invoked when an option is clicked. */
    _onSelect(option, isUserInput) {
        const wasSelected = this._selectionModel.isSelected(option);
        if (option.value == null && !this._multiple) {
            option.deselect();
            this._selectionModel.clear();
            if (this.value != null) {
                this._propagateChanges(option.value);
            }
        }
        else {
            if (wasSelected !== option.selected) {
                option.selected
                    ? this._selectionModel.select(option)
                    : this._selectionModel.deselect(option);
            }
            if (isUserInput) {
                this._keyManager.setActiveItem(option);
            }
            if (this.multiple) {
                this._sortValues();
                if (isUserInput) {
                    // In case the user selected the option with their mouse, we
                    // want to restore focus back to the trigger, in order to
                    // prevent the select keyboard controls from clashing with
                    // the ones from `cub-option`.
                    this.focus();
                }
            }
        }
        if (wasSelected !== this._selectionModel.isSelected(option)) {
            this._propagateChanges();
        }
        this.stateChanges.next();
    }
    /** Sorts the selected values in the selected based on their order in the panel. */
    _sortValues() {
        if (this.multiple) {
            const options = this.options.toArray();
            this._selectionModel.sort((a, b) => {
                return this.sortComparator
                    ? this.sortComparator(a, b, options)
                    : options.indexOf(a) - options.indexOf(b);
            });
            this.stateChanges.next();
        }
    }
    /** Emits change event to set the model value. */
    _propagateChanges(fallbackValue) {
        let valueToEmit = null;
        if (this.multiple) {
            valueToEmit = this.selected.map((option) => option.value);
        }
        else {
            valueToEmit = this.selected
                ? this.selected.value
                : fallbackValue;
        }
        this._value = valueToEmit;
        this.valueChange.emit(valueToEmit);
        this._onChange(valueToEmit);
        this.selectionChange.emit(this._getChangeEvent(valueToEmit));
        this._changeDetectorRef.markForCheck();
    }
    /**
     * Highlights the selected item. If no option is selected, it will highlight
     * the first item instead.
     */
    _highlightCorrectOption() {
        if (this._keyManager) {
            if (this.empty) {
                this._keyManager.setFirstItemActive();
            }
            else {
                this._keyManager.setActiveItem(this._selectionModel.selected[0]);
            }
        }
    }
    /** Gets the aria-labelledby of the select component trigger. */
    _getTriggerAriaLabelledby() {
        if (this.ariaLabel) {
            return null;
        }
        const labelId = this._parentFormField?._label._labelId;
        let value = (labelId ? labelId + ' ' : '') + this._valueId;
        if (this.ariaLabelledby) {
            value += ' ' + this.ariaLabelledby;
        }
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubSelectBase, deps: [{ token: i1.ViewportRuler }, { token: i0.ChangeDetectorRef }, { token: i0.NgZone }, { token: i2.ErrorStateMatcher }, { token: i0.ElementRef }, { token: i3.Directionality, optional: true }, { token: i1$1.NgForm, optional: true }, { token: i1$1.FormGroupDirective, optional: true }, { token: CUB_FORM_FIELD, optional: true }, { token: i1$1.NgControl, optional: true, self: true }, { token: 'tabindex', attribute: true }, { token: CUB_SELECT_SCROLL_STRATEGY }, { token: i5.LiveAnnouncer }, { token: CUB_SELECT_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubSelectBase, isStandalone: true, inputs: { errorStateMatcher: "errorStateMatcher", ariaLabel: ["aria-label", "ariaLabel"], ariaDescribedBy: ["aria-describedby", "ariaDescribedBy"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], panelClass: "panelClass", sortComparator: "sortComparator", placeholder: "placeholder", required: "required", multiple: "multiple", compareWith: "compareWith", value: "value", typeaheadDebounceInterval: "typeaheadDebounceInterval", id: "id" }, outputs: { openedChange: "openedChange", selectionChange: "selectionChange", valueChange: "valueChange", _openedStream: "opened", _closedStream: "closed" }, viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true }, { propertyName: "panel", first: true, predicate: ["panel"], descendants: true }, { propertyName: "_overlayDir", first: true, predicate: CubCdkConnectedOverlay, descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubSelectBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1.ViewportRuler }, { type: i0.ChangeDetectorRef }, { type: i0.NgZone }, { type: i2.ErrorStateMatcher }, { type: i0.ElementRef }, { type: i3.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i1$1.NgForm, decorators: [{
                    type: Optional
                }] }, { type: i1$1.FormGroupDirective, decorators: [{
                    type: Optional
                }] }, { type: i6.CubFormField, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_FORM_FIELD]
                }] }, { type: i1$1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_SELECT_SCROLL_STRATEGY]
                }] }, { type: i5.LiveAnnouncer }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_SELECT_CONFIG]
                }] }], propDecorators: { errorStateMatcher: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaDescribedBy: [{
                type: Input,
                args: ['aria-describedby']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], panelClass: [{
                type: Input
            }], sortComparator: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], required: [{
                type: Input
            }], multiple: [{
                type: Input
            }], compareWith: [{
                type: Input
            }], value: [{
                type: Input
            }], typeaheadDebounceInterval: [{
                type: Input
            }], id: [{
                type: Input
            }], openedChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], _openedStream: [{
                type: Output,
                args: ['opened']
            }], _closedStream: [{
                type: Output,
                args: ['closed']
            }], trigger: [{
                type: ViewChild,
                args: ['trigger']
            }], panel: [{
                type: ViewChild,
                args: ['panel']
            }], _overlayDir: [{
                type: ViewChild,
                args: [CubCdkConnectedOverlay]
            }] } });

/** Change event object that is emitted when the select value has changed. */
class CubSelectChange {
    constructor(
    /** Reference to the select that emitted the change event. */
    source, 
    /** Current value of the select that emitted the event. */
    value) {
        this.source = source;
        this.value = value;
    }
}
class _CubSelectAdvance extends _CubSelectBase {
    constructor() {
        super(...arguments);
        /** The cached font-size of the trigger element. */
        this._triggerFontSize = 0;
        /** The value of the select panel's transform-origin property. */
        this._transformOrigin = 'top';
        /**
         * The y-offset of the overlay panel in relation to the trigger's top start corner.
         * This must be adjusted to align the selected option text over the trigger text.
         * when the panel opens. Will change based on the y-position of the selected option.
         */
        this._offsetY = 0;
        this._positions = [
            {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'top',
            },
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'bottom',
            },
        ];
        /** The scroll position of the overlay panel, calculated to center the selected option. */
        this._scrollTop = 0;
    }
    ngOnInit() {
        super.ngOnInit();
        this._viewportRuler
            .change()
            .pipe(takeUntil(this._destroy))
            .subscribe(() => {
            if (this.panelOpen) {
                this._triggerRect =
                    this.trigger.nativeElement.getBoundingClientRect();
                this._changeDetectorRef.markForCheck();
            }
        });
    }
    open() {
        if (super._canOpen()) {
            super.open();
            this._triggerRect = this.trigger.nativeElement.getBoundingClientRect();
            // Note: The computed font-size will be a string pixel value (e.g. "16px").
            // `parseInt` ignores the trailing 'px' and converts this to a number.
            this._triggerFontSize = parseInt(getComputedStyle(this.trigger.nativeElement).fontSize || '0');
            this._calculateOverlayPosition();
            // Set the font size on the panel element once it exists.
            this._ngZone.onStable.pipe(take(1)).subscribe(() => {
                if (this._triggerFontSize &&
                    this._overlayDir.overlayRef &&
                    this._overlayDir.overlayRef.overlayElement) {
                    this._overlayDir.overlayRef.overlayElement.style.fontSize = `${this._triggerFontSize}px`;
                }
            });
        }
    }
    /**
     * Calculates the scroll position of the select's overlay panel.
     *
     * Attempts to center the selected option in the panel. If the option is
     * too high or too low in the panel to be scrolled to the center, it clamps the
     * scroll position to the min or max scroll positions respectively.
     */
    _calculateOverlayScroll(selectedIndex, scrollBuffer, maxScroll) {
        const itemHeight = this._getItemHeight();
        const optionOffsetFromScrollTop = itemHeight * selectedIndex;
        const halfOptionHeight = itemHeight / 2;
        // Starts at the optionOffsetFromScrollTop, which scrolls the option to the top of the
        // scroll container, then subtracts the scroll buffer to scroll the option down to
        // the center of the overlay panel. Half the option height must be re-added to the
        // scrollTop so the option is centered based on its middle, not its top edge.
        const optimalScrollPosition = optionOffsetFromScrollTop - scrollBuffer + halfOptionHeight;
        return Math.min(Math.max(0, optimalScrollPosition), maxScroll);
    }
    /** Scrolls the active option into view. */
    _scrollOptionIntoView(index) {
        const labelCount = _countGroupLabelsBeforeOption(index, this.options, this.optionGroups);
        const itemHeight = this._getItemHeight();
        if (index === 0 && labelCount === 1) {
            // If we've got one group label before the option and we're at the top option,
            // scroll the list to the top. This is better UX than scrolling the list to the
            // top of the option, because it allows the user to read the top group's label.
            this.panel.nativeElement.scrollTop = 0;
        }
        else {
            this.panel.nativeElement.scrollTop = _getOptionScrollPosition((index + labelCount) * itemHeight, itemHeight, this.panel.nativeElement.scrollTop, SELECT_PANEL_MAX_HEIGHT);
        }
    }
    _positioningSettled() {
        this._calculateOverlayOffsetX();
        this.panel.nativeElement.scrollTop = this._scrollTop;
    }
    _panelDoneAnimating(isOpen) {
        if (this.panelOpen) {
            this._scrollTop = 0;
        }
        else {
            this._overlayDir.offsetX = 0;
            this._changeDetectorRef.markForCheck();
        }
        super._panelDoneAnimating(isOpen);
    }
    _getChangeEvent(value) {
        return new CubSelectChange(this, value);
    }
    /**
     * Sets the x-offset of the overlay panel in relation to the trigger's top start corner.
     * This must be adjusted to align the selected option text over the trigger text when
     * the panel opens. Will change based on LTR or RTL text direction. Note that the offset
     * can't be calculated until the panel has been attached, because we need to know the
     * content width in order to constrain the panel within the viewport.
     */
    _calculateOverlayOffsetX() {
        const overlayRect = this._overlayDir.overlayRef.overlayElement.getBoundingClientRect();
        const viewportSize = this._viewportRuler.getViewportSize();
        const isRtl = this._isRtl();
        const paddingWidth = this.multiple
            ? SELECT_MULTIPLE_PANEL_PADDING_X + SELECT_PANEL_PADDING_X
            : SELECT_PANEL_PADDING_X * 2;
        let offsetX;
        // Adjust the offset, depending on the option padding.
        if (this.multiple) {
            offsetX = SELECT_MULTIPLE_PANEL_PADDING_X;
        }
        else if (this.disableOptionCentering) {
            offsetX = SELECT_PANEL_PADDING_X;
        }
        else {
            let selected = this._selectionModel.selected[0] || this.options.first;
            offsetX =
                selected && selected.group
                    ? SELECT_PANEL_INDENT_PADDING_X
                    : SELECT_PANEL_PADDING_X;
        }
        // Invert the offset in LTR.
        if (!isRtl) {
            offsetX *= -1;
        }
        // Determine how much the select overflows on each side.
        const leftOverflow = 0 - (overlayRect.left + offsetX - (isRtl ? paddingWidth : 0));
        const rightOverflow = overlayRect.right +
            offsetX -
            viewportSize.width +
            (isRtl ? 0 : paddingWidth);
        // If the element overflows on either side, reduce the offset to allow it to fit.
        if (leftOverflow > 0) {
            offsetX += leftOverflow + SELECT_PANEL_VIEWPORT_PADDING;
        }
        else if (rightOverflow > 0) {
            offsetX -= rightOverflow + SELECT_PANEL_VIEWPORT_PADDING;
        }
        // Set the offset directly in order to avoid having to go through change detection and
        // potentially triggering "changed after it was checked" errors. Round the value to avoid
        // blurry content in some browsers.
        this._overlayDir.offsetX = Math.round(offsetX);
        this._overlayDir.overlayRef.updatePosition();
    }
    /**
     * Calculates the y-offset of the select's overlay panel in relation to the
     * top start corner of the trigger. It has to be adjusted in order for the
     * selected option to be aligned over the trigger when the panel opens.
     */
    _calculateOverlayOffsetY(selectedIndex, scrollBuffer, maxScroll) {
        const itemHeight = this._getItemHeight();
        const optionHeightAdjustment = (itemHeight - this._triggerRect.height) / 2;
        const maxOptionsDisplayed = Math.floor(SELECT_PANEL_MAX_HEIGHT / itemHeight);
        let optionOffsetFromPanelTop;
        // Disable offset if requested by user by returning 0 as value to offset
        if (this.disableOptionCentering) {
            return 0;
        }
        if (this._scrollTop === 0) {
            optionOffsetFromPanelTop = selectedIndex * itemHeight;
        }
        else if (this._scrollTop === maxScroll) {
            const firstDisplayedIndex = this._getItemCount() - maxOptionsDisplayed;
            const selectedDisplayIndex = selectedIndex - firstDisplayedIndex;
            // The first item is partially out of the viewport. Therefore we need to calculate what
            // portion of it is shown in the viewport and account for it in our offset.
            let partialItemHeight = itemHeight -
                ((this._getItemCount() * itemHeight - SELECT_PANEL_MAX_HEIGHT) %
                    itemHeight);
            // Because the panel height is longer than the height of the options alone,
            // there is always extra padding at the top or bottom of the panel. When
            // scrolled to the very bottom, this padding is at the top of the panel and
            // must be added to the offset.
            optionOffsetFromPanelTop =
                selectedDisplayIndex * itemHeight + partialItemHeight;
        }
        else {
            // If the option was scrolled to the middle of the panel using a scroll buffer,
            // its offset will be the scroll buffer minus the half height that was added to
            // center it.
            optionOffsetFromPanelTop = scrollBuffer - itemHeight / 2;
        }
        // The final offset is the option's offset from the top, adjusted for the height difference,
        // multiplied by -1 to ensure that the overlay moves in the correct direction up the page.
        // The value is rounded to prevent some browsers from blurring the content.
        return Math.round(optionOffsetFromPanelTop * -1 - optionHeightAdjustment);
    }
    /**
     * Checks that the attempted overlay position will fit within the viewport.
     * If it will not fit, tries to adjust the scroll position and the associated
     * y-offset so the panel can open fully on-screen. If it still won't fit,
     * sets the offset back to 0 to allow the fallback position to take over.
     */
    _checkOverlayWithinViewport(maxScroll) {
        const itemHeight = this._getItemHeight();
        const viewportSize = this._viewportRuler.getViewportSize();
        const topSpaceAvailable = this._triggerRect.top - SELECT_PANEL_VIEWPORT_PADDING;
        const bottomSpaceAvailable = viewportSize.height -
            this._triggerRect.bottom -
            SELECT_PANEL_VIEWPORT_PADDING;
        const panelHeightTop = Math.abs(this._offsetY);
        const totalPanelHeight = Math.min(this._getItemCount() * itemHeight, SELECT_PANEL_MAX_HEIGHT);
        const panelHeightBottom = totalPanelHeight - panelHeightTop - this._triggerRect.height;
        if (panelHeightBottom > bottomSpaceAvailable) {
            this._adjustPanelUp(panelHeightBottom, bottomSpaceAvailable);
        }
        else if (panelHeightTop > topSpaceAvailable) {
            this._adjustPanelDown(panelHeightTop, topSpaceAvailable, maxScroll);
        }
        else {
            this._transformOrigin = this._getOriginBasedOnOption();
        }
    }
    /** Adjusts the overlay panel up to fit in the viewport. */
    _adjustPanelUp(panelHeightBottom, bottomSpaceAvailable) {
        // Browsers ignore fractional scroll offsets, so we need to round.
        const distanceBelowViewport = Math.round(panelHeightBottom - bottomSpaceAvailable);
        // Scrolls the panel up by the distance it was extending past the boundary, then
        // adjusts the offset by that amount to move the panel up into the viewport.
        this._scrollTop -= distanceBelowViewport;
        this._offsetY -= distanceBelowViewport;
        this._transformOrigin = this._getOriginBasedOnOption();
        // If the panel is scrolled to the very top, it won't be able to fit the panel
        // by scrolling, so set the offset to 0 to allow the fallback position to take
        // effect.
        if (this._scrollTop <= 0) {
            this._scrollTop = 0;
            this._offsetY = 0;
            this._transformOrigin = `50% bottom 0px`;
        }
    }
    /** Adjusts the overlay panel down to fit in the viewport. */
    _adjustPanelDown(panelHeightTop, topSpaceAvailable, maxScroll) {
        // Browsers ignore fractional scroll offsets, so we need to round.
        const distanceAboveViewport = Math.round(panelHeightTop - topSpaceAvailable);
        // Scrolls the panel down by the distance it was extending past the boundary, then
        // adjusts the offset by that amount to move the panel down into the viewport.
        this._scrollTop += distanceAboveViewport;
        this._offsetY += distanceAboveViewport;
        this._transformOrigin = this._getOriginBasedOnOption();
        // If the panel is scrolled to the very bottom, it won't be able to fit the
        // panel by scrolling, so set the offset to 0 to allow the fallback position
        // to take effect.
        if (this._scrollTop >= maxScroll) {
            this._scrollTop = maxScroll;
            this._offsetY = 0;
            this._transformOrigin = `50% top 0px`;
            return;
        }
    }
    /** Calculates the scroll position and x- and y-offsets of the overlay panel. */
    _calculateOverlayPosition() {
        const itemHeight = this._getItemHeight();
        const items = this._getItemCount();
        const panelHeight = Math.min(items * itemHeight, SELECT_PANEL_MAX_HEIGHT);
        const scrollContainerHeight = items * itemHeight;
        // The farthest the panel can be scrolled before it hits the bottom
        const maxScroll = scrollContainerHeight - panelHeight;
        // If no value is selected we open the popup to the first item.
        let selectedOptionOffset;
        if (this.empty) {
            selectedOptionOffset = 0;
        }
        else {
            selectedOptionOffset = Math.max(this.options.toArray().indexOf(this._selectionModel.selected[0]), 0);
        }
        selectedOptionOffset += _countGroupLabelsBeforeOption(selectedOptionOffset, this.options, this.optionGroups);
        // We must maintain a scroll buffer so the selected option will be scrolled to the
        // center of the overlay panel rather than the top.
        const scrollBuffer = panelHeight / 2;
        this._scrollTop = this._calculateOverlayScroll(selectedOptionOffset, scrollBuffer, maxScroll);
        this._offsetY = this._calculateOverlayOffsetY(selectedOptionOffset, scrollBuffer, maxScroll);
        this._checkOverlayWithinViewport(maxScroll);
    }
    /** Sets the transform origin point based on the selected option. */
    _getOriginBasedOnOption() {
        const itemHeight = this._getItemHeight();
        const optionHeightAdjustment = (itemHeight - this._triggerRect.height) / 2;
        const originY = Math.abs(this._offsetY) - optionHeightAdjustment + itemHeight / 2;
        return `50% ${originY}px 0px`;
    }
    /** Calculates the height of the select's options. */
    _getItemHeight() {
        return this._triggerFontSize * SELECT_ITEM_HEIGHT_EM;
    }
    /** Calculates the amount of items in the select. This includes options and group labels. */
    _getItemCount() {
        return this.options.length + this.optionGroups.length;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubSelectAdvance, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubSelectAdvance, isStandalone: true, queries: [{ propertyName: "customTrigger", first: true, predicate: CUB_SELECT_TRIGGER, descendants: true }, { propertyName: "options", predicate: CubOption, descendants: true }, { propertyName: "optionGroups", predicate: CUB_OPTION_GROUP, descendants: true }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubSelectAdvance, decorators: [{
            type: Directive
        }], propDecorators: { options: [{
                type: ContentChildren,
                args: [CubOption, { descendants: true }]
            }], optionGroups: [{
                type: ContentChildren,
                args: [CUB_OPTION_GROUP, { descendants: true }]
            }], customTrigger: [{
                type: ContentChild,
                args: [CUB_SELECT_TRIGGER]
            }] } });

/* 參考來源：
  1. https://github.com/angular/components/blob/ff787fcf654b86c30261848c74b1a6e734f7dbf8/src/material/select/select.ts
  2. https://github.com/mdlivingston/mat-select-filter/blob/master/src/lib/mat-select-filter.component.ts
*/
class CubSelect extends _CubSelectAdvance {
    get triggerValue() {
        if (this.empty) {
            return '';
        }
        if (this.multiple) {
            const selectedOptions = this._selectionModel.selected.map((option) => option.viewValue);
            if (this._isRtl()) {
                selectedOptions.reverse();
            }
            if (selectedOptions.length <= this.maxSelectedLabels) {
                return selectedOptions.join(', ');
            }
            else {
                const pattern = /{(.*?)}/;
                if (pattern.test(this.selectedItemsLabel)) {
                    const matchPattern = this.selectedItemsLabel.match(pattern);
                    if (matchPattern) {
                        return this.selectedItemsLabel.replace(matchPattern[0], selectedOptions.length + '');
                    }
                    else {
                        return this.selectedItemsLabel;
                    }
                }
                else {
                    return this.selectedItemsLabel;
                }
            }
        }
        return this._selectionModel.selected[0].viewValue;
    }
    get hasGroup() {
        return this.optionGroups && this.optionGroups.length > 0;
    }
    get isOptionContainerScroll() {
        return (this.optionContainerElementRef &&
            this.optionContainerElementRef.nativeElement.scrollHeight >
                this.optionContainerElementRef.nativeElement.clientHeight);
    }
    /** 元件數值，預設為 undefined。 */
    get value() {
        return super.value;
    }
    set value(newValue) {
        super.value = newValue;
        if (this.multiple) {
            this.updateSelectStatus();
        }
    }
    constructor(fb, renderer, viewportRuler, changeDetectorRef, ngZone, defaultErrorStateMatcher, elementRef, dir, parentForm, parentFormGroup, parentFormField, ngControl, tabIndex, scrollStrategyFactory, liveAnnouncer, defaultOptions) {
        super(viewportRuler, changeDetectorRef, ngZone, defaultErrorStateMatcher, elementRef, dir, parentForm, parentFormGroup, parentFormField, ngControl, tabIndex, scrollStrategyFactory, liveAnnouncer, defaultOptions);
        this.fb = fb;
        this.renderer = renderer;
        this.viewportRuler = viewportRuler;
        this.changeDetectorRef = changeDetectorRef;
        this.ngZone = ngZone;
        this.dir = dir;
        this.parentFormField = parentFormField;
        this.liveAnnouncer = liveAnnouncer;
        this.defaultOptions = defaultOptions;
        this.selectOptions = [];
        this.noFilterResults = false;
        this.checkboxFocus = false;
        this.isSelectAll = false;
        this.filteredActiveOptionIndex = 0;
        this.filteredItems = [];
        this.positions = [
            {
                originX: 'end',
                originY: 'bottom',
                overlayX: 'end',
                overlayY: 'top',
            },
        ];
        this.selectPanelObserver = null;
        this.isSelectAllKeydownActive = false;
        this.unsubscribe$ = new Subject();
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 外觀樣式，預設為 'outline'。 */
        this.appearance = 'outline';
        /** 元件是否啟用篩選功能，預設為不啟用。 */
        this.showFilter = false;
        /** 元件關閉下拉選單後，是否清空篩選輸入框，在啟用篩選功能時使用，預設為啟用。 */
        this.resetFilterOnHide = true;
        /** 元件全選文字，預設為 '全選'。 */
        this.selectAllLabel = '全選';
        /** 元件下拉選單是否顯示請選擇文字，預設為 true。 */
        this.showOptionPlaceholder = true;
        /** 元件下拉選單請選擇文字，預設為 '請選擇'。 */
        this.optionPlaceholder = '請選擇';
        /** 元件篩選輸入框的佔位符文字，在啟用篩選功能時使用，預設為 '請輸入關鍵字查詢'。 */
        this.filterPlaceholder = '請輸入關鍵字查詢';
        /** 元件查無資料的提示文字，在啟用篩選功能時使用，預設為 '無資料'。 */
        this.emptyFilterMessage = '無資料';
        /** 元件顯示選中選項的數量，在啟用多選功能時使用，預設為 3。 */
        this.maxSelectedLabels = 3;
        /** 元件顯示選中選項文字，在啟用多選功能時使用，預設為 '已選擇 {0} 個項目'。 */
        this.selectedItemsLabel = '已選擇 {0} 個項目';
        /** 元件顯示全選文字，在啟用多選功能時使用，預設為 '全部'。 */
        this.selectedAllItemsLabel = '全部';
        /** 元件完成清單篩選時發出通知。 */
        this.filter = new EventEmitter();
        this.searchForm = fb.group({
            searchValue: '',
        });
    }
    ngOnInit() {
        super.ngOnInit();
        this.searchForm.valueChanges
            .pipe(takeUntil(this.unsubscribe$))
            .subscribe((searchForm) => {
            this.onFilter(searchForm);
        });
        if (this.multiple) {
            this.valueChange.pipe(takeUntil(this._destroy)).subscribe((value) => {
                this.updateSelectStatus();
            });
        }
    }
    ngAfterContentInit() {
        super.ngAfterContentInit();
        this.getOptions();
        if (this.multiple) {
            this.updateSelectStatus();
        }
        this.optionElementRefList.changes
            .pipe(takeUntil(this._destroy))
            .subscribe(() => {
            this.getOptions();
            this.resetOptions();
        });
        this.optionGroupElementRefList.changes
            .pipe(takeUntil(this._destroy))
            .subscribe(() => {
            this.getOptions();
            this.resetOptions();
        });
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        if (this.selectPanelObserver) {
            this.selectPanelObserver.disconnect();
            this.selectPanelObserver = null;
        }
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    open() {
        if (super._canOpen()) {
            super.open();
            this.resetActiveOption();
            this.calculateSelectPanelPosition();
            if (!this.multiple && this.showOptionPlaceholder) {
                setTimeout(() => {
                    const optionList = this.optionElementList.toArray();
                    const optionPlaceholderElement = optionList.find((optionElement) => {
                        return (optionElement.viewValue ===
                            this.optionPlaceholderElement.viewValue &&
                            optionElement.value === this.optionPlaceholderElement.value);
                    });
                    if (!optionPlaceholderElement) {
                        this.optionElementList.reset([
                            this.optionPlaceholderElement,
                            ...this.optionElementList,
                        ]);
                        if (this.hasGroup) {
                            this.optionGroupElementList.reset([
                                this.optionGroupPlaceholderElement,
                                ...this.optionGroupElementList,
                            ]);
                        }
                    }
                }, 10);
            }
            if (!this.selectPanelObserver) {
                setTimeout(() => {
                    const selectPanelElement = this.panel.nativeElement.parentElement.parentElement;
                    this.selectPanelObserver = new MutationObserver((mutations) => {
                        mutations.forEach((mutationRecord) => {
                            this.calculateSelectPanelPosition();
                        });
                    });
                    this.selectPanelObserver.observe(selectPanelElement, {
                        attributes: true,
                        attributeFilter: ['style'],
                    });
                }, 10);
            }
            if (this.showFilter) {
                setTimeout(() => {
                    this.inputElementRef.nativeElement.focus();
                }, 10);
            }
            else {
                setTimeout(() => {
                    this.panel.nativeElement.focus();
                }, 10);
            }
        }
    }
    close() {
        super.close();
        if (this.selectPanelObserver) {
            this.selectPanelObserver.disconnect();
            this.selectPanelObserver = null;
        }
        if (this.showFilter &&
            this.resetFilterOnHide &&
            this.searchForm.value['searchValue']) {
            this.searchForm.controls['searchValue'].setValue('');
        }
        this._elementRef.nativeElement.focus();
    }
    _handleKeydown(event) {
        if (!this.disabled) {
            this.panelOpen
                ? this.handleOpenKeydown(event)
                : this.handleClosedKeydown(event);
        }
    }
    getOptions() {
        const selectOptions = [];
        if (this.hasGroup) {
            const optionGroupList = this.optionGroups.toArray();
            const optionGroupListLength = optionGroupList.length;
            for (let index = 0; index < optionGroupListLength; index++) {
                let optionGroupLabel = optionGroupList[index].label;
                let optionGroup = {
                    label: optionGroupLabel,
                    items: [],
                };
                selectOptions.push(optionGroup);
            }
            const optionList = this.options.toArray();
            const optionListLength = optionList.length;
            for (let index = 0; index < optionListLength; index++) {
                let optionLabel = optionList[index].viewValue;
                let optionValue = optionList[index].value;
                let optionDisabled = optionList[index].disabled;
                let option = {
                    label: optionLabel,
                    value: optionValue,
                    disabled: optionDisabled,
                };
                let optionGroup = selectOptions.find((optionGroup) => {
                    return optionGroup.label === optionList[index].group.label;
                });
                if (optionGroup) {
                    optionGroup.items.push(option);
                }
            }
            if (!this.multiple && this.showOptionPlaceholder) {
                const optionPlaceholder = {
                    label: '',
                    items: [
                        {
                            label: this.optionPlaceholder,
                            value: '',
                            disabled: false,
                        },
                    ],
                };
                selectOptions.splice(0, 0, optionPlaceholder);
            }
        }
        else {
            const optionList = this.options.toArray();
            const optionListLength = optionList.length;
            for (let index = 0; index < optionListLength; index++) {
                let optionLabel = optionList[index].viewValue;
                let optionValue = optionList[index].value;
                let optionDisabled = optionList[index].disabled;
                let option = {
                    label: optionLabel,
                    value: optionValue,
                    disabled: optionDisabled,
                };
                selectOptions.push(option);
            }
            if (!this.multiple && this.showOptionPlaceholder) {
                const optionPlaceholder = {
                    label: this.optionPlaceholder,
                    value: '',
                    disabled: false,
                };
                selectOptions.splice(0, 0, optionPlaceholder);
            }
        }
        this.selectOptions = selectOptions;
    }
    calculateSelectPanelPosition() {
        if (this.panelOpen) {
            setTimeout(() => {
                let selectElementRect = null;
                let selectWidth = null;
                let selectLeft = null;
                let selectTop = null;
                let selectBottom = null;
                // 取得 cub-select DOM
                const selectElement = this._elementRef.nativeElement;
                // 判斷是否父層為 cub-input-group
                const isInputGroup = selectElement.parentNode.parentNode.parentNode.tagName ===
                    'CUB-INPUT-GROUP';
                if (isInputGroup) {
                    // 取得 cub-input-group-container DOM
                    const inputGroupContainerElement = selectElement.parentElement.parentElement;
                    selectElementRect =
                        inputGroupContainerElement.getBoundingClientRect();
                }
                else {
                    selectElementRect = selectElement.getBoundingClientRect();
                }
                selectWidth = selectElementRect.width;
                selectLeft = selectElementRect.left;
                selectTop = selectElementRect.top;
                selectBottom = selectElementRect.bottom;
                // 取得 cub-cdk-overlay-pane DOM
                const selectPanelElement = this.panel.nativeElement.parentElement.parentElement;
                const selectPanelElementRect = selectPanelElement.getBoundingClientRect();
                const selectPanelHeight = selectPanelElementRect.height;
                // 取得 viewport 的寬、高
                const viewportSize = this._viewportRuler.getViewportSize();
                const viewportHeight = viewportSize.height;
                const bottomSpaceAvailable = viewportHeight - selectBottom;
                let selectPanelTopPosition = 0;
                if (selectPanelHeight > bottomSpaceAvailable) {
                    selectPanelTopPosition = selectTop - selectPanelHeight;
                }
                else {
                    selectPanelTopPosition = selectBottom;
                }
                this.renderer.setStyle(selectPanelElement, 'width', `${selectWidth}px`);
                this.renderer.setStyle(selectPanelElement, 'left', `${selectLeft}px`);
                this.renderer.setStyle(selectPanelElement, 'top', `${selectPanelTopPosition}px`);
                this.renderer.setStyle(selectPanelElement, 'transform', `translate(0, 0)`);
            }, 10);
        }
    }
    onCheckboxFocusIn() {
        this.checkboxFocus = true;
    }
    onCheckboxFocusOut() {
        this.checkboxFocus = false;
    }
    clear() {
        this.value = this.multiple ? [] : '';
        this.valueChange.emit(this.value);
        this._onChange(this.value);
        this.selectionChange.emit(this._getChangeEvent(this.value));
        this._changeDetectorRef.markForCheck();
        this.close();
    }
    updateSelectStatus() {
        if (typeof this.value === 'undefined' || this.value === null) {
            this.value = [];
        }
        const options = this.getNonDisabledOptions();
        this.isSelectAll =
            options.length > 0 &&
                options.every((option) => {
                    return this.value.includes(option['value']);
                });
    }
    selectPart() {
        if (typeof this.value === 'undefined' || this.value === null) {
            this.value = [];
        }
        const options = this.getNonDisabledOptions();
        return (!this.isSelectAll &&
            options.some((option) => {
                return this.value.includes(option['value']);
            }));
    }
    selectAll(checked) {
        this.isSelectAll = checked;
        if (checked) {
            this.value = this.getNonDisabledOptions().map((option) => {
                return option['value'];
            });
        }
        else {
            this.value = [];
        }
        this.valueChange.emit(this.value);
        this._onChange(this.value);
        this.selectionChange.emit(this._getChangeEvent(this.value));
        this._changeDetectorRef.markForCheck();
    }
    getNonDisabledOptions() {
        let options = [];
        if (this.showFilter) {
            if (!this.searchForm.value['searchValue']) {
                options = this.selectOptions;
            }
            else {
                options = this.filteredItems;
            }
            if (this.hasGroup) {
                options = options.reduce((accumulator, optionGroup) => {
                    return accumulator.concat(optionGroup.disabled ? [] : optionGroup['items']);
                }, []);
            }
        }
        else {
            options = this.options.toArray();
        }
        return options.filter((option) => {
            return !option.disabled;
        });
    }
    onFilter(searchForm) {
        if (searchForm['searchValue']) {
            if (this.hasGroup) {
                this.filteredItems = this.selectOptions
                    .map((optionGroup) => {
                    const optionGroupCopy = Object.assign({}, optionGroup);
                    optionGroupCopy['items'] = optionGroupCopy['items'].filter((option) => option['label'].toLowerCase().includes(searchForm['searchValue'].toLowerCase()));
                    return optionGroupCopy;
                })
                    .filter((optionGroup) => optionGroup['items'].length > 0);
            }
            else {
                this.filteredItems = this.selectOptions.filter((option) => option['label'].toLowerCase().includes(searchForm['searchValue'].toLowerCase()));
            }
            this.noFilterResults =
                this.filteredItems == null || this.filteredItems.length === 0;
        }
        else {
            this.filteredItems = this.selectOptions.slice();
            this.noFilterResults = false;
        }
        this.resetActiveOption();
        this.displayOption();
        this.calculateSelectPanelPosition();
        if (this.multiple) {
            this.updateSelectStatus();
        }
        this.filter.emit(this.filteredItems);
    }
    displayOption() {
        if (this.hasGroup) {
            const optionGroupList = this.selectOptions;
            const optionGroupListLength = optionGroupList.length;
            const filteredOptionGroupList = this.filteredItems;
            const optionGroupElementRefList = this.optionGroupElementRefList.toArray();
            if (!this.multiple && this.showOptionPlaceholder) {
                optionGroupElementRefList.splice(0, 0, this.optionGroupPlaceholderElementRef);
            }
            for (let index = 0; index < optionGroupListLength; index++) {
                let optionGroupResult = filteredOptionGroupList.find((optionGroup) => {
                    return optionGroup['label'] === optionGroupList[index]['label'];
                });
                if (optionGroupResult) {
                    this.renderer.setStyle(optionGroupElementRefList[index].nativeElement, 'display', 'inline');
                    const optionList = optionGroupList[index]['items'];
                    const optionListLength = optionList.length;
                    const filteredOptionList = optionGroupResult['items'];
                    const optionElementRefList = optionGroupElementRefList[index].nativeElement.querySelectorAll('.cub-option');
                    for (let index = 0; index < optionListLength; index++) {
                        let optionResult = filteredOptionList.find((option) => {
                            return option['label'] === optionList[index]['label'];
                        });
                        if (optionResult) {
                            this.renderer.setStyle(optionElementRefList[index], 'display', 'flex');
                            this.renderer.setAttribute(optionElementRefList[index], 'tabindex', '0');
                        }
                        else {
                            this.renderer.setStyle(optionElementRefList[index], 'display', 'none');
                            this.renderer.setAttribute(optionElementRefList[index], 'tabindex', '-1');
                        }
                    }
                }
                else {
                    this.renderer.setStyle(optionGroupElementRefList[index].nativeElement, 'display', 'none');
                    const optionList = optionGroupList[index]['items'];
                    const optionListLength = optionList.length;
                    const optionElementRefList = optionGroupElementRefList[index].nativeElement.querySelectorAll('.cub-option');
                    for (let index = 0; index < optionListLength; index++) {
                        this.renderer.setStyle(optionElementRefList[index], 'display', 'none');
                        this.renderer.setAttribute(optionElementRefList[index], 'tabindex', '-1');
                    }
                }
            }
        }
        else {
            const optionList = this.selectOptions;
            const optionListLength = optionList.length;
            const filteredOptionList = this.filteredItems;
            const optionElementRefList = this.optionElementRefList.toArray();
            if (!this.multiple && this.showOptionPlaceholder) {
                optionElementRefList.splice(0, 0, this.optionPlaceholderElementRef);
            }
            for (let index = 0; index < optionListLength; index++) {
                let optionResult = filteredOptionList.find((option) => {
                    return option['label'] === optionList[index]['label'];
                });
                if (optionResult) {
                    this.renderer.setStyle(optionElementRefList[index].nativeElement, 'display', 'flex');
                    this.renderer.setAttribute(optionElementRefList[index].nativeElement, 'tabindex', '0');
                }
                else {
                    this.renderer.setStyle(optionElementRefList[index].nativeElement, 'display', 'none');
                    this.renderer.setAttribute(optionElementRefList[index].nativeElement, 'tabindex', '-1');
                }
            }
        }
    }
    resetActiveOption() {
        const manager = this._keyManager;
        manager.setActiveItem(-1);
        this.filteredActiveOptionIndex = -1;
    }
    resetOptions() {
        setTimeout(() => {
            if (this.showFilter && this.searchForm.value['searchValue']) {
                this.onFilter(this.searchForm.value);
            }
        }, 10);
    }
    handleSelectAllClick() {
        this.isSelectAllKeydownActive = false;
        this.selectAll(!this.isSelectAll);
    }
    handleOpenKeydown(event) {
        this.isSelectAllKeydownActive = true;
        const manager = this._keyManager;
        const keyCode = event.keyCode;
        const isArrowKey = keyCode === DOWN_ARROW || keyCode === UP_ARROW;
        const isTabKey = keyCode === TAB;
        const isTyping = manager.isTyping();
        if (isArrowKey && event.altKey) {
            event.preventDefault();
            this.close();
        }
        else if (!isTyping &&
            (keyCode === ENTER || keyCode === SPACE) &&
            manager.activeItem &&
            !hasModifierKey(event)) {
            event.preventDefault();
            if (this.showFilter && this.searchForm.value['searchValue']) {
                const options = this.options.toArray();
                const currentIndex = manager.activeItemIndex;
                const style = getComputedStyle(options[currentIndex]._getHostElement());
                const display = style.display;
                const pointerEvents = style.pointerEvents;
                if (display === 'none' || pointerEvents === 'none') {
                    return;
                }
            }
            manager.activeItem._selectViaInteraction();
        }
        else if (this.checkboxFocus && (keyCode === ENTER || keyCode === SPACE)) {
            event.preventDefault();
            this.selectAll(!this.isSelectAll);
        }
        else if ((isArrowKey || isTabKey) &&
            this.showFilter &&
            this.searchForm.value['searchValue']) {
            event.preventDefault();
            const options = this.options.toArray();
            const optionsLength = options.length;
            const isInputFocus = this.inputElementRef.nativeElement === document.activeElement;
            let currentIndex = -1;
            if (keyCode === DOWN_ARROW || (!event.shiftKey && isTabKey)) {
                if (!this.multiple) {
                    if (this.showOptionPlaceholder) {
                        const optionPlaceholderElement = this.optionPlaceholderElementRef.nativeElement;
                        const optionPlaceholderStyle = getComputedStyle(optionPlaceholderElement);
                        const optionPlaceholderDisplay = optionPlaceholderStyle.display;
                        const optionPlaceholderPointerEvents = optionPlaceholderStyle.pointerEvents;
                        const isOptionPlaceholderActive = optionPlaceholderElement === document.activeElement;
                        if (!isOptionPlaceholderActive &&
                            optionPlaceholderDisplay !== 'none' &&
                            optionPlaceholderPointerEvents !== 'none' &&
                            manager.activeItemIndex === -1) {
                            optionPlaceholderElement.focus();
                            return;
                        }
                        else {
                            if (isTabKey) {
                                manager.setNextItemActive();
                            }
                            else {
                                manager.onKeydown(event);
                            }
                        }
                    }
                    else {
                        if (isTabKey) {
                            manager.setNextItemActive();
                        }
                        else {
                            manager.onKeydown(event);
                        }
                    }
                }
                else {
                    if (!this.checkboxFocus && manager.activeItemIndex === -1) {
                        this.checkbox.focus();
                        return;
                    }
                    else {
                        if (isTabKey) {
                            manager.setNextItemActive();
                        }
                        else {
                            manager.onKeydown(event);
                        }
                    }
                }
                currentIndex = manager.activeItem ? manager.activeItemIndex : 0;
                for (let index = currentIndex; index < optionsLength; index++) {
                    let style = getComputedStyle(options[index]._getHostElement());
                    let display = style.display;
                    let pointerEvents = style.pointerEvents;
                    if (display !== 'none' && pointerEvents !== 'none') {
                        manager.setActiveItem(index);
                        this.filteredActiveOptionIndex = index;
                        break;
                    }
                    else if (index === optionsLength - 1) {
                        manager.setActiveItem(this.filteredActiveOptionIndex);
                    }
                }
                if (manager.activeItemIndex !== -1) {
                    this.panel.nativeElement.focus();
                }
            }
            else if (keyCode === UP_ARROW || (event.shiftKey && isTabKey)) {
                if (isInputFocus) {
                    return;
                }
                if (!this.multiple) {
                    if ((this.showOptionPlaceholder &&
                        this.optionPlaceholderElementRef.nativeElement ===
                            document.activeElement &&
                        this.filteredActiveOptionIndex === -1) ||
                        this.filteredActiveOptionIndex === 0) {
                        this.inputElementRef.nativeElement.focus();
                        manager.setActiveItem(-1);
                        this.filteredActiveOptionIndex = -1;
                        return;
                    }
                }
                else {
                    if (this.checkboxFocus && this.filteredActiveOptionIndex === -1) {
                        this.inputElementRef.nativeElement.focus();
                        manager.setActiveItem(-1);
                        return;
                    }
                    else if (!this.checkboxFocus &&
                        this.filteredActiveOptionIndex === 0) {
                        this.checkbox.focus();
                        manager.setActiveItem(-1);
                        this.filteredActiveOptionIndex = -1;
                        return;
                    }
                }
                if (isTabKey) {
                    manager.setPreviousItemActive();
                }
                else {
                    manager.onKeydown(event);
                }
                currentIndex = manager.activeItem ? manager.activeItemIndex : 0;
                for (let index = currentIndex; index >= 0; index--) {
                    let style = getComputedStyle(options[index]._getHostElement());
                    let display = style.display;
                    let pointerEvents = style.pointerEvents;
                    if (display !== 'none' && pointerEvents !== 'none') {
                        manager.setActiveItem(index);
                        this.filteredActiveOptionIndex = index;
                        break;
                    }
                    else if (index === 0) {
                        if (!this.multiple) {
                            if (this.showOptionPlaceholder) {
                                const optionPlaceholderElement = this.optionPlaceholderElementRef.nativeElement;
                                const optionPlaceholderStyle = getComputedStyle(optionPlaceholderElement);
                                const optionPlaceholderDisplay = optionPlaceholderStyle.display;
                                const optionPlaceholderPointerEvents = optionPlaceholderStyle.pointerEvents;
                                const isOptionPlaceholderActive = optionPlaceholderElement === document.activeElement;
                                if (!isOptionPlaceholderActive &&
                                    optionPlaceholderDisplay !== 'none' &&
                                    optionPlaceholderPointerEvents !== 'none') {
                                    optionPlaceholderElement.focus();
                                }
                                else {
                                    this.inputElementRef.nativeElement.focus();
                                }
                            }
                            else {
                                this.inputElementRef.nativeElement.focus();
                            }
                        }
                        else {
                            if (!this.checkboxFocus) {
                                this.checkbox.focus();
                            }
                            else {
                                this.inputElementRef.nativeElement.focus();
                            }
                        }
                        manager.setActiveItem(-1);
                        this.filteredActiveOptionIndex = -1;
                    }
                }
            }
        }
        else if ((isArrowKey || isTabKey) &&
            this.showFilter &&
            !this.searchForm.value['searchValue']) {
            event.preventDefault();
            const isInputFocus = this.inputElementRef.nativeElement === document.activeElement;
            if (keyCode === DOWN_ARROW || (!event.shiftKey && isTabKey)) {
                if (!this.multiple) {
                    if (this.showOptionPlaceholder) {
                        const optionPlaceholderElement = this.optionPlaceholderElementRef.nativeElement;
                        const isOptionPlaceholderActive = optionPlaceholderElement === document.activeElement;
                        if (!isOptionPlaceholderActive && manager.activeItemIndex === -1) {
                            optionPlaceholderElement.focus();
                            return;
                        }
                        else {
                            if (isTabKey) {
                                manager.setNextItemActive();
                            }
                            else {
                                manager.onKeydown(event);
                            }
                            this.panel.nativeElement.focus();
                        }
                    }
                    else {
                        if (isTabKey) {
                            manager.setNextItemActive();
                        }
                        else {
                            manager.onKeydown(event);
                        }
                        this.panel.nativeElement.focus();
                    }
                }
                else {
                    if (!this.checkboxFocus && manager.activeItemIndex === -1) {
                        this.checkbox.focus();
                        return;
                    }
                    else {
                        if (isTabKey) {
                            manager.setNextItemActive();
                        }
                        else {
                            manager.onKeydown(event);
                        }
                        this.panel.nativeElement.focus();
                    }
                }
            }
            else if (keyCode === UP_ARROW || (event.shiftKey && isTabKey)) {
                if (isInputFocus) {
                    return;
                }
                if (!this.multiple) {
                    if (manager.activeItemIndex === 0) {
                        if (isTabKey) {
                            manager.setPreviousItemActive();
                        }
                        else {
                            manager.onKeydown(event);
                        }
                        manager.setActiveItem(-1);
                        if (this.showOptionPlaceholder) {
                            this.optionPlaceholderElementRef.nativeElement.focus();
                        }
                        else {
                            this.inputElementRef.nativeElement.focus();
                        }
                    }
                    else if (this.showOptionPlaceholder &&
                        this.optionPlaceholderElementRef.nativeElement ===
                            document.activeElement &&
                        manager.activeItemIndex === -1) {
                        this.inputElementRef.nativeElement.focus();
                        return;
                    }
                }
                else {
                    if (this.checkboxFocus && manager.activeItemIndex === -1) {
                        this.inputElementRef.nativeElement.focus();
                        manager.setActiveItem(-1);
                        return;
                    }
                    else if (!this.checkboxFocus && manager.activeItemIndex === 0) {
                        this.checkbox.focus();
                        manager.setActiveItem(-1);
                        return;
                    }
                }
                if (isTabKey) {
                    manager.setPreviousItemActive();
                }
                else {
                    manager.onKeydown(event);
                }
            }
        }
        else if (isTabKey) {
            event.preventDefault();
            let isActiveElement = false;
            let focusElement = null;
            if (!this.multiple) {
                if (!this.showOptionPlaceholder) {
                    if (!event.shiftKey) {
                        manager.setNextItemActive();
                    }
                    else {
                        manager.setPreviousItemActive();
                    }
                    if (manager.activeItem) {
                        manager.activeItem.isKeydownActive = true;
                    }
                    return;
                }
                isActiveElement =
                    this.optionPlaceholderElementRef.nativeElement ===
                        document.activeElement;
                focusElement = this.optionPlaceholderElementRef.nativeElement;
            }
            else {
                isActiveElement = this.checkboxFocus;
                focusElement = this.checkbox;
            }
            if (isActiveElement && manager.activeItemIndex === -1) {
                if (!event.shiftKey) {
                    manager.setNextItemActive();
                    this.panel.nativeElement.focus();
                }
            }
            else if ((!event.shiftKey && manager.activeItemIndex === -1) ||
                (event.shiftKey && manager.activeItemIndex === 0)) {
                manager.setActiveItem(-1);
                focusElement.focus();
            }
            else {
                if (!event.shiftKey) {
                    manager.setNextItemActive();
                }
                else {
                    manager.setPreviousItemActive();
                }
            }
        }
        else {
            let isActiveElement = false;
            let focusElement = null;
            if (!this.multiple) {
                if (!this.showOptionPlaceholder) {
                    manager.onKeydown(event);
                    if (manager.activeItem) {
                        manager.activeItem.isKeydownActive = true;
                    }
                    return;
                }
                isActiveElement =
                    this.optionPlaceholderElementRef.nativeElement ===
                        document.activeElement;
                focusElement = this.optionPlaceholderElementRef.nativeElement;
            }
            else {
                isActiveElement = this.checkboxFocus;
                focusElement = this.checkbox;
            }
            if (isActiveElement && manager.activeItemIndex === -1) {
                if (keyCode === DOWN_ARROW) {
                    manager.onKeydown(event);
                    this.panel.nativeElement.focus();
                }
            }
            else if ((keyCode === DOWN_ARROW && manager.activeItemIndex === -1) ||
                (keyCode === UP_ARROW && manager.activeItemIndex === 0)) {
                manager.onKeydown(event);
                manager.setActiveItem(-1);
                focusElement.focus();
            }
            else {
                manager.onKeydown(event);
            }
        }
        if (manager.activeItem) {
            manager.activeItem.isKeydownActive = true;
        }
    }
    handleClosedKeydown(event) {
        const keyCode = event.keyCode;
        const isArrowKey = keyCode === DOWN_ARROW ||
            keyCode === UP_ARROW ||
            keyCode === LEFT_ARROW ||
            keyCode === RIGHT_ARROW;
        const isOpenKey = keyCode === ENTER || keyCode === SPACE;
        const manager = this._keyManager;
        if ((!manager.isTyping() && isOpenKey && !hasModifierKey(event)) ||
            isArrowKey) {
            event.preventDefault();
            this.open();
        }
    }
    handleFilterKeydown(event) {
        if ((event.key && event.key.length === 1) ||
            (event.keyCode >= A && event.keyCode <= Z) ||
            (event.keyCode >= ZERO && event.keyCode <= NINE) ||
            event.keyCode === SPACE) {
            event.stopPropagation();
        }
    }
    handlePlaceholderkeydown(event) {
        if (event.keyCode === ENTER || event.keyCode === SPACE) {
            this.clear();
            event.stopPropagation();
        }
    }
    _scrollOptionIntoView(index) {
        if (!this.multiple && this.showOptionPlaceholder) {
            index++;
        }
        // 取得 cub-option-container DOM
        const optionContainerElement = this.panel.nativeElement.querySelector('.cub-option-container');
        const optionContainerElementRect = optionContainerElement.getBoundingClientRect();
        const optionContainerHeight = optionContainerElementRect.height;
        const options = this.optionElementList;
        const optionGroups = this.optionGroupElementList;
        const itemOffsetTop = options.get(index)?._getHostElement().offsetTop;
        const itemOffsetHeight = options.get(index)?._getHostElement().offsetHeight;
        const labelCount = _countGroupLabelsBeforeOption(index, options, optionGroups);
        if (index === 0 && labelCount === 1) {
            optionContainerElement.scrollTop = 0;
        }
        else {
            optionContainerElement.scrollTop = _getOptionScrollPosition(itemOffsetTop, itemOffsetHeight, optionContainerElement.scrollTop, optionContainerHeight);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelect, deps: [{ token: i1$1.FormBuilder }, { token: i0.Renderer2 }, { token: i1.ViewportRuler }, { token: i0.ChangeDetectorRef }, { token: i0.NgZone }, { token: i2.ErrorStateMatcher }, { token: i0.ElementRef }, { token: i3.Directionality, optional: true }, { token: i1$1.NgForm, optional: true }, { token: i1$1.FormGroupDirective, optional: true }, { token: CUB_FORM_FIELD, optional: true }, { token: i1$1.NgControl, optional: true, self: true }, { token: 'tabindex', attribute: true }, { token: CUB_SELECT_SCROLL_STRATEGY }, { token: i5.LiveAnnouncer }, { token: CUB_SELECT_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubSelect, isStandalone: true, selector: "cub-select", inputs: { disabled: "disabled", disableRipple: "disableRipple", tabIndex: "tabIndex", value: "value", size: "size", appearance: "appearance", showFilter: ["filter", "showFilter"], resetFilterOnHide: "resetFilterOnHide", selectAllLabel: "selectAllLabel", showOptionPlaceholder: "showOptionPlaceholder", optionPlaceholder: "optionPlaceholder", filterPlaceholder: "filterPlaceholder", emptyFilterMessage: "emptyFilterMessage", maxSelectedLabels: "maxSelectedLabels", selectedItemsLabel: "selectedItemsLabel", selectedAllItemsLabel: "selectedAllItemsLabel" }, outputs: { filter: "filter" }, host: { attributes: { "role": "combobox", "aria-autocomplete": "none", "aria-haspopup": "true" }, listeners: { "keydown": "_handleKeydown($event)", "focus": "_onFocus()", "blur": "_onBlur()" }, properties: { "class.cub-select-expanded": "panelOpen", "class.cub-select-invalid": "errorState", "class.cub-select-required": "required", "class.cub-select-empty": "empty", "class.cub-select-multiple": "multiple", "class.cub-select-focused": "focused", "class.cub-select-outline": "appearance === \"outline\"", "class.cub-select-borderless": "appearance === \"borderless\"", "class.cub-select-small": "size === \"small\"", "class.cub-disabled": "disabled", "attr.id": "id", "attr.tabindex": "tabIndex", "attr.aria-controls": "panelOpen ? id + \"-panel\" : null", "attr.aria-expanded": "panelOpen", "attr.aria-label": "ariaLabel || null", "attr.aria-required": "required.toString()", "attr.aria-disabled": "disabled.toString()", "attr.aria-invalid": "errorState", "attr.aria-activedescendant": "_getAriaActiveDescendant()" }, classAttribute: "cub-select" }, providers: [
            {
                provide: CubFormFieldControl,
                useExisting: CubSelect,
            },
            {
                provide: CUB_OPTION_PARENT,
                useExisting: CubSelect,
            },
        ], queries: [{ propertyName: "optionElementRefList", predicate: CubOption, read: ElementRef }, { propertyName: "optionGroupElementRefList", predicate: CUB_OPTION_GROUP, read: ElementRef }, { propertyName: "optionElementList", predicate: CubOption, descendants: true }, { propertyName: "optionGroupElementList", predicate: CUB_OPTION_GROUP, descendants: true }], viewQueries: [{ propertyName: "checkbox", first: true, predicate: ["checkbox"], descendants: true }, { propertyName: "inputElementRef", first: true, predicate: ["inputElementRef"], descendants: true }, { propertyName: "optionContainerElementRef", first: true, predicate: ["optionContainerElementRef"], descendants: true }, { propertyName: "optionPlaceholderElementRef", first: true, predicate: ["optionPlaceholderElementRef"], descendants: true, read: ElementRef }, { propertyName: "optionGroupPlaceholderElementRef", first: true, predicate: ["optionGroupPlaceholderElementRef"], descendants: true, read: ElementRef }, { propertyName: "optionPlaceholderElement", first: true, predicate: ["optionPlaceholderElementRef"], descendants: true }, { propertyName: "optionGroupPlaceholderElement", first: true, predicate: ["optionGroupPlaceholderElementRef"], descendants: true }], exportAs: ["cubSelect"], usesInheritance: true, ngImport: i0, template: "<div\n  cub-cdk-overlay-origin\n  [attr.aria-owns]=\"panelOpen ? id + '-panel' : null\"\n  class=\"cub-select-trigger\"\n  (click)=\"toggle()\"\n  #origin=\"cubCdkOverlayOrigin\"\n  #trigger\n>\n  <div class=\"cub-select-value\" [ngSwitch]=\"empty\" [attr.id]=\"_valueId\">\n    <span\n      class=\"cub-select-placeholder cub-select-min-line\"\n      *ngSwitchCase=\"true\"\n    >\n      {{ placeholder }}\n    </span>\n    <span\n      class=\"cub-select-value-text\"\n      *ngSwitchCase=\"false\"\n      [ngSwitch]=\"!!customTrigger\"\n    >\n      <span class=\"cub-select-min-line\" *ngSwitchDefault>\n        <ng-container *ngIf=\"multiple && isSelectAll; else nonSelectAll\">\n          {{ selectedAllItemsLabel }}\n        </ng-container>\n        <ng-template #nonSelectAll> {{ triggerValue }} </ng-template>\n      </span>\n      <ng-content select=\"cub-select-trigger\" *ngSwitchCase=\"true\"></ng-content>\n    </span>\n  </div>\n\n  <div class=\"cub-select-arrow\">\n    <span class=\"cub-icon-chevron-down\"></span>\n  </div>\n</div>\n\n<ng-template\n  cub-cdk-connected-overlay\n  cubCdkConnectedOverlayHasBackdrop\n  cubCdkConnectedOverlayBackdropClass=\"cub-cdk-overlay-transparent-backdrop\"\n  cubCdkConnectedOverlayPanelClass=\"cub-select-panel-container\"\n  [cubCdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\n  [cubCdkConnectedOverlayOrigin]=\"origin\"\n  [cubCdkConnectedOverlayOpen]=\"panelOpen\"\n  [cubCdkConnectedOverlayPositions]=\"positions\"\n  (backdropClick)=\"close()\"\n  (detach)=\"close()\"\n>\n  <div class=\"cub-select-panel-wrap\">\n    <div\n      #panel\n      role=\"listbox\"\n      tabindex=\"-1\"\n      class=\"cub-select-panel\"\n      [class.cub-select-panel-multiple]=\"multiple\"\n      [class.cub-select-panel-small]=\"size === 'small'\"\n      [ngClass]=\"panelClass\"\n      [attr.id]=\"id + '-panel'\"\n      [attr.aria-multiselectable]=\"multiple\"\n      [attr.aria-label]=\"ariaLabel || null\"\n      [attr.aria-labelledby]=\"_getPanelAriaLabelledby()\"\n      [@transformPanel]=\"multiple ? 'showing-multiple' : 'showing'\"\n      (@transformPanel.done)=\"_panelDoneAnimatingStream.next($event.toState)\"\n      [style.transformOrigin]=\"_transformOrigin\"\n      (keydown)=\"_handleKeydown($event)\"\n    >\n      <div *ngIf=\"showFilter || multiple\" class=\"cub-select-panel-header\">\n        <div\n          *ngIf=\"showFilter\"\n          class=\"cub-filter-input\"\n          [formGroup]=\"searchForm\"\n        >\n          <cub-form-field>\n            <input\n              #inputElementRef\n              cubInput\n              [size]=\"size\"\n              [placeholder]=\"filterPlaceholder\"\n              formControlName=\"searchValue\"\n              (keydown)=\"handleFilterKeydown($event)\"\n            />\n          </cub-form-field>\n        </div>\n\n        <div\n          *ngIf=\"multiple && !noFilterResults\"\n          class=\"cub-option-select-all\"\n          [class.cub-padding-scroll]=\"isOptionContainerScroll\"\n        >\n          <div\n            #optionSelectAll\n            class=\"cub-option cub-option-multiple\"\n            [class.cub-option-small]=\"size === 'small'\"\n            [class.cub-active]=\"checkboxFocus && isSelectAllKeydownActive\"\n            [class.cub-selected]=\"isSelectAll\"\n            (click)=\"handleSelectAllClick()\"\n          >\n            <cub-checkbox\n              #checkbox\n              [size]=\"size\"\n              [checked]=\"isSelectAll\"\n              [indeterminate]=\"selectPart()\"\n              (focusin)=\"onCheckboxFocusIn()\"\n              (focusout)=\"onCheckboxFocusOut()\"\n              (change)=\"handleSelectAllClick()\"\n            ></cub-checkbox>\n\n            <span class=\"cub-option-text\">\n              {{ selectAllLabel }}\n            </span>\n\n            <div\n              cubRipple\n              cubRippleClass=\"cub-option-ripple\"\n              [cubRippleTrigger]=\"optionSelectAll\"\n              [cubRippleDisabled]=\"disableRipple\"\n            ></div>\n\n            <span\n              class=\"cub-persistent-ripple cub-option-persistent-ripple\"\n            ></span>\n          </div>\n        </div>\n      </div>\n\n      <div\n        #optionContainerElementRef\n        class=\"cub-option-container\"\n        [class.cub-option-container-margin]=\"multiple && hasGroup\"\n      >\n        <div *ngIf=\"noFilterResults\" class=\"cub-filter-empty-message\">\n          {{ emptyFilterMessage }}\n        </div>\n\n        <ng-container *ngIf=\"!multiple && showOptionPlaceholder\">\n          <cub-option-group\n            *ngIf=\"hasGroup\"\n            #optionGroupPlaceholderElementRef\n            class=\"cub-option-group-placeholder\"\n            label=\"\"\n            [size]=\"size\"\n          >\n            <cub-option\n              #optionPlaceholderElementRef\n              class=\"cub-option-placeholder\"\n              value=\"\"\n              [size]=\"size\"\n              (click)=\"clear()\"\n              (keydown)=\"handlePlaceholderkeydown($event)\"\n            >\n              {{ optionPlaceholder }}\n            </cub-option>\n          </cub-option-group>\n\n          <cub-option\n            *ngIf=\"!hasGroup\"\n            #optionPlaceholderElementRef\n            class=\"cub-option-placeholder\"\n            value=\"\"\n            [size]=\"size\"\n            (click)=\"clear()\"\n            (keydown)=\"handlePlaceholderkeydown($event)\"\n          >\n            {{ optionPlaceholder }}\n          </cub-option>\n        </ng-container>\n\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: CubCdkOverlayOrigin, selector: "[cub-cdk-overlay-origin], [overlay-origin], [cubCdkOverlayOrigin]", exportAs: ["cubCdkOverlayOrigin"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: NgSwitchDefault, selector: "[ngSwitchDefault]" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: CubCdkConnectedOverlay, selector: "[cub-cdk-connected-overlay], [connected-overlay], [cubCdkConnectedOverlay]", inputs: ["cubCdkConnectedOverlayOrigin", "cubCdkConnectedOverlayPositions", "cubCdkConnectedOverlayPositionStrategy", "cubCdkConnectedOverlayOffsetX", "cubCdkConnectedOverlayOffsetY", "cubCdkConnectedOverlayWidth", "cubCdkConnectedOverlayHeight", "cubCdkConnectedOverlayMinWidth", "cubCdkConnectedOverlayMinHeight", "cubCdkConnectedOverlayBackdropClass", "cubCdkConnectedOverlayPanelClass", "cubCdkConnectedOverlayViewportMargin", "cubCdkConnectedOverlayScrollStrategy", "cubCdkConnectedOverlayOpen", "cubCdkConnectedOverlayDisableClose", "cubCdkConnectedOverlayTransformOriginOn", "cubCdkConnectedOverlayHasBackdrop", "cubCdkConnectedOverlayLockPosition", "cubCdkConnectedOverlayFlexibleDimensions", "cubCdkConnectedOverlayGrowAfterOpen", "cubCdkConnectedOverlayPush"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cubCdkConnectedOverlay"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: CubFormField, selector: "cub-form-field", inputs: ["invalid", "orientation", "size"], exportAs: ["cubFormField"] }, { kind: "directive", type: CubInput, selector: "input[cubInput], textarea[cubInput], select[cubNativeControl],      input[cubNativeControl], textarea[cubNativeControl]", inputs: ["size", "appearance", "rows", "title", "autocomplete", "disabled", "id", "placeholder", "showClear", "style", "class", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], outputs: ["clear"], exportAs: ["cubInput"] }, { kind: "component", type: CubCheckbox, selector: "cub-checkbox", inputs: ["disableRipple", "tabIndex", "size"], exportAs: ["cubCheckbox"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "component", type: CubOptionGroup, selector: "cub-option-group", inputs: ["disabled"], exportAs: ["cubOptionGroup"] }, { kind: "component", type: CubOption, selector: "cub-option", exportAs: ["cubOption"] }], animations: [
            cubSelectAnimations.transformPanelWrap,
            cubSelectAnimations.transformPanel,
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelect, decorators: [{
            type: Component,
            args: [{ selector: 'cub-select', exportAs: 'cubSelect', inputs: ['disabled', 'disableRipple', 'tabIndex'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        role: 'combobox',
                        class: 'cub-select',
                        '[class.cub-select-expanded]': 'panelOpen',
                        '[class.cub-select-invalid]': 'errorState',
                        '[class.cub-select-required]': 'required',
                        '[class.cub-select-empty]': 'empty',
                        '[class.cub-select-multiple]': 'multiple',
                        '[class.cub-select-focused]': 'focused',
                        '[class.cub-select-outline]': 'appearance === "outline"',
                        '[class.cub-select-borderless]': 'appearance === "borderless"',
                        '[class.cub-select-small]': 'size === "small"',
                        '[class.cub-disabled]': 'disabled',
                        '[attr.id]': 'id',
                        '[attr.tabindex]': 'tabIndex',
                        '[attr.aria-controls]': 'panelOpen ? id + "-panel" : null',
                        '[attr.aria-expanded]': 'panelOpen',
                        '[attr.aria-label]': 'ariaLabel || null',
                        '[attr.aria-required]': 'required.toString()',
                        '[attr.aria-disabled]': 'disabled.toString()',
                        '[attr.aria-invalid]': 'errorState',
                        '[attr.aria-activedescendant]': '_getAriaActiveDescendant()',
                        'aria-autocomplete': 'none',
                        'aria-haspopup': 'true',
                        '(keydown)': '_handleKeydown($event)',
                        '(focus)': '_onFocus()',
                        '(blur)': '_onBlur()',
                    }, animations: [
                        cubSelectAnimations.transformPanelWrap,
                        cubSelectAnimations.transformPanel,
                    ], providers: [
                        {
                            provide: CubFormFieldControl,
                            useExisting: CubSelect,
                        },
                        {
                            provide: CUB_OPTION_PARENT,
                            useExisting: CubSelect,
                        },
                    ], imports: [
                        ReactiveFormsModule,
                        CubCdkOverlayOrigin,
                        NgSwitch,
                        NgSwitchCase,
                        NgSwitchDefault,
                        NgIf,
                        CubCdkConnectedOverlay,
                        NgClass,
                        CubFormField,
                        CubInput,
                        CubCheckbox,
                        CubRipple,
                        CubOptionGroup,
                        CubOption,
                    ], template: "<div\n  cub-cdk-overlay-origin\n  [attr.aria-owns]=\"panelOpen ? id + '-panel' : null\"\n  class=\"cub-select-trigger\"\n  (click)=\"toggle()\"\n  #origin=\"cubCdkOverlayOrigin\"\n  #trigger\n>\n  <div class=\"cub-select-value\" [ngSwitch]=\"empty\" [attr.id]=\"_valueId\">\n    <span\n      class=\"cub-select-placeholder cub-select-min-line\"\n      *ngSwitchCase=\"true\"\n    >\n      {{ placeholder }}\n    </span>\n    <span\n      class=\"cub-select-value-text\"\n      *ngSwitchCase=\"false\"\n      [ngSwitch]=\"!!customTrigger\"\n    >\n      <span class=\"cub-select-min-line\" *ngSwitchDefault>\n        <ng-container *ngIf=\"multiple && isSelectAll; else nonSelectAll\">\n          {{ selectedAllItemsLabel }}\n        </ng-container>\n        <ng-template #nonSelectAll> {{ triggerValue }} </ng-template>\n      </span>\n      <ng-content select=\"cub-select-trigger\" *ngSwitchCase=\"true\"></ng-content>\n    </span>\n  </div>\n\n  <div class=\"cub-select-arrow\">\n    <span class=\"cub-icon-chevron-down\"></span>\n  </div>\n</div>\n\n<ng-template\n  cub-cdk-connected-overlay\n  cubCdkConnectedOverlayHasBackdrop\n  cubCdkConnectedOverlayBackdropClass=\"cub-cdk-overlay-transparent-backdrop\"\n  cubCdkConnectedOverlayPanelClass=\"cub-select-panel-container\"\n  [cubCdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\n  [cubCdkConnectedOverlayOrigin]=\"origin\"\n  [cubCdkConnectedOverlayOpen]=\"panelOpen\"\n  [cubCdkConnectedOverlayPositions]=\"positions\"\n  (backdropClick)=\"close()\"\n  (detach)=\"close()\"\n>\n  <div class=\"cub-select-panel-wrap\">\n    <div\n      #panel\n      role=\"listbox\"\n      tabindex=\"-1\"\n      class=\"cub-select-panel\"\n      [class.cub-select-panel-multiple]=\"multiple\"\n      [class.cub-select-panel-small]=\"size === 'small'\"\n      [ngClass]=\"panelClass\"\n      [attr.id]=\"id + '-panel'\"\n      [attr.aria-multiselectable]=\"multiple\"\n      [attr.aria-label]=\"ariaLabel || null\"\n      [attr.aria-labelledby]=\"_getPanelAriaLabelledby()\"\n      [@transformPanel]=\"multiple ? 'showing-multiple' : 'showing'\"\n      (@transformPanel.done)=\"_panelDoneAnimatingStream.next($event.toState)\"\n      [style.transformOrigin]=\"_transformOrigin\"\n      (keydown)=\"_handleKeydown($event)\"\n    >\n      <div *ngIf=\"showFilter || multiple\" class=\"cub-select-panel-header\">\n        <div\n          *ngIf=\"showFilter\"\n          class=\"cub-filter-input\"\n          [formGroup]=\"searchForm\"\n        >\n          <cub-form-field>\n            <input\n              #inputElementRef\n              cubInput\n              [size]=\"size\"\n              [placeholder]=\"filterPlaceholder\"\n              formControlName=\"searchValue\"\n              (keydown)=\"handleFilterKeydown($event)\"\n            />\n          </cub-form-field>\n        </div>\n\n        <div\n          *ngIf=\"multiple && !noFilterResults\"\n          class=\"cub-option-select-all\"\n          [class.cub-padding-scroll]=\"isOptionContainerScroll\"\n        >\n          <div\n            #optionSelectAll\n            class=\"cub-option cub-option-multiple\"\n            [class.cub-option-small]=\"size === 'small'\"\n            [class.cub-active]=\"checkboxFocus && isSelectAllKeydownActive\"\n            [class.cub-selected]=\"isSelectAll\"\n            (click)=\"handleSelectAllClick()\"\n          >\n            <cub-checkbox\n              #checkbox\n              [size]=\"size\"\n              [checked]=\"isSelectAll\"\n              [indeterminate]=\"selectPart()\"\n              (focusin)=\"onCheckboxFocusIn()\"\n              (focusout)=\"onCheckboxFocusOut()\"\n              (change)=\"handleSelectAllClick()\"\n            ></cub-checkbox>\n\n            <span class=\"cub-option-text\">\n              {{ selectAllLabel }}\n            </span>\n\n            <div\n              cubRipple\n              cubRippleClass=\"cub-option-ripple\"\n              [cubRippleTrigger]=\"optionSelectAll\"\n              [cubRippleDisabled]=\"disableRipple\"\n            ></div>\n\n            <span\n              class=\"cub-persistent-ripple cub-option-persistent-ripple\"\n            ></span>\n          </div>\n        </div>\n      </div>\n\n      <div\n        #optionContainerElementRef\n        class=\"cub-option-container\"\n        [class.cub-option-container-margin]=\"multiple && hasGroup\"\n      >\n        <div *ngIf=\"noFilterResults\" class=\"cub-filter-empty-message\">\n          {{ emptyFilterMessage }}\n        </div>\n\n        <ng-container *ngIf=\"!multiple && showOptionPlaceholder\">\n          <cub-option-group\n            *ngIf=\"hasGroup\"\n            #optionGroupPlaceholderElementRef\n            class=\"cub-option-group-placeholder\"\n            label=\"\"\n            [size]=\"size\"\n          >\n            <cub-option\n              #optionPlaceholderElementRef\n              class=\"cub-option-placeholder\"\n              value=\"\"\n              [size]=\"size\"\n              (click)=\"clear()\"\n              (keydown)=\"handlePlaceholderkeydown($event)\"\n            >\n              {{ optionPlaceholder }}\n            </cub-option>\n          </cub-option-group>\n\n          <cub-option\n            *ngIf=\"!hasGroup\"\n            #optionPlaceholderElementRef\n            class=\"cub-option-placeholder\"\n            value=\"\"\n            [size]=\"size\"\n            (click)=\"clear()\"\n            (keydown)=\"handlePlaceholderkeydown($event)\"\n          >\n            {{ optionPlaceholder }}\n          </cub-option>\n        </ng-container>\n\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.FormBuilder }, { type: i0.Renderer2 }, { type: i1.ViewportRuler }, { type: i0.ChangeDetectorRef }, { type: i0.NgZone }, { type: i2.ErrorStateMatcher }, { type: i0.ElementRef }, { type: i3.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i1$1.NgForm, decorators: [{
                    type: Optional
                }] }, { type: i1$1.FormGroupDirective, decorators: [{
                    type: Optional
                }] }, { type: i6.CubFormField, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_FORM_FIELD]
                }] }, { type: i1$1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_SELECT_SCROLL_STRATEGY]
                }] }, { type: i5.LiveAnnouncer }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_SELECT_CONFIG]
                }] }], propDecorators: { value: [{
                type: Input
            }], size: [{
                type: Input
            }], appearance: [{
                type: Input
            }], showFilter: [{
                type: Input,
                args: ['filter']
            }], resetFilterOnHide: [{
                type: Input
            }], selectAllLabel: [{
                type: Input
            }], showOptionPlaceholder: [{
                type: Input
            }], optionPlaceholder: [{
                type: Input
            }], filterPlaceholder: [{
                type: Input
            }], emptyFilterMessage: [{
                type: Input
            }], maxSelectedLabels: [{
                type: Input
            }], selectedItemsLabel: [{
                type: Input
            }], selectedAllItemsLabel: [{
                type: Input
            }], filter: [{
                type: Output
            }], checkbox: [{
                type: ViewChild,
                args: ['checkbox']
            }], inputElementRef: [{
                type: ViewChild,
                args: ['inputElementRef']
            }], optionContainerElementRef: [{
                type: ViewChild,
                args: ['optionContainerElementRef']
            }], optionPlaceholderElementRef: [{
                type: ViewChild,
                args: ['optionPlaceholderElementRef', { read: ElementRef }]
            }], optionGroupPlaceholderElementRef: [{
                type: ViewChild,
                args: ['optionGroupPlaceholderElementRef', { read: ElementRef }]
            }], optionPlaceholderElement: [{
                type: ViewChild,
                args: ['optionPlaceholderElementRef']
            }], optionGroupPlaceholderElement: [{
                type: ViewChild,
                args: ['optionGroupPlaceholderElementRef']
            }], optionElementRefList: [{
                type: ContentChildren,
                args: [CubOption, { read: ElementRef }]
            }], optionGroupElementRefList: [{
                type: ContentChildren,
                args: [CUB_OPTION_GROUP, { read: ElementRef }]
            }], optionElementList: [{
                type: ContentChildren,
                args: [CubOption, { descendants: true }]
            }], optionGroupElementList: [{
                type: ContentChildren,
                args: [CUB_OPTION_GROUP, { descendants: true }]
            }] } });

class CubSelectModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubSelectModule, imports: [CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule,
            CubSelect,
            CubSelectTrigger], exports: [CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule,
            CubSelect,
            CubSelectTrigger] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_SELECT_SCROLL_STRATEGY_PROVIDER,
        ], imports: [CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule,
            CubSelect, CubCdkScrollableModule,
            CubCommonModule,
            CubOptionModule,
            CubFormFieldModule,
            CubLabelModule,
            CubInputGroupModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkScrollableModule,
                        CubCommonModule,
                        CubOptionModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputGroupModule,
                        CubSelect,
                        CubSelectTrigger,
                    ],
                    exports: [
                        CubCdkScrollableModule,
                        CubCommonModule,
                        CubOptionModule,
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputGroupModule,
                        CubSelect,
                        CubSelectTrigger,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_SELECT_SCROLL_STRATEGY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/select
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_SELECT_CONFIG, CUB_SELECT_SCROLL_STRATEGY, CUB_SELECT_SCROLL_STRATEGY_PROVIDER, CUB_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY, CUB_SELECT_TRIGGER, CubSelect, CubSelectChange, CubSelectModule, CubSelectTrigger, SELECT_ITEM_HEIGHT_EM, SELECT_MULTIPLE_PANEL_PADDING_X, SELECT_PANEL_INDENT_PADDING_X, SELECT_PANEL_MAX_HEIGHT, SELECT_PANEL_PADDING_X, SELECT_PANEL_VIEWPORT_PADDING, _CubSelectAdvance, _CubSelectBase, _CubSelectMixinBase, cubSelectAnimations, getCubSelectDynamicMultipleError, getCubSelectNonArrayValueError, getCubSelectNonFunctionValueError };
//# sourceMappingURL=cub-lib-view-rootng-component-select.mjs.map
