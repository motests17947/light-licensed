import * as i0 from '@angular/core';
import { inject, ChangeDetectorRef, ElementRef, EventEmitter, booleanAttribute, HostListener, Output, Input, Directive, NgModule } from '@angular/core';

class CubShowMore {
    constructor() {
        this._expanded = false;
        this._changeDetectorRef = inject(ChangeDetectorRef);
        this.hostElement = inject(ElementRef).nativeElement;
        /**
         * 元件是否為禁用狀態，預設值為 false。
         */
        this.disabled = false;
        /**
         * 當元件收起時送出事件。
         */
        this.closed = new EventEmitter();
        /**
         * 當元件展開時送出事件。
         */
        this.opened = new EventEmitter();
        /**
         * 當元件實體被摧毀時送出事件。
         */
        this.destroyed = new EventEmitter();
        /**
         * 當 expanded 狀態改變時送出事件。
         */
        this.expandedChange = new EventEmitter();
    }
    /**
     * 元件是否為展開狀態，預設值為 false。
     */
    get expanded() {
        return this._expanded;
    }
    set expanded(expanded) {
        if (this._expanded == expanded)
            return;
        Promise.resolve().then(() => {
            this._expanded = expanded;
            this.expandedChange.emit(expanded);
            if (expanded) {
                this.hostElement.style.height = this.hostElement.scrollHeight + 'px';
            }
            else {
                const currentHeight = this.hostElement.scrollHeight;
                this.hostElement.style.height = currentHeight + 'px';
                // 重新使瀏覽器去渲染頁面。
                void this.hostElement.offsetHeight;
                this.hostElement.style.height = '0';
            }
            this._changeDetectorRef.markForCheck();
        });
    }
    onTransitionEnd(event) {
        if (event.propertyName === 'height') {
            if (this._expanded) {
                this.opened.emit();
                // 解決巢狀的 show-more 元素在展開時高度不正確的問題。
                this.hostElement.style.height = 'auto';
            }
            else {
                this.closed.emit();
            }
        }
    }
    ngOnDestroy() {
        this.opened.complete();
        this.closed.complete();
        this.destroyed.emit();
        this.destroyed.complete();
    }
    toggle() {
        if (!this.disabled) {
            this.expanded = !this.expanded;
        }
    }
    close() {
        if (!this.disabled) {
            this.expanded = false;
        }
    }
    open() {
        if (!this.disabled) {
            this.expanded = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubShowMore, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubShowMore, isStandalone: true, selector: "[cubShowMore]", inputs: { expanded: ["expanded", "expanded", booleanAttribute], disabled: ["disabled", "disabled", booleanAttribute] }, outputs: { closed: "closed", opened: "opened", destroyed: "destroyed", expandedChange: "expandedChange" }, host: { listeners: { "transitionend": "onTransitionEnd($event)" }, properties: { "class.cub-expanded": "expanded" }, classAttribute: "cub-show-more" }, exportAs: ["cubShowMore"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubShowMore, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubShowMore]',
                    exportAs: 'cubShowMore',
                    host: {
                        class: 'cub-show-more',
                        '[class.cub-expanded]': 'expanded',
                    },
                }]
        }], propDecorators: { expanded: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], closed: [{
                type: Output
            }], opened: [{
                type: Output
            }], destroyed: [{
                type: Output
            }], expandedChange: [{
                type: Output
            }], onTransitionEnd: [{
                type: HostListener,
                args: ['transitionend', ['$event']]
            }] } });

class CubShowMoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubShowMoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubShowMoreModule, imports: [CubShowMore], exports: [CubShowMore] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubShowMoreModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubShowMoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubShowMore],
                    exports: [CubShowMore],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/show-more
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CubShowMore, CubShowMoreModule };
//# sourceMappingURL=cub-lib-view-rootng-component-show-more.mjs.map
