import * as i0 from '@angular/core';
import { InjectionToken, ViewChild, Input, Inject, ViewEncapsulation, ChangeDetectionStrategy, Component, EventEmitter, isDevMode, ContentChildren, ContentChild, ViewChildren, Output, Optional, forwardRef, Directive, NgModule } from '@angular/core';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { take } from 'rxjs/operators';
import * as i1 from 'cub-lib-view-rootng/cdk';
import { coerceBooleanProperty, coerceNumberProperty } from 'cub-lib-view-rootng/cdk';
import { CubRipple, mixinColor, mixinDisableRipple, CUB_RIPPLE_GLOBAL_OPTIONS } from 'cub-lib-view-rootng/component/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject } from 'rxjs';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';

function _validateInputs(isRange, endInputElement, startInputElement) {
    const startValid = !isRange ||
        startInputElement?._hostElement.hasAttribute('cubSliderStartThumb');
    const endValid = endInputElement._hostElement.hasAttribute(isRange ? 'cubSliderEndThumb' : 'cubSliderThumb');
    if (!startValid || !endValid) {
        _throwInvalidInputConfigurationError();
    }
}
function _throwInvalidInputConfigurationError() {
    throw Error(`Invalid slider thumb input configuration!`);
}

const CUB_SLIDER = new InjectionToken('_CubSlider');
const CUB_SLIDER_THUMB = new InjectionToken('_CubSliderThumb');
const CUB_SLIDER_RANGE_THUMB = new InjectionToken('_CubSliderRangeThumb');
const CUB_SLIDER_VISUAL_THUMB = new InjectionToken('_CubSliderVisualThumb');

class CubSliderVisualThumb {
    get rippleDisabled() {
        return this._slider.disabled;
    }
    constructor(_cdr, _platform, _ngZone, _elementRef, _slider) {
        this._cdr = _cdr;
        this._platform = _platform;
        this._ngZone = _ngZone;
        this._slider = _slider;
        this._isActive = false;
        this._isValueIndicatorVisible = false;
        /* TODO 待移除 Hover 相關邏輯 */
        this._isHovered = false;
        this._onPointerMove = (event) => {
            if (this._sliderInput._isFocused) {
                return;
            }
            const rect = this._hostElement.getBoundingClientRect();
            const isHovered = this._isSliderThumbHovered(event, rect);
            this._isHovered = isHovered;
        };
        this._onMouseLeave = (event) => {
            if (!this._platformSupportsMouseEvents()) {
                setTimeout(() => {
                    this._sliderInput._updateThumbUIByPointerEvent(event);
                }, 10);
                if (this._sliderInput._isFocused) {
                    return;
                }
            }
        };
        this._onFocus = () => {
            this._hideRipple(this._hoverRippleRef);
            this._hostElement.classList.add('cub-slider-thumb-focused');
        };
        this._onBlur = () => {
            if (!this._isActive) {
                this._hideRipple(this._focusRippleRef);
            }
            this._hostElement.classList.remove('cub-slider-thumb-focused');
        };
        this._onDragStart = () => {
            this._isActive = true;
            this._showActiveRipple();
        };
        this._onDragEnd = () => {
            this._isActive = false;
            this._hideRipple(this._activeRippleRef);
            if (!this._sliderInput._isFocused) {
                this._hideRipple(this._focusRippleRef);
            }
        };
        this._hostElement = _elementRef.nativeElement;
    }
    ngAfterViewInit() {
        this._ripple.radius = 24;
        this._sliderInput = this._slider._getInput(this.thumbPosition);
        this._sliderInputEl = this._sliderInput._hostElement;
        const input = this._sliderInputEl;
        this._ngZone.runOutsideAngular(() => {
            input.addEventListener('pointermove', this._onPointerMove);
            input.addEventListener('pointerdown', this._onDragStart);
            input.addEventListener('pointerup', this._onDragEnd);
            input.addEventListener('pointerleave', this._onMouseLeave);
            input.addEventListener('focus', this._onFocus);
            input.addEventListener('blur', this._onBlur);
        });
    }
    ngOnDestroy() {
        const input = this._sliderInputEl;
        input.removeEventListener('pointermove', this._onPointerMove);
        input.removeEventListener('pointerdown', this._onDragStart);
        input.removeEventListener('pointerup', this._onDragEnd);
        input.removeEventListener('pointerleave', this._onMouseLeave);
        input.removeEventListener('focus', this._onFocus);
        input.removeEventListener('blur', this._onBlur);
    }
    _showValueIndicator() {
        this._hostElement.classList.add('cub-slider-thumb-with-indicator');
    }
    _hideValueIndicator() {
        this._hostElement.classList.remove('cub-slider-thumb-with-indicator');
    }
    _getSibling() {
        return this._slider._getThumb(this.thumbPosition === 1 /* _CubThumb.START */ ? 2 /* _CubThumb.END */ : 1 /* _CubThumb.START */);
    }
    _getValueIndicatorContainer() {
        return this._valueIndicatorContainer?.nativeElement;
    }
    _getKnob() {
        return this._knob.nativeElement;
    }
    _isShowingAnyRipple() {
        return (this._isShowingRipple(this._hoverRippleRef) ||
            this._isShowingRipple(this._focusRippleRef) ||
            this._isShowingRipple(this._activeRippleRef));
    }
    _platformSupportsMouseEvents() {
        return !this._platform.IOS && !this._platform.ANDROID;
    }
    _showActiveRipple() {
        if (!this._isShowingRipple(this._activeRippleRef)) {
            this._activeRippleRef = this._showRipple({
                enterDuration: 225,
                exitDuration: 400,
            });
            this._activeRippleRef?.element.classList.add('cub-slider-active-ripple');
        }
    }
    _isShowingRipple(rippleRef) {
        return (rippleRef?.state === 0 /* CubRippleState.FADING_IN */ ||
            rippleRef?.state === 1 /* CubRippleState.VISIBLE */);
    }
    _showRipple(animation, ignoreGlobalRippleConfig) {
        if (this._slider.disabled) {
            return;
        }
        this._showValueIndicator();
        if (this._slider._isRange) {
            const sibling = this._slider._getThumb(this.thumbPosition === 1 /* _CubThumb.START */ ? 2 /* _CubThumb.END */ : 1 /* _CubThumb.START */);
            sibling._showValueIndicator();
        }
        if (this._slider._globalRippleOptions?.disabled &&
            !ignoreGlobalRippleConfig) {
            return;
        }
        return this._ripple.launch({
            animation: this._slider._noopAnimations
                ? { enterDuration: 0, exitDuration: 0 }
                : animation,
            centered: true,
            persistent: true,
        });
    }
    _hideRipple(rippleRef) {
        rippleRef?.fadeOut();
        if (this._isShowingAnyRipple()) {
            return;
        }
        if (!this._slider._isRange) {
            this._hideValueIndicator();
        }
        const sibling = this._getSibling();
        if (!sibling._isShowingAnyRipple()) {
            this._hideValueIndicator();
            sibling._hideValueIndicator();
        }
    }
    _isSliderThumbHovered(event, rect) {
        const radius = rect.width / 2;
        const centerX = rect.x + radius;
        const centerY = rect.y + radius;
        const dx = event.clientX - centerX;
        const dy = event.clientY - centerY;
        return Math.pow(dx, 2) + Math.pow(dy, 2) < Math.pow(radius, 2);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderVisualThumb, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.Platform }, { token: i0.NgZone }, { token: i0.ElementRef }, { token: CUB_SLIDER }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubSliderVisualThumb, isStandalone: true, selector: "cub-slider-thumb", inputs: { discrete: "discrete", thumbPosition: "thumbPosition", valueIndicatorText: "valueIndicatorText" }, host: { classAttribute: "cub-slider-thumb cub-slider-visual-thumb" }, providers: [
            { provide: CUB_SLIDER_VISUAL_THUMB, useExisting: CubSliderVisualThumb },
        ], viewQueries: [{ propertyName: "_ripple", first: true, predicate: CubRipple, descendants: true }, { propertyName: "_knob", first: true, predicate: ["knob"], descendants: true }, { propertyName: "_valueIndicatorContainer", first: true, predicate: ["valueIndicatorContainer"], descendants: true }], ngImport: i0, template: "@if (discrete) {\n<div class=\"cub-slider-value-indicator-container\" #valueIndicatorContainer>\n  <div class=\"cub-slider-value-indicator\">\n    <span class=\"cub-slider-value-indicator-text\">{{\n      valueIndicatorText\n    }}</span>\n  </div>\n</div>\n}\n\n<div class=\"cub-slider-thumb-knob\" #knob></div>\n\n<div\n  cubRipple\n  cubRippleClass=\"cub-slider-thumb-ripple\"\n  [cubRippleDisabled]=\"rippleDisabled\"\n  [cubRippleTrigger]=\"_hostElement\"\n></div>\n<div class=\"cub-persistent-ripple cub-slider-thumb-persistent-ripple\"></div>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderVisualThumb, decorators: [{
            type: Component,
            args: [{ selector: 'cub-slider-thumb', host: {
                        class: 'cub-slider-thumb cub-slider-visual-thumb',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, providers: [
                        { provide: CUB_SLIDER_VISUAL_THUMB, useExisting: CubSliderVisualThumb },
                    ], imports: [CubRipple], template: "@if (discrete) {\n<div class=\"cub-slider-value-indicator-container\" #valueIndicatorContainer>\n  <div class=\"cub-slider-value-indicator\">\n    <span class=\"cub-slider-value-indicator-text\">{{\n      valueIndicatorText\n    }}</span>\n  </div>\n</div>\n}\n\n<div class=\"cub-slider-thumb-knob\" #knob></div>\n\n<div\n  cubRipple\n  cubRippleClass=\"cub-slider-thumb-ripple\"\n  [cubRippleDisabled]=\"rippleDisabled\"\n  [cubRippleTrigger]=\"_hostElement\"\n></div>\n<div class=\"cub-persistent-ripple cub-slider-thumb-persistent-ripple\"></div>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.Platform }, { type: i0.NgZone }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_SLIDER]
                }] }], propDecorators: { discrete: [{
                type: Input
            }], thumbPosition: [{
                type: Input
            }], valueIndicatorText: [{
                type: Input
            }], _ripple: [{
                type: ViewChild,
                args: [CubRipple]
            }], _knob: [{
                type: ViewChild,
                args: ['knob']
            }], _valueIndicatorContainer: [{
                type: ViewChild,
                args: ['valueIndicatorContainer']
            }] } });

const _CubSliderMixinBase = mixinColor(mixinDisableRipple(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}));
/** 'disableRipple' 是否禁用漣漪效果，預設為 undefined。 */
class CubSlider extends _CubSliderMixinBase {
    /** 元件是否禁用，預設為 false。 */
    get disabled() {
        return this._disabled;
    }
    set disabled(v) {
        this._disabled = coerceBooleanProperty(v);
        const endInput = this._getInput(2 /* _CubThumb.END */);
        const startInput = this._getInput(1 /* _CubThumb.START */);
        if (endInput) {
            endInput.disabled = this._disabled;
        }
        if (startInput) {
            startInput.disabled = this._disabled;
        }
    }
    /** 元件是否在按下時顯示數值標籤，預設為 false。【暫不開放使用】 */
    // @Input()
    get discrete() {
        return this._discrete;
    }
    set discrete(v) {
        this._discrete = coerceBooleanProperty(v);
        this._updateValueIndicatorUIs();
    }
    /** 元件是否沿著軌道顯示刻度標記，預設為 false。 */
    get showTickMarks() {
        return this._showTickMarks;
    }
    set showTickMarks(v) {
        this._showTickMarks = coerceBooleanProperty(v);
    }
    /** 元件的最小值，預設為 0。 */
    get min() {
        return this._min;
    }
    set min(v) {
        const min = coerceNumberProperty(v, this._min);
        if (this._min !== min) {
            this._updateMin(min);
        }
    }
    /** 滑桿可以擁有的最大值，預設為 100。 */
    get max() {
        return this._max;
    }
    set max(v) {
        const max = coerceNumberProperty(v, this._max);
        if (this._max !== max) {
            this._updateMax(max);
        }
    }
    /** 用於顯示刻度的間隔 (不影響滑動) */
    get tickStep() {
        return this._tickStep;
    }
    set tickStep(v) {
        const tickStep = coerceNumberProperty(v, this._tickStep);
        if (this._tickStep !== tickStep) {
            this._tickStep = tickStep;
            this._updateTickMarkUI();
        }
    }
    /** 元件移動時的數值間隔，預設為 0。 */
    get step() {
        return this._step;
    }
    set step(v) {
        const step = coerceNumberProperty(v, this._step);
        if (this._step !== step) {
            this._updateStep(step);
        }
    }
    constructor(_ngZone, _cdr, _platform, elementRef, _dir, _globalRippleOptions, animationMode) {
        super(elementRef);
        this._ngZone = _ngZone;
        this._cdr = _cdr;
        this._platform = _platform;
        this._dir = _dir;
        this._globalRippleOptions = _globalRippleOptions;
        this._rippleRadius = 24;
        this._isRange = false;
        this._isRtl = false;
        this._tickMarkTrackWidth = 0;
        this._hasAnimation = false;
        this._knobRadius = 10;
        this.startValueIndicatorText = '';
        this.endValueIndicatorText = '';
        this._disabled = false;
        this._discrete = false;
        this._showTickMarks = false;
        this._min = 0;
        this._max = 100;
        this._tickStep = 10;
        this._step = 0;
        this._hasViewInitialized = false;
        this._resizeTimer = null;
        this._thumbsOverlap = false;
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        this.displayWithChange = new EventEmitter();
        this._noopAnimations = animationMode === 'NoopAnimations';
        this._dirChangeSubscription = this._dir.change.subscribe(() => this._onDirChange());
        this._isRtl = this._dir.value === 'rtl';
    }
    ngAfterViewInit() {
        if (this._platform.isBrowser) {
            this._updateDimensions();
        }
        const eInput = this._getInput(2 /* _CubThumb.END */);
        const sInput = this._getInput(1 /* _CubThumb.START */);
        this._isRange = !!eInput && !!sInput;
        this._cdr.detectChanges();
        if (isDevMode()) {
            _validateInputs(this._isRange, this._getInput(2 /* _CubThumb.END */), this._getInput(1 /* _CubThumb.START */));
        }
        const thumb = this._getThumb(2 /* _CubThumb.END */);
        this._rippleRadius = thumb._ripple.radius;
        this._inputPadding = this._rippleRadius - this._knobRadius;
        this._inputOffset = this._knobRadius;
        this._isRange
            ? this._initUIRange(eInput, sInput)
            : this._initUINonRange(eInput);
        this._updateTrackUI(eInput);
        this._updateTickMarkUI();
        this._updateTickMarkTrackUI();
        this._observeHostResize();
        this._updateActiveClass();
        this._cdr.detectChanges();
    }
    ngOnDestroy() {
        this._dirChangeSubscription.unsubscribe();
        this._resizeObserver?.disconnect();
        this._resizeObserver = null;
    }
    /* 設定值到最小值（移除 active 狀態） */
    resetToMinValue() {
        const eInput = this._getInput(2 /* _CubThumb.END */);
        const sInput = this._getInput(1 /* _CubThumb.START */);
        if (eInput) {
            eInput.value = this.min;
            this._onValueChange(eInput);
        }
        if (sInput) {
            sInput.value = this.min;
            this._onValueChange(sInput);
        }
        this._updateActiveClass();
    }
    _updateDimensions() {
        this._cachedWidth = this._elementRef.nativeElement.offsetWidth;
        this._cachedLeft =
            this._elementRef.nativeElement.getBoundingClientRect().left;
    }
    _setTrackActiveStyles(styles) {
        const trackStyle = this._trackActive.nativeElement.style;
        const animationOriginChanged = styles.left !== trackStyle.left && styles.right !== trackStyle.right;
        trackStyle.left = styles.left;
        trackStyle.right = styles.right;
        trackStyle.transformOrigin = styles.transformOrigin;
        if (animationOriginChanged) {
            this._elementRef.nativeElement.classList.add('cub-slider-disable-track-animation');
            this._ngZone.onStable.pipe(take(1)).subscribe(() => {
                this._elementRef.nativeElement.classList.remove('cub-slider-disable-track-animation');
                trackStyle.transform = styles.transform;
            });
        }
        else {
            trackStyle.transform = styles.transform;
        }
    }
    _calcTickMarkTransform(index) {
        const translateX = index * (this._tickMarkTrackWidth / (this._tickMarks.length - 1));
        return `translateX(${translateX - 1}px`;
    }
    _onTranslateXChange(source) {
        if (!this._hasViewInitialized) {
            return;
        }
        this._updateThumbUI(source);
        this._updateTrackUI(source);
        this._updateOverlappingThumbUI(source);
        this._updateActiveClass();
    }
    _onTranslateXChangeBySideEffect(input1, input2) {
        if (!this._hasViewInitialized) {
            return;
        }
        input1._updateThumbUIByValue();
        input2._updateThumbUIByValue();
    }
    _onValueChange(source) {
        if (!this._hasViewInitialized) {
            return;
        }
        this._updateValueIndicatorUI(source);
        this._updateTickMarkUI();
        this._updateActiveClass();
        this._cdr.detectChanges();
    }
    _onMinMaxOrStepChange() {
        if (!this._hasViewInitialized) {
            return;
        }
        this._updateTickMarkUI();
        this._updateTickMarkTrackUI();
        this._cdr.markForCheck();
    }
    _onResize() {
        if (!this._hasViewInitialized) {
            return;
        }
        this._updateDimensions();
        if (this._isRange) {
            const eInput = this._getInput(2 /* _CubThumb.END */);
            const sInput = this._getInput(1 /* _CubThumb.START */);
            eInput._updateThumbUIByValue();
            sInput._updateThumbUIByValue();
            eInput._updateStaticStyles();
            sInput._updateStaticStyles();
            eInput._updateMinMax();
            sInput._updateMinMax();
        }
        else {
            const eInput = this._getInput(2 /* _CubThumb.END */);
            if (eInput) {
                eInput._updateThumbUIByValue();
            }
        }
        this._updateTickMarkUI();
        this._updateTickMarkTrackUI();
        this._cdr.detectChanges();
    }
    _updateThumbUI(source) {
        if (this._skipUpdate()) {
            return;
        }
        const thumb = this._getThumb(source.thumbPosition === 2 /* _CubThumb.END */ ? 2 /* _CubThumb.END */ : 1 /* _CubThumb.START */);
        const trackWidth = this._cachedWidth;
        const valuePercentage = this._endTransform;
        const moveToX = valuePercentage * trackWidth;
        const thumbRadiuses = thumb._hostElement.offsetWidth / 2;
        const finalPosition = moveToX - thumbRadiuses;
        if (finalPosition < 0) {
            thumb._hostElement.style.transform = `translateX(-2px)`;
        }
        else if (finalPosition >= trackWidth - 2 * thumbRadiuses) {
            thumb._hostElement.style.transform = `translateX(${trackWidth - 2 * thumbRadiuses}px)`;
        }
        else {
            thumb._hostElement.style.transform = `translateX(${finalPosition}px)`;
        }
    }
    _updateTrackUI(source) {
        if (this._skipUpdate()) {
            return;
        }
        this._isRange
            ? this._updateTrackUIRange(source)
            : this._updateTrackUINonRange(source);
    }
    _updateValueIndicatorUI(source) {
        if (this._skipUpdate()) {
            return;
        }
        const valuetext = source.value + '';
        this.displayWithChange.emit(source.value);
        this._hasViewInitialized
            ? (source._valuetext = valuetext)
            : source._hostElement.setAttribute('aria-valuetext', valuetext);
        if (this.discrete) {
            source.thumbPosition === 1 /* _CubThumb.START */
                ? (this.startValueIndicatorText = valuetext)
                : (this.endValueIndicatorText = valuetext);
            const visualThumb = this._getThumb(source.thumbPosition);
            valuetext.length < 3
                ? visualThumb._hostElement.classList.add('cub-slider-thumb-short-value')
                : visualThumb._hostElement.classList.remove('cub-slider-thumb-short-value');
        }
    }
    _updateTickMarkUI() {
        if (!this.showTickMarks ||
            this.step === undefined ||
            this.min === undefined ||
            this.max === undefined) {
            return;
        }
        const tickStep = this._tickStep > 0 ? this._tickStep : 1;
        this._isRange
            ? this._updateTickMarkUIRange(tickStep)
            : this._updateTickMarkUINonRange(tickStep);
        if (this._isRtl) {
            this._tickMarks.reverse();
        }
    }
    _getInput(thumbPosition) {
        if (thumbPosition === 2 /* _CubThumb.END */ && this._input) {
            return this._input;
        }
        if (this._inputs?.length) {
            return thumbPosition === 1 /* _CubThumb.START */
                ? this._inputs.first
                : this._inputs.last;
        }
        return;
    }
    _getThumb(thumbPosition) {
        return thumbPosition === 2 /* _CubThumb.END */
            ? this._thumbs?.last
            : this._thumbs?.first;
    }
    _setTransition(withAnimation) {
        this._hasAnimation = withAnimation && !this._noopAnimations;
        this._elementRef.nativeElement.classList.toggle('cub-slider-with-animation', this._hasAnimation);
    }
    /* 檢查是否不是最小值 */
    _isNotMinValue() {
        const eInput = this._getInput(2 /* _CubThumb.END */);
        const sInput = this._getInput(1 /* _CubThumb.START */);
        if (this._isRange) {
            return eInput?.value !== this.min || sInput?.value !== this.min;
        }
        else {
            return eInput?.value !== this.min;
        }
    }
    /* 更新 active class - 只要不是最小值就有 active */
    _updateActiveClass() {
        const shouldBeActive = this._isNotMinValue();
        this._elementRef.nativeElement.classList.toggle('cub-slider-active', shouldBeActive);
    }
    _updateMax(max) {
        const prevMax = this._max;
        this._max = max;
        this._isRange
            ? this._updateMaxRange({ old: prevMax, new: max })
            : this._updateMaxNonRange(max);
        this._onMinMaxOrStepChange();
    }
    _updateMin(min) {
        const prevMin = this._min;
        this._min = min;
        this._isRange
            ? this._updateMinRange({ old: prevMin, new: min })
            : this._updateMinNonRange(min);
        this._onMinMaxOrStepChange();
    }
    _updateMinRange(min) {
        const endInput = this._getInput(2 /* _CubThumb.END */);
        const startInput = this._getInput(1 /* _CubThumb.START */);
        const oldEndValue = endInput.value;
        const oldStartValue = startInput.value;
        startInput.min = min.new;
        endInput.min = Math.max(min.new, startInput.value);
        startInput.max = Math.min(endInput.max, endInput.value);
        min.new < min.old
            ? this._onTranslateXChangeBySideEffect(endInput, startInput)
            : this._onTranslateXChangeBySideEffect(startInput, endInput);
        if (oldEndValue !== endInput.value) {
            this._onValueChange(endInput);
        }
        if (oldStartValue !== startInput.value) {
            this._onValueChange(startInput);
        }
    }
    _updateMinNonRange(min) {
        const input = this._getInput(2 /* _CubThumb.END */);
        if (input) {
            const oldValue = input.value;
            input.min = min;
            input._updateThumbUIByValue();
            this._updateTrackUI(input);
            if (oldValue !== input.value) {
                this._onValueChange(input);
            }
        }
    }
    _updateMaxRange(max) {
        const endInput = this._getInput(2 /* _CubThumb.END */);
        const startInput = this._getInput(1 /* _CubThumb.START */);
        const oldEndValue = endInput.value;
        const oldStartValue = startInput.value;
        endInput.max = max.new;
        startInput.max = Math.min(max.new, endInput.value);
        endInput.min = startInput.value;
        max.new > max.old
            ? this._onTranslateXChangeBySideEffect(startInput, endInput)
            : this._onTranslateXChangeBySideEffect(endInput, startInput);
        if (oldEndValue !== endInput.value) {
            this._onValueChange(endInput);
        }
        if (oldStartValue !== startInput.value) {
            this._onValueChange(startInput);
        }
    }
    _updateMaxNonRange(max) {
        const input = this._getInput(2 /* _CubThumb.END */);
        if (input) {
            const oldValue = input.value;
            input.max = max;
            input._updateThumbUIByValue();
            this._updateTrackUI(input);
            if (oldValue !== input.value) {
                this._onValueChange(input);
            }
        }
    }
    _updateStep(step) {
        this._step = step;
        this._isRange ? this._updateStepRange() : this._updateStepNonRange();
        this._onMinMaxOrStepChange();
    }
    _updateStepRange() {
        const endInput = this._getInput(2 /* _CubThumb.END */);
        const startInput = this._getInput(1 /* _CubThumb.START */);
        const oldEndValue = endInput.value;
        const oldStartValue = startInput.value;
        const prevStartValue = startInput.value;
        endInput.min = this._min;
        startInput.max = this._max;
        if (this._platform.SAFARI) {
            // eslint-disable-next-line no-self-assign
            endInput.value = endInput.value;
            // eslint-disable-next-line no-self-assign
            startInput.value = startInput.value;
        }
        endInput.min = Math.max(this._min, startInput.value);
        startInput.max = Math.min(this._max, endInput.value);
        endInput.value < prevStartValue
            ? this._onTranslateXChangeBySideEffect(startInput, endInput)
            : this._onTranslateXChangeBySideEffect(endInput, startInput);
        if (oldEndValue !== endInput.value) {
            this._onValueChange(endInput);
        }
        if (oldStartValue !== startInput.value) {
            this._onValueChange(startInput);
        }
    }
    _initUINonRange(eInput) {
        eInput.initProps();
        eInput.initUI();
        this._updateValueIndicatorUI(eInput);
        this._hasViewInitialized = true;
        eInput._updateThumbUIByValue();
    }
    _initUIRange(eInput, sInput) {
        eInput.initProps();
        eInput.initUI();
        sInput.initProps();
        sInput.initUI();
        eInput._updateMinMax();
        sInput._updateMinMax();
        eInput._updateStaticStyles();
        sInput._updateStaticStyles();
        this._updateValueIndicatorUIs();
        this._hasViewInitialized = true;
        eInput._updateThumbUIByValue();
        sInput._updateThumbUIByValue();
    }
    _updateStepNonRange() {
        const input = this._getInput(2 /* _CubThumb.END */);
        if (input) {
            const oldValue = input.value;
            if (this._platform.SAFARI) {
                // eslint-disable-next-line no-self-assign
                input.value = input.value;
            }
            input._updateThumbUIByValue();
            if (oldValue !== input.value) {
                this._onValueChange(input);
            }
        }
    }
    _onDirChange() {
        this._isRtl = this._dir.value === 'rtl';
        this._isRange ? this._onDirChangeRange() : this._onDirChangeNonRange();
        this._updateTickMarkUI();
    }
    _onDirChangeRange() {
        const endInput = this._getInput(2 /* _CubThumb.END */);
        const startInput = this._getInput(1 /* _CubThumb.START */);
        endInput._setIsLeftThumb();
        startInput._setIsLeftThumb();
        endInput.translateX = endInput._calcTranslateXByValue();
        startInput.translateX = startInput._calcTranslateXByValue();
        endInput._updateStaticStyles();
        startInput._updateStaticStyles();
        endInput._updateThumbUIByValue();
        startInput._updateThumbUIByValue();
    }
    _onDirChangeNonRange() {
        const input = this._getInput(2 /* _CubThumb.END */);
        input._updateThumbUIByValue();
    }
    _observeHostResize() {
        if (typeof ResizeObserver === 'undefined' || !ResizeObserver) {
            return;
        }
        this._ngZone.runOutsideAngular(() => {
            this._resizeObserver = new ResizeObserver(() => {
                if (this._isActive()) {
                    return;
                }
                if (this._resizeTimer) {
                    clearTimeout(this._resizeTimer);
                }
                this._onResize();
            });
            this._resizeObserver.observe(this._elementRef.nativeElement);
        });
    }
    _isActive() {
        return (this._getThumb(1 /* _CubThumb.START */)._isActive ||
            this._getThumb(2 /* _CubThumb.END */)._isActive);
    }
    _getValue(thumbPosition = 2 /* _CubThumb.END */) {
        const input = this._getInput(thumbPosition);
        if (!input) {
            return this.min;
        }
        return input.value;
    }
    _skipUpdate() {
        return !!(this._getInput(1 /* _CubThumb.START */)?._skipUIUpdate ||
            this._getInput(2 /* _CubThumb.END */)?._skipUIUpdate);
    }
    _areThumbsOverlapping() {
        const startInput = this._getInput(1 /* _CubThumb.START */);
        const endInput = this._getInput(2 /* _CubThumb.END */);
        if (!startInput || !endInput) {
            return false;
        }
        return endInput.translateX - startInput.translateX < 20;
    }
    _updateOverlappingThumbClassNames(source) {
        const sibling = source.getSibling();
        const sourceThumb = this._getThumb(source.thumbPosition);
        const siblingThumb = this._getThumb(sibling.thumbPosition);
        siblingThumb._hostElement.classList.remove('cub-slider-thumb--top');
        sourceThumb._hostElement.classList.toggle('cub-slider-thumb--top', this._thumbsOverlap);
    }
    _updateOverlappingThumbUI(source) {
        if (!this._isRange || this._skipUpdate()) {
            return;
        }
        if (this._thumbsOverlap !== this._areThumbsOverlapping()) {
            this._thumbsOverlap = !this._thumbsOverlap;
            this._updateOverlappingThumbClassNames(source);
        }
    }
    _updateValueIndicatorUIs() {
        const eInput = this._getInput(2 /* _CubThumb.END */);
        const sInput = this._getInput(1 /* _CubThumb.START */);
        if (eInput) {
            this._updateValueIndicatorUI(eInput);
        }
        if (sInput) {
            this._updateValueIndicatorUI(sInput);
        }
    }
    _updateTickMarkTrackUI() {
        if (!this.showTickMarks || this._skipUpdate()) {
            return;
        }
        const tickStep = this._tickStep && this._tickStep > 0 ? this._tickStep : 1;
        const maxValue = (this.max / tickStep) * tickStep;
        const percentage = (maxValue - this.min) / (this.max - this.min);
        this._tickMarkTrackWidth = this._cachedWidth * percentage;
    }
    _updateTrackUIRange(source) {
        const sibling = source.getSibling();
        if (!sibling || !this._cachedWidth) {
            return;
        }
        const activePercentage = Math.abs(sibling.translateX - source.translateX) / this._cachedWidth;
        if (source._isLeftThumb && this._cachedWidth) {
            this._setTrackActiveStyles({
                left: 'auto',
                right: `${this._cachedWidth - sibling.translateX}px`,
                transformOrigin: 'right',
                transform: `scaleX(${activePercentage})`,
            });
        }
        else {
            this._setTrackActiveStyles({
                left: `${sibling.translateX}px`,
                right: 'auto',
                transformOrigin: 'left',
                transform: `scaleX(${activePercentage})`,
            });
        }
    }
    _updateTrackUINonRange(source) {
        this._isRtl
            ? this._setTrackActiveStyles({
                left: 'auto',
                right: '0px',
                transformOrigin: 'right',
                transform: `scaleX(${1 - source.fillPercentage})`,
            })
            : this._setTrackActiveStyles({
                left: '0px',
                right: 'auto',
                transformOrigin: 'left',
                transform: `scaleX(${source.fillPercentage})`,
            });
        this._endTransform = source.fillPercentage;
    }
    _updateTickMarkUINonRange(tickStep) {
        const value = this._getValue();
        const normalizedValue = value - this.min;
        const activeTickIndex = Math.floor(normalizedValue / tickStep);
        const totalTicks = Math.floor((this.max - this.min) / tickStep) + 1;
        const numActive = Math.max(activeTickIndex, 0);
        const numInactive = Math.max(totalTicks - numActive - 1, 0);
        this._tickMarks = Array(numActive)
            .fill(0 /* _CubTickMark.ACTIVE */)
            .concat([0 /* _CubTickMark.ACTIVE */])
            .concat(Array(numInactive).fill(1 /* _CubTickMark.INACTIVE */));
    }
    _updateTickMarkUIRange(tickStep) {
        const endValue = this._getValue();
        const startValue = this._getValue(1 /* _CubThumb.START */);
        const numInactiveBeforeStartThumb = Math.max(Math.floor((startValue - this.min) / tickStep), 0);
        const numActive = Math.max(Math.floor((endValue - startValue) / tickStep) + 1, 0);
        const numInactiveAfterEndThumb = Math.max(Math.floor((this.max - endValue) / tickStep), 0);
        this._tickMarks = Array(numInactiveBeforeStartThumb)
            .fill(1 /* _CubTickMark.INACTIVE */)
            .concat(Array(numActive).fill(0 /* _CubTickMark.ACTIVE */), Array(numInactiveAfterEndThumb).fill(1 /* _CubTickMark.INACTIVE */));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSlider, deps: [{ token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i1.Platform }, { token: i0.ElementRef }, { token: i1.Directionality, optional: true }, { token: CUB_RIPPLE_GLOBAL_OPTIONS, optional: true }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubSlider, isStandalone: true, selector: "cub-slider", inputs: { disableRipple: "disableRipple", displayWith: "displayWith", size: "size", disabled: "disabled", showTickMarks: "showTickMarks", min: "min", max: "max", tickStep: "tickStep", step: "step" }, outputs: { displayWithChange: "displayWithChange" }, host: { properties: { "class.cub-slider-range": "_isRange", "class.cub-disabled": "disabled", "class.cub-slider-discrete": "discrete", "class.cub-slider-tick-marks": "showTickMarks", "class.cub-animation-noop-able": "_noopAnimations", "class.cub-slider-small": "size === \"small\"" }, classAttribute: "cub-slider" }, providers: [{ provide: CUB_SLIDER, useExisting: CubSlider }], queries: [{ propertyName: "_input", first: true, predicate: CUB_SLIDER_THUMB, descendants: true }, { propertyName: "_inputs", predicate: CUB_SLIDER_RANGE_THUMB }], viewQueries: [{ propertyName: "_trackActive", first: true, predicate: ["trackActive"], descendants: true }, { propertyName: "_thumbs", predicate: CUB_SLIDER_VISUAL_THUMB, descendants: true }], exportAs: ["cubSlider"], usesInheritance: true, ngImport: i0, template: "<!-- Inputs -->\n<ng-content></ng-content>\n\n<!-- Track -->\n<div class=\"cub-slider-track\">\n  <div class=\"cub-slider-track-inactive\"></div>\n  <div class=\"cub-slider-track-active\">\n    <div #trackActive class=\"cub-slider-track-active-fill\"></div>\n  </div>\n  @if (showTickMarks) {\n  <div class=\"cub-slider-tick-marks\" #tickMarkContainer>\n    @if (_cachedWidth) { @for (tickMark of _tickMarks; track $index; let i =\n    $index) { @if (i !== 0 && i !== _tickMarks.length - 1) {\n    <div\n      [class]=\"\n        tickMark === 0\n          ? 'cub-slider-tick-mark-active'\n          : 'cub-slider-tick-mark-inactive'\n      \"\n      [style.transform]=\"_calcTickMarkTransform(i)\"\n    >\n      <span class=\"cub-slider-tick-mark-value\">\n        {{ min + tickStep * i }}\n      </span>\n    </div>\n    } } }\n  </div>\n  }\n</div>\n\n<!-- Thumbs -->\n@if (_isRange) {\n<cub-slider-thumb\n  [discrete]=\"discrete\"\n  [thumbPosition]=\"1\"\n  [valueIndicatorText]=\"startValueIndicatorText\"\n>\n</cub-slider-thumb>\n}\n\n<cub-slider-thumb\n  [discrete]=\"discrete\"\n  [thumbPosition]=\"2\"\n  [valueIndicatorText]=\"endValueIndicatorText\"\n>\n</cub-slider-thumb>\n", styles: [""], dependencies: [{ kind: "component", type: CubSliderVisualThumb, selector: "cub-slider-thumb", inputs: ["discrete", "thumbPosition", "valueIndicatorText"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSlider, decorators: [{
            type: Component,
            args: [{ selector: 'cub-slider', host: {
                        class: 'cub-slider',
                        '[class.cub-slider-range]': '_isRange',
                        '[class.cub-disabled]': 'disabled',
                        '[class.cub-slider-discrete]': 'discrete',
                        '[class.cub-slider-tick-marks]': 'showTickMarks',
                        '[class.cub-animation-noop-able]': '_noopAnimations',
                        '[class.cub-slider-small]': 'size === "small"',
                    }, exportAs: 'cubSlider', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, inputs: ['disableRipple'], providers: [{ provide: CUB_SLIDER, useExisting: CubSlider }], imports: [CubSliderVisualThumb], template: "<!-- Inputs -->\n<ng-content></ng-content>\n\n<!-- Track -->\n<div class=\"cub-slider-track\">\n  <div class=\"cub-slider-track-inactive\"></div>\n  <div class=\"cub-slider-track-active\">\n    <div #trackActive class=\"cub-slider-track-active-fill\"></div>\n  </div>\n  @if (showTickMarks) {\n  <div class=\"cub-slider-tick-marks\" #tickMarkContainer>\n    @if (_cachedWidth) { @for (tickMark of _tickMarks; track $index; let i =\n    $index) { @if (i !== 0 && i !== _tickMarks.length - 1) {\n    <div\n      [class]=\"\n        tickMark === 0\n          ? 'cub-slider-tick-mark-active'\n          : 'cub-slider-tick-mark-inactive'\n      \"\n      [style.transform]=\"_calcTickMarkTransform(i)\"\n    >\n      <span class=\"cub-slider-tick-mark-value\">\n        {{ min + tickStep * i }}\n      </span>\n    </div>\n    } } }\n  </div>\n  }\n</div>\n\n<!-- Thumbs -->\n@if (_isRange) {\n<cub-slider-thumb\n  [discrete]=\"discrete\"\n  [thumbPosition]=\"1\"\n  [valueIndicatorText]=\"startValueIndicatorText\"\n>\n</cub-slider-thumb>\n}\n\n<cub-slider-thumb\n  [discrete]=\"discrete\"\n  [thumbPosition]=\"2\"\n  [valueIndicatorText]=\"endValueIndicatorText\"\n>\n</cub-slider-thumb>\n" }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i1.Platform }, { type: i0.ElementRef }, { type: i1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_RIPPLE_GLOBAL_OPTIONS]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { displayWith: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], showTickMarks: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], tickStep: [{
                type: Input
            }], step: [{
                type: Input
            }], displayWithChange: [{
                type: Output
            }], _trackActive: [{
                type: ViewChild,
                args: ['trackActive']
            }], _thumbs: [{
                type: ViewChildren,
                args: [CUB_SLIDER_VISUAL_THUMB]
            }], _input: [{
                type: ContentChild,
                args: [CUB_SLIDER_THUMB]
            }], _inputs: [{
                type: ContentChildren,
                args: [CUB_SLIDER_RANGE_THUMB, { descendants: false }]
            }] } });

const CUB_SLIDER_THUMB_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubSliderThumb),
    multi: true,
};
const CUB_SLIDER_RANGE_THUMB_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubSliderRangeThumb),
    multi: true,
};
class CubSliderThumb {
    get translateX() {
        if (this._slider.min >= this._slider.max) {
            this._translateX = 0;
            return this._translateX;
        }
        if (this._translateX === undefined) {
            this._translateX = this._calcTranslateXByValue();
        }
        return this._translateX;
    }
    set translateX(v) {
        this._translateX = v;
    }
    get min() {
        return coerceNumberProperty(this._hostElement.min);
    }
    set min(v) {
        this._hostElement.min = coerceNumberProperty(v).toString();
        this._cdr.detectChanges();
    }
    get max() {
        return coerceNumberProperty(this._hostElement.max);
    }
    set max(v) {
        this._hostElement.max = coerceNumberProperty(v).toString();
        this._cdr.detectChanges();
    }
    get step() {
        return coerceNumberProperty(this._hostElement.step);
    }
    set step(v) {
        this._hostElement.step = coerceNumberProperty(v).toString();
        this._cdr.detectChanges();
    }
    get disabled() {
        return coerceBooleanProperty(this._hostElement.disabled);
    }
    set disabled(v) {
        this._hostElement.disabled = coerceBooleanProperty(v);
        this._cdr.detectChanges();
        if (this._slider.disabled !== this.disabled) {
            this._slider.disabled = this.disabled;
        }
    }
    get percentage() {
        if (this._slider.min >= this._slider.max) {
            return this._slider._isRtl ? 1 : 0;
        }
        return ((this.value - this._slider.min) / (this._slider.max - this._slider.min));
    }
    get fillPercentage() {
        if (!this._slider._cachedWidth) {
            return this._slider._isRtl ? 1 : 0;
        }
        if (this._translateX === 0) {
            return 0;
        }
        return this.translateX / this._slider._cachedWidth;
    }
    /** 元件輸入的當前值，預設為 undefined。 */
    get value() {
        return coerceNumberProperty(this._hostElement.value);
    }
    set value(value) {
        const val = coerceNumberProperty(value).toString();
        if (!this._hasSetInitialValue) {
            this._initialValue = val;
            return;
        }
        if (this._isActive) {
            return;
        }
        this._hostElement.value = val;
        this._updateThumbUIByValue();
        this._slider._onValueChange(this);
        this._cdr.detectChanges();
    }
    constructor(_ngZone, _elementRef, _cdr, _slider) {
        this._ngZone = _ngZone;
        this._elementRef = _elementRef;
        this._cdr = _cdr;
        this._slider = _slider;
        this.thumbPosition = 2 /* _CubThumb.END */;
        this._knobRadius = 8;
        this._isActive = false;
        this._isFocused = false;
        this._skipUIUpdate = false;
        this._destroyed = new Subject();
        this._hasSetInitialValue = false;
        /** 當 `value` 改變時發出的事件。 */
        this.valueChange = new EventEmitter();
        /** 當滑桿滑塊開始被拖拽時發出的事件。 */
        this.dragStart = new EventEmitter();
        /** 當滑桿滑塊停止被拖拽時發出的事件。 */
        this.dragEnd = new EventEmitter();
        this._onChangeFn = () => {
            void 0;
        };
        this._onTouchedFn = () => {
            void 0;
        };
        this._hostElement = _elementRef.nativeElement;
        this._ngZone.runOutsideAngular(() => {
            this._hostElement.addEventListener('pointerdown', this._onPointerDown.bind(this));
            this._hostElement.addEventListener('pointermove', this._onPointerMove.bind(this));
            this._hostElement.addEventListener('pointerup', this._onPointerUp.bind(this));
        });
    }
    ngOnDestroy() {
        this._hostElement.removeEventListener('pointerdown', this._onPointerDown);
        this._hostElement.removeEventListener('pointermove', this._onPointerMove);
        this._hostElement.removeEventListener('pointerup', this._onPointerUp);
        this._destroyed.next();
        this._destroyed.complete();
        this.dragStart.complete();
        this.dragEnd.complete();
    }
    initProps() {
        if (this.disabled !== this._slider.disabled) {
            this._slider.disabled = true;
        }
        this.step = this._slider.step;
        this.min = this._slider.min;
        this.max = this._slider.max;
        this._initValue();
    }
    initUI() {
        this._updateThumbUIByValue();
    }
    _initValue() {
        this._hasSetInitialValue = true;
        if (this._initialValue === undefined) {
            this.value = this._getDefaultValue();
        }
        else {
            this._hostElement.value = this._initialValue;
            this._updateThumbUIByValue();
            this._slider._onValueChange(this);
            this._cdr.detectChanges();
        }
    }
    _getDefaultValue() {
        return this.min;
    }
    _onBlur() {
        this._setIsFocused(false);
        this._onTouchedFn();
    }
    _onFocus() {
        this._setIsFocused(true);
    }
    _onChange() {
        this.valueChange.emit(this.value);
        if (this._isActive) {
            this._updateThumbUIByValue({ withAnimation: true });
        }
    }
    _onInput() {
        this._onChangeFn(this.value);
        if (this._slider.step || !this._isActive) {
            this._updateThumbUIByValue({ withAnimation: true });
        }
        this._slider._onValueChange(this);
    }
    _onNgControlValueChange() {
        if (!this._isActive || !this._isFocused) {
            this._slider._onValueChange(this);
            this._updateThumbUIByValue();
        }
        this._slider.disabled = this._formControl.disabled;
    }
    _onPointerDown(event) {
        if (this.disabled || event.button !== 0) {
            return;
        }
        this._isActive = true;
        this._setIsFocused(true);
        this._slider._updateDimensions();
        if (!this._slider.step) {
            this._updateThumbUIByPointerEvent(event, { withAnimation: true });
        }
        if (!this.disabled) {
            this._handleValueCorrection(event);
            this.dragStart.emit({
                source: this,
                parent: this._slider,
                value: this.value,
            });
        }
    }
    _fixValue(event) {
        const xPos = event.clientX - this._slider._cachedLeft;
        const width = this._slider._cachedWidth;
        const step = this._slider.step === 0 ? 1 : this._slider.step;
        const numSteps = Math.floor((this._slider.max - this._slider.min) / step);
        const percentage = this._slider._isRtl ? 1 - xPos / width : xPos / width;
        const fixedPercentage = Math.round(percentage * numSteps) / numSteps;
        const impreciseValue = fixedPercentage * (this._slider.max - this._slider.min) +
            this._slider.min;
        const value = Math.round(impreciseValue / step) * step;
        const prevValue = this.value;
        if (value === prevValue) {
            this._slider._onValueChange(this);
            this._slider.step > 0
                ? this._updateThumbUIByValue()
                : this._updateThumbUIByPointerEvent(event, {
                    withAnimation: this._slider._hasAnimation,
                });
            return;
        }
        this.value = value;
        this.valueChange.emit(this.value);
        this._onChangeFn(this.value);
        this._slider._onValueChange(this);
        this._slider.step > 0
            ? this._updateThumbUIByValue()
            : this._updateThumbUIByPointerEvent(event, {
                withAnimation: this._slider._hasAnimation,
            });
    }
    _onPointerMove(event) {
        if (!this._slider.step && this._isActive) {
            this._updateThumbUIByPointerEvent(event);
        }
    }
    _onPointerUp() {
        if (this._isActive) {
            this._isActive = false;
            this.dragEnd.emit({
                source: this,
                parent: this._slider,
                value: this.value,
            });
        }
    }
    _clamp(v) {
        return Math.max(Math.min(v, this._slider._cachedWidth), 0);
    }
    _calcTranslateXByValue() {
        if (this._slider._isRtl) {
            return (1 - this.percentage) * this._slider._cachedWidth;
        }
        return this.percentage * this._slider._cachedWidth;
    }
    _calcTranslateXByPointerEvent(event) {
        return event.clientX - this._slider._cachedLeft;
    }
    _updateThumbUIByValue(options) {
        this.translateX = this._clamp(this._calcTranslateXByValue());
        this._updateThumbUI(options);
    }
    _updateThumbUIByPointerEvent(event, options) {
        this.translateX = this._clamp(this._calcTranslateXByPointerEvent(event));
        this._updateThumbUI();
        this._onChange();
    }
    _updateThumbUI(options) {
        this._slider._setTransition(!!options?.withAnimation);
        this._slider._onTranslateXChange(this);
        this._slider._updateThumbUI(this);
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this._onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this._onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    focus() {
        this._hostElement.focus();
    }
    blur() {
        this._hostElement.blur();
    }
    _setIsFocused(v) {
        this._isFocused = v;
    }
    _handleValueCorrection(event) {
        this._skipUIUpdate = true;
        setTimeout(() => {
            this._skipUIUpdate = false;
            this._fixValue(event);
        }, 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderThumb, deps: [{ token: i0.NgZone }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: CUB_SLIDER }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSliderThumb, isStandalone: true, selector: "input[cubSliderThumb]", inputs: { value: "value" }, outputs: { valueChange: "valueChange", dragStart: "dragStart", dragEnd: "dragEnd" }, host: { attributes: { "type": "range" }, listeners: { "change": "_onChange()", "input": "_onInput()", "blur": "_onBlur()", "focus": "_onFocus()" }, properties: { "attr.aria-valuetext": "_valuetext", "tabindex": "0" }, classAttribute: "cub-slider-input" }, providers: [
            CUB_SLIDER_THUMB_VALUE_ACCESSOR,
            { provide: CUB_SLIDER_THUMB, useExisting: CubSliderThumb },
        ], exportAs: ["cubSliderThumb"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderThumb, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[cubSliderThumb]',
                    exportAs: 'cubSliderThumb',
                    host: {
                        class: 'cub-slider-input',
                        type: 'range',
                        '[attr.aria-valuetext]': '_valuetext',
                        '(change)': '_onChange()',
                        '(input)': '_onInput()',
                        '(blur)': '_onBlur()',
                        '(focus)': '_onFocus()',
                        '[tabindex]': '0',
                    },
                    providers: [
                        CUB_SLIDER_THUMB_VALUE_ACCESSOR,
                        { provide: CUB_SLIDER_THUMB, useExisting: CubSliderThumb },
                    ],
                }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_SLIDER]
                }] }], propDecorators: { value: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], dragStart: [{
                type: Output
            }], dragEnd: [{
                type: Output
            }] } });
class CubSliderRangeThumb extends CubSliderThumb {
    constructor(_ngZone, _slider, _elementRef, _cdr) {
        super(_ngZone, _elementRef, _cdr, _slider);
        this._cdr = _cdr;
        this._isEndThumb = this._hostElement.hasAttribute('cubSliderEndThumb');
        this._setIsLeftThumb();
        this.thumbPosition = this._isEndThumb ? 2 /* _CubThumb.END */ : 1 /* _CubThumb.START */;
    }
    getSibling() {
        if (!this._sibling) {
            this._sibling = this._slider._getInput(this._isEndThumb ? 1 /* _CubThumb.START */ : 2 /* _CubThumb.END */);
        }
        return this._sibling;
    }
    getMinPos() {
        const sibling = this.getSibling();
        if (!this._isLeftThumb && sibling) {
            return sibling.translateX;
        }
        return 0;
    }
    getMaxPos() {
        const sibling = this.getSibling();
        if (this._isLeftThumb && sibling) {
            return sibling.translateX;
        }
        return this._slider._cachedWidth;
    }
    _setIsLeftThumb() {
        this._isLeftThumb =
            (this._isEndThumb && this._slider._isRtl) ||
                (!this._isEndThumb && !this._slider._isRtl);
    }
    _getDefaultValue() {
        return this._isEndThumb && this._slider._isRange ? this.max : this.min;
    }
    _onInput() {
        super._onInput();
        this._updateSibling();
    }
    _onNgControlValueChange() {
        super._onNgControlValueChange();
        this.getSibling()?._updateMinMax();
    }
    _onPointerDown(event) {
        if (this.disabled) {
            return;
        }
        if (this._sibling) {
            this._sibling._hostElement.classList.add('cub-slider-input-no-pointer-events');
        }
        super._onPointerDown(event);
    }
    _onPointerUp() {
        super._onPointerUp();
        if (this._sibling) {
            setTimeout(() => {
                this._sibling._hostElement.classList.remove('cub-slider-input-no-pointer-events');
            });
        }
    }
    _onPointerMove(event) {
        super._onPointerMove(event);
        if (!this._slider.step && this._isActive) {
            this._updateSibling();
        }
    }
    _fixValue(event) {
        super._fixValue(event);
        this._sibling?._updateMinMax();
    }
    _clamp(v) {
        return Math.max(Math.min(v, this.getMaxPos()), this.getMinPos());
    }
    _updateMinMax() {
        const sibling = this.getSibling();
        if (!sibling) {
            return;
        }
        if (this._isEndThumb) {
            this.min = Math.max(this._slider.min, sibling.value);
            this.max = this._slider.max;
        }
        else {
            this.min = this._slider.min;
            this.max = Math.min(this._slider.max, sibling.value);
        }
    }
    writeValue(value) {
        this.value = value;
        this._updateSibling();
    }
    _updateStaticStyles() {
        this._hostElement.classList.toggle('cub-slider-right-input', !this._isLeftThumb);
    }
    _updateSibling() {
        const sibling = this.getSibling();
        if (!sibling) {
            return;
        }
        sibling._updateMinMax();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderRangeThumb, deps: [{ token: i0.NgZone }, { token: CUB_SLIDER }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSliderRangeThumb, isStandalone: true, selector: "input[cubSliderStartThumb], input[cubSliderEndThumb]", providers: [
            CUB_SLIDER_RANGE_THUMB_VALUE_ACCESSOR,
            { provide: CUB_SLIDER_RANGE_THUMB, useExisting: CubSliderRangeThumb },
        ], exportAs: ["cubSliderRangeThumb"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderRangeThumb, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[cubSliderStartThumb], input[cubSliderEndThumb]',
                    exportAs: 'cubSliderRangeThumb',
                    providers: [
                        CUB_SLIDER_RANGE_THUMB_VALUE_ACCESSOR,
                        { provide: CUB_SLIDER_RANGE_THUMB, useExisting: CubSliderRangeThumb },
                    ],
                }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_SLIDER]
                }] }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }] });

class CubSliderChange {
}

class CubSliderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubSliderModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubSlider,
            CubSliderVisualThumb,
            CubSliderThumb,
            CubSliderRangeThumb], exports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubSlider,
            CubSliderVisualThumb,
            CubSliderThumb,
            CubSliderRangeThumb] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule, CubFormFieldModule,
            CubLabelModule,
            CubInputModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSliderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubSlider,
                        CubSliderVisualThumb,
                        CubSliderThumb,
                        CubSliderRangeThumb,
                    ],
                    exports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubSlider,
                        CubSliderVisualThumb,
                        CubSliderThumb,
                        CubSliderRangeThumb,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/slider
 */
/* 參考來源：https://github.com/angular/components/tree/15.2.9/src/material/slider */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_SLIDER, CUB_SLIDER_RANGE_THUMB, CUB_SLIDER_RANGE_THUMB_VALUE_ACCESSOR, CUB_SLIDER_THUMB, CUB_SLIDER_THUMB_VALUE_ACCESSOR, CUB_SLIDER_VISUAL_THUMB, CubSlider, CubSliderChange, CubSliderModule, CubSliderRangeThumb, CubSliderThumb, CubSliderVisualThumb };
//# sourceMappingURL=cub-lib-view-rootng-component-slider.mjs.map
