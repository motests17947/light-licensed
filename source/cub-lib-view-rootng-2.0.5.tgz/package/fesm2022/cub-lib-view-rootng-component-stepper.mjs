import * as i0 from '@angular/core';
import { Directive, EventEmitter, forwardRef, ContentChild, Output, Input, Inject, Optional, Component, inject, Renderer2, ContentChildren, ViewChildren, NgModule } from '@angular/core';
import { Subscription, switchMap, map, startWith, takeUntil } from 'rxjs';
import * as i1 from 'cub-lib-view-rootng/cdk/stepper';
import { CubCdkStep, STEPPER_GLOBAL_OPTIONS, CubCdkStepper, STEP_STATE, CubCdkStepperModule } from 'cub-lib-view-rootng/cdk/stepper';
import { TemplatePortal, CubCdkPortalOutlet } from 'cub-lib-view-rootng/cdk/portal';
import { CubRipple } from 'cub-lib-view-rootng/component/common';
import { NgTemplateOutlet, NgClass } from '@angular/common';
import { FocusKeyManager } from 'cub-lib-view-rootng/cdk/a11y';
import { hasModifierKey, SPACE, ENTER, RIGHT_ARROW, DOWN_ARROW, LEFT_ARROW, UP_ARROW } from 'cub-lib-view-rootng/cdk/keycodes';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';
import * as i1$1 from 'cub-lib-view-rootng/cdk/bidi';
import * as i2 from '@angular/router';
import { NavigationEnd, RouterLink, RouterLinkWithHref } from '@angular/router';
import { filter, takeUntil as takeUntil$1 } from 'rxjs/operators';

class CubStepContent {
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepContent, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubStepContent, isStandalone: true, selector: "ng-template[cubStepContent]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepContent, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[cubStepContent]' }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

class CubStep extends CubCdkStep {
    constructor(stepper, viewContainerRef, stepperOptions) {
        super(stepper, stepperOptions);
        this.viewContainerRef = viewContainerRef;
        this.selectedStateSubscription = Subscription.EMPTY;
        /** 元件是否禁用，預設為 false。 */
        this.disabled = false;
        /** 路由匹配是否需要完全符合，預設為 false。 */
        this.exact = false;
        /** 步驟的加載狀態，預設為 false。 */
        this.loading = false;
        /** 步驟的副標題，預設為 ''。 */
        this.description = '';
        /** 路由鏈接，可以是字符串或數組，預設為 null。 */
        this.routerLink = null;
        /** 路由查詢參數，預設為 null。 */
        this.queryParams = null;
        /** 查詢參數處理方式，預設為 null。 */
        this.queryParamsHandling = null;
        /** 步驟選擇事件 */
        this.selectHandler = new EventEmitter();
    }
    ngAfterContentInit() {
        this.selectedStateSubscription = this._stepper.steps.changes
            .pipe(switchMap(() => {
            return this._stepper.selectionChange.pipe(map((event) => event.selectedStep === this), startWith(this._stepper.selected === this));
        }))
            .subscribe((isSelected) => {
            if (isSelected && this.lazyContent && !this.portal) {
                this.portal = new TemplatePortal(this.lazyContent.templateRef, this.viewContainerRef);
            }
        });
    }
    ngOnDestroy() {
        this.selectedStateSubscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStep, deps: [{ token: forwardRef(() => CubCdkStepper) }, { token: i0.ViewContainerRef }, { token: STEPPER_GLOBAL_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubStep, isStandalone: true, selector: "cub-step", inputs: { disabled: "disabled", exact: "exact", loading: "loading", description: "description", icon: "icon", routerLink: "routerLink", queryParams: "queryParams", queryParamsHandling: "queryParamsHandling" }, outputs: { selectHandler: "selectHandler" }, providers: [{ provide: CubCdkStep, useExisting: CubStep }], queries: [{ propertyName: "lazyContent", first: true, predicate: CubStepContent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<ng-template>\n  <ng-content></ng-content>\n  <ng-template [cubCdkPortalOutlet]=\"portal\"></ng-template>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: CubCdkPortalOutlet, selector: "[cubCdkPortalOutlet]", inputs: ["cubCdkPortalOutlet"], outputs: ["attached"], exportAs: ["cubCdkPortalOutlet"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStep, decorators: [{
            type: Component,
            args: [{ selector: 'cub-step', providers: [{ provide: CubCdkStep, useExisting: CubStep }], imports: [CubCdkPortalOutlet], template: "<ng-template>\n  <ng-content></ng-content>\n  <ng-template [cubCdkPortalOutlet]=\"portal\"></ng-template>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.CubCdkStepper, decorators: [{
                    type: Inject,
                    args: [forwardRef(() => CubCdkStepper)]
                }] }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [STEPPER_GLOBAL_OPTIONS]
                }] }], propDecorators: { disabled: [{
                type: Input
            }], exact: [{
                type: Input
            }], loading: [{
                type: Input
            }], description: [{
                type: Input
            }], icon: [{
                type: Input
            }], routerLink: [{
                type: Input
            }], queryParams: [{
                type: Input
            }], queryParamsHandling: [{
                type: Input
            }], selectHandler: [{
                type: Output
            }], lazyContent: [{
                type: ContentChild,
                args: [CubStepContent, { static: false }]
            }] } });

class CubStepHeader {
    constructor(elementRef) {
        this.elementRef = elementRef;
        /** Tab 鍵的控制項索引值，預設為 0。 */
        this.tabIndex = 0;
        /** 是否為啟用狀態，預設為 false。 */
        this.active = false;
        /** 是否為被選取狀態，預設為 false。 */
        this.selected = false;
        /** 是否為禁用狀態，預設為 false。 */
        this.disabled = false;
    }
    focus() {
        this.elementRef.nativeElement.focus();
    }
    _getHostElement() {
        return this.elementRef.nativeElement;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepHeader, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubStepHeader, isStandalone: true, selector: "cub-step-header", inputs: { id: "id", tabIndex: "tabIndex", active: "active", selected: "selected", disabled: "disabled" }, host: { properties: { "attr.id": "id", "attr.tabIndex": "tabIndex", "attr.aria-selected": "selected", "attr.aria-disabled": "disabled ? true : null", "class.cub-active": "active", "class.cub-selected": "selected", "class.cub-disabled": "disabled" }, classAttribute: "cub-step-header" }, ngImport: i0, template: "<ng-content></ng-content>\n\n<span\n  cubRipple\n  cubRippleClass=\"cub-stepper-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-stepper-persistent-ripple\"></span>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-step-header', host: {
                        class: 'cub-step-header',
                        '[attr.id]': 'id',
                        '[attr.tabIndex]': 'tabIndex',
                        '[attr.aria-selected]': 'selected',
                        '[attr.aria-disabled]': 'disabled ? true : null',
                        '[class.cub-active]': 'active',
                        '[class.cub-selected]': 'selected',
                        '[class.cub-disabled]': 'disabled',
                    }, imports: [CubRipple], template: "<ng-content></ng-content>\n\n<span\n  cubRipple\n  cubRippleClass=\"cub-stepper-ripple\"\n  [cubRippleDisabled]=\"disabled\"\n  [cubRippleTrigger]=\"_getHostElement()\"\n></span>\n<span class=\"cub-persistent-ripple cub-stepper-persistent-ripple\"></span>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { id: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], active: [{
                type: Input
            }], selected: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

// CubCdkStepper 需要在 CubStepper 先 imports，為避免 CubCdkStepperPrevious、CubCdkStepperNext，找不到宿主。
class CubStepper extends CubCdkStepper {
    /** 當前選中的步驟索引，預設為 0。 */
    get selectedIndex() {
        return super.selectedIndex;
    }
    set selectedIndex(index) {
        super.selectedIndex = index;
        if (this.keyManager) {
            this.keyManager.setActiveItem(super.selectedIndex);
        }
    }
    /** 步驟器排列方向，預設為 'horizontal'。 */
    get orientation() {
        return super.orientation;
    }
    set orientation(value) {
        super.orientation = value;
    }
    constructor(dir, changeDetectorRef, elementRef) {
        super(dir, changeDetectorRef, elementRef);
        this.render2 = inject(Renderer2);
        this.showLoading = true;
        this.RESIZE_DEBOUNCE_TIME = 200;
        this.LINE_MARGIN = 16;
        this.isDestroyed = false;
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 標籤文字排列位置，預設為 'horizontal'。 */
        this.labelOrientation = 'horizontal';
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.keyManager = new FocusKeyManager(this.stepHeaderList)
            .withWrap()
            .withHomeAndEnd()
            .withVerticalOrientation(this.orientation === 'vertical');
        this.keyManager.updateActiveItem(this.selectedIndex);
        this.updateLinePositions();
        this.setupWindowResize();
        // 監聽 stepList 變化，當 step 數量改變時重新計算連接線位置
        this.stepList.changes.pipe(takeUntil(this._destroyed)).subscribe(() => {
            // 使用 requestAnimationFrame 確保 DOM 完全渲染後再計算位置
            requestAnimationFrame(() => {
                this.updateLinePositions();
            });
        });
    }
    ngOnDestroy() {
        this.isDestroyed = true;
        if (this.debounceTimer) {
            window.clearTimeout(this.debounceTimer);
        }
        if (this.resizeListener) {
            window.removeEventListener('resize', this.resizeListener);
        }
        super.ngOnDestroy();
    }
    isActive(index) {
        return this.selectedIndex === index;
    }
    isCompleted(index, step) {
        if (this.linear) {
            return (
            // step 的 completed 為 true && step 的順序在當前選中的 step 前面 && step 不能有錯誤
            step.completed && this.selectedIndex > index && !Boolean(step.hasError));
        }
        else {
            return (
            // step 的 completed 為 true && step 的 state 為 EDIT  && step 不能有錯誤
            step.completed &&
                this._getIndicatorType(index, step.state) === STEP_STATE.EDIT &&
                !Boolean(step.hasError));
        }
    }
    isError(index, step) {
        return (
        // step 不能是 Active && step 不能是 Completed && (step 有 stepControl 錯誤並且有互動過 || 接口 hasError 為 true)
        !this.isActive(index) &&
            !this.isCompleted(index, step) &&
            ((step.stepControl && step.stepControl.invalid && step.interacted) ||
                Boolean(step.hasError)));
    }
    isDisabled(index, step) {
        if (step.disabled) {
            return true;
        }
        if (this.linear) {
            const stepsArray = this.steps.toArray();
            const previousStep = index > 0 ? stepsArray[index - 1] : null;
            const isPreviousStepHasStepControl = previousStep && previousStep.stepControl;
            const isPreviousStepValid = isPreviousStepHasStepControl && previousStep.stepControl.valid;
            const isPreviousStepInteracted = previousStep && previousStep.interacted;
            if (this.isActive(index)) {
                return false;
            }
            if (this.isCompleted(index, step)) {
                return false;
            }
            if (this.isError(index, step)) {
                return false;
            }
            if (this._getIndicatorType(index, step.state) === STEP_STATE.EDIT) {
                return false;
            }
            // 前一個 step 沒有 stepControl && ( step 是當前選中的 step 後面一位 || 前一個 step 有互動過)
            if (!isPreviousStepHasStepControl &&
                (index === this.selectedIndex + 1 || isPreviousStepInteracted)) {
                return false;
            }
            if (isPreviousStepValid || step.interacted) {
                return false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    selectStep(index, step) {
        if (step.selectHandler.observers.length > 0) {
            step.selectHandler.emit(step);
        }
        else {
            if (this.isDisabled(index, step)) {
                return;
            }
            step.select();
        }
        // 在狀態切換後重新渲染 Loading，為解決 ios loading svg 顏色延遲的問題。
        this.reRenderLoading();
    }
    getFocusIndex() {
        return this.keyManager
            ? this.keyManager.activeItemIndex
            : this.selectedIndex;
    }
    onKeydown(event) {
        const hasModifier = hasModifierKey(event);
        const keyCode = event.keyCode;
        const manager = this.keyManager;
        const isHorizontal = this.orientation === 'horizontal';
        if (manager.activeItemIndex != null &&
            !hasModifier &&
            (keyCode === SPACE || keyCode === ENTER)) {
            this.selectedIndex = manager.activeItemIndex;
        }
        else if (manager.activeItemIndex != null &&
            !hasModifier &&
            ((isHorizontal && keyCode === RIGHT_ARROW) ||
                (!isHorizontal && keyCode === DOWN_ARROW))) {
            manager.setActiveItem(this.nextFocusIndex(manager.activeItemIndex));
        }
        else if (manager.activeItemIndex != null &&
            !hasModifier &&
            ((isHorizontal && keyCode === LEFT_ARROW) ||
                (!isHorizontal && keyCode === UP_ARROW))) {
            manager.setActiveItem(this.previousFocusIndex(manager.activeItemIndex));
        }
        else {
            manager.onKeydown(event);
        }
    }
    nextFocusIndex(currentIndex) {
        const stepListLength = this.stepList.length;
        const nextIndex = currentIndex === stepListLength - 1 ? 0 : currentIndex + 1;
        const nextStep = this.stepList.get(nextIndex);
        if (this.isDisabled(nextIndex, nextStep)) {
            return this.nextFocusIndex(nextIndex);
        }
        else {
            return nextIndex;
        }
    }
    previousFocusIndex(currentIndex) {
        const stepListLength = this.stepList.length;
        const previousIndex = currentIndex === 0 ? stepListLength - 1 : currentIndex - 1;
        const previousStep = this.stepList.get(previousIndex);
        if (this.isDisabled(previousIndex, previousStep)) {
            return this.previousFocusIndex(previousIndex);
        }
        else {
            return previousIndex;
        }
    }
    getLoadingColor(index, step) {
        if (this.isCompleted(index, step)) {
            return 'brand';
        }
        if (this.isError(index, step)) {
            return 'error';
        }
        if (this.isActive(index)) {
            return 'brand-contrast';
        }
        return 'neutral';
    }
    reRenderLoading() {
        this.showLoading = false;
        setTimeout(() => {
            this.showLoading = true;
        }, 10);
    }
    /** trackBy 函數：確保 Angular 能正確追蹤 step 項目 */
    trackByStep(index, step) {
        return step.label ? `${step.label}-${index}` : index;
    }
    /** Returns a unique id for the given step label. */
    _getStepLabelId(i) {
        return `cub-step-label-${this._groupId}-${i}`;
    }
    /** Returns a unique id for the given step content. */
    _getStepContentId(i) {
        return `cub-step-content-${this._groupId}-${i}`;
    }
    getStepHeaderByIndex(index) {
        if (!this.stepHeaderList ||
            index < 0 ||
            index >= this.stepHeaderList.length) {
            return null;
        }
        const stepHeaderComponent = this.stepHeaderList.toArray()[index];
        return stepHeaderComponent?.elementRef?.nativeElement || null;
    }
    calculateLinePosition(labelElement, parentElement) {
        const labelRect = labelElement.getBoundingClientRect();
        const parentRect = parentElement.getBoundingClientRect();
        const labelLeftInParent = labelRect.left - parentRect.left;
        const availableWidth = parentRect.width - labelLeftInParent - labelRect.width;
        const leftOffset = availableWidth - this.LINE_MARGIN;
        return { leftOffset: Math.max(0, leftOffset) };
    }
    sortByDataIndex(elements) {
        return elements.sort((a, b) => {
            const aElement = a.nativeElement || a.elementRef.nativeElement;
            const bElement = b.nativeElement || b.elementRef.nativeElement;
            // 讀取 data-step-index 屬性
            const aIndex = parseInt(aElement.getAttribute('data-step-index') || '0', 10);
            const bIndex = parseInt(bElement.getAttribute('data-step-index') || '0', 10);
            return aIndex - bIndex;
        });
    }
    /**
     * 更新所有連接線的位置
     * 使用 data-step-index 屬性配對 stepHeader 和 lineBar，
     * 確保在動態 @if 插入/移除時對應關係正確
     */
    updateLinePositions() {
        if (!this.stepHeaderList || !this.lineBar) {
            return;
        }
        // 按照 data-step-index 排序，確保與數據順序一致
        const sortedStepHeaders = this.sortByDataIndex(this.stepHeaderList.toArray());
        const sortedLineBar = this.sortByDataIndex(this.lineBar.toArray());
        // 遍歷 lineBar，每條線對應一個 stepHeader
        sortedLineBar.forEach((lineElementRef, index) => {
            if (index < sortedStepHeaders.length) {
                const stepHeader = sortedStepHeaders[index];
                const stepHeaderElement = stepHeader.elementRef.nativeElement;
                const labelElement = stepHeaderElement.querySelector('.cub-stepper-label');
                if (labelElement && lineElementRef?.nativeElement) {
                    const { leftOffset } = this.calculateLinePosition(labelElement, stepHeaderElement);
                    this.render2.setStyle(lineElementRef.nativeElement, 'left', `-${leftOffset}px`);
                }
            }
        });
    }
    /** 設置視窗大小監聽 */
    setupWindowResize() {
        this.resizeListener = () => {
            if (this.debounceTimer) {
                window.clearTimeout(this.debounceTimer);
            }
            this.debounceTimer = window.setTimeout(() => {
                if (!this.isDestroyed) {
                    this.updateLinePositions();
                }
            }, this.RESIZE_DEBOUNCE_TIME);
        };
        window.addEventListener('resize', this.resizeListener, { passive: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepper, deps: [{ token: i1$1.Directionality, optional: true }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubStepper, isStandalone: true, selector: "cub-stepper", inputs: { size: "size", selectedIndex: "selectedIndex", orientation: "orientation", labelOrientation: "labelOrientation" }, providers: [{ provide: CubCdkStepper, useExisting: CubStepper }], queries: [{ propertyName: "stepList", predicate: CubStep, descendants: true }], viewQueries: [{ propertyName: "stepHeaderList", predicate: CubStepHeader, descendants: true }, { propertyName: "lineBar", predicate: ["lineBar"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"cub-stepper\"\n  [class.cub-stepper-vertical]=\"orientation === 'vertical'\"\n  [class.cub-stepper-collapse]=\"orientation === 'collapse'\"\n  [class.cub-stepper-small]=\"size === 'small'\"\n>\n  @switch (orientation) {\n    <!-- \u5782\u76F4\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u53F3\u5074\uFF09-->\n    @case (\"vertical\") {\n      <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n        @for (\n          step of steps;\n          track step;\n          let index = $index;\n          let isLast = $last\n        ) {\n          <ng-container\n            [ngTemplateOutlet]=\"stepHeaderTemplate\"\n            [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n          ></ng-container>\n        }\n      </div>\n      <div\n        class=\"cub-stepper-content\"\n        [id]=\"_getStepContentId(selectedIndex)\"\n        [attr.aria-labelledby]=\"_getStepLabelId(selectedIndex)\"\n        role=\"tabpanel\"\n      >\n        <ng-container\n          [ngTemplateOutlet]=\"selected?.content ?? null\"\n        ></ng-container>\n      </div>\n    }\n    <!-- \u6536\u5408\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u7576\u524D\u4E0B\u65B9\uFF09-->\n    @case (\"collapse\") {\n      <div class=\"cub-stepper-collapse-container\" (keydown)=\"onKeydown($event)\">\n        @for (\n          step of steps;\n          track step;\n          let index = $index;\n          let isLast = $last\n        ) {\n          <div\n            class=\"cub-stepper-collapse-step\"\n            [class.cub-stepper-collapse-step-active]=\"selectedIndex === index\"\n          >\n            <!-- \u6B65\u9A5F\u6A19\u984C -->\n            <ng-container\n              [ngTemplateOutlet]=\"stepHeaderTemplate\"\n              [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n            ></ng-container>\n\n            <!-- \u6B65\u9A5F\u5167\u5BB9\uFF08\u53EA\u6709\u7576\u524D\u9078\u4E2D\u7684\u986F\u793A\uFF09-->\n            @if (selectedIndex === index) {\n              <div\n                class=\"cub-stepper-collapse-step-content\"\n                role=\"tabpanel\"\n                [id]=\"_getStepContentId(index)\"\n                [attr.aria-labelledby]=\"_getStepLabelId(index)\"\n              >\n                <div class=\"cub-stepper-collapse-step-content-inner\">\n                  <ng-container\n                    [ngTemplateOutlet]=\"step.content ?? null\"\n                  ></ng-container>\n                </div>\n              </div>\n            }\n          </div>\n        }\n      </div>\n    }\n    <!-- \u6C34\u5E73\u4F48\u5C40 -->\n    @default {\n      <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n        @for (\n          step of steps;\n          track trackByStep($index, step);\n          let index = $index;\n          let isLast = $last\n        ) {\n          <ng-container\n            [ngTemplateOutlet]=\"stepHeaderTemplate\"\n            [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n          ></ng-container>\n          @if (!isLast) {\n            <div class=\"cub-stepper-line\">\n              <div\n                class=\"cub-stepper-line-bar\"\n                #lineBar\n                [attr.data-step-index]=\"index\"\n              ></div>\n            </div>\n          }\n        }\n      </div>\n      <div\n        class=\"cub-stepper-content\"\n        [id]=\"_getStepContentId(selectedIndex)\"\n        [attr.aria-labelledby]=\"_getStepLabelId(selectedIndex)\"\n        role=\"tabpanel\"\n      >\n        <ng-container\n          [ngTemplateOutlet]=\"selected?.content ?? null\"\n        ></ng-container>\n      </div>\n    }\n  }\n</div>\n\n<!-- \u5171\u7528\u6B65\u9A5F\u6A19\u984C\u6A21\u677F -->\n<ng-template let-step=\"step\" let-index=\"index\" #stepHeaderTemplate>\n  <cub-step-header\n    [id]=\"_getStepLabelId(index)\"\n    [tabIndex]=\"getFocusIndex() === index ? 0 : -1\"\n    [active]=\"isActive(index)\"\n    [disabled]=\"isDisabled(index, step)\"\n    [selected]=\"selectedIndex === index\"\n    [class.cub-step-header-completed]=\"isCompleted(index, step)\"\n    [class.cub-step-header-error]=\"isError(index, step)\"\n    [class.cub-stepper-link-vertical]=\"labelOrientation === 'vertical'\"\n    [attr.aria-posinset]=\"index + 1\"\n    [attr.aria-setsize]=\"steps.length\"\n    [attr.aria-controls]=\"_getStepContentId(index)\"\n    [attr.data-step-index]=\"index\"\n    (click)=\"selectStep(index, step)\"\n  >\n    <div class=\"cub-stepper-link\">\n      @if (isCompleted(index, step)) {\n        <div class=\"cub-stepper-label-container\">\n          <span class=\"cub-step-icon\">\n            @if (step.loading && showLoading) {\n              <cub-loading\n                [size]=\"size\"\n                [color]=\"getLoadingColor(index, step)\"\n              ></cub-loading>\n            } @else {\n              <span class=\"cub-step-icon-wrapper cub-icon-check\"></span>\n            }\n          </span>\n          <span class=\"cub-stepper-label\">{{ step.label }}</span>\n        </div>\n        @if (step.description) {\n          <span class=\"cub-stepper-description\">{{ step.description }}</span>\n        }\n      }\n      @if (!isCompleted(index, step)) {\n        <div class=\"cub-stepper-label-container\">\n          <span class=\"cub-step-icon\">\n            @if (step.loading && showLoading) {\n              <span class=\"cub-step-icon-wrapper\">\n                <cub-loading\n                  [size]=\"size\"\n                  [color]=\"getLoadingColor(index, step)\"\n                ></cub-loading>\n              </span>\n            } @else if (step.hasError && !(selectedIndex === index)) {\n              <span\n                class=\"cub-step-icon-wrapper\"\n                [ngClass]=\"{ 'cub-icon-x': step.hasError }\"\n              >\n              </span>\n            } @else if (step.icon) {\n              <span class=\"cub-step-icon-wrapper\" [class]=\"step.icon\"> </span>\n            } @else {\n              <span class=\"cub-step-icon-wrapper\"> {{ index + 1 }} </span>\n            }\n          </span>\n          <span class=\"cub-stepper-label\">\n            {{ step.label }}\n          </span>\n        </div>\n        @if (step.description) {\n          <span class=\"cub-stepper-description\">\n            {{ step.description }}\n          </span>\n        }\n      }\n    </div>\n  </cub-step-header>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubStepHeader, selector: "cub-step-header", inputs: ["id", "tabIndex", "active", "selected", "disabled"] }, { kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepper, decorators: [{
            type: Component,
            args: [{ selector: 'cub-stepper', providers: [{ provide: CubCdkStepper, useExisting: CubStepper }], imports: [
                        NgTemplateOutlet,
                        CubStepHeader,
                        CubLoading,
                        CubCdkStepper,
                        NgClass,
                    ], template: "<div\n  class=\"cub-stepper\"\n  [class.cub-stepper-vertical]=\"orientation === 'vertical'\"\n  [class.cub-stepper-collapse]=\"orientation === 'collapse'\"\n  [class.cub-stepper-small]=\"size === 'small'\"\n>\n  @switch (orientation) {\n    <!-- \u5782\u76F4\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u53F3\u5074\uFF09-->\n    @case (\"vertical\") {\n      <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n        @for (\n          step of steps;\n          track step;\n          let index = $index;\n          let isLast = $last\n        ) {\n          <ng-container\n            [ngTemplateOutlet]=\"stepHeaderTemplate\"\n            [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n          ></ng-container>\n        }\n      </div>\n      <div\n        class=\"cub-stepper-content\"\n        [id]=\"_getStepContentId(selectedIndex)\"\n        [attr.aria-labelledby]=\"_getStepLabelId(selectedIndex)\"\n        role=\"tabpanel\"\n      >\n        <ng-container\n          [ngTemplateOutlet]=\"selected?.content ?? null\"\n        ></ng-container>\n      </div>\n    }\n    <!-- \u6536\u5408\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u7576\u524D\u4E0B\u65B9\uFF09-->\n    @case (\"collapse\") {\n      <div class=\"cub-stepper-collapse-container\" (keydown)=\"onKeydown($event)\">\n        @for (\n          step of steps;\n          track step;\n          let index = $index;\n          let isLast = $last\n        ) {\n          <div\n            class=\"cub-stepper-collapse-step\"\n            [class.cub-stepper-collapse-step-active]=\"selectedIndex === index\"\n          >\n            <!-- \u6B65\u9A5F\u6A19\u984C -->\n            <ng-container\n              [ngTemplateOutlet]=\"stepHeaderTemplate\"\n              [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n            ></ng-container>\n\n            <!-- \u6B65\u9A5F\u5167\u5BB9\uFF08\u53EA\u6709\u7576\u524D\u9078\u4E2D\u7684\u986F\u793A\uFF09-->\n            @if (selectedIndex === index) {\n              <div\n                class=\"cub-stepper-collapse-step-content\"\n                role=\"tabpanel\"\n                [id]=\"_getStepContentId(index)\"\n                [attr.aria-labelledby]=\"_getStepLabelId(index)\"\n              >\n                <div class=\"cub-stepper-collapse-step-content-inner\">\n                  <ng-container\n                    [ngTemplateOutlet]=\"step.content ?? null\"\n                  ></ng-container>\n                </div>\n              </div>\n            }\n          </div>\n        }\n      </div>\n    }\n    <!-- \u6C34\u5E73\u4F48\u5C40 -->\n    @default {\n      <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n        @for (\n          step of steps;\n          track trackByStep($index, step);\n          let index = $index;\n          let isLast = $last\n        ) {\n          <ng-container\n            [ngTemplateOutlet]=\"stepHeaderTemplate\"\n            [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n          ></ng-container>\n          @if (!isLast) {\n            <div class=\"cub-stepper-line\">\n              <div\n                class=\"cub-stepper-line-bar\"\n                #lineBar\n                [attr.data-step-index]=\"index\"\n              ></div>\n            </div>\n          }\n        }\n      </div>\n      <div\n        class=\"cub-stepper-content\"\n        [id]=\"_getStepContentId(selectedIndex)\"\n        [attr.aria-labelledby]=\"_getStepLabelId(selectedIndex)\"\n        role=\"tabpanel\"\n      >\n        <ng-container\n          [ngTemplateOutlet]=\"selected?.content ?? null\"\n        ></ng-container>\n      </div>\n    }\n  }\n</div>\n\n<!-- \u5171\u7528\u6B65\u9A5F\u6A19\u984C\u6A21\u677F -->\n<ng-template let-step=\"step\" let-index=\"index\" #stepHeaderTemplate>\n  <cub-step-header\n    [id]=\"_getStepLabelId(index)\"\n    [tabIndex]=\"getFocusIndex() === index ? 0 : -1\"\n    [active]=\"isActive(index)\"\n    [disabled]=\"isDisabled(index, step)\"\n    [selected]=\"selectedIndex === index\"\n    [class.cub-step-header-completed]=\"isCompleted(index, step)\"\n    [class.cub-step-header-error]=\"isError(index, step)\"\n    [class.cub-stepper-link-vertical]=\"labelOrientation === 'vertical'\"\n    [attr.aria-posinset]=\"index + 1\"\n    [attr.aria-setsize]=\"steps.length\"\n    [attr.aria-controls]=\"_getStepContentId(index)\"\n    [attr.data-step-index]=\"index\"\n    (click)=\"selectStep(index, step)\"\n  >\n    <div class=\"cub-stepper-link\">\n      @if (isCompleted(index, step)) {\n        <div class=\"cub-stepper-label-container\">\n          <span class=\"cub-step-icon\">\n            @if (step.loading && showLoading) {\n              <cub-loading\n                [size]=\"size\"\n                [color]=\"getLoadingColor(index, step)\"\n              ></cub-loading>\n            } @else {\n              <span class=\"cub-step-icon-wrapper cub-icon-check\"></span>\n            }\n          </span>\n          <span class=\"cub-stepper-label\">{{ step.label }}</span>\n        </div>\n        @if (step.description) {\n          <span class=\"cub-stepper-description\">{{ step.description }}</span>\n        }\n      }\n      @if (!isCompleted(index, step)) {\n        <div class=\"cub-stepper-label-container\">\n          <span class=\"cub-step-icon\">\n            @if (step.loading && showLoading) {\n              <span class=\"cub-step-icon-wrapper\">\n                <cub-loading\n                  [size]=\"size\"\n                  [color]=\"getLoadingColor(index, step)\"\n                ></cub-loading>\n              </span>\n            } @else if (step.hasError && !(selectedIndex === index)) {\n              <span\n                class=\"cub-step-icon-wrapper\"\n                [ngClass]=\"{ 'cub-icon-x': step.hasError }\"\n              >\n              </span>\n            } @else if (step.icon) {\n              <span class=\"cub-step-icon-wrapper\" [class]=\"step.icon\"> </span>\n            } @else {\n              <span class=\"cub-step-icon-wrapper\"> {{ index + 1 }} </span>\n            }\n          </span>\n          <span class=\"cub-stepper-label\">\n            {{ step.label }}\n          </span>\n        </div>\n        @if (step.description) {\n          <span class=\"cub-stepper-description\">\n            {{ step.description }}\n          </span>\n        }\n      }\n    </div>\n  </cub-step-header>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }], propDecorators: { size: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], orientation: [{
                type: Input
            }], labelOrientation: [{
                type: Input
            }], stepHeaderList: [{
                type: ViewChildren,
                args: [CubStepHeader]
            }], lineBar: [{
                type: ViewChildren,
                args: ['lineBar']
            }], stepList: [{
                type: ContentChildren,
                args: [CubStep, { descendants: true }]
            }] } });

// CubCdkStepper 需要在 CubNavStepper 先 imports，為避免 CubCdkStepperPrevious、CubCdkStepperNext，找不到宿主。
class CubNavStepper extends CubCdkStepper {
    /** 當前選中的步驟索引，預設為 0。 */
    get selectedIndex() {
        return super.selectedIndex;
    }
    set selectedIndex(index) {
        super.selectedIndex = index;
        setTimeout(() => {
            if (this.keyManager) {
                this.keyManager.setActiveItem(super.selectedIndex);
            }
        }, 0);
    }
    /** 步驟器排列方向，預設為 'horizontal'。 */
    get orientation() {
        return super.orientation;
    }
    set orientation(value) {
        super.orientation = value;
    }
    /** 目前選中的步驟物件，預設為 undefined。 */
    get selected() {
        return this.steps ? this.steps.toArray()[this.selectedIndex] : undefined;
    }
    set selected(step) {
        this.selectedIndex =
            step && this.steps ? this.steps.toArray().indexOf(step) : -1;
    }
    constructor(dir, changeDetectorRef, elementRef, router) {
        super(dir, changeDetectorRef, elementRef);
        this.dir = dir;
        this.changeDetectorRef = changeDetectorRef;
        this.elementRef = elementRef;
        this.router = router;
        this.render2 = inject(Renderer2);
        this.showLoading = true;
        this.RESIZE_DEBOUNCE_TIME = 200;
        this.LINE_MARGIN = 16;
        this.isDestroyed = false;
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /** 標籤文字排列位置，預設為 'horizontal'。 */
        this.labelOrientation = 'horizontal';
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.activeHandler();
        this.router.events
            .pipe(filter((event) => event instanceof NavigationEnd), takeUntil$1(this._destroyed))
            .subscribe(() => {
            this.activeHandler();
        });
        this.keyManager = new FocusKeyManager(this.stepHeaderList)
            .withWrap()
            .withHomeAndEnd()
            .withVerticalOrientation(this.orientation === 'vertical');
        this.keyManager.updateActiveItem(this.selectedIndex);
        this.updateLinePositions();
        this.setupWindowResize();
        // 監聽 stepList 變化，當 step 數量改變時重新計算連接線位置
        this.stepList.changes.pipe(takeUntil$1(this._destroyed)).subscribe(() => {
            // 使用 requestAnimationFrame 確保 DOM 完全渲染後再計算位置
            requestAnimationFrame(() => {
                this.updateLinePositions();
            });
        });
    }
    ngOnDestroy() {
        this.isDestroyed = true;
        if (this.debounceTimer) {
            window.clearTimeout(this.debounceTimer);
        }
        if (this.resizeListener) {
            window.removeEventListener('resize', this.resizeListener);
        }
        super.ngOnDestroy();
    }
    isActive(index) {
        return this.selectedIndex === index;
    }
    isCompleted(index, step) {
        if (this.linear) {
            return (
            // step 的 completed 為 true && step 的順序在當前選中的 step 前面 && step 不能有錯誤
            step.completed && this.selectedIndex > index && !Boolean(step.hasError));
        }
        else {
            return (
            // step 的 completed 為 true && step 的 state 為 EDIT  && step 不能有錯誤
            step.completed &&
                this._getIndicatorType(index, step.state) === STEP_STATE.EDIT &&
                !Boolean(step.hasError));
        }
    }
    isError(index, step) {
        return (
        // step 不能是 Active && step 不能是 Completed && (step 有 stepControl 錯誤並且有互動過 || 接口 hasError 為 true)
        !this.isActive(index) &&
            !this.isCompleted(index, step) &&
            ((step.stepControl && step.stepControl.invalid && step.interacted) ||
                Boolean(step.hasError)));
    }
    isDisabled(index, step) {
        if (step.disabled) {
            return true;
        }
        if (this.linear) {
            const stepsArray = this.steps.toArray();
            const previousStep = index > 0 ? stepsArray[index - 1] : null;
            const isPreviousStepHasStepControl = previousStep && previousStep.stepControl;
            const isPreviousStepValid = isPreviousStepHasStepControl && previousStep.stepControl.valid;
            const isPreviousStepInteracted = previousStep && previousStep.interacted;
            if (this.isActive(index)) {
                return false;
            }
            if (this.isCompleted(index, step)) {
                return false;
            }
            if (this.isError(index, step)) {
                return false;
            }
            if (this._getIndicatorType(index, step.state) === STEP_STATE.EDIT) {
                return false;
            }
            // 前一個 step 沒有 stepControl && ( step 是當前選中的 step 後面一位 || 前一個 step 有互動過)
            if (!isPreviousStepHasStepControl &&
                (index === this.selectedIndex + 1 || isPreviousStepInteracted)) {
                return false;
            }
            if (isPreviousStepValid || step.interacted) {
                return false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    selectStep(index, step) {
        if (step.selectHandler.observers.length > 0) {
            step.selectHandler.emit(step);
        }
        else if (this.canRedirect(index, step)) {
            step.select();
            // 為了先讓 Ripple 事件執行完畢，再執行 route 切換
            setTimeout(() => {
                this.router.navigate([step.routerLink], {
                    queryParams: step.queryParams,
                    queryParamsHandling: step.queryParamsHandling,
                });
            }, 200);
        }
        // 在狀態切換後重新渲染 Loading，為解決 ios loading svg 顏色延遲的問題。
        this.reRenderLoading();
    }
    getFocusIndex() {
        return this.keyManager
            ? this.keyManager.activeItemIndex
            : this.selectedIndex;
    }
    onKeydown(event) {
        const hasModifier = hasModifierKey(event);
        const keyCode = event.keyCode;
        const manager = this.keyManager;
        const isHorizontal = this.orientation === 'horizontal';
        if (manager.activeItemIndex != null &&
            !hasModifier &&
            (keyCode === SPACE || keyCode === ENTER)) {
            this.selectedIndex = manager.activeItemIndex;
            this.selectStep(this.selectedIndex, this.stepList.toArray()[this.selectedIndex]);
        }
        else if (manager.activeItemIndex != null &&
            !hasModifier &&
            ((isHorizontal && keyCode === RIGHT_ARROW) ||
                (!isHorizontal && keyCode === DOWN_ARROW))) {
            manager.setActiveItem(this.nextFocusIndex(manager.activeItemIndex));
        }
        else if (manager.activeItemIndex != null &&
            !hasModifier &&
            ((isHorizontal && keyCode === LEFT_ARROW) ||
                (!isHorizontal && keyCode === UP_ARROW))) {
            manager.setActiveItem(this.previousFocusIndex(manager.activeItemIndex));
        }
        else {
            manager.onKeydown(event);
        }
    }
    nextFocusIndex(currentIndex) {
        const stepListLength = this.stepList.length;
        const nextIndex = currentIndex === stepListLength - 1 ? 0 : currentIndex + 1;
        const nextStep = this.stepList.get(nextIndex);
        if (nextStep && this.isDisabled(nextIndex, nextStep)) {
            return this.nextFocusIndex(nextIndex);
        }
        else {
            return nextIndex;
        }
    }
    previousFocusIndex(currentIndex) {
        const stepListLength = this.stepList.length;
        const previousIndex = currentIndex === 0 ? stepListLength - 1 : currentIndex - 1;
        const previousStep = this.stepList.get(previousIndex);
        if (previousStep && this.isDisabled(previousIndex, previousStep)) {
            return this.previousFocusIndex(previousIndex);
        }
        else {
            return previousIndex;
        }
    }
    getLoadingColor(index, step) {
        if (this.isCompleted(index, step)) {
            return 'brand';
        }
        if (this.isError(index, step)) {
            return 'error';
        }
        if (this.isActive(index)) {
            return 'brand-contrast';
        }
        return 'neutral';
    }
    reRenderLoading() {
        this.showLoading = false;
        setTimeout(() => {
            this.showLoading = true;
        }, 10);
    }
    /** trackBy 函數：確保 Angular 能正確追蹤 step 項目 */
    trackByStep(index, step) {
        return step.label ? `${step.label}-${index}` : index;
    }
    getStepHeaderByIndex(index) {
        if (!this.stepHeaderList ||
            index < 0 ||
            index >= this.stepHeaderList.length) {
            return null;
        }
        const stepHeaderComponent = this.stepHeaderList.toArray()[index];
        return stepHeaderComponent?.elementRef?.nativeElement || null;
    }
    calculateLinePosition(labelElement, parentElement) {
        const labelRect = labelElement.getBoundingClientRect();
        const parentRect = parentElement.getBoundingClientRect();
        const labelLeftInParent = labelRect.left - parentRect.left;
        const availableWidth = parentRect.width - labelLeftInParent - labelRect.width;
        const leftOffset = availableWidth - this.LINE_MARGIN;
        return { leftOffset: Math.max(0, leftOffset) };
    }
    sortByDataIndex(elements) {
        return elements.sort((a, b) => {
            const aElement = a.nativeElement || a.elementRef.nativeElement;
            const bElement = b.nativeElement || b.elementRef.nativeElement;
            // 讀取 data-step-index 屬性
            const aIndex = parseInt(aElement.getAttribute('data-step-index') || '0', 10);
            const bIndex = parseInt(bElement.getAttribute('data-step-index') || '0', 10);
            return aIndex - bIndex;
        });
    }
    activeHandler() {
        const hasActiveLinks = this.hasActiveLinks();
        if (hasActiveLinks) {
            const activeLinksIndex = this.activeLinksIndex();
            const selectedIndex = Math.max(...activeLinksIndex);
            const selectedStep = this.steps.toArray()[selectedIndex];
            // 如果當 url 匹配到的 step 不能 Redirect，再跳轉回原本 step 的 url
            if (!this.canRedirect(selectedIndex, selectedStep)) {
                this.router.navigate([this.selected['routerLink']], {
                    queryParams: this.selected['queryParams'],
                    queryParamsHandling: this.selected['queryParamsHandling'],
                });
                return;
            }
            if (this.selectedIndex !== selectedIndex) {
                this.selectedIndex = selectedIndex;
            }
        }
        else {
            this.selectedIndex = 0;
        }
        this.changeDetectorRef.detectChanges();
    }
    hasActiveLinks() {
        const exact = this.steps.map((step) => step.exact);
        const isLinkActiveFn = () => (link, index) => {
            const hasCommand = link['commands']
                ? this.router.url.indexOf(link['commands'][0])
                : -1;
            return exact[index]
                ? this.router.isActive(link.urlTree, exact[index])
                : this.router.isActive(link.urlTree, exact[index]) || hasCommand > -1;
        };
        return (this.links.some(isLinkActiveFn()) ||
            this.linksWithHref.some(isLinkActiveFn()));
    }
    activeLinksIndex() {
        const exact = this.steps.map((step) => step.exact);
        const linksIndex = new Set([]);
        const activeLinksIndexFn = () => (link, index) => {
            const hasCommand = link['commands']
                ? this.router.url.indexOf(link['commands'][0])
                : -1;
            const isActive = exact[index]
                ? this.router.isActive(link.urlTree, exact[index])
                : this.router.isActive(link.urlTree, exact[index]) || hasCommand > -1;
            if (isActive) {
                linksIndex.add(index);
            }
        };
        this.links.forEach(activeLinksIndexFn());
        this.linksWithHref.forEach(activeLinksIndexFn());
        return Array.from(linksIndex);
    }
    canRedirect(index, step) {
        if (this.isDisabled(index, step)) {
            return false;
        }
        // stepper 為 linear && step 有錯誤 && step 的順序在當前選中的 step 後面 && 當前選中的 step 的 completed 為 false
        if (this.linear &&
            this.isError(index, step) &&
            index > this.selectedIndex &&
            !this.selected.completed) {
            return false;
        }
        return true;
    }
    /**
     * 更新所有連接線的位置
     * 使用 data-step-index 屬性配對 stepHeader 和 lineBar，
     * 確保在動態 @if 插入/移除時對應關係正確
     */
    updateLinePositions() {
        if (!this.stepHeaderList || !this.lineBar) {
            return;
        }
        // 按照 data-step-index 排序，確保與數據順序一致
        const sortedStepHeaders = this.sortByDataIndex(this.stepHeaderList.toArray());
        const sortedLineBar = this.sortByDataIndex(this.lineBar.toArray());
        // 遍歷 lineBar，每條線對應一個 stepHeader
        sortedLineBar.forEach((lineElementRef, index) => {
            if (index < sortedStepHeaders.length) {
                const stepHeader = sortedStepHeaders[index];
                const stepHeaderElement = stepHeader.elementRef.nativeElement;
                const labelElement = stepHeaderElement.querySelector('.cub-stepper-label');
                if (labelElement && lineElementRef?.nativeElement) {
                    const { leftOffset } = this.calculateLinePosition(labelElement, stepHeaderElement);
                    this.render2.setStyle(lineElementRef.nativeElement, 'left', `-${leftOffset}px`);
                }
            }
        });
    }
    /** 設置視窗大小監聽 */
    setupWindowResize() {
        this.resizeListener = () => {
            if (this.debounceTimer) {
                window.clearTimeout(this.debounceTimer);
            }
            this.debounceTimer = window.setTimeout(() => {
                if (!this.isDestroyed) {
                    this.updateLinePositions();
                }
            }, this.RESIZE_DEBOUNCE_TIME);
        };
        window.addEventListener('resize', this.resizeListener, { passive: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNavStepper, deps: [{ token: i1$1.Directionality }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubNavStepper, isStandalone: true, selector: "cub-nav-stepper", inputs: { size: "size", selectedIndex: "selectedIndex", orientation: "orientation", labelOrientation: "labelOrientation", selected: "selected" }, host: { properties: { "class.cub-nav-stepper-vertical": "this.orientation === \"vertical\"" }, classAttribute: "cub-nav-stepper" }, providers: [{ provide: CubCdkStepper, useExisting: CubNavStepper }], queries: [{ propertyName: "links", predicate: RouterLink, descendants: true }, { propertyName: "linksWithHref", predicate: RouterLinkWithHref, descendants: true }, { propertyName: "stepList", predicate: CubStep, descendants: true }], viewQueries: [{ propertyName: "lineBar", predicate: ["lineBar"], descendants: true }, { propertyName: "stepHeaderList", predicate: CubStepHeader, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"cub-stepper\"\n  [class.cub-stepper-vertical]=\"orientation === 'vertical'\"\n  [class.cub-stepper-collapse]=\"orientation === 'collapse'\"\n  [class.cub-stepper-small]=\"size === 'small'\"\n>\n  @switch (orientation) {\n  <!-- \u5782\u76F4\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u53F3\u5074\uFF09-->\n  @case('vertical'){\n  <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n    @for (step of steps; track step; let index = $index; let isLast = $last) {\n    <ng-container\n      [ngTemplateOutlet]=\"stepHeaderTemplate\"\n      [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n    ></ng-container>\n    }\n  </div>\n  }\n  <!-- \u6536\u5408\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u7576\u524D\u4E0B\u65B9\uFF09-->\n  @case('collapse'){\n  <div class=\"cub-stepper-collapse-container\" (keydown)=\"onKeydown($event)\">\n    @for (step of steps; track step; let index = $index; let isLast = $last) {\n    <div\n      class=\"cub-stepper-collapse-step\"\n      [class.cub-stepper-collapse-step-active]=\"selectedIndex === index\"\n    >\n      <!-- \u6B65\u9A5F\u6A19\u984C -->\n      <ng-container\n        [ngTemplateOutlet]=\"stepHeaderTemplate\"\n        [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n      ></ng-container>\n\n      <!-- \u6B65\u9A5F\u5167\u5BB9\uFF08\u53EA\u6709\u7576\u524D\u9078\u4E2D\u7684\u986F\u793A\uFF09-->\n      @if(selectedIndex === index){\n      <div class=\"cub-stepper-collapse-step-content\">\n        <div class=\"cub-stepper-collapse-step-content-inner\">\n          <ng-container [ngTemplateOutlet]=\"step.content\"></ng-container>\n        </div>\n      </div>\n      }\n    </div>\n    }\n  </div>\n  }\n  <!-- \u6C34\u5E73\u4F48\u5C40 -->\n  @default {\n  <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n    @for (step of steps; track trackByStep($index, step); let index = $index;\n    let isLast = $last) {\n    <ng-container\n      [ngTemplateOutlet]=\"stepHeaderTemplate\"\n      [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n    ></ng-container>\n    @if (!isLast) {\n    <div class=\"cub-stepper-line\">\n      <div\n        class=\"cub-stepper-line-bar\"\n        #lineBar\n        [attr.data-step-index]=\"index\"\n      ></div>\n    </div>\n    } }\n  </div>\n  } }\n</div>\n\n<!-- \u5171\u7528\u6B65\u9A5F\u6A19\u984C\u6A21\u677F -->\n<ng-template let-step=\"step\" let-index=\"index\" #stepHeaderTemplate>\n  <cub-step-header\n    [id]=\"_getStepLabelId(index)\"\n    [tabIndex]=\"getFocusIndex() === index ? 0 : -1\"\n    [active]=\"isActive(index)\"\n    [disabled]=\"isDisabled(index, step)\"\n    [selected]=\"selectedIndex === index\"\n    [class.cub-step-header-completed]=\"isCompleted(index, step)\"\n    [class.cub-step-header-error]=\"isError(index, step)\"\n    [class.cub-stepper-link-vertical]=\"labelOrientation === 'vertical'\"\n    [attr.aria-posinset]=\"index + 1\"\n    [attr.aria-setsize]=\"steps.length\"\n    [attr.aria-controls]=\"_getStepContentId(index)\"\n    [attr.data-step-index]=\"index\"\n    (click)=\"selectStep(index, step)\"\n  >\n    <a class=\"cub-stepper-link\">\n      @if (isCompleted(index, step)){\n      <div class=\"cub-stepper-label-container\">\n        <span class=\"cub-step-icon\">\n          @if (step.loading && showLoading) {\n          <cub-loading\n            [size]=\"size\"\n            [color]=\"getLoadingColor(index, step)\"\n          ></cub-loading>\n          } @else {\n          <span class=\"cub-step-icon-wrapper cub-icon-check\"></span>\n          }\n        </span>\n        <span class=\"cub-stepper-label\">{{ step.label }}</span>\n      </div>\n      @if(step.description){\n      <span class=\"cub-stepper-description\">{{ step.description }}</span>\n      } } @if (!isCompleted(index, step)){\n      <div class=\"cub-stepper-label-container\">\n        <span class=\"cub-step-icon\">\n          @if (step.loading && showLoading){\n          <span class=\"cub-step-icon-wrapper\">\n            <cub-loading\n              [size]=\"size\"\n              [color]=\"getLoadingColor(index, step)\"\n            ></cub-loading> </span\n          >} @else if(step.hasError && !(selectedIndex === index)){\n          <span\n            class=\"cub-step-icon-wrapper\"\n            [ngClass]=\"{ 'cub-icon-x': step.hasError }\"\n          >\n          </span>\n          } @else if (step.icon) {\n          <span class=\"cub-step-icon-wrapper\" [class]=\"step.icon\"></span>\n          } @else {\n          <span class=\"cub-step-icon-wrapper\"> {{ index + 1 }} </span>}\n        </span>\n        <span class=\"cub-stepper-label\">\n          {{ step.label }}\n        </span>\n      </div>\n      @if(step.description){\n      <span class=\"cub-stepper-description\"> {{ step.description }} </span>} }\n    </a>\n  </cub-step-header>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubStepHeader, selector: "cub-step-header", inputs: ["id", "tabIndex", "active", "selected", "disabled"] }, { kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNavStepper, decorators: [{
            type: Component,
            args: [{ selector: 'cub-nav-stepper', host: {
                        class: 'cub-nav-stepper',
                        '[class.cub-nav-stepper-vertical]': 'this.orientation === "vertical"',
                    }, providers: [{ provide: CubCdkStepper, useExisting: CubNavStepper }], imports: [
                        NgTemplateOutlet,
                        CubStepHeader,
                        CubLoading,
                        NgClass,
                        CubCdkStepper,
                    ], template: "<div\n  class=\"cub-stepper\"\n  [class.cub-stepper-vertical]=\"orientation === 'vertical'\"\n  [class.cub-stepper-collapse]=\"orientation === 'collapse'\"\n  [class.cub-stepper-small]=\"size === 'small'\"\n>\n  @switch (orientation) {\n  <!-- \u5782\u76F4\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u53F3\u5074\uFF09-->\n  @case('vertical'){\n  <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n    @for (step of steps; track step; let index = $index; let isLast = $last) {\n    <ng-container\n      [ngTemplateOutlet]=\"stepHeaderTemplate\"\n      [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n    ></ng-container>\n    }\n  </div>\n  }\n  <!-- \u6536\u5408\u4F48\u5C40\uFF08\u5167\u5BB9\u5728\u7576\u524D\u4E0B\u65B9\uFF09-->\n  @case('collapse'){\n  <div class=\"cub-stepper-collapse-container\" (keydown)=\"onKeydown($event)\">\n    @for (step of steps; track step; let index = $index; let isLast = $last) {\n    <div\n      class=\"cub-stepper-collapse-step\"\n      [class.cub-stepper-collapse-step-active]=\"selectedIndex === index\"\n    >\n      <!-- \u6B65\u9A5F\u6A19\u984C -->\n      <ng-container\n        [ngTemplateOutlet]=\"stepHeaderTemplate\"\n        [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n      ></ng-container>\n\n      <!-- \u6B65\u9A5F\u5167\u5BB9\uFF08\u53EA\u6709\u7576\u524D\u9078\u4E2D\u7684\u986F\u793A\uFF09-->\n      @if(selectedIndex === index){\n      <div class=\"cub-stepper-collapse-step-content\">\n        <div class=\"cub-stepper-collapse-step-content-inner\">\n          <ng-container [ngTemplateOutlet]=\"step.content\"></ng-container>\n        </div>\n      </div>\n      }\n    </div>\n    }\n  </div>\n  }\n  <!-- \u6C34\u5E73\u4F48\u5C40 -->\n  @default {\n  <div class=\"cub-stepper-header\" (keydown)=\"onKeydown($event)\">\n    @for (step of steps; track trackByStep($index, step); let index = $index;\n    let isLast = $last) {\n    <ng-container\n      [ngTemplateOutlet]=\"stepHeaderTemplate\"\n      [ngTemplateOutletContext]=\"{ step: step, index: index }\"\n    ></ng-container>\n    @if (!isLast) {\n    <div class=\"cub-stepper-line\">\n      <div\n        class=\"cub-stepper-line-bar\"\n        #lineBar\n        [attr.data-step-index]=\"index\"\n      ></div>\n    </div>\n    } }\n  </div>\n  } }\n</div>\n\n<!-- \u5171\u7528\u6B65\u9A5F\u6A19\u984C\u6A21\u677F -->\n<ng-template let-step=\"step\" let-index=\"index\" #stepHeaderTemplate>\n  <cub-step-header\n    [id]=\"_getStepLabelId(index)\"\n    [tabIndex]=\"getFocusIndex() === index ? 0 : -1\"\n    [active]=\"isActive(index)\"\n    [disabled]=\"isDisabled(index, step)\"\n    [selected]=\"selectedIndex === index\"\n    [class.cub-step-header-completed]=\"isCompleted(index, step)\"\n    [class.cub-step-header-error]=\"isError(index, step)\"\n    [class.cub-stepper-link-vertical]=\"labelOrientation === 'vertical'\"\n    [attr.aria-posinset]=\"index + 1\"\n    [attr.aria-setsize]=\"steps.length\"\n    [attr.aria-controls]=\"_getStepContentId(index)\"\n    [attr.data-step-index]=\"index\"\n    (click)=\"selectStep(index, step)\"\n  >\n    <a class=\"cub-stepper-link\">\n      @if (isCompleted(index, step)){\n      <div class=\"cub-stepper-label-container\">\n        <span class=\"cub-step-icon\">\n          @if (step.loading && showLoading) {\n          <cub-loading\n            [size]=\"size\"\n            [color]=\"getLoadingColor(index, step)\"\n          ></cub-loading>\n          } @else {\n          <span class=\"cub-step-icon-wrapper cub-icon-check\"></span>\n          }\n        </span>\n        <span class=\"cub-stepper-label\">{{ step.label }}</span>\n      </div>\n      @if(step.description){\n      <span class=\"cub-stepper-description\">{{ step.description }}</span>\n      } } @if (!isCompleted(index, step)){\n      <div class=\"cub-stepper-label-container\">\n        <span class=\"cub-step-icon\">\n          @if (step.loading && showLoading){\n          <span class=\"cub-step-icon-wrapper\">\n            <cub-loading\n              [size]=\"size\"\n              [color]=\"getLoadingColor(index, step)\"\n            ></cub-loading> </span\n          >} @else if(step.hasError && !(selectedIndex === index)){\n          <span\n            class=\"cub-step-icon-wrapper\"\n            [ngClass]=\"{ 'cub-icon-x': step.hasError }\"\n          >\n          </span>\n          } @else if (step.icon) {\n          <span class=\"cub-step-icon-wrapper\" [class]=\"step.icon\"></span>\n          } @else {\n          <span class=\"cub-step-icon-wrapper\"> {{ index + 1 }} </span>}\n        </span>\n        <span class=\"cub-stepper-label\">\n          {{ step.label }}\n        </span>\n      </div>\n      @if(step.description){\n      <span class=\"cub-stepper-description\"> {{ step.description }} </span>} }\n    </a>\n  </cub-step-header>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.Directionality }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i2.Router }], propDecorators: { size: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], orientation: [{
                type: Input
            }], labelOrientation: [{
                type: Input
            }], selected: [{
                type: Input
            }], lineBar: [{
                type: ViewChildren,
                args: ['lineBar']
            }], stepHeaderList: [{
                type: ViewChildren,
                args: [CubStepHeader]
            }], links: [{
                type: ContentChildren,
                args: [RouterLink, { descendants: true }]
            }], linksWithHref: [{
                type: ContentChildren,
                args: [RouterLinkWithHref, { descendants: true }]
            }], stepList: [{
                type: ContentChildren,
                args: [CubStep, { descendants: true }]
            }] } });

class CubStepperContainer extends CubCdkStepper {
    selectStepByIndex(index) {
        this.selectedIndex = index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepperContainer, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubStepperContainer, isStandalone: true, selector: "cub-stepper-container", providers: [{ provide: CubCdkStepper, useExisting: CubStepperContainer }], usesInheritance: true, ngImport: i0, template: "<ng-container\n  [ngTemplateOutlet]=\"selected ? selected.content : null\"\n></ng-container>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepperContainer, decorators: [{
            type: Component,
            args: [{ selector: 'cub-stepper-container', providers: [{ provide: CubCdkStepper, useExisting: CubStepperContainer }], imports: [NgTemplateOutlet], template: "<ng-container\n  [ngTemplateOutlet]=\"selected ? selected.content : null\"\n></ng-container>\n" }]
        }] });

class CubStepperModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepperModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubStepperModule, imports: [CubCdkStepperModule,
            CubStep,
            CubStepHeader,
            CubStepContent,
            CubStepper,
            CubNavStepper,
            CubStepperContainer], exports: [CubCdkStepperModule,
            CubStep,
            CubStepHeader,
            CubStepContent,
            CubStepper,
            CubNavStepper,
            CubStepperContainer] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepperModule, imports: [CubCdkStepperModule,
            CubStepper,
            CubNavStepper, CubCdkStepperModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubStepperModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCdkStepperModule,
                        CubStep,
                        CubStepHeader,
                        CubStepContent,
                        CubStepper,
                        CubNavStepper,
                        CubStepperContainer,
                    ],
                    exports: [
                        CubCdkStepperModule,
                        CubStep,
                        CubStepHeader,
                        CubStepContent,
                        CubStepper,
                        CubNavStepper,
                        CubStepperContainer,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/stepper
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubNavStepper, CubStep, CubStepContent, CubStepHeader, CubStepper, CubStepperContainer, CubStepperModule };
//# sourceMappingURL=cub-lib-view-rootng-component-stepper.mjs.map
