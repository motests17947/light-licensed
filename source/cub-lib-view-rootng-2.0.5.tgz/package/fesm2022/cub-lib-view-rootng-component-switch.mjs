import * as i0 from '@angular/core';
import { InjectionToken, forwardRef, EventEmitter, Output, Input, Directive, ViewChild, Attribute, Inject, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, CheckboxRequiredValidator } from '@angular/forms';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { CubCdkObserveContent } from 'cub-lib-view-rootng/cdk/observers';
import { mixinTabIndex, mixinColor, mixinDisableRipple, mixinDisabled, CubRipple } from 'cub-lib-view-rootng/component/common';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';

class CubSwitchChange {
    constructor(source, checked) {
        this.source = source;
        this.checked = checked;
    }
}

const CUB_SWITCH_DEFAULT_OPTIONS = new InjectionToken('cub-switch-default-options', {
    providedIn: 'root',
    factory: () => ({ disableToggleValue: false }),
});

const CUB_SWITCH_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CubSwitch),
    multi: true,
};
let nextUniqueId = 0;
const _CubSwitchMixinBase = mixinTabIndex(mixinColor(mixinDisableRipple(mixinDisabled(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}))));
class _CubSwitchBase extends _CubSwitchMixinBase {
    get inputId() {
        return `${this.id || this._uniqueId}-input`;
    }
    /** 元件是否為必填，預設為 false。 */
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    /** 元件是否被選中，預設為 false。 */
    get checked() {
        return this._checked;
    }
    set checked(value) {
        this._checked = coerceBooleanProperty(value);
        this._changeDetectorRef.markForCheck();
    }
    constructor(elementRef, _focusMonitor, _changeDetectorRef, tabIndex, defaults, idPrefix) {
        super(elementRef);
        this._focusMonitor = _focusMonitor;
        this._changeDetectorRef = _changeDetectorRef;
        this.defaults = defaults;
        this._required = false;
        this._checked = false;
        /** 元件名稱，用於表單提交，預設為 null。 */
        this.name = null;
        /** 元件尺寸，預設為 'medium' */
        this.size = 'medium';
        /** 元件標籤顯示位置，預設為 'after' */
        this.labelPosition = 'after';
        /** 元件標題（螢幕閱讀器讀取用），預設為 null。 */
        this.ariaLabel = null;
        /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
        this.ariaLabelledby = null;
        /** 當元件狀態變更（如 checked 狀態改變）時發出的事件，會帶有變更後的資料。 */
        this.change = new EventEmitter();
        /**  當元件被切換（不論狀態是否真的改變）時發出的事件，不帶任何資料。 */
        this.toggleChange = new EventEmitter();
        this._onChange = (_) => { };
        this._onTouched = () => { };
        this.tabIndex = parseInt(tabIndex) || 0;
        this.color = this.defaultColor = defaults.color || 'warning';
        this.id = this._uniqueId = `${idPrefix}${++nextUniqueId}`;
    }
    ngAfterContentInit() {
        this._focusMonitor
            .monitor(this._elementRef, true)
            .subscribe((focusOrigin) => {
            if (focusOrigin === 'keyboard' || focusOrigin === 'program') {
                this._focused = true;
            }
            else if (!focusOrigin) {
                Promise.resolve().then(() => {
                    this._focused = false;
                    this._onTouched();
                    this._changeDetectorRef.markForCheck();
                });
            }
        });
    }
    ngOnDestroy() {
        this._focusMonitor.stopMonitoring(this._elementRef);
    }
    writeValue(value) {
        this.checked = !!value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._changeDetectorRef.markForCheck();
    }
    toggle() {
        this.checked = !this.checked;
        this._onChange(this.checked);
    }
    _emitChangeEvent() {
        this._onChange(this.checked);
        this.change.emit(this._createChangeEvent(this.checked));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubSwitchBase, deps: "invalid", target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubSwitchBase, isStandalone: true, inputs: { name: "name", id: "id", size: "size", labelPosition: "labelPosition", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], required: "required", checked: "checked" }, outputs: { change: "change", toggleChange: "toggleChange" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubSwitchBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }, { type: i0.ChangeDetectorRef }, { type: undefined }, { type: undefined }, { type: undefined }], propDecorators: { name: [{
                type: Input
            }], id: [{
                type: Input
            }], size: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], required: [{
                type: Input
            }], checked: [{
                type: Input
            }], change: [{
                type: Output
            }], toggleChange: [{
                type: Output
            }] } });
class CubSwitch extends _CubSwitchBase {
    constructor(elementRef, focusMonitor, changeDetectorRef, tabIndex, defaults) {
        super(elementRef, focusMonitor, changeDetectorRef, tabIndex, defaults, 'cub-switch-');
    }
    focus(options, origin) {
        if (origin) {
            this._focusMonitor.focusVia(this._inputElement, origin, options);
        }
        else {
            this._inputElement.nativeElement.focus(options);
        }
    }
    _onChangeEvent(event) {
        event.stopPropagation();
        this.toggleChange.emit();
        if (this.defaults.disableToggleValue) {
            this._inputElement.nativeElement.checked = this.checked;
            return;
        }
        this.checked = this._inputElement.nativeElement.checked;
        this._onTouched();
        this._emitChangeEvent();
    }
    _onInputClick(event) {
        event.stopPropagation();
    }
    _onLabelTextChange() {
        this._changeDetectorRef.detectChanges();
    }
    _handleKeydown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.toggle();
        }
    }
    _createChangeEvent(isChecked) {
        return new CubSwitchChange(this, isChecked);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitch, deps: [{ token: i0.ElementRef }, { token: i1.FocusMonitor }, { token: i0.ChangeDetectorRef }, { token: 'tabindex', attribute: true }, { token: CUB_SWITCH_DEFAULT_OPTIONS }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubSwitch, isStandalone: true, selector: "cub-switch", inputs: { disabled: "disabled", disableRipple: "disableRipple", color: "color", tabIndex: "tabIndex" }, host: { listeners: { "keydown": "_handleKeydown($event)" }, properties: { "id": "id", "attr.tabindex": "null", "attr.aria-label": "null", "attr.aria-labelledby": "null", "attr.name": "null", "class.cub-checked": "checked", "class.cub-disabled": "disabled", "class.cub-switch-small": "this.size === \"small\"" }, classAttribute: "cub-switch" }, providers: [CUB_SWITCH_VALUE_ACCESSOR], viewQueries: [{ propertyName: "_inputElement", first: true, predicate: ["input"], descendants: true }], exportAs: ["cubSwitch"], usesInheritance: true, ngImport: i0, template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  class=\"cub-switch-label\"\n  [class.cub-switch-label-before]=\"labelPosition == 'before'\"\n  [class.cub-switch-label-after]=\"\n    labelPosition == 'after' && labelContent.textContent?.trim()\n  \"\n  [class.cub-switch-label-empty]=\"\n    !labelContent.textContent || !labelContent.textContent.trim()\n  \"\n  [tabIndex]=\"tabIndex\"\n>\n  <span class=\"cub-switch-bar\">\n    <input\n      #input\n      class=\"cub-switch-input cub-cdk-visually-hidden\"\n      type=\"checkbox\"\n      role=\"switch\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [disabled]=\"disabled\"\n      [tabIndex]=\"-1\"\n      [attr.name]=\"name\"\n      [attr.aria-checked]=\"checked\"\n      [attr.aria-label]=\"ariaLabel\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"_onChangeEvent($event)\"\n      (click)=\"_onInputClick($event)\"\n    />\n\n    <span class=\"cub-switch-thumb-container\">\n      <span class=\"cub-switch-thumb\">\n        @if (checked) {\n        <span class=\"cub-switch-checkedmark\"></span>\n        } @else {\n        <span class=\"cub-switch-uncheckedmark\"></span>\n        }\n      </span>\n      <span\n        cub-ripple\n        cubRippleClass=\"cub-switch-ripple\"\n        [cubRippleTrigger]=\"label\"\n        [cubRippleDisabled]=\"disableRipple || disabled\"\n        [cubRippleCentered]=\"true\"\n        [cubRippleRadius]=\"20\"\n      >\n        <span class=\"cub-switch-ripple-element\"></span>\n      </span>\n      <span class=\"cub-persistent-ripple cub-switch-persistent-ripple\"></span>\n    </span>\n  </span>\n\n  <span\n    class=\"cub-switch-label-content\"\n    #labelContent\n    (cubCdkObserveContent)=\"_onLabelTextChange()\"\n  >\n    <span style=\"display: none\">&nbsp;</span>\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: CubCdkObserveContent, selector: "[cubCdkObserveContent]", inputs: ["cubCdkObserveContentDisabled", "debounce"], outputs: ["cubCdkObserveContent"], exportAs: ["cubCdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitch, decorators: [{
            type: Component,
            args: [{ selector: 'cub-switch', exportAs: 'cubSwitch', host: {
                        class: 'cub-switch',
                        '[id]': 'id',
                        '[attr.tabindex]': 'null',
                        '[attr.aria-label]': 'null',
                        '[attr.aria-labelledby]': 'null',
                        '[attr.name]': 'null',
                        '[class.cub-checked]': 'checked',
                        '[class.cub-disabled]': 'disabled',
                        '[class.cub-switch-small]': 'this.size === "small"',
                        '(keydown)': '_handleKeydown($event)',
                    }, providers: [CUB_SWITCH_VALUE_ACCESSOR], inputs: ['disabled', 'disableRipple', 'color', 'tabIndex'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubRipple, CubCdkObserveContent], template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  class=\"cub-switch-label\"\n  [class.cub-switch-label-before]=\"labelPosition == 'before'\"\n  [class.cub-switch-label-after]=\"\n    labelPosition == 'after' && labelContent.textContent?.trim()\n  \"\n  [class.cub-switch-label-empty]=\"\n    !labelContent.textContent || !labelContent.textContent.trim()\n  \"\n  [tabIndex]=\"tabIndex\"\n>\n  <span class=\"cub-switch-bar\">\n    <input\n      #input\n      class=\"cub-switch-input cub-cdk-visually-hidden\"\n      type=\"checkbox\"\n      role=\"switch\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [disabled]=\"disabled\"\n      [tabIndex]=\"-1\"\n      [attr.name]=\"name\"\n      [attr.aria-checked]=\"checked\"\n      [attr.aria-label]=\"ariaLabel\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"_onChangeEvent($event)\"\n      (click)=\"_onInputClick($event)\"\n    />\n\n    <span class=\"cub-switch-thumb-container\">\n      <span class=\"cub-switch-thumb\">\n        @if (checked) {\n        <span class=\"cub-switch-checkedmark\"></span>\n        } @else {\n        <span class=\"cub-switch-uncheckedmark\"></span>\n        }\n      </span>\n      <span\n        cub-ripple\n        cubRippleClass=\"cub-switch-ripple\"\n        [cubRippleTrigger]=\"label\"\n        [cubRippleDisabled]=\"disableRipple || disabled\"\n        [cubRippleCentered]=\"true\"\n        [cubRippleRadius]=\"20\"\n      >\n        <span class=\"cub-switch-ripple-element\"></span>\n      </span>\n      <span class=\"cub-persistent-ripple cub-switch-persistent-ripple\"></span>\n    </span>\n  </span>\n\n  <span\n    class=\"cub-switch-label-content\"\n    #labelContent\n    (cubCdkObserveContent)=\"_onLabelTextChange()\"\n  >\n    <span style=\"display: none\">&nbsp;</span>\n    <ng-content></ng-content>\n  </span>\n</label>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusMonitor }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_SWITCH_DEFAULT_OPTIONS]
                }] }], propDecorators: { _inputElement: [{
                type: ViewChild,
                args: ['input']
            }] } });

const CUB_SWITCH_BUTTON_REQUIRED_VALIDATOR = {
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => CubSwitchRequiredValidator),
    multi: true,
};
class CubSwitchRequiredValidator extends CheckboxRequiredValidator {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitchRequiredValidator, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSwitchRequiredValidator, isStandalone: true, selector: "cub-switch-button[required][formControlName],\n  cub-switch-button[required][formControl], cub-switch-button[required][ngModel]", providers: [CUB_SWITCH_BUTTON_REQUIRED_VALIDATOR], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitchRequiredValidator, decorators: [{
            type: Directive,
            args: [{
                    selector: `cub-switch-button[required][formControlName],
  cub-switch-button[required][formControl], cub-switch-button[required][ngModel]`,
                    providers: [CUB_SWITCH_BUTTON_REQUIRED_VALIDATOR],
                }]
        }] });

class CubSwitchModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubSwitchModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubSwitch,
            CubSwitchRequiredValidator], exports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubSwitch,
            CubSwitchRequiredValidator] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitchModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule, CubFormFieldModule,
            CubLabelModule,
            CubInputModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSwitchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubSwitch,
                        CubSwitchRequiredValidator,
                    ],
                    exports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubSwitch,
                        CubSwitchRequiredValidator,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/switch
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_SWITCH_BUTTON_REQUIRED_VALIDATOR, CUB_SWITCH_DEFAULT_OPTIONS, CUB_SWITCH_VALUE_ACCESSOR, CubSwitch, CubSwitchChange, CubSwitchModule, CubSwitchRequiredValidator, _CubSwitchBase };
//# sourceMappingURL=cub-lib-view-rootng-component-switch.mjs.map
