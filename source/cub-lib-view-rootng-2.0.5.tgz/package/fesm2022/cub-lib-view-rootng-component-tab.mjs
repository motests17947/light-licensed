import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, ViewEncapsulation, Component, InjectionToken, inject, ANIMATION_MODULE_TYPE, Inject, Optional, Directive, EventEmitter, NgZone, Attribute, ViewChild, forwardRef, ContentChildren, Output, DOCUMENT, TemplateRef, ContentChild, QueryList, NgModule } from '@angular/core';
import { CubCdkObserveContent } from 'cub-lib-view-rootng/cdk/observers';
import { mixinTabIndex, mixinDisabled, CubRipple, mixinColor } from 'cub-lib-view-rootng/component/common';
import { take, takeUntil, startWith, switchMap, skip, filter, distinctUntilChanged } from 'rxjs/operators';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i3 from 'cub-lib-view-rootng/cdk/platform';
import { normalizePassiveListenerOptions, Platform } from 'cub-lib-view-rootng/cdk/platform';
import { coerceNumberProperty, coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { hasModifierKey, SPACE, ENTER } from 'cub-lib-view-rootng/cdk/keycodes';
import { Subject, fromEvent, of, merge, timer, EMPTY, Observable, Subscription, startWith as startWith$1, takeUntil as takeUntil$1 } from 'rxjs';
import * as i2 from 'cub-lib-view-rootng/cdk/a11y';
import { FocusKeyManager, CubCdkMonitorFocus } from 'cub-lib-view-rootng/cdk/a11y';
import * as i1 from 'cub-lib-view-rootng/cdk/scrolling';
import { CubCdkScrollable } from 'cub-lib-view-rootng/cdk/scrolling';
import * as i1$1 from 'cub-lib-view-rootng/cdk/bidi';
import { CubCdkPortalOutlet, TemplatePortal, CubCdkPortal } from 'cub-lib-view-rootng/cdk/portal';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import { CubTooltipTrigger, CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER } from 'cub-lib-view-rootng/component/tooltip';
import { CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';

let nextUniqueId$1 = 0;
class CubTabNavPanel {
    constructor() {
        /** 元件唯一識別符，預設為 undefined。 */
        this.id = `cub-tab-nav-panel-${nextUniqueId$1++}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabNavPanel, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTabNavPanel, isStandalone: true, selector: "cub-tab-nav-panel", inputs: { id: "id" }, host: { attributes: { "role": "tabpanel" }, properties: { "attr.aria-labelledby": "_activeTabId", "attr.id": "id" }, classAttribute: "cub-tab-nav-panel" }, exportAs: ["cubTabNavPanel"], ngImport: i0, template: "<ng-content></ng-content>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabNavPanel, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tab-nav-panel', exportAs: 'cubTabNavPanel', host: {
                        '[attr.aria-labelledby]': '_activeTabId',
                        '[attr.id]': 'id',
                        class: 'cub-tab-nav-panel',
                        role: 'tabpanel',
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content></ng-content>\n" }]
        }], propDecorators: { id: [{
                type: Input
            }] } });

const CUB_TAB_CONTENT = new InjectionToken('CubTabContent');
const EXAGGERATED_OVERSCROLL = 60;
const HEADER_SCROLL_DELAY = 650;
const HEADER_SCROLL_INTERVAL = 100;
const passiveEventListenerOptions = normalizePassiveListenerOptions({
    passive: true,
});
const CUB_TABS_CONFIG = new InjectionToken('CUB_TABS_CONFIG');
const CUB_TAB_GROUP = new InjectionToken('CUB_TAB_GROUP');
const CUB_TAB_LABEL = new InjectionToken('CubTabLabel');
const CUB_TAB = new InjectionToken('CUB_TAB');
const cubTabsAnimations = {
    translateTab: trigger('translateTab', [
        state('center, void, left-origin-center, right-origin-center', style({ transform: 'none' })),
        state('left', style({
            transform: 'translate3d(-100%, 0, 0)',
            minHeight: '0px',
            visibility: 'hidden',
        })),
        state('right', style({
            transform: 'translate3d(100%, 0, 0)',
            minHeight: '0px',
            visibility: 'hidden',
        })),
        transition('* => left, * => right, left => center, right => center', animate('{{animationDuration}} cubic-bezier(0.35, 0, 0.25, 1)')),
        transition('void => left-origin-center', [
            style({ transform: 'translate3d(-100%, 0, 0)', visibility: 'hidden' }),
            animate('{{animationDuration}} cubic-bezier(0.35, 0, 0.25, 1)'),
        ]),
        transition('void => right-origin-center', [
            style({ transform: 'translate3d(100%, 0, 0)', visibility: 'hidden' }),
            animate('{{animationDuration}} cubic-bezier(0.35, 0, 0.25, 1)'),
        ]),
    ]),
};

const _CUB_INK_BAR_POSITIONER = new InjectionToken('CubInkBarPositioner', {
    providedIn: 'root',
    factory: _CUB_INK_BAR_POSITIONER_FACTORY,
});
function _CUB_INK_BAR_POSITIONER_FACTORY() {
    const method = (element, orientation) => {
        if (orientation === 'vertical') {
            return {
                top: element ? (element.offsetTop || 0) + 'px' : '0',
                height: element ? (element.offsetHeight || 0) + 'px' : '0',
            };
        }
        else {
            return {
                left: element ? (element.offsetLeft || 0) + 'px' : '0',
                width: element ? (element.offsetWidth || 0) + 'px' : '0',
            };
        }
    };
    return method;
}
class CubInkBar {
    constructor(_elementRef, _ngZone, _inkBarPositioner, _animationMode) {
        this._elementRef = _elementRef;
        this._ngZone = _ngZone;
        this._inkBarPositioner = _inkBarPositioner;
        this._animationMode = _animationMode;
        this.cubTabGroup = inject(CUB_TAB_GROUP, { optional: true });
        if (this.cubTabGroup) {
            this._orientation = this.cubTabGroup.orientation;
        }
    }
    alignToElement(element) {
        this.show();
        this._ngZone.run(() => {
            this._ngZone.onStable.pipe(take(1)).subscribe(() => {
                const inkBar = this._elementRef.nativeElement;
                const positions = this._inkBarPositioner(element, this._orientation);
                if (this._orientation === 'vertical') {
                    // 垂直方向
                    inkBar.style.top = positions.top;
                    inkBar.style.height = positions.height;
                }
                else {
                    // 水平方向（預設）
                    inkBar.style.left = positions.left;
                    inkBar.style.width = positions.width;
                }
            });
        });
    }
    show() {
        this._elementRef.nativeElement.style.visibility = 'visible';
    }
    hide() {
        this._elementRef.nativeElement.style.visibility = 'hidden';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInkBar, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: _CUB_INK_BAR_POSITIONER }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubInkBar, isStandalone: true, selector: "cub-ink-bar", host: { properties: { "class.cub-animation-noop-able": "_animationMode === 'NoopAnimations'" }, classAttribute: "cub-ink-bar" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubInkBar, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-ink-bar',
                    host: {
                        class: 'cub-ink-bar',
                        '[class.cub-animation-noop-able]': `_animationMode === 'NoopAnimations'`,
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [_CUB_INK_BAR_POSITIONER]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }] });

class CubTabHeaderPaginated {
    get scrollDistance() {
        return this._scrollDistance;
    }
    set scrollDistance(value) {
        this._scrollTo(value);
    }
    get focusIndex() {
        return this._keyManager ? this._keyManager.activeItemIndex : 0;
    }
    set focusIndex(value) {
        if (!this._isValidIndex(value) ||
            this.focusIndex === value ||
            !this._keyManager) {
            return;
        }
        this._keyManager.setActiveItem(value);
    }
    get selectedIndex() {
        return this._selectedIndex;
    }
    set selectedIndex(value) {
        value = coerceNumberProperty(value);
        if (this._selectedIndex != value) {
            this._selectedIndexChanged = true;
            this._selectedIndex = value;
            if (this._keyManager) {
                this._keyManager.updateActiveItem(value);
            }
        }
    }
    /**
     * 是否停用 tab 分頁按鈕（當 tab 過多時不顯示左右切換箭頭）。
     * 預設為 false。
     */
    get disablePagination() {
        return this._disablePagination;
    }
    set disablePagination(value) {
        this._disablePagination = coerceBooleanProperty(value);
    }
    constructor(_elementRef, _changeDetectorRef, _viewportRuler, _dir, _ngZone, _platform, _animationMode) {
        this._elementRef = _elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._viewportRuler = _viewportRuler;
        this._dir = _dir;
        this._ngZone = _ngZone;
        this._platform = _platform;
        this._animationMode = _animationMode;
        this._showPaginationControls = false;
        this._disableScrollAfter = true;
        this._disableScrollBefore = true;
        this.cubTabGroup = inject(CUB_TAB_GROUP, { optional: true });
        this.selectFocusedIndex = new EventEmitter();
        this.indexFocused = new EventEmitter();
        this._destroyed = new Subject();
        this._scrollDistanceChanged = false;
        this._stopScrolling = new Subject();
        this._scrollDistance = 0;
        this._selectedIndexChanged = false;
        this._disablePagination = false;
        this._selectedIndex = 0;
        _ngZone.runOutsideAngular(() => {
            fromEvent(_elementRef.nativeElement, 'mouseleave')
                .pipe(takeUntil(this._destroyed))
                .subscribe(() => {
                this._stopInterval();
            });
        });
        if (this.cubTabGroup) {
            this._orientation = this.cubTabGroup.orientation;
        }
    }
    ngAfterViewInit() {
        fromEvent(this._previousPaginator.nativeElement, 'touchstart', passiveEventListenerOptions)
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => {
            this._handlePaginatorPress('before');
        });
        fromEvent(this._nextPaginator.nativeElement, 'touchstart', passiveEventListenerOptions)
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => {
            this._handlePaginatorPress('after');
        });
    }
    ngAfterContentInit() {
        const dirChange = this._dir ? this._dir.change : of('ltr');
        const resize = this._viewportRuler.change(150);
        const realign = () => {
            this.updatePagination();
            this._alignInkBarToSelectedTab();
        };
        this._keyManager = new FocusKeyManager(this._items)
            .withHorizontalOrientation(this._getLayoutDirection())
            .withHomeAndEnd()
            .withWrap();
        this._keyManager.updateActiveItem(this._selectedIndex);
        this._ngZone.onStable.pipe(take(1)).subscribe(realign);
        merge(dirChange, resize, this._items.changes, this._itemsResized())
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => {
            this._ngZone.run(() => {
                Promise.resolve().then(() => {
                    this._scrollDistance = Math.max(0, Math.min(this._getMaxScrollDistance(), this._scrollDistance));
                    realign();
                });
            });
            this._keyManager.withHorizontalOrientation(this._getLayoutDirection());
        });
        this._keyManager.change
            .pipe(takeUntil(this._destroyed))
            .subscribe((newFocusIndex) => {
            this.indexFocused.emit(newFocusIndex);
            this._setTabFocus(newFocusIndex);
        });
    }
    ngAfterContentChecked() {
        if (this._tabLabelCount != this._items.length) {
            this.updatePagination();
            this._tabLabelCount = this._items.length;
            this._changeDetectorRef.markForCheck();
        }
        if (this._selectedIndexChanged) {
            this._scrollToLabel(this._selectedIndex);
            this._checkScrollingControls();
            this._alignInkBarToSelectedTab();
            this._selectedIndexChanged = false;
            this._changeDetectorRef.markForCheck();
        }
        if (this._scrollDistanceChanged) {
            this._updateTabScrollPosition();
            this._scrollDistanceChanged = false;
            this._changeDetectorRef.markForCheck();
        }
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
        this._stopScrolling.complete();
    }
    updatePagination() {
        this._checkPaginationEnabled();
        this._checkScrollingControls();
        this._updateTabScrollPosition();
    }
    _handleKeydown(event) {
        if (hasModifierKey(event)) {
            return;
        }
        switch (event.keyCode) {
            case ENTER:
            case SPACE:
                if (this.focusIndex !== this.selectedIndex) {
                    this.selectFocusedIndex.emit(this.focusIndex);
                    this._itemSelected(event);
                }
                break;
            default:
                this._keyManager.onKeydown(event);
        }
    }
    _onContentChanges() {
        const textContent = this._elementRef.nativeElement.textContent;
        if (textContent !== this._currentTextContent) {
            this._currentTextContent = textContent || '';
            this._ngZone.run(() => {
                this.updatePagination();
                this._alignInkBarToSelectedTab();
                this._changeDetectorRef.markForCheck();
            });
        }
    }
    _isValidIndex(index) {
        if (!this._items) {
            return true;
        }
        const tab = this._items ? this._items.toArray()[index] : null;
        return !!tab && !tab.disabled;
    }
    _setTabFocus(tabIndex) {
        if (this._showPaginationControls) {
            this._scrollToLabel(tabIndex);
        }
        if (this._items && this._items.length) {
            this._items.toArray()[tabIndex].focus();
            const containerEl = this._tabListContainer.nativeElement;
            const dir = this._getLayoutDirection();
            if (dir == 'ltr') {
                containerEl.scrollLeft = 0;
            }
            else {
                containerEl.scrollLeft =
                    containerEl.scrollWidth - containerEl.offsetWidth;
            }
        }
    }
    _getLayoutDirection() {
        return this._dir && this._dir.value === 'rtl' ? 'rtl' : 'ltr';
    }
    _updateTabScrollPosition() {
        if (this.disablePagination) {
            return;
        }
        const scrollDistance = this.scrollDistance;
        if (this._orientation === 'vertical') {
            this._tabList.nativeElement.style.transform = `translateY(${-scrollDistance}px)`;
        }
        else {
            const translateX = this._getLayoutDirection() === 'ltr' ? -scrollDistance : scrollDistance;
            this._tabList.nativeElement.style.transform = `translateX(${Math.round(translateX)}px)`;
        }
        if (this._platform.TRIDENT || this._platform.EDGE) {
            if (this._orientation === 'vertical') {
                this._tabListContainer.nativeElement.scrollTop = 0;
            }
            else {
                this._tabListContainer.nativeElement.scrollLeft = 0;
            }
        }
    }
    _scrollHeader(direction) {
        let viewLength;
        let scrollAmount;
        if (this._orientation === 'vertical') {
            viewLength = this._tabListContainer.nativeElement.offsetHeight;
            scrollAmount = ((direction == 'before' ? -1 : 1) * viewLength) / 3;
            return this._scrollTo(this._scrollDistance + scrollAmount);
        }
        else {
            viewLength = this._tabListContainer.nativeElement.offsetWidth;
            scrollAmount = ((direction == 'before' ? -1 : 1) * viewLength) / 3;
            return this._scrollTo(this._scrollDistance + scrollAmount);
        }
    }
    _handlePaginatorClick(direction) {
        this._stopInterval();
        this._scrollHeader(direction);
    }
    _scrollToLabel(labelIndex) {
        if (this.disablePagination) {
            return;
        }
        const selectedLabel = this._items
            ? this._items.toArray()[labelIndex]
            : null;
        if (!selectedLabel) {
            return;
        }
        const container = this._tabListContainer.nativeElement;
        const labelEl = selectedLabel.elementRef.nativeElement;
        if (this._orientation === 'vertical') {
            const viewLength = container.offsetHeight;
            const labelTop = labelEl.offsetTop;
            const labelHeight = labelEl.offsetHeight;
            const targetScroll = labelTop - viewLength / 2 + labelHeight / 2;
            this.scrollDistance = targetScroll;
        }
        else {
            const viewLength = container.offsetWidth;
            const labelLeft = labelEl.offsetLeft;
            const labelWidth = labelEl.offsetWidth;
            const targetScroll = labelLeft - viewLength / 2 + labelWidth / 2;
            this.scrollDistance = targetScroll;
        }
    }
    _checkPaginationEnabled() {
        if (this.disablePagination) {
            this._showPaginationControls = false;
        }
        else {
            let isEnabled;
            if (this._orientation === 'vertical') {
                isEnabled =
                    this._tabListInner.nativeElement.scrollHeight >
                        this._elementRef.nativeElement.offsetHeight;
            }
            else {
                isEnabled =
                    this._tabListInner.nativeElement.scrollWidth >
                        this._elementRef.nativeElement.offsetWidth;
            }
            if (!isEnabled) {
                this.scrollDistance = 0;
            }
            if (isEnabled !== this._showPaginationControls) {
                this._changeDetectorRef.markForCheck();
            }
            this._showPaginationControls = isEnabled;
        }
    }
    _checkScrollingControls() {
        if (this.disablePagination) {
            this._disableScrollAfter = this._disableScrollBefore = true;
        }
        else {
            // Check if the pagination arrows should be activated.
            this._disableScrollBefore = this.scrollDistance == 0;
            this._disableScrollAfter =
                this.scrollDistance == this._getMaxScrollDistance();
            this._changeDetectorRef.markForCheck();
        }
    }
    _getMaxScrollDistance() {
        if (this._orientation === 'vertical') {
            const lengthOfTabList = this._tabListInner.nativeElement.scrollHeight;
            const viewLength = this._tabListContainer.nativeElement.offsetHeight;
            return lengthOfTabList - viewLength || 0;
        }
        else {
            const lengthOfTabList = this._tabListInner.nativeElement.scrollWidth;
            const viewLength = this._tabListContainer.nativeElement.offsetWidth;
            return lengthOfTabList - viewLength || 0;
        }
    }
    _alignInkBarToSelectedTab() {
        const selectedItem = this._items && this._items.length
            ? this._items.toArray()[this.selectedIndex]
            : null;
        const selectedLabelWrapper = selectedItem
            ? selectedItem.elementRef.nativeElement
            : null;
        if (selectedLabelWrapper) {
            this._inkBar.alignToElement(selectedLabelWrapper);
        }
        else {
            this._inkBar.hide();
        }
    }
    _stopInterval() {
        this._stopScrolling.next();
    }
    _handlePaginatorPress(direction, mouseEvent) {
        if (mouseEvent && mouseEvent.button != null && mouseEvent.button !== 0) {
            return;
        }
        this._stopInterval();
        timer(HEADER_SCROLL_DELAY, HEADER_SCROLL_INTERVAL)
            .pipe(takeUntil(merge(this._stopScrolling, this._destroyed)))
            .subscribe(() => {
            const { maxScrollDistance, distance } = this._scrollHeader(direction);
            if (distance === 0 || distance >= maxScrollDistance) {
                this._stopInterval();
            }
        });
    }
    _itemsResized() {
        if (typeof ResizeObserver !== 'function') {
            return EMPTY;
        }
        return this._items.changes.pipe(startWith(this._items), switchMap((tabItems) => new Observable((observer) => this._ngZone.runOutsideAngular(() => {
            const resizeObserver = new ResizeObserver((entries) => observer.next(entries));
            tabItems.forEach((item) => resizeObserver.observe(item.elementRef.nativeElement));
            return () => {
                resizeObserver.disconnect();
            };
        }))), skip(1), filter((entries) => entries.some((e) => e.contentRect.width > 0 && e.contentRect.height > 0)));
    }
    _scrollTo(position) {
        if (this.disablePagination) {
            return { maxScrollDistance: 0, distance: 0 };
        }
        const maxScrollDistance = this._getMaxScrollDistance();
        this._scrollDistance = Math.max(0, Math.min(maxScrollDistance, position));
        this._ngZone.run(() => {
            this._scrollDistanceChanged = true;
            this._changeDetectorRef.detectChanges();
        });
        this._checkScrollingControls();
        return { maxScrollDistance, distance: this._scrollDistance };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabHeaderPaginated, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i1$1.Directionality, optional: true }, { token: i0.NgZone }, { token: i3.Platform }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabHeaderPaginated, isStandalone: true, inputs: { disablePagination: "disablePagination" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabHeaderPaginated, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.NgZone }, { type: i3.Platform }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { disablePagination: [{
                type: Input
            }] } });

class _CubTabNavBase extends CubTabHeaderPaginated {
    constructor(elementRef, dir, ngZone, changeDetectorRef, viewportRuler, platform) {
        super(elementRef, changeDetectorRef, viewportRuler, dir, ngZone, platform);
    }
    ngAfterContentInit() {
        this._items.changes
            .pipe(startWith(null), takeUntil(this._destroyed))
            .subscribe(() => {
            this.updateActiveLink();
        });
        super.ngAfterContentInit();
    }
    updateActiveLink() {
        if (!this._items) {
            return;
        }
        const items = this._items.toArray();
        let foundActive = false;
        for (let i = 0; i < items.length; i++) {
            if (items[i].active) {
                this.selectedIndex = i;
                this._changeDetectorRef.markForCheck();
                if (this.tabPanel) {
                    this.tabPanel._activeTabId = items[i].id;
                }
                this._inkBar.alignToElement(items[i].elementRef.nativeElement);
                foundActive = true;
                break;
            }
        }
        if (!foundActive) {
            this.selectedIndex = -1;
            this._inkBar.hide();
        }
    }
    _getRole() {
        return this.tabPanel
            ? 'tablist'
            : this._elementRef.nativeElement.getAttribute('role');
    }
    _itemSelected() {
        // 要繼承給 CubTabNavBar
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabNavBase, deps: [{ token: i0.ElementRef }, { token: i1$1.Directionality, optional: true }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i3.Platform }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubTabNavBase, isStandalone: true, inputs: { tabPanel: "tabPanel" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabNavBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i3.Platform }], propDecorators: { tabPanel: [{
                type: Input
            }] } });

const _CubTabLinkMixinBase = mixinTabIndex(mixinDisabled(class {
}));
let nextUniqueId = 0;
class _CubTabLinkBase extends _CubTabLinkMixinBase {
    /**
     * 是否為目前作用中的 tab link。
     */
    get active() {
        return this._isActive;
    }
    set active(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== this._isActive) {
            this._isActive = newValue;
            this._tabNavBar.updateActiveLink();
        }
    }
    constructor(_tabNavBar, injector, renderer, elementRef, tabIndex, _focusMonitor) {
        super();
        this._tabNavBar = _tabNavBar;
        this.injector = injector;
        this.renderer = renderer;
        this.elementRef = elementRef;
        this._focusMonitor = _focusMonitor;
        this._isActive = false;
        this._rippleInstance = null;
        /** 元件唯一識別符，預設為 undefined。 */
        this.id = `cub-tab-link-${nextUniqueId++}`;
        this.tabIndex = parseInt(tabIndex) || 0;
    }
    ngAfterViewInit() {
        this._focusMonitor.monitor(this.elementRef);
        try {
            // 獲取必要的依賴
            const ngZone = this.injector.get(NgZone);
            const platform = this.injector.get(Platform);
            // 創建 CubRipple 實例
            this._rippleInstance = new CubRipple(this.elementRef, ngZone, platform, 
            // 不提供全局選項
            undefined, 
            // 不提供動畫模式
            undefined);
            this._rippleInstance.centered = false;
            this._rippleInstance.disabled = this.disabled;
            this._rippleInstance.specifyClass = 'cub-tab-ripple';
            this._rippleInstance.ngOnInit();
            this.renderer.addClass(this.elementRef.nativeElement, 'cub-ripple');
            this.renderer.addClass(this.elementRef.nativeElement, 'cub-tab-item-ripple');
            const persistentRipple = this.renderer.createElement('span');
            this.renderer.addClass(persistentRipple, 'cub-persistent-ripple');
            this.renderer.addClass(persistentRipple, 'cub-tab-item-persistent-ripple');
            this.renderer.appendChild(this.elementRef.nativeElement, persistentRipple);
        }
        catch (error) {
            console.error('Error initializing ripple:', error);
        }
    }
    ngOnDestroy() {
        this._focusMonitor.stopMonitoring(this.elementRef);
        if (this._rippleInstance) {
            this._rippleInstance.ngOnDestroy();
            this._rippleInstance = null;
        }
    }
    focus() {
        this.elementRef.nativeElement.focus();
    }
    _handleFocus() {
        this._tabNavBar.focusIndex = this._tabNavBar._items.toArray().indexOf(this);
    }
    _handleKeydown(event) {
        if (this._tabNavBar.tabPanel && event.keyCode === SPACE) {
            this.elementRef.nativeElement.click();
        }
    }
    _getAriaControls() {
        return this._tabNavBar.tabPanel
            ? this._tabNavBar.tabPanel?.id
            : this.elementRef.nativeElement.getAttribute('aria-controls');
    }
    _getAriaSelected() {
        if (this._tabNavBar.tabPanel) {
            return this.active ? 'true' : 'false';
        }
        else {
            return this.elementRef.nativeElement.getAttribute('aria-selected');
        }
    }
    _getAriaCurrent() {
        return this.active && !this._tabNavBar.tabPanel ? 'page' : null;
    }
    _getRole() {
        return this._tabNavBar.tabPanel
            ? 'tab'
            : this.elementRef.nativeElement.getAttribute('role');
    }
    _getTabIndex() {
        if (this._tabNavBar.tabPanel) {
            return this._isActive && !this.disabled ? 0 : -1;
        }
        else {
            return this.tabIndex;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabLinkBase, deps: [{ token: _CubTabNavBase }, { token: i0.Injector }, { token: i0.Renderer2 }, { token: i0.ElementRef }, { token: 'tabindex', attribute: true, optional: true }, { token: i2.FocusMonitor }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubTabLinkBase, isStandalone: true, inputs: { active: "active", id: "id" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabLinkBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: _CubTabNavBase }, { type: i0.Injector }, { type: i0.Renderer2 }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: i2.FocusMonitor }], propDecorators: { active: [{
                type: Input
            }], id: [{
                type: Input
            }] } });
class CubTabLink extends _CubTabLinkBase {
    constructor(tabNavBar, injector, renderer, elementRef, tabIndex, focusMonitor) {
        super(tabNavBar, injector, renderer, elementRef, tabIndex, focusMonitor);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabLink, deps: [{ token: CubTabNavBar }, { token: i0.Injector }, { token: i0.Renderer2 }, { token: i0.ElementRef }, { token: 'tabindex', attribute: true, optional: true }, { token: i2.FocusMonitor }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabLink, isStandalone: true, selector: "[cub-tab-link], [CubTabLink]", inputs: { disabled: "disabled", tabIndex: "tabIndex" }, host: { listeners: { "focus": "_handleFocus()", "keydown": "_handleKeydown($event)" }, properties: { "attr.aria-controls": "_getAriaControls()", "attr.aria-current": "_getAriaCurrent()", "attr.aria-disabled": "disabled", "attr.aria-selected": "_getAriaSelected()", "attr.id": "id", "attr.tabIndex": "_getTabIndex()", "attr.role": "_getRole()", "class.cub-disabled": "disabled", "class.cub-tab-item-active": "active" }, classAttribute: "cub-tab-item cub-tab-link cub-focus-indicator" }, exportAs: ["cubTabLink"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabLink, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cub-tab-link], [CubTabLink]',
                    exportAs: 'cubTabLink',
                    /** 元件是否禁用，預設為 false。 */
                    /** 元件的鍵盤導航順序，預設為 undefined。 */
                    inputs: ['disabled', 'tabIndex'],
                    host: {
                        class: 'cub-tab-item cub-tab-link cub-focus-indicator',
                        '[attr.aria-controls]': '_getAriaControls()',
                        '[attr.aria-current]': '_getAriaCurrent()',
                        '[attr.aria-disabled]': 'disabled',
                        '[attr.aria-selected]': '_getAriaSelected()',
                        '[attr.id]': 'id',
                        '[attr.tabIndex]': '_getTabIndex()',
                        '[attr.role]': '_getRole()',
                        '[class.cub-disabled]': 'disabled',
                        '[class.cub-tab-item-active]': 'active',
                        '(focus)': '_handleFocus()',
                        '(keydown)': '_handleKeydown($event)',
                    },
                }]
        }], ctorParameters: () => [{ type: CubTabNavBar }, { type: i0.Injector }, { type: i0.Renderer2 }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: i2.FocusMonitor }] });

class CubTabNavBar extends _CubTabNavBase {
    constructor(elementRef, dir, ngZone, changeDetectorRef, viewportRuler, platform) {
        super(elementRef, dir, ngZone, changeDetectorRef, viewportRuler, platform);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabNavBar, deps: [{ token: i0.ElementRef }, { token: i1$1.Directionality, optional: true }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i3.Platform }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTabNavBar, isStandalone: true, selector: "[cub-tab-nav-bar]", inputs: { color: "color" }, host: { properties: { "attr.role": "_getRole()", "class.cub-tab-header-pagination-controls-enabled": "_showPaginationControls", "class.cub-tab-header-rtl": "_getLayoutDirection() == 'rtl'" }, classAttribute: "cub-tab-nav-bar cub-tab-header" }, queries: [{ propertyName: "_items", predicate: i0.forwardRef(() => CubTabLink), descendants: true }], viewQueries: [{ propertyName: "_inkBar", first: true, predicate: CubInkBar, descendants: true, static: true }, { propertyName: "_tabListContainer", first: true, predicate: ["tabListContainer"], descendants: true, static: true }, { propertyName: "_tabList", first: true, predicate: ["tabList"], descendants: true, static: true }, { propertyName: "_tabListInner", first: true, predicate: ["tabListInner"], descendants: true, static: true }, { propertyName: "_nextPaginator", first: true, predicate: ["nextPaginator"], descendants: true }, { propertyName: "_previousPaginator", first: true, predicate: ["previousPaginator"], descendants: true }], exportAs: ["cubTabNavBar", "cubTabNav"], usesInheritance: true, ngImport: i0, template: "<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-before\"\n  #previousPaginator\n  [attr.aria-hidden]=\"_disableScrollBefore ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollBefore\"\n  tabindex=\"-1\"\n  [disabled]=\"_disableScrollBefore || null\"\n  (click)=\"_handlePaginatorClick('before')\"\n  (mousedown)=\"_handlePaginatorPress('before', $event)\"\n  (touchend)=\"_stopInterval()\"\n>\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-left\"></span>\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n\n<div\n  class=\"cub-tab-item-container\"\n  #tabListContainer\n  (keydown)=\"_handleKeydown($event)\"\n>\n  <div\n    #tabList\n    class=\"cub-tab-list\"\n    [class.cub-animation-noop-able]=\"_animationMode === 'NoopAnimations'\"\n    (cubCdkObserveContent)=\"_onContentChanges()\"\n  >\n    <div class=\"cub-tab-items\" #tabListInner>\n      <ng-content></ng-content>\n    </div>\n    <cub-ink-bar></cub-ink-bar>\n  </div>\n</div>\n\n<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-after\"\n  #nextPaginator\n  [attr.aria-hidden]=\"_disableScrollAfter ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollAfter\"\n  [disabled]=\"_disableScrollAfter || null\"\n  tabindex=\"-1\"\n  (mousedown)=\"_handlePaginatorPress('after', $event)\"\n  (click)=\"_handlePaginatorClick('after')\"\n  (touchend)=\"_stopInterval()\"\n>\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-right\"></span>\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: CubCdkObserveContent, selector: "[cubCdkObserveContent]", inputs: ["cubCdkObserveContentDisabled", "debounce"], outputs: ["cubCdkObserveContent"], exportAs: ["cubCdkObserveContent"] }, { kind: "directive", type: CubInkBar, selector: "cub-ink-bar" }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabNavBar, decorators: [{
            type: Component,
            args: [{ selector: '[cub-tab-nav-bar]', exportAs: 'cubTabNavBar, cubTabNav', inputs: ['color'], host: {
                        '[attr.role]': '_getRole()',
                        class: 'cub-tab-nav-bar cub-tab-header',
                        '[class.cub-tab-header-pagination-controls-enabled]': '_showPaginationControls',
                        '[class.cub-tab-header-rtl]': "_getLayoutDirection() == 'rtl'",
                    }, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Default, imports: [CubRipple, CubCdkObserveContent, CubInkBar], template: "<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-before\"\n  #previousPaginator\n  [attr.aria-hidden]=\"_disableScrollBefore ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollBefore\"\n  tabindex=\"-1\"\n  [disabled]=\"_disableScrollBefore || null\"\n  (click)=\"_handlePaginatorClick('before')\"\n  (mousedown)=\"_handlePaginatorPress('before', $event)\"\n  (touchend)=\"_stopInterval()\"\n>\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-left\"></span>\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n\n<div\n  class=\"cub-tab-item-container\"\n  #tabListContainer\n  (keydown)=\"_handleKeydown($event)\"\n>\n  <div\n    #tabList\n    class=\"cub-tab-list\"\n    [class.cub-animation-noop-able]=\"_animationMode === 'NoopAnimations'\"\n    (cubCdkObserveContent)=\"_onContentChanges()\"\n  >\n    <div class=\"cub-tab-items\" #tabListInner>\n      <ng-content></ng-content>\n    </div>\n    <cub-ink-bar></cub-ink-bar>\n  </div>\n</div>\n\n<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-after\"\n  #nextPaginator\n  [attr.aria-hidden]=\"_disableScrollAfter ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollAfter\"\n  [disabled]=\"_disableScrollAfter || null\"\n  tabindex=\"-1\"\n  (mousedown)=\"_handlePaginatorPress('after', $event)\"\n  (click)=\"_handlePaginatorClick('after')\"\n  (touchend)=\"_stopInterval()\"\n>\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-right\"></span>\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i3.Platform }], propDecorators: { _items: [{
                type: ContentChildren,
                args: [forwardRef(() => CubTabLink), { descendants: true }]
            }], _inkBar: [{
                type: ViewChild,
                args: [CubInkBar, { static: true }]
            }], _tabListContainer: [{
                type: ViewChild,
                args: ['tabListContainer', { static: true }]
            }], _tabList: [{
                type: ViewChild,
                args: ['tabList', { static: true }]
            }], _tabListInner: [{
                type: ViewChild,
                args: ['tabListInner', { static: true }]
            }], _nextPaginator: [{
                type: ViewChild,
                args: ['nextPaginator']
            }], _previousPaginator: [{
                type: ViewChild,
                args: ['previousPaginator']
            }] } });

class _CubTabBodyBase {
    /** 設定 tab body 的位置索引，會自動計算動畫狀態。 */
    set position(position) {
        this._positionIndex = position;
        this._computePositionAnimationState();
    }
    constructor(_elementRef, _dir, changeDetectorRef) {
        this._elementRef = _elementRef;
        this._dir = _dir;
        this._translateTabComplete = new Subject();
        this._dirChangeSubscription = Subscription.EMPTY;
        /** 動畫持續時間，預設為 '0ms'。 */
        this.animationDuration = '0ms';
        /** 是否保留內容（切換時不移除 DOM），預設為 false。 */
        this.preserveContent = false;
        /** 當 tab body 開始置中動畫時發出，帶入目前 tab 的高度（px）。 */
        this.onCentering = new EventEmitter();
        /** 當 tab body 動畫開始置中前發出，帶入是否為置中狀態（true/false）。 */
        this.beforeCentering = new EventEmitter();
        /** 當 tab body 離開置中狀態後發出。 */
        this.afterLeavingCenter = new EventEmitter();
        /** 當 tab body 動畫完成置中時發出。 */
        this.onCentered = new EventEmitter(true);
        if (_dir) {
            this._dirChangeSubscription = _dir.change.subscribe((dir) => {
                this._computePositionAnimationState(dir);
                changeDetectorRef.markForCheck();
            });
        }
        this._translateTabComplete
            .pipe(distinctUntilChanged((x, y) => {
            return x.fromState === y.fromState && x.toState === y.toState;
        }))
            .subscribe((event) => {
            if (this._isCenterPosition(event.toState) &&
                this._isCenterPosition(this._position)) {
                this.onCentered.emit();
            }
            if (this._isCenterPosition(event.fromState) &&
                !this._isCenterPosition(this._position)) {
                this.afterLeavingCenter.emit();
            }
        });
    }
    ngOnInit() {
        if (this._position == 'center' && this.origin != null) {
            this._position = this._computePositionFromOrigin(this.origin);
        }
    }
    ngOnDestroy() {
        this._dirChangeSubscription.unsubscribe();
        this._translateTabComplete.complete();
    }
    _onTranslateTabStarted(event) {
        const isCentering = this._isCenterPosition(event.toState);
        this.beforeCentering.emit(isCentering);
        if (isCentering) {
            this.onCentering.emit(this._elementRef.nativeElement.clientHeight);
        }
    }
    _getLayoutDirection() {
        return this._dir && this._dir.value === 'rtl' ? 'rtl' : 'ltr';
    }
    _isCenterPosition(position) {
        return (position == 'center' ||
            position == 'left-origin-center' ||
            position == 'right-origin-center');
    }
    _computePositionAnimationState(dir = this._getLayoutDirection()) {
        if (this._positionIndex < 0) {
            this._position = dir == 'ltr' ? 'left' : 'right';
        }
        else if (this._positionIndex > 0) {
            this._position = dir == 'ltr' ? 'right' : 'left';
        }
        else {
            this._position = 'center';
        }
    }
    _computePositionFromOrigin(origin) {
        const dir = this._getLayoutDirection();
        if ((dir == 'ltr' && origin <= 0) || (dir == 'rtl' && origin > 0)) {
            return 'left-origin-center';
        }
        return 'right-origin-center';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabBodyBase, deps: [{ token: i0.ElementRef }, { token: i1$1.Directionality, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubTabBodyBase, isStandalone: true, inputs: { _content: ["content", "_content"], origin: "origin", animationDuration: "animationDuration", preserveContent: "preserveContent", position: "position" }, outputs: { onCentering: "onCentering", beforeCentering: "beforeCentering", afterLeavingCenter: "afterLeavingCenter", onCentered: "onCentered" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabBodyBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { _content: [{
                type: Input,
                args: ['content']
            }], origin: [{
                type: Input
            }], animationDuration: [{
                type: Input
            }], preserveContent: [{
                type: Input
            }], position: [{
                type: Input
            }], onCentering: [{
                type: Output
            }], beforeCentering: [{
                type: Output
            }], afterLeavingCenter: [{
                type: Output
            }], onCentered: [{
                type: Output
            }] } });

class CubTabBody extends _CubTabBodyBase {
    constructor(elementRef, dir, changeDetectorRef) {
        super(elementRef, dir, changeDetectorRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabBody, deps: [{ token: i0.ElementRef }, { token: i1$1.Directionality, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTabBody, isStandalone: true, selector: "cub-tab-body", host: { classAttribute: "cub-tab-body" }, viewQueries: [{ propertyName: "_portalHost", first: true, predicate: CubCdkPortalOutlet, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"cub-tab-body-content\"\n  #content\n  [@translateTab]=\"{\n    value: _position,\n    params: { animationDuration: animationDuration }\n  }\"\n  (@translateTab.start)=\"_onTranslateTabStarted($event)\"\n  (@translateTab.done)=\"_translateTabComplete.next($event)\"\n  cubCdkScrollable\n>\n  <ng-template CubTabBodyPortal></ng-template>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: i0.forwardRef(() => CubCdkScrollable), selector: "[cub-cdk-scrollable], [cubCdkScrollable]" }, { kind: "directive", type: i0.forwardRef(() => CubTabBodyPortal), selector: "[CubTabBodyPortal]" }], animations: [cubTabsAnimations.translateTab], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabBody, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tab-body', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Default, animations: [cubTabsAnimations.translateTab], host: {
                        class: 'cub-tab-body',
                    }, imports: [CubCdkScrollable, forwardRef(() => CubTabBodyPortal)], template: "<div\n  class=\"cub-tab-body-content\"\n  #content\n  [@translateTab]=\"{\n    value: _position,\n    params: { animationDuration: animationDuration }\n  }\"\n  (@translateTab.start)=\"_onTranslateTabStarted($event)\"\n  (@translateTab.done)=\"_translateTabComplete.next($event)\"\n  cubCdkScrollable\n>\n  <ng-template CubTabBodyPortal></ng-template>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { _portalHost: [{
                type: ViewChild,
                args: [CubCdkPortalOutlet]
            }] } });
// Directive 拆出去會有循環依賴的問題目前先與 Material 一樣結構和 tab-body 放在一起
class CubTabBodyPortal extends CubCdkPortalOutlet {
    constructor(componentFactoryResolver, viewContainerRef, _host, _document) {
        super(componentFactoryResolver, viewContainerRef, _document);
        this._host = _host;
        this._centeringSub = Subscription.EMPTY;
        this._leavingSub = Subscription.EMPTY;
    }
    ngOnInit() {
        super.ngOnInit();
        this._centeringSub = this._host.beforeCentering
            .pipe(startWith$1(this._host._isCenterPosition(this._host._position)))
            .subscribe((isCentering) => {
            if (isCentering && !this.hasAttached()) {
                this.attach(this._host._content);
            }
        });
        this._leavingSub = this._host.afterLeavingCenter.subscribe(() => {
            if (!this._host.preserveContent) {
                this.detach();
            }
        });
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        this._centeringSub.unsubscribe();
        this._leavingSub.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabBodyPortal, deps: [{ token: i0.ComponentFactoryResolver }, { token: i0.ViewContainerRef }, { token: forwardRef(() => CubTabBody) }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabBodyPortal, isStandalone: true, selector: "[CubTabBodyPortal]", usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabBodyPortal, decorators: [{
            type: Directive,
            args: [{ selector: '[CubTabBodyPortal]' }]
        }], ctorParameters: () => [{ type: i0.ComponentFactoryResolver }, { type: i0.ViewContainerRef }, { type: CubTabBody, decorators: [{
                    type: Inject,
                    args: [forwardRef(() => CubTabBody)]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

const _CubTabBase = mixinDisabled(class {
});
class CubTab extends _CubTabBase {
    get content() {
        return this._contentPortal;
    }
    get templateLabel() {
        return this._templateLabel;
    }
    set templateLabel(value) {
        this._setTemplateLabelInput(value);
    }
    constructor(_viewContainerRef, _closestTabGroup) {
        super();
        this._viewContainerRef = _viewContainerRef;
        this._closestTabGroup = _closestTabGroup;
        this.position = null;
        this.origin = null;
        this.isActive = false;
        this._stateChanges = new Subject();
        this._contentPortal = null;
        /** 元件傳入的計數數值，判斷 0 是否顯示，預設值為 true。 */
        this.countHidden = true;
        /** 示的數值最大值，當超過設定數值時，會以"最大值+"顯示。 */
        this.countMax = 99;
        /** 元件標籤，預設為 ''。 */
        this.textLabel = '';
    }
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('textLabel') ||
            changes.hasOwnProperty('disabled')) {
            this._stateChanges.next();
        }
    }
    ngOnDestroy() {
        this._stateChanges.complete();
    }
    ngOnInit() {
        this._contentPortal = new TemplatePortal(this._explicitContent || this._implicitContent, this._viewContainerRef);
    }
    _setTemplateLabelInput(value) {
        if (value && value._closestTab === this) {
            this._templateLabel = value;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTab, deps: [{ token: i0.ViewContainerRef }, { token: CUB_TAB_GROUP, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTab, isStandalone: true, selector: "cub-tab", inputs: { disabled: "disabled", count: "count", countHidden: "countHidden", countMax: "countMax", textLabel: ["label", "textLabel"], ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], labelClass: "labelClass", bodyClass: "bodyClass" }, providers: [{ provide: CUB_TAB, useExisting: CubTab }], queries: [{ propertyName: "templateLabel", first: true, predicate: CUB_TAB_LABEL, descendants: true }, { propertyName: "_explicitContent", first: true, predicate: CUB_TAB_CONTENT, descendants: true, read: TemplateRef, static: true }], viewQueries: [{ propertyName: "_implicitContent", first: true, predicate: TemplateRef, descendants: true, static: true }], exportAs: ["cubTab"], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<ng-template><ng-content></ng-content></ng-template>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTab, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tab', inputs: ['disabled'], changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, exportAs: 'cubTab', providers: [{ provide: CUB_TAB, useExisting: CubTab }], template: "<ng-template><ng-content></ng-content></ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_TAB_GROUP]
                }, {
                    type: Optional
                }] }], propDecorators: { count: [{
                type: Input
            }], countHidden: [{
                type: Input
            }], countMax: [{
                type: Input
            }], textLabel: [{
                type: Input,
                args: ['label']
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], labelClass: [{
                type: Input
            }], bodyClass: [{
                type: Input
            }], templateLabel: [{
                type: ContentChild,
                args: [CUB_TAB_LABEL]
            }], _explicitContent: [{
                type: ContentChild,
                args: [CUB_TAB_CONTENT, { read: TemplateRef, static: true }]
            }], _implicitContent: [{
                type: ViewChild,
                args: [TemplateRef, { static: true }]
            }] } });

class CubTabChangeEvent {
}

let nextId = 0;
const _CubTabGroupMixinBase = mixinColor(class {
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}, 'brand');
class _CubTabGroupBase extends _CubTabGroupMixinBase {
    /** 元件方向，預設為 'horizontal'。 */
    get orientation() {
        return this._orientation;
    }
    set orientation(value) {
        this._orientation = value === 'vertical' ? 'vertical' : 'horizontal';
    }
    /**
     * 是否根據選取的 tab 動態調整高度。預設為 false。
     * 設為 true 時，tab 內容高度會隨內容自動變化。
     */
    get dynamicHeight() {
        return this._dynamicHeight;
    }
    set dynamicHeight(value) {
        this._dynamicHeight = coerceBooleanProperty(value);
    }
    /**
     * 當前選取的 tab 索引（從 0 開始）。可由外部設定或雙向繫結。
     * 預設為 null（會自動選第一個）。
     */
    get selectedIndex() {
        return this._selectedIndex;
    }
    set selectedIndex(value) {
        this._indexToSelect = coerceNumberProperty(value, null);
    }
    /**
     * tab 切換動畫持續時間，可傳數字（自動補 ms）或字串。
     * 預設為 '0ms'。
     */
    get animationDuration() {
        return this._animationDuration;
    }
    set animationDuration(value) {
        this._animationDuration = /^\d+$/.test(value + '')
            ? value + 'ms'
            : value;
    }
    /**
     * 內容區域的 tabIndex 屬性，預設為 null（不設定）。
     */
    get contentTabIndex() {
        return this._contentTabIndex;
    }
    set contentTabIndex(value) {
        this._contentTabIndex = coerceNumberProperty(value, null);
    }
    /**
     * 是否停用 tab 分頁按鈕（當 tab 過多時不顯示左右切換箭頭）。
     * 預設為 false。
     */
    get disablePagination() {
        return this._disablePagination;
    }
    set disablePagination(value) {
        this._disablePagination = coerceBooleanProperty(value);
    }
    /**
     * 切換 tab 時是否保留內容（不移除 DOM），預設為 false。
     */
    get preserveContent() {
        return this._preserveContent;
    }
    set preserveContent(value) {
        this._preserveContent = coerceBooleanProperty(value);
    }
    constructor(elementRef, _changeDetectorRef, defaultConfig, _animationMode) {
        super(elementRef);
        this._changeDetectorRef = _changeDetectorRef;
        this._animationMode = _animationMode;
        this._tabs = new QueryList();
        /**
         * 【暫不開放使用】
         * tab 標頭（tab 標籤列）顯示位置。可選 'above'（上方）、'below'（下方）、'before'（左側）、'after'（右側）。
         * 預設為 'above'。
         */
        // @Input()
        this.headerPosition = 'above';
        this._indexToSelect = 0;
        this._lastFocusedTabIndex = null;
        this._tabBodyWrapperHeight = 0;
        this._tabsSubscription = Subscription.EMPTY;
        this._tabLabelSubscription = Subscription.EMPTY;
        this._orientation = 'horizontal';
        this._dynamicHeight = false;
        this._selectedIndex = null;
        this._disablePagination = false;
        this._preserveContent = false;
        /** 元件外觀樣式，預設為 'line'。 */
        this.appearance = 'line';
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
        /**
         * 當選取的 tab 索引變更時發出。
         */
        this.selectedIndexChange = new EventEmitter();
        /**
         * 當 tab header focus 變更時發出。
         */
        this.focusChange = new EventEmitter();
        /**
         * 當 tab 動畫完成時發出。
         */
        this.animationDone = new EventEmitter();
        /**
         * 當選取的 tab 變更時發出，包含索引與 tab 實例。
         */
        this.selectedTabChange = new EventEmitter(true);
        this._groupId = nextId++;
        this.animationDuration =
            defaultConfig && defaultConfig.animationDuration
                ? defaultConfig.animationDuration
                : '0ms';
        this.disablePagination =
            defaultConfig && defaultConfig.disablePagination != null
                ? defaultConfig.disablePagination
                : false;
        this.dynamicHeight =
            defaultConfig && defaultConfig.dynamicHeight != null
                ? defaultConfig.dynamicHeight
                : false;
        this.contentTabIndex = defaultConfig?.contentTabIndex ?? null;
        this.preserveContent = !!defaultConfig?.preserveContent;
    }
    ngAfterContentChecked() {
        const indexToSelect = (this._indexToSelect = this._clampTabIndex(this._indexToSelect));
        if (this._selectedIndex != indexToSelect) {
            const isFirstRun = this._selectedIndex == null;
            if (!isFirstRun) {
                this.selectedTabChange.emit(this._createChangeEvent(indexToSelect));
                const wrapper = this._tabBodyWrapper.nativeElement;
                wrapper.style.minHeight = wrapper.clientHeight + 'px';
            }
            Promise.resolve().then(() => {
                this._tabs.forEach((tab, index) => (tab.isActive = index === indexToSelect));
                if (!isFirstRun) {
                    this.selectedIndexChange.emit(indexToSelect);
                    this._tabBodyWrapper.nativeElement.style.minHeight = '';
                }
            });
        }
        this._tabs.forEach((tab, index) => {
            tab.position = index - indexToSelect;
            if (this._selectedIndex != null && tab.position == 0 && !tab.origin) {
                tab.origin = indexToSelect - this._selectedIndex;
            }
        });
        if (this._selectedIndex !== indexToSelect) {
            this._selectedIndex = indexToSelect;
            this._lastFocusedTabIndex = null;
            this._changeDetectorRef.markForCheck();
        }
    }
    ngAfterContentInit() {
        this._subscribeToAllTabChanges();
        this._subscribeToTabLabels();
        this._tabsSubscription = this._tabs.changes.subscribe(() => {
            const indexToSelect = this._clampTabIndex(this._indexToSelect);
            if (indexToSelect === this._selectedIndex) {
                const tabs = this._tabs.toArray();
                let selectedTab;
                for (let i = 0; i < tabs.length; i++) {
                    if (tabs[i].isActive) {
                        this._indexToSelect = this._selectedIndex = i;
                        this._lastFocusedTabIndex = null;
                        selectedTab = tabs[i];
                        break;
                    }
                }
                if (!selectedTab && tabs[indexToSelect]) {
                    Promise.resolve().then(() => {
                        tabs[indexToSelect].isActive = true;
                        this.selectedTabChange.emit(this._createChangeEvent(indexToSelect));
                    });
                }
            }
            this._changeDetectorRef.markForCheck();
        });
    }
    ngOnDestroy() {
        this._tabs.destroy();
        this._tabsSubscription.unsubscribe();
        this._tabLabelSubscription.unsubscribe();
    }
    realignInkBar() {
        if (this._tabHeader) {
            this._tabHeader._alignInkBarToSelectedTab();
        }
    }
    updatePagination() {
        if (this._tabHeader) {
            this._tabHeader.updatePagination();
        }
    }
    focusTab(index) {
        const header = this._tabHeader;
        if (header) {
            header.focusIndex = index;
        }
    }
    _focusChanged(index) {
        this._lastFocusedTabIndex = index;
        this.focusChange.emit(this._createChangeEvent(index));
    }
    _getTabLabelId(i) {
        return `cub-tab-label-${this._groupId}-${i}`;
    }
    _getTabContentId(i) {
        return `cub-tab-content-${this._groupId}-${i}`;
    }
    _setTabBodyWrapperHeight(tabHeight) {
        if (!this._dynamicHeight || !this._tabBodyWrapperHeight) {
            return;
        }
        const wrapper = this._tabBodyWrapper.nativeElement;
        wrapper.style.height = this._tabBodyWrapperHeight + 'px';
        if (this._tabBodyWrapper.nativeElement.offsetHeight) {
            wrapper.style.height = tabHeight + 'px';
        }
    }
    _removeTabBodyWrapperHeight() {
        const wrapper = this._tabBodyWrapper.nativeElement;
        this._tabBodyWrapperHeight = wrapper.clientHeight;
        wrapper.style.height = '';
        this.animationDone.emit();
    }
    _handleClick(tab, tabHeader, index) {
        if (!tab.disabled) {
            this.selectedIndex = tabHeader.focusIndex = index;
        }
    }
    _getTabIndex(tab, index) {
        if (tab.disabled) {
            return null;
        }
        const targetIndex = this._lastFocusedTabIndex ?? this.selectedIndex;
        return index === targetIndex ? 0 : -1;
    }
    _tabFocusChanged(focusOrigin, index) {
        if (focusOrigin && focusOrigin !== 'mouse' && focusOrigin !== 'touch') {
            this._tabHeader.focusIndex = index;
        }
    }
    _clampTabIndex(index) {
        return Math.min(this._tabs.length - 1, Math.max(index || 0, 0));
    }
    _subscribeToAllTabChanges() {
        this._allTabs.changes
            .pipe(startWith(this._allTabs))
            .subscribe((tabs) => {
            this._tabs.reset(tabs.filter((tab) => {
                return tab._closestTabGroup === this || !tab._closestTabGroup;
            }));
            this._tabs.notifyOnChanges();
        });
    }
    _createChangeEvent(index) {
        const event = new CubTabChangeEvent();
        event.index = index;
        if (this._tabs && this._tabs.length) {
            event.tab = this._tabs.toArray()[index];
        }
        return event;
    }
    _subscribeToTabLabels() {
        if (this._tabLabelSubscription) {
            this._tabLabelSubscription.unsubscribe();
        }
        this._tabLabelSubscription = merge(...this._tabs.map((tab) => tab._stateChanges)).subscribe(() => this._changeDetectorRef.markForCheck());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabGroupBase, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: CUB_TABS_CONFIG, optional: true }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubTabGroupBase, isStandalone: true, inputs: { appearance: "appearance", size: "size", orientation: "orientation", dynamicHeight: "dynamicHeight", selectedIndex: "selectedIndex", animationDuration: "animationDuration", contentTabIndex: "contentTabIndex", disablePagination: "disablePagination", preserveContent: "preserveContent" }, outputs: { selectedIndexChange: "selectedIndexChange", focusChange: "focusChange", animationDone: "animationDone", selectedTabChange: "selectedTabChange" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabGroupBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_TABS_CONFIG]
                }, {
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { appearance: [{
                type: Input
            }], size: [{
                type: Input
            }], orientation: [{
                type: Input
            }], dynamicHeight: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], animationDuration: [{
                type: Input
            }], contentTabIndex: [{
                type: Input
            }], disablePagination: [{
                type: Input
            }], preserveContent: [{
                type: Input
            }], selectedIndexChange: [{
                type: Output
            }], focusChange: [{
                type: Output
            }], animationDone: [{
                type: Output
            }], selectedTabChange: [{
                type: Output
            }] } });

const _CubTabLabelWrapperBase = mixinDisabled(class {
});
class CubTabLabelWrapper extends _CubTabLabelWrapperBase {
    constructor(elementRef) {
        super();
        this.elementRef = elementRef;
    }
    focus() {
        this.elementRef.nativeElement.focus();
    }
    getOffsetLeft() {
        return this.elementRef.nativeElement.offsetLeft;
    }
    getOffsetWidth() {
        return this.elementRef.nativeElement.offsetWidth;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabLabelWrapper, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabLabelWrapper, isStandalone: true, selector: "[CubTabLabelWrapper]", inputs: { disabled: "disabled" }, host: { properties: { "class.cub-disabled": "disabled", "attr.aria-disabled": "!!disabled" } }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabLabelWrapper, decorators: [{
            type: Directive,
            args: [{
                    selector: '[CubTabLabelWrapper]',
                    /** 元件是否禁用，預設為 false。 */
                    inputs: ['disabled'],
                    host: {
                        '[class.cub-disabled]': 'disabled',
                        '[attr.aria-disabled]': '!!disabled',
                    }
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

class CubTabCount {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        /** 元件傳入的計數數值，預設值為 0。 */
        this.count = 0;
        /** 元件傳入的計數數值，判斷 0 是否隱藏，預設值為 true。 */
        this.countHidden = true;
        /** 示的數值最大值，當超過設定數值時，會以"最大值+"顯示，預設值 99。 */
        this.max = 99;
        this.countElement = this.renderer.createElement('span');
        this.renderer.addClass(this.countElement, 'cub-tab-count');
        this.renderer.appendChild(this.el.nativeElement, this.countElement);
    }
    ngOnInit() {
        this.updateRenderedContent(this.count);
    }
    ngOnChanges(changes) {
        if (changes['count'] || changes['max']) {
            this.updateRenderedContent(this.count);
        }
    }
    /* 確認內容是否有超過限制大小 */
    checkRenderedContent(newContent) {
        const value = Number(newContent ?? 0);
        if (this.max != null && value > this.max) {
            return `${this.max}+`;
        }
        return `${value}`;
    }
    /* 更新顯示內容 */
    updateRenderedContent(newContent) {
        // 如果 countHidden 為 true 且 count 為 0，不顯示
        if (this.countHidden && (!newContent || Number(newContent) === 0)) {
            this.countElement.style.display = 'none';
        }
        else {
            this.countElement.style.display = '';
            const newContentNormalized = this.checkRenderedContent(newContent);
            this.countElement.textContent = newContentNormalized;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabCount, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabCount, isStandalone: true, selector: "[cubTabCount]", inputs: { count: ["cubTabCount", "count"], countHidden: ["cubTabCountHidden", "countHidden"], max: ["cubTabCountMax", "max"] }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabCount, decorators: [{
            type: Directive,
            args: [{ selector: '[cubTabCount]' }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { count: [{
                type: Input,
                args: ['cubTabCount']
            }], countHidden: [{
                type: Input,
                args: ['cubTabCountHidden']
            }], max: [{
                type: Input,
                args: ['cubTabCountMax']
            }] } });

class _CubTabHeaderBase extends CubTabHeaderPaginated {
    constructor(elementRef, changeDetectorRef, viewportRuler, dir, ngZone, platform) {
        super(elementRef, changeDetectorRef, viewportRuler, dir, ngZone, platform);
    }
    _itemSelected(event) {
        event.preventDefault();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabHeaderBase, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i1$1.Directionality, optional: true }, { token: i0.NgZone }, { token: i3.Platform }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: _CubTabHeaderBase, isStandalone: true, selector: "[CubTabHeaderBase]", usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: _CubTabHeaderBase, decorators: [{
            type: Directive,
            args: [{
                    selector: '[CubTabHeaderBase]',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.NgZone }, { type: i3.Platform }] });

class CubTabHeader extends _CubTabHeaderBase {
    constructor(elementRef, changeDetectorRef, viewportRuler, dir, ngZone, platform) {
        super(elementRef, changeDetectorRef, viewportRuler, dir, ngZone, platform);
        if (this.cubTabGroup) {
            this._orientation = this.cubTabGroup.orientation;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabHeader, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i1$1.Directionality, optional: true }, { token: i0.NgZone }, { token: i3.Platform }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTabHeader, isStandalone: true, selector: "cub-tab-header", inputs: { selectedIndex: "selectedIndex" }, outputs: { selectFocusedIndex: "selectFocusedIndex", indexFocused: "indexFocused" }, host: { properties: { "class.cub-tab-header-pagination-controls-enabled": "_showPaginationControls", "class.cub-tab-header-rtl": "_getLayoutDirection() == 'rtl'" }, classAttribute: "cub-tab-header" }, queries: [{ propertyName: "_items", predicate: CubTabLabelWrapper }], viewQueries: [{ propertyName: "_inkBar", first: true, predicate: CubInkBar, descendants: true, static: true }, { propertyName: "_tabListContainer", first: true, predicate: ["tabListContainer"], descendants: true, static: true }, { propertyName: "_tabList", first: true, predicate: ["tabList"], descendants: true, static: true }, { propertyName: "_tabListInner", first: true, predicate: ["tabListInner"], descendants: true, static: true }, { propertyName: "_nextPaginator", first: true, predicate: ["nextPaginator"], descendants: true }, { propertyName: "_previousPaginator", first: true, predicate: ["previousPaginator"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-before\"\n  #previousPaginator\n  [attr.aria-hidden]=\"_disableScrollBefore ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollBefore\"\n  tabindex=\"-1\"\n  [disabled]=\"_disableScrollBefore || null\"\n  (click)=\"_handlePaginatorClick('before')\"\n  (mousedown)=\"_handlePaginatorPress('before', $event)\"\n  (touchend)=\"_stopInterval()\"\n>\n  @if (_orientation === 'vertical') {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-up\"></span>\n  } @else {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-left\"></span>\n  }\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n\n<div\n  class=\"cub-tab-item-container\"\n  #tabListContainer\n  (keydown)=\"_handleKeydown($event)\"\n>\n  <div\n    #tabList\n    class=\"cub-tab-list\"\n    [class.cub-animation-noop-able]=\"_animationMode === 'NoopAnimations'\"\n    role=\"tablist\"\n    (cubCdkObserveContent)=\"_onContentChanges()\"\n  >\n    <div class=\"cub-tab-items\" #tabListInner>\n      <ng-content></ng-content>\n    </div>\n    <cub-ink-bar></cub-ink-bar>\n  </div>\n</div>\n\n<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-after\"\n  #nextPaginator\n  [attr.aria-hidden]=\"_disableScrollAfter ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollAfter\"\n  [disabled]=\"_disableScrollAfter || null\"\n  tabindex=\"-1\"\n  (mousedown)=\"_handlePaginatorPress('after', $event)\"\n  (click)=\"_handlePaginatorClick('after')\"\n  (touchend)=\"_stopInterval()\"\n>\n  @if (_orientation === 'vertical') {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-down\"></span> }\n  @else {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-right\"></span>\n  }\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: CubCdkObserveContent, selector: "[cubCdkObserveContent]", inputs: ["cubCdkObserveContentDisabled", "debounce"], outputs: ["cubCdkObserveContent"], exportAs: ["cubCdkObserveContent"] }, { kind: "directive", type: CubInkBar, selector: "cub-ink-bar" }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabHeader, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tab-header', inputs: ['selectedIndex'], outputs: ['selectFocusedIndex', 'indexFocused'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Default, host: {
                        class: 'cub-tab-header',
                        '[class.cub-tab-header-pagination-controls-enabled]': '_showPaginationControls',
                        '[class.cub-tab-header-rtl]': "_getLayoutDirection() == 'rtl'",
                    }, imports: [CubRipple, CubCdkObserveContent, CubInkBar], template: "<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-before\"\n  #previousPaginator\n  [attr.aria-hidden]=\"_disableScrollBefore ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollBefore\"\n  tabindex=\"-1\"\n  [disabled]=\"_disableScrollBefore || null\"\n  (click)=\"_handlePaginatorClick('before')\"\n  (mousedown)=\"_handlePaginatorPress('before', $event)\"\n  (touchend)=\"_stopInterval()\"\n>\n  @if (_orientation === 'vertical') {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-up\"></span>\n  } @else {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-left\"></span>\n  }\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n\n<div\n  class=\"cub-tab-item-container\"\n  #tabListContainer\n  (keydown)=\"_handleKeydown($event)\"\n>\n  <div\n    #tabList\n    class=\"cub-tab-list\"\n    [class.cub-animation-noop-able]=\"_animationMode === 'NoopAnimations'\"\n    role=\"tablist\"\n    (cubCdkObserveContent)=\"_onContentChanges()\"\n  >\n    <div class=\"cub-tab-items\" #tabListInner>\n      <ng-content></ng-content>\n    </div>\n    <cub-ink-bar></cub-ink-bar>\n  </div>\n</div>\n\n<button\n  class=\"cub-tab-header-pagination cub-tab-header-pagination-after\"\n  #nextPaginator\n  [attr.aria-hidden]=\"_disableScrollAfter ? 'true' : null\"\n  type=\"button\"\n  cubRipple\n  cubRippleClass=\"cub-tab-button-ripple\"\n  [cubRippleDisabled]=\"_disableScrollAfter\"\n  [disabled]=\"_disableScrollAfter || null\"\n  tabindex=\"-1\"\n  (mousedown)=\"_handlePaginatorPress('after', $event)\"\n  (click)=\"_handlePaginatorClick('after')\"\n  (touchend)=\"_stopInterval()\"\n>\n  @if (_orientation === 'vertical') {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-down\"></span> }\n  @else {\n  <span class=\"cub-tab-header-pagination-icon cub-icon-chevron-right\"></span>\n  }\n  <span class=\"cub-persistent-ripple cub-tab-button-persistent-ripple\"></span>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i1$1.Directionality, decorators: [{
                    type: Optional
                }] }, { type: i0.NgZone }, { type: i3.Platform }], propDecorators: { _items: [{
                type: ContentChildren,
                args: [CubTabLabelWrapper, { descendants: false }]
            }], _inkBar: [{
                type: ViewChild,
                args: [CubInkBar, { static: true }]
            }], _tabListContainer: [{
                type: ViewChild,
                args: ['tabListContainer', { static: true }]
            }], _tabList: [{
                type: ViewChild,
                args: ['tabList', { static: true }]
            }], _tabListInner: [{
                type: ViewChild,
                args: ['tabListInner', { static: true }]
            }], _nextPaginator: [{
                type: ViewChild,
                args: ['nextPaginator']
            }], _previousPaginator: [{
                type: ViewChild,
                args: ['previousPaginator']
            }] } });

class CubTabGroup extends _CubTabGroupBase {
    constructor(elementRef, changeDetectorRef, defaultConfig, _animationMode) {
        super(elementRef, changeDetectorRef, defaultConfig, _animationMode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabGroup, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: CUB_TABS_CONFIG, optional: true }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTabGroup, isStandalone: true, selector: "cub-tab-group", host: { properties: { "class.cub-tab-group-dynamic-height": "dynamicHeight", "class.cub-tab-group-inverted-header": "headerPosition === \"below\"", "class.cub-tab-group-vertical": "orientation === \"vertical\"", "class.cub-tab-line": "appearance === \"line\"", "class.cub-tab-outline": "appearance === \"outline\"", "class.cub-tab-filled": "appearance === \"filled\"", "class.cub-tab-small": "size === \"small\"" }, classAttribute: "cub-tab-group" }, providers: [
            {
                provide: CUB_TAB_GROUP,
                useExisting: CubTabGroup,
            },
        ], queries: [{ propertyName: "_allTabs", predicate: CubTab, descendants: true }], viewQueries: [{ propertyName: "_tabBodyWrapper", first: true, predicate: ["tabBodyWrapper"], descendants: true }, { propertyName: "_tabHeader", first: true, predicate: ["tabHeader"], descendants: true }], exportAs: ["cubTabGroup"], usesInheritance: true, ngImport: i0, template: "<cub-tab-header\n  #tabHeader\n  [selectedIndex]=\"selectedIndex || 0\"\n  [disablePagination]=\"disablePagination\"\n  (indexFocused)=\"_focusChanged($event)\"\n  (selectFocusedIndex)=\"selectedIndex = $event\"\n>\n  @for (tab of _tabs; track tab; let i = $index) {\n  <div\n    class=\"cub-tab-item cub-tab-label cub-focus-indicator\"\n    role=\"tab\"\n    CubTabLabelWrapper\n    cubCdkMonitorElementFocus\n    [id]=\"_getTabLabelId(i)\"\n    [attr.tabIndex]=\"_getTabIndex(tab, i)\"\n    [attr.aria-posinset]=\"i + 1\"\n    [attr.aria-setsize]=\"_tabs.length\"\n    [attr.aria-controls]=\"_getTabContentId(i)\"\n    [attr.aria-selected]=\"selectedIndex === i\"\n    [attr.aria-label]=\"tab.ariaLabel || null\"\n    [attr.aria-labelledby]=\"\n      !tab.ariaLabel && tab.ariaLabelledby ? tab.ariaLabelledby : null\n    \"\n    [disabled]=\"tab.disabled\"\n    [class.cub-tab-item-active]=\"selectedIndex === i\"\n    [ngClass]=\"tab.labelClass\"\n    (click)=\"_handleClick(tab, tabHeader, i)\"\n    (keydown.enter)=\"_handleClick(tab, tabHeader, i)\"\n    (keydown.space)=\"_handleClick(tab, tabHeader, i)\"\n    (cubCdkFocusChange)=\"_tabFocusChanged($event, i)\"\n    cubRipple\n    cubRippleClass=\"cub-tab-item-ripple\"\n    [cubRippleDisabled]=\"tab.disabled\"\n    [cubTooltip]=\"tabTooltip\"\n    [cubTooltipDisabled]=\"orientation !== 'vertical'\"\n    [cubTooltipShowDelay]=\"100\"\n    [cubTooltipPosition]=\"'right'\"\n  >\n    <div class=\"cub-tab-item-content\">\n      <!-- \u986F\u793A Label Text-->\n      <div class=\"cub-tab-item-text\">\n        <ng-container [ngTemplateOutlet]=\"tabTextContent\"></ng-container>\n      </div>\n\n      <!-- \u986F\u793A Count -->\n      @if (tab.count !== null && tab.count !== undefined) {\n      <span\n        [cubTabCount]=\"tab.count\"\n        [cubTabCountHidden]=\"tab.countHidden\"\n        [cubTabCountMax]=\"tab.countMax\"\n      ></span>\n      }\n    </div>\n\n    <!-- \u986F\u793A Tooltip -->\n    <ng-template #tabTooltip>\n      <ng-container [ngTemplateOutlet]=\"tabTextContent\"></ng-container>\n    </ng-template>\n\n    <!-- Label & Tooltip \u6587\u5B57\u5171\u7528 Template -->\n    <ng-template #tabTextContent>\n      @if (tab.templateLabel) {\n      <ng-template [cubCdkPortalOutlet]=\"tab.templateLabel\"></ng-template>\n      } @else {\n      {{ tab.textLabel }}\n      }\n    </ng-template>\n\n    <span class=\"cub-persistent-ripple cub-tab-item-persistent-ripple\"></span>\n  </div>\n  }\n</cub-tab-header>\n\n<div\n  class=\"cub-tab-body-wrapper\"\n  [class.cub-animation-noopable]=\"_animationMode === 'NoopAnimations'\"\n  #tabBodyWrapper\n>\n  @for (tab of _tabs; track tab; let i = $index) {\n  <cub-tab-body\n    role=\"tabpanel\"\n    [id]=\"_getTabContentId(i)\"\n    [attr.tabindex]=\"\n      contentTabIndex != null && selectedIndex === i ? contentTabIndex : null\n    \"\n    [attr.aria-labelledby]=\"_getTabLabelId(i)\"\n    [class.cub-tab-body-active]=\"selectedIndex === i\"\n    [class.cub-tab-body-inactive]=\"selectedIndex !== i\"\n    [ngClass]=\"tab.bodyClass\"\n    [content]=\"tab.content!\"\n    [position]=\"tab.position!\"\n    [origin]=\"tab.origin\"\n    [animationDuration]=\"animationDuration\"\n    [preserveContent]=\"preserveContent\"\n    (onCentered)=\"_removeTabBodyWrapperHeight()\"\n    (onCentering)=\"_setTabBodyWrapperHeight($event)\"\n  >\n  </cub-tab-body>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "component", type: CubTabHeader, selector: "cub-tab-header", inputs: ["selectedIndex"], outputs: ["selectFocusedIndex", "indexFocused"] }, { kind: "directive", type: CubTabLabelWrapper, selector: "[CubTabLabelWrapper]", inputs: ["disabled"] }, { kind: "directive", type: CubCdkMonitorFocus, selector: "[cubCdkMonitorElementFocus], [cubCdkMonitorSubtreeFocus]", outputs: ["cubCdkFocusChange"], exportAs: ["cubCdkMonitorFocus"] }, { kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: CubTooltipTrigger, selector: "[cubTooltip]", inputs: ["cubTooltipShowArrow", "cubTooltipPosition", "cubTooltipPositionAtOrigin", "cubTooltipDisabled", "cubTooltipShowDelay", "cubTooltipHideDelay", "cubTooltipTouchGestures", "cubTooltip", "cubTooltipClass"], exportAs: ["cubTooltip"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: CubTabCount, selector: "[cubTabCount]", inputs: ["cubTabCount", "cubTabCountHidden", "cubTabCountMax"] }, { kind: "directive", type: CubCdkPortalOutlet, selector: "[cubCdkPortalOutlet]", inputs: ["cubCdkPortalOutlet"], outputs: ["attached"], exportAs: ["cubCdkPortalOutlet"] }, { kind: "component", type: CubTabBody, selector: "cub-tab-body" }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabGroup, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tab-group', exportAs: 'cubTabGroup', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Default, providers: [
                        {
                            provide: CUB_TAB_GROUP,
                            useExisting: CubTabGroup,
                        },
                    ], host: {
                        class: 'cub-tab-group',
                        '[class.cub-tab-group-dynamic-height]': 'dynamicHeight',
                        '[class.cub-tab-group-inverted-header]': 'headerPosition === "below"',
                        '[class.cub-tab-group-vertical]': 'orientation === "vertical"',
                        '[class.cub-tab-line]': 'appearance === "line"',
                        '[class.cub-tab-outline]': 'appearance === "outline"',
                        '[class.cub-tab-filled]': 'appearance === "filled"',
                        '[class.cub-tab-small]': 'size === "small"',
                    }, imports: [
                        CubTabHeader,
                        CubTabLabelWrapper,
                        CubCdkMonitorFocus,
                        CubRipple,
                        NgClass,
                        CubTooltipTrigger,
                        NgTemplateOutlet,
                        CubTabCount,
                        CubCdkPortalOutlet,
                        CubTabBody,
                    ], template: "<cub-tab-header\n  #tabHeader\n  [selectedIndex]=\"selectedIndex || 0\"\n  [disablePagination]=\"disablePagination\"\n  (indexFocused)=\"_focusChanged($event)\"\n  (selectFocusedIndex)=\"selectedIndex = $event\"\n>\n  @for (tab of _tabs; track tab; let i = $index) {\n  <div\n    class=\"cub-tab-item cub-tab-label cub-focus-indicator\"\n    role=\"tab\"\n    CubTabLabelWrapper\n    cubCdkMonitorElementFocus\n    [id]=\"_getTabLabelId(i)\"\n    [attr.tabIndex]=\"_getTabIndex(tab, i)\"\n    [attr.aria-posinset]=\"i + 1\"\n    [attr.aria-setsize]=\"_tabs.length\"\n    [attr.aria-controls]=\"_getTabContentId(i)\"\n    [attr.aria-selected]=\"selectedIndex === i\"\n    [attr.aria-label]=\"tab.ariaLabel || null\"\n    [attr.aria-labelledby]=\"\n      !tab.ariaLabel && tab.ariaLabelledby ? tab.ariaLabelledby : null\n    \"\n    [disabled]=\"tab.disabled\"\n    [class.cub-tab-item-active]=\"selectedIndex === i\"\n    [ngClass]=\"tab.labelClass\"\n    (click)=\"_handleClick(tab, tabHeader, i)\"\n    (keydown.enter)=\"_handleClick(tab, tabHeader, i)\"\n    (keydown.space)=\"_handleClick(tab, tabHeader, i)\"\n    (cubCdkFocusChange)=\"_tabFocusChanged($event, i)\"\n    cubRipple\n    cubRippleClass=\"cub-tab-item-ripple\"\n    [cubRippleDisabled]=\"tab.disabled\"\n    [cubTooltip]=\"tabTooltip\"\n    [cubTooltipDisabled]=\"orientation !== 'vertical'\"\n    [cubTooltipShowDelay]=\"100\"\n    [cubTooltipPosition]=\"'right'\"\n  >\n    <div class=\"cub-tab-item-content\">\n      <!-- \u986F\u793A Label Text-->\n      <div class=\"cub-tab-item-text\">\n        <ng-container [ngTemplateOutlet]=\"tabTextContent\"></ng-container>\n      </div>\n\n      <!-- \u986F\u793A Count -->\n      @if (tab.count !== null && tab.count !== undefined) {\n      <span\n        [cubTabCount]=\"tab.count\"\n        [cubTabCountHidden]=\"tab.countHidden\"\n        [cubTabCountMax]=\"tab.countMax\"\n      ></span>\n      }\n    </div>\n\n    <!-- \u986F\u793A Tooltip -->\n    <ng-template #tabTooltip>\n      <ng-container [ngTemplateOutlet]=\"tabTextContent\"></ng-container>\n    </ng-template>\n\n    <!-- Label & Tooltip \u6587\u5B57\u5171\u7528 Template -->\n    <ng-template #tabTextContent>\n      @if (tab.templateLabel) {\n      <ng-template [cubCdkPortalOutlet]=\"tab.templateLabel\"></ng-template>\n      } @else {\n      {{ tab.textLabel }}\n      }\n    </ng-template>\n\n    <span class=\"cub-persistent-ripple cub-tab-item-persistent-ripple\"></span>\n  </div>\n  }\n</cub-tab-header>\n\n<div\n  class=\"cub-tab-body-wrapper\"\n  [class.cub-animation-noopable]=\"_animationMode === 'NoopAnimations'\"\n  #tabBodyWrapper\n>\n  @for (tab of _tabs; track tab; let i = $index) {\n  <cub-tab-body\n    role=\"tabpanel\"\n    [id]=\"_getTabContentId(i)\"\n    [attr.tabindex]=\"\n      contentTabIndex != null && selectedIndex === i ? contentTabIndex : null\n    \"\n    [attr.aria-labelledby]=\"_getTabLabelId(i)\"\n    [class.cub-tab-body-active]=\"selectedIndex === i\"\n    [class.cub-tab-body-inactive]=\"selectedIndex !== i\"\n    [ngClass]=\"tab.bodyClass\"\n    [content]=\"tab.content!\"\n    [position]=\"tab.position!\"\n    [origin]=\"tab.origin\"\n    [animationDuration]=\"animationDuration\"\n    [preserveContent]=\"preserveContent\"\n    (onCentered)=\"_removeTabBodyWrapperHeight()\"\n    (onCentering)=\"_setTabBodyWrapperHeight($event)\"\n  >\n  </cub-tab-body>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_TABS_CONFIG]
                }, {
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }], propDecorators: { _allTabs: [{
                type: ContentChildren,
                args: [CubTab, { descendants: true }]
            }], _tabBodyWrapper: [{
                type: ViewChild,
                args: ['tabBodyWrapper']
            }], _tabHeader: [{
                type: ViewChild,
                args: ['tabHeader']
            }] } });

/**
 * Tab 切換時，因為不同分頁內容長度不同，有時會有檢視範圍上跳問題。
 * 此修正主要目的是讓切換保持穩定且檢視範圍不上跳。
 */
class CubGroupScrollFix {
    constructor(cubTabGroup) {
        this.cubTabGroup = cubTabGroup;
        this.unsubscribe$ = new Subject();
    }
    ngAfterViewInit() {
        const content = document.querySelector('.cub-layout-content');
        if (content) {
            const scrollHandler = (_) => {
                if (this.tabChanging) {
                    content.scrollTop = this.scrollPosition;
                }
                this.scrollPosition = content.scrollTop;
            };
            content.addEventListener('scroll', scrollHandler);
        }
        this.cubTabGroup.selectedTabChange
            .pipe(takeUntil$1(this.unsubscribe$))
            .subscribe((tabChangeEvent) => {
            this.tabChanging = false;
            document.documentElement.scrollTop = this.scrollPosition;
        });
        this.cubTabGroup.selectedIndexChange
            .pipe(takeUntil$1(this.unsubscribe$))
            .subscribe((index) => {
            this.tabChanging = true;
        });
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubGroupScrollFix, deps: [{ token: CubTabGroup }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubGroupScrollFix, isStandalone: true, selector: "[cubTabGroupScrollFix]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubGroupScrollFix, decorators: [{
            type: Directive,
            args: [{ selector: '[cubTabGroupScrollFix]' }]
        }], ctorParameters: () => [{ type: CubTabGroup }] });

class CubTabContent {
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabContent, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabContent, isStandalone: true, selector: "[cubTabContent]", providers: [{ provide: CUB_TAB_CONTENT, useExisting: CubTabContent }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTabContent]',
                    providers: [{ provide: CUB_TAB_CONTENT, useExisting: CubTabContent }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

class CubTabLabel extends CubCdkPortal {
    constructor(templateRef, viewContainerRef, _closestTab) {
        super(templateRef, viewContainerRef);
        this._closestTab = _closestTab;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabLabel, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }, { token: CUB_TAB, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabLabel, isStandalone: true, selector: "[cub-tab-label],[cubTabLabel]", providers: [{ provide: CUB_TAB_LABEL, useExisting: CubTabLabel }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cub-tab-label],[cubTabLabel]',
                    providers: [{ provide: CUB_TAB_LABEL, useExisting: CubTabLabel }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_TAB]
                }, {
                    type: Optional
                }] }] });

class CubTabNavGroup {
    constructor() {
        /** 元件外觀樣式，預設為 'line'。 */
        this.appearance = 'line';
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabNavGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTabNavGroup, isStandalone: true, selector: "cub-tab-nav-group", inputs: { appearance: "appearance", size: "size" }, host: { properties: { "class.cub-tab-line": "appearance === \"line\"", "class.cub-tab-outline": "appearance === \"outline\"", "class.cub-tab-filled": "appearance === \"filled\"", "class.cub-tab-small": "size === \"small\"" }, classAttribute: "cub-tab-nav-group cub-tab-group" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabNavGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-tab-nav-group',
                    host: {
                        class: 'cub-tab-nav-group cub-tab-group',
                        '[class.cub-tab-line]': 'appearance === "line"',
                        '[class.cub-tab-outline]': 'appearance === "outline"',
                        '[class.cub-tab-filled]': 'appearance === "filled"',
                        '[class.cub-tab-small]': 'size === "small"',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { appearance: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

class CubTabModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTabModule, imports: [CubGroupScrollFix,
            CubTabNavBar,
            CubTabBody,
            CubTabGroup,
            CubTabHeader,
            CubTab,
            CubTabNavPanel,
            CubTabBodyPortal,
            CubInkBar,
            CubTabLabelWrapper,
            CubTabLabel,
            CubTabLink,
            CubTabContent,
            CubTabNavGroup,
            CubTabCount], exports: [CubGroupScrollFix,
            CubTabNavBar,
            CubTabBody,
            CubTabGroup,
            CubTabHeader,
            CubTab,
            CubTabNavPanel,
            CubTabBodyPortal,
            CubInkBar,
            CubTabLabelWrapper,
            CubTabLabel,
            CubTabLink,
            CubTabContent,
            CubTabNavGroup,
            CubTabCount] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTabModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubGroupScrollFix,
                        CubTabNavBar,
                        CubTabBody,
                        CubTabGroup,
                        CubTabHeader,
                        CubTab,
                        CubTabNavPanel,
                        CubTabBodyPortal,
                        CubInkBar,
                        CubTabLabelWrapper,
                        CubTabLabel,
                        CubTabLink,
                        CubTabContent,
                        CubTabNavGroup,
                        CubTabCount,
                    ],
                    exports: [
                        CubGroupScrollFix,
                        CubTabNavBar,
                        CubTabBody,
                        CubTabGroup,
                        CubTabHeader,
                        CubTab,
                        CubTabNavPanel,
                        CubTabBodyPortal,
                        CubInkBar,
                        CubTabLabelWrapper,
                        CubTabLabel,
                        CubTabLink,
                        CubTabContent,
                        CubTabNavGroup,
                        CubTabCount,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/tab
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_TAB, CUB_TABS_CONFIG, CUB_TAB_CONTENT, CUB_TAB_GROUP, CUB_TAB_LABEL, CubGroupScrollFix, CubInkBar, CubTab, CubTabBody, CubTabBodyPortal, CubTabChangeEvent, CubTabContent, CubTabCount, CubTabGroup, CubTabHeader, CubTabHeaderPaginated, CubTabLabel, CubTabLabelWrapper, CubTabLink, CubTabModule, CubTabNavBar, CubTabNavGroup, CubTabNavPanel, EXAGGERATED_OVERSCROLL, HEADER_SCROLL_DELAY, HEADER_SCROLL_INTERVAL, _CubTabBodyBase, _CubTabGroupBase, _CubTabHeaderBase, _CubTabLinkBase, _CubTabNavBase, cubTabsAnimations, passiveEventListenerOptions };
//# sourceMappingURL=cub-lib-view-rootng-component-tab.mjs.map
