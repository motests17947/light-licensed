import * as i0 from '@angular/core';
import { EventEmitter, ContentChildren, ViewChild, Output, Input, ViewEncapsulation, ChangeDetectionStrategy, Component, Injectable, forwardRef, Directive, HostListener, NgModule } from '@angular/core';
import { NgStyle, NgClass, NgTemplateOutlet, NgIf } from '@angular/common';
import * as i2 from 'cub-lib-view-rootng/component/common';
import { DomHandler, CubTemplate, UniqueComponentId, ObjectUtils, FilterMatchMode, CubPrefix, TranslationKeys, CubCommonModule } from 'cub-lib-view-rootng/component/common';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';
import { CubButton, CubIconButton } from 'cub-lib-view-rootng/component/button';
import { CubPaginator } from 'cub-lib-view-rootng/component/paginator';
import { Subject } from 'rxjs';
import { CubDropDownTrigger, CubDropDown, CubDropDownGroup, CubDropDownOption } from 'cub-lib-view-rootng/component/drop-down';
import { CubPopoverTrigger, CubPopover } from 'cub-lib-view-rootng/component/popover';
import { CubRadio } from 'cub-lib-view-rootng/component/radio';
import { CubCheckbox } from 'cub-lib-view-rootng/component/checkbox';
import { CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { CUB_SELECT_SCROLL_STRATEGY_PROVIDER } from 'cub-lib-view-rootng/component/select';

class CubScroller {
    get vertical() {
        return this._orientation === 'vertical';
    }
    get horizontal() {
        return this._orientation === 'horizontal';
    }
    get both() {
        return this._orientation === 'both';
    }
    get loadedItems() {
        if (this._items && !this.d_loading) {
            if (this.both)
                return this._items
                    .slice(this._appendOnly ? 0 : this.first.rows, this.last.rows)
                    .map((item) => this._columns
                    ? item
                    : item.slice(this._appendOnly ? 0 : this.first.cols, this.last.cols));
            else if (this.horizontal && this._columns)
                return this._items;
            else
                return this._items.slice(this._appendOnly ? 0 : this.first, this.last);
        }
        return [];
    }
    get loadedRows() {
        return this.d_loading
            ? this._loaderDisabled
                ? this.loaderArr
                : []
            : this.loadedItems;
    }
    get loadedColumns() {
        if (this._columns && (this.both || this.horizontal)) {
            return this.d_loading && this._loaderDisabled
                ? this.both
                    ? this.loaderArr[0]
                    : this.loaderArr
                : this._columns.slice(this.both ? this.first.cols : this.first, this.both ? this.last.cols : this.last);
        }
        return this._columns;
    }
    get isPageChanged() {
        return this._step ? this.page !== this.getPageByFirst() : true;
    }
    /** 元件唯一識別符，預設為 undefined。 */
    get id() {
        return this._id;
    }
    set id(value) {
        this._id = value;
    }
    /** 元件的行內樣式，預設為 undefined。 */
    get style() {
        return this._style;
    }
    set style(value) {
        this._style = value;
    }
    /** 元件的類別樣式，預設為 undefined。 */
    get styleClass() {
        return this._styleClass;
    }
    set styleClass(value) {
        this._styleClass = value;
    }
    /** 元件的鍵盤導航順序，預設為 undefined。 */
    get tabindex() {
        return this._tabindex;
    }
    set tabindex(value) {
        this._tabindex = value;
    }
    /** 要顯示的物件陣列，預設為 undefined。 */
    get items() {
        return this._items;
    }
    set items(value) {
        this._items = value;
    }
    /** 根據方向調整項目的高度/寬度，預設為 0。 */
    get itemSize() {
        return this._itemSize;
    }
    set itemSize(value) {
        this._itemSize = value;
    }
    /** 滾動的視窗高度，預設為 undefined。 */
    get scrollHeight() {
        return this._scrollHeight;
    }
    set scrollHeight(value) {
        this._scrollHeight = value;
    }
    /** 滾動的視窗寬度，預設為 undefined。 */
    get scrollWidth() {
        return this._scrollWidth;
    }
    set scrollWidth(value) {
        this._scrollWidth = value;
    }
    /** 滾動條的顯示方向，有效值為 'vertical'（垂直）、'horizontal'（水平）與 'both'（兩者），預設為 'vertical'。 */
    get orientation() {
        return this._orientation;
    }
    set orientation(value) {
        this._orientation = value;
    }
    /** 是否以行內元素顯示，預設為 false。 */
    get inline() {
        return this._inline;
    }
    set inline(value) {
        this._inline = value;
    }
    /** 在延遲載入模式下，每次載入多少個項目，預設為 0。 */
    get step() {
        return this._step;
    }
    set step(value) {
        this._step = value;
    }
    /** 滾動後到載入新資料前的延遲時間，預設為 0。 */
    get delay() {
        return this._delay;
    }
    set delay(value) {
        this._delay = value;
    }
    /** 視窗調整大小完成後的延遲時間，預設為 10。 */
    get resizeDelay() {
        return this._resizeDelay;
    }
    set resizeDelay(value) {
        this._resizeDelay = value;
    }
    /** 是否將每個載入的項目附加到頂部，而不從 DOM 中移除任何項目，預設為 false。 */
    get appendOnly() {
        return this._appendOnly;
    }
    set appendOnly(value) {
        this._appendOnly = value;
    }
    /** 是否啟用延遲載入功能，預設為 false。 */
    get lazy() {
        return this._lazy;
    }
    set lazy(value) {
        this._lazy = value;
    }
    /** 是否為禁用狀態，預設為 false。 */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = value;
    }
    /** 是否自訂讀取動畫，而不使用預設的讀取動畫，預設為 false。 */
    get loaderDisabled() {
        return this._loaderDisabled;
    }
    set loaderDisabled(value) {
        this._loaderDisabled = value;
    }
    /** 動態欄位的物件陣列資料，預設為 undefined。 */
    get columns() {
        return this._columns;
    }
    set columns(value) {
        this._columns = value;
    }
    /** 是否自訂間隔器，而不使用預設的間隔器，預設為 true。 */
    get showSpacer() {
        return this._showSpacer;
    }
    set showSpacer(value) {
        this._showSpacer = value;
    }
    /** 是否顯示讀取動畫，預設為 false。 */
    get showLoader() {
        return this._showLoader;
    }
    set showLoader(value) {
        this._showLoader = value;
    }
    /** 決定在視窗外要新增多少額外元素。根據上下滾動，會以此數字的倍數形式新增額外項目。預設值是視窗中顯示項目數量的一半。 */
    get numToleratedItems() {
        return this._numToleratedItems;
    }
    set numToleratedItems(value) {
        this._numToleratedItems = value;
    }
    /** 是否為載入狀態，預設為 undefined。 */
    get loading() {
        return this._loading;
    }
    set loading(value) {
        this._loading = value;
    }
    /** 是否動態改變可滾動容器的高度或寬度，預設為 false。 */
    get autoSize() {
        return this._autoSize;
    }
    set autoSize(value) {
        this._autoSize = value;
    }
    /** 透過 ngForTrackBy 來檢查元素的唯一識別符，預設為 undefined。 */
    get trackBy() {
        return this._trackBy;
    }
    set trackBy(value) {
        this._trackBy = value;
    }
    /** 滾動器項目設定，預設為 undefined。 */
    get options() {
        return this._options;
    }
    set options(value) {
        this._options = value;
        if (value && typeof value === 'object') {
            Object.entries(value).forEach(([k, v]) => this[`_${k}`] !== v && (this[`_${k}`] = v));
        }
    }
    constructor(cd, zone) {
        this.cd = cd;
        this.zone = zone;
        this.d_loading = false;
        this.first = 0;
        this.last = 0;
        this.page = 0;
        this.numItemsInViewport = 0;
        this.lastScrollPos = 0;
        this.lazyLoadState = {};
        this.loaderArr = [];
        this.spacerStyle = {};
        this.contentStyle = {};
        this.initialized = false;
        this._tabindex = 0;
        this._itemSize = 0;
        this._orientation = 'vertical';
        this._inline = false;
        this._step = 0;
        this._delay = 0;
        this._resizeDelay = 10;
        this._appendOnly = false;
        this._lazy = false;
        this._disabled = false;
        this._loaderDisabled = false;
        this._showSpacer = true;
        this._showLoader = false;
        this._autoSize = false;
        /** 在延遲載入模式下載入新資料時調用的通知事件。 */
        this.lazyLoad = new EventEmitter();
        /** 當滾動位置改變時調用的通知事件。 */
        this.scroll = new EventEmitter();
        /** 當滾動位置和視窗中項目範圍改變時調用的通知事件。 */
        this.scrollIndexChange = new EventEmitter();
    }
    ngOnInit() {
        this.setInitialState();
    }
    ngOnChanges(simpleChanges) {
        let isLoadingChanged = false;
        if (simpleChanges['loading']) {
            const { previousValue, currentValue } = simpleChanges['loading'];
            if (this.lazy &&
                previousValue !== currentValue &&
                currentValue !== this.d_loading) {
                this.d_loading = currentValue;
                isLoadingChanged = true;
            }
        }
        if (simpleChanges['orientation']) {
            this.lastScrollPos = this.both ? { top: 0, left: 0 } : 0;
        }
        if (simpleChanges['numToleratedItems']) {
            const { previousValue, currentValue } = simpleChanges['numToleratedItems'];
            if (previousValue !== currentValue &&
                currentValue !== this.d_numToleratedItems) {
                this.d_numToleratedItems = currentValue;
            }
        }
        if (simpleChanges['options']) {
            const { previousValue, currentValue } = simpleChanges['options'];
            if (this.lazy &&
                previousValue?.loading !== currentValue?.loading &&
                currentValue?.loading !== this.d_loading) {
                this.d_loading = currentValue.loading;
                isLoadingChanged = true;
            }
            if (previousValue?.numToleratedItems !== currentValue?.numToleratedItems &&
                currentValue?.numToleratedItems !== this.d_numToleratedItems) {
                this.d_numToleratedItems = currentValue.numToleratedItems;
            }
        }
        if (this.initialized) {
            const isChanged = !isLoadingChanged &&
                (simpleChanges['items']?.previousValue?.length !==
                    simpleChanges['items']?.currentValue?.length ||
                    simpleChanges['itemSize'] ||
                    simpleChanges['scrollHeight'] ||
                    simpleChanges['scrollWidth']);
            if (isChanged) {
                this.init();
                this.calculateAutoSize();
            }
        }
    }
    ngAfterContentInit() {
        this.templates.forEach((item) => {
            switch (item.getType()) {
                case 'content':
                    this.contentTemplate = item.template;
                    break;
                case 'item':
                    this.itemTemplateRef = item.template;
                    break;
                case 'loader':
                    this.loaderTemplateRef = item.template;
                    break;
                case 'loadericon':
                    this.loaderIconTemplateRef = item.template;
                    break;
                default:
                    this.itemTemplateRef = item.template;
                    break;
            }
        });
    }
    ngAfterViewInit() {
        this.viewInit();
    }
    ngAfterViewChecked() {
        if (!this.initialized) {
            this.viewInit();
        }
    }
    ngOnDestroy() {
        this.unbindResizeListener();
        this.contentEl = null;
        this.initialized = false;
    }
    viewInit() {
        if (DomHandler.isVisible(this.elementViewChild?.nativeElement)) {
            this.setInitialState();
            this.setContentEl(this.contentEl);
            this.init();
            this.defaultWidth = DomHandler.getWidth(this.elementViewChild.nativeElement);
            this.defaultHeight = DomHandler.getHeight(this.elementViewChild.nativeElement);
            this.initialized = true;
        }
    }
    init() {
        if (!this._disabled) {
            this.setSize();
            this.calculateOptions();
            this.setSpacerSize();
            this.bindResizeListener();
            this.cd.detectChanges();
        }
    }
    setContentEl(el) {
        this.contentEl =
            el ||
                this.contentViewChild?.nativeElement ||
                DomHandler.findSingle(this.elementViewChild?.nativeElement, '.cub-scroller-content');
    }
    setInitialState() {
        this.first = this.both ? { rows: 0, cols: 0 } : 0;
        this.last = this.both ? { rows: 0, cols: 0 } : 0;
        this.numItemsInViewport = this.both ? { rows: 0, cols: 0 } : 0;
        this.lastScrollPos = this.both ? { top: 0, left: 0 } : 0;
        this.d_loading = this._loading || false;
        this.d_numToleratedItems = this._numToleratedItems;
        this.loaderArr = [];
        this.spacerStyle = {};
        this.contentStyle = {};
    }
    getElementRef() {
        return this.elementViewChild;
    }
    getPageByFirst() {
        return Math.floor((this.first + this.d_numToleratedItems * 4) / (this._step || 1));
    }
    scrollTo(options) {
        this.lastScrollPos = this.both ? { top: 0, left: 0 } : 0;
        this.elementViewChild?.nativeElement?.scrollTo(options);
    }
    scrollToIndex(index, behavior = 'auto') {
        const { numToleratedItems } = this.calculateNumItems();
        const contentPos = this.getContentPosition();
        const calculateFirst = (_index = 0, _numT) => _index <= _numT ? 0 : _index;
        const calculateCoord = (_first, _size, _cpos) => _first * _size + _cpos;
        const scrollTo = (left = 0, top = 0) => this.scrollTo({ left, top, behavior });
        if (this.both) {
            this.first = {
                rows: calculateFirst(index[0], numToleratedItems[0]),
                cols: calculateFirst(index[1], numToleratedItems[1]),
            };
            scrollTo(calculateCoord(this.first.cols, this._itemSize[1], contentPos.left), calculateCoord(this.first.rows, this._itemSize[0], contentPos.top));
        }
        else {
            this.first = calculateFirst(index, numToleratedItems);
            this.horizontal
                ? scrollTo(calculateCoord(this.first, this._itemSize, contentPos.left), 0)
                : scrollTo(0, calculateCoord(this.first, this._itemSize, contentPos.top));
        }
    }
    scrollInView(index, to, behavior = 'auto') {
        if (to) {
            const { first, viewport } = this.getRenderedRange();
            const scrollTo = (left = 0, top = 0) => this.scrollTo({ left, top, behavior });
            const isToStart = to === 'to-start';
            const isToEnd = to === 'to-end';
            if (isToStart) {
                if (this.both) {
                    if (viewport.first.rows - first.rows > index[0]) {
                        scrollTo(viewport.first.cols * this._itemSize[1], (viewport.first.rows - 1) * this._itemSize[0]);
                    }
                    else if (viewport.first.cols - first.cols > index[1]) {
                        scrollTo((viewport.first.cols - 1) * this._itemSize[1], viewport.first.rows * this._itemSize[0]);
                    }
                }
                else {
                    if (viewport.first - first > index) {
                        const pos = (viewport.first - 1) * this._itemSize;
                        this.horizontal ? scrollTo(pos, 0) : scrollTo(0, pos);
                    }
                }
            }
            else if (isToEnd) {
                if (this.both) {
                    if (viewport.last.rows - first.rows <= index[0] + 1) {
                        scrollTo(viewport.first.cols * this._itemSize[1], (viewport.first.rows + 1) * this._itemSize[0]);
                    }
                    else if (viewport.last.cols - first.cols <= index[1] + 1) {
                        scrollTo((viewport.first.cols + 1) * this._itemSize[1], viewport.first.rows * this._itemSize[0]);
                    }
                }
                else {
                    if (viewport.last - first <= index + 1) {
                        const pos = (viewport.first + 1) * this._itemSize;
                        this.horizontal ? scrollTo(pos, 0) : scrollTo(0, pos);
                    }
                }
            }
        }
        else {
            this.scrollToIndex(index, behavior);
        }
    }
    getRenderedRange() {
        const calculateFirstInViewport = (_pos, _size) => Math.floor(_pos / (_size || _pos));
        let firstInViewport = this.first;
        let lastInViewport = 0;
        if (this.elementViewChild?.nativeElement) {
            const { scrollTop, scrollLeft } = this.elementViewChild.nativeElement;
            if (this.both) {
                firstInViewport = {
                    rows: calculateFirstInViewport(scrollTop, this._itemSize[0]),
                    cols: calculateFirstInViewport(scrollLeft, this._itemSize[1]),
                };
                lastInViewport = {
                    rows: firstInViewport.rows + this.numItemsInViewport.rows,
                    cols: firstInViewport.cols + this.numItemsInViewport.cols,
                };
            }
            else {
                const scrollPos = this.horizontal ? scrollLeft : scrollTop;
                firstInViewport = calculateFirstInViewport(scrollPos, this._itemSize);
                lastInViewport = firstInViewport + this.numItemsInViewport;
            }
        }
        return {
            first: this.first,
            last: this.last,
            viewport: {
                first: firstInViewport,
                last: lastInViewport,
            },
        };
    }
    calculateNumItems() {
        const contentPos = this.getContentPosition();
        const contentWidth = this.elementViewChild?.nativeElement
            ? this.elementViewChild.nativeElement.offsetWidth - contentPos.left
            : 0;
        const contentHeight = this.elementViewChild?.nativeElement
            ? this.elementViewChild.nativeElement.offsetHeight - contentPos.top
            : 0;
        const calculateNumItemsInViewport = (_contentSize, _itemSize) => Math.ceil(_contentSize / (_itemSize || _contentSize));
        const calculateNumToleratedItems = (_numItems) => Math.ceil(_numItems / 2);
        const numItemsInViewport = this.both
            ? {
                rows: calculateNumItemsInViewport(contentHeight, this._itemSize[0]),
                cols: calculateNumItemsInViewport(contentWidth, this._itemSize[1]),
            }
            : calculateNumItemsInViewport(this.horizontal ? contentWidth : contentHeight, this._itemSize);
        const numToleratedItems = this.d_numToleratedItems ||
            (this.both
                ? [
                    calculateNumToleratedItems(numItemsInViewport.rows),
                    calculateNumToleratedItems(numItemsInViewport.cols),
                ]
                : calculateNumToleratedItems(numItemsInViewport));
        return { numItemsInViewport, numToleratedItems };
    }
    calculateOptions() {
        const { numItemsInViewport, numToleratedItems } = this.calculateNumItems();
        const calculateLast = (_first, _num, _numT, _isCols = false) => this.getLast(_first + _num + (_first < _numT ? 2 : 3) * _numT, _isCols);
        const first = this.first;
        const last = this.both
            ? {
                rows: calculateLast(this.first.rows, numItemsInViewport.rows, numToleratedItems[0]),
                cols: calculateLast(this.first.cols, numItemsInViewport.cols, numToleratedItems[1], true),
            }
            : calculateLast(this.first, numItemsInViewport, numToleratedItems);
        this.last = last;
        this.numItemsInViewport = numItemsInViewport;
        this.d_numToleratedItems = numToleratedItems;
        if (this.showLoader) {
            this.loaderArr = this.both
                ? Array.from({ length: numItemsInViewport.rows }).map(() => Array.from({ length: numItemsInViewport.cols }))
                : Array.from({ length: numItemsInViewport });
        }
        if (this._lazy) {
            Promise.resolve().then(() => {
                this.lazyLoadState = {
                    first: this._step
                        ? this.both
                            ? { rows: 0, cols: first.cols }
                            : 0
                        : first,
                    last: Math.min(this._step ? this._step : this.last, this.items.length),
                };
                this.handleEvents('lazyLoad', this.lazyLoadState);
            });
        }
    }
    calculateAutoSize() {
        if (this._autoSize && !this.d_loading) {
            Promise.resolve().then(() => {
                if (this.contentEl) {
                    this.contentEl.style.minHeight = this.contentEl.style.minWidth =
                        'auto';
                    const { offsetWidth, offsetHeight } = this.contentEl;
                    (this.both || this.horizontal) &&
                        (this.elementViewChild.nativeElement.style.width =
                            (offsetWidth < this.defaultWidth
                                ? offsetWidth
                                : this.defaultWidth) + 'px');
                    (this.both || this.vertical) &&
                        (this.elementViewChild.nativeElement.style.height =
                            (offsetHeight < this.defaultHeight
                                ? offsetHeight
                                : this.defaultHeight) + 'px');
                    this.contentEl.style.minHeight = this.contentEl.style.minWidth = '';
                }
            });
        }
    }
    getLast(last = 0, isCols = false) {
        return this._items
            ? Math.min(isCols
                ? (this._columns || this._items[0]).length
                : this._items.length, last)
            : 0;
    }
    getContentPosition() {
        if (this.contentEl) {
            const style = getComputedStyle(this.contentEl);
            const left = parseFloat(style.paddingLeft) +
                Math.max(parseFloat(style.left) || 0, 0);
            const right = parseFloat(style.paddingRight) +
                Math.max(parseFloat(style.right) || 0, 0);
            const top = parseFloat(style.paddingTop) + Math.max(parseFloat(style.top) || 0, 0);
            const bottom = parseFloat(style.paddingBottom) +
                Math.max(parseFloat(style.bottom) || 0, 0);
            return { left, right, top, bottom, x: left + right, y: top + bottom };
        }
        return { left: 0, right: 0, top: 0, bottom: 0, x: 0, y: 0 };
    }
    setSize() {
        if (this.elementViewChild?.nativeElement) {
            const parentElement = this.elementViewChild.nativeElement.parentElement.parentElement;
            const width = this._scrollWidth ||
                `${this.elementViewChild.nativeElement.offsetWidth ||
                    parentElement.offsetWidth}px`;
            const height = this._scrollHeight ||
                `${this.elementViewChild.nativeElement.offsetHeight ||
                    parentElement.offsetHeight}px`;
            const setProp = (_name, _value) => (this.elementViewChild.nativeElement.style[_name] = _value);
            if (this.both || this.horizontal) {
                setProp('height', height);
                setProp('width', width);
            }
            else {
                setProp('height', height);
            }
        }
    }
    setSpacerSize() {
        if (this._items) {
            const contentPos = this.getContentPosition();
            const setProp = (_name, _value, _size, _cpos = 0) => (this.spacerStyle = {
                ...this.spacerStyle,
                ...{ [`${_name}`]: (_value || []).length * _size + _cpos + 'px' },
            });
            if (this.both) {
                setProp('height', this._items, this._itemSize[0], contentPos.y);
                setProp('width', this._columns || this._items[1], this._itemSize[1], contentPos.x);
            }
            else {
                this.horizontal
                    ? setProp('width', this._columns || this._items, this._itemSize, contentPos.x)
                    : setProp('height', this._items, this._itemSize, contentPos.y);
            }
        }
    }
    setContentPosition(pos) {
        if (this.contentEl && !this._appendOnly) {
            const first = pos ? pos.first : this.first;
            const calculateTranslateValue = (_first, _size) => _first * _size;
            const setTransform = (_x = 0, _y = 0) => (this.contentStyle = {
                ...this.contentStyle,
                ...{ transform: `translate3d(${_x}px, ${_y}px, 0)` },
            });
            if (this.both) {
                setTransform(calculateTranslateValue(first.cols, this._itemSize[1]), calculateTranslateValue(first.rows, this._itemSize[0]));
            }
            else {
                const translateValue = calculateTranslateValue(first, this._itemSize);
                this.horizontal
                    ? setTransform(translateValue, 0)
                    : setTransform(0, translateValue);
            }
        }
    }
    onScrollPositionChange(event) {
        const target = event.target;
        const contentPos = this.getContentPosition();
        const calculateScrollPos = (_pos, _cpos) => _pos ? (_pos > _cpos ? _pos - _cpos : _pos) : 0;
        const calculateCurrentIndex = (_pos, _size) => Math.floor(_pos / (_size || _pos));
        const calculateTriggerIndex = (_currentIndex, _first, _last, _num, _numT, _isScrollDownOrRight) => {
            return _currentIndex <= _numT
                ? _numT
                : _isScrollDownOrRight
                    ? _last - _num - _numT
                    : _first + _numT - 1;
        };
        const calculateFirst = (_currentIndex, _triggerIndex, _first, _last, _num, _numT, _isScrollDownOrRight) => {
            if (_currentIndex <= _numT)
                return 0;
            else
                return Math.max(0, _isScrollDownOrRight
                    ? _currentIndex < _triggerIndex
                        ? _first
                        : _currentIndex - _numT
                    : _currentIndex > _triggerIndex
                        ? _first
                        : _currentIndex - 2 * _numT);
        };
        const calculateLast = (_currentIndex, _first, _last, _num, _numT, _isCols = false) => {
            let lastValue = _first + _num + 2 * _numT;
            if (_currentIndex >= _numT) {
                lastValue += _numT + 1;
            }
            return this.getLast(lastValue, _isCols);
        };
        const scrollTop = calculateScrollPos(target.scrollTop, contentPos.top);
        const scrollLeft = calculateScrollPos(target.scrollLeft, contentPos.left);
        let newFirst = this.both ? { rows: 0, cols: 0 } : 0;
        let newLast = this.last;
        let isRangeChanged = false;
        let newScrollPos = this.lastScrollPos;
        if (this.both) {
            const isScrollDown = this.lastScrollPos.top <= scrollTop;
            const isScrollRight = this.lastScrollPos.left <= scrollLeft;
            if (!this._appendOnly ||
                (this._appendOnly && (isScrollDown || isScrollRight))) {
                const currentIndex = {
                    rows: calculateCurrentIndex(scrollTop, this._itemSize[0]),
                    cols: calculateCurrentIndex(scrollLeft, this._itemSize[1]),
                };
                const triggerIndex = {
                    rows: calculateTriggerIndex(currentIndex.rows, this.first.rows, this.last.rows, this.numItemsInViewport.rows, this.d_numToleratedItems[0], isScrollDown),
                    cols: calculateTriggerIndex(currentIndex.cols, this.first.cols, this.last.cols, this.numItemsInViewport.cols, this.d_numToleratedItems[1], isScrollRight),
                };
                newFirst = {
                    rows: calculateFirst(currentIndex.rows, triggerIndex.rows, this.first.rows, this.last.rows, this.numItemsInViewport.rows, this.d_numToleratedItems[0], isScrollDown),
                    cols: calculateFirst(currentIndex.cols, triggerIndex.cols, this.first.cols, this.last.cols, this.numItemsInViewport.cols, this.d_numToleratedItems[1], isScrollRight),
                };
                newLast = {
                    rows: calculateLast(currentIndex.rows, newFirst.rows, this.last.rows, this.numItemsInViewport.rows, this.d_numToleratedItems[0]),
                    cols: calculateLast(currentIndex.cols, newFirst.cols, this.last.cols, this.numItemsInViewport.cols, this.d_numToleratedItems[1], true),
                };
                isRangeChanged =
                    newFirst.rows !== this.first.rows ||
                        newLast.rows !== this.last.rows ||
                        newFirst.cols !== this.first.cols ||
                        newLast.cols !== this.last.cols;
                newScrollPos = { top: scrollTop, left: scrollLeft };
            }
        }
        else {
            const scrollPos = this.horizontal ? scrollLeft : scrollTop;
            const isScrollDownOrRight = this.lastScrollPos <= scrollPos;
            if (!this._appendOnly || (this._appendOnly && isScrollDownOrRight)) {
                const currentIndex = calculateCurrentIndex(scrollPos, this._itemSize);
                const triggerIndex = calculateTriggerIndex(currentIndex, this.first, this.last, this.numItemsInViewport, this.d_numToleratedItems, isScrollDownOrRight);
                newFirst = calculateFirst(currentIndex, triggerIndex, this.first, this.last, this.numItemsInViewport, this.d_numToleratedItems, isScrollDownOrRight);
                newLast = calculateLast(currentIndex, newFirst, this.last, this.numItemsInViewport, this.d_numToleratedItems);
                isRangeChanged = newFirst !== this.first || newLast !== this.last;
                newScrollPos = scrollPos;
            }
        }
        return {
            first: newFirst,
            last: newLast,
            isRangeChanged,
            scrollPos: newScrollPos,
        };
    }
    onScrollChange(event) {
        const { first, last, isRangeChanged, scrollPos } = this.onScrollPositionChange(event);
        if (isRangeChanged) {
            const newState = { first, last };
            this.setContentPosition(newState);
            this.first = first;
            this.last = last;
            this.lastScrollPos = scrollPos;
            this.handleEvents('scrollIndexChange', newState);
            if (this._lazy && this.isPageChanged) {
                const lazyLoadState = {
                    first: this._step
                        ? Math.min(this.getPageByFirst() * this._step, this.items.length - this._step)
                        : first,
                    last: Math.min(this._step ? (this.getPageByFirst() + 1) * this._step : last, this.items.length),
                };
                const isLazyStateChanged = this.lazyLoadState.first !== lazyLoadState.first ||
                    this.lazyLoadState.last !== lazyLoadState.last;
                isLazyStateChanged && this.handleEvents('lazyLoad', lazyLoadState);
                this.lazyLoadState = lazyLoadState;
            }
        }
    }
    onContainerScroll(event) {
        this.handleEvents('scroll', { originalEvent: event });
        if (this._delay && this.isPageChanged) {
            if (this.scrollTimeout) {
                clearTimeout(this.scrollTimeout);
            }
            if (!this.d_loading && this.showLoader) {
                const { isRangeChanged } = this.onScrollPositionChange(event);
                const changed = isRangeChanged || (this._step ? this.isPageChanged : false);
                if (changed) {
                    this.d_loading = true;
                    this.cd.detectChanges();
                }
            }
            this.scrollTimeout = setTimeout(() => {
                this.onScrollChange(event);
                if (this.d_loading &&
                    this.showLoader &&
                    (!this._lazy || this._loading === undefined)) {
                    this.d_loading = false;
                    this.page = this.getPageByFirst();
                    this.cd.detectChanges();
                }
            }, this._delay);
        }
        else {
            !this.d_loading && this.onScrollChange(event);
        }
    }
    bindResizeListener() {
        if (!this.windowResizeListener) {
            this.zone.runOutsideAngular(() => {
                this.windowResizeListener = this.onWindowResize.bind(this);
                window.addEventListener('resize', this.windowResizeListener);
                window.addEventListener('orientationchange', this.windowResizeListener);
            });
        }
    }
    unbindResizeListener() {
        if (this.windowResizeListener) {
            window.removeEventListener('resize', this.windowResizeListener);
            window.removeEventListener('orientationchange', this.windowResizeListener);
            this.windowResizeListener = null;
        }
    }
    onWindowResize() {
        if (this.resizeTimeout) {
            clearTimeout(this.resizeTimeout);
        }
        this.resizeTimeout = setTimeout(() => {
            if (DomHandler.isVisible(this.elementViewChild?.nativeElement)) {
                const [width, height] = [
                    DomHandler.getWidth(this.elementViewChild.nativeElement),
                    DomHandler.getHeight(this.elementViewChild.nativeElement),
                ];
                const [isDiffWidth, isDiffHeight] = [
                    width !== this.defaultWidth,
                    height !== this.defaultHeight,
                ];
                const reinit = this.both
                    ? isDiffWidth || isDiffHeight
                    : this.horizontal
                        ? isDiffWidth
                        : this.vertical
                            ? isDiffHeight
                            : false;
                reinit &&
                    this.zone.run(() => {
                        this.d_numToleratedItems = this._numToleratedItems;
                        this.defaultWidth = width;
                        this.defaultHeight = height;
                        this.init();
                    });
            }
        }, this._resizeDelay);
    }
    handleEvents(name, params) {
        return this.options && this.options[name]
            ? this.options[name](params)
            : this[name].emit(params);
    }
    getContentOptions() {
        return {
            contentStyleClass: `cub-scroller-content ${this.d_loading ? 'cub-scroller-loading' : ''}`,
            items: this.loadedItems,
            getItemOptions: (index) => this.getOptions(index),
            loading: this.d_loading,
            getLoaderOptions: (index, options) => this.getLoaderOptions(index, options),
            itemSize: this._itemSize,
            rows: this.loadedRows,
            columns: this.loadedColumns,
            spacerStyle: this.spacerStyle,
            contentStyle: this.contentStyle,
            vertical: this.vertical,
            horizontal: this.horizontal,
            both: this.both,
        };
    }
    getOptions(renderedIndex) {
        const count = (this._items || []).length;
        const index = this.both
            ? this.first.rows + renderedIndex
            : this.first + renderedIndex;
        return {
            index,
            count,
            first: index === 0,
            last: index === count - 1,
            even: index % 2 === 0,
            odd: index % 2 !== 0,
        };
    }
    getLoaderOptions(index, extOptions) {
        const count = this.loaderArr.length;
        return {
            index,
            count,
            first: index === 0,
            last: index === count - 1,
            even: index % 2 === 0,
            odd: index % 2 !== 0,
            ...extOptions,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubScroller, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubScroller, isStandalone: true, selector: "cub-scroller", inputs: { id: "id", style: "style", styleClass: "styleClass", tabindex: "tabindex", items: "items", itemSize: "itemSize", scrollHeight: "scrollHeight", scrollWidth: "scrollWidth", orientation: "orientation", inline: "inline", step: "step", delay: "delay", resizeDelay: "resizeDelay", appendOnly: "appendOnly", lazy: "lazy", disabled: "disabled", loaderDisabled: "loaderDisabled", columns: "columns", showSpacer: "showSpacer", showLoader: "showLoader", numToleratedItems: "numToleratedItems", loading: "loading", autoSize: "autoSize", trackBy: "trackBy", options: "options" }, outputs: { lazyLoad: "lazyLoad", scroll: "scroll", scrollIndexChange: "scrollIndexChange" }, host: { classAttribute: "cub-scroller-viewport" }, queries: [{ propertyName: "templates", predicate: CubTemplate }], viewQueries: [{ propertyName: "elementViewChild", first: true, predicate: ["element"], descendants: true }, { propertyName: "contentViewChild", first: true, predicate: ["content"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "@if (!_disabled) {\n<div\n  #element\n  [attr.id]=\"_id\"\n  [attr.tabindex]=\"tabindex\"\n  [ngStyle]=\"_style\"\n  [class]=\"_styleClass\"\n  [ngClass]=\"{\n    'cub-scroller': true,\n    'cub-scroller-inline': inline,\n    'cub-both-scroll': both,\n    'cub-horizontal-scroll': horizontal\n  }\"\n  (scroll)=\"onContainerScroll($event)\"\n>\n  @if (contentTemplate) {\n  <ng-container\n    *ngTemplateOutlet=\"\n      contentTemplate;\n      context: { $implicit: loadedItems, options: getContentOptions() }\n    \"\n  ></ng-container>\n  } @else {\n  <div\n    #content\n    class=\"cub-scroller-content\"\n    [ngClass]=\"{ 'cub-scroller-loading': d_loading }\"\n    [ngStyle]=\"contentStyle\"\n  >\n    @for (item of loadedItems; track _trackBy; let index = $index) {\n    <ng-container\n      *ngTemplateOutlet=\"\n        itemTemplateRef;\n        context: { $implicit: item, options: getOptions(index) }\n      \"\n    ></ng-container>\n    }\n  </div>\n  } @if (_showSpacer) {\n  <div class=\"cub-scroller-spacer\" [ngStyle]=\"spacerStyle\"></div>\n  } @if (!loaderDisabled && _showLoader && d_loading) {\n  <div\n    class=\"cub-scroller-loader\"\n    [ngClass]=\"{ 'cub-component-overlay': !loaderTemplateRef }\"\n  >\n    @if (loaderTemplateRef) { @for (item of loaderArr; track $index; let index =\n    $index) {\n    <ng-container\n      *ngTemplateOutlet=\"\n        loaderTemplateRef;\n        context: {\n          options: getLoaderOptions(\n            index,\n            both && { numCols: numItemsInViewport.cols }\n          )\n        }\n      \"\n    ></ng-container>\n    } } @else if(loaderIconTemplateRef) {\n    <ng-container *ngTemplateOutlet=\"loaderIconTemplateRef\"></ng-container>\n    } @else {\n    <cub-loading [size]=\"'large'\"></cub-loading>\n    }\n  </div>\n  }\n</div>\n} @else {\n<ng-content></ng-content>\n@if (contentTemplate) {\n<ng-container\n  *ngTemplateOutlet=\"\n    contentTemplate;\n    context: {\n      $implicit: items,\n      options: { rows: _items, columns: loadedColumns }\n    }\n  \"\n></ng-container>\n} }\n", styles: [""], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubScroller, decorators: [{
            type: Component,
            args: [{ selector: 'cub-scroller', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-scroller-viewport',
                    }, imports: [NgStyle, NgClass, NgTemplateOutlet, CubLoading], template: "@if (!_disabled) {\n<div\n  #element\n  [attr.id]=\"_id\"\n  [attr.tabindex]=\"tabindex\"\n  [ngStyle]=\"_style\"\n  [class]=\"_styleClass\"\n  [ngClass]=\"{\n    'cub-scroller': true,\n    'cub-scroller-inline': inline,\n    'cub-both-scroll': both,\n    'cub-horizontal-scroll': horizontal\n  }\"\n  (scroll)=\"onContainerScroll($event)\"\n>\n  @if (contentTemplate) {\n  <ng-container\n    *ngTemplateOutlet=\"\n      contentTemplate;\n      context: { $implicit: loadedItems, options: getContentOptions() }\n    \"\n  ></ng-container>\n  } @else {\n  <div\n    #content\n    class=\"cub-scroller-content\"\n    [ngClass]=\"{ 'cub-scroller-loading': d_loading }\"\n    [ngStyle]=\"contentStyle\"\n  >\n    @for (item of loadedItems; track _trackBy; let index = $index) {\n    <ng-container\n      *ngTemplateOutlet=\"\n        itemTemplateRef;\n        context: { $implicit: item, options: getOptions(index) }\n      \"\n    ></ng-container>\n    }\n  </div>\n  } @if (_showSpacer) {\n  <div class=\"cub-scroller-spacer\" [ngStyle]=\"spacerStyle\"></div>\n  } @if (!loaderDisabled && _showLoader && d_loading) {\n  <div\n    class=\"cub-scroller-loader\"\n    [ngClass]=\"{ 'cub-component-overlay': !loaderTemplateRef }\"\n  >\n    @if (loaderTemplateRef) { @for (item of loaderArr; track $index; let index =\n    $index) {\n    <ng-container\n      *ngTemplateOutlet=\"\n        loaderTemplateRef;\n        context: {\n          options: getLoaderOptions(\n            index,\n            both && { numCols: numItemsInViewport.cols }\n          )\n        }\n      \"\n    ></ng-container>\n    } } @else if(loaderIconTemplateRef) {\n    <ng-container *ngTemplateOutlet=\"loaderIconTemplateRef\"></ng-container>\n    } @else {\n    <cub-loading [size]=\"'large'\"></cub-loading>\n    }\n  </div>\n  }\n</div>\n} @else {\n<ng-content></ng-content>\n@if (contentTemplate) {\n<ng-container\n  *ngTemplateOutlet=\"\n    contentTemplate;\n    context: {\n      $implicit: items,\n      options: { rows: _items, columns: loadedColumns }\n    }\n  \"\n></ng-container>\n} }\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.NgZone }], propDecorators: { id: [{
                type: Input
            }], style: [{
                type: Input
            }], styleClass: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], items: [{
                type: Input
            }], itemSize: [{
                type: Input
            }], scrollHeight: [{
                type: Input
            }], scrollWidth: [{
                type: Input
            }], orientation: [{
                type: Input
            }], inline: [{
                type: Input
            }], step: [{
                type: Input
            }], delay: [{
                type: Input
            }], resizeDelay: [{
                type: Input
            }], appendOnly: [{
                type: Input
            }], lazy: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loaderDisabled: [{
                type: Input
            }], columns: [{
                type: Input
            }], showSpacer: [{
                type: Input
            }], showLoader: [{
                type: Input
            }], numToleratedItems: [{
                type: Input
            }], loading: [{
                type: Input
            }], autoSize: [{
                type: Input
            }], trackBy: [{
                type: Input
            }], options: [{
                type: Input
            }], lazyLoad: [{
                type: Output
            }], scroll: [{
                type: Output
            }], scrollIndexChange: [{
                type: Output
            }], elementViewChild: [{
                type: ViewChild,
                args: ['element']
            }], contentViewChild: [{
                type: ViewChild,
                args: ['content']
            }], templates: [{
                type: ContentChildren,
                args: [CubTemplate]
            }] } });

class CubTableService {
    constructor() {
        this.sortSource = new Subject();
        this.selectionSource = new Subject();
        this.contextMenuSource = new Subject();
        this.valueSource = new Subject();
        this.totalRecordsSource = new Subject();
        this.columnsSource = new Subject();
        this.resetSource = new Subject();
        this.disabledCancelCheck = new Subject();
        this.frozenTriggerCheck = new Subject();
        this.sortSource$ = this.sortSource.asObservable();
        this.selectionSource$ = this.selectionSource.asObservable();
        this.contextMenuSource$ = this.contextMenuSource.asObservable();
        this.valueSource$ = this.valueSource.asObservable();
        this.totalRecordsSource$ = this.totalRecordsSource.asObservable();
        this.columnsSource$ = this.columnsSource.asObservable();
        this.resetSource$ = this.resetSource.asObservable();
        this.disabledCancelCheck$ = this.disabledCancelCheck.asObservable();
        this.frozenTriggerCheck$ = this.frozenTriggerCheck.asObservable();
    }
    onSort(sortMeta) {
        this.sortSource.next(sortMeta);
    }
    onSelectionChange() {
        this.selectionSource.next(null);
    }
    onResetChange() {
        this.resetSource.next(null);
    }
    onContextMenu(data) {
        this.contextMenuSource.next(data);
    }
    onValueChange(value) {
        this.valueSource.next(value);
    }
    onTotalRecordsChange(value) {
        this.totalRecordsSource.next(value);
    }
    onColumnsChange(columns) {
        this.columnsSource.next(columns);
    }
    onDisabledCancelCheck() {
        this.disabledCancelCheck.next(null);
    }
    onFrozenTriggerCheck() {
        this.frozenTriggerCheck.next(null);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableService, decorators: [{
            type: Injectable
        }] });

class FilterOperator {
    static { this.AND = 'and'; }
    static { this.OR = 'or'; }
}

class CubTable {
    get processedData() {
        return this.filteredValue || this.value || [];
    }
    get selectionContent() {
        const length = this._selection?.length || 0;
        return length > 0
            ? this.selectionTemplate.replace('{length}', String(length))
            : '';
    }
    get filterContent() {
        if (this.hasFilter()) {
            const field = this.columns
                .filter((col) => this.filters[col.field] &&
                this.filters[col.field].every((filter) => !!filter.value))
                .map((col) => col.header)
                .join('、');
            return this.filterTemplate.replace('{field}', String(field));
        }
        else {
            return '';
        }
    }
    /** 表格的物件陣列資料，預設為 []。 */
    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
    }
    /** 動態欄位的物件陣列資料，預設為 undefined。 */
    get columns() {
        return this._columns;
    }
    set columns(cols) {
        this._columns = cols;
    }
    /** 總筆數，預設為 0。 */
    get totalRecords() {
        return this._totalRecords;
    }
    set totalRecords(value) {
        this._totalRecords = value;
        this.tableService.onTotalRecordsChange(this._totalRecords);
    }
    /** 每頁顯示筆數，預設為 10。 */
    get pageSize() {
        return this._pageSize;
    }
    set pageSize(value) {
        this._pageSize = value;
    }
    /** 當前頁數的第一筆資料的索引值，預設為 0。 */
    get first() {
        return this._first;
    }
    set first(value) {
        this._first = value;
    }
    /** 進行排序的欄位名稱，預設為 undefined。*/
    get sortField() {
        return this._sortField;
    }
    set sortField(value) {
        this._sortField = value;
    }
    /** 排序順序，1 表示升冪排序，-1 表示降冪排序，預設為 1。*/
    get sortOrder() {
        return this._sortOrder;
    }
    set sortOrder(value) {
        this._sortOrder = value;
    }
    /** 以多重排序模式對資料進行排序，預設為 undefined。*/
    get multiSortMeta() {
        return this._multiSortMeta;
    }
    set multiSortMeta(value) {
        this._multiSortMeta = value;
    }
    /** 在單選模式下或多選模式下所選擇的資料列，預設為 undefined。 */
    get selection() {
        return this._selection;
    }
    set selection(value) {
        this._selection = value;
    }
    /** 是否選擇所有資料，預設為 null。*/
    get selectAll() {
        return this._selection;
    }
    set selectAll(value) {
        this._selection = value;
    }
    constructor(elementRef, zone, tableService, changeDetectorRef, filterService) {
        this.elementRef = elementRef;
        this.zone = zone;
        this.tableService = tableService;
        this.changeDetectorRef = changeDetectorRef;
        this.filterService = filterService;
        this.columnResizeMode = 'fit';
        this.showLoader = true;
        this.showInitialSortBadge = true;
        this.stateStorage = 'session';
        this.editMode = 'cell';
        this.groupRowsByOrder = 1;
        this.contextMenuSelectionMode = 'separate';
        this.compareSelectionBy = 'deepEquals';
        this.csvSeparator = ',';
        this.exportFilename = 'download';
        this.filters = {};
        this.filterDelay = 300;
        this.editingRowKeys = {};
        this.scrollDirection = 'vertical';
        this.virtualScrollDelay = 250;
        this.selectionKeys = {};
        this.columnResizing = false;
        this.rowGroupHeaderStyleObject = {};
        this.id = UniqueComponentId();
        this.dragScrollMouseDown = false;
        this.disabledRowList = [];
        this._value = [];
        this._totalRecords = 0;
        this._first = 0;
        this._sortOrder = 1;
        this._selectAll = null;
        // --------------- 基本功能 ---------------
        /** 外觀樣式，預設為 'default'。 */
        this.appearance = 'default';
        /** 元件尺寸，預設為 medium */
        this.size = 'medium';
        // --------------- 分頁器 ---------------
        /** 是否開啟分頁器功能，預設為 false。 */
        this.paginator = false;
        /** 分頁類型：前端分頁 or 後端分頁，當使用 paginator 接口時才使用 */
        this.paginatorType = 'clientSide';
        /** 分頁器顯示總筆數，預設為 0。 */
        /** 僅當 paginatorType 設定為 'serverSide' 時可用。 */
        this.paginatorTotalRecords = 0;
        /** 當總頁數為一頁時是否顯示分頁器，預設為 true。 */
        this.alwaysShowPaginator = true;
        /** 頁數資訊的模板，預設為 '{first} - {last} / {totalRecords}'。 */
        this.pageRangeTemplate = '{first} - {last} / {totalRecords}';
        /** 跳至指定頁數的模板，預設為 '跳至' */
        this.jumpToTemplate = '跳至';
        /** 是否顯示頁數資訊，預設為 true。 */
        this.showPageRange = true;
        /** 是否顯示往第一頁與往最後一頁的按鈕，預設為 true。 */
        this.showFirstLastButton = true;
        /** 是否自動計算頁數連結的顯示個數，預設為 true。 */
        this.pageLinkAutoSize = true;
        /** 頁數連結的顯示個數，預設為 5。 */
        this.pageLinkSize = 5;
        /** 每頁顯示筆數選項，預設為 [10, 20, 30, 50, 100] */
        this.pageSizeOptions = [10, 20, 30, 50, 100];
        /** 是否隱藏每頁筆數的下拉選單，預設為 false。 */
        this.hidePageSize = false;
        /** 當前頁數的索引值，預設為 0。 */
        this.pageIndex = 0;
        // --------------- 排序 ---------------
        /** 當未排序的欄位透過操作進行排序時所使用的預設排序順序，預設為 1。*/
        this.defaultSortOrder = 1;
        /** 排序模式，針對單一欄位或多欄位進行排序，預設為 'single'。*/
        this.sortMode = 'single';
        /** 排序時，是否將分頁器的當前頁數重設為第一頁，預設為 true。 */
        /** 僅當 sortMode 設定為 'single' 時可用。 */
        this.resetPageOnSort = true;
        /** 是否啟用延遲載入功能，預設為 false。 */
        this.lazy = false;
        /** 是否在元件初始化階段啟用延遲載入功能，預設為 false。 */
        this.lazyLoadOnInit = true;
        // --------------- 響應式 ---------------
        /** 表格的響應式排版方式，'scroll' 為卷軸滾動，'stack' 為堆疊顯示，預設為 'scroll'。 */
        /** 當設定為 'stack' 時，使用具有「cub-column-title」的類別樣式元素來顯示欄位標題。 */
        this.responsiveLayout = 'scroll';
        // --------------- 選取 ---------------
        /** 是否只選擇目前頁面的資料列，預設為 true。 */
        /** 僅當 paginatorType 設定為 'clientSide' 時可用。
         * 'clientSide' 模式下預設選取全部資料，將 selectionPageOnly 設定為 true 時改為選取當前頁面資料。
         * 'serverSide' 模式下僅會選取當前頁面資料。 */
        this.selectionPageOnly = true;
        /** 選取項目的模板，預設為 '欄位設定' */
        this.selectionTemplate = '已選擇 {length} 項';
        /** 選取清除按鈕的模板，預設為 '欄位設定' */
        this.selectionButtonTemplate = '清除所選';
        // --------------- 篩選 ---------------
        /** 選取項目的模板，預設為 '欄位設定' */
        this.filterTemplate = '已篩選 {field}';
        /** 選取清除按鈕的模板，預設為 '欄位設定' */
        this.filterButtonTemplate = '清除篩選';
        // --------------- 欄位顯示/隱藏 ---------------
        /** 是否顯示欄位切換的按鈕，預設為 false。 */
        this.showColumnToggle = false;
        /** 欄位切換按鈕的模板，預設為 '欄位設定' */
        this.columnToggleButtonTemplate = '欄位設定';
        // --------------- 資料列展開 ---------------
        /** 資料列展開的顯示模式，有效值為 'single' 與 'multiple'，預設為 'multiple'。 */
        this.rowExpandMode = 'multiple';
        /** 預設展開的資料列鍵值，需搭配 dataKey 使用，預設為 {}。 */
        this.expandedRowKeys = {};
        // --------------- 拖曳 ---------------
        /** 是否開啟拖曳捲動，預設為 false。 */
        this.dragToScroll = false;
        // --------------- [事件] 分頁器 ---------------
        /** 當頁面第一筆索引值變更時調用的通知事件。 */
        this.firstChange = new EventEmitter();
        /** 當每頁顯示筆數變更時調用的通知事件。 */
        this.pageSizeChange = new EventEmitter();
        /** 當分頁變更時調用的通知事件。 */
        this.pageChange = new EventEmitter();
        // --------------- [事件] 排序 ---------------
        /** 實作自訂排序的函式。 */
        this.sortFunction = new EventEmitter();
        /** 當排序變更時調用的通知事件。 */
        this.sort = new EventEmitter();
        // --------------- [事件] 延遲載入 ---------------
        /** 在延遲載入模式下，進行分頁、排序或篩選時調用的通知事件。 */
        this.lazyLoad = new EventEmitter();
        // --------------- [事件] 選取 ---------------
        /** 當資料全部選取時調用的通知事件。 */
        this.selectAllChange = new EventEmitter();
        /** 當選取內容改變時調用的通知事件。 */
        this.selectionChange = new EventEmitter();
        /** 當 Header Checkbox 狀態改變時調用的通知事件。 */
        this.headerCheckboxChange = new EventEmitter();
        // --------------- [事件] 篩選 ---------------
        /** 當資料被篩選時調用的通知事件。 */
        this.filter = new EventEmitter();
        // --------------- [事件] 欄位顯示/隱藏 ---------------
        this.columnToggle = new EventEmitter();
        // --------------- [事件] 資料列展開 ---------------
        /** 當有資料列展開時調用的通知事件。 */
        this.rowExpand = new EventEmitter();
        /** 當有資料列收合時調用的通知事件。 */
        this.rowCollapse = new EventEmitter();
        // --------------- [事件] 拖曳（暫不使用） ---------------
        /** 當調整資料列大小時調用的通知事件。 */
        this.columnResize = new EventEmitter();
        /** 當欄位重新排序時調用的通知事件。 */
        this.columnReorder = new EventEmitter();
        /** 當資料列重新排序時調用的通知事件。 */
        this.rowReorder = new EventEmitter();
        //////////////////////////////////////////////////////////////////
        this.rowTrackBy = (index, item) => item;
    }
    // ------------------------- 生命週期區塊 -------------------------
    ngOnInit() {
        if (this.lazy && this.lazyLoadOnInit) {
            if (!this.virtualScroll) {
                this.lazyLoad.emit(this.createLazyLoadMetadata());
            }
            if (this.restoringFilter) {
                this.restoringFilter = false;
            }
        }
        if (this.pageIndex > 0 && this.paginatorType === 'clientSide') {
            this.first = this.pageSize * this.pageIndex;
        }
        this.initialized = true;
    }
    ngAfterContentInit() {
        this.templates.forEach((item) => {
            switch (item.getType()) {
                case 'caption':
                    this.captionTemplateRef = item.template;
                    break;
                case 'header':
                    this.headerTemplateRef = item.template;
                    break;
                case 'headergrouped':
                    this.headerGroupedTemplateRef = item.template;
                    break;
                case 'body':
                    this.bodyTemplateRef = item.template;
                    break;
                case 'loadingbody':
                    this.loadingBodyTemplateRef = item.template;
                    break;
                case 'footer':
                    this.footerTemplateRef = item.template;
                    break;
                case 'footergrouped':
                    this.footerGroupedTemplateRef = item.template;
                    break;
                case 'summary':
                    this.summaryTemplateRef = item.template;
                    break;
                case 'colgroup':
                    this.colGroupTemplateRef = item.template;
                    break;
                case 'rowexpansion':
                    this.expandedRowTemplateRef = item.template;
                    break;
                case 'groupheader':
                    this.groupHeaderTemplateRef = item.template;
                    break;
                case 'rowspan':
                    this.rowspanTemplateRef = item.template;
                    break;
                case 'groupfooter':
                    this.groupFooterTemplateRef = item.template;
                    break;
                case 'frozenrows':
                    this.frozenRowsTemplateRef = item.template;
                    break;
                case 'frozenheader':
                    this.frozenHeaderTemplateRef = item.template;
                    break;
                case 'frozenbody':
                    this.frozenBodyTemplateRef = item.template;
                    break;
                case 'frozenfooter':
                    this.frozenFooterTemplateRef = item.template;
                    break;
                case 'frozencolgroup':
                    this.frozenColGroupTemplateRef = item.template;
                    break;
                case 'frozenrowexpansion':
                    this.frozenExpandedRowTemplateRef = item.template;
                    break;
                case 'emptymessage':
                    this.emptyMessageTemplateRef = item.template;
                    break;
            }
        });
    }
    ngAfterViewInit() {
        if (this.isStateful() && this.resizableColumns) {
            this.restoreColumnWidths();
        }
    }
    ngOnChanges(simpleChange) {
        if (simpleChange['value']) {
            if (this.isStateful() && !this.stateRestored) {
                this.restoreState();
            }
            this._value = simpleChange['value'].currentValue;
            if (!this.lazy) {
                if (this.paginator && this.paginatorType === 'clientSide') {
                    this.totalRecords = this._value ? this._value.length : 0;
                }
                else {
                    this.totalRecords = this.paginatorTotalRecords
                        ? this.paginatorTotalRecords
                        : this._value.length;
                }
                if (this.sortMode == 'single' && (this.sortField || this.groupRowsBy))
                    this.sortSingle();
                else if (this.sortMode == 'multiple' &&
                    (this.multiSortMeta || this.groupRowsBy))
                    this.sortMultiple();
                else if (this.hasFilter())
                    //sort already filters
                    this._filter();
            }
            this.tableService.onValueChange(simpleChange['value'].currentValue);
        }
        if (simpleChange['columns']) {
            this._columns = simpleChange['columns'].currentValue;
            this.tableService.onColumnsChange(simpleChange['columns'].currentValue);
            if (this._columns &&
                this.isStateful() &&
                this.reorderableColumns &&
                !this.columnOrderStateRestored) {
                this.restoreColumnOrder();
            }
        }
        if (simpleChange['sortField']) {
            this._sortField = simpleChange['sortField'].currentValue;
            //avoid triggering lazy load prior to lazy initialization at onInit
            if (!this.lazy || this.initialized) {
                if (this.sortMode === 'single') {
                    this.sortSingle();
                }
            }
        }
        if (simpleChange['groupRowsBy']) {
            //avoid triggering lazy load prior to lazy initialization at onInit
            if (!this.lazy || this.initialized) {
                if (this.sortMode === 'single') {
                    this.sortSingle();
                }
            }
        }
        if (simpleChange['sortOrder']) {
            this._sortOrder = simpleChange['sortOrder'].currentValue;
            //avoid triggering lazy load prior to lazy initialization at onInit
            if (!this.lazy || this.initialized) {
                if (this.sortMode === 'single') {
                    this.sortSingle();
                }
            }
        }
        if (simpleChange['groupRowsByOrder']) {
            //avoid triggering lazy load prior to lazy initialization at onInit
            if (!this.lazy || this.initialized) {
                if (this.sortMode === 'single') {
                    this.sortSingle();
                }
            }
        }
        if (simpleChange['multiSortMeta']) {
            this._multiSortMeta = simpleChange['multiSortMeta'].currentValue;
            if (this.sortMode === 'multiple' &&
                (this.initialized || (!this.lazy && !this.virtualScroll))) {
                this.sortMultiple();
            }
        }
        if (simpleChange['selection']) {
            this._selection = simpleChange['selection'].currentValue;
            if (!this.preventSelectionSetterPropagation) {
                this.updateSelectionKeys();
                this.tableService.onSelectionChange();
            }
            this.preventSelectionSetterPropagation = false;
        }
        if (simpleChange['selectAll']) {
            this._selectAll = simpleChange['selectAll'].currentValue;
            if (!this.preventSelectionSetterPropagation) {
                this.updateSelectionKeys();
                this.tableService.onSelectionChange();
                if (this.isStateful()) {
                    this.saveState();
                }
            }
            this.preventSelectionSetterPropagation = false;
        }
    }
    ngOnDestroy() {
        this.unbindDocumentEditListener();
        this.editingCell = null;
        this.initialized = null;
        this.destroyStyleElement();
        this.destroyResponsiveStyle();
    }
    dataToRender(data) {
        const _data = data || this.processedData;
        if (_data && this.paginator && this.paginatorType === 'clientSide') {
            const first = this.lazy ? 0 : this.first;
            return _data.slice(first, first + this.pageSize);
        }
        return _data;
    }
    updateSelectionKeys() {
        if (this.dataKey && this._selection) {
            this.selectionKeys = {};
            if (Array.isArray(this._selection)) {
                for (let data of this._selection) {
                    this.selectionKeys[String(ObjectUtils.resolveFieldData(data, this.dataKey))] = 1;
                }
            }
            else {
                this.selectionKeys[String(ObjectUtils.resolveFieldData(this._selection, this.dataKey))] = 1;
            }
        }
    }
    onPageChange(event) {
        /**
         *  paginatorState = {
         *    first: 目前頁數第一列資料索引,
         *    pageIndex: 目前頁數索引,
         *    pageCount: 總頁數,
         *    pageSize: 單頁筆數,
         *    totalRecords: 資料總筆數,
         *  }
         */
        this.first = event.first;
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;
        if (this.paginatorType === 'clientSide') {
            this.totalRecords = event.totalRecords;
        }
        else {
            this.paginatorTotalRecords = event.totalRecords;
        }
        this.pageChange.emit({
            first: this.first,
            pageIndex: this.pageIndex,
            pageSize: this.pageSize,
            totalRecords: this.paginatorType === 'clientSide'
                ? this.totalRecords
                : this.paginatorTotalRecords,
        });
        if (this.lazy) {
            this.lazyLoad.emit(this.createLazyLoadMetadata());
        }
        this.firstChange.emit(this.first);
        this.pageSizeChange.emit(this.pageSize);
        this.tableService.onValueChange(this.value);
        if (this.isStateful()) {
            this.saveState();
        }
        this.anchorRowIndex = null;
        if (this.scrollable) {
            this.resetScrollTop();
        }
    }
    onSort(event) {
        let originalEvent = event.originalEvent;
        if (this.sortMode === 'single') {
            this._sortOrder =
                this.sortField === event.field
                    ? this.sortOrder * -1
                    : this.defaultSortOrder;
            this._sortField = event.field;
            if (this.resetPageOnSort) {
                this._first = 0;
                this.firstChange.emit(this._first);
                if (this.scrollable) {
                    this.resetScrollTop();
                }
            }
            this.sortSingle();
        }
        if (this.sortMode === 'multiple') {
            let metaKey = originalEvent.metaKey || originalEvent.ctrlKey;
            let sortMeta = this.getSortMeta(event.field);
            if (sortMeta) {
                if (!metaKey) {
                    this._multiSortMeta = [
                        {
                            field: event.field,
                            order: sortMeta.order * -1,
                        },
                    ];
                    if (this.resetPageOnSort) {
                        this._first = 0;
                        this.firstChange.emit(this._first);
                        if (this.scrollable) {
                            this.resetScrollTop();
                        }
                    }
                }
                else {
                    sortMeta.order = sortMeta.order * -1;
                }
            }
            else {
                if (!metaKey || !this.multiSortMeta) {
                    this._multiSortMeta = [];
                    if (this.resetPageOnSort) {
                        this._first = 0;
                        this.firstChange.emit(this._first);
                    }
                }
                this._multiSortMeta.push({
                    field: event.field,
                    order: this.defaultSortOrder,
                });
            }
            this.sortMultiple();
        }
        if (this.isStateful()) {
            this.saveState();
        }
        this.anchorRowIndex = null;
    }
    hasFilter() {
        let empty = true;
        for (let prop in this.filters) {
            const hasFilter = this.filters.hasOwnProperty(prop);
            const hasFilterValue = hasFilter
                ? this.filters[prop].every((filter) => !!filter.value)
                : false;
            if (hasFilter && hasFilterValue) {
                empty = false;
                break;
            }
        }
        return !empty;
    }
    getBlockableElement() {
        return this.elementRef.nativeElement.children[0];
    }
    getStorage() {
        switch (this.stateStorage) {
            case 'local':
                return window.localStorage;
            case 'session':
                return window.sessionStorage;
            default:
                throw new Error(this.stateStorage +
                    ' is not a valid value for the state storage, supported values are "local" and "session".');
        }
    }
    getGroupRowsMeta() {
        return { field: this.groupRowsBy, order: this.groupRowsByOrder };
    }
    getSortMeta(field) {
        if (this.multiSortMeta && this.multiSortMeta.length) {
            for (let index = 0; index < this.multiSortMeta.length; index++) {
                if (this.multiSortMeta[index].field === field) {
                    return this.multiSortMeta[index];
                }
            }
        }
        return null;
    }
    isSorted(field) {
        if (this.sortMode === 'single') {
            return this.sortField && this.sortField === field;
        }
        else if (this.sortMode === 'multiple') {
            let sorted = false;
            if (this.multiSortMeta) {
                for (let index = 0; index < this.multiSortMeta.length; index++) {
                    if (this.multiSortMeta[index].field == field) {
                        sorted = true;
                        break;
                    }
                }
            }
            return sorted;
        }
        else {
            return null;
        }
    }
    handleRowClick(event) {
        let target = event.originalEvent.target;
        let targetNode = target.nodeName;
        let parentNode = target.parentElement && target.parentElement.nodeName;
        if (targetNode == 'INPUT' ||
            targetNode == 'BUTTON' ||
            targetNode == 'A' ||
            parentNode == 'INPUT' ||
            parentNode == 'BUTTON' ||
            parentNode == 'A' ||
            DomHandler.hasClass(event.originalEvent.target, 'cub-clickable')) {
            return;
        }
        if (this.selectionMode) {
            let rowData = event.rowData;
            let rowIndex = event.rowIndex;
            this.preventSelectionSetterPropagation = true;
            if (this.isMultipleSelectionMode() &&
                event.originalEvent.shiftKey &&
                this.anchorRowIndex != null) {
                DomHandler.clearSelection();
                if (this.rangeRowIndex != null) {
                    this.clearSelectionRange(event.originalEvent);
                }
                this.rangeRowIndex = rowIndex;
                this.selectRange(event.originalEvent, rowIndex);
            }
            else {
                let selected = this.isSelected(rowData);
                if (!selected && !this.isRowSelectable(rowData, rowIndex)) {
                    return;
                }
                let metaSelection = this.rowTouched ? false : this.metaKeySelection;
                let dataKeyValue = this.dataKey
                    ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey))
                    : null;
                this.anchorRowIndex = rowIndex;
                this.rangeRowIndex = rowIndex;
                if (metaSelection) {
                    let metaKey = event.originalEvent.metaKey || event.originalEvent.ctrlKey;
                    if (selected && metaKey) {
                        if (this.isSingleSelectionMode()) {
                            this._selection = null;
                            this.selectionKeys = {};
                            this.selectionChange.emit(null);
                        }
                        else {
                            let selectionIndex = this.findIndexInSelection(rowData);
                            this._selection = this.selection.filter((value, index) => index != selectionIndex);
                            this.selectionChange.emit(this.selection);
                            if (dataKeyValue) {
                                delete this.selectionKeys[dataKeyValue];
                            }
                        }
                    }
                    else {
                        if (this.isSingleSelectionMode()) {
                            this._selection = rowData;
                            this.selectionChange.emit(rowData);
                            if (dataKeyValue) {
                                this.selectionKeys = {};
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                        else if (this.isMultipleSelectionMode()) {
                            if (metaKey) {
                                this._selection = this.selection || [];
                            }
                            else {
                                this._selection = [];
                                this.selectionKeys = {};
                            }
                            this._selection = [...this.selection, rowData];
                            this.selectionChange.emit(this.selection);
                            if (dataKeyValue) {
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                    }
                }
                else {
                    if (this.selectionMode === 'single') {
                        if (selected) {
                            this._selection = null;
                            this.selectionKeys = {};
                            this.selectionChange.emit(this.selection);
                        }
                        else {
                            this._selection = rowData;
                            this.selectionChange.emit(this.selection);
                            if (dataKeyValue) {
                                this.selectionKeys = {};
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                    }
                    else if (this.selectionMode === 'multiple') {
                        if (selected) {
                            let selectionIndex = this.findIndexInSelection(rowData);
                            this._selection = this.selection.filter((value, index) => index != selectionIndex);
                            this.selectionChange.emit(this.selection);
                            if (dataKeyValue) {
                                delete this.selectionKeys[dataKeyValue];
                            }
                        }
                        else {
                            this._selection = this.selection
                                ? [...this.selection, rowData]
                                : [rowData];
                            this.selectionChange.emit(this.selection);
                            if (dataKeyValue) {
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                    }
                }
            }
            this.tableService.onSelectionChange();
            if (this.isStateful()) {
                this.saveState();
            }
        }
        this.rowTouched = false;
    }
    handleRowTouchEnd(event) {
        this.rowTouched = true;
    }
    handleRowRightClick(event) {
        if (this.contextMenu) {
            const rowData = event.rowData;
            const rowIndex = event.rowIndex;
            if (this.contextMenuSelectionMode === 'separate') {
                this.contextMenuSelection = rowData;
                this.contextMenu.show(event.originalEvent);
                this.tableService.onContextMenu(rowData);
            }
            else if (this.contextMenuSelectionMode === 'joint') {
                this.preventSelectionSetterPropagation = true;
                let selected = this.isSelected(rowData);
                let dataKeyValue = this.dataKey
                    ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey))
                    : null;
                if (!selected) {
                    if (!this.isRowSelectable(rowData, rowIndex)) {
                        return;
                    }
                    if (this.isSingleSelectionMode()) {
                        this.selection = rowData;
                        this.selectionChange.emit(rowData);
                        if (dataKeyValue) {
                            this.selectionKeys = {};
                            this.selectionKeys[dataKeyValue] = 1;
                        }
                    }
                    else if (this.isMultipleSelectionMode()) {
                        this._selection = this.selection
                            ? [...this.selection, rowData]
                            : [rowData];
                        this.selectionChange.emit(this.selection);
                        if (dataKeyValue) {
                            this.selectionKeys[dataKeyValue] = 1;
                        }
                    }
                }
                this.tableService.onSelectionChange();
                this.contextMenu.show(event.originalEvent);
            }
        }
    }
    _filter() {
        if (!this.restoringFilter) {
            this.first = 0;
            this.firstChange.emit(this.first);
        }
        if (this.lazy) {
            this.lazyLoad.emit(this.createLazyLoadMetadata());
        }
        else {
            if (!this.value) {
                return;
            }
            if (!this.hasFilter()) {
                this.filteredValue = null;
                if (this.paginator && this.paginatorType === 'clientSide') {
                    this.totalRecords = this._value ? this._value.length : 0;
                }
                else {
                    this.totalRecords = this.paginatorTotalRecords
                        ? this.paginatorTotalRecords
                        : this._value.length;
                }
            }
            else {
                let globalFilterFieldsArray;
                if (this.filters['global']) {
                    if (!this.columns && !this.globalFilterFields)
                        throw new Error('Global filtering requires dynamic columns or globalFilterFields to be defined.');
                    else
                        globalFilterFieldsArray = this.globalFilterFields || this.columns;
                }
                this.filteredValue = [];
                for (let index = 0; index < this.value.length; index++) {
                    let localMatch = true;
                    let globalMatch = false;
                    let localFiltered = false;
                    for (let prop in this.filters) {
                        if (this.filters.hasOwnProperty(prop) && prop !== 'global') {
                            localFiltered = true;
                            let filterField = prop;
                            let filterMeta = this.filters[filterField];
                            if (Array.isArray(filterMeta)) {
                                for (let meta of filterMeta) {
                                    localMatch = this.executeLocalFilter(filterField, this.value[index], meta);
                                    if ((meta.operator === FilterOperator.OR && localMatch) ||
                                        (meta.operator === FilterOperator.AND && !localMatch)) {
                                        break;
                                    }
                                }
                            }
                            else {
                                localMatch = this.executeLocalFilter(filterField, this.value[index], filterMeta);
                            }
                            if (!localMatch) {
                                break;
                            }
                        }
                    }
                    if (this.filters['global'] &&
                        !globalMatch &&
                        globalFilterFieldsArray) {
                        for (let j = 0; j < globalFilterFieldsArray.length; j++) {
                            let globalFilterField = globalFilterFieldsArray[j].field ||
                                globalFilterFieldsArray[j];
                            globalMatch = this.filterService.filters[this.filters['global']
                                .matchMode](ObjectUtils.resolveFieldData(this.value[index], globalFilterField), this.filters['global'].value, this.filterLocale);
                            if (globalMatch) {
                                break;
                            }
                        }
                    }
                    let matches;
                    if (this.filters['global']) {
                        matches = localFiltered
                            ? localFiltered && localMatch && globalMatch
                            : globalMatch;
                    }
                    else {
                        matches = localFiltered && localMatch;
                    }
                    if (matches) {
                        this.filteredValue.push(this.value[index]);
                    }
                }
                if (this.filteredValue.length === this.value.length) {
                    this.filteredValue = null;
                }
                if (this.paginator && this.paginatorType === 'clientSide') {
                    this.totalRecords = this.filteredValue
                        ? this.filteredValue.length
                        : this.value
                            ? this.value.length
                            : 0;
                }
            }
        }
        this.filter.emit({
            filters: this.filters,
            filteredValue: this.filteredValue || this.value,
        });
        this.tableService.onValueChange(this.value);
        if (this.isStateful() && !this.restoringFilter) {
            this.saveState();
        }
        if (this.restoringFilter) {
            this.restoringFilter = false;
        }
        this.changeDetectorRef.markForCheck();
        if (this.scrollable) {
            this.resetScrollTop();
        }
    }
    createLazyLoadMetadata() {
        return {
            first: this.first,
            pageIndex: this.pageIndex,
            pageSize: this.pageSize,
            totalRecords: this.paginatorType === 'clientSide'
                ? this.totalRecords
                : this.paginatorTotalRecords,
            sortField: this.sortField,
            sortOrder: this.sortOrder,
            filters: this.filters,
            globalFilter: this.filters && this.filters['global']
                ? this.filters['global'].value
                : null,
            multiSortMeta: this.multiSortMeta,
            forceUpdate: () => this.changeDetectorRef.detectChanges(),
        };
    }
    destroyResponsiveStyle() {
        if (this.responsiveStyleElement) {
            document.head.removeChild(this.responsiveStyleElement);
            this.responsiveStyleElement = null;
        }
    }
    destroyStyleElement() {
        if (this.styleElement) {
            document.head.removeChild(this.styleElement);
            this.styleElement = null;
        }
    }
    createStyleElement() {
        this.styleElement = document.createElement('style');
        this.styleElement.type = 'text/css';
        document.head.appendChild(this.styleElement);
    }
    compareValuesOnSort(value1, value2, order) {
        return ObjectUtils.sort(value1, value2, order, this.filterLocale, this.sortOrder);
    }
    executeLocalFilter(field, rowData, filterMeta) {
        let filterValue = filterMeta.value;
        let filterMatchMode = filterMeta.matchMode || FilterMatchMode.STARTS_WITH;
        let dataFieldValue = ObjectUtils.resolveFieldData(rowData, field);
        let filterConstraint = this.filterService.filters[filterMatchMode];
        return filterConstraint(dataFieldValue, filterValue, this.filterLocale);
    }
    multisortField(data1, data2, multiSortMeta, index) {
        const value1 = ObjectUtils.resolveFieldData(data1, multiSortMeta[index].field);
        const value2 = ObjectUtils.resolveFieldData(data2, multiSortMeta[index].field);
        if (ObjectUtils.compare(value1, value2, this.filterLocale) === 0) {
            return multiSortMeta.length - 1 > index
                ? this.multisortField(data1, data2, multiSortMeta, index + 1)
                : 0;
        }
        return this.compareValuesOnSort(value1, value2, multiSortMeta[index].order);
    }
    isStateful() {
        return this.stateKey != null;
    }
    saveState() {
        const storage = this.getStorage();
        let state = {};
        if (this.paginator) {
            state.first = this.first;
            state.pageIndex = this.pageIndex;
            state.pageSize = this.pageSize;
        }
        if (this.sortField) {
            state.sortField = this.sortField;
            state.sortOrder = this.sortOrder;
        }
        if (this.multiSortMeta) {
            state.multiSortMeta = this.multiSortMeta;
        }
        if (this.hasFilter()) {
            state.filters = this.filters;
        }
        if (this.resizableColumns) {
            this.saveColumnWidths(state);
        }
        if (this.reorderableColumns) {
            this.saveColumnOrder(state);
        }
        if (this.selection) {
            state.selection = this.selection;
        }
        if (Object.keys(this.expandedRowKeys).length) {
            state.expandedRowKeys = this.expandedRowKeys;
        }
        storage.setItem(this.stateKey, JSON.stringify(state));
    }
    saveColumnWidths(state) {
        let widths = [];
        let headers = DomHandler.find(this.containerViewChild.nativeElement, '.cub-datatable-thead > tr > th');
        headers.forEach((header) => widths.push(DomHandler.getOuterWidth(header)));
        state.columnWidths = widths.join(',');
        if (this.columnResizeMode === 'expand') {
            state.tableWidth =
                DomHandler.getOuterWidth(this.tableViewChild.nativeElement) + 'px';
        }
    }
    saveColumnOrder(state) {
        if (this.columns) {
            let columnOrder = [];
            this.columns.map((column) => {
                columnOrder.push(column.field || column.key);
            });
            state.columnOrder = columnOrder;
        }
    }
    clearState() {
        const storage = this.getStorage();
        if (this.stateKey) {
            storage.removeItem(this.stateKey);
        }
    }
    restoreColumnWidths() {
        if (this.columnWidthsState) {
            let widths = this.columnWidthsState.split(',');
            if (this.columnResizeMode === 'expand' && this.tableWidthState) {
                this.setResizeTableWidth(this.tableWidthState + 'px');
            }
            if (ObjectUtils.isNotEmpty(widths)) {
                this.createStyleElement();
                let innerHTML = '';
                widths.forEach((width, index) => {
                    let style = `width: ${width}px !important; max-width: ${width}px !important`;
                    innerHTML += `#${this.id}-table > .cub-datatable-thead > tr > th:nth-child(${index + 1}),
                    #${this.id}-table > .cub-datatable-tbody > tr > td:nth-child(${index + 1}),
                    #${this.id}-table > .cub-datatable-tfoot > tr > td:nth-child(${index + 1}) {
                        ${style}
                    }`;
                });
                this.styleElement.innerHTML = innerHTML;
            }
        }
    }
    selectRange(event, rowIndex) {
        let rangeStart, rangeEnd;
        if (this.anchorRowIndex > rowIndex) {
            rangeStart = rowIndex;
            rangeEnd = this.anchorRowIndex;
        }
        else if (this.anchorRowIndex < rowIndex) {
            rangeStart = this.anchorRowIndex;
            rangeEnd = rowIndex;
        }
        else {
            rangeStart = rowIndex;
            rangeEnd = rowIndex;
        }
        if (this.lazy && this.paginator) {
            rangeStart -= this.first;
            rangeEnd -= this.first;
        }
        let rangeRowsData = [];
        for (let index = rangeStart; index <= rangeEnd; index++) {
            let rangeRowData = this.filteredValue
                ? this.filteredValue[index]
                : this.value[index];
            if (!this.isSelected(rangeRowData)) {
                if (!this.isRowSelectable(rangeRowData, rowIndex)) {
                    continue;
                }
                rangeRowsData.push(rangeRowData);
                this._selection = [...this.selection, rangeRowData];
                let dataKeyValue = this.dataKey
                    ? String(ObjectUtils.resolveFieldData(rangeRowData, this.dataKey))
                    : null;
                if (dataKeyValue) {
                    this.selectionKeys[dataKeyValue] = 1;
                }
            }
        }
        this.selectionChange.emit(this.selection);
    }
    setResizeTableWidth(width) {
        this.tableViewChild.nativeElement.style.width = width;
        this.tableViewChild.nativeElement.style.minWidth = width;
    }
    sortSingle() {
        let field = this.sortField || this.groupRowsBy;
        let order = this.sortField ? this.sortOrder : this.groupRowsByOrder;
        if (this.groupRowsBy &&
            this.sortField &&
            this.groupRowsBy !== this.sortField) {
            this._multiSortMeta = [
                this.getGroupRowsMeta(),
                {
                    field: this.sortField,
                    order: this.sortOrder,
                },
            ];
            this.sortMultiple();
            return;
        }
        if (field && order) {
            if (this.restoringSort) {
                this.restoringSort = false;
            }
            if (this.lazy) {
                this.lazyLoad.emit(this.createLazyLoadMetadata());
            }
            else if (this.value) {
                if (this.customSort) {
                    this.sortFunction.emit({
                        data: this.value,
                        mode: this.sortMode,
                        field: field,
                        order: order,
                    });
                }
                else {
                    this.value.sort((data1, data2) => {
                        let value1 = ObjectUtils.resolveFieldData(data1, field);
                        let value2 = ObjectUtils.resolveFieldData(data2, field);
                        let result = null;
                        if (value1 == null && value2 != null)
                            result = -1;
                        else if (value1 != null && value2 == null)
                            result = 1;
                        else if (value1 == null && value2 == null)
                            result = 0;
                        else if (typeof value1 === 'string' && typeof value2 === 'string')
                            result = value1.localeCompare(value2);
                        else
                            result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
                        return order * result;
                    });
                    this._value = [...this.value];
                }
                if (this.hasFilter()) {
                    this._filter();
                }
            }
            let sortMeta = {
                field: field,
                order: order,
            };
            this.sort.emit(sortMeta);
            this.tableService.onSort(sortMeta);
        }
    }
    sortMultiple() {
        if (this.groupRowsBy) {
            if (!this._multiSortMeta)
                this._multiSortMeta = [this.getGroupRowsMeta()];
            else if (this.multiSortMeta[0].field !== this.groupRowsBy)
                this._multiSortMeta = [this.getGroupRowsMeta(), ...this._multiSortMeta];
        }
        if (this.multiSortMeta) {
            if (this.lazy) {
                this.lazyLoad.emit(this.createLazyLoadMetadata());
            }
            else if (this.value) {
                if (this.customSort) {
                    this.sortFunction.emit({
                        data: this.value,
                        mode: this.sortMode,
                        multiSortMeta: this.multiSortMeta,
                    });
                }
                else {
                    this.value.sort((data1, data2) => {
                        return this.multisortField(data1, data2, this.multiSortMeta, 0);
                    });
                    this._value = [...this.value];
                }
                if (this.hasFilter()) {
                    this._filter();
                }
            }
            this.sort.emit({
                multisortmeta: this.multiSortMeta,
            });
            this.tableService.onSort(this.multiSortMeta);
        }
    }
    restoreColumnOrder() {
        const storage = this.getStorage();
        const stateString = storage.getItem(this.stateKey);
        if (stateString) {
            let state = JSON.parse(stateString);
            let columnOrder = state.columnOrder;
            if (columnOrder) {
                let reorderedColumns = [];
                columnOrder.map((key) => {
                    let col = this.findColumnByKey(key);
                    if (col) {
                        reorderedColumns.push(col);
                    }
                });
                this.columnOrderStateRestored = true;
                this.columns = reorderedColumns;
            }
        }
    }
    findColumnByKey(key) {
        if (this.columns) {
            for (let col of this.columns) {
                if (col.key === key || col.field === key)
                    return col;
                else
                    continue;
            }
        }
        else {
            return null;
        }
    }
    clearSelectionRange(event) {
        let rangeStart, rangeEnd;
        if (this.rangeRowIndex > this.anchorRowIndex) {
            rangeStart = this.anchorRowIndex;
            rangeEnd = this.rangeRowIndex;
        }
        else if (this.rangeRowIndex < this.anchorRowIndex) {
            rangeStart = this.rangeRowIndex;
            rangeEnd = this.anchorRowIndex;
        }
        else {
            rangeStart = this.rangeRowIndex;
            rangeEnd = this.rangeRowIndex;
        }
        for (let index = rangeStart; index <= rangeEnd; index++) {
            let rangeRowData = this.value[index];
            let selectionIndex = this.findIndexInSelection(rangeRowData);
            this._selection = this.selection.filter((value, index) => index != selectionIndex);
            let dataKeyValue = this.dataKey
                ? String(ObjectUtils.resolveFieldData(rangeRowData, this.dataKey))
                : null;
            if (dataKeyValue) {
                delete this.selectionKeys[dataKeyValue];
            }
        }
    }
    findIndexInSelection(rowData) {
        let selectionIndex = -1;
        if (this.selection && this.selection.length) {
            for (let index = 0; index < this.selection.length; index++) {
                if (this.equals(rowData, this.selection[index])) {
                    selectionIndex = index;
                    break;
                }
            }
        }
        return selectionIndex;
    }
    equals(data1, data2) {
        return this.compareSelectionBy === 'equals'
            ? data1 === data2
            : ObjectUtils.equals(data1, data2, this.dataKey);
    }
    restoreState() {
        const storage = this.getStorage();
        const stateString = storage.getItem(this.stateKey);
        const dateFormat = /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/;
        const reviver = function (key, value) {
            if (typeof value === 'string' && dateFormat.test(value)) {
                return new Date(value);
            }
            return value;
        };
        if (stateString) {
            let state = JSON.parse(stateString, reviver);
            if (this.paginator) {
                if (this.paginatorType === 'clientSide') {
                    if (this.first !== undefined) {
                        this.first = state.first;
                        this.firstChange.emit(this.first);
                    }
                    if (this.pageSize !== undefined) {
                        this.pageSize = state.pageSize;
                        this.pageSizeChange.emit(this.pageSize);
                    }
                }
            }
            if (state.sortField) {
                this.restoringSort = true;
                this._sortField = state.sortField;
                this._sortOrder = state.sortOrder;
            }
            if (state.multiSortMeta) {
                this.restoringSort = true;
                this._multiSortMeta = state.multiSortMeta;
            }
            if (state.filters) {
                this.restoringFilter = true;
                this.filters = state.filters;
            }
            if (this.resizableColumns) {
                this.columnWidthsState = state.columnWidths;
                this.tableWidthState = state.tableWidth;
            }
            if (state.expandedRowKeys) {
                this.expandedRowKeys = state.expandedRowKeys;
            }
            if (state.selection) {
                Promise.resolve(null).then(() => this.selectionChange.emit(state.selection));
            }
            this.stateRestored = true;
        }
    }
    isRowExpanded(rowData) {
        return (this.expandedRowKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey))] === true);
    }
    isRowEditing(rowData) {
        return (this.editingRowKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey))] === true);
    }
    isSingleSelectionMode() {
        return this.selectionMode === 'single';
    }
    isMultipleSelectionMode() {
        return this.selectionMode === 'multiple';
    }
    isSelected(rowData) {
        if (rowData && this.selection) {
            if (this.dataKey) {
                return (this.selectionKeys[ObjectUtils.resolveFieldData(rowData, this.dataKey)] !== undefined);
            }
            else {
                if (this.selection instanceof Array)
                    return this.findIndexInSelection(rowData) > -1;
                else
                    return this.equals(rowData, this.selection);
            }
        }
        return false;
    }
    deleteSelectionWhenCheckboxDisabled(rowData) {
        if (rowData && this.selection) {
            const index = this.selection.indexOf(rowData);
            if (index > -1) {
                const dataKey = this.selection[index][this.dataKey];
                this.selection.splice(index, 1);
                delete this.selectionKeys[dataKey];
            }
        }
    }
    isRowSelectable(data, index) {
        if (this.rowSelectable && !this.rowSelectable({ data, index })) {
            return false;
        }
        return true;
    }
    toggleRowWithRadio(event, rowData) {
        this.preventSelectionSetterPropagation = true;
        if (this.selection != rowData) {
            if (!this.isRowSelectable(rowData, event.rowIndex)) {
                return;
            }
            this._selection = rowData;
            this.selectionChange.emit(this.selection);
            if (this.dataKey) {
                this.selectionKeys = {};
                this.selectionKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey))] = 1;
            }
        }
        else {
            this._selection = null;
            this.selectionChange.emit(this.selection);
        }
        this.tableService.onSelectionChange();
        if (this.isStateful()) {
            this.saveState();
        }
    }
    clearSelectionWhenCheckboxDisabled(rowData) {
        this.selection = this.selection || [];
        let selected = this.isSelected(rowData);
        let dataKeyValue = this.dataKey
            ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey))
            : null;
        this.preventSelectionSetterPropagation = true;
        let selectionIndex = this.findIndexInSelection(rowData);
        this._selection = this.selection.filter((value, index) => index != selectionIndex);
        this.selectionChange.emit(this.selection);
        if (dataKeyValue) {
            delete this.selectionKeys[dataKeyValue];
        }
        this.tableService.onDisabledCancelCheck();
    }
    toggleRowWithCheckbox(event, rowData) {
        this.selection = this.selection || [];
        let selected = this.isSelected(rowData);
        let dataKeyValue = this.dataKey
            ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey))
            : null;
        this.preventSelectionSetterPropagation = true;
        if (selected) {
            let selectionIndex = this.findIndexInSelection(rowData);
            this._selection = this.selection.filter((value, index) => index != selectionIndex);
            this.selectionChange.emit(this.selection);
            if (dataKeyValue) {
                delete this.selectionKeys[dataKeyValue];
            }
        }
        else {
            if (!this.isRowSelectable(rowData, event.rowIndex)) {
                return;
            }
            this._selection = this.selection
                ? [...this.selection, rowData]
                : [rowData];
            this.selectionChange.emit(this.selection);
            if (dataKeyValue) {
                this.selectionKeys[dataKeyValue] = 1;
            }
        }
        this.tableService.onSelectionChange();
        if (this.isStateful()) {
            this.saveState();
        }
    }
    toggleRowsWithCheckbox(event, check) {
        if (this._selectAll !== null) {
            this.selectAllChange.emit({ originalEvent: event, checked: check });
        }
        else {
            const data = this.selectionPageOnly
                ? this.dataToRender(this.processedData)
                : this.processedData;
            let selection = this.selectionPageOnly && this._selection
                ? this._selection.filter((s) => !data.some((d) => this.equals(s, d)))
                : [];
            if (check) {
                selection = this.frozenValue
                    ? [...selection, ...this.frozenValue, ...data]
                    : [...selection, ...data];
                selection = this.rowSelectable
                    ? selection.filter((data, index) => this.rowSelectable({ data, index }))
                    : selection;
            }
            this._selection = selection;
            this.preventSelectionSetterPropagation = true;
            this.updateSelectionKeys();
            this.selectionChange.emit(this._selection);
            this.tableService.onSelectionChange();
            this.headerCheckboxChange.emit({
                originalEvent: event,
                checked: check,
            });
            if (this.isStateful()) {
                this.saveState();
            }
        }
    }
    /* Legacy Filtering for custom elements */
    onFilter(value, field, matchMode) {
        if (this.filterTimeout) {
            clearTimeout(this.filterTimeout);
        }
        if (!this.isFilterBlank(value)) {
            this.filters[field] = [{ value: value, matchMode: matchMode }];
        }
        else if (this.filters[field]) {
            delete this.filters[field];
        }
        this.filterTimeout = setTimeout(() => {
            this._filter();
            this.filterTimeout = null;
        }, this.filterDelay);
        this.anchorRowIndex = null;
    }
    filterGlobal(value, matchMode) {
        this.onFilter(value, 'global', matchMode);
    }
    isFilterBlank(filter) {
        if (filter !== null && filter !== undefined) {
            if ((typeof filter === 'string' && filter.trim().length == 0) ||
                (filter instanceof Array && filter.length == 0))
                return true;
            else
                return false;
        }
        return true;
    }
    getExportHeader(column) {
        return column[this.exportHeader] || column.header || column.field;
    }
    clear() {
        this._sortField = null;
        this._sortOrder = this.defaultSortOrder;
        this._multiSortMeta = null;
        this.tableService.onSort(null);
        if (this.filters['global']) {
            this.filters['global'].value = null;
        }
        this.filteredValue = null;
        this.tableService.onResetChange();
        this.first = 0;
        this.firstChange.emit(this.first);
        if (this.lazy) {
            this.lazyLoad.emit(this.createLazyLoadMetadata());
        }
        else {
            if (this.paginator && this.paginatorType === 'clientSide') {
                this.totalRecords = this._value ? this._value.length : 0;
            }
            else {
                this.totalRecords = this.paginatorTotalRecords
                    ? this.paginatorTotalRecords
                    : this._value.length;
            }
        }
    }
    reset() {
        this.clear();
    }
    resetSort() {
        this._sortField = null;
        this._sortOrder = this.defaultSortOrder;
        this._multiSortMeta = null;
        this.tableService.onSort(null);
    }
    resetFilter() {
        if (this.filters['global']) {
            this.filters['global'].value = null;
        }
        this.filteredValue = null;
        this.tableService.onResetChange();
    }
    exportCSV(options) {
        let data;
        let csv = '';
        let columns = this.columns;
        if (options && options.selectionOnly) {
            data = this.selection || [];
        }
        else {
            data = this.filteredValue || this.value;
            if (this.frozenValue) {
                data = data ? [...this.frozenValue, ...data] : this.frozenValue;
            }
        }
        //headers
        for (let index = 0; index < columns.length; index++) {
            let column = columns[index];
            if (column.exportable !== false && column.field) {
                csv += '"' + this.getExportHeader(column) + '"';
                if (index < columns.length - 1) {
                    csv += this.csvSeparator;
                }
            }
        }
        //body
        data.forEach((record, index) => {
            csv += '\n';
            for (let index = 0; index < columns.length; index++) {
                let column = columns[index];
                if (column.exportable !== false && column.field) {
                    let cellData = ObjectUtils.resolveFieldData(record, column.field);
                    if (cellData != null) {
                        if (this.exportFunction) {
                            cellData = this.exportFunction({
                                data: cellData,
                                field: column.field,
                            });
                        }
                        else
                            cellData = String(cellData).replace(/"/g, '""');
                    }
                    else
                        cellData = '';
                    csv += '"' + cellData + '"';
                    if (index < columns.length - 1) {
                        csv += this.csvSeparator;
                    }
                }
            }
        });
        let blob = new Blob([csv], {
            type: 'text/csv;charset=utf-8;',
        });
        let link = document.createElement('a');
        link.style.display = 'none';
        document.body.appendChild(link);
        if (link.download !== undefined) {
            link.setAttribute('href', URL.createObjectURL(blob));
            link.setAttribute('download', this.exportFilename + '.csv');
            link.click();
        }
        else {
            csv = 'data:text/csv;charset=utf-8,' + csv;
            window.open(encodeURI(csv));
        }
        document.body.removeChild(link);
    }
    onLazyItemLoad(event) {
        this.lazyLoad.emit({
            ...this.createLazyLoadMetadata(),
            ...event,
            pageSize: event.last - event.first,
        });
    }
    resetScrollTop() {
        if (this.virtualScroll)
            this.scrollToVirtualIndex(0);
        else
            this.scrollTo({ top: 0 });
    }
    scrollToVirtualIndex(index) {
        this.virtualScroll && this.scroller.scrollToIndex(index);
    }
    scrollTo(options) {
        if (this.virtualScroll) {
            this.scroller.scrollTo(options);
        }
        else if (this.wrapperViewChild && this.wrapperViewChild.nativeElement) {
            if (this.wrapperViewChild.nativeElement.scrollTo) {
                this.wrapperViewChild.nativeElement.scrollTo(options);
            }
            else {
                this.wrapperViewChild.nativeElement.scrollLeft = options.left;
                this.wrapperViewChild.nativeElement.scrollTop = options.top;
            }
        }
    }
    updateEditingCell(cell, data, field, index) {
        this.editingCell = cell;
        this.editingCellData = data;
        this.editingCellField = field;
        this.editingCellRowIndex = index;
        this.bindDocumentEditListener();
    }
    isEditingCellValid() {
        return (this.editingCell &&
            DomHandler.find(this.editingCell, '.ng-invalid.ng-dirty').length === 0);
    }
    bindDocumentEditListener() {
        if (!this.documentEditListener) {
            this.documentEditListener = (event) => {
                if (this.editingCell && !this.selfClick && this.isEditingCellValid()) {
                    DomHandler.removeClass(this.editingCell, 'cub-cell-editing');
                    this.editingCell = null;
                    this.editingCellField = null;
                    this.editingCellData = null;
                    this.editingCellRowIndex = null;
                    this.unbindDocumentEditListener();
                    this.changeDetectorRef.markForCheck();
                    if (this.overlaySubscription) {
                        this.overlaySubscription.unsubscribe();
                    }
                }
                this.selfClick = false;
            };
            document.addEventListener('click', this.documentEditListener);
        }
    }
    unbindDocumentEditListener() {
        if (this.documentEditListener) {
            document.removeEventListener('click', this.documentEditListener);
            this.documentEditListener = null;
        }
    }
    initRowEdit(rowData) {
        let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
        this.editingRowKeys[dataKeyValue] = true;
    }
    saveRowEdit(rowData, rowElement) {
        if (DomHandler.find(rowElement, '.ng-invalid.ng-dirty').length === 0) {
            let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
            delete this.editingRowKeys[dataKeyValue];
        }
    }
    cancelRowEdit(rowData) {
        let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
        delete this.editingRowKeys[dataKeyValue];
    }
    toggleRow(rowData, event) {
        if (!this.dataKey) {
            throw new Error('dataKey must be defined to use row expansion');
        }
        let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
        if (this.expandedRowKeys[dataKeyValue] != null) {
            delete this.expandedRowKeys[dataKeyValue];
            this.rowCollapse.emit({
                originalEvent: event,
                data: rowData,
            });
        }
        else {
            if (this.rowExpandMode === 'single') {
                this.expandedRowKeys = {};
            }
            this.expandedRowKeys[dataKeyValue] = true;
            this.rowExpand.emit({
                originalEvent: event,
                data: rowData,
            });
        }
        if (event) {
            event.preventDefault();
        }
        if (this.isStateful()) {
            this.saveState();
        }
    }
    onColumnResizeBegin(event) {
        let containerLeft = DomHandler.getOffset(this.containerViewChild.nativeElement).left;
        this.resizeColumnElement = event.target.parentElement;
        this.columnResizing = true;
        this.lastResizerHelperX =
            event.pageX -
                containerLeft +
                this.containerViewChild.nativeElement.scrollLeft;
        this.onColumnResize(event);
        event.preventDefault();
    }
    onColumnResize(event) {
        let containerLeft = DomHandler.getOffset(this.containerViewChild.nativeElement).left;
        DomHandler.addClass(this.containerViewChild.nativeElement, 'cub-unselectable-text');
        this.resizeHelperViewChild.nativeElement.style.height =
            this.containerViewChild.nativeElement.offsetHeight + 'px';
        this.resizeHelperViewChild.nativeElement.style.top = 0 + 'px';
        this.resizeHelperViewChild.nativeElement.style.left =
            event.pageX -
                containerLeft +
                this.containerViewChild.nativeElement.scrollLeft +
                'px';
        this.resizeHelperViewChild.nativeElement.style.display = 'block';
    }
    onColumnResizeEnd() {
        let delta = this.resizeHelperViewChild.nativeElement.offsetLeft -
            this.lastResizerHelperX;
        let columnWidth = this.resizeColumnElement.offsetWidth;
        let newColumnWidth = columnWidth + delta;
        let minWidth = this.resizeColumnElement.style.minWidth.replace(/[^\d.]/g, '') || 15;
        if (newColumnWidth >= minWidth) {
            if (this.columnResizeMode === 'fit') {
                let nextColumn = this.resizeColumnElement.nextElementSibling;
                let nextColumnWidth = nextColumn.offsetWidth - delta;
                if (newColumnWidth > 15 && nextColumnWidth > 15) {
                    this.resizeTableCells(newColumnWidth, nextColumnWidth);
                }
            }
            else if (this.columnResizeMode === 'expand') {
                let tableWidth = this.tableViewChild.nativeElement.offsetWidth + delta;
                this.setResizeTableWidth(tableWidth + 'px');
                this.resizeTableCells(newColumnWidth, null);
            }
            this.columnResize.emit({
                element: this.resizeColumnElement,
                delta: delta,
            });
            if (this.isStateful()) {
                this.saveState();
            }
        }
        this.resizeHelperViewChild.nativeElement.style.display = 'none';
        DomHandler.removeClass(this.containerViewChild.nativeElement, 'cub-unselectable-text');
    }
    resizeTableCells(newColumnWidth, nextColumnWidth) {
        let colIndex = DomHandler.index(this.resizeColumnElement);
        let widths = [];
        const tableHead = DomHandler.findSingle(this.containerViewChild.nativeElement, '.cub-datatable-thead');
        let headers = DomHandler.find(tableHead, 'tr > th');
        headers.forEach((header) => widths.push(DomHandler.getOuterWidth(header)));
        this.destroyStyleElement();
        this.createStyleElement();
        let innerHTML = '';
        widths.forEach((width, index) => {
            let colWidth = index === colIndex
                ? newColumnWidth
                : nextColumnWidth && index === colIndex + 1
                    ? nextColumnWidth
                    : width;
            let style = `width: ${colWidth}px !important; max-width: ${colWidth}px !important;`;
            innerHTML += `
            #${this.id}-table > .cub-datatable-thead > tr > th:nth-child(${index + 1}),
            #${this.id}-table > .cub-datatable-tbody > tr > td:nth-child(${index + 1}),
            #${this.id}-table > .cub-datatable-tfoot > tr > td:nth-child(${index + 1}) {
                ${style}
            }
        `;
        });
        this.styleElement.innerHTML = innerHTML;
    }
    onColumnDragStart(event, columnElement) {
        this.reorderIconWidth = DomHandler.getHiddenElementOuterWidth(this.reorderIndicatorUpViewChild.nativeElement);
        this.reorderIconHeight = DomHandler.getHiddenElementOuterHeight(this.reorderIndicatorDownViewChild.nativeElement);
        this.draggedColumn = columnElement;
        event.dataTransfer.setData('text', 'b'); // For firefox
    }
    onColumnDragEnter(event, dropHeader) {
        if (this.reorderableColumns && this.draggedColumn && dropHeader) {
            event.preventDefault();
            let containerOffset = DomHandler.getOffset(this.containerViewChild.nativeElement);
            let dropHeaderOffset = DomHandler.getOffset(dropHeader);
            if (this.draggedColumn != dropHeader) {
                let targetLeft = dropHeaderOffset.left - containerOffset.left;
                let columnCenter = dropHeaderOffset.left + dropHeader.offsetWidth / 2;
                this.reorderIndicatorUpViewChild.nativeElement.style.top =
                    dropHeaderOffset.top -
                        containerOffset.top -
                        (this.reorderIconHeight - 1) +
                        'px';
                this.reorderIndicatorDownViewChild.nativeElement.style.top =
                    dropHeaderOffset.top -
                        containerOffset.top +
                        dropHeader.offsetHeight +
                        'px';
                if (event.pageX > columnCenter) {
                    this.reorderIndicatorUpViewChild.nativeElement.style.left =
                        targetLeft +
                            dropHeader.offsetWidth -
                            Math.ceil(this.reorderIconWidth / 2) +
                            'px';
                    this.reorderIndicatorDownViewChild.nativeElement.style.left =
                        targetLeft +
                            dropHeader.offsetWidth -
                            Math.ceil(this.reorderIconWidth / 2) +
                            'px';
                    this.dropPosition = 1;
                }
                else {
                    this.reorderIndicatorUpViewChild.nativeElement.style.left =
                        targetLeft - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.reorderIndicatorDownViewChild.nativeElement.style.left =
                        targetLeft - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.dropPosition = -1;
                }
                this.reorderIndicatorUpViewChild.nativeElement.style.display = 'block';
                this.reorderIndicatorDownViewChild.nativeElement.style.display =
                    'block';
            }
            else {
                event.dataTransfer.dropEffect = 'none';
            }
        }
    }
    onColumnDragLeave(event) {
        if (this.reorderableColumns && this.draggedColumn) {
            event.preventDefault();
        }
    }
    onColumnDrop(event, dropColumn) {
        event.preventDefault();
        if (this.draggedColumn) {
            let dragIndex = DomHandler.indexWithinGroup(this.draggedColumn, 'preorderablecolumn');
            let dropIndex = DomHandler.indexWithinGroup(dropColumn, 'preorderablecolumn');
            let allowDrop = dragIndex != dropIndex;
            if (allowDrop &&
                ((dropIndex - dragIndex == 1 && this.dropPosition === -1) ||
                    (dragIndex - dropIndex == 1 && this.dropPosition === 1))) {
                allowDrop = false;
            }
            if (allowDrop && dropIndex < dragIndex && this.dropPosition === 1) {
                dropIndex = dropIndex + 1;
            }
            if (allowDrop && dropIndex > dragIndex && this.dropPosition === -1) {
                dropIndex = dropIndex - 1;
            }
            if (allowDrop) {
                ObjectUtils.reorderArray(this.columns, dragIndex, dropIndex);
                this.columnReorder.emit({
                    dragIndex: dragIndex,
                    dropIndex: dropIndex,
                    columns: this.columns,
                });
                if (this.isStateful()) {
                    this.zone.runOutsideAngular(() => {
                        setTimeout(() => {
                            this.saveState();
                        });
                    });
                }
            }
            this.reorderIndicatorUpViewChild.nativeElement.style.display = 'none';
            this.reorderIndicatorDownViewChild.nativeElement.style.display = 'none';
            this.draggedColumn.draggable = false;
            this.draggedColumn = null;
            this.dropPosition = null;
        }
    }
    onRowDragStart(event, index) {
        this.rowDragging = true;
        this.draggedRowIndex = index;
        event.dataTransfer.setData('text', 'b'); // For firefox
    }
    onRowDragOver(event, index, rowElement) {
        if (this.rowDragging && this.draggedRowIndex !== index) {
            let rowY = DomHandler.getOffset(rowElement).top + DomHandler.getWindowScrollTop();
            let pageY = event.pageY;
            let rowMidY = rowY + DomHandler.getOuterHeight(rowElement) / 2;
            let prevRowElement = rowElement.previousElementSibling;
            if (pageY < rowMidY) {
                DomHandler.removeClass(rowElement, 'cub-datatable-dragpoint-bottom');
                this.droppedRowIndex = index;
                if (prevRowElement)
                    DomHandler.addClass(prevRowElement, 'cub-datatable-dragpoint-bottom');
                else
                    DomHandler.addClass(rowElement, 'cub-datatable-dragpoint-top');
            }
            else {
                if (prevRowElement)
                    DomHandler.removeClass(prevRowElement, 'cub-datatable-dragpoint-bottom');
                else
                    DomHandler.addClass(rowElement, 'cub-datatable-dragpoint-top');
                this.droppedRowIndex = index + 1;
                DomHandler.addClass(rowElement, 'cub-datatable-dragpoint-bottom');
            }
        }
    }
    onRowDragLeave(event, rowElement) {
        let prevRowElement = rowElement.previousElementSibling;
        if (prevRowElement) {
            DomHandler.removeClass(prevRowElement, 'cub-datatable-dragpoint-bottom');
        }
        DomHandler.removeClass(rowElement, 'cub-datatable-dragpoint-bottom');
        DomHandler.removeClass(rowElement, 'cub-datatable-dragpoint-top');
    }
    onRowDragEnd(event) {
        this.rowDragging = false;
        this.draggedRowIndex = null;
        this.droppedRowIndex = null;
    }
    onRowDrop(event, rowElement) {
        if (this.droppedRowIndex != null) {
            let dropIndex = this.draggedRowIndex > this.droppedRowIndex
                ? this.droppedRowIndex
                : this.droppedRowIndex === 0
                    ? 0
                    : this.droppedRowIndex - 1;
            ObjectUtils.reorderArray(this.value, this.draggedRowIndex, dropIndex);
            if (this.virtualScroll) {
                // TODO: Check
                this._value = [...this._value];
            }
            this.rowReorder.emit({
                dragIndex: this.draggedRowIndex,
                dropIndex: dropIndex,
            });
        }
        //cleanup
        this.onRowDragLeave(event, rowElement);
        this.onRowDragEnd(event);
    }
    isEmpty() {
        let data = this.filteredValue || this.value;
        return data == null || data.length == 0;
    }
    startDraggingScroll(event, flag, element) {
        if (this.dragToScroll) {
            this.dragScrollMouseDown = true;
            this.dragScrollStartX = event.pageX - element.offsetLeft;
            this.dragScrollLeft = element.scrollLeft;
        }
    }
    stopDraggingScroll(event, flag) {
        if (this.dragToScroll) {
            this.dragScrollMouseDown = false;
        }
    }
    dragScrollEvent(event, element) {
        if (this.dragToScroll) {
            event.preventDefault();
            if (!this.dragScrollMouseDown) {
                return;
            }
            const x = event.pageX - element.offsetLeft;
            const scroll = x - this.dragScrollStartX;
            element.scrollLeft = this.dragScrollLeft - scroll;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTable, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: CubTableService }, { token: i0.ChangeDetectorRef }, { token: i2.CubFilterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTable, isStandalone: true, selector: "cub-table", inputs: { appearance: "appearance", size: "size", style: "style", styleClass: "styleClass", tableStyle: "tableStyle", tableStyleClass: "tableStyleClass", value: "value", columns: "columns", paginator: "paginator", paginatorType: "paginatorType", paginatorTotalRecords: "paginatorTotalRecords", alwaysShowPaginator: "alwaysShowPaginator", pageRangeTemplate: "pageRangeTemplate", jumpToTemplate: "jumpToTemplate", showPageRange: "showPageRange", showFirstLastButton: "showFirstLastButton", pageLinkAutoSize: "pageLinkAutoSize", pageLinkSize: "pageLinkSize", totalRecords: "totalRecords", pageSize: "pageSize", pageSizeOptions: "pageSizeOptions", hidePageSize: "hidePageSize", pageIndex: "pageIndex", first: "first", defaultSortOrder: "defaultSortOrder", sortMode: "sortMode", resetPageOnSort: "resetPageOnSort", customSort: "customSort", sortField: "sortField", sortOrder: "sortOrder", multiSortMeta: "multiSortMeta", loading: "loading", lazy: "lazy", lazyLoadOnInit: "lazyLoadOnInit", responsiveLayout: "responsiveLayout", scrollable: "scrollable", scrollHeight: "scrollHeight", dataKey: "dataKey", selectionPageOnly: "selectionPageOnly", selectionTemplate: "selectionTemplate", selectionButtonTemplate: "selectionButtonTemplate", selection: "selection", selectAll: "selectAll", filterTemplate: "filterTemplate", filterButtonTemplate: "filterButtonTemplate", showColumnToggle: "showColumnToggle", columnToggleButtonTemplate: "columnToggleButtonTemplate", rowExpandMode: "rowExpandMode", expandedRowKeys: "expandedRowKeys", dragToScroll: "dragToScroll" }, outputs: { firstChange: "firstChange", pageSizeChange: "pageSizeChange", pageChange: "pageChange", sortFunction: "sortFunction", sort: "sort", lazyLoad: "lazyLoad", selectAllChange: "selectAllChange", selectionChange: "selectionChange", headerCheckboxChange: "headerCheckboxChange", filter: "filter", columnToggle: "columnToggle", rowExpand: "rowExpand", rowCollapse: "rowCollapse", columnResize: "columnResize", columnReorder: "columnReorder", rowReorder: "rowReorder" }, providers: [CubTableService], queries: [{ propertyName: "templates", predicate: CubTemplate }], viewQueries: [{ propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true }, { propertyName: "resizeHelperViewChild", first: true, predicate: ["resizeHelper"], descendants: true }, { propertyName: "reorderIndicatorUpViewChild", first: true, predicate: ["reorderIndicatorUp"], descendants: true }, { propertyName: "reorderIndicatorDownViewChild", first: true, predicate: ["reorderIndicatorDown"], descendants: true }, { propertyName: "wrapperViewChild", first: true, predicate: ["wrapper"], descendants: true }, { propertyName: "tableViewChild", first: true, predicate: ["table"], descendants: true }, { propertyName: "tableHeaderViewChild", first: true, predicate: ["thead"], descendants: true }, { propertyName: "tableFooterViewChild", first: true, predicate: ["tfoot"], descendants: true }, { propertyName: "scroller", first: true, predicate: ["scroller"], descendants: true }, { propertyName: "previewTableViewChild", first: true, predicate: ["previewTable"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  #container\n  [ngStyle]=\"style\"\n  [class]=\"styleClass\"\n  [ngClass]=\"{\n    'cub-datatable': true,\n    'cub-datatable-small': size === 'small',\n    'cub-datatable-resizable': resizableColumns,\n    'cub-datatable-hoverable-rows': rowHover || selectionMode,\n    'cub-datatable-scrollable': scrollable,\n    'cub-datatable-flex-scrollable': scrollable && scrollHeight === 'flex'\n  }\"\n  [attr.id]=\"id\"\n>\n  <!-- Loading \u906E\u7F69\u8207\u52D5\u756B -->\n  @if (loading && showLoader) {\n  <div class=\"cub-datatable-loading-overlay cub-component-overlay\">\n    <cub-loading size=\"large\" [hasBackdrop]=\"true\"></cub-loading>\n  </div>\n  }\n  <!-- \u4E0A\u65B9\u9644\u52A0\u5340\u584A -->\n  @if (captionTemplateRef || selection?.length || hasFilter() ||\n  showColumnToggle) {\n  <div class=\"cub-datatable-header\">\n    <div class=\"cub-datatable-header-content\">\n      @if (selection?.length) {\n      <div class=\"cub-datatable-header-content-checkbox\">\n        <span>{{ selectionContent }}</span>\n        <button\n          cub-button\n          type=\"button\"\n          appearance=\"plain\"\n          [size]=\"size\"\n          (click)=\"toggleRowsWithCheckbox($event, false)\"\n        >\n          {{ selectionButtonTemplate }}\n        </button>\n      </div>\n      } @if (hasFilter()) {\n      <div class=\"cub-datatable-header-content-filter\">\n        <span>{{ filterContent }}</span>\n        <button\n          cub-button\n          type=\"button\"\n          appearance=\"plain\"\n          [size]=\"size\"\n          (click)=\"resetFilter()\"\n        >\n          {{ filterButtonTemplate }}\n        </button>\n      </div>\n      }\n\n      <ng-container *ngTemplateOutlet=\"captionTemplateRef\"></ng-container>\n    </div>\n    @if (showColumnToggle) {\n    <button\n      cub-button\n      type=\"button\"\n      color=\"neutral\"\n      appearance=\"plain\"\n      [size]=\"size\"\n      (click)=\"columnToggle.emit()\"\n    >\n      <span cubPrefix class=\"cub-icon-gear\"></span\n      >{{ columnToggleButtonTemplate }}\n    </button>\n    }\n  </div>\n  }\n\n  <!-- \u8868\u683C -->\n  <div\n    #wrapper\n    class=\"cub-datatable-wrapper\"\n    [ngStyle]=\"{ maxHeight: virtualScroll ? '' : scrollHeight }\"\n    (mousedown)=\"startDraggingScroll($event, false, wrapper)\"\n    (mouseup)=\"stopDraggingScroll($event, false)\"\n    (mouseleave)=\"stopDraggingScroll($event, false)\"\n    (mousemove)=\"dragScrollEvent($event, wrapper)\"\n  >\n    @if (virtualScroll) {\n\n    <cub-scroller\n      #scroller\n      [items]=\"processedData\"\n      [columns]=\"columns\"\n      [style]=\"{ height: scrollHeight !== 'flex' ? scrollHeight : undefined }\"\n      [scrollHeight]=\"scrollHeight !== 'flex' ? undefined : '100%'\"\n      [itemSize]=\"virtualScrollItemSize\"\n      [step]=\"pageSize\"\n      [delay]=\"lazy ? virtualScrollDelay : 0\"\n      [inline]=\"true\"\n      [lazy]=\"lazy\"\n      [loaderDisabled]=\"true\"\n      [showSpacer]=\"false\"\n      [showLoader]=\"loadingBodyTemplateRef ? true : false\"\n      [options]=\"virtualScrollOptions\"\n      [autoSize]=\"true\"\n      (lazyLoad)=\"onLazyItemLoad($event)\"\n    >\n      <ng-template\n        cubTemplate=\"content\"\n        let-items\n        let-scrollerOptions=\"options\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"\n            buildInTable;\n            context: { $implicit: items, options: scrollerOptions }\n          \"\n        ></ng-container>\n      </ng-template>\n    </cub-scroller>\n    } @else {\n    <ng-container\n      *ngTemplateOutlet=\"\n        buildInTable;\n        context: { $implicit: processedData, options: { columns } }\n      \"\n    ></ng-container>\n    }\n\n    <ng-template #buildInTable let-items let-scrollerOptions=\"options\">\n      <table\n        #table\n        role=\"table\"\n        [ngClass]=\"{\n          'cub-datatable-table': true,\n          'cub-datatable-bordered-table': appearance === 'bordered',\n          'cub-datatable-responsive-table': responsiveLayout === 'stack',\n          'cub-datatable-scrollable-table': scrollable,\n          'cub-datatable-resizable-table': resizableColumns,\n          'cub-datatable-resizable-table-fit':\n            resizableColumns && columnResizeMode === 'fit'\n        }\"\n        [class]=\"tableStyleClass\"\n        [style]=\"tableStyle\"\n        [attr.id]=\"id + '-table'\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"\n            colGroupTemplateRef;\n            context: { $implicit: scrollerOptions.columns }\n          \"\n        ></ng-container>\n        <thead #thead class=\"cub-datatable-thead\">\n          <ng-container\n            *ngTemplateOutlet=\"\n              headerGroupedTemplateRef || headerTemplateRef;\n              context: { $implicit: scrollerOptions.columns }\n            \"\n          ></ng-container>\n        </thead>\n        @if (frozenValue || frozenBodyTemplateRef) {\n        <tbody\n          class=\"cub-datatable-tbody cub-datatable-frozen-tbody\"\n          [value]=\"frozenValue\"\n          [frozenRows]=\"true\"\n          [cubTableBody]=\"scrollerOptions.columns\"\n          [cubTableBodyTemplate]=\"frozenBodyTemplateRef\"\n          [frozen]=\"true\"\n        ></tbody>\n        }\n        <tbody\n          class=\"cub-datatable-tbody\"\n          [ngClass]=\"scrollerOptions.contentStyleClass\"\n          [style]=\"scrollerOptions.contentStyle\"\n          [value]=\"dataToRender(scrollerOptions.rows)\"\n          [cubTableBody]=\"scrollerOptions.columns\"\n          [cubTableBodyTemplate]=\"bodyTemplateRef\"\n          [scrollerOptions]=\"scrollerOptions\"\n        ></tbody>\n        @if (scrollerOptions.spacerStyle) {\n        <tbody\n          [style]=\"\n            'height: calc(' +\n            scrollerOptions.spacerStyle.height +\n            ' - ' +\n            scrollerOptions.rows.length * scrollerOptions.itemSize +\n            'px);'\n          \"\n          class=\"cub-datatable-scroller-spacer\"\n        ></tbody>\n        } @if (footerGroupedTemplateRef || footerTemplateRef) {\n        <tfoot #tfoot class=\"cub-datatable-tfoot\">\n          <ng-container\n            *ngTemplateOutlet=\"\n              footerGroupedTemplateRef || footerTemplateRef;\n              context: { $implicit: scrollerOptions.columns }\n            \"\n          ></ng-container>\n        </tfoot>\n        }\n      </table>\n    </ng-template>\n  </div>\n\n  <!-- Summary -->\n  @if (summaryTemplateRef) {\n  <div class=\"cub-datatable-footer\">\n    <ng-container *ngTemplateOutlet=\"summaryTemplateRef\"></ng-container>\n  </div>\n  }\n\n  <!-- \u5206\u9801\u5668 -->\n  @if (paginator) {\n  <cub-paginator\n    [alwaysShow]=\"alwaysShowPaginator\"\n    [hidePageSize]=\"hidePageSize\"\n    [pageRangeTemplate]=\"pageRangeTemplate\"\n    [jumpToTemplate]=\"jumpToTemplate\"\n    [showPageRange]=\"showPageRange\"\n    [showFirstLastButton]=\"showFirstLastButton\"\n    [pageLinkAutoSize]=\"pageLinkAutoSize\"\n    [pageLinkSize]=\"pageLinkSize\"\n    [totalRecords]=\"\n      this.paginatorType === 'clientSide' ? totalRecords : paginatorTotalRecords\n    \"\n    [pageSize]=\"pageSize\"\n    [pageSizeOptions]=\"pageSizeOptions\"\n    [pageIndex]=\"pageIndex\"\n    (pageChange)=\"onPageChange($event)\"\n  ></cub-paginator>\n  }\n\n  <!-- Column Resizer -->\n  @if (resizableColumns) {\n  <div\n    #resizeHelper\n    class=\"cub-column-resizer-helper\"\n    style=\"display: none\"\n  ></div>\n  }\n  <!-- Reorder Column -->\n  @if (reorderableColumns) {\n  <span\n    #reorderIndicatorUp\n    class=\"cub-datatable-reorder-indicator-up cub-icon-arrowup_24\"\n    style=\"display: none\"\n  ></span>\n  }\n  <!-- Reorder Column -->\n  @if (reorderableColumns) {\n  <span\n    #reorderIndicatorDown\n    class=\"cub-datatable-reorder-indicator-down cub-icon-arrowdown_24\"\n    style=\"display: none\"\n  ></span>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: i0.forwardRef(() => NgStyle), selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i0.forwardRef(() => NgClass), selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i0.forwardRef(() => CubLoading), selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "component", type: i0.forwardRef(() => CubButton), selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }, { kind: "directive", type: i0.forwardRef(() => NgTemplateOutlet), selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i0.forwardRef(() => CubPrefix), selector: "[cubPrefix]" }, { kind: "component", type: i0.forwardRef(() => CubScroller), selector: "cub-scroller", inputs: ["id", "style", "styleClass", "tabindex", "items", "itemSize", "scrollHeight", "scrollWidth", "orientation", "inline", "step", "delay", "resizeDelay", "appendOnly", "lazy", "disabled", "loaderDisabled", "columns", "showSpacer", "showLoader", "numToleratedItems", "loading", "autoSize", "trackBy", "options"], outputs: ["lazyLoad", "scroll", "scrollIndexChange"] }, { kind: "directive", type: i0.forwardRef(() => CubTemplate), selector: "[cubTemplate]", inputs: ["cubTemplate"] }, { kind: "component", type: i0.forwardRef(() => CubTableBody), selector: "[cubTableBody]", inputs: ["cubTableBody", "cubTableBodyTemplate", "value", "frozen", "frozenRows", "scrollerOptions"] }, { kind: "component", type: i0.forwardRef(() => CubPaginator), selector: "cub-paginator", inputs: ["disabled", "disableRipple", "style", "styleClass", "alwaysShow", "pageRangeTemplate", "jumpToTemplate", "showPageRange", "showFirstLastButton", "pageLinkAutoSize", "pageLinkSize", "totalRecords", "pageSize", "pageSizeOptions", "hidePageSize", "pageIndex"], outputs: ["pageChange"], exportAs: ["cubPaginator"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTable, decorators: [{
            type: Component,
            args: [{ selector: 'cub-table', providers: [CubTableService], changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, imports: [
                        NgStyle,
                        NgClass,
                        CubLoading,
                        CubButton,
                        NgTemplateOutlet,
                        CubPrefix,
                        CubScroller,
                        CubTemplate,
                        forwardRef(() => CubTableBody),
                        CubPaginator,
                    ], template: "<div\n  #container\n  [ngStyle]=\"style\"\n  [class]=\"styleClass\"\n  [ngClass]=\"{\n    'cub-datatable': true,\n    'cub-datatable-small': size === 'small',\n    'cub-datatable-resizable': resizableColumns,\n    'cub-datatable-hoverable-rows': rowHover || selectionMode,\n    'cub-datatable-scrollable': scrollable,\n    'cub-datatable-flex-scrollable': scrollable && scrollHeight === 'flex'\n  }\"\n  [attr.id]=\"id\"\n>\n  <!-- Loading \u906E\u7F69\u8207\u52D5\u756B -->\n  @if (loading && showLoader) {\n  <div class=\"cub-datatable-loading-overlay cub-component-overlay\">\n    <cub-loading size=\"large\" [hasBackdrop]=\"true\"></cub-loading>\n  </div>\n  }\n  <!-- \u4E0A\u65B9\u9644\u52A0\u5340\u584A -->\n  @if (captionTemplateRef || selection?.length || hasFilter() ||\n  showColumnToggle) {\n  <div class=\"cub-datatable-header\">\n    <div class=\"cub-datatable-header-content\">\n      @if (selection?.length) {\n      <div class=\"cub-datatable-header-content-checkbox\">\n        <span>{{ selectionContent }}</span>\n        <button\n          cub-button\n          type=\"button\"\n          appearance=\"plain\"\n          [size]=\"size\"\n          (click)=\"toggleRowsWithCheckbox($event, false)\"\n        >\n          {{ selectionButtonTemplate }}\n        </button>\n      </div>\n      } @if (hasFilter()) {\n      <div class=\"cub-datatable-header-content-filter\">\n        <span>{{ filterContent }}</span>\n        <button\n          cub-button\n          type=\"button\"\n          appearance=\"plain\"\n          [size]=\"size\"\n          (click)=\"resetFilter()\"\n        >\n          {{ filterButtonTemplate }}\n        </button>\n      </div>\n      }\n\n      <ng-container *ngTemplateOutlet=\"captionTemplateRef\"></ng-container>\n    </div>\n    @if (showColumnToggle) {\n    <button\n      cub-button\n      type=\"button\"\n      color=\"neutral\"\n      appearance=\"plain\"\n      [size]=\"size\"\n      (click)=\"columnToggle.emit()\"\n    >\n      <span cubPrefix class=\"cub-icon-gear\"></span\n      >{{ columnToggleButtonTemplate }}\n    </button>\n    }\n  </div>\n  }\n\n  <!-- \u8868\u683C -->\n  <div\n    #wrapper\n    class=\"cub-datatable-wrapper\"\n    [ngStyle]=\"{ maxHeight: virtualScroll ? '' : scrollHeight }\"\n    (mousedown)=\"startDraggingScroll($event, false, wrapper)\"\n    (mouseup)=\"stopDraggingScroll($event, false)\"\n    (mouseleave)=\"stopDraggingScroll($event, false)\"\n    (mousemove)=\"dragScrollEvent($event, wrapper)\"\n  >\n    @if (virtualScroll) {\n\n    <cub-scroller\n      #scroller\n      [items]=\"processedData\"\n      [columns]=\"columns\"\n      [style]=\"{ height: scrollHeight !== 'flex' ? scrollHeight : undefined }\"\n      [scrollHeight]=\"scrollHeight !== 'flex' ? undefined : '100%'\"\n      [itemSize]=\"virtualScrollItemSize\"\n      [step]=\"pageSize\"\n      [delay]=\"lazy ? virtualScrollDelay : 0\"\n      [inline]=\"true\"\n      [lazy]=\"lazy\"\n      [loaderDisabled]=\"true\"\n      [showSpacer]=\"false\"\n      [showLoader]=\"loadingBodyTemplateRef ? true : false\"\n      [options]=\"virtualScrollOptions\"\n      [autoSize]=\"true\"\n      (lazyLoad)=\"onLazyItemLoad($event)\"\n    >\n      <ng-template\n        cubTemplate=\"content\"\n        let-items\n        let-scrollerOptions=\"options\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"\n            buildInTable;\n            context: { $implicit: items, options: scrollerOptions }\n          \"\n        ></ng-container>\n      </ng-template>\n    </cub-scroller>\n    } @else {\n    <ng-container\n      *ngTemplateOutlet=\"\n        buildInTable;\n        context: { $implicit: processedData, options: { columns } }\n      \"\n    ></ng-container>\n    }\n\n    <ng-template #buildInTable let-items let-scrollerOptions=\"options\">\n      <table\n        #table\n        role=\"table\"\n        [ngClass]=\"{\n          'cub-datatable-table': true,\n          'cub-datatable-bordered-table': appearance === 'bordered',\n          'cub-datatable-responsive-table': responsiveLayout === 'stack',\n          'cub-datatable-scrollable-table': scrollable,\n          'cub-datatable-resizable-table': resizableColumns,\n          'cub-datatable-resizable-table-fit':\n            resizableColumns && columnResizeMode === 'fit'\n        }\"\n        [class]=\"tableStyleClass\"\n        [style]=\"tableStyle\"\n        [attr.id]=\"id + '-table'\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"\n            colGroupTemplateRef;\n            context: { $implicit: scrollerOptions.columns }\n          \"\n        ></ng-container>\n        <thead #thead class=\"cub-datatable-thead\">\n          <ng-container\n            *ngTemplateOutlet=\"\n              headerGroupedTemplateRef || headerTemplateRef;\n              context: { $implicit: scrollerOptions.columns }\n            \"\n          ></ng-container>\n        </thead>\n        @if (frozenValue || frozenBodyTemplateRef) {\n        <tbody\n          class=\"cub-datatable-tbody cub-datatable-frozen-tbody\"\n          [value]=\"frozenValue\"\n          [frozenRows]=\"true\"\n          [cubTableBody]=\"scrollerOptions.columns\"\n          [cubTableBodyTemplate]=\"frozenBodyTemplateRef\"\n          [frozen]=\"true\"\n        ></tbody>\n        }\n        <tbody\n          class=\"cub-datatable-tbody\"\n          [ngClass]=\"scrollerOptions.contentStyleClass\"\n          [style]=\"scrollerOptions.contentStyle\"\n          [value]=\"dataToRender(scrollerOptions.rows)\"\n          [cubTableBody]=\"scrollerOptions.columns\"\n          [cubTableBodyTemplate]=\"bodyTemplateRef\"\n          [scrollerOptions]=\"scrollerOptions\"\n        ></tbody>\n        @if (scrollerOptions.spacerStyle) {\n        <tbody\n          [style]=\"\n            'height: calc(' +\n            scrollerOptions.spacerStyle.height +\n            ' - ' +\n            scrollerOptions.rows.length * scrollerOptions.itemSize +\n            'px);'\n          \"\n          class=\"cub-datatable-scroller-spacer\"\n        ></tbody>\n        } @if (footerGroupedTemplateRef || footerTemplateRef) {\n        <tfoot #tfoot class=\"cub-datatable-tfoot\">\n          <ng-container\n            *ngTemplateOutlet=\"\n              footerGroupedTemplateRef || footerTemplateRef;\n              context: { $implicit: scrollerOptions.columns }\n            \"\n          ></ng-container>\n        </tfoot>\n        }\n      </table>\n    </ng-template>\n  </div>\n\n  <!-- Summary -->\n  @if (summaryTemplateRef) {\n  <div class=\"cub-datatable-footer\">\n    <ng-container *ngTemplateOutlet=\"summaryTemplateRef\"></ng-container>\n  </div>\n  }\n\n  <!-- \u5206\u9801\u5668 -->\n  @if (paginator) {\n  <cub-paginator\n    [alwaysShow]=\"alwaysShowPaginator\"\n    [hidePageSize]=\"hidePageSize\"\n    [pageRangeTemplate]=\"pageRangeTemplate\"\n    [jumpToTemplate]=\"jumpToTemplate\"\n    [showPageRange]=\"showPageRange\"\n    [showFirstLastButton]=\"showFirstLastButton\"\n    [pageLinkAutoSize]=\"pageLinkAutoSize\"\n    [pageLinkSize]=\"pageLinkSize\"\n    [totalRecords]=\"\n      this.paginatorType === 'clientSide' ? totalRecords : paginatorTotalRecords\n    \"\n    [pageSize]=\"pageSize\"\n    [pageSizeOptions]=\"pageSizeOptions\"\n    [pageIndex]=\"pageIndex\"\n    (pageChange)=\"onPageChange($event)\"\n  ></cub-paginator>\n  }\n\n  <!-- Column Resizer -->\n  @if (resizableColumns) {\n  <div\n    #resizeHelper\n    class=\"cub-column-resizer-helper\"\n    style=\"display: none\"\n  ></div>\n  }\n  <!-- Reorder Column -->\n  @if (reorderableColumns) {\n  <span\n    #reorderIndicatorUp\n    class=\"cub-datatable-reorder-indicator-up cub-icon-arrowup_24\"\n    style=\"display: none\"\n  ></span>\n  }\n  <!-- Reorder Column -->\n  @if (reorderableColumns) {\n  <span\n    #reorderIndicatorDown\n    class=\"cub-datatable-reorder-indicator-down cub-icon-arrowdown_24\"\n    style=\"display: none\"\n  ></span>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: CubTableService }, { type: i0.ChangeDetectorRef }, { type: i2.CubFilterService }], propDecorators: { appearance: [{
                type: Input
            }], size: [{
                type: Input
            }], style: [{
                type: Input
            }], styleClass: [{
                type: Input
            }], tableStyle: [{
                type: Input
            }], tableStyleClass: [{
                type: Input
            }], value: [{
                type: Input
            }], columns: [{
                type: Input
            }], paginator: [{
                type: Input
            }], paginatorType: [{
                type: Input
            }], paginatorTotalRecords: [{
                type: Input
            }], alwaysShowPaginator: [{
                type: Input
            }], pageRangeTemplate: [{
                type: Input
            }], jumpToTemplate: [{
                type: Input
            }], showPageRange: [{
                type: Input
            }], showFirstLastButton: [{
                type: Input
            }], pageLinkAutoSize: [{
                type: Input
            }], pageLinkSize: [{
                type: Input
            }], totalRecords: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageSizeOptions: [{
                type: Input
            }], hidePageSize: [{
                type: Input
            }], pageIndex: [{
                type: Input
            }], first: [{
                type: Input
            }], defaultSortOrder: [{
                type: Input
            }], sortMode: [{
                type: Input
            }], resetPageOnSort: [{
                type: Input
            }], customSort: [{
                type: Input
            }], sortField: [{
                type: Input
            }], sortOrder: [{
                type: Input
            }], multiSortMeta: [{
                type: Input
            }], loading: [{
                type: Input
            }], lazy: [{
                type: Input
            }], lazyLoadOnInit: [{
                type: Input
            }], responsiveLayout: [{
                type: Input
            }], scrollable: [{
                type: Input
            }], scrollHeight: [{
                type: Input
            }], dataKey: [{
                type: Input
            }], selectionPageOnly: [{
                type: Input
            }], selectionTemplate: [{
                type: Input
            }], selectionButtonTemplate: [{
                type: Input
            }], selection: [{
                type: Input
            }], selectAll: [{
                type: Input
            }], filterTemplate: [{
                type: Input
            }], filterButtonTemplate: [{
                type: Input
            }], showColumnToggle: [{
                type: Input
            }], columnToggleButtonTemplate: [{
                type: Input
            }], rowExpandMode: [{
                type: Input
            }], expandedRowKeys: [{
                type: Input
            }], dragToScroll: [{
                type: Input
            }], firstChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }], pageChange: [{
                type: Output
            }], sortFunction: [{
                type: Output
            }], sort: [{
                type: Output
            }], lazyLoad: [{
                type: Output
            }], selectAllChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], headerCheckboxChange: [{
                type: Output
            }], filter: [{
                type: Output
            }], columnToggle: [{
                type: Output
            }], rowExpand: [{
                type: Output
            }], rowCollapse: [{
                type: Output
            }], columnResize: [{
                type: Output
            }], columnReorder: [{
                type: Output
            }], rowReorder: [{
                type: Output
            }], containerViewChild: [{
                type: ViewChild,
                args: ['container']
            }], resizeHelperViewChild: [{
                type: ViewChild,
                args: ['resizeHelper']
            }], reorderIndicatorUpViewChild: [{
                type: ViewChild,
                args: ['reorderIndicatorUp']
            }], reorderIndicatorDownViewChild: [{
                type: ViewChild,
                args: ['reorderIndicatorDown']
            }], wrapperViewChild: [{
                type: ViewChild,
                args: ['wrapper']
            }], tableViewChild: [{
                type: ViewChild,
                args: ['table']
            }], tableHeaderViewChild: [{
                type: ViewChild,
                args: ['thead']
            }], tableFooterViewChild: [{
                type: ViewChild,
                args: ['tfoot']
            }], scroller: [{
                type: ViewChild,
                args: ['scroller']
            }], previewTableViewChild: [{
                type: ViewChild,
                args: ['previewTable']
            }], templates: [{
                type: ContentChildren,
                args: [CubTemplate]
            }] } });
/** 獨立 Tbody 元件檔案編譯會產生 Cycle Import 錯誤，暫時不獨立檔案 */
class CubTableBody {
    /** 表格的物件陣列資料，預設為 undefined。 */
    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
        if (this.frozenRows) {
            this.updateFrozenRowStickyPosition();
        }
        if (this.cubTable.scrollable &&
            this.cubTable.rowGroupMode === 'subheader') {
            this.updateFrozenRowGroupHeaderStickyPosition();
        }
    }
    constructor(cubTable, tableService, changeDetectorRef, elementRef) {
        this.cubTable = cubTable;
        this.tableService = tableService;
        this.changeDetectorRef = changeDetectorRef;
        this.elementRef = elementRef;
        this.subscription = this.cubTable.tableService.valueSource$.subscribe(() => {
            if (this.cubTable.virtualScroll) {
                this.changeDetectorRef.detectChanges();
            }
        });
    }
    ngAfterViewInit() {
        if (this.frozenRows) {
            this.updateFrozenRowStickyPosition();
        }
        if (this.cubTable.scrollable &&
            this.cubTable.rowGroupMode === 'subheader') {
            this.updateFrozenRowGroupHeaderStickyPosition();
        }
    }
    ngOnChanges(changes) { }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    shouldRenderRowGroupHeader(value, rowData, index) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.cubTable.groupRowsBy);
        let prevRowData = value[index - 1];
        if (prevRowData) {
            let previousRowFieldData = ObjectUtils.resolveFieldData(prevRowData, this.cubTable.groupRowsBy);
            return currentRowFieldData !== previousRowFieldData;
        }
        else {
            return true;
        }
    }
    shouldRenderRowGroupFooter(value, rowData, index) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.cubTable.groupRowsBy);
        let nextRowData = value[index + 1];
        if (nextRowData) {
            let nextRowFieldData = ObjectUtils.resolveFieldData(nextRowData, this.cubTable.groupRowsBy);
            return currentRowFieldData !== nextRowFieldData;
        }
        else {
            return true;
        }
    }
    shouldRenderRowspan(value, rowData, index) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.cubTable.groupRowsBy);
        let prevRowData = value[index - 1];
        if (prevRowData) {
            let previousRowFieldData = ObjectUtils.resolveFieldData(prevRowData, this.cubTable.groupRowsBy);
            return currentRowFieldData !== previousRowFieldData;
        }
        else {
            return true;
        }
    }
    calculateRowGroupSize(value, rowData, index) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.cubTable.groupRowsBy);
        let nextRowFieldData = currentRowFieldData;
        let groupRowSpan = 0;
        while (currentRowFieldData === nextRowFieldData) {
            groupRowSpan++;
            let nextRowData = value[++index];
            if (nextRowData) {
                nextRowFieldData = ObjectUtils.resolveFieldData(nextRowData, this.cubTable.groupRowsBy);
            }
            else {
                break;
            }
        }
        return groupRowSpan === 1 ? null : groupRowSpan;
    }
    updateFrozenRowStickyPosition() {
        this.elementRef.nativeElement.style.top =
            DomHandler.getOuterHeight(this.elementRef.nativeElement.previousElementSibling) + 'px';
    }
    updateFrozenRowGroupHeaderStickyPosition() {
        if (this.elementRef.nativeElement.previousElementSibling) {
            let tableHeaderHeight = DomHandler.getOuterHeight(this.elementRef.nativeElement.previousElementSibling);
            this.cubTable.rowGroupHeaderStyleObject.top = tableHeaderHeight + 'px';
        }
    }
    getScrollerOption(option, options) {
        if (this.cubTable.virtualScroll) {
            options = options || this.scrollerOptions;
            return options ? options[option] : null;
        }
        return null;
    }
    getRowIndex(rowIndex) {
        const index = this.cubTable.paginator
            ? this.cubTable.first + rowIndex
            : rowIndex;
        const getItemOptions = this.getScrollerOption('getItemOptions');
        return getItemOptions ? getItemOptions(index).index : index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableBody, deps: [{ token: CubTable }, { token: CubTableService }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTableBody, isStandalone: true, selector: "[cubTableBody]", inputs: { columns: ["cubTableBody", "columns"], template: ["cubTableBodyTemplate", "template"], value: "value", frozen: "frozen", frozenRows: "frozenRows", scrollerOptions: "scrollerOptions" }, providers: [CubTableService], usesOnChanges: true, ngImport: i0, template: `@if (!cubTable.expandedRowTemplateRef) { @for (rowData of value;
    track cubTable.rowTrackBy($index, rowData); let rowIndex = $index) { @if
    (cubTable.groupHeaderTemplateRef && !cubTable.virtualScroll &&
    cubTable.rowGroupMode === 'subheader' && shouldRenderRowGroupHeader(value,
    rowData, rowIndex)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupHeaderTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.rowGroupMode !== 'rowspan') {
    <ng-container
      *ngTemplateOutlet="
        rowData ? template : cubTable.loadingBodyTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.rowGroupMode === 'rowspan') {
    <ng-container
      *ngTemplateOutlet="
        rowData ? template : cubTable.loadingBodyTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen,
          rowgroup: shouldRenderRowspan(value, rowData, rowIndex),
          rowspan: calculateRowGroupSize(value, rowData, rowIndex)
        }
      "
    ></ng-container>
    } @if (cubTable.groupFooterTemplateRef && !cubTable.virtualScroll &&
    cubTable.rowGroupMode === 'subheader' && shouldRenderRowGroupFooter(value,
    rowData, rowIndex)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupFooterTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } } } @if (cubTable.expandedRowTemplateRef && !(frozen &&
    cubTable.frozenExpandedRowTemplateRef)) { @for (rowData of value; track
    cubTable.rowTrackBy($index, rowData); let rowIndex = $index) { @if
    (!cubTable.groupHeaderTemplateRef) {
    <ng-container
      *ngTemplateOutlet="
        template;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.groupHeaderTemplateRef && cubTable.rowGroupMode ===
    'subheader' && shouldRenderRowGroupHeader(value, rowData,
    getRowIndex(rowIndex))) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupHeaderTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.isRowExpanded(rowData)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.expandedRowTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          frozen: frozen
        }
      "
    ></ng-container>
    @if (cubTable.groupFooterTemplateRef && cubTable.rowGroupMode ===
    'subheader' && shouldRenderRowGroupFooter(value, rowData,
    getRowIndex(rowIndex))) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupFooterTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } } } } @if (cubTable.frozenExpandedRowTemplateRef && frozen) { @for
    (rowData of value; track cubTable.rowTrackBy($index, rowData); let rowIndex
    = $index) {
    <ng-container
      *ngTemplateOutlet="
        template;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    @if (cubTable.isRowExpanded(rowData)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.frozenExpandedRowTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          frozen: frozen
        }
      "
    ></ng-container>
    } } } @if (cubTable.loading) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.loadingBodyTemplateRef;
        context: { $implicit: columns, frozen: frozen }
      "
    ></ng-container>
    } @if (cubTable.isEmpty() && !cubTable.loading) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.emptyMessageTemplateRef;
        context: { $implicit: columns, frozen: frozen }
      "
    ></ng-container>
    }`, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableBody, decorators: [{
            type: Component,
            args: [{
                    selector: '[cubTableBody]',
                    template: `@if (!cubTable.expandedRowTemplateRef) { @for (rowData of value;
    track cubTable.rowTrackBy($index, rowData); let rowIndex = $index) { @if
    (cubTable.groupHeaderTemplateRef && !cubTable.virtualScroll &&
    cubTable.rowGroupMode === 'subheader' && shouldRenderRowGroupHeader(value,
    rowData, rowIndex)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupHeaderTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.rowGroupMode !== 'rowspan') {
    <ng-container
      *ngTemplateOutlet="
        rowData ? template : cubTable.loadingBodyTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.rowGroupMode === 'rowspan') {
    <ng-container
      *ngTemplateOutlet="
        rowData ? template : cubTable.loadingBodyTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen,
          rowgroup: shouldRenderRowspan(value, rowData, rowIndex),
          rowspan: calculateRowGroupSize(value, rowData, rowIndex)
        }
      "
    ></ng-container>
    } @if (cubTable.groupFooterTemplateRef && !cubTable.virtualScroll &&
    cubTable.rowGroupMode === 'subheader' && shouldRenderRowGroupFooter(value,
    rowData, rowIndex)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupFooterTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } } } @if (cubTable.expandedRowTemplateRef && !(frozen &&
    cubTable.frozenExpandedRowTemplateRef)) { @for (rowData of value; track
    cubTable.rowTrackBy($index, rowData); let rowIndex = $index) { @if
    (!cubTable.groupHeaderTemplateRef) {
    <ng-container
      *ngTemplateOutlet="
        template;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.groupHeaderTemplateRef && cubTable.rowGroupMode ===
    'subheader' && shouldRenderRowGroupHeader(value, rowData,
    getRowIndex(rowIndex))) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupHeaderTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } @if (cubTable.isRowExpanded(rowData)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.expandedRowTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          frozen: frozen
        }
      "
    ></ng-container>
    @if (cubTable.groupFooterTemplateRef && cubTable.rowGroupMode ===
    'subheader' && shouldRenderRowGroupFooter(value, rowData,
    getRowIndex(rowIndex))) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.groupFooterTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    } } } } @if (cubTable.frozenExpandedRowTemplateRef && frozen) { @for
    (rowData of value; track cubTable.rowTrackBy($index, rowData); let rowIndex
    = $index) {
    <ng-container
      *ngTemplateOutlet="
        template;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          expanded: cubTable.isRowExpanded(rowData),
          editing:
            cubTable.editMode === 'row' && cubTable.isRowEditing(rowData),
          frozen: frozen
        }
      "
    ></ng-container>
    @if (cubTable.isRowExpanded(rowData)) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.frozenExpandedRowTemplateRef;
        context: {
          $implicit: rowData,
          rowIndex: getRowIndex(rowIndex),
          columns: columns,
          frozen: frozen
        }
      "
    ></ng-container>
    } } } @if (cubTable.loading) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.loadingBodyTemplateRef;
        context: { $implicit: columns, frozen: frozen }
      "
    ></ng-container>
    } @if (cubTable.isEmpty() && !cubTable.loading) {
    <ng-container
      *ngTemplateOutlet="
        cubTable.emptyMessageTemplateRef;
        context: { $implicit: columns, frozen: frozen }
      "
    ></ng-container>
    }`,
                    providers: [CubTableService],
                    changeDetection: ChangeDetectionStrategy.Default,
                    encapsulation: ViewEncapsulation.None,
                    imports: [NgTemplateOutlet],
                }]
        }], ctorParameters: () => [{ type: CubTable }, { type: CubTableService }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }], propDecorators: { columns: [{
                type: Input,
                args: ['cubTableBody']
            }], template: [{
                type: Input,
                args: ['cubTableBodyTemplate']
            }], value: [{
                type: Input
            }], frozen: [{
                type: Input
            }], frozenRows: [{
                type: Input
            }], scrollerOptions: [{
                type: Input
            }] } });

class CubTableSortIcon {
    constructor(cubTable, changeDetectorRef) {
        this.cubTable = cubTable;
        this.changeDetectorRef = changeDetectorRef;
        this.subscription = this.cubTable.tableService.sortSource$.subscribe((sortMeta) => {
            this.updateSortState();
        });
    }
    ngOnInit() {
        this.updateSortState();
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    onClick(event) {
        event.preventDefault();
    }
    updateSortState() {
        if (this.cubTable.sortMode === 'single') {
            this.sortOrder = this.cubTable.isSorted(this.field)
                ? this.cubTable.sortOrder
                : 0;
        }
        else if (this.cubTable.sortMode === 'multiple') {
            let sortMeta = this.cubTable.getSortMeta(this.field);
            this.sortOrder = sortMeta ? sortMeta.order : 0;
        }
        this.changeDetectorRef.markForCheck();
    }
    getMultiSortMetaIndex() {
        let multiSortMeta = this.cubTable._multiSortMeta;
        let index = -1;
        if (multiSortMeta &&
            this.cubTable.sortMode === 'multiple' &&
            (this.cubTable.showInitialSortBadge || multiSortMeta.length > 1)) {
            for (let i = 0; i < multiSortMeta.length; i++) {
                let meta = multiSortMeta[i];
                if (meta.field === this.field || meta.field === this.field) {
                    index = i;
                    break;
                }
            }
        }
        return index;
    }
    getBadgeValue() {
        let index = this.getMultiSortMetaIndex();
        return this.cubTable.groupRowsBy && index > -1 ? index : index + 1;
    }
    isMultiSorted() {
        return (this.cubTable.sortMode === 'multiple' && this.getMultiSortMetaIndex() > -1);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableSortIcon, deps: [{ token: CubTable }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTableSortIcon, isStandalone: true, selector: "cub-table-sort-icon", inputs: { field: "field" }, host: { classAttribute: "cub-table-sort-icon" }, ngImport: i0, template: "<svg\n  width=\"16\"\n  height=\"24\"\n  viewBox=\"0 0 16 24\"\n  fill=\"none\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  class=\"cub-sortable-column-icon\"\n>\n  @if (sortOrder === 1) {\n    <path\n      d=\"M8.00002 5.18004L5.23002 7.95004C5.13811 8.04617 5.01286 8.10343 4.88002 8.11004C4.7842 8.10871 4.69057 8.08118 4.60928 8.03043C4.52798 7.97967 4.46213 7.90764 4.41887 7.82213C4.3756 7.73662 4.35656 7.6409 4.36381 7.54534C4.37107 7.44978 4.40434 7.35804 4.46002 7.28004C4.48002 7.26004 4.49002 7.24004 4.51002 7.23004L7.43002 4.31004C7.50678 4.23222 7.59867 4.17096 7.70002 4.13004C7.89389 4.06001 8.10615 4.06001 8.30002 4.13004C8.3994 4.17462 8.49065 4.23545 8.57002 4.31004L11.49 7.23004C11.5862 7.32195 11.6434 7.4472 11.65 7.58004C11.6487 7.67586 11.6212 7.7695 11.5704 7.85079C11.5197 7.93208 11.4476 7.99793 11.3621 8.0412C11.2766 8.08447 11.1809 8.10351 11.0853 8.09625C10.9898 8.089 10.898 8.05572 10.82 8.00004C10.8 7.98004 10.78 7.97004 10.77 7.95004L8.00002 5.18004Z\"\n      fill=\"currentColor\"\n    />\n  } @else if (sortOrder === -1) {\n    <path\n      d=\"M8.0001 18.82L10.7701 16.05C10.8646 15.9576 10.9884 15.9011 11.1201 15.89C11.1896 15.8886 11.2587 15.9021 11.3225 15.9297C11.3863 15.9573 11.4435 15.9984 11.4901 16.05C11.5374 16.0907 11.5762 16.1403 11.6043 16.196C11.6324 16.2517 11.6492 16.3124 11.6539 16.3746C11.6585 16.4369 11.6509 16.4994 11.6313 16.5586C11.6118 16.6179 11.5808 16.6727 11.5401 16.72C11.5201 16.74 11.5101 16.76 11.4901 16.77L8.5701 19.69C8.49334 19.7678 8.40145 19.8291 8.3001 19.87C8.10623 19.94 7.89397 19.94 7.7001 19.87C7.59875 19.8291 7.50686 19.7678 7.4301 19.69L4.5101 16.77C4.41397 16.6781 4.35671 16.5528 4.3501 16.42C4.35143 16.3242 4.37896 16.2305 4.42971 16.1492C4.48046 16.068 4.5525 16.0021 4.63801 15.9588C4.72351 15.9156 4.81924 15.8965 4.91479 15.9038C5.01035 15.911 5.1021 15.9443 5.1801 16C5.2001 16.02 5.2201 16.03 5.2301 16.05L8.0001 18.82Z\"\n      fill=\"currentColor\"\n    />\n  } @else if (sortOrder === 0) {\n    <path\n      d=\"M8.0001 18.82L10.7701 16.05C10.8646 15.9577 10.9884 15.9011 11.1201 15.89C11.1896 15.8886 11.2587 15.9022 11.3225 15.9298C11.3863 15.9574 11.4435 15.9984 11.4901 16.05C11.5374 16.0907 11.5762 16.1404 11.6043 16.1961C11.6324 16.2518 11.6492 16.3125 11.6539 16.3747C11.6585 16.4369 11.6509 16.4994 11.6313 16.5587C11.6118 16.6179 11.5808 16.6728 11.5401 16.72C11.5201 16.74 11.5101 16.76 11.4901 16.77L8.5701 19.69C8.49334 19.7679 8.40145 19.8291 8.3001 19.87C8.10623 19.9401 7.89397 19.9401 7.7001 19.87C7.59875 19.8291 7.50686 19.7679 7.4301 19.69L4.5101 16.77C4.41397 16.6781 4.35671 16.5529 4.3501 16.42C4.35143 16.3242 4.37896 16.2306 4.42971 16.1493C4.48046 16.068 4.5525 16.0021 4.63801 15.9589C4.72351 15.9156 4.81924 15.8966 4.91479 15.9038C5.01035 15.9111 5.1021 15.9444 5.1801 16C5.2001 16.02 5.2201 16.03 5.2301 16.05L8.0001 18.82ZM8.0001 5.18004L5.2301 7.95004C5.13818 8.04617 5.01293 8.10343 4.8801 8.11004C4.78427 8.10871 4.69064 8.08118 4.60935 8.03043C4.52806 7.97967 4.46221 7.90764 4.41894 7.82213C4.37567 7.73662 4.35663 7.6409 4.36388 7.54534C4.37114 7.44978 4.40441 7.35804 4.4601 7.28004C4.4801 7.26004 4.4901 7.24004 4.5101 7.23004L7.4301 4.31004C7.50686 4.23222 7.59875 4.17096 7.7001 4.13004C7.89397 4.06001 8.10623 4.06001 8.3001 4.13004C8.39947 4.17462 8.49073 4.23545 8.5701 4.31004L11.4901 7.23004C11.5862 7.32195 11.6435 7.4472 11.6501 7.58004C11.6488 7.67586 11.6212 7.7695 11.5705 7.85079C11.5197 7.93208 11.4477 7.99793 11.3622 8.0412C11.2767 8.08447 11.181 8.10351 11.0854 8.09625C10.9898 8.089 10.8981 8.05572 10.8201 8.00004C10.8001 7.98004 10.7801 7.97004 10.7701 7.95004L8.0001 5.18004Z\"\n      fill=\"currentColor\"\n    />\n  }\n</svg>\n\n@if (isMultiSorted()) {\n  <span class=\"cub-sortable-column-badge\">{{ getBadgeValue() }}</span>\n}\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableSortIcon, decorators: [{
            type: Component,
            args: [{ selector: 'cub-table-sort-icon', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-table-sort-icon',
                    }, template: "<svg\n  width=\"16\"\n  height=\"24\"\n  viewBox=\"0 0 16 24\"\n  fill=\"none\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  class=\"cub-sortable-column-icon\"\n>\n  @if (sortOrder === 1) {\n    <path\n      d=\"M8.00002 5.18004L5.23002 7.95004C5.13811 8.04617 5.01286 8.10343 4.88002 8.11004C4.7842 8.10871 4.69057 8.08118 4.60928 8.03043C4.52798 7.97967 4.46213 7.90764 4.41887 7.82213C4.3756 7.73662 4.35656 7.6409 4.36381 7.54534C4.37107 7.44978 4.40434 7.35804 4.46002 7.28004C4.48002 7.26004 4.49002 7.24004 4.51002 7.23004L7.43002 4.31004C7.50678 4.23222 7.59867 4.17096 7.70002 4.13004C7.89389 4.06001 8.10615 4.06001 8.30002 4.13004C8.3994 4.17462 8.49065 4.23545 8.57002 4.31004L11.49 7.23004C11.5862 7.32195 11.6434 7.4472 11.65 7.58004C11.6487 7.67586 11.6212 7.7695 11.5704 7.85079C11.5197 7.93208 11.4476 7.99793 11.3621 8.0412C11.2766 8.08447 11.1809 8.10351 11.0853 8.09625C10.9898 8.089 10.898 8.05572 10.82 8.00004C10.8 7.98004 10.78 7.97004 10.77 7.95004L8.00002 5.18004Z\"\n      fill=\"currentColor\"\n    />\n  } @else if (sortOrder === -1) {\n    <path\n      d=\"M8.0001 18.82L10.7701 16.05C10.8646 15.9576 10.9884 15.9011 11.1201 15.89C11.1896 15.8886 11.2587 15.9021 11.3225 15.9297C11.3863 15.9573 11.4435 15.9984 11.4901 16.05C11.5374 16.0907 11.5762 16.1403 11.6043 16.196C11.6324 16.2517 11.6492 16.3124 11.6539 16.3746C11.6585 16.4369 11.6509 16.4994 11.6313 16.5586C11.6118 16.6179 11.5808 16.6727 11.5401 16.72C11.5201 16.74 11.5101 16.76 11.4901 16.77L8.5701 19.69C8.49334 19.7678 8.40145 19.8291 8.3001 19.87C8.10623 19.94 7.89397 19.94 7.7001 19.87C7.59875 19.8291 7.50686 19.7678 7.4301 19.69L4.5101 16.77C4.41397 16.6781 4.35671 16.5528 4.3501 16.42C4.35143 16.3242 4.37896 16.2305 4.42971 16.1492C4.48046 16.068 4.5525 16.0021 4.63801 15.9588C4.72351 15.9156 4.81924 15.8965 4.91479 15.9038C5.01035 15.911 5.1021 15.9443 5.1801 16C5.2001 16.02 5.2201 16.03 5.2301 16.05L8.0001 18.82Z\"\n      fill=\"currentColor\"\n    />\n  } @else if (sortOrder === 0) {\n    <path\n      d=\"M8.0001 18.82L10.7701 16.05C10.8646 15.9577 10.9884 15.9011 11.1201 15.89C11.1896 15.8886 11.2587 15.9022 11.3225 15.9298C11.3863 15.9574 11.4435 15.9984 11.4901 16.05C11.5374 16.0907 11.5762 16.1404 11.6043 16.1961C11.6324 16.2518 11.6492 16.3125 11.6539 16.3747C11.6585 16.4369 11.6509 16.4994 11.6313 16.5587C11.6118 16.6179 11.5808 16.6728 11.5401 16.72C11.5201 16.74 11.5101 16.76 11.4901 16.77L8.5701 19.69C8.49334 19.7679 8.40145 19.8291 8.3001 19.87C8.10623 19.9401 7.89397 19.9401 7.7001 19.87C7.59875 19.8291 7.50686 19.7679 7.4301 19.69L4.5101 16.77C4.41397 16.6781 4.35671 16.5529 4.3501 16.42C4.35143 16.3242 4.37896 16.2306 4.42971 16.1493C4.48046 16.068 4.5525 16.0021 4.63801 15.9589C4.72351 15.9156 4.81924 15.8966 4.91479 15.9038C5.01035 15.9111 5.1021 15.9444 5.1801 16C5.2001 16.02 5.2201 16.03 5.2301 16.05L8.0001 18.82ZM8.0001 5.18004L5.2301 7.95004C5.13818 8.04617 5.01293 8.10343 4.8801 8.11004C4.78427 8.10871 4.69064 8.08118 4.60935 8.03043C4.52806 7.97967 4.46221 7.90764 4.41894 7.82213C4.37567 7.73662 4.35663 7.6409 4.36388 7.54534C4.37114 7.44978 4.40441 7.35804 4.4601 7.28004C4.4801 7.26004 4.4901 7.24004 4.5101 7.23004L7.4301 4.31004C7.50686 4.23222 7.59875 4.17096 7.7001 4.13004C7.89397 4.06001 8.10623 4.06001 8.3001 4.13004C8.39947 4.17462 8.49073 4.23545 8.5701 4.31004L11.4901 7.23004C11.5862 7.32195 11.6435 7.4472 11.6501 7.58004C11.6488 7.67586 11.6212 7.7695 11.5705 7.85079C11.5197 7.93208 11.4477 7.99793 11.3622 8.0412C11.2767 8.08447 11.181 8.10351 11.0854 8.09625C10.9898 8.089 10.8981 8.05572 10.8201 8.00004C10.8001 7.98004 10.7801 7.97004 10.7701 7.95004L8.0001 5.18004Z\"\n      fill=\"currentColor\"\n    />\n  }\n</svg>\n\n@if (isMultiSorted()) {\n  <span class=\"cub-sortable-column-badge\">{{ getBadgeValue() }}</span>\n}\n" }]
        }], ctorParameters: () => [{ type: CubTable }, { type: i0.ChangeDetectorRef }], propDecorators: { field: [{
                type: Input
            }] } });

class CubColumnFilterFormElement {
    constructor(cubTable) {
        this.cubTable = cubTable;
        /** 是否顯示數值分割符號，預設為 true。 */
        /** 僅當 type 設定為 'numeric' 時可用。 */
        this.useGrouping = true;
    }
    ngOnInit() {
        this.filterCallback = (value) => {
            this.filterConstraint[0].value = value;
            this.cubTable._filter();
        };
    }
    onModelChange(value) {
        this.filterConstraint[0].value = value;
        if (this.type === 'boolean' || value === '') {
            this.cubTable._filter();
        }
    }
    onTextInputEnterKeyDown(event) {
        this.cubTable._filter();
        event.preventDefault();
    }
    onNumericInputKeyDown(event) {
        if (event.key === 'Enter') {
            this.cubTable._filter();
            event.preventDefault();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubColumnFilterFormElement, deps: [{ token: CubTable }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubColumnFilterFormElement, isStandalone: true, selector: "cub-column-filter-form-element", inputs: { field: "field", type: "type", filterConstraint: "filterConstraint", filterTemplateRef: "filterTemplateRef", placeholder: "placeholder", minFractionDigits: "minFractionDigits", maxFractionDigits: "maxFractionDigits", prefix: "prefix", suffix: "suffix", locale: "locale", localeMatcher: "localeMatcher", currency: "currency", currencyDisplay: "currencyDisplay", useGrouping: "useGrouping" }, host: { classAttribute: "cub-column-filter-form-element" }, ngImport: i0, template: "<ng-container *ngIf=\"filterTemplateRef\">\n  <ng-container\n    *ngTemplateOutlet=\"\n      filterTemplateRef;\n      context: {\n        $implicit: filterConstraint.value,\n        filterCallback: filterCallback\n      }\n    \"\n  ></ng-container>\n</ng-container>\n", styles: [""], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubColumnFilterFormElement, decorators: [{
            type: Component,
            args: [{ selector: 'cub-column-filter-form-element', encapsulation: ViewEncapsulation.None, host: { class: 'cub-column-filter-form-element' }, imports: [NgIf, NgTemplateOutlet], template: "<ng-container *ngIf=\"filterTemplateRef\">\n  <ng-container\n    *ngTemplateOutlet=\"\n      filterTemplateRef;\n      context: {\n        $implicit: filterConstraint.value,\n        filterCallback: filterCallback\n      }\n    \"\n  ></ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: CubTable }], propDecorators: { field: [{
                type: Input
            }], type: [{
                type: Input
            }], filterConstraint: [{
                type: Input
            }], filterTemplateRef: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], minFractionDigits: [{
                type: Input
            }], maxFractionDigits: [{
                type: Input
            }], prefix: [{
                type: Input
            }], suffix: [{
                type: Input
            }], locale: [{
                type: Input
            }], localeMatcher: [{
                type: Input
            }], currency: [{
                type: Input
            }], currencyDisplay: [{
                type: Input
            }], useGrouping: [{
                type: Input
            }] } });

class CubTableFilterIcon {
    get fieldConstraints() {
        return this.cubTable.filters
            ? this.cubTable.filters[this.field]
            : null;
    }
    get showRemoveIcon() {
        return this.fieldConstraints ? this.fieldConstraints.length > 1 : false;
    }
    get isShowAddConstraint() {
        return (this.showAddButton &&
            this.type !== 'boolean' &&
            this.fieldConstraints &&
            this.fieldConstraints.length < this.maxConstraints);
    }
    get applyButtonLabel() {
        return this.config.getTranslation(TranslationKeys.APPLY);
    }
    get clearButtonLabel() {
        return this.config.getTranslation(TranslationKeys.CLEAR);
    }
    get addRuleButtonLabel() {
        return this.config.getTranslation(TranslationKeys.ADD_RULE);
    }
    get removeRuleButtonLabel() {
        return this.config.getTranslation(TranslationKeys.REMOVE_RULE);
    }
    get noFilterLabel() {
        return this.config.getTranslation(TranslationKeys.NO_FILTER);
    }
    constructor(cubTable, elementRef, config, renderer) {
        this.cubTable = cubTable;
        this.elementRef = elementRef;
        this.config = config;
        this.renderer = renderer;
        // --------------- 暫隱藏的接口，待有開發需求時再開啟 ---------------
        /** 篩選的顯示模式，有效值為 'dropdown'（複合選單） 與 'popover'（彈出面板），預設為 'dropdown'。 */
        this.display = 'dropdown';
        this.showAddButton = false;
        this.showClearButton = false;
        this.showApplyButton = false;
        this.maxConstraints = 2;
        //////////////////////////////////////////////////////////////////
        this.filterValue = [];
        /** 篩選的運算方式，有效值為 'and' 與 'or'，預設為 'or'。 */
        this.operator = FilterOperator.OR;
        /** 篩選的欄位類型，有效值為 'text'、'numeric'、'date' 與 'boolean'，預設為 'text'。 */
        this.type = 'text';
        /** 篩選的選項清單，預設為 []。 */
        this.options = [];
        /** 是否顯示數值分割符號，預設為 true。 */
        /** 僅當 type 設定為 'numeric' 時可用。 */
        /** 此為 Intl.NumberFormat() 函式使用的相關參數。 */
        this.useGrouping = true;
    }
    ngOnInit() {
        if (!this.cubTable.filters[this.field]) {
            this.initFieldFilterConstraint();
        }
        this.translationSubscription = this.config.translationObserver.subscribe(() => {
            this.generateMatchModeOptions();
            this.generateOperatorOptions();
        });
        this.resetSubscription = this.cubTable.tableService.resetSource$.subscribe(() => {
            this.initFieldFilterConstraint();
        });
        this.generateMatchModeOptions();
        this.generateOperatorOptions();
    }
    ngAfterContentInit() {
        this.templates.forEach((item) => {
            switch (item.getType()) {
                case 'header':
                    this.headerTemplateRef = item.template;
                    break;
                case 'filter':
                    this.filterTemplateRef = item.template;
                    break;
                case 'footer':
                    this.footerTemplateRef = item.template;
                    break;
                default:
                    this.filterTemplateRef = item.template;
                    break;
            }
        });
    }
    ngOnDestroy() {
        if (this.overlay) {
            this.elementRef.nativeElement.appendChild(this.overlay);
            //ZIndexUtils.clear(this.overlay);
            //this.onOverlayHide();
        }
        if (this.translationSubscription) {
            this.translationSubscription.unsubscribe();
        }
        if (this.resetSubscription) {
            this.resetSubscription.unsubscribe();
        }
        if (this.overlaySubscription) {
            this.overlaySubscription.unsubscribe();
        }
    }
    generateMatchModeOptions() {
        this.matchModes =
            this.matchModeOptions ||
                this.config.filterMatchModeOptions[this.type]?.map((key) => {
                    return { label: this.config.getTranslation(key), value: key };
                });
    }
    generateOperatorOptions() {
        this.operatorOptions = [
            {
                label: this.config.getTranslation(TranslationKeys.MATCH_ALL),
                value: FilterOperator.AND,
            },
            {
                label: this.config.getTranslation(TranslationKeys.MATCH_ANY),
                value: FilterOperator.OR,
            },
        ];
    }
    initFieldFilterConstraint() {
        let defaultMatchMode = this.getDefaultMatchMode();
        this.cubTable.filters[this.field] = [
            {
                value: null,
                matchMode: defaultMatchMode,
                operator: this.operator,
            },
        ];
        this.filterValue = [];
    }
    onDropdownChange(value) {
        let defaultMatchMode = this.getDefaultMatchMode();
        let defaultOperator = FilterOperator.OR;
        // 更新 filterValue
        this.filterValue = value;
        if (value.length) {
            this.cubTable.filters[this.field] = value.map((val) => ({
                value: val,
                matchMode: defaultMatchMode,
                operator: defaultOperator,
            }));
        }
        else {
            delete this.cubTable.filters[this.field];
        }
        // 如果有自訂 filterCallback，使用自訂邏輯（後端篩選）
        if (this.filterCallback) {
            this.filterCallback(value, this.field);
            return;
        }
        // 否則使用預設的 table 篩選邏輯（前端篩選）
        this.cubTable._filter();
    }
    onMenuMatchModeChange(value, filterMeta) {
        filterMeta.matchMode = value;
        if (!this.showApplyButton) {
            /* TODO 待開放 popover 進階篩選後，確認是否需要判斷前後端篩選 */
            this.cubTable._filter();
        }
    }
    onRowMatchModeChange(matchMode) {
        this.cubTable.filters[this.field].matchMode =
            matchMode;
        /* TODO 待開放 popover 進階篩選後，確認是否需要判斷前後端篩選 */
        this.cubTable._filter();
        this.hide();
    }
    onRowMatchModeKeyDown(event) {
        let item = event.target;
        switch (event.key) {
            case 'ArrowDown':
                var nextItem = this.findNextItem(item);
                if (nextItem) {
                    item.removeAttribute('tabindex');
                    nextItem.tabIndex = '0';
                    nextItem.focus();
                }
                event.preventDefault();
                break;
            case 'ArrowUp':
                var prevItem = this.findPrevItem(item);
                if (prevItem) {
                    item.removeAttribute('tabindex');
                    prevItem.tabIndex = '0';
                    prevItem.focus();
                }
                event.preventDefault();
                break;
        }
    }
    onRowClearItemClick() {
        this.clearFilter();
        this.hide();
    }
    isRowMatchModeSelected(matchMode) {
        return (this.cubTable.filters[this.field].matchMode ===
            matchMode);
    }
    addConstraint() {
        this.cubTable.filters[this.field].push({
            value: null,
            matchMode: this.getDefaultMatchMode(),
            operator: this.getDefaultOperator(),
        });
    }
    removeConstraint(filterMeta) {
        this.cubTable.filters[this.field] = (this.cubTable.filters[this.field]).filter((meta) => meta !== filterMeta);
        /* TODO 待開放 popover 進階篩選後，確認是否需要判斷前後端篩選 */
        this.cubTable._filter();
    }
    onOperatorChange(value) {
        this.cubTable.filters[this.field].forEach((filterMeta) => {
            filterMeta.operator = value;
            this.operator = value;
        });
        if (!this.showApplyButton) {
            /* TODO 待開放 popover 進階篩選後，確認是否需要判斷前後端篩選 */
            this.cubTable._filter();
        }
    }
    toggleMenu() {
        this.overlayVisible = !this.overlayVisible;
    }
    onToggleButtonKeyDown(event) {
        switch (event.key) {
            case 'Escape':
            case 'Tab':
                this.overlayVisible = false;
                break;
            case 'ArrowDown':
                if (this.overlayVisible) {
                    let focusable = DomHandler.getFocusableElements(this.overlay);
                    if (focusable) {
                        focusable[0].focus();
                    }
                    event.preventDefault();
                }
                else if (event.altKey) {
                    this.overlayVisible = true;
                    event.preventDefault();
                }
                break;
        }
    }
    onEscape() {
        this.overlayVisible = false;
        this.icon.nativeElement.focus();
    }
    findNextItem(item) {
        let nextItem = item.nextElementSibling;
        if (nextItem)
            return DomHandler.hasClass(nextItem, 'cub-column-filter-separator')
                ? this.findNextItem(nextItem)
                : nextItem;
        else {
            if (item.parentElement)
                return item.parentElement.firstElementChild;
        }
    }
    findPrevItem(item) {
        let prevItem = item.previousElementSibling;
        if (prevItem)
            return DomHandler.hasClass(prevItem, 'cub-column-filter-separator')
                ? this.findPrevItem(prevItem)
                : prevItem;
        else {
            if (item.parentElement)
                return item.parentElement.lastElementChild;
        }
    }
    onContentClick() {
        this.selfClick = true;
    }
    getDefaultMatchMode() {
        if (this.matchMode) {
            return this.matchMode;
        }
        else {
            if (this.type === 'text')
                return FilterMatchMode.STARTS_WITH;
            else if (this.type === 'numeric')
                return FilterMatchMode.EQUALS;
            else if (this.type === 'date')
                return FilterMatchMode.DATE_IS;
            else
                return FilterMatchMode.CONTAINS;
        }
    }
    getDefaultOperator() {
        return this.cubTable.filters
            ? this.cubTable.filters[this.field][0]
                .operator
            : this.operator;
    }
    hasRowFilter() {
        return (this.cubTable.filters[this.field] &&
            !this.cubTable.isFilterBlank(this.cubTable.filters[this.field].value));
    }
    hasFilter() {
        let fieldFilter = this.cubTable.filters[this.field];
        if (fieldFilter) {
            if (Array.isArray(fieldFilter)) {
                return !this.cubTable.isFilterBlank(fieldFilter[0].value);
            }
        }
        return false;
    }
    isOutsideClicked(event) {
        return !(this.overlay.isSameNode(event.target) ||
            this.overlay.contains(event.target) ||
            this.icon.nativeElement.isSameNode(event.target) ||
            this.icon.nativeElement.contains(event.target) ||
            DomHandler.hasClass(event.target, 'cub-column-filter-add-button') ||
            DomHandler.hasClass(event.target.parentElement, 'cub-column-filter-add-button') ||
            DomHandler.hasClass(event.target, 'cub-column-filter-remove-button') ||
            DomHandler.hasClass(event.target.parentElement, 'cub-column-filter-remove-button'));
    }
    bindDocumentClickListener() {
        if (!this.documentClickListener) {
            const documentTarget = this.elementRef
                ? this.elementRef.nativeElement.ownerDocument
                : 'document';
            this.documentClickListener = this.renderer.listen(documentTarget, 'click', (event) => {
                if (this.overlayVisible &&
                    !this.selfClick &&
                    this.isOutsideClicked(event)) {
                    this.hide();
                }
                this.selfClick = false;
            });
        }
    }
    unbindDocumentClickListener() {
        if (this.documentClickListener) {
            this.documentClickListener();
            this.documentClickListener = null;
            this.selfClick = false;
        }
    }
    bindDocumentResizeListener() {
        this.documentResizeListener = () => {
            if (this.overlayVisible && !DomHandler.isTouchDevice()) {
                this.hide();
            }
        };
        window.addEventListener('resize', this.documentResizeListener);
    }
    unbindDocumentResizeListener() {
        if (this.documentResizeListener) {
            window.removeEventListener('resize', this.documentResizeListener);
            this.documentResizeListener = null;
        }
    }
    hide() {
        this.overlayVisible = false;
    }
    /* 透過按鈕觸發清除篩選的功能 */
    clearFilter() {
        this.filterValue = [];
        this.initFieldFilterConstraint();
        // 如果有自訂 filterCallback，使用自訂邏輯（後端篩選）
        if (this.filterCallback) {
            this.filterCallback([], this.field);
            return;
        }
        // 否則使用預設的 table 篩選邏輯（前端篩選）
        this.cubTable._filter();
    }
    /* 透過按鈕觸發篩選功能 */
    applyFilter() {
        if (this.filterCallback) {
            // 如果有自訂 filterCallback，使用自訂邏輯（後端篩選）
            this.filterCallback([], this.field);
        }
        else {
            // 否則使用預設的 table 篩選邏輯（前端篩選）
            this.cubTable._filter();
        }
        this.hide();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableFilterIcon, deps: [{ token: CubTable }, { token: i0.ElementRef }, { token: i2.TranslationConfig }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTableFilterIcon, isStandalone: true, selector: "cub-table-filter-icon", inputs: { field: "field", matchMode: "matchMode", operator: "operator", type: "type", options: "options", filterCallback: "filterCallback", placeholder: "placeholder", minFractionDigits: "minFractionDigits", maxFractionDigits: "maxFractionDigits", prefix: "prefix", suffix: "suffix", locale: "locale", localeMatcher: "localeMatcher", currency: "currency", currencyDisplay: "currencyDisplay", useGrouping: "useGrouping" }, host: { listeners: { "click": "$event.stopPropagation()", "keydown": "$event.stopPropagation()", "keyup": "$event.stopPropagation()" }, classAttribute: "cub-table-filter-icon" }, queries: [{ propertyName: "templates", predicate: CubTemplate }], viewQueries: [{ propertyName: "icon", first: true, predicate: ["icon"], descendants: true }], ngImport: i0, template: "@if (display === \"dropdown\") {\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral\"\n    appearance=\"plain\"\n    [cubDropDownTriggerFor]=\"dropDown\"\n  >\n    <svg\n      width=\"16\"\n      height=\"24\"\n      viewBox=\"0 0 16 24\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n      class=\"cub-filterable-column-icon cub-icon-filter\"\n    >\n      <path\n        d=\"M7.77003 19C7.66824 19.0025 7.56701 18.9842 7.47247 18.9464C7.37793 18.9086 7.29206 18.852 7.22006 18.78C7.14807 18.708 7.09144 18.6221 7.05362 18.5275C7.01579 18.433 6.99756 18.3318 7.00003 18.23V12.65L1.60003 5.82999C1.54085 5.75286 1.50467 5.66059 1.49564 5.5638C1.48661 5.46701 1.50511 5.36964 1.549 5.2829C1.59289 5.19616 1.66039 5.12359 1.74373 5.07353C1.82706 5.02348 1.92284 4.99799 2.02003 4.99999H13.98C14.0772 4.99799 14.173 5.02348 14.2563 5.07353C14.3397 5.12359 14.4072 5.19616 14.4511 5.2829C14.495 5.36964 14.5134 5.46701 14.5044 5.5638C14.4954 5.66059 14.4592 5.75286 14.4 5.82999L9.00003 12.65V18.23C9.0025 18.3318 8.98427 18.433 8.94644 18.5275C8.90862 18.6221 8.85199 18.708 8.77999 18.78C8.708 18.852 8.62213 18.9086 8.52759 18.9464C8.43305 18.9842 8.33182 19.0025 8.23003 19H7.77003ZM8.00003 12.3L12.95 5.99999H3.05003L8.00003 12.3Z\"\n        fill=\"currentColor\"\n      />\n    </svg>\n  </button>\n\n  <cub-drop-down [size]=\"cubTable.size\" #dropDown>\n    <cub-drop-down-group\n      [value]=\"filterValue\"\n      [multiple]=\"true\"\n      (change)=\"onDropdownChange($event.value)\"\n    >\n      @for (item of options; track item.value) {\n        <button\n          cub-drop-down-option\n          [label]=\"item.label\"\n          [value]=\"item.value\"\n        ></button>\n      }\n    </cub-drop-down-group>\n  </cub-drop-down>\n} @else if (display === \"popover\") {\n  <!-- TODO\uFF1Apopover \u9032\u968E\u7BE9\u9078\u66AB\u4E0D\u4F7F\u7528\uFF0C\u5F85\u60C5\u5883\u5B8C\u5584\u5F8C\u512A\u5316 -->\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral\"\n    appearance=\"plain\"\n    [cubPopoverTriggerFor]=\"popover\"\n    [cubPopoverHasArrow]=\"false\"\n  >\n    <span class=\"cub-filterable-column-icon cub-icon-filter\"></span>\n  </button>\n\n  <cub-popover #popover=\"cubPopover\">\n    <ng-container\n      *ngTemplateOutlet=\"headerTemplateRef; context: { $implicit: field }\"\n    ></ng-container>\n    <cub-column-filter-form-element\n      [type]=\"type\"\n      [field]=\"field\"\n      [filterConstraint]=\"cubTable.filters[field]\"\n      [filterTemplateRef]=\"filterTemplateRef\"\n      [placeholder]=\"placeholder\"\n      [minFractionDigits]=\"minFractionDigits\"\n      [maxFractionDigits]=\"maxFractionDigits\"\n      [prefix]=\"prefix\"\n      [suffix]=\"suffix\"\n      [locale]=\"locale\"\n      [localeMatcher]=\"localeMatcher\"\n      [currency]=\"currency\"\n      [currencyDisplay]=\"currencyDisplay\"\n      [useGrouping]=\"useGrouping\"\n    ></cub-column-filter-form-element>\n\n    @if (isShowAddConstraint) {\n      <button\n        cub-button\n        type=\"button\"\n        appearance=\"plain\"\n        [block]=\"true\"\n        (click)=\"addConstraint()\"\n      >\n        <span cubPrefix class=\"cub-icon-plus\"></span>\n        {{ addRuleButtonLabel }}\n      </button>\n    }\n    <div class=\"cub-filter-buttonbar\">\n      @if (showClearButton) {\n        <button\n          cub-button\n          type=\"button\"\n          color=\"neutral\"\n          appearance=\"text\"\n          (click)=\"clearFilter()\"\n        >\n          {{ clearButtonLabel }}\n        </button>\n      }\n      @if (showApplyButton) {\n        <button\n          cub-button\n          type=\"button\"\n          color=\"brand\"\n          appearance=\"text\"\n          (click)=\"applyFilter()\"\n        >\n          {{ applyButtonLabel }}\n        </button>\n      }\n    </div>\n    <ng-container\n      *ngTemplateOutlet=\"footerTemplateRef; context: { $implicit: field }\"\n    ></ng-container>\n  </cub-popover>\n}\n", styles: [""], dependencies: [{ kind: "directive", type: CubDropDownTrigger, selector: "[cubDropDownTriggerFor]", exportAs: ["cubDropDownTrigger"] }, { kind: "component", type: CubDropDown, selector: "cub-drop-down", exportAs: ["cubDropDown"] }, { kind: "component", type: CubDropDownGroup, selector: "cub-drop-down-group", inputs: ["emptyMessage", "label", "multiple", "selectable", "value", "compareWith"], outputs: ["change"] }, { kind: "component", type: CubDropDownOption, selector: "[cub-drop-down-option]", inputs: ["selected"], outputs: ["selectedChange", "selectionChange"] }, { kind: "directive", type: CubPopoverTrigger, selector: "[cub-popover-trigger-for], [cubPopoverTriggerFor]", inputs: ["cubPopoverTriggerFor", "cubPopoverDisabled", "cubPopoverData", "cubPopoverConnectedTo", "cubPopoverHasArrow"], outputs: ["cubPopoverOpened", "cubPopoverClosed"], exportAs: ["cubPopoverTrigger"] }, { kind: "component", type: CubPopover, selector: "cub-popover", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "enterDelay", "leaveDelay", "positionStart", "positionEnd", "xOffset", "yOffset", "autoFocus", "hasBackdrop", "hasArrow", "triggerEvent", "closeOnPanelClick", "closeOnBackdropClick"], outputs: ["closed"], exportAs: ["cubPopover"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubColumnFilterFormElement, selector: "cub-column-filter-form-element", inputs: ["field", "type", "filterConstraint", "filterTemplateRef", "placeholder", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }, { kind: "directive", type: CubPrefix, selector: "[cubPrefix]" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableFilterIcon, decorators: [{
            type: Component,
            args: [{ selector: 'cub-table-filter-icon', encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-table-filter-icon',
                        '(click)': '$event.stopPropagation()',
                        '(keydown)': '$event.stopPropagation()',
                        '(keyup)': '$event.stopPropagation()',
                    }, imports: [
                        CubDropDownTrigger,
                        CubDropDown,
                        CubDropDownGroup,
                        CubDropDownOption,
                        CubPopoverTrigger,
                        CubPopover,
                        NgTemplateOutlet,
                        CubColumnFilterFormElement,
                        CubButton,
                        CubIconButton,
                        CubPrefix,
                    ], template: "@if (display === \"dropdown\") {\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral\"\n    appearance=\"plain\"\n    [cubDropDownTriggerFor]=\"dropDown\"\n  >\n    <svg\n      width=\"16\"\n      height=\"24\"\n      viewBox=\"0 0 16 24\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n      class=\"cub-filterable-column-icon cub-icon-filter\"\n    >\n      <path\n        d=\"M7.77003 19C7.66824 19.0025 7.56701 18.9842 7.47247 18.9464C7.37793 18.9086 7.29206 18.852 7.22006 18.78C7.14807 18.708 7.09144 18.6221 7.05362 18.5275C7.01579 18.433 6.99756 18.3318 7.00003 18.23V12.65L1.60003 5.82999C1.54085 5.75286 1.50467 5.66059 1.49564 5.5638C1.48661 5.46701 1.50511 5.36964 1.549 5.2829C1.59289 5.19616 1.66039 5.12359 1.74373 5.07353C1.82706 5.02348 1.92284 4.99799 2.02003 4.99999H13.98C14.0772 4.99799 14.173 5.02348 14.2563 5.07353C14.3397 5.12359 14.4072 5.19616 14.4511 5.2829C14.495 5.36964 14.5134 5.46701 14.5044 5.5638C14.4954 5.66059 14.4592 5.75286 14.4 5.82999L9.00003 12.65V18.23C9.0025 18.3318 8.98427 18.433 8.94644 18.5275C8.90862 18.6221 8.85199 18.708 8.77999 18.78C8.708 18.852 8.62213 18.9086 8.52759 18.9464C8.43305 18.9842 8.33182 19.0025 8.23003 19H7.77003ZM8.00003 12.3L12.95 5.99999H3.05003L8.00003 12.3Z\"\n        fill=\"currentColor\"\n      />\n    </svg>\n  </button>\n\n  <cub-drop-down [size]=\"cubTable.size\" #dropDown>\n    <cub-drop-down-group\n      [value]=\"filterValue\"\n      [multiple]=\"true\"\n      (change)=\"onDropdownChange($event.value)\"\n    >\n      @for (item of options; track item.value) {\n        <button\n          cub-drop-down-option\n          [label]=\"item.label\"\n          [value]=\"item.value\"\n        ></button>\n      }\n    </cub-drop-down-group>\n  </cub-drop-down>\n} @else if (display === \"popover\") {\n  <!-- TODO\uFF1Apopover \u9032\u968E\u7BE9\u9078\u66AB\u4E0D\u4F7F\u7528\uFF0C\u5F85\u60C5\u5883\u5B8C\u5584\u5F8C\u512A\u5316 -->\n  <button\n    cub-icon-button\n    type=\"button\"\n    color=\"neutral\"\n    appearance=\"plain\"\n    [cubPopoverTriggerFor]=\"popover\"\n    [cubPopoverHasArrow]=\"false\"\n  >\n    <span class=\"cub-filterable-column-icon cub-icon-filter\"></span>\n  </button>\n\n  <cub-popover #popover=\"cubPopover\">\n    <ng-container\n      *ngTemplateOutlet=\"headerTemplateRef; context: { $implicit: field }\"\n    ></ng-container>\n    <cub-column-filter-form-element\n      [type]=\"type\"\n      [field]=\"field\"\n      [filterConstraint]=\"cubTable.filters[field]\"\n      [filterTemplateRef]=\"filterTemplateRef\"\n      [placeholder]=\"placeholder\"\n      [minFractionDigits]=\"minFractionDigits\"\n      [maxFractionDigits]=\"maxFractionDigits\"\n      [prefix]=\"prefix\"\n      [suffix]=\"suffix\"\n      [locale]=\"locale\"\n      [localeMatcher]=\"localeMatcher\"\n      [currency]=\"currency\"\n      [currencyDisplay]=\"currencyDisplay\"\n      [useGrouping]=\"useGrouping\"\n    ></cub-column-filter-form-element>\n\n    @if (isShowAddConstraint) {\n      <button\n        cub-button\n        type=\"button\"\n        appearance=\"plain\"\n        [block]=\"true\"\n        (click)=\"addConstraint()\"\n      >\n        <span cubPrefix class=\"cub-icon-plus\"></span>\n        {{ addRuleButtonLabel }}\n      </button>\n    }\n    <div class=\"cub-filter-buttonbar\">\n      @if (showClearButton) {\n        <button\n          cub-button\n          type=\"button\"\n          color=\"neutral\"\n          appearance=\"text\"\n          (click)=\"clearFilter()\"\n        >\n          {{ clearButtonLabel }}\n        </button>\n      }\n      @if (showApplyButton) {\n        <button\n          cub-button\n          type=\"button\"\n          color=\"brand\"\n          appearance=\"text\"\n          (click)=\"applyFilter()\"\n        >\n          {{ applyButtonLabel }}\n        </button>\n      }\n    </div>\n    <ng-container\n      *ngTemplateOutlet=\"footerTemplateRef; context: { $implicit: field }\"\n    ></ng-container>\n  </cub-popover>\n}\n" }]
        }], ctorParameters: () => [{ type: CubTable }, { type: i0.ElementRef }, { type: i2.TranslationConfig }, { type: i0.Renderer2 }], propDecorators: { field: [{
                type: Input
            }], matchMode: [{
                type: Input
            }], operator: [{
                type: Input
            }], type: [{
                type: Input
            }], options: [{
                type: Input
            }], filterCallback: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], minFractionDigits: [{
                type: Input
            }], maxFractionDigits: [{
                type: Input
            }], prefix: [{
                type: Input
            }], suffix: [{
                type: Input
            }], locale: [{
                type: Input
            }], localeMatcher: [{
                type: Input
            }], currency: [{
                type: Input
            }], currencyDisplay: [{
                type: Input
            }], useGrouping: [{
                type: Input
            }], icon: [{
                type: ViewChild,
                args: ['icon']
            }], templates: [{
                type: ContentChildren,
                args: [CubTemplate]
            }] } });

class CubTableRadio {
    constructor(cubTable, tableService, changeDetectorRef, elementRef, renderer) {
        this.cubTable = cubTable;
        this.tableService = tableService;
        this.changeDetectorRef = changeDetectorRef;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.subscription = this.cubTable.tableService.selectionSource$.subscribe(() => {
            this.checked = this.cubTable.isSelected(this.value);
            this.updateTrSelectedState();
            this.changeDetectorRef.markForCheck();
        });
    }
    ngOnInit() {
        this.checked = this.cubTable.isSelected(this.value);
        this.updateTrSelectedState();
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    onClick(event) {
        if (!this.disabled) {
            this.cubTable.toggleRowWithRadio({
                originalEvent: event.source,
                rowIndex: this.index,
            }, this.value);
        }
        DomHandler.clearSelection();
    }
    /* 勾選時在 tr 新增選取狀態 */
    updateTrSelectedState() {
        const parentNode = this.elementRef.nativeElement.parentNode.parentNode;
        if (this.checked) {
            this.renderer.addClass(parentNode, 'cub-selected');
        }
        else {
            this.renderer.removeClass(parentNode, 'cub-selected');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableRadio, deps: [{ token: CubTable }, { token: CubTableService }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTableRadio, isStandalone: true, selector: "cub-table-radio", inputs: { disabled: "disabled", value: "value", index: "index", inputId: "inputId", name: "name", ariaLabel: ["aria-label", "ariaLabel"] }, host: { classAttribute: "cub-table-radio" }, ngImport: i0, template: "<cub-radio\n  [id]=\"inputId\"\n  [name]=\"name\"\n  [checked]=\"checked\"\n  [disabled]=\"disabled\"\n  [aria-label]=\"ariaLabel\"\n  [size]=\"cubTable.size\"\n  (change)=\"onClick($event)\"\n></cub-radio>\n", styles: [""], dependencies: [{ kind: "component", type: CubRadio, selector: "cub-radio", inputs: ["disableRipple", "tabIndex", "size"], exportAs: ["cubRadio"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableRadio, decorators: [{
            type: Component,
            args: [{ selector: 'cub-table-radio', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-table-radio',
                    }, imports: [CubRadio], template: "<cub-radio\n  [id]=\"inputId\"\n  [name]=\"name\"\n  [checked]=\"checked\"\n  [disabled]=\"disabled\"\n  [aria-label]=\"ariaLabel\"\n  [size]=\"cubTable.size\"\n  (change)=\"onClick($event)\"\n></cub-radio>\n" }]
        }], ctorParameters: () => [{ type: CubTable }, { type: CubTableService }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { disabled: [{
                type: Input
            }], value: [{
                type: Input
            }], index: [{
                type: Input
            }], inputId: [{
                type: Input
            }], name: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }] } });

class CubTableCheckbox {
    constructor(cubTable, tableService, changeDetectorRef, elementRef, renderer) {
        this.cubTable = cubTable;
        this.tableService = tableService;
        this.changeDetectorRef = changeDetectorRef;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.subscription = this.cubTable.tableService.selectionSource$.subscribe(() => {
            if (this.disabled) {
                this.cubTable.deleteSelectionWhenCheckboxDisabled(this.value);
            }
            this.checked = this.cubTable.isSelected(this.value) && !this.disabled;
            this.updateTrSelectedState();
            this.changeDetectorRef.markForCheck();
        });
    }
    ngOnInit() {
        this.checked = this.cubTable.isSelected(this.value);
        this.updateTrSelectedState();
        if (this.disabled) {
            this.cubTable.disabledRowList.push(this.value);
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    onClick(event) {
        if (!this.disabled) {
            this.cubTable.toggleRowWithCheckbox({
                originalEvent: event.source,
                rowIndex: this.index,
            }, this.value);
        }
        DomHandler.clearSelection();
    }
    /* 勾選時在 tr 新增選取狀態 */
    updateTrSelectedState() {
        const parentNode = this.elementRef.nativeElement.parentNode.parentNode;
        if (this.checked) {
            this.renderer.addClass(parentNode, 'cub-selected');
        }
        else {
            this.renderer.removeClass(parentNode, 'cub-selected');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableCheckbox, deps: [{ token: CubTable }, { token: CubTableService }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTableCheckbox, isStandalone: true, selector: "cub-table-checkbox", inputs: { disabled: "disabled", value: "value", index: "index", inputId: "inputId", name: "name", required: "required", ariaLabel: ["aria-label", "ariaLabel"] }, host: { classAttribute: "cub-table-checkbox" }, ngImport: i0, template: "<cub-checkbox\n  [id]=\"inputId\"\n  [name]=\"name\"\n  [checked]=\"checked\"\n  [required]=\"required\"\n  [disabled]=\"disabled\"\n  [aria-label]=\"ariaLabel\"\n  [size]=\"cubTable.size\"\n  (change)=\"onClick($event)\"\n></cub-checkbox>\n", styles: [""], dependencies: [{ kind: "component", type: CubCheckbox, selector: "cub-checkbox", inputs: ["disableRipple", "tabIndex", "size"], exportAs: ["cubCheckbox"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableCheckbox, decorators: [{
            type: Component,
            args: [{ selector: 'cub-table-checkbox', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-table-checkbox',
                    }, imports: [CubCheckbox], template: "<cub-checkbox\n  [id]=\"inputId\"\n  [name]=\"name\"\n  [checked]=\"checked\"\n  [required]=\"required\"\n  [disabled]=\"disabled\"\n  [aria-label]=\"ariaLabel\"\n  [size]=\"cubTable.size\"\n  (change)=\"onClick($event)\"\n></cub-checkbox>\n" }]
        }], ctorParameters: () => [{ type: CubTable }, { type: CubTableService }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { disabled: [{
                type: Input
            }], value: [{
                type: Input
            }], index: [{
                type: Input
            }], inputId: [{
                type: Input
            }], name: [{
                type: Input
            }], required: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }] } });

class CubTableHeaderCheckbox {
    constructor(cubTable, tableService, changeDetectorRef) {
        this.cubTable = cubTable;
        this.tableService = tableService;
        this.changeDetectorRef = changeDetectorRef;
        this.valueChangeSubscription =
            this.cubTable.tableService.valueSource$.subscribe(() => {
                this.checked = this.updateCheckedState();
                this.indeterminate = this.updateIndeterminateState();
            });
        this.selectionChangeSubscription =
            this.cubTable.tableService.selectionSource$.subscribe(() => {
                this.checked = this.updateCheckedState();
                this.indeterminate = this.updateIndeterminateState();
            });
    }
    ngOnInit() {
        this.checked = this.updateCheckedState();
        this.indeterminate = this.updateIndeterminateState();
    }
    ngOnDestroy() {
        if (this.selectionChangeSubscription) {
            this.selectionChangeSubscription.unsubscribe();
        }
        if (this.valueChangeSubscription) {
            this.valueChangeSubscription.unsubscribe();
        }
    }
    onClick(event) {
        if (!this.disabled) {
            if (this.cubTable.value && this.cubTable.value.length > 0) {
                this.cubTable.toggleRowsWithCheckbox(event.source, !this.checked);
            }
        }
        DomHandler.clearSelection();
    }
    isDisabled() {
        return this.disabled || !this.cubTable.value || !this.cubTable.value.length;
    }
    updateCheckedState() {
        this.changeDetectorRef.markForCheck();
        if (this.cubTable._selectAll !== null) {
            return this.cubTable._selectAll;
        }
        else {
            const data = this.cubTable.selectionPageOnly
                ? this.cubTable.dataToRender(this.cubTable.processedData)
                : this.cubTable.processedData;
            const val = this.cubTable.frozenValue
                ? [...this.cubTable.frozenValue, ...data]
                : data;
            let selectableVal = this.cubTable.rowSelectable
                ? val.filter((data, index) => this.cubTable.rowSelectable({ data, index }))
                : val;
            if (this.cubTable.disabledRowList.length > 0) {
                selectableVal = selectableVal.filter((list) => !this.cubTable.disabledRowList.includes(list));
            }
            return (ObjectUtils.isNotEmpty(selectableVal) &&
                ObjectUtils.isNotEmpty(this.cubTable.selection) &&
                selectableVal.every((value) => this.cubTable.selection.some((selection) => this.cubTable.equals(value, selection))));
        }
    }
    updateIndeterminateState() {
        this.changeDetectorRef.markForCheck();
        if (this.checked) {
            return false;
        }
        else {
            const data = this.cubTable.selectionPageOnly
                ? this.cubTable.dataToRender(this.cubTable.processedData)
                : this.cubTable.processedData;
            const val = this.cubTable.frozenValue
                ? [...this.cubTable.frozenValue, ...data]
                : data;
            let selectableVal = this.cubTable.rowSelectable
                ? val.filter((data, index) => this.cubTable.rowSelectable({ data, index }))
                : val;
            if (this.cubTable.disabledRowList.length > 0) {
                selectableVal = selectableVal.filter((list) => !this.cubTable.disabledRowList.includes(list));
            }
            return (ObjectUtils.isNotEmpty(selectableVal) &&
                ObjectUtils.isNotEmpty(this.cubTable.selection) &&
                selectableVal.some((value) => this.cubTable.selection.some((selection) => this.cubTable.equals(value, selection))));
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableHeaderCheckbox, deps: [{ token: CubTable }, { token: CubTableService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTableHeaderCheckbox, isStandalone: true, selector: "cub-table-header-checkbox", inputs: { disabled: "disabled", inputId: "inputId", name: "name", ariaLabel: ["aria-label", "ariaLabel"] }, host: { classAttribute: "cub-table-checkbox" }, ngImport: i0, template: "<cub-checkbox\n  [id]=\"inputId\"\n  [name]=\"name\"\n  [checked]=\"checked\"\n  [indeterminate]=\"indeterminate\"\n  [disabled]=\"isDisabled()\"\n  [aria-label]=\"ariaLabel\"\n  [size]=\"cubTable.size\"\n  (change)=\"onClick($event)\"\n></cub-checkbox>\n", styles: [""], dependencies: [{ kind: "component", type: CubCheckbox, selector: "cub-checkbox", inputs: ["disableRipple", "tabIndex", "size"], exportAs: ["cubCheckbox"] }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableHeaderCheckbox, decorators: [{
            type: Component,
            args: [{ selector: 'cub-table-header-checkbox', changeDetection: ChangeDetectionStrategy.Default, encapsulation: ViewEncapsulation.None, host: {
                        class: 'cub-table-checkbox',
                    }, imports: [CubCheckbox], template: "<cub-checkbox\n  [id]=\"inputId\"\n  [name]=\"name\"\n  [checked]=\"checked\"\n  [indeterminate]=\"indeterminate\"\n  [disabled]=\"isDisabled()\"\n  [aria-label]=\"ariaLabel\"\n  [size]=\"cubTable.size\"\n  (change)=\"onClick($event)\"\n></cub-checkbox>\n" }]
        }], ctorParameters: () => [{ type: CubTable }, { type: CubTableService }, { type: i0.ChangeDetectorRef }], propDecorators: { disabled: [{
                type: Input
            }], inputId: [{
                type: Input
            }], name: [{
                type: Input
            }], ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }] } });

class CubRowGroupHeader {
    get getFrozenRowGroupHeaderStickyPosition() {
        return this.cubTable.rowGroupHeaderStyleObject
            ? this.cubTable.rowGroupHeaderStyleObject.top
            : '';
    }
    constructor(cubTable) {
        this.cubTable = cubTable;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRowGroupHeader, deps: [{ token: CubTable }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubRowGroupHeader, isStandalone: true, selector: "[cubRowGroupHeader]", host: { properties: { "style.top": "getFrozenRowGroupHeaderStickyPosition" }, classAttribute: "cub-rowgroup-header" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRowGroupHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubRowGroupHeader]',
                    host: {
                        class: 'cub-rowgroup-header',
                        '[style.top]': 'getFrozenRowGroupHeaderStickyPosition',
                    },
                }]
        }], ctorParameters: () => [{ type: CubTable }] });

const entriesMap = new WeakMap();
const resizeObserver = new ResizeObserver((entries) => {
    for (const entry of entries) {
        if (entriesMap.has(entry.target)) {
            const comp = entriesMap.get(entry.target);
            comp._resizeCallback(entry);
        }
    }
});
class CubFrozenColumn {
    /** 是否固定欄位，預設為 true。 */
    get frozen() {
        return this._frozen;
    }
    set frozen(val) {
        this._frozen = val;
        this.updateStickyPosition();
    }
    constructor(_renderer, elementRef, cubTable) {
        this._renderer = _renderer;
        this.elementRef = elementRef;
        this.cubTable = cubTable;
        this._frozen = true;
        this.afterViewInitFlag = false;
        this.borderFixing = false;
        /** 固定欄位的位置，有效值為 'left' 與 'right'，預設為 'left'。 */
        this.alignFrozen = 'left';
        const target = this.elementRef.nativeElement;
        entriesMap.set(target, this);
        resizeObserver.observe(target);
    }
    ngAfterViewInit() {
        this.afterViewInitFlag = true;
        this.updateStickyPosition();
        this.afterViewInitFlag = false;
    }
    ngOnDestroy() {
        const target = this.elementRef.nativeElement;
        resizeObserver.unobserve(target);
        entriesMap.delete(target);
    }
    _resizeCallback(entry) {
        if (!this.afterViewInitFlag) {
            this.updateStickyPosition();
            this.cubTable.tableService.onFrozenTriggerCheck();
        }
    }
    updateStickyPosition() {
        const target = this.elementRef.nativeElement;
        if (!target || !target.parentElement) {
            return;
        }
        /* 初始狀態 */
        if (target.classList.contains('cub-datatable-frozen-right-shadow')) {
            this._renderer.removeClass(target, 'cub-datatable-frozen-right-shadow');
        }
        /* 初始狀態 */
        if (target.classList.contains('cub-datatable-frozen-left-shadow')) {
            this._renderer.removeClass(target, 'cub-datatable-frozen-left-shadow');
        }
        if (this._frozen) {
            setTimeout(() => {
                if (this.alignFrozen === 'right') {
                    let right = 0;
                    const prev = target.previousElementSibling;
                    const next = target.nextElementSibling;
                    this.borderFixing =
                        target.parentElement?.parentElement?.classList.contains('cub-datatable-frozen-border-fixing') || false;
                    if (next) {
                        const siblingAfterWidth = this.getAllNextElementSiblingWidth(target);
                        const siblingAfterWidthSum = siblingAfterWidth?.reduce((partialSum, a) => partialSum + a, 0);
                        target.style.right = this.borderFixing
                            ? siblingAfterWidthSum + 1 + 'px'
                            : siblingAfterWidthSum + 'px';
                    }
                    else {
                        target.style.right = this.borderFixing
                            ? right + 1 + 'px'
                            : right + 'px';
                    }
                    /* 右邊第一個固定欄位顯示陰影 */
                    if (prev && !prev.classList.contains('cub-frozen-column')) {
                        this._renderer.addClass(target, 'cub-datatable-frozen-right-shadow');
                    }
                }
                else {
                    let left = 0;
                    const prev = target.previousElementSibling;
                    const next = target.nextElementSibling;
                    if (prev) {
                        left =
                            DomHandler.getOuterWidth(prev) +
                                (parseFloat(prev.style.left) || 0);
                    }
                    target.style.left = left + 'px';
                    /* 左邊最後一個固定欄位顯示陰影 */
                    if (next && !next.classList.contains('cub-frozen-column')) {
                        this._renderer.addClass(target, 'cub-datatable-frozen-left-shadow');
                    }
                }
            }, 0);
        }
    }
    getAllNextElementSiblingWidth(element) {
        if (!element || !element.parentNode) {
            return;
        }
        const sibling = [...element.parentNode['children']];
        const index = sibling.indexOf(element);
        const siblingAfter = sibling.slice(index + 1);
        const siblingAfterWidth = siblingAfter.map((next) => {
            return DomHandler.getOuterWidth(next);
        });
        return siblingAfterWidth;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFrozenColumn, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: CubTable }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubFrozenColumn, isStandalone: true, selector: "[cubFrozenColumn]", inputs: { frozen: "frozen", alignFrozen: "alignFrozen" }, host: { properties: { "class.cub-frozen-column": "frozen" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubFrozenColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubFrozenColumn]',
                    host: {
                        '[class.cub-frozen-column]': 'frozen',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: CubTable }], propDecorators: { frozen: [{
                type: Input
            }], alignFrozen: [{
                type: Input
            }] } });

class CubSortableColumn {
    onClick(event) {
        if (this.isEnabled() && !this.isFilterElement(event.target)) {
            this.updateSortState();
            this.cubTable.onSort({
                originalEvent: event,
                field: this.field,
            });
            DomHandler.clearSelection();
        }
    }
    onEnterKey(event) {
        this.onClick(event);
    }
    constructor(cubTable) {
        this.cubTable = cubTable;
        if (this.isEnabled()) {
            this.subscription = this.cubTable.tableService.sortSource$.subscribe((sortMeta) => {
                this.updateSortState();
            });
        }
    }
    ngOnInit() {
        if (this.isEnabled()) {
            this.updateSortState();
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    updateSortState() {
        this.sorted = this.cubTable.isSorted(this.field);
        this.sortOrder = this.sorted
            ? this.cubTable.sortOrder === 1
                ? 'ascending'
                : 'descending'
            : 'none';
    }
    isEnabled() {
        return this.disabled !== true;
    }
    isFilterElement(element) {
        return DomHandler.hasClass(element, 'cub-filter-icon');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSortableColumn, deps: [{ token: CubTable }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSortableColumn, isStandalone: true, selector: "[cubSortableColumn]", inputs: { field: ["cubSortableColumn", "field"], disabled: ["cubSortableColumnDisabled", "disabled"] }, host: { listeners: { "click": "onClick($event)", "keydown.enter": "onEnterKey($event)" }, properties: { "class.cub-sortable-column": "isEnabled()", "class.cub-highlight": "sorted", "attr.tabindex": "isEnabled() ? \"0\" : null", "attr.role": "\"columnheader\"", "attr.aria-sort": "sortOrder" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSortableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubSortableColumn]',
                    host: {
                        '[class.cub-sortable-column]': 'isEnabled()',
                        '[class.cub-highlight]': 'sorted',
                        '[attr.tabindex]': 'isEnabled() ? "0" : null',
                        '[attr.role]': '"columnheader"',
                        '[attr.aria-sort]': 'sortOrder',
                    },
                }]
        }], ctorParameters: () => [{ type: CubTable }], propDecorators: { field: [{
                type: Input,
                args: ['cubSortableColumn']
            }], disabled: [{
                type: Input,
                args: ['cubSortableColumnDisabled']
            }], onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onEnterKey: [{
                type: HostListener,
                args: ['keydown.enter', ['$event']]
            }] } });

class CubSelectableRow {
    onClick(event) {
        if (this.isEnabled()) {
            this.cubTable.handleRowClick({
                originalEvent: event,
                rowData: this.data,
                rowIndex: this.index,
            });
        }
    }
    onTouchEnd(event) {
        if (this.isEnabled()) {
            this.cubTable.handleRowTouchEnd(event);
        }
    }
    onArrowDownKeyDown(event) {
        if (!this.isEnabled()) {
            return;
        }
        const row = event.currentTarget;
        const nextRow = this.findNextSelectableRow(row);
        if (nextRow) {
            nextRow.focus();
        }
        event.preventDefault();
    }
    onArrowUpKeyDown(event) {
        if (!this.isEnabled()) {
            return;
        }
        const row = event.currentTarget;
        const prevRow = this.findPrevSelectableRow(row);
        if (prevRow) {
            prevRow.focus();
        }
        event.preventDefault();
    }
    onEnterKeyDown(event) {
        if (!this.isEnabled()) {
            return;
        }
        this.cubTable.handleRowClick({
            originalEvent: event,
            rowData: this.data,
            rowIndex: this.index,
        });
    }
    onPageDownKeyDown() {
        if (this.cubTable.virtualScroll) {
            this.cubTable.scroller.elementViewChild.nativeElement.focus();
        }
    }
    onSpaceKeydown() {
        if (this.cubTable.virtualScroll && !this.cubTable.editingCell) {
            this.cubTable.scroller.elementViewChild.nativeElement.focus();
        }
    }
    constructor(cubTable, tableService) {
        this.cubTable = cubTable;
        this.tableService = tableService;
        if (this.isEnabled()) {
            this.subscription = this.cubTable.tableService.selectionSource$.subscribe(() => {
                this.selected = this.cubTable.isSelected(this.data);
            });
        }
    }
    ngOnInit() {
        if (this.isEnabled()) {
            this.selected = this.cubTable.isSelected(this.data);
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    findNextSelectableRow(row) {
        let nextRow = row.nextElementSibling;
        if (nextRow) {
            if (DomHandler.hasClass(nextRow, 'cub-selectable-row'))
                return nextRow;
            else
                return this.findNextSelectableRow(nextRow);
        }
        else {
            return null;
        }
    }
    findPrevSelectableRow(row) {
        let prevRow = row.previousElementSibling;
        if (prevRow) {
            if (DomHandler.hasClass(prevRow, 'cub-selectable-row'))
                return prevRow;
            else
                return this.findPrevSelectableRow(prevRow);
        }
        else {
            return null;
        }
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableRow, deps: [{ token: CubTable }, { token: CubTableService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSelectableRow, isStandalone: true, selector: "[cubSelectableRow]", inputs: { data: ["cubSelectableRow", "data"], index: ["cubSelectableRowIndex", "index"], disabled: ["cubSelectableRowDisabled", "disabled"] }, host: { listeners: { "click": "onClick($event)", "touchend": "onTouchEnd($event)", "keydown.arrowdown": "onArrowDownKeyDown($event)", "keydown.arrowup": "onArrowUpKeyDown($event)", "keydown.enter": "onEnterKeyDown($event)", "keydown.shift.enter": "onEnterKeyDown($event)", "keydown.meta.enter": "onEnterKeyDown($event)", "keydown.pagedown": "onPageDownKeyDown()", "keydown.pageup": "onPageDownKeyDown()", "keydown.home": "onPageDownKeyDown()", "keydown.end": "onPageDownKeyDown()", "keydown.space": "onSpaceKeydown()" }, properties: { "class.cub-selectable-row": "isEnabled()", "class.cub-highlight": "selected", "attr.tabindex": "isEnabled() ? 0 : undefined" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubSelectableRow]',
                    host: {
                        '[class.cub-selectable-row]': 'isEnabled()',
                        '[class.cub-highlight]': 'selected',
                        '[attr.tabindex]': 'isEnabled() ? 0 : undefined',
                    },
                }]
        }], ctorParameters: () => [{ type: CubTable }, { type: CubTableService }], propDecorators: { data: [{
                type: Input,
                args: ['cubSelectableRow']
            }], index: [{
                type: Input,
                args: ['cubSelectableRowIndex']
            }], disabled: [{
                type: Input,
                args: ['cubSelectableRowDisabled']
            }], onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onTouchEnd: [{
                type: HostListener,
                args: ['touchend', ['$event']]
            }], onArrowDownKeyDown: [{
                type: HostListener,
                args: ['keydown.arrowdown', ['$event']]
            }], onArrowUpKeyDown: [{
                type: HostListener,
                args: ['keydown.arrowup', ['$event']]
            }], onEnterKeyDown: [{
                type: HostListener,
                args: ['keydown.enter', ['$event']]
            }, {
                type: HostListener,
                args: ['keydown.shift.enter', ['$event']]
            }, {
                type: HostListener,
                args: ['keydown.meta.enter', ['$event']]
            }], onPageDownKeyDown: [{
                type: HostListener,
                args: ['keydown.pagedown']
            }, {
                type: HostListener,
                args: ['keydown.pageup']
            }, {
                type: HostListener,
                args: ['keydown.home']
            }, {
                type: HostListener,
                args: ['keydown.end']
            }], onSpaceKeydown: [{
                type: HostListener,
                args: ['keydown.space']
            }] } });

class CubSelectableRowDoubleClick {
    onClick(event) {
        if (this.isEnabled()) {
            this.cubTable.handleRowClick({
                originalEvent: event,
                rowData: this.data,
                rowIndex: this.index,
            });
        }
    }
    constructor(cubTable, tableService) {
        this.cubTable = cubTable;
        this.tableService = tableService;
        if (this.isEnabled()) {
            this.subscription = this.cubTable.tableService.selectionSource$.subscribe(() => {
                this.selected = this.cubTable.isSelected(this.data);
            });
        }
    }
    ngOnInit() {
        if (this.isEnabled()) {
            this.selected = this.cubTable.isSelected(this.data);
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableRowDoubleClick, deps: [{ token: CubTable }, { token: CubTableService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubSelectableRowDoubleClick, isStandalone: true, selector: "[cubSelectableRowDoubleClick]", inputs: { data: ["cubSelectableRowDblClick", "data"], index: ["cubSelectableRowIndex", "index"], disabled: ["cubSelectableRowDisabled", "disabled"] }, host: { listeners: { "dblclick": "onClick($event)" }, properties: { "class.cub-selectable-row": "isEnabled()", "class.cub-highlight": "selected" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubSelectableRowDoubleClick, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubSelectableRowDoubleClick]',
                    host: {
                        '[class.cub-selectable-row]': 'isEnabled()',
                        '[class.cub-highlight]': 'selected',
                    },
                }]
        }], ctorParameters: () => [{ type: CubTable }, { type: CubTableService }], propDecorators: { data: [{
                type: Input,
                args: ['cubSelectableRowDblClick']
            }], index: [{
                type: Input,
                args: ['cubSelectableRowIndex']
            }], disabled: [{
                type: Input,
                args: ['cubSelectableRowDisabled']
            }], onClick: [{
                type: HostListener,
                args: ['dblclick', ['$event']]
            }] } });

class CubRowToggler {
    constructor(cubTable, elementRef, renderer) {
        this.cubTable = cubTable;
        this.elementRef = elementRef;
        this.renderer = renderer;
    }
    ngAfterViewInit() {
        const icon = this.renderer.createElement('span');
        this.renderer.addClass(icon, 'cub-icon-chevron-down');
        this.renderer.addClass(icon, 'cub-row-toggler-icon');
        this.renderer.appendChild(this.elementRef.nativeElement, icon);
        const parentNode = this.elementRef.nativeElement.parentNode.parentNode;
        if (!!parentNode) {
            this.renderer.addClass(parentNode, 'cub-row-expanded');
        }
    }
    toggleRow(event) {
        if (this.isEnabled()) {
            this.cubTable.toggleRow(this.data, event);
            event.preventDefault();
        }
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRowToggler, deps: [{ token: CubTable }, { token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubRowToggler, isStandalone: true, selector: "[cubRowToggler]", inputs: { data: ["cubRowToggler", "data"], expanded: ["cubRowTogglerExpanded", "expanded"], disabled: ["cubRowTogglerDisabled", "disabled"] }, host: { attributes: { "tabindex": "0" }, listeners: { "click": "toggleRow($event)", "keydown.enter": "toggleRow($event)" }, properties: { "class.cub-row-toggler-expanded": "!!expanded" }, classAttribute: "cub-row-toggler" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubRowToggler, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubRowToggler]',
                    host: {
                        class: 'cub-row-toggler',
                        '[class.cub-row-toggler-expanded]': '!!expanded',
                        tabindex: '0',
                        '(click)': 'toggleRow($event)',
                        '(keydown.enter)': 'toggleRow($event)',
                    }
                }]
        }], ctorParameters: () => [{ type: CubTable }, { type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { data: [{
                type: Input,
                args: ['cubRowToggler']
            }], expanded: [{
                type: Input,
                args: ['cubRowTogglerExpanded']
            }], disabled: [{
                type: Input,
                args: ['cubRowTogglerDisabled']
            }] } });

class CubResizableColumn {
    constructor(cubTable, elementRef, zone) {
        this.cubTable = cubTable;
        this.elementRef = elementRef;
        this.zone = zone;
    }
    ngAfterViewInit() {
        if (this.isEnabled()) {
            DomHandler.addClass(this.elementRef.nativeElement, 'cub-resizable-column');
            this.resizer = document.createElement('span');
            this.resizer.className = 'cub-column-resizer';
            this.elementRef.nativeElement.appendChild(this.resizer);
            this.zone.runOutsideAngular(() => {
                this.resizerMouseDownListener = this.onMouseDown.bind(this);
                this.resizer.addEventListener('mousedown', this.resizerMouseDownListener);
            });
        }
    }
    ngOnDestroy() {
        if (this.resizerMouseDownListener) {
            this.resizer.removeEventListener('mousedown', this.resizerMouseDownListener);
        }
        this.unbindDocumentEvents();
    }
    bindDocumentEvents() {
        this.zone.runOutsideAngular(() => {
            this.documentMouseMoveListener = this.onDocumentMouseMove.bind(this);
            document.addEventListener('mousemove', this.documentMouseMoveListener);
            this.documentMouseUpListener = this.onDocumentMouseUp.bind(this);
            document.addEventListener('mouseup', this.documentMouseUpListener);
        });
    }
    unbindDocumentEvents() {
        if (this.documentMouseMoveListener) {
            document.removeEventListener('mousemove', this.documentMouseMoveListener);
            this.documentMouseMoveListener = null;
        }
        if (this.documentMouseUpListener) {
            document.removeEventListener('mouseup', this.documentMouseUpListener);
            this.documentMouseUpListener = null;
        }
    }
    onMouseDown(event) {
        if (event.which === 1) {
            this.cubTable.onColumnResizeBegin(event);
            this.bindDocumentEvents();
        }
    }
    onDocumentMouseMove(event) {
        this.cubTable.onColumnResize(event);
    }
    onDocumentMouseUp(event) {
        this.cubTable.onColumnResizeEnd();
        this.unbindDocumentEvents();
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResizableColumn, deps: [{ token: CubTable }, { token: i0.ElementRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubResizableColumn, isStandalone: true, selector: "[cubResizableColumn]", inputs: { disabled: ["cubResizableColumnDisabled", "disabled"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubResizableColumn, decorators: [{
            type: Directive,
            args: [{ selector: '[cubResizableColumn]', }]
        }], ctorParameters: () => [{ type: CubTable }, { type: i0.ElementRef }, { type: i0.NgZone }], propDecorators: { disabled: [{
                type: Input,
                args: ['cubResizableColumnDisabled']
            }] } });

class CubReorderableColumn {
    onDrop(event) {
        if (this.isEnabled()) {
            this.cubTable.onColumnDrop(event, this.elementRef.nativeElement);
        }
    }
    constructor(cubTable, elementRef, zone) {
        this.cubTable = cubTable;
        this.elementRef = elementRef;
        this.zone = zone;
    }
    ngAfterViewInit() {
        if (this.isEnabled()) {
            this.bindEvents();
        }
    }
    ngOnDestroy() {
        this.unbindEvents();
    }
    bindEvents() {
        this.zone.runOutsideAngular(() => {
            this.mouseDownListener = this.onMouseDown.bind(this);
            this.elementRef.nativeElement.addEventListener('mousedown', this.mouseDownListener);
            this.dragStartListener = this.onDragStart.bind(this);
            this.elementRef.nativeElement.addEventListener('dragstart', this.dragStartListener);
            this.dragOverListener = this.onDragOver.bind(this);
            this.elementRef.nativeElement.addEventListener('dragover', this.dragOverListener);
            this.dragEnterListener = this.onDragEnter.bind(this);
            this.elementRef.nativeElement.addEventListener('dragenter', this.dragEnterListener);
            this.dragLeaveListener = this.onDragLeave.bind(this);
            this.elementRef.nativeElement.addEventListener('dragleave', this.dragLeaveListener);
        });
    }
    unbindEvents() {
        if (this.mouseDownListener) {
            this.elementRef.nativeElement.removeEventListener('mousedown', this.mouseDownListener);
            this.mouseDownListener = null;
        }
        if (this.dragOverListener) {
            this.elementRef.nativeElement.removeEventListener('dragover', this.dragOverListener);
            this.dragOverListener = null;
        }
        if (this.dragStartListener) {
            this.elementRef.nativeElement.removeEventListener('dragstart', this.dragStartListener);
            this.dragStartListener = null;
        }
        if (this.dragEnterListener) {
            this.elementRef.nativeElement.removeEventListener('dragenter', this.dragEnterListener);
            this.dragEnterListener = null;
        }
        if (this.dragLeaveListener) {
            this.elementRef.nativeElement.removeEventListener('dragleave', this.dragLeaveListener);
            this.dragLeaveListener = null;
        }
    }
    onMouseDown(event) {
        if (event.target.nodeName === 'INPUT' ||
            event.target.nodeName === 'TEXTAREA' ||
            DomHandler.hasClass(event.target, 'cub-column-resizer'))
            this.elementRef.nativeElement.draggable = false;
        else
            this.elementRef.nativeElement.draggable = true;
    }
    onDragStart(event) {
        this.cubTable.onColumnDragStart(event, this.elementRef.nativeElement);
    }
    onDragOver(event) {
        event.preventDefault();
    }
    onDragEnter(event) {
        this.cubTable.onColumnDragEnter(event, this.elementRef.nativeElement);
    }
    onDragLeave(event) {
        this.cubTable.onColumnDragLeave(event);
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubReorderableColumn, deps: [{ token: CubTable }, { token: i0.ElementRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubReorderableColumn, isStandalone: true, selector: "[cubReorderableColumn]", inputs: { disabled: ["cubReorderableColumnDisabled", "disabled"] }, host: { listeners: { "drop": "onDrop($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubReorderableColumn, decorators: [{
            type: Directive,
            args: [{ selector: '[cubReorderableColumn]', }]
        }], ctorParameters: () => [{ type: CubTable }, { type: i0.ElementRef }, { type: i0.NgZone }], propDecorators: { disabled: [{
                type: Input,
                args: ['cubReorderableColumnDisabled']
            }], onDrop: [{
                type: HostListener,
                args: ['drop', ['$event']]
            }] } });

class CubDraggableRowHandle {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDraggableRowHandle, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDraggableRowHandle, isStandalone: true, selector: "[cubDraggableRowHandle]", host: { classAttribute: "cub-draggable-row-handle cub-icon-grip-dots" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDraggableRowHandle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubDraggableRowHandle]',
                    host: {
                        class: 'cub-draggable-row-handle cub-icon-grip-dots',
                    }
                }]
        }], ctorParameters: () => [] });

class CubDraggableRow {
    onDrop(event) {
        if (this.isEnabled() && this.cubTable.rowDragging) {
            this.cubTable.onRowDrop(event, this.elementRef.nativeElement);
        }
        event.preventDefault();
    }
    constructor(cubTable, elementRef, zone) {
        this.cubTable = cubTable;
        this.elementRef = elementRef;
        this.zone = zone;
    }
    ngAfterViewInit() {
        if (this.isEnabled()) {
            this.elementRef.nativeElement.droppable = true;
            this.bindEvents();
        }
    }
    ngOnDestroy() {
        this.unbindEvents();
    }
    bindEvents() {
        this.zone.runOutsideAngular(() => {
            this.mouseDownListener = this.onMouseDown.bind(this);
            this.elementRef.nativeElement.addEventListener('mousedown', this.mouseDownListener);
            this.dragStartListener = this.onDragStart.bind(this);
            this.elementRef.nativeElement.addEventListener('dragstart', this.dragStartListener);
            this.dragEndListener = this.onDragEnd.bind(this);
            this.elementRef.nativeElement.addEventListener('dragend', this.dragEndListener);
            this.dragOverListener = this.onDragOver.bind(this);
            this.elementRef.nativeElement.addEventListener('dragover', this.dragOverListener);
            this.dragLeaveListener = this.onDragLeave.bind(this);
            this.elementRef.nativeElement.addEventListener('dragleave', this.dragLeaveListener);
        });
    }
    unbindEvents() {
        if (this.mouseDownListener) {
            this.elementRef.nativeElement.removeEventListener('mousedown', this.mouseDownListener);
            this.mouseDownListener = null;
        }
        if (this.dragStartListener) {
            this.elementRef.nativeElement.removeEventListener('dragstart', this.dragStartListener);
            this.dragStartListener = null;
        }
        if (this.dragEndListener) {
            this.elementRef.nativeElement.removeEventListener('dragend', this.dragEndListener);
            this.dragEndListener = null;
        }
        if (this.dragOverListener) {
            this.elementRef.nativeElement.removeEventListener('dragover', this.dragOverListener);
            this.dragOverListener = null;
        }
        if (this.dragLeaveListener) {
            this.elementRef.nativeElement.removeEventListener('dragleave', this.dragLeaveListener);
            this.dragLeaveListener = null;
        }
    }
    onMouseDown(event) {
        if (DomHandler.hasClass(event.target, 'cub-draggable-row-handle')) {
            this.elementRef.nativeElement.draggable = true;
        }
        else {
            this.elementRef.nativeElement.draggable = false;
        }
    }
    onDragStart(event) {
        this.cubTable.onRowDragStart(event, this.index);
    }
    onDragEnd(event) {
        this.cubTable.onRowDragEnd(event);
        this.elementRef.nativeElement.draggable = false;
    }
    onDragOver(event) {
        this.cubTable.onRowDragOver(event, this.index, this.elementRef.nativeElement);
        event.preventDefault();
    }
    onDragLeave(event) {
        this.cubTable.onRowDragLeave(event, this.elementRef.nativeElement);
    }
    isEnabled() {
        return this.disabled !== true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDraggableRow, deps: [{ token: CubTable }, { token: i0.ElementRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubDraggableRow, isStandalone: true, selector: "[cubDraggableRow]", inputs: { index: ["cubDraggableRow", "index"], disabled: ["cubDraggableRowDisabled", "disabled"] }, host: { listeners: { "drop": "onDrop($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubDraggableRow, decorators: [{
            type: Directive,
            args: [{ selector: '[cubDraggableRow]', }]
        }], ctorParameters: () => [{ type: CubTable }, { type: i0.ElementRef }, { type: i0.NgZone }], propDecorators: { index: [{
                type: Input,
                args: ['cubDraggableRow']
            }], disabled: [{
                type: Input,
                args: ['cubDraggableRowDisabled']
            }], onDrop: [{
                type: HostListener,
                args: ['drop', ['$event']]
            }] } });

class CubTableFrozenFixer {
    constructor(elementRef, _renderer, cubTable) {
        this.elementRef = elementRef;
        this._renderer = _renderer;
        this.cubTable = cubTable;
        this.subscription =
            this.cubTable.tableService.frozenTriggerCheck$.subscribe(() => {
                this.targetTable = this.elementRef.nativeElement.querySelector('table.cub-datatable-table');
                const theadTrList = this.targetTable.querySelectorAll('thead tr');
                const tbodyTrList = this.targetTable.querySelectorAll('tbody tr');
                setTimeout(() => {
                    this.fixTheadAlignLeft(theadTrList);
                    this.fixTbodyAlignLeft(tbodyTrList);
                    this.fixTheadAlignRight(theadTrList);
                    this.fixTbodyAlignRight(tbodyTrList);
                }, 0);
            });
    }
    ngAfterViewInit() { }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    // 修復左側表頭固定欄位
    fixTheadAlignLeft(theadList) {
        let trListOnlyLeftFrozenTh = this.createTrListOnlyLeftFrozenTh(theadList);
        // mapping 紀錄視覺上表格欄位是否被合併
        // 0 代表沒有欄位
        // 1 代表有欄位
        let mergeStatusEveryTr = [];
        // 初始化 mapping，根據第一列欄位數，先將每一列陣列全填1
        trListOnlyLeftFrozenTh.forEach((tr, rowIndex, array) => {
            mergeStatusEveryTr.push([]);
            trListOnlyLeftFrozenTh[0].forEach((firstTrth) => {
                mergeStatusEveryTr[rowIndex].push(1);
            });
        });
        // 檢查每欄的 rowspan 值，並將因此被合併的欄位 mapping 值改為 0
        for (let rowIndex = 0; rowIndex < trListOnlyLeftFrozenTh.length; rowIndex++) {
            // 紀錄未被合併的 flag 視覺上的 Index 為多少用的 flag
            let trueIndexFlag = 0;
            for (let thIndex = 0; thIndex < trListOnlyLeftFrozenTh[rowIndex].length; thIndex++) {
                if (trListOnlyLeftFrozenTh[rowIndex][thIndex].rowSpan > 1) {
                    // 因 tr 陣列內不會有被合併的欄位，因此參照 mapping ，若此列有被合併，尋找第一個未被合併的欄位
                    if (mergeStatusEveryTr[rowIndex][thIndex] === 0) {
                        trueIndexFlag = mergeStatusEveryTr[rowIndex].findIndex((element, index, array) => element === 1 && index > trueIndexFlag);
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyLeftFrozenTh[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][trueIndexFlag] = 0;
                            }
                            rowCount++;
                        }
                    }
                    else {
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyLeftFrozenTh[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][thIndex] = 0;
                            }
                            rowCount++;
                        }
                    }
                }
            }
        }
        for (let mergeRowIndex = 1; mergeRowIndex < mergeStatusEveryTr.length; mergeRowIndex++) {
            let thCounting = 0;
            for (let thIndex = 0; thIndex < mergeStatusEveryTr[mergeRowIndex].length; thIndex++) {
                if (mergeStatusEveryTr[mergeRowIndex][thIndex] === 1) {
                    trListOnlyLeftFrozenTh[mergeRowIndex][thCounting].style.left =
                        trListOnlyLeftFrozenTh[0][thIndex].style.left;
                    thCounting++;
                }
            }
            // 非視覺上的最後一欄要移除陰影
            const lastIndex = mergeStatusEveryTr[mergeRowIndex].length - 1;
            const hasShadowIndex = mergeStatusEveryTr[mergeRowIndex].lastIndexOf(1);
            if (hasShadowIndex !== lastIndex) {
                this._renderer.removeClass(trListOnlyLeftFrozenTh[mergeRowIndex][0], 'cub-datatable-frozen-left-shadow');
            }
        }
    }
    // 修復左側內容固定欄位
    fixTbodyAlignLeft(tbodyList) {
        let trListOnlyLeftFrozentd = this.createTrListOnlyLeftFrozenTd(tbodyList);
        // mapping 紀錄視覺上表格欄位是否被合併
        // 0 代表沒有欄位
        // 1 代表有欄位
        let mergeStatusEveryTr = [];
        // 初始化 mapping，根據第一列欄位數，先將每一列陣列全填1
        trListOnlyLeftFrozentd.forEach((tr, rowIndex, array) => {
            mergeStatusEveryTr.push([]);
            trListOnlyLeftFrozentd[0].forEach((firstTrth) => {
                mergeStatusEveryTr[rowIndex].push(1);
            });
        });
        // 檢查每欄的 rowspan 值，並將因此被合併的欄位 mapping 值改為 0
        for (let rowIndex = 0; rowIndex < trListOnlyLeftFrozentd.length; rowIndex++) {
            // 紀錄未被合併的 flag 視覺上的 Index 為多少用的 flag
            let trueIndexFlag = 0;
            for (let thIndex = 0; thIndex < trListOnlyLeftFrozentd[rowIndex].length; thIndex++) {
                if (trListOnlyLeftFrozentd[rowIndex][thIndex].rowSpan > 1) {
                    // 因 tr 陣列內不會有被合併的欄位，因此參照 mapping ，若此列有被合併，尋找第一個未被合併的欄位
                    if (mergeStatusEveryTr[rowIndex][thIndex] === 0) {
                        trueIndexFlag = mergeStatusEveryTr[rowIndex].findIndex((element, index, array) => element === 1 && index > trueIndexFlag);
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyLeftFrozentd[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][trueIndexFlag] = 0;
                            }
                            rowCount++;
                        }
                    }
                    else {
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyLeftFrozentd[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][thIndex] = 0;
                            }
                            rowCount++;
                        }
                    }
                }
            }
        }
        for (let mergeRowIndex = 1; mergeRowIndex < mergeStatusEveryTr.length; mergeRowIndex++) {
            let thCounting = 0;
            for (let thIndex = 0; thIndex < mergeStatusEveryTr[mergeRowIndex].length; thIndex++) {
                if (mergeStatusEveryTr[mergeRowIndex][thIndex] === 1) {
                    trListOnlyLeftFrozentd[mergeRowIndex][thCounting].style.left =
                        trListOnlyLeftFrozentd[0][thIndex].style.left;
                    thCounting++;
                }
            }
            // 非視覺上的最後一欄要移除陰影
            const lastIndex = mergeStatusEveryTr[mergeRowIndex].length - 1;
            const hasShadowIndex = mergeStatusEveryTr[mergeRowIndex].lastIndexOf(1);
            if (hasShadowIndex !== lastIndex) {
                this._renderer.removeClass(trListOnlyLeftFrozentd[mergeRowIndex][0], 'cub-datatable-frozen-left-shadow');
            }
        }
    }
    // 建立左側表頭固定欄位陣列
    createTrListOnlyLeftFrozenTh(theadList) {
        let list = [];
        for (let index = 0; index < theadList.length; index++) {
            list.push(theadList[index].querySelectorAll('.cub-frozen-column:not([alignfrozen="right"])'));
        }
        return list;
    }
    // 建立左側內容固定欄位陣列
    createTrListOnlyLeftFrozenTd(tbodyList) {
        let list = [];
        for (let index = 0; index < tbodyList.length; index++) {
            list.push(tbodyList[index].querySelectorAll('.cub-frozen-column:not([alignfrozen="right"])'));
        }
        return list;
    }
    //修復右側表頭固定欄位
    fixTheadAlignRight(theadList) {
        let trListOnlyRightFrozenTh = this.createTrListOnlyRightFrozenTh(theadList);
        // mapping 紀錄視覺上表格欄位是否被合併
        // 0 代表沒有欄位
        // 1 代表有欄位
        let mergeStatusEveryTr = [];
        // 初始化 mapping，根據第一列欄位數，先將每一列陣列全填1
        trListOnlyRightFrozenTh.forEach((tr, rowIndex, array) => {
            mergeStatusEveryTr.push([]);
            trListOnlyRightFrozenTh[0].forEach((firstTrth) => {
                mergeStatusEveryTr[rowIndex].push(1);
            });
        });
        // 檢查每欄的 rowspan 值，並將因此被合併的欄位 mapping 值改為 0
        for (let rowIndex = 0; rowIndex < trListOnlyRightFrozenTh.length; rowIndex++) {
            // 紀錄未被合併的 flag 視覺上的 Index 為多少用的 flag
            let trueIndexFlag = 0;
            for (let thIndex = 0; thIndex < trListOnlyRightFrozenTh[rowIndex].length; thIndex++) {
                if (trListOnlyRightFrozenTh[rowIndex][thIndex].rowSpan > 1) {
                    // 因 tr 陣列內不會有被合併的欄位，因此參照 mapping ，若此列有被合併，尋找第一個未被合併的欄位
                    if (mergeStatusEveryTr[rowIndex][thIndex] === 0) {
                        trueIndexFlag = mergeStatusEveryTr[rowIndex].findIndex((element, index, array) => element === 1 && index > trueIndexFlag);
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyRightFrozenTh[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][trueIndexFlag] = 0;
                            }
                            rowCount++;
                        }
                    }
                    else {
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyRightFrozenTh[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][thIndex] = 0;
                            }
                            rowCount++;
                        }
                    }
                }
            }
        }
        for (let mergeRowIndex = 1; mergeRowIndex < mergeStatusEveryTr.length; mergeRowIndex++) {
            let thCounting = 0;
            for (let thIndex = 0; thIndex < mergeStatusEveryTr[mergeRowIndex].length; thIndex++) {
                if (mergeStatusEveryTr[mergeRowIndex][thIndex] === 1) {
                    // 如果右方欄位是被合併的，要將右方邊線加回來
                    if (thCounting === 0) {
                        trListOnlyRightFrozenTh[mergeRowIndex][thCounting].style.borderRightWidth = '1px';
                    }
                    trListOnlyRightFrozenTh[mergeRowIndex][thCounting].style.right =
                        trListOnlyRightFrozenTh[0][thIndex].style.right;
                    thCounting++;
                }
            }
            // 非視覺上的第一欄要移除陰影
            const hasShadowIndex = mergeStatusEveryTr[mergeRowIndex].indexOf(1);
            if (hasShadowIndex !== 0) {
                this._renderer.removeClass(trListOnlyRightFrozenTh[mergeRowIndex][0], 'cub-datatable-frozen-right-shadow');
            }
        }
    }
    //修復右側內容固定欄位
    fixTbodyAlignRight(tbodyList) {
        let trListOnlyRightFrozenTd = this.createTrListOnlyRightFrozenTd(tbodyList);
        // mapping 紀錄視覺上表格欄位是否被合併
        // 0 代表沒有欄位
        // 1 代表有欄位
        let mergeStatusEveryTr = [];
        // 初始化 mapping，根據第一列欄位數，先將每一列陣列全填1
        trListOnlyRightFrozenTd.forEach((tr, rowIndex, array) => {
            mergeStatusEveryTr.push([]);
            trListOnlyRightFrozenTd[0].forEach((firstTrth) => {
                mergeStatusEveryTr[rowIndex].push(1);
            });
        });
        // 檢查每欄的 rowspan 值，並將因此被合併的欄位 mapping 值改為 0
        for (let rowIndex = 0; rowIndex < trListOnlyRightFrozenTd.length; rowIndex++) {
            // 紀錄未被合併的 flag 視覺上的 Index 為多少用的 flag
            let trueIndexFlag = 0;
            for (let thIndex = 0; thIndex < trListOnlyRightFrozenTd[rowIndex].length; thIndex++) {
                if (trListOnlyRightFrozenTd[rowIndex][thIndex].rowSpan > 1) {
                    // 因 tr 陣列內不會有被合併的欄位，因此參照 mapping ，若此列有被合併，尋找第一個未被合併的欄位
                    if (mergeStatusEveryTr[rowIndex][thIndex] === 0) {
                        trueIndexFlag = mergeStatusEveryTr[rowIndex].findIndex((element, index, array) => element === 1 && index > trueIndexFlag);
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyRightFrozenTd[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][trueIndexFlag] = 0;
                            }
                            rowCount++;
                        }
                    }
                    else {
                        let rowCount = rowIndex + 1;
                        while (rowCount <
                            rowIndex + trListOnlyRightFrozenTd[rowIndex][thIndex].rowSpan) {
                            if (mergeStatusEveryTr[rowCount] !== undefined) {
                                mergeStatusEveryTr[rowCount][thIndex] = 0;
                            }
                            rowCount++;
                        }
                    }
                }
            }
        }
        for (let mergeRowIndex = 1; mergeRowIndex < mergeStatusEveryTr.length; mergeRowIndex++) {
            let thCounting = 0;
            for (let thIndex = 0; thIndex < mergeStatusEveryTr[mergeRowIndex].length; thIndex++) {
                if (mergeStatusEveryTr[mergeRowIndex][thIndex] === 1) {
                    // 如果右方欄位是被合併的，要將右方邊線加回來
                    if (thCounting === 0) {
                        trListOnlyRightFrozenTd[mergeRowIndex][thCounting].style.borderRightWidth = '1px';
                    }
                    trListOnlyRightFrozenTd[mergeRowIndex][thCounting].style.right =
                        trListOnlyRightFrozenTd[0][thIndex].style.right;
                    thCounting++;
                }
            }
            // 非視覺上的第一欄要移除陰影
            const hasShadowIndex = mergeStatusEveryTr[mergeRowIndex].indexOf(1);
            if (hasShadowIndex !== 0) {
                this._renderer.removeClass(trListOnlyRightFrozenTd[mergeRowIndex][0], 'cub-datatable-frozen-right-shadow');
            }
        }
    }
    // 建立右側表頭固定欄位陣列
    createTrListOnlyRightFrozenTh(theadList) {
        let list = [];
        for (let index = 0; index < theadList.length; index++) {
            list.push(theadList[index].querySelectorAll('.cub-frozen-column[alignfrozen="right"]'));
        }
        return list;
    }
    // 建立右側內容固定欄位陣列
    createTrListOnlyRightFrozenTd(tbodyList) {
        let list = [];
        for (let index = 0; index < tbodyList.length; index++) {
            list.push(tbodyList[index].querySelectorAll('.cub-frozen-column[alignfrozen="right"]'));
        }
        return list;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableFrozenFixer, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: CubTable }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTableFrozenFixer, isStandalone: true, selector: "[cubTableFrozenFixer]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableFrozenFixer, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTableFrozenFixer]',
                    host: {},
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: CubTable }] });

class CubTableModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTableModule, imports: [CubCommonModule,
            /** Components */
            CubTable,
            CubTableBody,
            CubTableSortIcon,
            CubTableFilterIcon,
            CubColumnFilterFormElement,
            CubScroller,
            CubTableRadio,
            CubTableCheckbox,
            CubTableHeaderCheckbox,
            /** Directives */
            CubRowGroupHeader,
            CubFrozenColumn,
            CubSortableColumn,
            CubSelectableRow,
            CubSelectableRowDoubleClick,
            CubRowToggler,
            CubResizableColumn,
            CubReorderableColumn,
            CubDraggableRow,
            CubDraggableRowHandle,
            CubTableFrozenFixer], exports: [CubCommonModule,
            /** Components */
            CubTable,
            CubTableBody,
            CubTableSortIcon,
            CubTableFilterIcon,
            CubColumnFilterFormElement,
            CubScroller,
            CubTableRadio,
            CubTableCheckbox,
            CubTableHeaderCheckbox,
            /** Directives */
            CubRowGroupHeader,
            CubFrozenColumn,
            CubSortableColumn,
            CubSelectableRow,
            CubSelectableRowDoubleClick,
            CubRowToggler,
            CubResizableColumn,
            CubReorderableColumn,
            CubDraggableRow,
            CubDraggableRowHandle,
            CubTableFrozenFixer] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_SELECT_SCROLL_STRATEGY_PROVIDER,
        ], imports: [CubCommonModule,
            /** Components */
            CubTable,
            CubTableFilterIcon,
            CubScroller,
            CubTableRadio,
            CubTableCheckbox,
            CubTableHeaderCheckbox, CubCommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubCommonModule,
                        /** Components */
                        CubTable,
                        CubTableBody,
                        CubTableSortIcon,
                        CubTableFilterIcon,
                        CubColumnFilterFormElement,
                        CubScroller,
                        CubTableRadio,
                        CubTableCheckbox,
                        CubTableHeaderCheckbox,
                        /** Directives */
                        CubRowGroupHeader,
                        CubFrozenColumn,
                        CubSortableColumn,
                        CubSelectableRow,
                        CubSelectableRowDoubleClick,
                        CubRowToggler,
                        CubResizableColumn,
                        CubReorderableColumn,
                        CubDraggableRow,
                        CubDraggableRowHandle,
                        CubTableFrozenFixer,
                    ],
                    exports: [
                        CubCommonModule,
                        /** Components */
                        CubTable,
                        CubTableBody,
                        CubTableSortIcon,
                        CubTableFilterIcon,
                        CubColumnFilterFormElement,
                        CubScroller,
                        CubTableRadio,
                        CubTableCheckbox,
                        CubTableHeaderCheckbox,
                        /** Directives */
                        CubRowGroupHeader,
                        CubFrozenColumn,
                        CubSortableColumn,
                        CubSelectableRow,
                        CubSelectableRowDoubleClick,
                        CubRowToggler,
                        CubResizableColumn,
                        CubReorderableColumn,
                        CubDraggableRow,
                        CubDraggableRowHandle,
                        CubTableFrozenFixer,
                    ],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_SELECT_SCROLL_STRATEGY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/table
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubColumnFilterFormElement, CubDraggableRow, CubDraggableRowHandle, CubFrozenColumn, CubReorderableColumn, CubResizableColumn, CubRowGroupHeader, CubRowToggler, CubScroller, CubSelectableRow, CubSelectableRowDoubleClick, CubSortableColumn, CubTable, CubTableBody, CubTableCheckbox, CubTableFilterIcon, CubTableFrozenFixer, CubTableHeaderCheckbox, CubTableModule, CubTableRadio, CubTableService, CubTableSortIcon, FilterOperator };
//# sourceMappingURL=cub-lib-view-rootng-component-table.mjs.map
