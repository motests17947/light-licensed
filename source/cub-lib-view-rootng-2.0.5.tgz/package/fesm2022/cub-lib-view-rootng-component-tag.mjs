import * as i0 from '@angular/core';
import { Input, Component, NgModule } from '@angular/core';

class CubTag {
    constructor() {
        /** 元件顏色，預設為 'green' */
        this.color = 'green';
        /** 尺寸，預設為 'medium'。 */
        this.size = 'medium';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTag, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTag, isStandalone: true, selector: "cub-tag", inputs: { color: "color", size: "size" }, host: { properties: { "class": "\"cub-tag cub-tag-\" + color", "class.cub-tag-small": "this.size === \"small\"" } }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTag, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tag', host: {
                        '[class]': '"cub-tag cub-tag-" + color',
                        '[class.cub-tag-small]': 'this.size === "small"',
                    }, template: "<ng-content></ng-content>\n" }]
        }], propDecorators: { color: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

class CubTagModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTagModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTagModule, imports: [CubTag], exports: [CubTag] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTagModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTagModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubTag],
                    exports: [CubTag],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/tag
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubTag, CubTagModule };
//# sourceMappingURL=cub-lib-view-rootng-component-tag.mjs.map
