import * as i0 from '@angular/core';
import { Input, Component, NgModule } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';

class CubTimeline {
    constructor() {
        /** 元件的資料，預設為 []。 */
        this.value = [];
        /** 元件顏色，預設值為 'brand'。 */
        this.color = 'brand';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTimeline, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTimeline, isStandalone: true, selector: "cub-timeline", inputs: { itemTemplateRef: "itemTemplateRef", markerTemplateRef: "markerTemplateRef", value: "value", color: "color" }, host: { properties: { "class.cub-neutral": "color === \"neutral\"", "class.cub-brand": "color === \"brand\"" }, classAttribute: "cub-timeline" }, ngImport: i0, template: "@for(step of value; track step;let last = $last;let index = $index){\n<div class=\"cub-timeline-step\" [class.cub-active]=\"step.active\">\n  <div class=\"cub-timeline-connector-container\">\n    <!-- \u81EA\u8A02 marker \u6A21\u677F\u6216\u9810\u8A2D\u5713\u9EDE -->\n    @if(step.icon){\n    <div class=\"cub-timeline-icon\">\n      <span [class]=\"step.icon\"></span>\n    </div>\n    } @else if(markerTemplateRef){\n    <div class=\"cub-timeline-icon\">\n      <ng-container\n        *ngTemplateOutlet=\"\n          markerTemplateRef;\n          context: { $implicit: step, index: index }\n        \"\n      ></ng-container>\n    </div>\n    } @else {\n    <div class=\"cub-timeline-marker\"></div>\n    }\n    <!-- \u9023\u63A5\u7DDA (\u6700\u5F8C\u4E00\u500B\u9805\u76EE\u4E0D\u986F\u793A) -->\n    @if(!last){\n    <div class=\"cub-timeline-connector\"></div>\n    }\n  </div>\n\n  <div class=\"cub-timeline-content\">\n    <!-- \u81EA\u8A02 content \u6A21\u677F\u6216\u9810\u8A2D\u986F\u793A -->\n    <ng-container\n      *ngTemplateOutlet=\"\n        itemTemplateRef;\n        context: { $implicit: step, index: index }\n      \"\n    ></ng-container>\n  </div>\n</div>\n}\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTimeline, decorators: [{
            type: Component,
            args: [{ selector: 'cub-timeline', host: {
                        class: 'cub-timeline',
                        '[class.cub-neutral]': 'color === "neutral"',
                        '[class.cub-brand]': 'color === "brand"',
                    }, imports: [NgTemplateOutlet], template: "@for(step of value; track step;let last = $last;let index = $index){\n<div class=\"cub-timeline-step\" [class.cub-active]=\"step.active\">\n  <div class=\"cub-timeline-connector-container\">\n    <!-- \u81EA\u8A02 marker \u6A21\u677F\u6216\u9810\u8A2D\u5713\u9EDE -->\n    @if(step.icon){\n    <div class=\"cub-timeline-icon\">\n      <span [class]=\"step.icon\"></span>\n    </div>\n    } @else if(markerTemplateRef){\n    <div class=\"cub-timeline-icon\">\n      <ng-container\n        *ngTemplateOutlet=\"\n          markerTemplateRef;\n          context: { $implicit: step, index: index }\n        \"\n      ></ng-container>\n    </div>\n    } @else {\n    <div class=\"cub-timeline-marker\"></div>\n    }\n    <!-- \u9023\u63A5\u7DDA (\u6700\u5F8C\u4E00\u500B\u9805\u76EE\u4E0D\u986F\u793A) -->\n    @if(!last){\n    <div class=\"cub-timeline-connector\"></div>\n    }\n  </div>\n\n  <div class=\"cub-timeline-content\">\n    <!-- \u81EA\u8A02 content \u6A21\u677F\u6216\u9810\u8A2D\u986F\u793A -->\n    <ng-container\n      *ngTemplateOutlet=\"\n        itemTemplateRef;\n        context: { $implicit: step, index: index }\n      \"\n    ></ng-container>\n  </div>\n</div>\n}\n" }]
        }], propDecorators: { itemTemplateRef: [{
                type: Input
            }], markerTemplateRef: [{
                type: Input
            }], value: [{
                type: Input
            }], color: [{
                type: Input
            }] } });

/**
 * data?: 表示這個屬性是可選的（optional），可以存在也可以不存在
 * Record<string, any> 是一個泛型工具類型，表示一個物件
 * string: 物件的鍵（key）必須是字串類型
 * any: 物件的值（value）可以是任何類型
 */

class CubTimelineModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTimelineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTimelineModule, imports: [CubTimeline], exports: [CubTimeline] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTimelineModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTimelineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubTimeline],
                    exports: [CubTimeline],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/timeline
 */
/* 參考來源：https://github.com/primefaces/primeng/tree/19.1.4/packages/primeng/src/timeline */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubTimeline, CubTimelineModule };
//# sourceMappingURL=cub-lib-view-rootng-component-timeline.mjs.map
