import * as i0 from '@angular/core';
import { EventEmitter, ViewChild, Output, Input, ChangeDetectionStrategy, ViewEncapsulation, Component, Injectable, ContentChildren, NgModule } from '@angular/core';
import { NgClass, NgSwitch, NgSwitchCase, NgIf, NgTemplateOutlet, NgStyle, NgFor } from '@angular/common';
import { trigger, state, transition, style, animate, query, animateChild } from '@angular/animations';
import { CubTemplate } from 'cub-lib-view-rootng/component/common';
import { CubIconButton } from 'cub-lib-view-rootng/component/button';
import { Subject } from 'rxjs';

class CubToastItem {
    constructor(zone) {
        this.zone = zone;
        this.toastLife = 5000;
        /**
         當關閉元件時發出通知。
         */
        this.closed = new EventEmitter();
    }
    ngAfterViewInit() {
        this.initTimeout();
    }
    ngOnDestroy() {
        this.clearTimeout();
    }
    initTimeout() {
        if (!this.toast.sticky) {
            this.zone.runOutsideAngular(() => {
                this.timeout = setTimeout(() => {
                    this.closed.emit({
                        index: this.index,
                        toast: this.toast,
                    });
                }, this.toast.life || this.toastLife);
            });
        }
    }
    clearTimeout() {
        if (this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }
    }
    onMouseEnter() {
        this.clearTimeout();
    }
    onMouseLeave() {
        this.initTimeout();
    }
    onCloseIconClick(event) {
        this.clearTimeout();
        this.closed.emit({
            index: this.index,
            toast: this.toast,
        });
        event.preventDefault();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastItem, deps: [{ token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubToastItem, isStandalone: true, selector: "cub-toast-item", inputs: { toast: "toast", index: "index", templateRef: "templateRef", showTransformOptions: "showTransformOptions", hideTransformOptions: "hideTransformOptions", showTransitionOptions: "showTransitionOptions", hideTransitionOptions: "hideTransitionOptions" }, outputs: { closed: "closed" }, viewQueries: [{ propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true }], ngImport: i0, template: "<div\n  #container\n  [attr.id]=\"toast.id\"\n  [class]=\"toast.styleClass!\"\n  [ngClass]=\"['cub-toast-item-' + toast.status || 'success', 'cub-toast-item']\"\n  [@toastState]=\"{\n    value: 'visible',\n    params: {\n      showTransformParams: showTransformOptions,\n      hideTransformParams: hideTransformOptions,\n      showTransitionParams: showTransitionOptions,\n      hideTransitionParams: hideTransitionOptions\n    }\n  }\"\n  (mouseenter)=\"onMouseEnter()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <div\n    class=\"cub-toast-item-content\"\n    role=\"alert\"\n    aria-live=\"assertive\"\n    aria-atomic=\"true\"\n    [ngClass]=\"toast.contentStyleClass\"\n  >\n    <div class=\"cub-toast-item-icon\">\n      <ng-container [ngSwitch]=\"toast.status\">\n        <ng-container *ngSwitchCase=\"'success'\">\n          <span class=\"cub-icon-check-circle-filled\"></span>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'warning'\">\n          <span class=\"cub-icon-exclamation-triangle-filled\"></span>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'error'\">\n          <span class=\"cub-icon-x-circle-filled\"></span>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'neutral'\">\n          <span class=\"cub-icon-info-circle-filled\"></span>\n        </ng-container>\n      </ng-container>\n    </div>\n    <ng-container *ngIf=\"!templateRef\">\n      <div class=\"cub-toast-item-text\">\n        <div class=\"cub-toast-item-title\">{{ toast.title }}</div>\n        <div\n          *ngIf=\"toast.message && toast.message.length > 0\"\n          class=\"cub-toast-item-message\"\n        >\n          {{ toast.message }}\n        </div>\n      </div>\n    </ng-container>\n    <ng-container\n      *ngTemplateOutlet=\"templateRef; context: { $implicit: toast }\"\n    ></ng-container>\n    <div class=\"cub-toast-item-close\">\n      <button\n        *ngIf=\"toast.closable !== false\"\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"plain\"\n        (click)=\"onCloseIconClick($event)\"\n        (keydown.enter)=\"onCloseIconClick($event)\"\n      >\n        <span class=\"cub-icon-x-small\"></span>\n      </button>\n    </div>\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CubIconButton, selector: "button[cub-icon-button]", inputs: ["disabled", "disableRipple", "color", "appearance"], exportAs: ["cubIconButton"] }], animations: [
            trigger('toastState', [
                state('visible', style({
                    transform: 'translateY(0)',
                    opacity: 1,
                })),
                transition('void => *', [
                    style({ transform: '{{showTransformParams}}', opacity: 0 }),
                    animate('{{showTransitionParams}}'),
                ]),
                transition('* => void', [
                    animate('{{hideTransitionParams}}', style({
                        opacity: 0,
                        transform: '{{hideTransformParams}}',
                    })),
                ]),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastItem, decorators: [{
            type: Component,
            args: [{ selector: 'cub-toast-item', animations: [
                        trigger('toastState', [
                            state('visible', style({
                                transform: 'translateY(0)',
                                opacity: 1,
                            })),
                            transition('void => *', [
                                style({ transform: '{{showTransformParams}}', opacity: 0 }),
                                animate('{{showTransitionParams}}'),
                            ]),
                            transition('* => void', [
                                animate('{{hideTransitionParams}}', style({
                                    opacity: 0,
                                    transform: '{{hideTransformParams}}',
                                })),
                            ]),
                        ]),
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgClass,
                        NgSwitch,
                        NgSwitchCase,
                        NgIf,
                        NgTemplateOutlet,
                        CubIconButton,
                    ], template: "<div\n  #container\n  [attr.id]=\"toast.id\"\n  [class]=\"toast.styleClass!\"\n  [ngClass]=\"['cub-toast-item-' + toast.status || 'success', 'cub-toast-item']\"\n  [@toastState]=\"{\n    value: 'visible',\n    params: {\n      showTransformParams: showTransformOptions,\n      hideTransformParams: hideTransformOptions,\n      showTransitionParams: showTransitionOptions,\n      hideTransitionParams: hideTransitionOptions\n    }\n  }\"\n  (mouseenter)=\"onMouseEnter()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <div\n    class=\"cub-toast-item-content\"\n    role=\"alert\"\n    aria-live=\"assertive\"\n    aria-atomic=\"true\"\n    [ngClass]=\"toast.contentStyleClass\"\n  >\n    <div class=\"cub-toast-item-icon\">\n      <ng-container [ngSwitch]=\"toast.status\">\n        <ng-container *ngSwitchCase=\"'success'\">\n          <span class=\"cub-icon-check-circle-filled\"></span>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'warning'\">\n          <span class=\"cub-icon-exclamation-triangle-filled\"></span>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'error'\">\n          <span class=\"cub-icon-x-circle-filled\"></span>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'neutral'\">\n          <span class=\"cub-icon-info-circle-filled\"></span>\n        </ng-container>\n      </ng-container>\n    </div>\n    <ng-container *ngIf=\"!templateRef\">\n      <div class=\"cub-toast-item-text\">\n        <div class=\"cub-toast-item-title\">{{ toast.title }}</div>\n        <div\n          *ngIf=\"toast.message && toast.message.length > 0\"\n          class=\"cub-toast-item-message\"\n        >\n          {{ toast.message }}\n        </div>\n      </div>\n    </ng-container>\n    <ng-container\n      *ngTemplateOutlet=\"templateRef; context: { $implicit: toast }\"\n    ></ng-container>\n    <div class=\"cub-toast-item-close\">\n      <button\n        *ngIf=\"toast.closable !== false\"\n        cub-icon-button\n        type=\"button\"\n        color=\"neutral-light\"\n        appearance=\"plain\"\n        (click)=\"onCloseIconClick($event)\"\n        (keydown.enter)=\"onCloseIconClick($event)\"\n      >\n        <span class=\"cub-icon-x-small\"></span>\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.NgZone }], propDecorators: { toast: [{
                type: Input
            }], index: [{
                type: Input
            }], templateRef: [{
                type: Input
            }], showTransformOptions: [{
                type: Input
            }], hideTransformOptions: [{
                type: Input
            }], showTransitionOptions: [{
                type: Input
            }], hideTransitionOptions: [{
                type: Input
            }], closed: [{
                type: Output
            }], containerViewChild: [{
                type: ViewChild,
                args: ['container']
            }] } });

class CubToastService {
    constructor() {
        this.toastSource = new Subject();
        this.clearSource = new Subject();
        this.toastObserver = this.toastSource.asObservable();
        this.clearObserver = this.clearSource.asObservable();
    }
    add(toast) {
        if (toast) {
            this.toastSource.next(toast);
        }
    }
    addAll(toasts) {
        if (toasts && toasts.length) {
            this.toastSource.next(toasts);
        }
    }
    clear(key) {
        this.clearSource.next(key || null);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class CubToast {
    constructor(toastService, changeDetectorRef) {
        this.toastService = toastService;
        this.changeDetectorRef = changeDetectorRef;
        this.preventOpenDuplicates = false;
        this.preventDuplicates = false;
        this.showTransformOptions = 'translateY(100%)';
        this.hideTransformOptions = 'translateY(-100%)';
        this.showTransitionOptions = '300ms ease-out';
        this.hideTransitionOptions = '250ms ease-in';
        /**
         當關閉元件時發出通知。
         */
        this.closed = new EventEmitter();
    }
    ngOnInit() {
        this.toastSubscription = this.toastService.toastObserver.subscribe((toasts) => {
            if (toasts) {
                if (toasts instanceof Array) {
                    const filteredToasts = toasts.filter((m) => this.canAdd(m));
                    this.add(filteredToasts);
                }
                else if (this.canAdd(toasts)) {
                    this.add([toasts]);
                }
            }
        });
        this.clearSubscription = this.toastService.clearObserver.subscribe((key) => {
            if (key) {
                if (this.key === key) {
                    this.toasts = null;
                }
            }
            else {
                this.toasts = null;
            }
            this.changeDetectorRef.markForCheck();
        });
    }
    ngAfterContentInit() {
        this.templates.forEach((item) => {
            switch (item.getType()) {
                case 'toast':
                    this.templateRef = item.template;
                    break;
                default:
                    this.templateRef = item.template;
                    break;
            }
        });
    }
    ngOnDestroy() {
        if (this.toastSubscription) {
            this.toastSubscription.unsubscribe();
        }
        if (this.clearSubscription) {
            this.clearSubscription.unsubscribe();
        }
    }
    add(toasts) {
        this.toasts = this.toasts ? [...this.toasts, ...toasts] : [...toasts];
        if (this.preventDuplicates) {
            this.toastsArchive = this.toastsArchive
                ? [...this.toastsArchive, ...toasts]
                : [...toasts];
        }
        this.changeDetectorRef.markForCheck();
    }
    canAdd(toast) {
        let allow = this.key === toast.key;
        if (allow && this.preventOpenDuplicates) {
            allow = !this.containsToast(this.toasts, toast);
        }
        if (allow && this.preventDuplicates) {
            allow = !this.containsToast(this.toastsArchive, toast);
        }
        return allow;
    }
    containsToast(collection, toast) {
        if (!collection) {
            return false;
        }
        return (collection.find((m) => {
            return (m.title === toast.title &&
                m.message == toast.message &&
                m.status === toast.status);
        }) != null);
    }
    onToastClose(event) {
        this.toasts?.splice(event.index, 1);
        this.closed.emit({
            toast: event.toast,
        });
        this.changeDetectorRef.detectChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToast, deps: [{ token: CubToastService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubToast, isStandalone: true, selector: "cub-toast", inputs: { key: "key", style: "style", styleClass: "styleClass" }, outputs: { closed: "closed" }, queries: [{ propertyName: "templates", predicate: CubTemplate }], viewQueries: [{ propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true }], ngImport: i0, template: "<div\n  #container\n  [ngClass]=\"'cub-toast cub-toast-bottom-right'\"\n  [ngStyle]=\"style\"\n  [class]=\"styleClass\"\n>\n  <cub-toast-item\n    *ngFor=\"let toast of toasts; let index = index\"\n    [toast]=\"toast\"\n    [index]=\"index\"\n    (closed)=\"onToastClose($event)\"\n    [templateRef]=\"templateRef\"\n    @toastAnimation\n    [showTransformOptions]=\"showTransformOptions\"\n    [hideTransformOptions]=\"hideTransformOptions\"\n    [showTransitionOptions]=\"showTransitionOptions\"\n    [hideTransitionOptions]=\"hideTransitionOptions\"\n  ></cub-toast-item>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CubToastItem, selector: "cub-toast-item", inputs: ["toast", "index", "templateRef", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions"], outputs: ["closed"] }], animations: [
            trigger('toastAnimation', [
                transition(':enter, :leave', [query('@*', animateChild())]),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToast, decorators: [{
            type: Component,
            args: [{ selector: 'cub-toast', animations: [
                        trigger('toastAnimation', [
                            transition(':enter, :leave', [query('@*', animateChild())]),
                        ]),
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [NgClass, NgStyle, NgFor, CubToastItem], template: "<div\n  #container\n  [ngClass]=\"'cub-toast cub-toast-bottom-right'\"\n  [ngStyle]=\"style\"\n  [class]=\"styleClass\"\n>\n  <cub-toast-item\n    *ngFor=\"let toast of toasts; let index = index\"\n    [toast]=\"toast\"\n    [index]=\"index\"\n    (closed)=\"onToastClose($event)\"\n    [templateRef]=\"templateRef\"\n    @toastAnimation\n    [showTransformOptions]=\"showTransformOptions\"\n    [hideTransformOptions]=\"hideTransformOptions\"\n    [showTransitionOptions]=\"showTransitionOptions\"\n    [hideTransitionOptions]=\"hideTransitionOptions\"\n  ></cub-toast-item>\n</div>\n" }]
        }], ctorParameters: () => [{ type: CubToastService }, { type: i0.ChangeDetectorRef }], propDecorators: { key: [{
                type: Input
            }], style: [{
                type: Input
            }], styleClass: [{
                type: Input
            }], closed: [{
                type: Output
            }], containerViewChild: [{
                type: ViewChild,
                args: ['container']
            }], templates: [{
                type: ContentChildren,
                args: [CubTemplate]
            }] } });

class CubToastModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubToastModule, imports: [CubToast, CubToastItem], exports: [CubToast, CubToastItem] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastModule, imports: [CubToast, CubToastItem] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToastModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubToast, CubToastItem],
                    exports: [CubToast, CubToastItem],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/toast
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubToast, CubToastItem, CubToastModule, CubToastService };
//# sourceMappingURL=cub-lib-view-rootng-component-toast.mjs.map
