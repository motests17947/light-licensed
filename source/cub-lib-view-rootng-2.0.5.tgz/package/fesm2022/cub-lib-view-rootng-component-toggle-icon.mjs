import * as i0 from '@angular/core';
import { forwardRef, Input, Optional, Inject, Attribute, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { ANIMATION_MODULE_TYPE } from '@angular/platform-browser/animations';
import { CubRipple } from 'cub-lib-view-rootng/component/common';
import * as i2 from 'cub-lib-view-rootng/component/checkbox';
import { _CubCheckboxBase, CubCheckboxChange, CUB_CHECKBOX_GROUP, CUB_CHECKBOX_DEFAULT_OPTIONS } from 'cub-lib-view-rootng/component/checkbox';
import * as i1 from 'cub-lib-view-rootng/cdk/a11y';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';

const CUB_TOGGLE_ICON_CONFIG = [
    {
        icon: 'star',
        color: 'orange',
        toggleOff: 'cub-icon-star',
        toggleOn: 'cub-icon-star-filled',
    },
    {
        icon: 'heart',
        color: 'red',
        toggleOff: 'cub-icon-heart',
        toggleOn: 'cub-icon-heart-filled',
    },
    {
        icon: 'bookmark',
        color: 'orange',
        toggleOff: 'cub-icon-bookmark',
        toggleOn: 'cub-icon-bookmark-filled',
    },
    {
        icon: 'thumbtack',
        color: 'gray',
        toggleOff: 'cub-icon-thumbtack',
        toggleOn: 'cub-icon-thumbtack-filled',
    },
];

class CubToggleIcon extends _CubCheckboxBase {
    /** 處理 icon 對應開關樣式替換*/
    get iconStates() {
        return CUB_TOGGLE_ICON_CONFIG.find((item) => item.icon === this.icon);
    }
    get currentIcon() {
        const iconStates = this.iconStates;
        if (!iconStates)
            return '';
        return this.checked ? iconStates.toggleOn : iconStates.toggleOff;
    }
    /** 元件顏色，預設為 undefined。 */
    get toggleIconColor() {
        if (this._toggleIconColor) {
            return this._toggleIconColor;
        }
        const iconStates = this.iconStates;
        return iconStates?.color;
    }
    set toggleIconColor(value) {
        this._toggleIconColor = value;
    }
    constructor(checkboxGroup, elementRef, changeDetectorRef, _focusMonitor, ngZone, tabIndex, _animationMode, options) {
        super('cub-toggle-icon-', checkboxGroup, elementRef, changeDetectorRef, _focusMonitor, ngZone, tabIndex, options);
        /** 元件樣式，預設為 'star'。 */
        this.icon = 'star';
        /** 元件尺寸，預設為 'medium'。 */
        this.size = 'medium';
        this._noopAnimations = _animationMode === 'NoopAnimations';
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this._focusMonitor
            .monitor(this._elementRef, true)
            .subscribe((focusOrigin) => {
            if (!focusOrigin) {
                this._onBlur();
            }
        });
    }
    ngOnDestroy() {
        this._focusMonitor.stopMonitoring(this._elementRef);
    }
    /**
     * 處理標籤上的鍵盤事件。
     * 當使用者按下空白鍵時，會切換選取狀態。
     */
    _onLabelKeydown(event) {
        if (event instanceof KeyboardEvent) {
            if (event.code === 'Space' ||
                event.key === 'Enter' ||
                event.key === ' ') {
                event.preventDefault();
                event.stopPropagation();
                const input = this._elementRef.nativeElement.querySelector('input.cub-toggle-icon-input');
                if (input && !this.disabled) {
                    // 切換 checked 狀態
                    this.checked = !this.checked;
                    this._changeDetectorRef.markForCheck();
                    // 手動觸發 change 事件
                    const changeEvent = new Event('change', { bubbles: true });
                    input.dispatchEvent(changeEvent);
                }
            }
        }
    }
    _onInputClick(event) {
        event.stopPropagation();
        super._handleInputClick();
    }
    focus(origin, options) {
        if (origin) {
            this._focusMonitor.focusVia(this._inputElement, origin, options);
        }
        else {
            this._inputElement.nativeElement.focus(options);
        }
    }
    _createChangeEvent(isChecked) {
        const event = new CubCheckboxChange();
        event.source = this;
        event.checked = isChecked;
        return event;
    }
    _getAnimationTargetElement() {
        return this._elementRef.nativeElement;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleIcon, deps: [{ token: CUB_CHECKBOX_GROUP, optional: true }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.FocusMonitor }, { token: i0.NgZone }, { token: 'tabindex', attribute: true }, { token: ANIMATION_MODULE_TYPE, optional: true }, { token: CUB_CHECKBOX_DEFAULT_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubToggleIcon, isStandalone: true, selector: "cub-toggle-icon", inputs: { disableRipple: "disableRipple", tabIndex: "tabIndex", icon: "icon", toggleIconColor: ["color", "toggleIconColor"], size: "size" }, host: { properties: { "class": "\"cub-toggle-icon cub-toggle-icon-\" + icon + \" cub-toggle-icon-\" + toggleIconColor", "id": "id", "class.cub-checked": "checked", "class.cub-disabled": "disabled", "attr.tabindex": "null", "attr.aria-label": "null", "attr.aria-labelledby": "null", "class.cub-toggle-icon-small": "size === \"small\"" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CubToggleIcon),
                multi: true,
            },
        ], exportAs: ["cubToggleIcon"], usesInheritance: true, ngImport: i0, template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  class=\"cub-toggle-icon-label\"\n  [class.cub-disabled]=\"disabled\"\n  [tabIndex]=\"tabIndex\"\n  (keydown)=\"_onLabelKeydown($event)\"\n>\n  <span class=\"cub-toggle-icon-container\">\n    <input\n      #input\n      class=\"cub-toggle-icon-input cub-cdk-visually-hidden\"\n      type=\"checkbox\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [attr.value]=\"value\"\n      [disabled]=\"disabled\"\n      [attr.name]=\"name\"\n      [tabIndex]=\"-1\"\n      [attr.aria-label]=\"ariaLabel || null\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-checked]=\"_getAriaChecked()\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"_onInteractionEvent($event)\"\n      (click)=\"_onInputClick($event)\"\n    />\n    <span class=\"cub-toggle-icon-background\">\n      <span [class]=\"currentIcon\"></span>\n    </span>\n  </span>\n  <span\n    cubRipple\n    cubRippleClass=\"cub-toggle-icon-ripple\"\n    [cubRippleTrigger]=\"label\"\n    [cubRippleDisabled]=\"_isRippleDisabled()\"\n    [cubRippleCentered]=\"true\"\n    [cubRippleAnimation]=\"{\n      enterDuration: _noopAnimations ? 0 : 150\n    }\"\n  >\n  </span>\n  <span class=\"cub-persistent-ripple cub-toggle-icon-persistent-ripple\"></span>\n</label>\n", styles: [""], dependencies: [{ kind: "directive", type: CubRipple, selector: "[cub-ripple], [cubRipple]", inputs: ["cubRippleClass", "cubRippleColor", "cubRippleUnbounded", "cubRippleCentered", "cubRippleRadius", "cubRippleAnimation", "cubRippleDisabled", "cubRippleTrigger"], exportAs: ["cubRipple"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleIcon, decorators: [{
            type: Component,
            args: [{ selector: 'cub-toggle-icon', exportAs: 'cubToggleIcon', host: {
                        '[class]': '"cub-toggle-icon cub-toggle-icon-" + icon + " cub-toggle-icon-" + toggleIconColor',
                        '[id]': 'id',
                        '[class.cub-checked]': 'checked',
                        '[class.cub-disabled]': 'disabled',
                        '[attr.tabindex]': 'null',
                        '[attr.aria-label]': 'null',
                        '[attr.aria-labelledby]': 'null',
                        '[class.cub-toggle-icon-small]': 'size === "small"',
                    }, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CubToggleIcon),
                            multi: true,
                        },
                    ], inputs: ['disableRipple', 'tabIndex'], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CubRipple], template: "<label\n  #label\n  [attr.for]=\"inputId\"\n  class=\"cub-toggle-icon-label\"\n  [class.cub-disabled]=\"disabled\"\n  [tabIndex]=\"tabIndex\"\n  (keydown)=\"_onLabelKeydown($event)\"\n>\n  <span class=\"cub-toggle-icon-container\">\n    <input\n      #input\n      class=\"cub-toggle-icon-input cub-cdk-visually-hidden\"\n      type=\"checkbox\"\n      [id]=\"inputId\"\n      [required]=\"required\"\n      [checked]=\"checked\"\n      [attr.value]=\"value\"\n      [disabled]=\"disabled\"\n      [attr.name]=\"name\"\n      [tabIndex]=\"-1\"\n      [attr.aria-label]=\"ariaLabel || null\"\n      [attr.aria-labelledby]=\"ariaLabelledby\"\n      [attr.aria-checked]=\"_getAriaChecked()\"\n      [attr.aria-describedby]=\"ariaDescribedby\"\n      (change)=\"_onInteractionEvent($event)\"\n      (click)=\"_onInputClick($event)\"\n    />\n    <span class=\"cub-toggle-icon-background\">\n      <span [class]=\"currentIcon\"></span>\n    </span>\n  </span>\n  <span\n    cubRipple\n    cubRippleClass=\"cub-toggle-icon-ripple\"\n    [cubRippleTrigger]=\"label\"\n    [cubRippleDisabled]=\"_isRippleDisabled()\"\n    [cubRippleCentered]=\"true\"\n    [cubRippleAnimation]=\"{\n      enterDuration: _noopAnimations ? 0 : 150\n    }\"\n  >\n  </span>\n  <span class=\"cub-persistent-ripple cub-toggle-icon-persistent-ripple\"></span>\n</label>\n" }]
        }], ctorParameters: () => [{ type: i2.CubCheckboxGroup, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CHECKBOX_GROUP]
                }] }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.FocusMonitor }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['tabindex']
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_CHECKBOX_DEFAULT_OPTIONS]
                }] }], propDecorators: { icon: [{
                type: Input
            }], toggleIconColor: [{
                type: Input,
                args: ['color']
            }], size: [{
                type: Input
            }] } });

class CubToggleIconModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleIconModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubToggleIconModule, imports: [CubFormFieldModule, CubLabelModule, CubInputModule, CubToggleIcon], exports: [CubFormFieldModule, CubLabelModule, CubInputModule, CubToggleIcon] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleIconModule, imports: [CubFormFieldModule, CubLabelModule, CubInputModule, CubFormFieldModule, CubLabelModule, CubInputModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleIconModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubFormFieldModule, CubLabelModule, CubInputModule, CubToggleIcon],
                    exports: [CubFormFieldModule, CubLabelModule, CubInputModule, CubToggleIcon],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/toggle-icon
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_TOGGLE_ICON_CONFIG, CubToggleIcon, CubToggleIconModule };
//# sourceMappingURL=cub-lib-view-rootng-component-toggle-icon.mjs.map
