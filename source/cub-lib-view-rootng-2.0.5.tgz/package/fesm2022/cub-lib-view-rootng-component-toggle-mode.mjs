import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';
import { CubInputModule } from 'cub-lib-view-rootng/component/input';
import { CubButtonModule } from 'cub-lib-view-rootng/component/button';

class CubToggleMode {
    get hasOnLabel() {
        return !!this.onLabel && this.onLabel.length > 0;
    }
    get hasOffLabel() {
        return !!this.onLabel && this.onLabel.length > 0;
    }
    get toggleLabel() {
        if (this.checked) {
            return this.hasOnLabel ? this.onLabel : '';
        }
        else {
            return this.hasOffLabel ? this.offLabel : '';
        }
    }
    constructor(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
        this.checked = false;
        /** 元件標題（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaLabel = '';
        /** 優先於標題讀取的替代文字（螢幕閱讀器讀取用），預設為 null。 */
        this.ariaLabelledby = null;
        /** 在標題與欄位型別之後提供額外的描述資訊（螢幕閱讀器讀取用），預設為 ''。 */
        this.ariaDescribedby = '';
        /** 按鈕尺寸，預設為 medium */
        this.size = 'medium';
        /** 元件開啟狀態的標題，預設為 ''。 */
        this.onLabel = '';
        /** 元件關閉狀態的標題，預設為 ''。 */
        this.offLabel = '';
        /** 元件開啟狀態的圖示，預設為 ''。 */
        this.onIcon = '';
        /** 元件關閉狀態的圖示，預設為 ''。 */
        this.offIcon = '';
        /** 元件的停用狀態，預設為 false。 */
        this.disabled = false;
        /** Tab 鍵的控制項索引值，預設為 0。 */
        this.tabindex = 0;
        /** 當狀態切換時調用的通知事件。 */
        this.change = new EventEmitter();
        this.onModelChange = () => { };
        this.onModelTouched = () => { };
    }
    writeValue(value) {
        this.checked = value;
        this.changeDetectorRef.markForCheck();
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onModelTouched = fn;
    }
    setDisabledState(val) {
        this.disabled = val;
        this.changeDetectorRef.markForCheck();
    }
    onKeydown(event) {
        switch (event.code) {
            case 'Enter':
                this.toggle(event);
                event.preventDefault();
                break;
            case 'Space':
                this.toggle(event);
                event.preventDefault();
                break;
        }
    }
    onClick(event) {
        this.toggle(event);
    }
    toggle(event) {
        if (!this.disabled) {
            this.checked = !this.checked;
            this.onModelChange(this.checked);
            this.onModelTouched();
            this.change.emit({
                originalEvent: event,
                checked: this.checked,
            });
            this.changeDetectorRef.markForCheck();
        }
    }
    onBlur() {
        this.onModelTouched();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleMode, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubToggleMode, isStandalone: true, selector: "button[cub-toggle-mode]", inputs: { ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"], size: "size", onLabel: "onLabel", offLabel: "offLabel", onIcon: "onIcon", offIcon: "offIcon", disabled: "disabled", tabindex: "tabindex" }, outputs: { change: "change" }, host: { attributes: { "role": "checkbox" }, listeners: { "click": "onClick($event)", "keydown": "onKeydown($event)" }, properties: { "attr.aria-checked": "checked", "attr.tabindex": "disabled ? -1 : 0", "attr.disabled": "disabled || null", "class.cub-disabled": "disabled || loading", "class.cub-toggle-mode-on": "checked", "class.cub-toggle-mode-off": "!checked", "class.cub-toggle-mode-small": "size === \"small\"" }, classAttribute: "cub-toggle-mode" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CubToggleMode),
                multi: true,
            },
        ], exportAs: ["cubToggleMode"], ngImport: i0, template: "<span class=\"cub-toggle-mode-wrapper\">\n  @if(onIcon || offIcon) {\n  <span\n    [class]=\"'cub-toggle-mode-icon ' + (checked ? this.onIcon : this.offIcon)\"\n  ></span>\n  } @if(onLabel || offLabel) {\n  <span class=\"cub-toggle-mode-label\">{{ toggleLabel }}</span>\n  }\n</span>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleMode, decorators: [{
            type: Component,
            args: [{ selector: 'button[cub-toggle-mode]', exportAs: 'cubToggleMode', host: {
                        class: 'cub-toggle-mode',
                        role: 'checkbox',
                        '[attr.aria-checked]': 'checked',
                        '[attr.tabindex]': 'disabled ? -1 : 0',
                        '[attr.disabled]': 'disabled || null',
                        '[class.cub-disabled]': 'disabled || loading',
                        '[class.cub-toggle-mode-on]': 'checked',
                        '[class.cub-toggle-mode-off]': '!checked',
                        '[class.cub-toggle-mode-small]': 'size === "small"',
                        '(click)': 'onClick($event)',
                        '(keydown)': 'onKeydown($event)',
                    }, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CubToggleMode),
                            multi: true,
                        },
                    ], template: "<span class=\"cub-toggle-mode-wrapper\">\n  @if(onIcon || offIcon) {\n  <span\n    [class]=\"'cub-toggle-mode-icon ' + (checked ? this.onIcon : this.offIcon)\"\n  ></span>\n  } @if(onLabel || offLabel) {\n  <span class=\"cub-toggle-mode-label\">{{ toggleLabel }}</span>\n  }\n</span>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], ariaLabelledby: [{
                type: Input,
                args: ['aria-labelledby']
            }], ariaDescribedby: [{
                type: Input,
                args: ['aria-describedby']
            }], size: [{
                type: Input
            }], onLabel: [{
                type: Input
            }], offLabel: [{
                type: Input
            }], onIcon: [{
                type: Input
            }], offIcon: [{
                type: Input
            }], disabled: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], change: [{
                type: Output
            }] } });

class CubToggleModeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleModeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubToggleModeModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule,
            CubToggleMode], exports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule,
            CubToggleMode] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleModeModule, imports: [CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule, CubFormFieldModule,
            CubLabelModule,
            CubInputModule,
            CubButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubToggleModeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubButtonModule,
                        CubToggleMode,
                    ],
                    exports: [
                        CubFormFieldModule,
                        CubLabelModule,
                        CubInputModule,
                        CubButtonModule,
                        CubToggleMode,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/toggle-mode
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubToggleMode, CubToggleModeModule };
//# sourceMappingURL=cub-lib-view-rootng-component-toggle-mode.mjs.map
