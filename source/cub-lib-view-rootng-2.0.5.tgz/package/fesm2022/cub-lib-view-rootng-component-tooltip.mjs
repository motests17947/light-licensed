import * as i0 from '@angular/core';
import { InjectionToken, TemplateRef, ViewChild, ChangeDetectionStrategy, ViewEncapsulation, Component, Input, Inject, Optional, Directive, NgModule } from '@angular/core';
import { NgClass, NgIf, NgTemplateOutlet, AsyncPipe } from '@angular/common';
import { Subject, takeUntil, take } from 'rxjs';
import * as i1 from 'cub-lib-view-rootng/cdk/layout';
import { Breakpoints } from 'cub-lib-view-rootng/cdk/layout';
import { trigger, state, transition, style, animate, keyframes } from '@angular/animations';
import * as i2 from 'cub-lib-view-rootng/cdk/platform';
import { normalizePassiveListenerOptions } from 'cub-lib-view-rootng/cdk/platform';
import * as i1$1 from 'cub-lib-view-rootng/cdk/overlay';
import { Overlay, CUB_CDK_OVERLAY_PROVIDER_LIST } from 'cub-lib-view-rootng/cdk/overlay';
import { coerceBooleanProperty } from 'cub-lib-view-rootng/cdk/coercion';
import { ESCAPE, hasModifierKey } from 'cub-lib-view-rootng/cdk/keycodes';
import { ComponentPortal } from 'cub-lib-view-rootng/cdk/portal';
import * as i3 from 'cub-lib-view-rootng/cdk/a11y';
import * as i4 from 'cub-lib-view-rootng/cdk/bidi';
import { CubCdkScrollableModule } from 'cub-lib-view-rootng/cdk/scrolling';

/**
 * Creates an error to be thrown if the user supplied an invalid tooltip position.
 * @docs-private
 */
function getCubTooltipInvalidPositionError(position) {
    return Error(`Tooltip position "${position}" is invalid.`);
}
/** @docs-private */
function CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.reposition({ scrollThrottle: SCROLL_THROTTLE_MS });
}
/** @docs-private */
function CUB_TOOLTIP_DEFAULT_OPTIONS_FACTORY() {
    return {
        showDelay: 0,
        hideDelay: 0,
        touchendHideDelay: 1500,
    };
}
function throttle(func, limit) {
    let lastFunc;
    let lastRan;
    return function (...args) {
        const now = Date.now();
        if (!lastRan) {
            func(...args);
            lastRan = now;
        }
        else {
            clearTimeout(lastFunc);
            lastFunc = setTimeout(() => {
                if (now - lastRan >= limit) {
                    func(...args);
                    lastRan = now;
                }
            }, limit - (now - lastRan));
        }
    };
}

/** Options used to bind passive event listeners. */
const passiveListenerOptions = normalizePassiveListenerOptions({
    passive: true,
});
/** Time in ms to throttle repositioning after scroll events. */
const SCROLL_THROTTLE_MS = 20;
/** CSS class that will be attached to the overlay panel. */
const TOOLTIP_PANEL_CLASS = 'cub-tooltip-panel';
/**
 * Time between the user putting the pointer on a tooltip
 * trigger and the long press event being fired.
 */
const LONGPRESS_DELAY = 100;
/** Injection token that determines the scroll handling while a tooltip is visible. */
const CUB_TOOLTIP_SCROLL_STRATEGY = new InjectionToken('cub-tooltip-scroll-strategy');
/** @docs-private */
const CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER = {
    provide: CUB_TOOLTIP_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY,
};
/** Injection token to be used to override the default options for `matTooltip`. */
const CUB_TOOLTIP_DEFAULT_OPTIONS = new InjectionToken('cub-tooltip-default-options', {
    providedIn: 'root',
    factory: CUB_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
});
/**
 * Animations used by CubTooltip.
 * @docs-private
 */
const cubTooltipAnimations = {
    /** Animation that transitions a tooltip in and out. */
    tooltipState: trigger('state', [
        state('initial, void, hidden', style({ opacity: 0, transform: 'scale(0)' })),
        state('visible', style({ transform: 'scale(1)' })),
        transition('* => visible', animate('0ms cubic-bezier(0, 0, 0.2, 1)', keyframes([
            style({ opacity: 0, transform: 'scale(0)', offset: 0 }),
            style({ opacity: 0.5, transform: 'scale(0.99)', offset: 0.5 }),
            style({ opacity: 1, transform: 'scale(1)', offset: 1 }),
        ]))),
        transition('* => hidden', animate('100ms cubic-bezier(0, 0, 0.2, 1)', style({ opacity: 0 }))),
    ]),
};

/**
 * Internal component that wraps the tooltip's content.
 * @docs-private
 */
class CubTooltip {
    get arrowOffset() {
        return this._arrowOffset;
    }
    set arrowOffset(value) {
        this._arrowOffset = value;
        this.updateArrowPosition(this.arrowDirection, value);
    }
    constructor(_changeDetectorRef, _breakpointObserver, renderer2) {
        this._changeDetectorRef = _changeDetectorRef;
        this._breakpointObserver = _breakpointObserver;
        this.renderer2 = renderer2;
        /** Property watched by the animation framework to show or hide the tooltip */
        this._visibility = 'initial';
        /** Stream that emits whether the user has a handset-sized display.  */
        this._isHandset = this._breakpointObserver.observe(Breakpoints.Handset);
        /** Amount of milliseconds to delay the closing sequence. */
        this._mouseLeaveHideDelay = 0;
        this.showArrow = true;
        /** Whether interactions on the page should close the tooltip */
        this._closeOnInteraction = false;
        /** Subject for notifying that the tooltip has been hidden from the view */
        this._onHide = new Subject();
    }
    ngOnInit() { }
    ngOnDestroy() {
        this._triggerElement = null;
        this._onHide.complete();
    }
    /**
     * Shows the tooltip with an animation originating from the provided origin
     * @param delay Amount of milliseconds to the delay showing the tooltip.
     */
    show(delay) {
        // Cancel the delayed hide if it is scheduled
        if (this._hideTimeoutId) {
            clearTimeout(this._hideTimeoutId);
            this._hideTimeoutId = null;
        }
        // Body interactions should cancel the tooltip if there is a delay in showing.
        this._closeOnInteraction = true;
        this._showTimeoutId = setTimeout(() => {
            this._visibility = 'visible';
            this._showTimeoutId = null;
            // Mark for check so if any parent component has set the
            // ChangeDetectionStrategy to OnPush it will be checked anyways
            this._markForCheck();
        }, delay);
    }
    /**
     * Begins the animation to hide the tooltip after the provided delay in ms.
     * @param delay Amount of milliseconds to delay showing the tooltip.
     */
    hide(delay) {
        // Cancel the delayed show if it is scheduled
        if (this._showTimeoutId) {
            clearTimeout(this._showTimeoutId);
            this._showTimeoutId = null;
        }
        this._hideTimeoutId = setTimeout(() => {
            this._visibility = 'hidden';
            this._hideTimeoutId = null;
            // Mark for check so if any parent component has set the
            // ChangeDetectionStrategy to OnPush it will be checked anyways
            this._markForCheck();
        }, delay);
    }
    /** Returns an observable that notifies when the tooltip has been hidden from view. */
    afterHidden() {
        return this._onHide.asObservable();
    }
    /** Whether the tooltip is being displayed. */
    isVisible() {
        return this._visibility === 'visible';
    }
    _isTemplateRef(template) {
        return template instanceof TemplateRef;
    }
    _animationStart() {
        this._closeOnInteraction = false;
    }
    _animationDone(event) {
        const toState = event.toState;
        if (toState === 'hidden' && !this.isVisible()) {
            this._onHide.next();
        }
        if (toState === 'visible' || toState === 'hidden') {
            this._closeOnInteraction = true;
        }
    }
    /**
     * Interactions on the HTML body should close the tooltip immediately as defined in the
     * material design spec.
     * https://material.io/design/components/tooltips.html#behavior
     */
    _handleBodyInteraction() {
        if (this._closeOnInteraction) {
            this.hide(0);
        }
    }
    /**
     * Marks that the tooltip needs to be checked in the next change detection run.
     * Mainly used for rendering the initial text before positioning a tooltip, which
     * can be problematic in components with OnPush change detection.
     */
    _markForCheck() {
        this._changeDetectorRef.markForCheck();
    }
    _handleMouseLeave({ relatedTarget }) {
        if (!relatedTarget ||
            !this._triggerElement?.contains(relatedTarget)) {
            if (this.isVisible()) {
                this.hide(this._mouseLeaveHideDelay);
            }
            else {
                this._finalizeAnimation(false);
            }
        }
    }
    /** Handles the cleanup after an animation has finished. */
    _finalizeAnimation(toVisible) {
        if (toVisible) {
            this._closeOnInteraction = true;
        }
        else if (!this.isVisible()) {
            this._onHide.next();
        }
    }
    updateArrowPosition(direction, value) {
        if (this.arrowElement && direction) {
            if (this.arrowDirection === 'up') {
                this.renderer2.setStyle(this.arrowElement.nativeElement, 'left', `${value}px`);
            }
            else if (this.arrowDirection === 'down') {
                this.renderer2.setStyle(this.arrowElement.nativeElement, 'left', `${value}px`);
            }
            else if (this.arrowDirection === 'left') {
                this.renderer2.setStyle(this.arrowElement.nativeElement, 'top', `${value}px`);
            }
            else if (this.arrowDirection === 'right') {
                this.renderer2.setStyle(this.arrowElement.nativeElement, 'top', `${value}px`);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltip, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.BreakpointObserver }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTooltip, isStandalone: true, selector: "cub-tooltip", host: { attributes: { "aria-hidden": "true" }, listeners: { "mouseleave": "_handleMouseLeave($event)" }, properties: { "style.zoom": "_visibility === \"visible\" ? 1 : null" } }, viewQueries: [{ propertyName: "arrowElement", first: true, predicate: ["arrow"], descendants: true }], ngImport: i0, template: "<div\n  class=\"cub-tooltip cub-tooltip-{{ arrowDirection }}\"\n  [ngClass]=\"tooltipClass\"\n  [class.cub-tooltip-handset]=\"(_isHandset | async)?.matches\"\n  [class.cub-tooltip-has-arrow]=\"showArrow\"\n  [@state]=\"_visibility\"\n  (@state.start)=\"_animationStart()\"\n  (@state.done)=\"_animationDone($event)\"\n>\n  <ng-template [ngIf]=\"_isTemplateRef(message)\" [ngIfElse]=\"msgStrTpl\">\n    <ng-template [ngTemplateOutlet]=\"$any(message)\"></ng-template>\n  </ng-template>\n  <ng-template #msgStrTpl>{{ message }}</ng-template>\n  @if (showArrow) {\n  <div\n    #arrow\n    class=\"cub-tooltip-arrow cub-tooltip-arrow-{{ arrowDirection }}\"\n  ></div>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], animations: [cubTooltipAnimations.tooltipState], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltip, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tooltip', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, animations: [cubTooltipAnimations.tooltipState], host: {
                        // Forces the element to have a layout in IE and Edge. This fixes issues where the element
                        // won't be rendered if the animations are disabled or there is no web animations polyfill.
                        '[style.zoom]': '_visibility === "visible" ? 1 : null',
                        'aria-hidden': 'true',
                        '(mouseleave)': '_handleMouseLeave($event)',
                    }, imports: [NgClass, NgIf, NgTemplateOutlet, AsyncPipe], template: "<div\n  class=\"cub-tooltip cub-tooltip-{{ arrowDirection }}\"\n  [ngClass]=\"tooltipClass\"\n  [class.cub-tooltip-handset]=\"(_isHandset | async)?.matches\"\n  [class.cub-tooltip-has-arrow]=\"showArrow\"\n  [@state]=\"_visibility\"\n  (@state.start)=\"_animationStart()\"\n  (@state.done)=\"_animationDone($event)\"\n>\n  <ng-template [ngIf]=\"_isTemplateRef(message)\" [ngIfElse]=\"msgStrTpl\">\n    <ng-template [ngTemplateOutlet]=\"$any(message)\"></ng-template>\n  </ng-template>\n  <ng-template #msgStrTpl>{{ message }}</ng-template>\n  @if (showArrow) {\n  <div\n    #arrow\n    class=\"cub-tooltip-arrow cub-tooltip-arrow-{{ arrowDirection }}\"\n  ></div>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.BreakpointObserver }, { type: i0.Renderer2 }], propDecorators: { arrowElement: [{
                type: ViewChild,
                args: ['arrow']
            }] } });

/**
 * Directive that attaches a material design tooltip to the host element. Animates the showing and
 * hiding of a tooltip provided position (defaults to above the element).
 *
 * https://material.io/design/components/tooltips.html
 */
class CubTooltipTrigger {
    /**
     是否顯示箭頭樣式，預設為 true。
    */
    get showArrow() {
        return this._showArrow;
    }
    set showArrow(value) {
        this._showArrow = value;
    }
    /**
     設置提示框與父元素的相對位置，預設為 'above'。
    */
    get position() {
        return this._position;
    }
    set position(value) {
        if (value !== this._position) {
            this._position = value;
            if (this._overlayRef) {
                this._updatePosition();
                if (this._tooltipInstance) {
                    this._tooltipInstance.show(0);
                }
                this._overlayRef.updatePosition();
            }
        }
    }
    /**
    是否啟用提示框改使用游標位置，預設為不啟用。
    */
    get positionAtOrigin() {
        return this._positionAtOrigin;
    }
    set positionAtOrigin(value) {
        this._positionAtOrigin = coerceBooleanProperty(value);
        this._detach();
        this._overlayRef = null;
    }
    /**
    是否禁用顯示提示框，預設為不禁用。
    */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        // If tooltip is disabled, hide immediately.
        if (this._disabled) {
            this.hide(0);
        }
        else {
            this._setupPointerEnterEventsIfNeeded();
        }
    }
    /** 提示框顯示的文字，或是自訂內容的 TemplateRef。 預設為 '' */
    get message() {
        return this._message;
    }
    set message(value) {
        this._ariaDescriber.removeDescription(this._elementRef.nativeElement, this._message);
        // TODO: If the message is a TemplateRef, it's hard to support a11y.
        // If the message is not a string (e.g. number), convert it to a string and trim it.
        this._message =
            value instanceof TemplateRef
                ? value
                : value != null
                    ? `${value}`.trim()
                    : '';
        if (!this._message && this._isTooltipVisible()) {
            this.hide(0);
        }
        else {
            this._setupPointerEnterEventsIfNeeded();
            this._updateTooltipMessage();
            this._ngZone.runOutsideAngular(() => {
                // The `AriaDescriber` has some functionality that avoids adding a description if it's the
                // same as the `aria-label` of an element, however we can't know whether the tooltip trigger
                // has a data-bound `aria-label` or when it'll be set for the first time. We can avoid the
                // issue by deferring the description by a tick so Angular has time to set the `aria-label`.
                Promise.resolve().then(() => {
                    this._ariaDescriber.describe(this._elementRef.nativeElement, this.message);
                });
            });
        }
    }
    /**
     提示框的類別樣式，支援與 ngClass 相同的語法，預設值為 undefined。
    */
    get tooltipClass() {
        return this._tooltipClass;
    }
    set tooltipClass(value) {
        this._tooltipClass = value;
        if (this._tooltipInstance) {
            this._setTooltipClass(this._tooltipClass);
        }
    }
    constructor(_overlay, _elementRef, _scrollDispatcher, _viewContainerRef, _ngZone, _platform, _ariaDescriber, _focusMonitor, scrollStrategy, _dir, _defaultOptions) {
        this._overlay = _overlay;
        this._elementRef = _elementRef;
        this._scrollDispatcher = _scrollDispatcher;
        this._viewContainerRef = _viewContainerRef;
        this._ngZone = _ngZone;
        this._platform = _platform;
        this._ariaDescriber = _ariaDescriber;
        this._focusMonitor = _focusMonitor;
        this._dir = _dir;
        this._defaultOptions = _defaultOptions;
        this.tooltipTouched = false;
        this._position = 'above';
        this._positionAtOrigin = false;
        this._disabled = false;
        this._viewInitialized = false;
        this._pointerExitEventsInitialized = false;
        this._message = '';
        this._showArrow = true;
        this._arrowWidth = 8;
        /** Manually-bound passive event listeners. */
        this._passiveListeners = [];
        /** Emits when the component is destroyed. */
        this._destroyed = new Subject();
        /**
        提示框顯示的延遲時間（毫秒），預設為 0 毫秒。
        */
        this.showDelay = this._defaultOptions.showDelay;
        /**
        提示框隱藏的延遲時間（毫秒），預設為 0 毫秒。
        */
        this.hideDelay = this._defaultOptions.hideDelay;
        /**
         * 提示框如何處理觸控裝置的手勢行為。可取下列值之一：
         * - `auto` - 啟用觸控手勢，並不停用瀏覽器原生觸控手勢行為。
         * - `on` - 啟用觸控手勢，並停用瀏覽器原生觸控手勢行為。
         * - `off` - 禁用觸控手勢。
         * 預設值為 'auto'。
         */
        this.touchGestures = 'auto';
        /**
         * Handles the keydown events on the host element.
         * Needs to be an arrow function so that we can use it in addEventListener.
         */
        this._handleKeydown = (event) => {
            if (this._isTooltipVisible() &&
                event.keyCode === ESCAPE &&
                !hasModifierKey(event)) {
                event.preventDefault();
                event.stopPropagation();
                this._ngZone.run(() => this.hide(0));
            }
        };
        this._scrollStrategy = scrollStrategy;
        if (_defaultOptions) {
            if (_defaultOptions.position) {
                this.position = _defaultOptions.position;
            }
            if (_defaultOptions.positionAtOrigin) {
                this.positionAtOrigin = _defaultOptions.positionAtOrigin;
            }
            if (_defaultOptions.touchGestures) {
                this.touchGestures = _defaultOptions.touchGestures;
            }
        }
        _ngZone.runOutsideAngular(() => {
            _elementRef.nativeElement.addEventListener('keydown', this._handleKeydown);
        });
    }
    ngAfterViewInit() {
        // This needs to happen after view init so the initial values for all inputs have been set.
        this._viewInitialized = true;
        this._setupPointerEnterEventsIfNeeded();
        this._focusMonitor
            .monitor(this._elementRef)
            .pipe(takeUntil(this._destroyed))
            .subscribe((origin) => {
            // Note that the focus monitor runs outside the Angular zone.
            if (!origin) {
                this._ngZone.run(() => this.hide(0));
            }
            else if (origin === 'keyboard') {
                this._ngZone.run(() => this.show());
            }
        });
    }
    /**
     * Dispose the tooltip when destroyed.
     */
    ngOnDestroy() {
        const nativeElement = this._elementRef.nativeElement;
        clearTimeout(this._touchstartTimeout);
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._tooltipInstance = null;
        }
        // Clean up the event listeners set in the constructor
        nativeElement.removeEventListener('keydown', this._handleKeydown);
        this._passiveListeners.forEach(([event, listener]) => {
            nativeElement.removeEventListener(event, listener, passiveListenerOptions);
        });
        this._passiveListeners.length = 0;
        this._destroyed.next();
        this._destroyed.complete();
        this._ariaDescriber.removeDescription(nativeElement, this.message);
        this._focusMonitor.stopMonitoring(nativeElement);
    }
    /** Shows the tooltip after the delay in ms, defaults to tooltip-delay-show or 0ms if no input */
    show(delay = this.showDelay, origin) {
        if (this.disabled ||
            !this.message ||
            (this._isTooltipVisible() &&
                !this._tooltipInstance._showTimeoutId &&
                !this._tooltipInstance._hideTimeoutId)) {
            return;
        }
        const overlayRef = this._createOverlay(origin);
        this._detach();
        this._portal =
            this._portal || new ComponentPortal(CubTooltip, this._viewContainerRef);
        this._tooltipInstance = overlayRef.attach(this._portal).instance;
        this._tooltipInstance._triggerElement = this._elementRef.nativeElement;
        this._tooltipInstance._mouseLeaveHideDelay = this.hideDelay;
        this._tooltipInstance
            .afterHidden()
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => this._detach());
        this._setTooltipClass(this._tooltipClass);
        this._updateTooltipMessage();
        this._tooltipInstance.show(delay);
    }
    /** Hides the tooltip after the delay in ms, defaults to tooltip-delay-hide or 0ms if no input */
    hide(delay = this.hideDelay) {
        if (this._tooltipInstance) {
            this._tooltipInstance.hide(delay);
        }
    }
    /** Shows/hides the tooltip */
    toggle(origin) {
        this._isTooltipVisible() ? this.hide() : this.show(undefined, origin);
    }
    /** Returns true if the tooltip is currently visible to the user */
    _isTooltipVisible() {
        return !!this._tooltipInstance && this._tooltipInstance.isVisible();
    }
    /**
     * Returns the origin position and a fallback position based on the user's position preference.
     * The fallback position is the inverse of the origin (e.g. `'below' -> 'above'`).
     */
    _getOrigin() {
        const isLtr = !this._dir || this._dir.value === 'ltr';
        const position = this.position;
        let originPosition;
        if (position === 'above' || position === 'below') {
            originPosition = {
                originX: 'center',
                originY: position === 'above' ? 'top' : 'bottom',
            };
        }
        else if (position === 'before' ||
            (position === 'left' && isLtr) ||
            (position === 'right' && !isLtr)) {
            originPosition = { originX: 'start', originY: 'center' };
        }
        else if (position === 'after' ||
            (position === 'right' && isLtr) ||
            (position === 'left' && !isLtr)) {
            originPosition = { originX: 'end', originY: 'center' };
        }
        else {
            throw getCubTooltipInvalidPositionError(position);
        }
        const { x, y } = this._invertPosition(originPosition.originX, originPosition.originY);
        return {
            main: originPosition,
            fallback: { originX: x, originY: y },
            above: { originX: 'center', originY: 'top' },
            below: { originX: 'center', originY: 'bottom' },
        };
    }
    /** Returns the overlay position and a fallback position based on the user's preference */
    _getOverlayPosition() {
        const isLtr = !this._dir || this._dir.value === 'ltr';
        const position = this.position;
        let overlayPosition;
        if (position === 'above') {
            overlayPosition = { overlayX: 'center', overlayY: 'bottom' };
        }
        else if (position === 'below') {
            overlayPosition = { overlayX: 'center', overlayY: 'top' };
        }
        else if (position === 'before' ||
            (position === 'left' && isLtr) ||
            (position === 'right' && !isLtr)) {
            overlayPosition = { overlayX: 'end', overlayY: 'center' };
        }
        else if (position === 'after' ||
            (position === 'right' && isLtr) ||
            (position === 'left' && !isLtr)) {
            overlayPosition = { overlayX: 'start', overlayY: 'center' };
        }
        else {
            throw getCubTooltipInvalidPositionError(position);
        }
        const { x, y } = this._invertPosition(overlayPosition.overlayX, overlayPosition.overlayY);
        return {
            main: overlayPosition,
            fallback: { overlayX: x, overlayY: y },
            above: { overlayX: 'center', overlayY: 'bottom' },
            below: { overlayX: 'center', overlayY: 'top' },
        };
    }
    /** Create the overlay config and position strategy */
    _createOverlay(origin) {
        if (this._overlayRef) {
            if (!this.positionAtOrigin) {
                return this._overlayRef;
            }
            this._detach();
        }
        const scrollableAncestors = this._scrollDispatcher.getAncestorScrollContainers(this._elementRef);
        // Create connected position strategy that listens for scroll events to reposition.
        const strategy = this._overlay
            .position()
            .flexibleConnectedTo(this.positionAtOrigin ? origin || this._elementRef : this._elementRef)
            .withTransformOriginOn('.cub-tooltip')
            .withFlexibleDimensions(false)
            .withViewportMargin(8)
            .withScrollableContainers(scrollableAncestors);
        strategy.positionChanges
            .pipe(takeUntil(this._destroyed))
            .subscribe((change) => {
            const { originX, originY } = change.connectionPair;
            if (this._tooltipInstance) {
                if (change.scrollableViewProperties.isOverlayClipped &&
                    this._tooltipInstance.isVisible()) {
                    // After position changes occur and the overlay is clipped by
                    // a parent scrollable then close the tooltip.
                    this._ngZone.run(() => this.hide(0));
                }
                const triggerRect = this._elementRef.nativeElement.getBoundingClientRect();
                const overlayRect = this._overlayRef?.overlayElement.getBoundingClientRect();
                if (originY === 'top') {
                    this._tooltipInstance.arrowDirection = 'down';
                    if (overlayRect) {
                        const left = triggerRect.x +
                            Math.floor(triggerRect.width / 2) -
                            overlayRect.x;
                        this._tooltipInstance.arrowOffset = left;
                    }
                }
                else if (originY === 'bottom') {
                    this._tooltipInstance.arrowDirection = 'up';
                    if (overlayRect) {
                        const left = triggerRect.x +
                            Math.floor(triggerRect.width / 2) -
                            overlayRect.x;
                        this._tooltipInstance.arrowOffset = left;
                    }
                }
                else if (originX === 'start') {
                    this._tooltipInstance.arrowDirection = 'right';
                    if (overlayRect) {
                        const left = triggerRect.y +
                            triggerRect.width / 2 -
                            overlayRect.y -
                            this._arrowWidth;
                        this._tooltipInstance.arrowOffset = left;
                    }
                }
                else if (originX === 'end') {
                    this._tooltipInstance.arrowDirection = 'left';
                    if (overlayRect) {
                        const top = triggerRect.y +
                            triggerRect.height / 2 -
                            overlayRect.y -
                            this._arrowWidth;
                        this._tooltipInstance.arrowOffset = top;
                    }
                }
                else {
                    this._tooltipInstance.arrowDirection = undefined;
                }
                if (this.showArrow) {
                    this._tooltipInstance.showArrow = true;
                }
            }
        });
        this._overlayRef = this._overlay.create({
            direction: this._dir,
            positionStrategy: strategy,
            panelClass: TOOLTIP_PANEL_CLASS,
            scrollStrategy: this._scrollStrategy(),
        });
        this._updatePosition();
        this._overlayRef
            .detachments()
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => this._detach());
        return this._overlayRef;
    }
    /** Detaches the currently-attached tooltip. */
    _detach() {
        if (this._overlayRef && this._overlayRef.hasAttached()) {
            this._overlayRef.detach();
        }
        this._tooltipInstance = null;
    }
    /** Updates the position of the current tooltip. */
    _updatePosition() {
        const position = this._overlayRef.getConfig()
            .positionStrategy;
        const origin = this._getOrigin();
        const overlay = this._getOverlayPosition();
        position.withPositions([
            { ...origin.main, ...overlay.main },
            { ...origin.fallback, ...overlay.fallback },
            { ...origin.above, ...overlay.above },
            { ...origin.below, ...overlay.below },
        ]);
    }
    /** Updates the tooltip message and repositions the overlay according to the new message length */
    _updateTooltipMessage() {
        // Must wait for the message to be painted to the tooltip so that the overlay can properly
        // calculate the correct positioning based on the size of the text.
        if (this._tooltipInstance) {
            this._tooltipInstance.message = this.message;
            this._tooltipInstance._markForCheck();
            this._ngZone.onMicrotaskEmpty
                .asObservable()
                .pipe(take(1), takeUntil(this._destroyed))
                .subscribe(() => {
                if (this._tooltipInstance) {
                    this._overlayRef.updatePosition();
                }
            });
        }
    }
    /** Updates the tooltip class */
    _setTooltipClass(tooltipClass) {
        if (this._tooltipInstance) {
            this._tooltipInstance.tooltipClass = tooltipClass;
            this._tooltipInstance._markForCheck();
        }
    }
    /** Inverts an overlay position. */
    _invertPosition(x, y) {
        if (this.position === 'above' || this.position === 'below') {
            if (y === 'top') {
                y = 'bottom';
            }
            else if (y === 'bottom') {
                y = 'top';
            }
        }
        else {
            if (x === 'end') {
                x = 'start';
            }
            else if (x === 'start') {
                x = 'end';
            }
        }
        return { x, y };
    }
    /** Binds the pointer events to the tooltip trigger. */
    _setupPointerEnterEventsIfNeeded() {
        // Optimization: Defer hooking up events if there's no message or the tooltip is disabled.
        if (this._disabled ||
            !this.message ||
            !this._viewInitialized ||
            this._passiveListeners.length) {
            return;
        }
        // The mouse events shouldn't be bound on mobile devices, because they can prevent the
        // first tap from firing its click event or can cause the tooltip to open for clicks.
        if (this._platformSupportsMouseEvents()) {
            this._passiveListeners.push([
                'touchstart',
                () => {
                    this.tooltipTouched = true;
                },
            ], [
                'mouseenter',
                (event) => {
                    this._setupPointerExitEventsIfNeeded();
                    let point = undefined;
                    if (event.x !== undefined &&
                        event.y !== undefined) {
                        point = event;
                    }
                    this.show(undefined, point);
                    this.tooltipTouched = false;
                },
            ]);
        }
        else if (this.touchGestures !== 'off') {
            this._disableNativeGesturesIfNecessary();
            this._passiveListeners.push([
                'touchstart',
                (event) => {
                    const touch = event.targetTouches?.[0];
                    const origin = touch
                        ? { x: touch.clientX, y: touch.clientY }
                        : undefined;
                    // Note that it's important that we don't `preventDefault` here,
                    // because it can prevent click events from firing on the element.
                    this._setupPointerExitEventsIfNeeded();
                    clearTimeout(this._touchstartTimeout);
                    this._touchstartTimeout = setTimeout(() => this.show(undefined, origin), LONGPRESS_DELAY);
                },
            ]);
        }
        this._addListeners(this._passiveListeners);
    }
    _setupPointerExitEventsIfNeeded() {
        if (this._pointerExitEventsInitialized) {
            return;
        }
        this._pointerExitEventsInitialized = true;
        const exitListeners = [];
        if (this._platformSupportsMouseEvents()) {
            exitListeners.push(['mouseleave', () => this.hide()]);
        }
        else if (this.touchGestures !== 'off') {
            this._disableNativeGesturesIfNecessary();
            const touchendListener = () => {
                clearTimeout(this._touchstartTimeout);
                this.hide(this._defaultOptions.touchendHideDelay);
            };
            exitListeners.push(['touchend', touchendListener], ['touchcancel', touchendListener]);
        }
        this._addListeners(exitListeners);
        this._passiveListeners.push(...exitListeners);
    }
    _addListeners(listeners) {
        listeners.forEach(([event, listener]) => {
            // Ensure listener is always a function with the correct signature
            // add throttle to prevent excessive event firing
            const handler = typeof listener === 'function'
                ? listener
                : (event) => listener.handleEvent(event);
            const throttledListener = throttle(handler, 50); // Throttle with a delay of 50ms
            this._elementRef.nativeElement.addEventListener(event, throttledListener, passiveListenerOptions);
        });
    }
    _platformSupportsMouseEvents() {
        return !this._platform.IOS && !this._platform.ANDROID;
    }
    /** Disables the native browser gestures, based on how the tooltip has been configured. */
    _disableNativeGesturesIfNecessary() {
        const gestures = this.touchGestures;
        if (gestures !== 'off') {
            const element = this._elementRef.nativeElement;
            const style = element.style;
            // If gestures are set to `auto`, we don't disable text selection on inputs and
            // textareas, because it prevents the user from typing into them on iOS Safari.
            if (gestures === 'on' ||
                (element.nodeName !== 'INPUT' && element.nodeName !== 'TEXTAREA')) {
                style.userSelect =
                    style.msUserSelect =
                        style.webkitUserSelect =
                            style.MozUserSelect =
                                'none';
            }
            // If we have `auto` gestures and the element uses native HTML dragging,
            // we don't set `-webkit-user-drag` because it prevents the native behavior.
            if (gestures === 'on' || !element.draggable) {
                style.webkitUserDrag = 'none';
            }
            style.touchAction = 'none';
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            style.webkitTapHighlightColor = 'transparent';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltipTrigger, deps: [{ token: i1$1.Overlay }, { token: i0.ElementRef }, { token: i1$1.ScrollDispatcher }, { token: i0.ViewContainerRef }, { token: i0.NgZone }, { token: i2.Platform }, { token: i3.AriaDescriber }, { token: i3.FocusMonitor }, { token: CUB_TOOLTIP_SCROLL_STRATEGY }, { token: i4.Directionality, optional: true }, { token: CUB_TOOLTIP_DEFAULT_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTooltipTrigger, isStandalone: true, selector: "[cubTooltip]", inputs: { showArrow: ["cubTooltipShowArrow", "showArrow"], position: ["cubTooltipPosition", "position"], positionAtOrigin: ["cubTooltipPositionAtOrigin", "positionAtOrigin"], disabled: ["cubTooltipDisabled", "disabled"], showDelay: ["cubTooltipShowDelay", "showDelay"], hideDelay: ["cubTooltipHideDelay", "hideDelay"], touchGestures: ["cubTooltipTouchGestures", "touchGestures"], message: ["cubTooltip", "message"], tooltipClass: ["cubTooltipClass", "tooltipClass"] }, host: { classAttribute: "cub-tooltip-trigger" }, exportAs: ["cubTooltip"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltipTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTooltip]',
                    exportAs: 'cubTooltip',
                    host: {
                        class: 'cub-tooltip-trigger',
                    },
                }]
        }], ctorParameters: () => [{ type: i1$1.Overlay }, { type: i0.ElementRef }, { type: i1$1.ScrollDispatcher }, { type: i0.ViewContainerRef }, { type: i0.NgZone }, { type: i2.Platform }, { type: i3.AriaDescriber }, { type: i3.FocusMonitor }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [CUB_TOOLTIP_SCROLL_STRATEGY]
                }] }, { type: i4.Directionality, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CUB_TOOLTIP_DEFAULT_OPTIONS]
                }] }], propDecorators: { showArrow: [{
                type: Input,
                args: ['cubTooltipShowArrow']
            }], position: [{
                type: Input,
                args: ['cubTooltipPosition']
            }], positionAtOrigin: [{
                type: Input,
                args: ['cubTooltipPositionAtOrigin']
            }], disabled: [{
                type: Input,
                args: ['cubTooltipDisabled']
            }], showDelay: [{
                type: Input,
                args: ['cubTooltipShowDelay']
            }], hideDelay: [{
                type: Input,
                args: ['cubTooltipHideDelay']
            }], touchGestures: [{
                type: Input,
                args: ['cubTooltipTouchGestures']
            }], message: [{
                type: Input,
                args: ['cubTooltip']
            }], tooltipClass: [{
                type: Input,
                args: ['cubTooltipClass']
            }] } });

class CubTooltipModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTooltipModule, imports: [CubCdkScrollableModule, CubTooltip, CubTooltipTrigger], exports: [CubCdkScrollableModule, CubTooltip, CubTooltipTrigger] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltipModule, providers: [
            ...CUB_CDK_OVERLAY_PROVIDER_LIST,
            CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
        ], imports: [CubCdkScrollableModule, CubCdkScrollableModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubCdkScrollableModule, CubTooltip, CubTooltipTrigger],
                    exports: [CubCdkScrollableModule, CubTooltip, CubTooltipTrigger],
                    providers: [
                        ...CUB_CDK_OVERLAY_PROVIDER_LIST,
                        CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
                    ],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/tooltip
 */
/* 參考來源：https://github.com/ng-matero/extensions/tree/v14.5.0/projects/extensions/tooltip */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CUB_TOOLTIP_DEFAULT_OPTIONS, CUB_TOOLTIP_DEFAULT_OPTIONS_FACTORY, CUB_TOOLTIP_SCROLL_STRATEGY, CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY, CUB_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER, CubTooltip, CubTooltipModule, CubTooltipTrigger, LONGPRESS_DELAY, SCROLL_THROTTLE_MS, TOOLTIP_PANEL_CLASS, cubTooltipAnimations, getCubTooltipInvalidPositionError, passiveListenerOptions, throttle };
//# sourceMappingURL=cub-lib-view-rootng-component-tooltip.mjs.map
