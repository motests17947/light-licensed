import * as i0 from '@angular/core';
import { inject, ViewContainerRef, Directive, Input, ViewChild, ChangeDetectionStrategy, ViewEncapsulation, Component, ElementRef, Renderer2, HostAttributeToken, numberAttribute, booleanAttribute, NgModule } from '@angular/core';
import { CUB_CDK_TREE_NODE_OUTLET_NODE, CubCdkTreeNodeOutlet, CubCdkTree, CubCdkTreeNode, CubCdkTreeNodePadding, CubCdkTreeNodeToggle, CubCdkNestedTreeNode, CubCdkTreeNodeDef } from 'cub-lib-view-rootng/cdk/tree';
import { BehaviorSubject, merge } from 'rxjs';
import { take, map } from 'rxjs/operators';
import { DataSource } from 'cub-lib-view-rootng/cdk/collections';

/**
 * Outlet for nested CdkNode. Put `[cubTreeNodeOutlet]` on a tag to place children dataNodes
 * inside the outlet.
 */
class CubTreeNodeOutlet {
    constructor() {
        this.viewContainer = inject(ViewContainerRef);
        this._node = inject(CUB_CDK_TREE_NODE_OUTLET_NODE, { optional: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeOutlet, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTreeNodeOutlet, isStandalone: true, selector: "[cubTreeNodeOutlet]", providers: [
            {
                provide: CubCdkTreeNodeOutlet,
                useExisting: CubTreeNodeOutlet,
            },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeOutlet, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTreeNodeOutlet]',
                    providers: [
                        {
                            provide: CubCdkTreeNodeOutlet,
                            useExisting: CubTreeNodeOutlet,
                        },
                    ],
                }]
        }] });

/**
 * Wrapper for the CdkTable with Cuberial design styles.
 */
class CubTree extends CubCdkTree {
    constructor() {
        super(...arguments);
        this._nodeOutlet = undefined;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTree, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CubTree, isStandalone: true, selector: "cub-tree", inputs: { size: "size" }, host: { properties: { "class.cub-small": "size === \"small\"" }, classAttribute: "cub-tree" }, providers: [{ provide: CubCdkTree, useExisting: CubTree }], viewQueries: [{ propertyName: "_nodeOutlet", first: true, predicate: CubTreeNodeOutlet, descendants: true, static: true }], exportAs: ["cubTree"], usesInheritance: true, ngImport: i0, template: `<ng-container cubTreeNodeOutlet></ng-container>`, isInline: true, dependencies: [{ kind: "directive", type: CubTreeNodeOutlet, selector: "[cubTreeNodeOutlet]" }], changeDetection: i0.ChangeDetectionStrategy.Default, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTree, decorators: [{
            type: Component,
            args: [{
                    selector: 'cub-tree',
                    exportAs: 'cubTree',
                    template: `<ng-container cubTreeNodeOutlet></ng-container>`,
                    host: {
                        class: 'cub-tree',
                        '[class.cub-small]': 'size === "small"',
                    },
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.Default,
                    providers: [{ provide: CubCdkTree, useExisting: CubTree }],
                    imports: [CubTreeNodeOutlet]
                }]
        }], propDecorators: { _nodeOutlet: [{
                type: ViewChild,
                args: [CubTreeNodeOutlet, { static: true }]
            }], size: [{
                type: Input
            }] } });

/**
 * Wrapper for the CdkTable with Cuberial design styles.
 */
class CubTreeNodeToggleIcon {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeToggleIcon, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubTreeNodeToggleIcon, isStandalone: true, selector: "cub-tree-node-toggle-icon", inputs: { isExpanded: "isExpanded" }, host: { classAttribute: "cub-tree-toggle-icon" }, ngImport: i0, template: "@if (isExpanded) {\n<span class=\"cub-icon-chevron-down\"></span>\n} @else {\n<span class=\"cub-icon-chevron-right\"></span>\n}\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeToggleIcon, decorators: [{
            type: Component,
            args: [{ selector: 'cub-tree-node-toggle-icon', host: {
                        class: 'cub-tree-toggle-icon',
                    }, template: "@if (isExpanded) {\n<span class=\"cub-icon-chevron-down\"></span>\n} @else {\n<span class=\"cub-icon-chevron-right\"></span>\n}\n" }]
        }], propDecorators: { isExpanded: [{
                type: Input
            }] } });

/**
 * Determinte if argument TreeKeyManager is the NoopTreeKeyManager. This function is safe to use with SSR.
 */
function isNoopTreeKeyManager(keyManager) {
    return !!keyManager._isNoopTreeKeyManager;
}
/**
 * activation 為 CubCdkTreeNode 的輸出事件，當樹狀節點被激活時觸發。
 * expandedChange 為 CubCdkTreeNode 的輸出事件，當樹狀節點的展開狀態改變時觸發。
 */
/**
 * Wrapper for the CubCdkTree node with Cuberial design styles.
 */
class CubTreeNode extends CubCdkTreeNode {
    /**
     * Whether the component is disabled.
     *
     * @deprecated This is an alias for `isDisabled`.
     * @breaking-change 21.0.0 Remove this input
     */
    /**
     * 樹狀節點是否被禁用，預設值為 false。
     */
    get disabled() {
        return this.isDisabled;
    }
    set disabled(value) {
        this.isDisabled = value;
    }
    /**
     * The tabindex of the tree node.
     *
     * @deprecated By default CubTreeNode manages focus using TreeKeyManager instead of tabIndex.
     *   Recommend to avoid setting tabIndex directly to prevent TreeKeyManager form getting into
     *   an unexpected state. Tabindex to be removed in a future version.
     * @breaking-change 21.0.0 Remove this attribute.
     */
    /**
     * 樹狀節點的 tabindex，預設值為 0。
     */
    get tabIndexInputBinding() {
        return this._tabIndexInputBinding;
    }
    set tabIndexInputBinding(value) {
        // If the specified tabIndex value is null or undefined, fall back to the default value.
        this._tabIndexInputBinding = value;
    }
    constructor() {
        super();
        /**
         * The default tabindex of the tree node.
         *
         * @deprecated By default CubTreeNode manages focus using TreeKeyManager instead of tabIndex.
         *   Recommend to avoid setting tabIndex directly to prevent TreeKeyManager form getting into
         *   an unexpected state. Tabindex to be removed in a future version.
         * @breaking-change 21.0.0 Remove this attribute.
         */
        this.defaultTabIndex = 0;
        this.el = inject(ElementRef);
        this.renderer = inject(Renderer2);
        const tabIndex = inject(new HostAttributeToken('tabindex'), {
            optional: true,
        });
        this.tabIndexInputBinding = Number(tabIndex) || this.defaultTabIndex;
    }
    // This is a workaround for https://github.com/angular/angular/issues/23091
    // In aot mode, the lifecycle hooks from parent class are not called.
    ngOnInit() {
        super.ngOnInit();
        const wrapBackground = this.renderer.createElement('div');
        wrapBackground.classList.add('cub-persistent-ripple');
        wrapBackground.classList.add('cub-tree-persistent-ripple');
        this.renderer.appendChild(this.el.nativeElement, wrapBackground);
    }
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    _getTabindexAttribute() {
        if (isNoopTreeKeyManager(this._tree._keyManager)) {
            return this.tabIndexInputBinding;
        }
        return this.tabIndexInputBinding;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNode, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubTreeNode, isStandalone: true, selector: "cub-tree-node", inputs: { appearance: "appearance", disabled: ["disabled", "disabled", booleanAttribute], tabIndexInputBinding: ["tabIndex", "tabIndexInputBinding", (value) => (value == null ? 0 : numberAttribute(value))] }, outputs: { activation: "activation", expandedChange: "expandedChange" }, host: { listeners: { "click": "_focusItem()" }, properties: { "attr.aria-expanded": "_getAriaExpanded()", "attr.aria-level": "level + 1", "attr.aria-posinset": "_getPositionInSet()", "attr.aria-setsize": "_getSetSize()", "tabindex": "_getTabindexAttribute()", "class.cub-tree-plain-text": "appearance === \"plain\"" }, classAttribute: "cub-tree-node" }, providers: [{ provide: CubCdkTreeNode, useExisting: CubTreeNode }], exportAs: ["cubTreeNode"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNode, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-tree-node',
                    exportAs: 'cubTreeNode',
                    outputs: ['activation', 'expandedChange'],
                    providers: [{ provide: CubCdkTreeNode, useExisting: CubTreeNode }],
                    host: {
                        class: 'cub-tree-node',
                        '[attr.aria-expanded]': '_getAriaExpanded()',
                        '[attr.aria-level]': 'level + 1',
                        '[attr.aria-posinset]': '_getPositionInSet()',
                        '[attr.aria-setsize]': '_getSetSize()',
                        '(click)': '_focusItem()',
                        '[tabindex]': '_getTabindexAttribute()',
                        '[class.cub-tree-plain-text]': 'appearance === "plain"',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { appearance: [{
                type: Input
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], tabIndexInputBinding: [{
                type: Input,
                args: [{
                        transform: (value) => (value == null ? 0 : numberAttribute(value)),
                        alias: 'tabIndex',
                    }]
            }] } });

/**
 * Wrapper for the CubCdkTree padding with Cuberial design styles.
 */
class CubTreeNodePadding extends CubCdkTreeNodePadding {
    /** The level of depth of the tree node. The padding will be `level * indent` pixels. */
    /**
     * 樹狀節點的深度級別。左側空間將是 `level * indent` 像素，預設值為 undefined。
     */
    get level() {
        return this._level;
    }
    set level(value) {
        this._setLevelInput(value);
    }
    /**
     * 樹狀節點每個級別的縮進。默認值為 40px，來自 cuberial 設計菜單子菜單規範。
     */
    get indent() {
        return this._indent;
    }
    set indent(indent) {
        this._setIndentInput(indent);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodePadding, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubTreeNodePadding, isStandalone: true, selector: "[cubTreeNodePadding]", inputs: { level: ["cubTreeNodePadding", "level", numberAttribute], indent: ["cubTreeNodePaddingIndent", "indent"] }, providers: [
            { provide: CubCdkTreeNodePadding, useExisting: CubTreeNodePadding },
        ], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodePadding, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTreeNodePadding]',
                    providers: [
                        { provide: CubCdkTreeNodePadding, useExisting: CubTreeNodePadding },
                    ],
                }]
        }], propDecorators: { level: [{
                type: Input,
                args: [{ alias: 'cubTreeNodePadding', transform: numberAttribute }]
            }], indent: [{
                type: Input,
                args: ['cubTreeNodePaddingIndent']
            }] } });

/**
 * Wrapper for the CubCdkTree's toggle with Cuberial design styles.
 */
/**
 * recursive 屬性用於控制是否遞歸切換子節點的狀態。
 * 當設置為 true 時，點擊節點將會切換該節點及其所有子節點的狀態。
 */
class CubTreeNodeToggle extends CubCdkTreeNodeToggle {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeToggle, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTreeNodeToggle, isStandalone: true, selector: "[cubTreeNodeToggle]", inputs: { recursive: ["cubTreeNodeToggleRecursive", "recursive"] }, providers: [
            { provide: CubCdkTreeNodeToggle, useExisting: CubTreeNodeToggle },
        ], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeToggle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTreeNodeToggle]',
                    providers: [
                        { provide: CubCdkTreeNodeToggle, useExisting: CubTreeNodeToggle },
                    ],
                    inputs: [{ name: 'recursive', alias: 'cubTreeNodeToggleRecursive' }],
                }]
        }] });

/**
 * Wrapper for the CubCdkTree nested node with Cuberial design styles.
 */
class CubNestedTreeNode extends CubCdkNestedTreeNode {
    /**
     * Whether the node is disabled.
     *
     * @deprecated This is an alias for `isDisabled`.
     * @breaking-change 21.0.0 Remove this input
     */
    /**
     * 樹狀節點是否被禁用，預設值為 false。
     */
    get disabled() {
        return this.isDisabled;
    }
    set disabled(value) {
        this.isDisabled = value;
    }
    /** Tabindex of the node. */
    /**
     * 樹狀節點的 tabindex，預設值為 0。
     * 如果節點被禁用，則 tabindex 為 -1。
     */
    get tabIndex() {
        return this.isDisabled ? -1 : this._tabIndex;
    }
    set tabIndex(value) {
        // If the specified tabIndex value is null or undefined, fall back to the default value.
        this._tabIndex = value;
    }
    // This is a workaround for https://github.com/angular/angular/issues/19145
    // In aot mode, the lifecycle hooks from parent class are not called.
    // TODO(tinayuangao): Remove when the angular issue #19145 is fixed
    ngOnInit() {
        super.ngOnInit();
    }
    ngAfterContentInit() {
        super.ngAfterContentInit();
    }
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNestedTreeNode, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "20.3.3", type: CubNestedTreeNode, isStandalone: true, selector: "cub-nested-tree-node", inputs: { node: ["cubNestedTreeNode", "node"], disabled: ["disabled", "disabled", booleanAttribute], tabIndex: ["tabIndex", "tabIndex", (value) => (value == null ? 0 : numberAttribute(value))] }, outputs: { activation: "activation", expandedChange: "expandedChange" }, host: { classAttribute: "cub-nested-tree-node" }, providers: [
            { provide: CubCdkNestedTreeNode, useExisting: CubNestedTreeNode },
            { provide: CubCdkTreeNode, useExisting: CubNestedTreeNode },
            { provide: CUB_CDK_TREE_NODE_OUTLET_NODE, useExisting: CubNestedTreeNode },
        ], exportAs: ["cubNestedTreeNode"], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubNestedTreeNode, decorators: [{
            type: Directive,
            args: [{
                    selector: 'cub-nested-tree-node',
                    exportAs: 'cubNestedTreeNode',
                    outputs: ['activation', 'expandedChange'],
                    providers: [
                        { provide: CubCdkNestedTreeNode, useExisting: CubNestedTreeNode },
                        { provide: CubCdkTreeNode, useExisting: CubNestedTreeNode },
                        { provide: CUB_CDK_TREE_NODE_OUTLET_NODE, useExisting: CubNestedTreeNode },
                    ],
                    host: {
                        class: 'cub-nested-tree-node',
                    },
                }]
        }], propDecorators: { node: [{
                type: Input,
                args: ['cubNestedTreeNode']
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], tabIndex: [{
                type: Input,
                args: [{
                        transform: (value) => (value == null ? 0 : numberAttribute(value)),
                    }]
            }] } });

/**
 * Wrapper for the CubCdkTree node definition with Cuberial design styles.
 * Captures the node's template and a when predicate that describes when this node should be used.
 */
/**
 * 樹狀節點定義的指令，使用 Cuberial 設計樣式，預設值為 undefined。
 */
class CubTreeNodeDef extends CubCdkTreeNodeDef {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeDef, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubTreeNodeDef, isStandalone: true, selector: "[cubTreeNodeDef]", inputs: { when: ["cubTreeNodeDefWhen", "when"], data: ["cubTreeNode", "data"] }, providers: [{ provide: CubCdkTreeNodeDef, useExisting: CubTreeNodeDef }], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeNodeDef, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubTreeNodeDef]',
                    inputs: [{ name: 'when', alias: 'cubTreeNodeDefWhen' }],
                    providers: [{ provide: CubCdkTreeNodeDef, useExisting: CubTreeNodeDef }],
                }]
        }], propDecorators: { data: [{
                type: Input,
                args: ['cubTreeNode']
            }] } });

class CubTreeFlattener {
    constructor(transformFunction, getLevel, isExpandable, getChildren) {
        this.transformFunction = transformFunction;
        this.getLevel = getLevel;
        this.isExpandable = isExpandable;
        this.getChildren = getChildren;
    }
    _flattenNode(node, level, resultNodes, parentMap) {
        const flatNode = this.transformFunction(node, level);
        resultNodes.push(flatNode);
        if (this.isExpandable(flatNode)) {
            const childrenNodes = this.getChildren(node);
            if (childrenNodes) {
                if (Array.isArray(childrenNodes)) {
                    this._flattenChildren(childrenNodes, level, resultNodes, parentMap);
                }
                else {
                    childrenNodes.pipe(take(1)).subscribe((children) => {
                        this._flattenChildren(children, level, resultNodes, parentMap);
                    });
                }
            }
        }
        return resultNodes;
    }
    _flattenChildren(children, level, resultNodes, parentMap) {
        children.forEach((child, index) => {
            const childParentMap = parentMap.slice();
            childParentMap.push(index != children.length - 1);
            this._flattenNode(child, level + 1, resultNodes, childParentMap);
        });
    }
    /**
     * Flatten a list of node type T to flattened version of node F.
     * Please note that type T may be nested, and the length of `structuredData` may be different
     * from that of returned list `F[]`.
     */
    flattenNodes(structuredData) {
        const resultNodes = [];
        structuredData.forEach((node) => this._flattenNode(node, 0, resultNodes, []));
        return resultNodes;
    }
    /**
     * Expand flattened node with current expansion status.
     * The returned list may have different length.
     */
    expandFlattenedNodes(nodes, treeControl) {
        const results = [];
        const currentExpand = [];
        currentExpand[0] = true;
        nodes.forEach((node) => {
            let expand = true;
            for (let i = 0; i <= this.getLevel(node); i++) {
                expand = expand && currentExpand[i];
            }
            if (expand) {
                results.push(node);
            }
            if (this.isExpandable(node)) {
                currentExpand[this.getLevel(node) + 1] = treeControl.isExpanded(node);
            }
        });
        return results;
    }
}
class CubTreeFlatDataSource extends DataSource {
    get data() {
        return this._data.value;
    }
    set data(value) {
        this._data.next(value);
        this._flattenedData.next(this._treeFlattener.flattenNodes(this.data));
        this._treeControl.dataNodes = this._flattenedData.value;
    }
    constructor(_treeControl, _treeFlattener, initialData) {
        super();
        this._treeControl = _treeControl;
        this._treeFlattener = _treeFlattener;
        this._data = new BehaviorSubject([]);
        this._flattenedData = new BehaviorSubject([]);
        this._expandedData = new BehaviorSubject([]);
        if (initialData) {
            // Assign the data through the constructor to ensure that all of the logic is executed.
            this.data = initialData;
        }
    }
    connect(collectionViewer) {
        return merge(collectionViewer.viewChange, this._treeControl.expansionModel.changed, this._flattenedData).pipe(map(() => {
            this._expandedData.next(this._treeFlattener.expandFlattenedNodes(this._flattenedData.value, this._treeControl));
            return this._expandedData.value;
        }));
    }
    disconnect() {
        // no op
    }
}
class CubTreeNestedDataSource extends DataSource {
    constructor() {
        super(...arguments);
        this._data = new BehaviorSubject([]);
    }
    /**
     * Data for the nested tree
     */
    get data() {
        return this._data.value;
    }
    set data(value) {
        this._data.next(value);
    }
    connect(collectionViewer) {
        return merge(...[collectionViewer.viewChange, this._data]).pipe(map(() => this.data));
    }
    disconnect() {
        // no op
    }
}

const CUB_TREE_DIRECTIVES = [
    CubNestedTreeNode,
    CubTreeNodeDef,
    CubTreeNodePadding,
    CubTreeNodeToggle,
    CubTree,
    CubTreeNode,
    CubTreeNodeOutlet,
    CubTreeNodeToggleIcon,
];
class CubTreeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubTreeModule, imports: [CubNestedTreeNode,
            CubTreeNodeDef,
            CubTreeNodePadding,
            CubTreeNodeToggle,
            CubTree,
            CubTreeNode,
            CubTreeNodeOutlet,
            CubTreeNodeToggleIcon], exports: [CubNestedTreeNode,
            CubTreeNodeDef,
            CubTreeNodePadding,
            CubTreeNodeToggle,
            CubTree,
            CubTreeNode,
            CubTreeNodeOutlet,
            CubTreeNodeToggleIcon] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubTreeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...CUB_TREE_DIRECTIVES],
                    exports: [CUB_TREE_DIRECTIVES],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/tree
 */
/* 參考來源：https://github.com/angular/components/tree/19.2.1/src/material/tree */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubNestedTreeNode, CubTree, CubTreeFlatDataSource, CubTreeFlattener, CubTreeModule, CubTreeNestedDataSource, CubTreeNode, CubTreeNodeDef, CubTreeNodeOutlet, CubTreeNodePadding, CubTreeNodeToggle, CubTreeNodeToggleIcon };
//# sourceMappingURL=cub-lib-view-rootng-component-tree.mjs.map
