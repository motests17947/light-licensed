import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, ViewChild, Output, Input, Component, NgModule } from '@angular/core';
import { FormControl, NgControl, NG_VALUE_ACCESSOR, NG_VALIDATORS } from '@angular/forms';
import { Subject } from 'rxjs';
import { CubPrefix } from 'cub-lib-view-rootng/component/common';
import { CubLoading } from 'cub-lib-view-rootng/component/loading';
import { CubButton } from 'cub-lib-view-rootng/component/button';
import { CubFormFieldControl, CubFormFieldModule } from 'cub-lib-view-rootng/component/form-field';
import { CubLabelModule } from 'cub-lib-view-rootng/component/label';

class CubUpload {
    static { this.nextId = 0; }
    get value() {
        return this._value;
    }
    set value(files) {
        this._value = files || [];
        this.onChange(this._value);
        this.stateChanges.next();
    }
    get empty() {
        return this._value.length === 0;
    }
    /**
     * 暫存的檔案清單，預設為 []。
     * 使用 FormControl 來管理值。
     */
    get files() {
        return this._value;
    }
    set files(value) {
        if (this.ngControl) {
            this.value = value || [];
        }
        else {
            this.validate(new FormControl(value || []));
        }
        this.onChange(this._value);
        this.stateChanges.next();
    }
    /**
     * 元件是否禁用，預設為 false。
     */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = value;
        this.stateChanges.next();
    }
    /**
     * 可選擇的檔案類型，例如: ['image/jpeg', 'image/png']，
     * 參數 null 表示不限制檔案類型，預設為 null。
     */
    get acceptableMimeTypes() {
        return this._acceptableMimeTypes;
    }
    set acceptableMimeTypes(types) {
        if (!types) {
            return;
        }
        this._acceptableMimeTypes = types;
        this.accept = types.join(',');
    }
    constructor(injector) {
        this.injector = injector;
        this.controlType = 'cub-upload';
        this.id = `cub-upload-${CubUpload.nextId++}`;
        this.stateChanges = new Subject();
        this.focused = false;
        this.errorState = false;
        this.required = false;
        this.placeholder = '';
        this.describedBy = '';
        this.dragging = false;
        this.accept = null;
        this._value = [];
        this._disabled = false;
        this._acceptableMimeTypes = [];
        /**
         * 元件的視覺樣式選擇，預設為 'area'。
         */
        this.appearance = 'area';
        /**
         * 限制最大檔案大小，單位為位元組(byte) 如: 5 * 1024 * 1024 (5MB)。
         * 參數 null 表示不限制檔案大小，預設為 null。
         */
        this.maxFileSize = null;
        /**
         * Upload Area 元件的主標題文字，預設為 '點擊或拖曳檔案來上傳'。
         */
        this.label = '點擊或拖曳檔案來上傳';
        /**
         * Upload Button 元件按鈕上的文字，預設為 '檔案上傳'。
         */
        this.uploadLabel = '檔案上傳';
        /**
         * 未選取檔案時顯示的說明文字，預設為 ''。
         */
        this.description = '';
        /**
         * 是否允許選擇多個檔案，預設為 false。
         */
        this.multiple = false;
        /**
         * 設定 loading 狀態，預設為 false。
         */
        this.loading = false;
        /**
         * 表示想由外部來告知元件需要顯示錯誤樣式，預設為 false。
         */
        this.hasError = false;
        /**
         * 檢查檔案格式、檔案大小的成功事件通知。
         */
        this.validationSuccess = new EventEmitter();
        /**
         * 檢查檔案格式、檔案大小的錯誤事件通知。
         */
        this.validationFailed = new EventEmitter();
        // ControlValueAccessor callbacks
        this.onChange = (value) => { };
        this.onTouched = () => { };
    }
    ngOnInit() {
        // 取得 NgControl 實例來檢查 form 狀態
        try {
            this.ngControl = this.injector.get(NgControl, null);
            if (this.ngControl && 'valueAccessor' in this.ngControl) {
                this.ngControl.valueAccessor = this;
            }
        }
        catch { }
    }
    ngOnDestroy() {
        this.stateChanges.complete();
    }
    // ControlValueAccessor implementation
    writeValue(value) {
        this._value = value || [];
        this.stateChanges.next();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled = isDisabled;
        this.stateChanges.next();
    }
    setDescribedByIds(ids) {
        this.describedBy = ids.join(' ');
    }
    onContainerClick(event) {
        if (!this.disabled && !this.loading) {
            this.fileUploder.nativeElement.click();
        }
    }
    // Validator implementation
    validate(control) {
        const files = control.value;
        if (!files || files.length === 0) {
            return null; // 讓 required validator 處理必填驗證
        }
        let validFiles = [];
        const errors = {};
        let validationErrors = [];
        if (!this.multiple && files.length > 1) {
            // 設定僅允許傳單筆檔案
            validationErrors = [
                ...validationErrors,
                {
                    errorTypes: ['multipleNotAllowed'],
                },
            ];
        }
        else {
            for (const file of files) {
                const isInvalidFileType = !this.isFileTypeAccepted(file);
                const isOversizedFile = this.maxFileSize === null ? false : file.size > this.maxFileSize;
                let error = {
                    file: undefined,
                    errorTypes: [],
                };
                // 驗證檔案類型
                if (isInvalidFileType) {
                    error = {
                        file: file,
                        errorTypes: ['invalidMimeType'],
                    };
                }
                // 驗證檔案大小
                if (isOversizedFile) {
                    if (error.errorTypes.length > 0) {
                        error.errorTypes = [...error.errorTypes, 'exceedsMaxSize'];
                    }
                    else {
                        error = {
                            file: file,
                            errorTypes: ['exceedsMaxSize'],
                        };
                    }
                }
                // 更新檔案類型、檔案大小的錯誤
                if (error.errorTypes.length > 0) {
                    validationErrors = [...validationErrors, error];
                }
                else {
                    validFiles = [...validFiles, file];
                }
            }
        }
        if (validationErrors.length > 0) {
            errors['fileValidation'] = validationErrors;
            this.errorState = true;
            // 發出檢查錯誤事件
            setTimeout(() => {
                this.validationFailed.emit(validationErrors);
            });
        }
        else {
            this.errorState = false;
            // 發出檢查錯誤事件
            setTimeout(() => {
                this.validationFailed.emit([]);
            });
        }
        if (validFiles.length > 0) {
            // 發出檢查成功事件
            setTimeout(() => {
                this.validationSuccess.emit(validFiles);
            });
        }
        else {
            // 發出檢查成功事件
            setTimeout(() => {
                this.validationSuccess.emit([]);
            });
        }
        return Object.keys(errors).length > 0 ? errors : null;
    }
    /**
     * 判斷檔案是否符合接受的格式
     */
    isFileTypeAccepted(file) {
        // 如果初始化時沒有設置 acceptableMimeTypes，表示默認全部接受
        if (this.acceptableMimeTypes.length === 0) {
            return true;
        }
        // 檢查 MIME 類型
        if (this.acceptableMimeTypes.includes(file.type)) {
            return true;
        }
        return false;
    }
    /**
     * 清空輸入框
     */
    reset() {
        this.fileUploder.nativeElement.value = null;
        this.value = [];
        this.onTouched();
    }
    /**
     * 以選擇的方式上傳檔案
     */
    chooseFile(event) {
        const files = Array.from(event.target.files || []);
        if (this.ngControl) {
            this.value = [...files];
        }
        else {
            this.validate(new FormControl([...files]));
        }
        this.onTouched();
    }
    /**
     * 以拖拉的方式上傳檔案
     */
    dropFile(event) {
        event.preventDefault();
        event.stopPropagation();
        this.dragging = false;
        const files = Array.from(event.dataTransfer.files || []);
        if (this.ngControl) {
            this.value = [...files];
        }
        else {
            this.validate(new FormControl([...files]));
        }
        this.onTouched();
    }
    /**
     * 拉進去樣式
     */
    dragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        this.dragging = true;
    }
    /**
     * 拉出去樣式
     */
    dragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this.dragging = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubUpload, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.3", type: CubUpload, isStandalone: true, selector: "cub-upload", inputs: { files: "files", disabled: "disabled", appearance: "appearance", acceptableMimeTypes: "acceptableMimeTypes", maxFileSize: "maxFileSize", label: "label", uploadLabel: "uploadLabel", description: "description", multiple: "multiple", loading: "loading", hasError: "hasError" }, outputs: { validationSuccess: "validationSuccess", validationFailed: "validationFailed" }, host: { classAttribute: "cub-upload" }, providers: [
            {
                provide: CubFormFieldControl,
                useExisting: CubUpload,
            },
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CubUpload),
                multi: true,
            },
            {
                provide: NG_VALIDATORS,
                useExisting: forwardRef(() => CubUpload),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "fileUploder", first: true, predicate: ["fileUploder"], descendants: true }], exportAs: ["cubUpload"], ngImport: i0, template: "@if (appearance === 'area') {\n<label\n  tabindex=\"0\"\n  class=\"cub-upload-area\"\n  [class.cub-upload-area-error]=\"errorState || hasError\"\n  [class.cub-disabled]=\"disabled\"\n  [class.dragging]=\"dragging\"\n  [class.loading]=\"loading\"\n  (dragover)=\"dragOver($event)\"\n  (dragleave)=\"dragLeave($event)\"\n  (drop)=\"dropFile($event)\"\n  (click)=\"fileUploder.click()\"\n  (keydown.enter)=\"fileUploder.click()\"\n>\n  @if (loading) {\n  <cub-loading [size]=\"'large'\" [hasBackdrop]=\"true\"></cub-loading>\n  }\n  <div class=\"cub-upload-area-content\">\n    <div class=\"cub-upload-area-prompt\">\n      <span class=\"cub-upload-area-icon cub-icon-cloud-arrow-up\"></span>\n      <span class=\"cub-upload-area-label\">{{ label }}</span>\n    </div>\n    @if (description) {\n    <div class=\"cub-upload-area-description\">{{ description }}</div>\n    }\n  </div>\n</label>\n} @else if ( appearance === 'button' || appearance === 'button-small' ) {\n<div\n  class=\"cub-upload-button-description\"\n  [class.cub-upload-button-description-small]=\"appearance === 'button-small'\"\n>\n  {{ description }}\n</div>\n<button\n  class=\"cub-upload-button\"\n  cub-button\n  type=\"button\"\n  color=\"brand\"\n  appearance=\"outline\"\n  [size]=\"appearance === 'button' ? 'medium' : 'small'\"\n  [disabled]=\"disabled\"\n  [loading]=\"loading\"\n  (click)=\"fileUploder.click()\"\n>\n  <span cubPrefix class=\"cub-icon-arrow-up-from-bracket\"></span>\n  {{ uploadLabel }}\n</button>\n}\n<input\n  hidden\n  type=\"file\"\n  [accept]=\"accept || false\"\n  [multiple]=\"multiple\"\n  [disabled]=\"disabled || loading\"\n  (change)=\"chooseFile($event)\"\n  #fileUploder\n/>\n", styles: [""], dependencies: [{ kind: "component", type: CubLoading, selector: "cub-loading", inputs: ["color", "size", "fullScreen", "hasBackdrop"] }, { kind: "component", type: CubButton, selector: "button[cub-button]", inputs: ["disabled", "disableRipple", "color", "appearance", "block", "withMinWidth"], exportAs: ["cubButton"] }, { kind: "directive", type: CubPrefix, selector: "[cubPrefix]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubUpload, decorators: [{
            type: Component,
            args: [{ selector: 'cub-upload', exportAs: 'cubUpload', host: {
                        class: 'cub-upload',
                    }, providers: [
                        {
                            provide: CubFormFieldControl,
                            useExisting: CubUpload,
                        },
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CubUpload),
                            multi: true,
                        },
                        {
                            provide: NG_VALIDATORS,
                            useExisting: forwardRef(() => CubUpload),
                            multi: true,
                        },
                    ], imports: [CubLoading, CubButton, CubPrefix], template: "@if (appearance === 'area') {\n<label\n  tabindex=\"0\"\n  class=\"cub-upload-area\"\n  [class.cub-upload-area-error]=\"errorState || hasError\"\n  [class.cub-disabled]=\"disabled\"\n  [class.dragging]=\"dragging\"\n  [class.loading]=\"loading\"\n  (dragover)=\"dragOver($event)\"\n  (dragleave)=\"dragLeave($event)\"\n  (drop)=\"dropFile($event)\"\n  (click)=\"fileUploder.click()\"\n  (keydown.enter)=\"fileUploder.click()\"\n>\n  @if (loading) {\n  <cub-loading [size]=\"'large'\" [hasBackdrop]=\"true\"></cub-loading>\n  }\n  <div class=\"cub-upload-area-content\">\n    <div class=\"cub-upload-area-prompt\">\n      <span class=\"cub-upload-area-icon cub-icon-cloud-arrow-up\"></span>\n      <span class=\"cub-upload-area-label\">{{ label }}</span>\n    </div>\n    @if (description) {\n    <div class=\"cub-upload-area-description\">{{ description }}</div>\n    }\n  </div>\n</label>\n} @else if ( appearance === 'button' || appearance === 'button-small' ) {\n<div\n  class=\"cub-upload-button-description\"\n  [class.cub-upload-button-description-small]=\"appearance === 'button-small'\"\n>\n  {{ description }}\n</div>\n<button\n  class=\"cub-upload-button\"\n  cub-button\n  type=\"button\"\n  color=\"brand\"\n  appearance=\"outline\"\n  [size]=\"appearance === 'button' ? 'medium' : 'small'\"\n  [disabled]=\"disabled\"\n  [loading]=\"loading\"\n  (click)=\"fileUploder.click()\"\n>\n  <span cubPrefix class=\"cub-icon-arrow-up-from-bracket\"></span>\n  {{ uploadLabel }}\n</button>\n}\n<input\n  hidden\n  type=\"file\"\n  [accept]=\"accept || false\"\n  [multiple]=\"multiple\"\n  [disabled]=\"disabled || loading\"\n  (change)=\"chooseFile($event)\"\n  #fileUploder\n/>\n" }]
        }], ctorParameters: () => [{ type: i0.Injector }], propDecorators: { files: [{
                type: Input
            }], disabled: [{
                type: Input
            }], appearance: [{
                type: Input
            }], acceptableMimeTypes: [{
                type: Input
            }], maxFileSize: [{
                type: Input
            }], label: [{
                type: Input
            }], uploadLabel: [{
                type: Input
            }], description: [{
                type: Input
            }], multiple: [{
                type: Input
            }], loading: [{
                type: Input
            }], hasError: [{
                type: Input
            }], validationSuccess: [{
                type: Output
            }], validationFailed: [{
                type: Output
            }], fileUploder: [{
                type: ViewChild,
                args: ['fileUploder']
            }] } });

class CubUploadModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubUploadModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubUploadModule, imports: [CubFormFieldModule, CubLabelModule, CubUpload], exports: [CubFormFieldModule, CubLabelModule, CubUpload] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubUploadModule, imports: [CubFormFieldModule, CubLabelModule, CubUpload, CubFormFieldModule, CubLabelModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubUploadModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubFormFieldModule, CubLabelModule, CubUpload],
                    exports: [CubFormFieldModule, CubLabelModule, CubUpload],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/upload
 */
/* Component */

/**
 * Generated bundle index. Do not edit.
 */

export { CubUpload, CubUploadModule };
//# sourceMappingURL=cub-lib-view-rootng-component-upload.mjs.map
