import * as i0 from '@angular/core';
import { ElementRef, Input, Directive, NgModule } from '@angular/core';

class WatermarkHandler {
    constructor(elementRef, renderer) {
        this.DEFAULT_OPTIONS = {
            text: '',
            width: 400,
            height: 320,
            fontFamily: 'CubFont,sans-serif',
            fontSize: '28px',
            fontWeight: 'normal',
            color: '#BDBDBD',
            alpha: 0.2,
            degree: -30,
            lineHeight: 36,
            textAlign: 'center',
            textBaseline: 'bottom',
            backgroundRepeat: 'repeat',
            backgroundPosition: '0% 0%',
        };
        this.elementRef = elementRef;
        this.renderer = renderer;
    }
    generateWatermark(options) {
        const watermarkOptions = Object.assign({}, this.DEFAULT_OPTIONS, options);
        this.processStyleFromOptions(watermarkOptions);
    }
    processStyleFromOptions(options) {
        this.setHTMLElementStyle([
            'background-image',
            `url(${this.createDataUrl(options)})`,
        ]);
        if (options.backgroundRepeat && options.backgroundPosition) {
            this.setHTMLElementStyle(['background-repeat', options.backgroundRepeat]);
            this.setHTMLElementStyle([
                'background-position',
                options.backgroundPosition,
            ]);
        }
    }
    createDataUrl(options) {
        const width = options.width;
        const height = options.height;
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (width &&
            height !== undefined &&
            ctx !== null &&
            options !== undefined) {
            canvas.width = width;
            canvas.height = height;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.globalAlpha = 0;
            ctx.fillRect(-0.5 * width, -0.5 * height, width, height);
            ctx.font = `${options.fontWeight} ${options.fontSize} ${options.fontFamily}`;
            ctx.fillStyle = options.color;
            ctx.globalAlpha = options.alpha;
            if (options.textAlign !== undefined) {
                ctx.textAlign = options.textAlign;
            }
            if (options.textBaseline !== undefined) {
                ctx.textBaseline = options.textBaseline;
            }
            ctx.translate(0.5 * width, 0.5 * height);
            ctx.rotate((options.degree * Math.PI) / 180);
            if (options.text !== undefined && options.lineHeight !== undefined) {
                this.generateMultiLineText(ctx, options.text, options.lineHeight, 0, 0);
            }
        }
        return canvas.toDataURL();
    }
    generateMultiLineText(ctx, text, lineHeight, xAxis, yAxis) {
        let words = text.split('\n');
        let line = '';
        for (let index = 0; index < words.length; index++) {
            line = words[index];
            ctx.fillText(line, xAxis, yAxis);
            yAxis += lineHeight;
        }
    }
    setHTMLElementStyle([name, value]) {
        this.renderer.setStyle(this.elementRef.nativeElement, name, value);
    }
}

const CubWatermarkSmallSizeOptions = {
    width: 240,
    height: 200,
    fontSize: '20px',
    lineHeight: 28,
    text: '00587000 姓Ｏ名\n 2021/05/13 13:00',
};
const CubWatermarkMediumSizeOptions = {
    width: 400,
    height: 320,
    fontSize: '28px',
    lineHeight: 36,
    text: '00587000 姓Ｏ名\n 2021/05/13 13:00',
};

class CubWatermark {
    constructor(elementRef, renderer) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        /** 是否螢幕滿版顯示。 false 表示僅在使用的 HTML Tag 內顯示。 預設為 false */
        this.fullscreen = false;
        /** 元件尺寸，預設為 'medium' */
        this.size = 'medium';
        /** 元件透明度，預設為 0.2 */
        this.alpha = 0.2;
        /** 元件內文，預設為 '00587000 姓Ｏ名\n 2025/05/13 13:00' */
        this.text = '00587000 姓Ｏ名\n 2025/05/13 13:00';
        this.renderer.setStyle(this.elementRef.nativeElement, 'position', 'relative');
        this.watermark = this.renderer.createElement('div');
        this.renderer.addClass(this.watermark, 'cub-watermark');
        this.watermarkHandler = new WatermarkHandler(new ElementRef(this.watermark), this.renderer);
    }
    ngOnChanges() {
        const { alpha, text, fullscreen } = this;
        if (fullscreen) {
            this.fullscreenState();
        }
        else {
            this.normalState();
        }
        switch (this.size) {
            case 'medium':
                this.watermarkHandler.generateWatermark({
                    ...CubWatermarkMediumSizeOptions,
                    alpha,
                    text,
                });
                break;
            case 'small':
                this.watermarkHandler.generateWatermark({
                    ...CubWatermarkSmallSizeOptions,
                    alpha,
                    text,
                });
                break;
            default:
                this.watermarkHandler.generateWatermark({
                    ...CubWatermarkMediumSizeOptions,
                    alpha,
                    text,
                });
        }
    }
    ngOnDestroy() {
        this.clear();
    }
    normalState() {
        this.renderer.removeClass(this.watermark, 'cub-watermark-fullscreen');
        const container = this.elementRef.nativeElement;
        this.renderer.appendChild(container, this.watermark);
    }
    fullscreenState() {
        this.renderer.addClass(this.watermark, 'cub-watermark-fullscreen');
        const container = document.querySelector('.cub-layout-overlay-container');
        this.renderer.appendChild(container, this.watermark);
    }
    clear() {
        if (this.fullscreen) {
            const container = document.querySelector('.cub-layout-overlay-container');
            this.renderer.removeChild(container, this.watermark);
        }
        else {
            const container = this.elementRef.nativeElement;
            this.renderer.removeChild(container, this.watermark);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubWatermark, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.3", type: CubWatermark, isStandalone: true, selector: "[cubWatermark]", inputs: { fullscreen: ["cubWatermarkFullscreen", "fullscreen"], size: ["cubWatermarkSize", "size"], alpha: ["cubWatermarkAlpha", "alpha"], text: ["cubWatermark", "text"] }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubWatermark, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cubWatermark]',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { fullscreen: [{
                type: Input,
                args: ['cubWatermarkFullscreen']
            }], size: [{
                type: Input,
                args: ['cubWatermarkSize']
            }], alpha: [{
                type: Input,
                args: ['cubWatermarkAlpha']
            }], text: [{
                type: Input,
                args: ['cubWatermark']
            }] } });

class CubWatermarkModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubWatermarkModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CubWatermarkModule, imports: [CubWatermark], exports: [CubWatermark] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubWatermarkModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CubWatermarkModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CubWatermark],
                    exports: [CubWatermark],
                }]
        }] });

/*
 * Public API Surface of cub-lib-view-rootng/component/watermark
 */
/* Directive */

/**
 * Generated bundle index. Do not edit.
 */

export { CubWatermark, CubWatermarkModule, WatermarkHandler };
//# sourceMappingURL=cub-lib-view-rootng-component-watermark.mjs.map
