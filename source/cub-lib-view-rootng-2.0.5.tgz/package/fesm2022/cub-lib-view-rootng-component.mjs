import { Version } from '@angular/core';

/*
 * Public API Surface of cub-lib-view-rootng/component
 */
const VERSION = new Version('2.0.5');

/**
 * Generated bundle index. Do not edit.
 */

export { VERSION };
//# sourceMappingURL=cub-lib-view-rootng-component.mjs.map
