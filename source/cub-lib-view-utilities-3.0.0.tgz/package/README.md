# CUB Design Guideline Utilities

這是由 UXD 小組所建立的前端通用樣式展示頁面。

## 編譯 SCSS 檔案

1. 專案資料夾下執行指令 `npm install` 安裝專案使用套件
2. 執行指令 `npm run watch` 監聽並編譯 SCSS 檔案

## 版本更動紀錄

### v1.0.0 20210525

- 新增 **Reset** 樣式重置設定
- 新增 **Font Face** 字體設定
- 新增 **Typography** 文字樣式
- 新增 **Variables** 共用變數
  - **Colors**：主要色票與文字、邊框、背景的顏色設定。
  - **Images**：元件內所使用的 base64 圖片。
  - **Animation**：常用動畫速度設定。
  - **Breakpoint**：響應式網頁的斷點設定。
- 新增 **Utilities** 共用樣式
  - **Color**：包括文字、邊框、背景的顏色樣式。
  - **Spacing**：Margin 與 Padding 的間距處理。
  - **Text**：控制文字的大小、粗細、對齊、換行等處理。
  - **Overflow**：控制內容溢出元素的處理。
- 新增 **Images** 共用圖片
  - **Error**：錯誤頁面顯示用的一系列圖片。
  - **Logo**：國泰世華銀行白底 LOGO。

### v1.1.0 20210625

- **Variables** 共用變數
  - **Images** 新增 1 個 base64 圖片：`$cub-img-alarm`。
- **Typography** 文字樣式
  - 將 `.cub-title` 字體尺寸由 `24px` 改為 `22px`。
  - 將 `h1` 與 `.cub-h1` 字體尺寸由 `28px` 改為 `22px`。
  - 將 `h2` 與 `.cub-h2` 字體尺寸由 `24px` 改為 `20px`。
- **Images** 共用圖片
  - 圖片命名統一加上 `cub` 前綴，並改為依 **Snake Case** 規則命名。
  - 為增加通用性，原先 **Error** 系列圖片名稱移除 **error** 單字。
  - 新增 1 張 **Logo**：國泰世華銀行白底含中英文名稱 LOGO（`cub_logo_cathay_bank_zh_en.svg`）。
  - 新增 3 張共用圖片：**PhoneSecret**、**Report**、**Success**。

### v1.1.1 20210729

- **Variables** 共用變數
  - `$cub-grid-breakpoint` 內 `xl` 參數修改為 `1440`。

### v1.1.2 20210901

- **Variables** 共用變數
  - **Color**：
    - 新增色票： `$cub-primary-pale: #95EBB3`。
    - 調整色票，將 `$cub-primary-overlay` 透明度由 `0.4` 調整成 `0.7`。
    - 調整色票，將 `$cub-danger-overlay` 透明度由 `0.4` 調整成 `0.7`。
  - **Images**：
    - 新增 2 個 base64 圖片：`$cub-img-caret-up`、`$cub-img-caret-down`。

### v1.1.3 20210917

- **Variables** 共用變數
  - **Images**：更新 5 個 base64 圖片。
    - `$cub-img-close`：將 `neutral-main-bright`、`neutral-main-pale` 換成 `40*40` 尺寸圖片，並移除 `size_40_m` 圖片。
    - `$cub-img-search`：將 `neutral-main-bright`、`neutral-main-pale`、`primary` 換成 `14*14` 尺寸圖片。
    - `$cub-img-copy`：將 `neutral-main-bright`、`neutral-main-pale` 換成 `14*14` 尺寸圖片。
    - `$cub-img-check`：將 `neutral-main-bright` 換成 `26*26` 尺寸圖片。
    - `$cub-img-caret-left`：將 `neutral-main-bright`、`primary-light` 換成 `32*32` 尺寸圖片。
    - `$cub-img-caret-right`：將 `neutral-main-bright`、`primary-light` 換成 `32*32` 尺寸圖片。
- **Typography** 文字樣式
  - 新增 `h4` ~ `h6` 與 `.cub-h4` ~ `.cub-h6` 字體尺寸

### v1.2.0 20211025

#### 重大改動 - 主題樣式設定

- **主題樣式設定（SCSS）**：所有元件新增 **SCSS 變數設定檔**，將樣式設定改由透過 **SCSS 變數**設定調整，可自訂**元件主題樣式**。

  > 貼心小提醒：
  >
  > - 元件樣式的引用方式不變，僅是額外提供客製主題樣式的設定方式。
  > - 元件內可提供調整的細節，請查看各元件檔案內的註解說明。

- **圖檔（Base64 Images）**：更新 **Base64 Images** 圖檔並調整圖檔名稱，名稱將包含圖片尺寸。使用方式參考以下：

  - 重構前

    ```SCSS
    background-image: url(map-get($image-name, 'color'));

    /* 以 Search Icon 為例 */
    background-image: url(map-get($cub-img-search, 'neutral-main-bright'));
    ```

  - 重構後

    ```SCSS
    background-image: base64-svg($image-name, $color);

    /* 以 Search Icon 為例 */
    background-image: base64-svg($cub-img-search-14, $cub-neutral-main-bright);
    ```

#### 元件調整

- **Variables** 共用變數
  - 新增 **Color Swatches**：將主要色票由 **Color** 檔案抽出為獨立的色票檔案。
  - 新增 **Common**：全網站統一的共用樣式設定，例如：遮罩背景顏色、Scrollbar 等。
- 新增 **Functions** 共用函式：主要以圖片處理為主。

### v1.3.0 20211117

- **Variables** 共用變數
  - **Images**：
    - 新增 4 個 base64 圖片：`$cub-img-chevron-left-24`、`$cub-img-chevron-right-24`、`$cub-img-dot-18`、`$cub-img-alert-circle-18`。
- **Images** 共用圖片
  - 新增 1 張共用圖片：**Notice Horizontal**。

### v1.4.0 20220315

- **Variables** 共用變數
  - **Images**：
    - 新增 2 個 base64 圖片：`$cub-img-chevron-up-24`、`$cub-img-chevron-down-24`。
    - 修正 2 個 base64 圖片在 IE 的顯示問題：`$cub-img-alert-18`、`$cub-img-alert-red-18`。
- **Images** 共用圖片
  - 新增 3 張 **Logo**：國泰世華銀行（`logo_cub_zh_en.svg`）、國泰金控（`logo_ch_zh_en.svg`）、國泰產險（`logo_cci_zh_en.svg`）。
  - 新增 1 張共用圖片：**Login Background**。
- **Typography** 文字樣式
  - 新增標題樣式：`.cub-title-h1` ~ `.cub-title-h6`。
  - 調整文字行高：預設為 1.5 行高，標題則為 1.2 行高。
- **Utilities** 共用樣式
  - 新增 **Images**：設定常用的 base64 圖片樣式（`.cub-img-alert`、`.cub-img-alert-red`、`.cub-img-alert-circle`、`.cub-img-alarm`）。
  - 新增 **List**：**Ordered List**、**Unordered List**。

### v1.5.0 20220325

- **Typography** 文字樣式
  - 調整**標題**變數設定：將**字體粗細**與**文字顏色**加入可調整變數。
- **Utilities** 共用樣式
  - 新增 **Ordered List** 樣式：新增 small 與 large 兩種文字級距樣式。
  - 新增 **Unordered List** 樣式：新增 small 與 large 兩種文字級距樣式。

### v1.6.0 20220913

- **Variables** 共用變數
  - **Color Swatches**
    - 新增 1 個新色票：`$cub-danger-pale`。
  - **Images**：
    - 新增 2 個 base64 圖片：`$cub-img-caret-left-8`、`$cub-img-caret-rigth-8`。
- **Utilities** 共用樣式
  - 新增 2 種分隔線樣式：`.cub-divider`、`.cub-divider-dashed`。
  - 新增 **Color** 樣式：新增 20 個文字顏色、23 個背景顏色、21 個邊框顏色。

### v1.7.0 20221130

- **Typography** 文字樣式
  - 調整**標題**在文字多行時，左側裝飾會隨文字換行而長高。
- **Variables** 共用變數
  - **Color Swatches**
    - 新增 1 個新色票：`$cub-neutral-sub-pale`。
- **Utilities** 共用樣式
  - 新增 **Color** 樣式： 新增 `$cub-neutral-sub-pale` 的文字顏色、背景顏色、邊框顏色。依序為 : `.cub-text-neutral-sub-pale`、`.cub-bg-neutral-sub-pale`、`.cub-border-neutral-sub-pale`。
- **Images** 共用圖片
  - 新增 2 張共用圖片：**Deny**、**Speechless**。

### v2.0.0 20230117

#### 重大改動 - 樣式設定（SCSS）

- **主題色票**：新版採用 **Material Design** 的顏色配置邏輯，將原本的 primary、danger 等顏色，統一調整為 50 至 900 的漸層色票。
- **主題樣式**：目前支援 `cathay-bank`、`cathay-hr` 兩種風格主題樣式。
- **元件樣式**：全部元件皆使用 `@mixin` 封裝元件樣式，可直接使用 `CSS` 檔案引用全部樣式，也可以使用 `SCSS` 並依照需求選擇部分引用。
- **SCSS 變數設定**：全部元件皆有搭配 **SCSS 變數設定**，可透過調整 **SCSS 變數**來設定新元件樣式，新版本的變數名稱統一移除前綴 `cub` 名稱。

#### 元件調整

- **Variables** 共用變數
  - **Color Swatches**
    - 搭配 **Material Design** 新增漸層色票，並移除舊版色票：`$gray-palette`、`$green-palette`、`$yellow-green-palette`、`$orange-palette`、`$red-palette`、`$blue-palette`。
- **Images** 共用圖片
  - 調整圖片命名，統一移除前綴 `cub` 名稱。
  - 新增以下共用圖片的類別樣式：`.cub-img-nodata`、`.cub-img-laptop`、`.cub-img-report`、`.cub-img-clean`、`.cub-img-busy`、`.cub-img-fix`、`.cub-img-success`、`.cub-img-phonesecret`、`.cub-img-deny`、`.cub-img-speechless`、`.cub-img-notice-horizontal`。
- **Utilities** 共用樣式
  - 移除舊版不建議使用的 **Color** 樣式，僅保留以下樣式：
    - 文字顏色：`.cub-text-primary`、`.cub-text-accent`、`.cub-text-warn`、`.cub-text-info`、`.cub-text-neutral-dark`、`.cub-text-neutral`、`.cub-text-neutral-light`。
    - 背景顏色：`.cub-bg-primary-overlay`、`.cub-bg-accent-overlay`、`.cub-bg-warn-overlay`、`.cub-bg-info-overlay`、`.cub-bg-neutral-dark`、`.cub-bg-neutral`、`.cub-bg-neutral-light`。
    - 邊框顏色：`.cub-border-primary`、`.cub-border-accent`、`.cub-border-warn`、`.cub-border-info`、`.cub-border-neutral`。
- **Typography** 文字樣式
  - 調整文字行高：預設為 1.5 行高，標題則為 1.4 行高。
  - 移除自訂標題樣式：`.cub-title`、`.cub-title-sm`、`.cub-title-h1` ~ `.cub-title-h6`。
  - 新增前綴樣式：將自訂標題樣式的前綴圖示抽成獨立的元件樣式 `.cub-decorate`，可與 `.cub-h1` ~ `.cub-h6` 搭配使用。

### v2.0.1 20230216

#### 元件調整

- **Variables** 共用變數
  - **Color Swatches**
    - 調整 `$red-palette` 色票設定。
    - 調整 `$light-theme-foreground-palette` 色票設定。

### v2.0.2 20230310

#### 元件調整

- **Typography** 文字樣式
  - 將 `.cub-decorate` 換行顯示方式改為換行樣式。
  - 調整原生標題 `h1` ~ `h6` 的文字顏色與字體尺寸。
- **Utilities** 共用樣式
  - **Ordered List**：移除 `<li>` 最後一項的下方間距。
  - **Unordered List**：移除 `<li>` 最後一項的下方間距。
- **Images** 共用圖片
  - **Logo**：更新國泰世華銀行、國泰金控 LOGO 圖片。

### v2.0.3 20230314

#### 元件調整

- **Variables** 共用變數
  - 修正共用圖片引用路徑錯誤的問題，將移除共用圖片引用路徑變數 `$image-path`;
- **Images** 共用圖片
  - 刪除 2 個 LOGO 圖檔：`cub_logo_cathay_bank_white.svg`、`cub_logo_cathay_bank_zh_en.svg`。
  - 新增 15 個 base64 圖片：`$img-date-time-14`、`$img-user-40`、`$img-agent-40`、`$img-bell-40`、`$img-nodata-450`、`$img-laptop-450`、`$img-report-450`、`$img-clean-450`、`$img-busy-450`、`$img-fix-450`、`$img-success-450`、`$img-phonesecret-450`、`$img-deny-450`、`$img-speechless-450`、`$img-notice-horizontal-350`。
  - 修正共用圖片引用路徑錯誤的問題，將類別樣式的圖片引用路徑由 SVG 圖片改為 base64 圖片。
  - 調整 `.cub-img` 共用圖片顯示尺寸。
  - 調整圖片名稱，將檔名由 `cub_img_no_data.svg` 改為 `cub_img_nodata.svg`。
  - 更新以下共用圖片的 SVG 圖檔：`cub_img_nodata`、`cub_img_laptop`、`cub_img_report`、`cub_img_clean`、`cub_img_busy`、`cub_img_fix`、`cub_img_success`、`cub_img_phonesecret`。

### v2.1.0 20230615

#### 元件調整

- **Images** 共用圖片
  - 新增 1 張 **Logo**：國泰企業識別 LOGO
  - 新增 16 個 base64 圖片：`$img-caret-left-to-line-32`、`$img-caret-right-to-line-32`、`$img-chevrons-up-24`、`$img-chevrons-down-24`、`$img-arrow-up-24`、`$img-arrow-down-24`、`$img-arrow-up-to-line-24`、`$img-arrow-down-to-line-24`、`$img-chevron-left-18`、`$img-chevron-right-18`、`$img-chevrons-left-18`、`$img-chevrons-right-18`、`$img-arrow-up-18`、`$img-arrow-down-18`、`$img-arrow-up-to-line-18`、`$img-arrow-down-to-line-18`。

### v2.1.1 20230703

#### 元件調整

- **Images** 共用圖片
  - 新增 1 個 base64 圖片：`$img-chinese-numbered-list-24`。

### v2.1.2 20230711

#### 元件調整

- **Reset** 樣式重置設定
  - 移除文字 `p` 間距樣式的 `!important` 權重設定
- **Variables** 共用變數
  - **Core**： 新增元件 **Lightbox** 的 `z-index` 變數設定

### v2.1.3 20230802

#### 元件調整

- **Images** 共用圖片
  - 調整變數名稱，將名稱由 `$img-chinese-numbered-list-24` 改為 `$img-chinese-numbered-list-20`，並更新該共用圖片的 SVG 圖檔。

### v2.1.4 20231023

#### 元件調整

- **Reset** 樣式重置設定
  - 調整列印顏色模式，由 `economy` 調整為 `exact`。
- **Variables** 共用變數
  - **Color Swatches**
    - 調整 `$orange-palette` 色票設定。

### v2.2.0 20231207

#### 元件調整

- **Utilities** 共用樣式
  - **Divider**：新增 `.cub-divider`、`.cub-divider-dashed` 2 種分隔線樣式 。
  - **Spacing**：新增 x、y 軸的間距樣式。
- **Images** 共用圖片
  - 新增 1 個 base64 圖片：`$img-siren-24`。
  - 新增 1 個類別樣式：`.cub-img-siren`。

### v2.3.0 20240221

#### 元件調整

- **Utilities** 共用樣式
  - **Spacing**：新增 gap 的間距樣式。
- **Images** 共用圖片
  - 新增 1 個類別樣式：`.cub-img-bg-preview`。
  - 新增 4 張背景圖片：**Peview Background（767 尺寸、1024 尺寸、1440 尺寸、1920 尺寸）**。

### v2.3.1 20240320

#### 元件調整

- **Utilities** 共用樣式
  - 修正 **Ordered List** 與 **Unordered List** 在巢狀結構搭配使用的樣式設定問題。

### v2.3.2 20240606

#### 元件調整

- **Typography** 文字樣式
  - 調整 `.cub-h1` ~ `.cub-h6` 的預設上下間距。
  - 調整 `h6` 的文字字重，由 `normal` 調整為 `bold`。
- **Variables** 共用變數
  - **Color Swatches**
    - 統一新增色票的 70 色號設定。
    - 調整 `$green-palette`、`$yellow-green-palette`、`$orange-palette`、`$red-palette`、`$blue-palette` 300 色號對應的文字顏色。

### v2.3.3 20240923

#### 元件新增

- **Core**
  - **Theming**
    - 新增 Public function `get-color-config`，與關聯使用的兩個 Private function `private-is-theme-object` 和 `private-is-legacy-constructed-theme`。

### v2.4.0 20250219

- **Utilities** 共用樣式
  - **Sizing**：新增 25、50、75、100 等常用寬度。
  - **Display**：新增 `.d-grid` 與 RWD 情境下的對應樣式。
- **Variables** 共用變數
  - 新增 `$sizing` 寬度數值設定。
  - 調整 `$displays` 設定，新增 **grid** 屬性。

### v2.4.1 20250318

- **Utilities** 共用樣式
  - **Sizing**：調整 `max-width` 與 `max-height` 的 class name。

### v3.0.0 20251128

- **Token**
  - 新增以 CSS Custom Properties 為基礎的設計變數（Token）。
  - 原有元件設定用的 SCSS Variables 已移除，舊版變數設定將無法沿用。
- **Color**
  - 新增全新階層色票，提供 1~11 階的漸層色彩配置。
  - 原有 50~900 的階層色票已調整為新的 1~11 的階層格式，舊版色票將無法沿用。
- **Radius**
  - 新增 `.cub-rounded`、`.cub-rounded-large`、`.cub-rounded-extra-large`、`.cub-rounded-pill`、`.cub-rounded-circle` 五種圓角樣式。
  - 新增 `.cub-rounded-top-*`、`.cub-rounded-bottom-*`、`.cub-rounded-left-*`、`.cub-rounded-right-*` 四種圓角方向。
- **Text**
  - 新增 `.cub-text-decoration-underline`、`.cub-text-decoration-line-through`、`.cub-text-decoration-none` 三種文字裝飾樣式。
  - 新增 22、36 字體大小，並移除 20、44、72 字體大小。
- **Heading**
  - 調整標題樣式風格與文字尺寸。
- **List**
  - 移除 `.cub-unordered-list-lg`、`.cub-ordered-list-lg` 大尺寸樣式。
- **Container**
  - 新增 `.cub-container`、`.cub-container-extra-small`、`.cub-container-small`、`.cub-container-large`、`.cub-container-extra-large` 五種容器尺寸。
- **Spacing**
  - 新增 2、64、72 間距尺寸，並移除 28、32、40 間距尺寸。
- **Core Function**
  - 新增函式：executeIfExists、deepMerge、parseValue。
- **Chart Setting**
  - 新增函式：calculateTooltipPosition、。
  - 新增介面：TooltipPositionParams、ChartDataSet、ChartData、BaseChartConfig、BarChartConfig、LineChartConfig。
  - 新增型別：TooltipStrategy、Position。
  - 新增預設配置：BASE_HORIZONTAL_BAR_CHART_CONFIG、BASE_VERTICAL_BAR_CHART_CONFIG、BASE_SINGLE_LINE_CHART_CONFIG、BASE_MULTIPLE_LINE_CHART_CONFIG。
- **Chart Token**
  - 新增 BASE_CHART_TOKENS 物件，包含完整的系統 Token 資料。
  - 新增 getToken 函式，用於取得圖表 Design Token 值，支援複合 key 路徑查詢（使用底線分隔）。
