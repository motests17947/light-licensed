import { BaseChartConfig } from '../core';

export interface BaseBarChartConfig {
  legend: {
    rectSize: number;
    rectWidth: number;
    rectHeight: number;
    rectGap: number;
    itemGap: number;
    offsetY: number;
  };
}

export interface BarChartConfig extends BaseChartConfig {
  bar: {
    animation: number;
    getColor: (value: any, index: number) => string;
  };

  gradient: {
    x1: string | null;
    y1: string | null;
    x2: string | null;
    y2: string | null;
    color: any[] | string;
    stops: [
      {
        offset: string | null;
        opacity: number;
      },
      {
        offset: string | null;
        opacity: number;
      }
    ];
  };

  valueLabel: {
    font: {
      size: number;
      weight: string | null;
      color: string | null | undefined;
    };
    format: (...args: any[]) => {};
  };
}
