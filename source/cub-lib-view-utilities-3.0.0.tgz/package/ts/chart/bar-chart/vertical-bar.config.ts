import { BarChartConfig, BaseBarChartConfig } from './bar-chart.interface';
import { getToken } from '../token';

export const BASE_VERTICAL_BAR_CHART_CONFIG: BaseBarChartConfig = {
  legend: {
    rectSize: 10,
    rectWidth: 10,
    rectHeight: 10,
    rectGap: 4,
    itemGap: 8,
    offsetY: 36,
  },
};

/** 垂直長條圖預設參數 */
export const verticalBarChartConfig: BarChartConfig = {
  /** 全局 */
  layout: {
    font: {
      size: getToken('typography_font_size_xs'),
      family: getToken('typography_font_family'),
      weight: getToken('typography_font_weight_regular'), // Not yet open
      color: getToken('color_auxiliary_700'), // Not yet open
    },
    margin: {
      inset: 0, // Not yet open
      top: 16,
      right: 8,
      bottom: 12,
      left: 24,
    },
    padding: {
      inset: 0, // Not yet open
      top: 0, // Not yet open
      right: 0, // Not yet open
      bottom: 3,
      left: 0, // Not yet open
    },
    width: {
      default: 0, // Not yet open
      min: 420,
      max: 0, // Not yet open
    },
    height: {
      default: 300,
      min: 0, // Not yet open
      max: 0, // Not yet open
    },
    innerScale: 1.2,
    delayTime: 10,
  },

  /** 座標軸 */
  axes: {
    x: {
      stroke: {
        width: 0, // Not yet open
        dashArray: 0, // Not yet open
        color: getToken('color_auxiliary_300'),
      },
      position: 'bottom', // Not yet open
      ticks: {
        position: 'bottom', // Not yet open
        count: 0, // Not yet open
        font: {
          size: getToken('typography_font_size_xxs'),
          weight: getToken('typography_font_weight_regular'), // Not yet open
          color: getToken('color_auxiliary_700'),
        },
        tickSizeOuter: {
          width: 0, // Not yet open
          dashArray: 0, // Not yet open
          color: null, // Not yet open
        },
        tickSize: {
          width: 4,
          dashArray: 0, // Not yet open
          color: null, // Not yet open
        },
        offset: 4,
        format: (x: string) => String(x),
      },
    },
    y: {
      stroke: {
        width: 0, // Not yet open
        dashArray: 0, // Not yet open
        color: getToken('color_auxiliary_300'),
      },
      position: 'left', // Not yet open
      ticks: {
        position: 'left', // Not yet open
        count: 6,
        font: {
          size: getToken('typography_font_size_xxs'), // Not yet open
          weight: getToken('typography_font_weight_regular'), // Not yet open
          color: getToken('color_auxiliary_700'), // Not yet open
        },
        tickSizeOuter: {
          width: 1,
          dashArray: 0, // Not yet open
          color: getToken('color_auxiliary_300'),
        },
        tickSize: {
          width: 0, // Not yet open
          dashArray: 0, // Not yet open
          color: 'transparent', // Not yet open
        },
        offset: 0, // Not yet open
        format: (y: number) => String(y),
      },
    },
  },

  /** 圖例 */
  legend: {
    enabled: true,
    font: {
      size: getToken('typography_font_size_xxs'),
      weight: getToken('typography_font_weight_semibold'), // Not yet open
      color: getToken('color_auxiliary_700'),
    },
    position: 'bottom', // Not yet open
    click: () => ({}), // Not yet open
    format: (x: string) => String(x),
  },

  /** Tooltip */
  tooltip: {
    margin: {
      inset: 4,
      top: 0, // Not yet open
      right: 0, // Not yet open
      bottom: 4,
      left: 0, // Not yet open
    },
    padding: {
      inset: 8,
      top: 0, // Not yet open
      right: 0, // Not yet open
      bottom: 0, // Not yet open
      left: 0, // Not yet open
    },
    style: {
      borderWidth: 0, // Not yet open
      borderStyle: '', // Not yet open
      borderColor: '', // Not yet open
      borderRadius: 2,
      backgroundColor: 'white',
    },
    click: () => ({}), // Not yet open
    hover: () => ({}), // Not yet open
    format: (x: string, y: number) => String(x) + ' : ' + String(y),
  },

  /** BarChartConfig */
  /** 長條區域 */
  bar: {
    animation: 400,
    getColor: (_: number, i: number) => {
      const colors = getToken('color_set_category_10x') as string[];
      return colors[i % colors.length];
    },
  },

  /** 長條漸層 Not yet open */
  gradient: {
    x1: '0%',
    y1: '100%',
    x2: '0%',
    y2: '0%',
    color: getToken('color_main_blue') as string,
    stops: [
      {
        offset: '0%',
        opacity: 0.8,
      },
      {
        offset: '100%',
        opacity: 0.3,
      },
    ],
  },

  /** 數值標籤 */
  valueLabel: {
    font: {
      size: getToken('typography_font_size_xxs'),
      weight: getToken('typography_font_weight_regular'),
      color: getToken('color_auxiliary_700'),
    },
    format: (x: string, y: number) => String(y),
  },
};
