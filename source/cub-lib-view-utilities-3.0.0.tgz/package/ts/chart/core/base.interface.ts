import { Position } from './base.type';

/* 多資料類別介面 */
export interface ChartDataSet {
  type: string;
  data: ChartData[];
}

/* 單資料介面 */
export interface ChartData {
  label: string;
  value: number;
}

/* 文字規格 */
export interface BaseFontConfig {
  size: number;
  family?: string | null;
  weight: string | null;
  color: string | null | undefined;
}

/* 線條規格 */
export interface BaseStrokeConfig {
  width: number;
  dashArray: number;
  color: string | null | undefined;
}

/* 間距規格 */
export interface BaseSpacingConfig {
  inset: number;
  top: number;
  right: number;
  bottom: number;
  left: number;
}

/* 尺寸(寬高)規格 */
export interface BaseSizeConfig {
  default: number;
  min: number;
  max: number;
}

/** 
 * Base 圖表規格
 * 包含 Layout 佈局、Axes 軸線、Legend 圖例、Tooltip 工具提示
 */
export interface BaseChartConfig {
  layout: {
    font: BaseFontConfig;
    margin: BaseSpacingConfig;
    padding: BaseSpacingConfig;
    width: BaseSizeConfig;
    height: BaseSizeConfig;
    innerScale: number;
    delayTime: number;
  };

  axes: {
    x: {
      stroke: BaseStrokeConfig;
      position: Position;
      ticks: {
        position: Position;
        count: number;
        font: BaseFontConfig;
        tickSizeOuter: BaseStrokeConfig;
        tickSize: BaseStrokeConfig;
        offset: number;
        format: (...args: any[]) => {};
      };
    };
    y: {
      stroke: BaseStrokeConfig;
      position: Position;
      ticks: {
        position: Position;
        count: number;
        font: BaseFontConfig;
        tickSizeOuter: BaseStrokeConfig;
        tickSize: BaseStrokeConfig;
        offset: number;
        format: (...args: any[]) => {};
      };
    };
  };

  legend: {
    enabled: boolean;
    font: BaseFontConfig;
    position: Position;
    click: () => {};
    format: (...args: any[]) => {};
  };

  tooltip: {
    margin: BaseSpacingConfig;
    padding: BaseSpacingConfig;
    style: {
      borderWidth: number;
      borderStyle: string | null;
      borderColor: string | null | undefined;
      borderRadius: number;
      backgroundColor: string | null | undefined;
    };
    click: () => {};
    hover: () => {};
    format: (...args: any[]) => {};
  };

  [key: string]: any;
}
