import { BaseChartConfig } from '../core';

export interface BaseLineChartConfig {
  hover: { sensingArea: number };
  auxiliary: { pointRadius: number };
  legend: {
    rectSize: number;
    rectWidth: number;
    rectHeight: number;
    rectGap: number;
    itemGap: number;
    offsetY: number;
  };
}

export interface LineChartConfig extends BaseChartConfig {
  stroke: {
    color: any[] | string | null | undefined;
    width: number;
    animation: number;
  };

  gradient: {
    x1: string | null;
    y1: string | null;
    x2: string | null;
    y2: string | null;
    color: any[] | string | null | undefined;
    stops: [
      {
        offset: string | null;
        opacity: number;
      },
      {
        offset: string | null;
        opacity: number;
      }
    ];
  };

  valueLabel: {
    font: {
      size: number;
      weight: string | null;
      color: string | null | undefined;
    };
    format: (...args: any[]) => {};
  };

  auxiliary: {
    point: {
      shape: string;
      color: any[] | string | null | undefined;
    };
    line: {
      width: number;
      dashArray: number;
      color: string | null | undefined;
    };
    click: () => {};
    hover: () => {};
  };
}
