import { getToken } from '../token';
import { BaseLineChartConfig, LineChartConfig } from './line-chart.interface';

export const BASE_MULTIPLE_LINE_CHART_CONFIG: BaseLineChartConfig = {
  hover: { sensingArea: 30 },
  auxiliary: { pointRadius: 3 },
  legend: {
    rectSize: 10,
    rectWidth: 10,
    rectHeight: 4,
    rectGap: 4,
    itemGap: 8,
    offsetY: 45,
  },
};

/** 多線折線圖預設參數 */
export const multipleLineChartConfig: LineChartConfig = {
  /** 全局 */
  layout: {
    font: {
      size: getToken('typography_font_size_xs'),
      family: getToken('typography_font_family'),
      weight: getToken('typography_font_weight_regular'), // Not yet open
      color: getToken('color_auxiliary_700'), // Not yet open
    },
    margin: {
      inset: 0, // Not yet open
      top: 16,
      right: 8,
      bottom: 30,
      left: 32,
    },
    padding: {
      inset: 0, // Not yet open
      top: 0, // Not yet open
      right: 24,
      bottom: 3,
      left: 24,
    },
    width: {
      default: 0, // Not yet open
      min: 480,
      max: 0, // Not yet open
    },
    height: {
      default: 300,
      min: 0, // Not yet open
      max: 0, // Not yet open
    },
    innerScale: 1.2,
    delayTime: 100,
  },

  /** 座標軸 */
  axes: {
    x: {
      stroke: {
        width: 0, // Not yet open
        dashArray: 0, // Not yet open
        color: getToken('color_auxiliary_300'),
      },
      position: 'bottom', // Not yet open
      ticks: {
        position: 'bottom', // Not yet open
        count: 0, // Not yet open
        font: {
          size: getToken('typography_font_size_xxs'),
          weight: getToken('typography_font_weight_regular'), // Not yet open
          color: getToken('color_auxiliary_700'),
        },
        tickSizeOuter: {
          width: 0, // Not yet open
          dashArray: 0, // Not yet open
          color: null, // Not yet open
        },
        tickSize: {
          width: 4,
          dashArray: 0, // Not yet open
          color: null, // Not yet open
        },
        offset: 4,
        format: (x: string) => String(x) + ' 月',
      },
    },
    y: {
      stroke: {
        width: 0, // Not yet open
        dashArray: 0, // Not yet open
        color: 'transparent', // Not yet open
      },
      position: 'left', // Not yet open
      ticks: {
        position: 'left', // Not yet open
        count: 6,
        font: {
          size: getToken('typography_font_size_xxs'), // Not yet open
          weight: getToken('typography_font_weight_regular'), // Not yet open
          color: getToken('color_auxiliary_700'), // Not yet open
        },
        tickSizeOuter: {
          width: 1,
          dashArray: 0, // Not yet open
          color: getToken('color_auxiliary_300'),
        },
        tickSize: {
          width: 0, // Not yet open
          dashArray: 0, // Not yet open
          color: 'transparent', // Not yet open
        },
        offset: 0, // Not yet open
        format: (y: number) => String(y),
      },
    },
  },

  /** 圖例 */
  legend: {
    enabled: true,
    font: {
      size: getToken('typography_font_size_xxs'),
      weight: getToken('typography_font_weight_semibold'), // Not yet open
      color: getToken('color_auxiliary_700'),
    },
    position: 'bottom', // Not yet open
    click: () => ({}), // Not yet open
    format: (type: string) => String(type),
  },

  /** Tooltip */
  tooltip: {
    margin: {
      inset: 4,
      top: 0, // Not yet open
      right: 0, // Not yet open
      bottom: 4,
      left: 0, // Not yet open
    },
    padding: {
      inset: 8,
      top: 0, // Not yet open
      right: 0, // Not yet open
      bottom: 0, // Not yet open
      left: 0, // Not yet open
    },
    style: {
      borderWidth: 0, // Not yet open
      borderStyle: '', // Not yet open
      borderColor: '', // Not yet open
      borderRadius: 2,
      backgroundColor: 'white',
    },
    click: () => ({}), // Not yet open
    hover: () => ({}), // Not yet open
    format: (type: string, x: string, y: number) =>
      String(type) + ' : ' + String(y),
  },

  /** LineChartConfig */
  /** 線條區域 */
  stroke: {
    color: getToken('color_set_category_5x'),
    width: 2,
    animation: 400,
  },

  /** 多線條漸層 Not yet open */
  gradient: {
    x1: '0%',
    y1: '0%',
    x2: '0%',
    y2: '100%',
    color: getToken('color_set_category_5x'),
    stops: [
      {
        offset: '0%',
        opacity: 0.6,
      },
      {
        offset: '75%',
        opacity: 0,
      },
    ],
  },

  /** 數值標籤 */
  valueLabel: {
    font: {
      size: getToken('typography_font_size_xxs'),
      weight: getToken('typography_font_weight_regular'),
      color: getToken('color_auxiliary_700'),
    },
    format: (x: string, y: number) => String(y),
  },

  /** 輔助節點標記 */
  auxiliary: {
    point: {
      shape: 'circle', // Not yet open
      color: getToken('color_set_category_5x'), // Not yet open (使用 stroke.color)
    },
    line: {
      width: 1,
      dashArray: 6,
      color: getToken('color_auxiliary_300'),
    },
    click: () => ({}), // Not yet open
    hover: () => ({}), // Not yet open
  },
};
