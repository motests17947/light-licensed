import tokensData from './sys-token.json';

import { TokenStructure } from './token.interface';

// 使用匯入的資料
const BASE_CHART_TOKENS: TokenStructure = tokensData;

export { BASE_CHART_TOKENS };
