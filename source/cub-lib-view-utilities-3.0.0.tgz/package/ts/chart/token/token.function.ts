import { TokenValue } from './token.type';
import { BASE_CHART_TOKENS } from './token.const';

/**
 * 取得圖表 token 值
 * 處理複合 key (例如 color_set, font_size)
 *
 * @param path - token 路徑，使用底線分隔
 * @returns token 值
 */
export function getToken(path: string): TokenValue | undefined {
  let value: any = BASE_CHART_TOKENS;
  let remaining: string = path;

  while (remaining && value != null) {
    const parts: string[] = remaining.split('_');
    let found: boolean = false;

    // 從最長的 key 開始嘗試匹配
    for (let i = parts.length; i > 0; i--) {
      const key: string = parts.slice(0, i).join('_');

      if (key in value) {
        value = value[key];
        remaining = parts.slice(i).join('_');
        found = true;
        break;
      }
    }

    if (!found) {
      console.warn(`Token "${path}" not found at "${remaining}"`);
      return undefined;
    }

    if (!remaining) return value;
  }

  return value;
}
