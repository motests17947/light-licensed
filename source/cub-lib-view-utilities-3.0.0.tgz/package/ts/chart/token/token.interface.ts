// 定義 token 結構的型別
export interface ColorSetToken {
  category: {
    '5x': string[];
    '10x': string[];
  };
  order: {
    green: string[];
    blue: string[];
    purple: string[];
    yellow: string[];
    orange: string[];
  };
  diverging: {
    blue: string[];
    orange: string[];
  };
  semantic: {
    positive: string;
    caution: string;
    negative: string;
  };
}

export interface ColorToken {
  main: {
    green: string;
    blue: string;
    purple: string;
    yellow: string;
    orange: string;
  };
  auxiliary: {
    '100': string;
    '200': string;
    '300': string;
    '400': string;
    '500': string;
    '600': string;
    '700': string;
  };
}

export interface TypographyToken {
  font_size: {
    xxs: number;
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
  };
  font_weight: {
    regular: number;
    medium: number;
    semibold: number;
    bold: number;
  };
  font_family: string;
}

export interface TokenStructure {
  color_set: ColorSetToken;
  color: ColorToken;
  typography: TypographyToken;
}
