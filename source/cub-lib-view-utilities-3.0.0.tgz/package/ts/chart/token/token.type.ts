import { TokenStructure } from './token.interface';

// Token 值的聯合型別
export type TokenValue =
  | string
  | number
  | string[]
  | TokenStructure[keyof TokenStructure]
  | any;
