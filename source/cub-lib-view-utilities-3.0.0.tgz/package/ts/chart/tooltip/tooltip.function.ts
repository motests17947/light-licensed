import { TooltipPositionParams } from './tooltip.interface';

export function calculateTooltipPosition(params: TooltipPositionParams): {
  x: number;
  y: number;
} {
  const {
    anchorX,
    anchorY,
    tooltipWidth,
    tooltipHeight,
    strategy,
    svgRect,
    scrollableRect,
    safeMargin,
    offset = 4,
    anchorWidth = 0,
    anchorHeight = 0,
    marginLeft = 0,
  } = params;

  let screenX: number = 0;
  let screenY: number = 0;

  if (strategy === 'center-top') {
    const anchorCenterX = anchorX + anchorWidth / 2;
    const pointScreenX = svgRect.left + anchorCenterX;
    const pointScreenY = svgRect.top + anchorY;

    screenX = Math.max(
      scrollableRect.left + safeMargin - marginLeft,
      Math.min(
        pointScreenX - tooltipWidth / 2,
        scrollableRect.right - marginLeft - tooltipWidth - safeMargin,
      ),
    );

    screenY = pointScreenY - tooltipHeight - offset;

    if (screenY < scrollableRect.top + safeMargin) {
      screenY = pointScreenY + offset;
    }

    if (screenY + tooltipHeight > scrollableRect.bottom - safeMargin) {
      screenY = scrollableRect.bottom - tooltipHeight - safeMargin;
    }
  } else if (strategy === 'right-center') {
    const anchorCenterY = anchorY + anchorHeight / 2;
    const pointScreenY = svgRect.top + anchorCenterY;

    screenX = svgRect.left + anchorX + offset;
    const rightBoundary = scrollableRect.right - safeMargin;

    if (screenX + tooltipWidth > rightBoundary) {
      screenX = Math.max(
        scrollableRect.left + safeMargin,
        Math.min(
          svgRect.left + anchorX - tooltipWidth - offset,
          rightBoundary - tooltipWidth,
        ),
      );
    }

    screenY = Math.max(
      scrollableRect.top + safeMargin,
      Math.min(
        pointScreenY - tooltipHeight / 2,
        scrollableRect.bottom - tooltipHeight - safeMargin,
      ),
    );
  }

  return {
    x: Math.max(0, screenX - svgRect.left),
    y: Math.max(0, screenY - svgRect.top),
  };
}
