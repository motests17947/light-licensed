import { TooltipStrategy } from './tooltip.type';

export interface TooltipPositionParams {
  anchorX: number;
  anchorY: number;
  tooltipWidth: number;
  tooltipHeight: number;
  strategy: TooltipStrategy;
  svgRect: DOMRect;
  scrollableRect: DOMRect;
  safeMargin: number;
  offset?: number;
  anchorWidth?: number;
  anchorHeight?: number;
  marginLeft?: number; // 折線圖專用
}
