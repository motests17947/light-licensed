export type TooltipStrategy = 'center-top' | 'right-center';
