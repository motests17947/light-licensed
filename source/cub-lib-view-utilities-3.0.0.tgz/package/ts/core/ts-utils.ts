/* 檢查方法是否存在並執行 */
export function executeIfExists(
  context: any,
  methodName: string,
  ...args: any[]
): void {
  const method = context[methodName];

  if (typeof method === 'function') {
    try {
      method.apply(context, args);
    } catch (error) {
      console.warn(`執行 ${methodName} 時發生錯誤:`, error);
    }
  }
}

/* 深度合併物件*/
export function deepMerge(target: any, source: any): any {
  const result = { ...target };

  for (const key in source) {
    if (source.hasOwnProperty(key)) {
      if (
        source[key] &&
        typeof source[key] === 'object' &&
        !Array.isArray(source[key])
      ) {
        result[key] = deepMerge(result[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    }
  }

  return result;
}

/* 處理 string/number 的值轉換 */
export function parseValue(value: string | number): number {
  return typeof value === 'string' ? parseFloat(value) : value;
}
